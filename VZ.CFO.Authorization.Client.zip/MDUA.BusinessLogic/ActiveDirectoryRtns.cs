using System;
using System.Collections;
using System.Configuration;
using System.DirectoryServices;
//using System.Web.UI;
//using System.Web.UI.WebControls;
//using System.Web.UI.WebControls.WebParts;
//using System.Web.UI.HtmlControls;

namespace MDUA.BusinessLogic
{

    /// <summary>
    /// Summary description for ActiveDirectoryRtns
    /// </summary>
    public class ActiveDirectoryRtns
    {
        public class ADUserInfo
        {
            public string FirstName = "";
            public string LastName = "";
            public string email = "";
            public string EmployeeId = "";
            public string UserId = "";

            public ADUserInfo()
            {
            }
        }

        public ActiveDirectoryRtns()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private static DirectorySearcher getSearcher()
        {
            DirectoryEntry entry = new DirectoryEntry();
            entry.Path = ConfigurationManager.AppSettings["ADServer"];
            //entry.Username = _serviceAccountName;
            //entry.Password = _servicePassword;

            return new DirectorySearcher(entry);
        }

        public static string ExtractUserName(string path)
        {
            string[] userPath = path.Split('\\');
            return userPath[userPath.Length - 1];
        }

        public static bool IsExistInAD(string loginName)
        {
            string userName = ExtractUserName(loginName);
            DirectorySearcher search = getSearcher();
            search.Filter = string.Format("(SAMAccountName={0})", userName);
            search.PropertiesToLoad.Add("cn");
            SearchResult result = search.FindOne();

            if (result == null)
                return false;
            else
                return true;
        }

        public static ArrayList GetADGroupUsers(string groupName)
        {
            SearchResult result;
            DirectorySearcher search = getSearcher();
            search.Filter = string.Format("(cn={0})", groupName);
            search.PropertiesToLoad.Add("member");

            ArrayList arrNames = new ArrayList();

            try
            {
                result = search.FindOne();
            }
            catch (DirectoryServicesCOMException dsce)
            {
                MDUA.DataAccess.DbAccess.LogEvent(null, "ActiveDirectoryRtns.GetADGroupUsers", dsce.Message, "Failure", LogLevel.Error);
                return arrNames;
            }

            if (result != null)
            {
                for (int counter = 0; counter < result.Properties["member"].Count; counter++)
                {
                    // "CN=Bellone\\, Patrick bellopa,OU=IT,OU=Users,OU=HQ,DC=uswin,DC=ad,DC=vzwcorp,DC=com"
                    string MemberInfo = (string)result.Properties["member"][counter];
                    int Start = MemberInfo.IndexOf("CN=");
                    if (Start >= 0)
                    {
                        int End = MemberInfo.IndexOf('=', Start + 3);
                        if (End < 0)
                            MemberInfo = MemberInfo.Substring(Start + 3);
                        else
                        {
                            End = MemberInfo.Substring(Start + 3, End - Start).LastIndexOf(',');
                            MemberInfo = MemberInfo.Substring(Start + 3, End);
                        }

                        Start = MemberInfo.LastIndexOf(' ');
                        arrNames.Add(MemberInfo.Substring(Start + 1));
                    }
                }
            }

            return arrNames;
        }

        public static ArrayList ADSearchUsers(string groupName)
        {
            ArrayList arrUsers = GetADGroupUsers(groupName);
            if (arrUsers == null || arrUsers.Count == 0)
                return null;

            DirectorySearcher mySearcher = getSearcher();
            mySearcher.PageSize = 10;
            mySearcher.CacheResults = false;

            //Add all properties that need to be fetched   
            mySearcher.PropertiesToLoad.Add("samAccountName");
            mySearcher.PropertiesToLoad.Add("employeeid");
            mySearcher.PropertiesToLoad.Add("mail");
            mySearcher.PropertiesToLoad.Add("sn");
            mySearcher.PropertiesToLoad.Add("givenname");

            //The search scope specifies how deep the search needs to be, it can be either 
            //"base"- which means only in the current 
            //level, and "OneLevel" which means the
            //base and one level below and then "subtree"-which means the entire tree needs 
            //to be searched.
            mySearcher.SearchScope = SearchScope.Subtree;

            ArrayList arrNames = new ArrayList();
            foreach (string sUser in arrUsers)
            {
                mySearcher.Filter = string.Format("(&(objectCategory=user)(samAccountName={0}))", sUser);
                //mySearcher.Filter = string.Format("(&(objectCategory=user)(cn={0}))", sUser);
                SearchResultCollection resultUsers = mySearcher.FindAll();

                foreach (SearchResult srUser in resultUsers)
                {
                    try
                    {
                        DirectoryEntry de = srUser.GetDirectoryEntry();

                        //  Get the search result from the collection
                        ADUserInfo aui = new ADUserInfo();
                        aui.email = (string)de.Properties["mail"].Value;
                        aui.EmployeeId = (string)de.Properties["employeeid"].Value;
                        aui.FirstName = (string)de.Properties["givenname"].Value;
                        aui.LastName = (string)de.Properties["sn"].Value;
                        aui.UserId = (string)de.Properties["samAccountName"].Value;
                        arrNames.Add(aui);

                        de.Close();
                    }

                    catch (Exception ex)
                    {
                        MDUA.DataAccess.DbAccess.LogEvent(null, "ActiveDirectoryRtns.ADSearchUsers", ex.Message, ex, LogLevel.FatalError);
                        throw ex;
                    }
                }
            }

            return arrNames;
        }


        public static ADUserInfo ADSearchUser(string samAccountName)
        {
            DirectorySearcher mySearcher = getSearcher();
            mySearcher.PageSize = 10;
            mySearcher.CacheResults = false;

            //Add all properties that need to be fetched   
            mySearcher.PropertiesToLoad.Add("samAccountName");
            mySearcher.PropertiesToLoad.Add("employeeid");
            mySearcher.PropertiesToLoad.Add("mail");
            mySearcher.PropertiesToLoad.Add("sn");
            mySearcher.PropertiesToLoad.Add("givenname");

            //The search scope specifies how deep the search needs to be, it can be either 
            //"base"- which means only in the current 
            //level, and "OneLevel" which means the
            //base and one level below and then "subtree"-which means the entire tree needs 
            //to be searched.
            mySearcher.SearchScope = SearchScope.Subtree;

            mySearcher.Filter = string.Format("(&(objectCategory=user)(samAccountName={0}))", samAccountName);
            SearchResultCollection resultUsers = mySearcher.FindAll();

            foreach (SearchResult srUser in resultUsers)
            {
                try
                {
                    DirectoryEntry de = srUser.GetDirectoryEntry();

                    //  Get the search result from the collection
                    ADUserInfo aui = new ADUserInfo();
                    aui.email = (string)de.Properties["mail"].Value;
                    aui.EmployeeId = (string)de.Properties["employeeid"].Value;
                    aui.FirstName = (string)de.Properties["givenname"].Value;
                    aui.LastName = (string)de.Properties["sn"].Value;
                    aui.UserId = (string)de.Properties["samAccountName"].Value;

                    de.Close();
                    return aui;
                }

                catch (Exception ex)
                {
                    MDUA.DataAccess.DbAccess.LogEvent(null, "ActiveDirectoryRtns.ADSearchUser", ex.Message, ex, LogLevel.FatalError);
                    throw ex;
                }
            }

            return null;
        }


        public static ArrayList GetADUserGroups(string loginName)
        {
            //DirectoryEntry DE = new DirectoryEntry("LDAP://USWIN");

            DirectorySearcher search = getSearcher();
            //search.SearchRoot = DE;
            search.Filter = string.Format("(SAMAccountName={0})", loginName);
            search.PropertiesToLoad.Add("memberOf");

            ArrayList arrGroups = new ArrayList();
            SearchResult result = search.FindOne();
            if (result != null)
            {
                int groupCount = result.Properties["memberOf"].Count;
                for (int counter = 0; counter < groupCount; counter++)
                {
                    // CN=ScannerSupport,OU=Groups,OU=HQ,DC=uswin,DC=ad,DC=vzwcorp,DC=com
                    string GroupInfo = (string)result.Properties["memberOf"][counter];
                    int Start = GroupInfo.IndexOf("CN=");
                    if (Start >= 0)
                    {
                        int End = GroupInfo.IndexOf(',', Start + 2);
                        if (End < 0)
                            arrGroups.Add(GroupInfo.Substring(Start + 3));
                        else
                            arrGroups.Add(GroupInfo.Substring(Start + 3, End - Start - 3));
                    }
                }
            }
            return arrGroups;
        }

        public static string GetUserInfo(string inSAM, string inType)
        {
            try
            {
                //string sPath = "LDAP://uswin";
                string SamAccount = ExtractUserName(inSAM);
                DirectorySearcher mySearcher = getSearcher();
                SearchResultCollection mySearchResultColl = null;
                SearchResult mySearchResult = null;
                ResultPropertyCollection myResultPropColl = null;
                ResultPropertyValueCollection myResultPropValueColl = null;

                //Build LDAP query
                mySearcher.Filter = ("(&(objectClass=user)(samaccountname=" + SamAccount + "))");
                mySearchResultColl = mySearcher.FindAll();

                if (mySearchResultColl.Count == 0 || mySearchResultColl.Count > 1)
                    return null;

                //  Get the search result from the collection
                mySearchResult = mySearchResultColl[0];

                //  Get the Properites, they contain the usefull info
                myResultPropColl = mySearchResult.Properties;

                //displayname, mail
                // Retrieve from the properties collection the display name and email of the user
                myResultPropValueColl = myResultPropColl[inType];
                return (string)myResultPropValueColl[0];
            }

            catch (Exception)
            {
            }

            return null;
        }
    } // end of class
} // end of namespace 