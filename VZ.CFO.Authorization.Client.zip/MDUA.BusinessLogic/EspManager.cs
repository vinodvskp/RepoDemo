﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MDUA.DTO;
using MDUA.DataAccess;
using System.Globalization;
namespace MDUA.BusinessLogic
{
    public class EspManager
    {
        #region Public Methods
        /// <summary>
        /// Run LAP command without generation
        /// </summary>
        /// <param name="jobName"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public EspJobStatus GetJobStatus(string jobName, string subApplName, string userId)
        {
            return GetJobStatus(jobName, subApplName, userId, null);
        }
        
        /// <summary>
        /// Run LAP command with a generation
        /// </summary>
        /// <param name="jobName"></param>
        /// <param name="userId"></param>
        /// <param name="generation"></param>
        /// <returns></returns>
        public EspJobStatus GetJobStatus(string jobName, string subApplName, string userId, long? generation)
        {
            EspDataAccess espDataAccess = new EspDataAccess();
            //Validate Inputs
            if (string.IsNullOrEmpty(jobName))
            {
                throw new ArgumentException("jobName cannot be null or empty");
            }
            if (string.IsNullOrEmpty(userId))
            {
                throw new ArgumentException("userId cannot be null or empty");
            }
            
            //Prepare Esp Request Message
            EspMessage jobStatusRequestAllParentJob = new EspMessage();
            EspMessage jobStatusRequestAllChildJob = new EspMessage();
            EspMessage jobStatusRequestJobs = new EspMessage();
            jobStatusRequestAllParentJob.Info = new EspInfo() { Status = EspKnownValues.EspInfoStatus.Request, Cont = EspKnownValues.EspInfoCont.EOM, Type = EspKnownValues.EspInfoType.Command };
            jobStatusRequestJobs.Info = new EspInfo() { Status = EspKnownValues.EspInfoStatus.Request, Cont = EspKnownValues.EspInfoCont.EOM, Type = EspKnownValues.EspInfoType.Command };

            string espDataRequestAllStatusParentJob = string.Empty;
            string espDataRequestAllStatusChildJob = string.Empty;
            string espDataRequestJobsStatus = string.Empty;

            //Get Status for Parent Job
            espDataRequestAllStatusParentJob = string.Format(EspKnownValues.EspJobRequest.EspStatusRequestFormat, EspKnownValues.EspJobRequest.EspStatusCommand, jobName,
                    (generation == null) ? string.Empty : "." + Convert.ToString(generation), EspLapCommandStatus.ALL);

            //Prepare Request strings for child if specified
            if (!string.IsNullOrEmpty(subApplName))
            {
                //Get Status for Child Job
                espDataRequestAllStatusChildJob = string.Format(EspKnownValues.EspJobRequest.EspSubApplStatusRequestFormat, EspKnownValues.EspJobRequest.EspStatusCommand, jobName,
                        (generation == null) ? string.Empty : "." + Convert.ToString(generation), subApplName, EspLapCommandStatus.ALL);

                jobStatusRequestAllChildJob.Info = new EspInfo() { Status = EspKnownValues.EspInfoStatus.Request, Cont = EspKnownValues.EspInfoCont.EOM, Type = EspKnownValues.EspInfoType.Command };
                jobStatusRequestAllChildJob.Data = new EspData() { Request = espDataRequestAllStatusChildJob };
            }

            espDataRequestJobsStatus = string.Format(EspKnownValues.EspJobRequest.EspStatusRequestFormat, EspKnownValues.EspJobRequest.EspStatusCommand, jobName,
                            (generation == null) ? string.Empty : "." + Convert.ToString(generation), EspLapCommandStatus.JOBS);

            jobStatusRequestAllParentJob.Data = new EspData() { Request = espDataRequestAllStatusParentJob };
            jobStatusRequestJobs.Data = new EspData() { Request = espDataRequestJobsStatus };
            
            //Get Job Status with ALL Keyword - Parent Job
            EspMessage jobStatusAllMessageParent = espDataAccess.GetJobStatus(jobStatusRequestAllParentJob);

            EspMessage jobStatusAllMessageChild = new EspMessage();
            EspMessageExtract jobStatusAllMsgExtractChild = new EspMessageExtract();
            EspJobStatus jobStatusChild = new EspJobStatus();
            
            if (!string.IsNullOrEmpty(subApplName))
            {
                jobStatusAllMessageChild = espDataAccess.GetJobStatus(jobStatusRequestAllChildJob);
                jobStatusAllMsgExtractChild = ExtractJobStatus(jobStatusAllMessageChild, jobName);
                jobStatusChild = GetJobStatusFromExtract(jobStatusAllMsgExtractChild);
            }

            //Extract Parent job response
            EspMessageExtract jobStatusAllMsgExtractParent = ExtractJobStatus(jobStatusAllMessageParent, jobName);
            EspJobStatus jobStatusParent = GetJobStatusFromExtract(jobStatusAllMsgExtractParent);
            
            //Get Job Status with JOBS keyword
            EspMessage jobStatusJobsMessage = espDataAccess.GetJobStatus(jobStatusRequestJobs);
            EspMessageExtract jobStatusJobsMsgExtract = ExtractCompletedJobs(jobStatusJobsMessage);
            //Get the Completed and In Complete jobs
            jobStatusParent.CompletedJobs = jobStatusJobsMsgExtract.CompletedJobs;
            jobStatusParent.InCompleteJobs = jobStatusJobsMsgExtract.InCompleteJobs;

            if (string.IsNullOrEmpty(subApplName))
            {
                return jobStatusParent;
            }
            else
            {
                //In some scenerios, child job status doesnt show anticipated end keyword when its successor is running
                if (jobStatusParent.Status == EspJobStatusState.InCompleteDependentJobs)
                {
                    return jobStatusParent;
                }
                else
                {
                    return jobStatusChild;
                }
            }
        }

        public EspMessage TriggerJob(string jobName, string subAppName, string userId)
        {
            EspDataAccess espDataAccess = new EspDataAccess();
            //Validate Inputs
            if (string.IsNullOrEmpty(jobName))
            {
                throw new ArgumentException("JobName cannot be null or empty");
            }
            if (string.IsNullOrEmpty(userId))
            {
                throw new ArgumentException("UserId cannot be null or empty");
            }

            //Prepare Esp Request Message
            EspMessage jobTriggerRequest = new EspMessage();

            if (string.IsNullOrEmpty(subAppName))
            {
                //Trigger ParentJob
                jobTriggerRequest.Info = new EspInfo() { Status = EspKnownValues.EspInfoStatus.Request, Cont = EspKnownValues.EspInfoCont.EOM, Type = EspKnownValues.EspInfoType.Command };
                string espDataRequest = string.Format(EspKnownValues.EspJobRequest.EspTriggerReqtFmtParentApp, EspKnownValues.EspJobRequest.EspTriggerCommand, EspDataAccess.EspPrefix, jobName);
                jobTriggerRequest.Data = new EspData() { Request = espDataRequest };
            }
            else
            {
                //Trigger ChildJob
                jobTriggerRequest.Info = new EspInfo() { Status = EspKnownValues.EspInfoStatus.Request, Cont = EspKnownValues.EspInfoCont.EOM, Type = EspKnownValues.EspInfoType.Command };
                string espDataRequest = string.Format(EspKnownValues.EspJobRequest.EspTriggerReqFmtChildApp, EspKnownValues.EspJobRequest.EspTriggerCommand, EspDataAccess.EspPrefix, jobName, subAppName);
                jobTriggerRequest.Data = new EspData() { Request = espDataRequest };
            }
            
            //Get Job status
            EspJobStatus espJobStatus = GetJobStatus(jobName, string.Empty, userId);
            EspMessage jobStatusResponse = null;
            if (espJobStatus != null && (espJobStatus.Status == EspJobStatusState.AppNotDefined || espJobStatus.Status == EspJobStatusState.NoMatchingAppOrUnAuthorized || espJobStatus.Status == EspJobStatusState.Completed))
            {
                jobStatusResponse = espDataAccess.TriggerJob(jobTriggerRequest);
            }
            else
            {
                //TODO: Log why trigger is not possible;
                throw new ApplicationException("MDUA-ESP-001: Could not Trigger job because it is active or one of this dependent job is active.");
            }
            //Validate the response
            if (jobStatusResponse == null)
            {
                GeneralDatabaseAccess.LogEvent(userId, "EspManager.cs", "Trigger Job", "TriggerJob() returned null", UserToolLogLevel.Error);
                throw new ApplicationException("TriggerJob() returned null");
            }
            else if (jobStatusResponse.Info.Status != EspKnownValues.EspInfoStatus.Success)
            {
                LogError(userId, jobName, jobStatusResponse);
                throw new ApplicationException("Response status from TriggerJob() did not contain success.");
            }
            return jobStatusResponse;
        }
        
        #endregion

        #region Private Methods
        /// <summary>
        /// Converts string containing date in the format "HH.mm dddd MMMM dd yyyy"
        /// </summary>
        /// <param name="dateString"></param>
        /// <returns></returns>
        private static DateTime ParseEspDateTime(string dateString)
        {
            DateTime espDate = new DateTime();
            string[] dateFormats = { EspKnownValues.EspJobResponse.EspDateTimeFormatSingleDigitDay, EspKnownValues.EspJobResponse.EspDateTimeFormatDoubleDigitDay };
            if (DateTime.TryParseExact(dateString, dateFormats,
                    new CultureInfo("en-US"),
                    DateTimeStyles.None,
                    out espDate) == false)
            {
                GeneralDatabaseAccess.LogEvent("ParseEspDateTime", "EspManager.cs", "Error Parsing DateTime", dateString, UserToolLogLevel.Error);
            }
            return espDate;
        }

        /// <summary>
        /// Formats the string containing date to standard date string
        /// </summary>
        /// <param name="dateString"></param>
        /// <returns></returns>
        private static string FormatEspDateTime(string dateString)
        {
            //17.01 ON WEDNESDAY APRIL 20TH, 2016
            dateString = dateString.Replace(" ON", string.Empty);
            //17.01 WEDNESDAY APRIL 20TH, 2016
            dateString = dateString.Replace("ST,", string.Empty);
            dateString = dateString.Replace("TH,", string.Empty);
            dateString = dateString.Replace("ND,", string.Empty);
            dateString = dateString.Replace("RD,", string.Empty);
            //17.01 WEDNESDAY APRIL 20 2016
            return dateString;
        }

        /// <summary>
        /// Parses the http response from ESP and returns message extract
        /// </summary>
        /// <param name="response"></param>
        /// <param name="jobName"></param>
        /// <returns></returns>
        private static EspMessageExtract ExtractJobStatus(EspMessage response, string jobName)
        {
            EspMessageExtract espMessageExtract = new EspMessageExtract();
            if (response.Info != null && response.Info.Status != null)
            {
                if (response.Data != null && response.Data.list != null && response.Data.list.Length > 0)
                {
                    for (int listCounter=0; listCounter < response.Data.list.Length; listCounter++)
                    {
                        string trimmedString = response.Data.list[listCounter].Trim();
                        trimmedString = trimmedString.ToUpper();

                        if (trimmedString.Contains(EspKnownValues.EspJobResponse.AppNotDefined))
                        {
                            espMessageExtract.IsAppNotDefined = true;
                            //Found in the first line. No need to to look into other status, so can stop parsing here.
                            break;
                        }
                        else if (trimmedString.Contains(EspKnownValues.EspJobResponse.NoMatchingAppOrUnAuthorized))
                        {
                            espMessageExtract.IsNoMatchingAppOrUnAuthorized = true;
                            //Found in the first line. No need to to look into other status, so can stop parsing here.
                            break;
                        }
                        else if (trimmedString.Contains(EspKnownValues.EspJobResponse.InValidAppSpec))
                        {
                            espMessageExtract.IsInvalidAppSpec = true;
                            //Found in the first line. No need to to look into other status, so can stop parsing here.
                            break;

                        }
                        else if (trimmedString.StartsWith(EspKnownValues.EspJobResponse.Appl) && trimmedString.Contains(jobName) && trimmedString.Contains(EspKnownValues.EspJobResponse.Generation))
                        {
                            int genIndex = trimmedString.IndexOf(EspKnownValues.EspJobResponse.Generation);
                            string gen = trimmedString.Substring(genIndex);
                            gen = gen.Replace(EspKnownValues.EspJobResponse.Generation, string.Empty);
                            int endOfGen = gen.IndexOf(" ");
                            gen = endOfGen > 0 ? gen.Substring(0, endOfGen) : gen;
                            long lGen;
                            if (long.TryParse(gen, out lGen))
                            {
                                espMessageExtract.Generation = lGen;
                            }
                            else
                            {
                                GeneralDatabaseAccess.LogEvent("EspManager.cs", "ExtractJobStatus", "Cannot parse Generation. {0}", trimmedString, UserToolLogLevel.Debug);
                            }

                            if (trimmedString.Contains(EspKnownValues.EspJobResponse.Complete))
                            {
                                //This can be successfull complete or failed complete
                                espMessageExtract.IsComplete = true;
                            }

                            /*if (trimmedString.Contains("APPLWAIT"))
                            {
                                espMessageExtract.IsWaiting = true;
                            }*/
                        }

                        else if (trimmedString.StartsWith(EspKnownValues.EspJobResponse.CreatedAt))
                        {
                            //CREATED AT 17.01 ON WEDNESDAY APRIL 20TH, 2016
                            trimmedString = trimmedString.Replace(EspKnownValues.EspJobResponse.CreatedAt, string.Empty);
                            //17.01 ON WEDNESDAY APRIL 20TH, 2016
                            trimmedString = FormatEspDateTime(trimmedString);
                            //17.01 WEDNESDAY APRIL 20, 2016

                            DateTime startDate = ParseEspDateTime(trimmedString);
                            //TODO: Validate
                            espMessageExtract.StartedOn = startDate;

                            //If there is a end date, it would be on the next line; Try to get end date and stop parsing
                            if (listCounter + 1 < response.Data.list.Length)
                            {
                                listCounter++;
                                trimmedString = response.Data.list[listCounter].Trim();
                                if (trimmedString.StartsWith(EspKnownValues.EspJobResponse.EndedAt))
                                {
                                    //ENDED AT 17.02 ON WEDNESDAY APRIL 20TH, 2016
                                    trimmedString = trimmedString.Replace(EspKnownValues.EspJobResponse.EndedAt, string.Empty);
                                    //17.02 ON WEDNESDAY APRIL 20TH, 2016
                                    trimmedString = FormatEspDateTime(trimmedString);
                                    //17.02 WEDNESDAY APRIL 20, 2016
                                    DateTime endDate = ParseEspDateTime(trimmedString);
                                    //TODO: Validate
                                    espMessageExtract.EndedOn = endDate;
                                }
                            }

                            //Continue to parse to see if there is an anticipated end time
                        }
                        else if (trimmedString.StartsWith(EspKnownValues.EspJobResponse.AnticipatedEndTime))
                        {
                            espMessageExtract.HasAnticipatedEndOn = true;
                            if(trimmedString.Contains(EspKnownValues.EspJobResponse.AnticipatedEndTimeNotAvailable) == false)
                            {
                                //ANTICIPATED END TIME: 13.01 ON SATURDAY APRIL 30TH, 2016
                                trimmedString = trimmedString.Replace(EspKnownValues.EspJobResponse.AnticipatedEndTime, string.Empty);
                                //13.01 ON SATURDAY APRIL 30TH, 2016
                                trimmedString = FormatEspDateTime(trimmedString);
                                //13.01 SATURDAY APRIL 30, 2016
                                DateTime anticipatedEndDate = ParseEspDateTime(trimmedString);
                                //TODO: Validate
                                espMessageExtract.AnticipatedEndOn = anticipatedEndDate;
                            }
                            //stop parsing
                            break;
                            
                        }
                        
                        
                    }
                }
            }
            return espMessageExtract;
        }

        /// <summary>
        /// Generates EspJobStatus from Message Extract
        /// </summary>
        /// <param name="messageExtract"></param>
        /// <returns></returns>
        private static EspJobStatus GetJobStatusFromExtract(EspMessageExtract messageExtract)
        {
            EspJobStatus espJobStatus = new EspJobStatus();
            //App Not Defined
            if (messageExtract.IsAppNotDefined == true)
            {
                espJobStatus.Status = EspJobStatusState.AppNotDefined;
                espJobStatus.StartedOn = null;
                espJobStatus.EndedOn = null;
                espJobStatus.AnticipatedEndOn = null;
                espJobStatus.Generation = null;
            }
            //NoMatchingAppOrUnAuthorized
            else if (messageExtract.IsNoMatchingAppOrUnAuthorized == true)
            {
                espJobStatus.Status = EspJobStatusState.NoMatchingAppOrUnAuthorized;
                espJobStatus.StartedOn = null;
                espJobStatus.EndedOn = null;
                espJobStatus.AnticipatedEndOn = null;
                espJobStatus.Generation = null;
            }
            else if (messageExtract.IsInvalidAppSpec == true)
            {
                espJobStatus.Status = EspJobStatusState.IsInvalidAppSpec;
                espJobStatus.StartedOn = null;
                espJobStatus.EndedOn = null;
                espJobStatus.AnticipatedEndOn = null;
                espJobStatus.Generation = null;
            }
            //Completed Successfully or with failure
            else if (messageExtract.IsComplete == true && messageExtract.HasAnticipatedEndOn == false)
            {
                espJobStatus.Status = EspJobStatusState.Completed;
                espJobStatus.StartedOn = messageExtract.StartedOn;
                espJobStatus.EndedOn = messageExtract.EndedOn;
                espJobStatus.AnticipatedEndOn = null;
                espJobStatus.Generation = espJobStatus.Generation;
            }
            //Dependent jobs still running
            else if (messageExtract.IsComplete == false && messageExtract.HasAnticipatedEndOn == true)
            {
                espJobStatus.Status = EspJobStatusState.InCompleteDependentJobs;
                espJobStatus.StartedOn = messageExtract.StartedOn;
                espJobStatus.EndedOn = messageExtract.EndedOn;
                espJobStatus.AnticipatedEndOn = null;
                espJobStatus.Generation = espJobStatus.Generation;
                espJobStatus.AnticipatedEndOn = messageExtract.AnticipatedEndOn;
            }
            //Job is complete; Consider the job completed because there is no anticipated
            else if (messageExtract.IsComplete == false && messageExtract.HasAnticipatedEndOn == false)
            {
                espJobStatus.Status = EspJobStatusState.Completed;
                espJobStatus.StartedOn = messageExtract.StartedOn;
                espJobStatus.EndedOn = messageExtract.EndedOn;
                espJobStatus.AnticipatedEndOn = null;
                espJobStatus.Generation = espJobStatus.Generation;
                espJobStatus.AnticipatedEndOn = null;
            }
            
            //Ready - Not possible as per ESP team
            return espJobStatus;
        }

        /// <summary>
        /// Logs error
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="jobName"></param>
        /// <param name="message"></param>
        private static void LogError(string userId, string jobName, EspMessage message)
        {
            string logMessage = string.Empty;
            if (message.Data != null && message.Data.list != null)
            {
                foreach (string s in message.Data.list)
                {
                    logMessage = logMessage + " " + s;
                }
            }
            GeneralDatabaseAccess.LogEvent(userId, "EspManager.cs", jobName,
                    string.Format("Info.Status:{0}; List: {1}", message.Info.Status, logMessage), UserToolLogLevel.Error);
            throw new ApplicationException("Response from TriggerJob() did not contain success.");
        }

        /// <summary>
        /// Get Completed and InComplete Job Names
        /// </summary>
        /// <param name="response"></param>
        /// <returns></returns>
        private static EspMessageExtract ExtractCompletedJobs(EspMessage response)
        {
            EspMessageExtract espMessageExtract = new EspMessageExtract();
            if (response.Info != null && response.Info.Status != null)
            {
                if (response.Data != null && response.Data.list != null && response.Data.list.Length > 0)
                {
                    foreach (string listItem in response.Data.list)
                    {
                        string trimmedString = listItem.Trim();
                        trimmedString = trimmedString.ToUpper();

                        if (trimmedString.StartsWith(EspKnownValues.EspJobResponse.CompletedJobs))
                        {
                            if (trimmedString.Contains(EspKnownValues.EspJobResponse.CompletedJobsNone) == false)
                            {
                                //"COMPLETED JOBS: TEST1, TEST2"
                                espMessageExtract.CompletedJobs = trimmedString.Replace(EspKnownValues.EspJobResponse.CompletedJobs, string.Empty).Trim(); ;
                            }
                        }
                        else if (trimmedString.StartsWith(EspKnownValues.EspJobResponse.InCompleteJobs))
                        {
                            if (trimmedString.Contains(EspKnownValues.EspJobResponse.CompletedJobsNone) == false)
                            {
                                //"INCOMPLETE JOBS: TEST1, TEST2"
                                espMessageExtract.InCompleteJobs = trimmedString.Replace(EspKnownValues.EspJobResponse.InCompleteJobs, string.Empty).Trim();
                            }
                            //Stop parsing since COMPLETED JOBS must have been parsed already before coming to INCOMPLETE JOBS
                            break;
                        }
                    }
                }
            }
            return espMessageExtract;
        }

        /// <summary>
        /// Class to hold Message Extract
        /// </summary>
        private class EspMessageExtract
        {
            public long? Generation { get; set; }
            public bool IsComplete { get; set; }
            public bool IsAnyDependentProcessRunning { get; set; }
            //public bool IsFailure { get; set; }
            //public bool IsHold { get; set; }
            public bool IsAppNotDefined { get; set; }
            public bool IsNoMatchingAppOrUnAuthorized { get; set; }
            //public bool IsRunning { get; set; }
            //public bool IsWaiting { get; set; }
            public DateTime? StartedOn { get; set; }
            public DateTime? EndedOn { get; set; }
            public bool HasAnticipatedEndOn { get; set; }
            public DateTime? AnticipatedEndOn { get; set; }
            public bool IsInvalidAppSpec { get; set; }
            public string CompletedJobs { get; set; }
            public string InCompleteJobs { get; set; }

        }
        #endregion 
    }
}
