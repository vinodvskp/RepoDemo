using System;
//using System.Web.UI.WebControls.WebParts;
//using System.Web.UI.HtmlControls;
using System.Collections;
//using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using MDUA.DataAccess;
using MDUA.DTO;
namespace MDUA.BusinessLogic
{
    /// <summary>
    /// Summary description for WPUtil
    /// </summary>
    public class WPUtil
    {
        public WPUtil()
        {
            //
            //  Add constructor logic here
            //
        }

        public static Table BuildProgressBar(string ProcessCode, string AsRelatesTo, int ProcessId, string ImagesDir, string Requestor)
        {

            WPProcessInfo pi = GetProcessInfo(ProcessCode, AsRelatesTo, ProcessId, true, Requestor);
            Table myTbl = new Table();
            TableRow tr = new TableRow();
            myTbl.Rows.Add(tr);
            myTbl.CellPadding = 0;
            myTbl.CellSpacing = 0;
            myTbl.BorderWidth = 0;

            //  If the ProcessId = 0, then it means there are no status for this process.
            if (pi.ProcessId == 0)
            {
                TableCell errTc = new TableCell();
                tr.Cells.Add(errTc);
                errTc.Text = DbAccess.GetProcessDescription(AsRelatesTo, ProcessCode);
                return myTbl;
            }

            //  Retrieve all the data for this process id so that we can build a Progress Bar.
            if (pi.arrSteps == null || pi.arrSteps.Count == 0)
                return null;

            TableRow trDesc = new TableRow();
            myTbl.Rows.Add(trDesc);

            TableCell tcLastLine = null;
            foreach (WPProcessStep ps in pi.arrSteps)
            {
                //  Create a Hint String.  The format is:
                //  Start Time: time
                //  End Time: time
                //  Elapsed: Elapsed
                //  Status: status
                string Hint = "";

                Hint += "Start Time: ";
                if (ps.StartTime > DateTime.MinValue)
                    Hint += ps.StartTime.ToString("MM/dd/yyyy  HH:mm:ss");
                else
                    Hint += "Not started";

                Hint += "\r\nEnd Time: ";
                if (ps.EndTime > DateTime.MinValue && ps.EndTime != null)
                     Hint += ps.EndTime.ToString("MM/dd/yyyy  HH:mm:ss");
                else
                    Hint += "Not complete";

                Hint += "\r\nElapsed Time: ";
                if (ps.EndTime > DateTime.MinValue)
                {
                    TimeSpan tsElapsed = ps.EndTime.Subtract(ps.StartTime);
                    Hint += string.Format("{0}h {1}m {2}s", tsElapsed.Hours, tsElapsed.Minutes, tsElapsed.Seconds);
                }
                else
                    Hint += "Not complete";

                Hint += "\r\nStatus: " + ps.StatusDesc;


                //  Build the Bar first.  It is made up of 3 bits, a line on the left (or spaces for first item),
                //  a colored dot based on the status, and another line (or spaces for the last item).
                TableCell tcLeftLine = new TableCell();
                TableCell tcDot = new TableCell();
                TableCell tcRgtLine = new TableCell();
                tr.Cells.Add(tcLeftLine);
                tr.Cells.Add(tcDot);
                tr.Cells.Add(tcRgtLine);

                tcLeftLine.Width = new Unit(67); //42);
                tcDot.Width = new Unit(15);
                tcRgtLine.Width = new Unit(68); //43);

                if (tcLastLine != null)
                {
                    tcLeftLine.Style.Add(HtmlTextWriterStyle.BackgroundImage, "url(" + ImagesDir + "/pb-line.jpg)");
                    tcLastLine.Style.Add(HtmlTextWriterStyle.BackgroundImage, "url(" + ImagesDir + "/pb-line.jpg)");
                }
                tcLastLine = tcRgtLine;

                Image imgDot = new Image();
                switch (ps.Status)
                {
                    case "S":
                        imgDot.ImageUrl = ImagesDir + "/pb-green.jpg";
                        break;
                    case "P":
                        imgDot.ImageUrl = ImagesDir + "/pb-yellow.jpg";
                        break;
                    case "R":
                        imgDot.ImageUrl = ImagesDir + "/pb-blue.jpg";
                        break;
                    case "E":
                        imgDot.ImageUrl = ImagesDir + "/pb-red.jpg";
                        break;
                    case "C":
                        imgDot.ImageUrl = ImagesDir + "/pb-red.jpg";
                        break;
                    default:
                        imgDot.ImageUrl = ImagesDir + "/pb-white.jpg";
                        break;
                }
                imgDot.ToolTip = Hint;
                tcDot.Controls.Add(imgDot);

                TableCell tcDesc = new TableCell();
                tcDesc.ColumnSpan = 3;
                tcDesc.HorizontalAlign = HorizontalAlign.Center;
                tcDesc.Wrap = true;
                trDesc.Cells.Add(tcDesc);
                Label lblDesc = new Label();
                lblDesc.Text = ps.StepDescription;
                lblDesc.ToolTip = Hint;
                lblDesc.SkinID = "ProgBarLbl";
                tcDesc.CssClass = "CPGAStep";
                tcDesc.Controls.Add(lblDesc);
            }

            //  Create a summary line
            if (pi.arrSteps != null && pi.arrSteps.Count > 0)
            {
                TableRow trSum = new TableRow();
                myTbl.Rows.Add(trSum);
                TableCell tcSum = new TableCell();
                trSum.Cells.Add(tcSum);
                tcSum.ColumnSpan = myTbl.Rows[0].Cells.Count;

                Label lblSum = new Label();
                lblSum.SkinID = "ProgBarLbl";
                tcSum.Controls.Add(lblSum);

                if (((WPProcessStep)pi.arrSteps[pi.arrSteps.Count - 1]).EndTime == DateTime.MinValue)
                {
                    //bool ErrFound = false;
                    foreach (WPProcessStep ps in pi.arrSteps)
                    {
                        if (ps.Status.Equals("E") || ps.Status.Equals("C"))
                        {
                            lblSum.Text = string.Format("The {0} process terminated with an error.", pi.ProcessCode );
                            break;
                        }
                        if (ps.StartTime != DateTime.MinValue && ps.EndTime == DateTime.MinValue)
                        {
                            lblSum.Text = string.Format("The {0} process is still running.", pi.ProcessCode);
                            break;
                        }
                    }
                }
                else
                {
                    TimeSpan tsSum = ((WPProcessStep)pi.arrSteps[pi.arrSteps.Count - 1]).EndTime.Subtract(
                        ((WPProcessStep)pi.arrSteps[0]).StartTime);
                    lblSum.Text = string.Format("The {0} process ran for {1}h {2}m {3}s and had a final status of {4}",
                       pi.ProcessCode, tsSum.Hours, tsSum.Minutes, tsSum.Seconds,
                        ((WPProcessStep)pi.arrSteps[pi.arrSteps.Count - 1]).StatusDesc);
                }
            }

            return myTbl;
        }

        public static WPProcessInfo GetProcessInfo(string ProcessCode, string AsRelatesTo, int ProcessId, bool GetLatest, string Requestor)
        {
            WPProcessInfo pi = new WPProcessInfo();

            //  If the ProcessId = 0 and they want to get the latest, find the latest
            if (ProcessId == 0 && GetLatest == true)
            {
                //  If there is no process for this item, return a Progress Bar that says so.
                // jevans 1/15/2011 - process id is moved to pi object later 
                ProcessId = DbAccess.GetProcessID(AsRelatesTo, ProcessCode);
            }

            //  If they supplied a ProcessID, but not the ProcessCode, lookup the process code
            else
                if (ProcessId > 0 && (ProcessCode == null || ProcessCode.Length == 0))
                {

                    if (DbAccess.GetProcessCode(ProcessId, out AsRelatesTo, out ProcessCode) == false)
                        return null;
                }

            pi.ProcessCode = ProcessCode;
            pi.AsRelatesTo = AsRelatesTo;
            pi.ProcessId = ProcessId;

            //  Retrieve the description
            pi.Description = DbAccess.GetProcessDescription(ProcessCode, AsRelatesTo);

            //  If we don't have a process id at this point, they just want the defined information without
            //  status information.
            if (ProcessId == 0)
            {
                pi.arrSteps = DbAccess.GetProcessSteps(ProcessCode, AsRelatesTo);
                return pi;
            }

            //  Retrieve all the data for this process id so that we can build a Progress Bar.
            pi.arrSteps = DbAccess.GetProcessSteps(ProcessId, ProcessCode, AsRelatesTo);
            return pi;
        }

    } // end of class 
} // end of namespace 