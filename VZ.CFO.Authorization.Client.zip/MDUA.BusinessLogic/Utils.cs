using System;
using System.Collections;
using System.Configuration;
using System.IO;
using System.Threading;
using System.Web;
using MDUA.DataAccess;
using MDUA.DTO;
using System.Collections.Generic;

namespace MDUA.BusinessLogic {
    /// <summary>
    /// Summary description for Utils
    /// </summary>
    public class Utils {
        #region local vars
        // this is used in system settings but never set!
        public static int numActiveSessions = 0;

        /* jevans 8/8/2011 - max lines is now a local to reduce round trips to AppSettings */
        private static int _maxLinesDisplayed = 0;
        
        private static int MaxLinesDisplayed {
            get {
                if (_maxLinesDisplayed == 0 && !int.TryParse(ConfigurationManager.AppSettings["UploadMaxLinesDisplayed"], out _maxLinesDisplayed))
                    _maxLinesDisplayed = 1000;
                return _maxLinesDisplayed;
            }
        }

        #endregion

        public Utils() {}
        
        #region User Routines

        public static WebSettings LoadWebSetting(string Requestor) {
            return DbAccess.LoadWebSetting(Requestor);
        }

        public static UserInfo GetCurUser(System.Web.SessionState.HttpSessionState Session, HttpRequest Request) {
            //  If there isn't a test user to sign in with, check the Request Headers.
            string EmpNbr = Request.ServerVariables[ConfigurationManager.AppSettings["EmployeeIdSessionVariable"]];

            //foreach (string key in Request.ServerVariables.AllKeys) {
            //    GeneralDatabaseAccess.LogEvent("unknown", "Utils.GetCurUser", string.Format("{1} is {0}", Request.ServerVariables[key], key), "Success", LogLevel.Audit);
            //}
            //GeneralDatabaseAccess.LogEvent("unknown", "Utils.GetCurUser", string.Format("HTTP_VZID is {0}", Request.ServerVariables["HTTP_VZID"]), "Success", LogLevel.Audit);
            //GeneralDatabaseAccess.LogEvent("unknown", "Utils.GetCurUser", string.Format("HTTP_EID is {0}", Request.ServerVariables["HTTP_EID"]), "Success", LogLevel.Audit);

            if (EmpNbr == null) {
                EmpNbr = ConfigurationManager.AppSettings["TestEmplId"];
                if (EmpNbr == null) {
                    GeneralDatabaseAccess.LogEvent("", "Utils.GetCurUser", "Getting Employee ID from Header", "employeeID=null", UserToolLogLevel.Audit);
                }
            }

            UserInfo tmpUser = GeneralDatabaseAccess.GetUserData(EmpNbr);
            if (tmpUser == null)
            {
                string DispName = Request.Headers["displayName"];
                //  If this is an anonymous user, fill out a user record and return it, 
                //  but don't store it or anything.
                tmpUser = new UserInfo();
                tmpUser.Role = UserRole.AnonymousUser;
                tmpUser.FirstName = "(Unknown)";
                tmpUser.EmployeeID = EmpNbr;
                if (DispName != null && DispName.Trim().Length > 0) {
                    string[] Nmes = DispName.Split(',');
                    if (Nmes.Length > 1) {
                        tmpUser.FirstName = Nmes[1].Trim();
                        tmpUser.LastName = Nmes[0].Trim();
                    } else {
                        tmpUser.FirstName = "(Unknown)";
                        tmpUser.LastName = DispName;
                    }
                }
                GeneralDatabaseAccess.LogEvent("", "Utils.GetCurUser", "Setting Employee ID to anonymous user", "employeeID=null", UserToolLogLevel.Message);
                return tmpUser;
            }

            //  Only write out the log the first time the user signs in.
            if (Session["CurUser"] == null) {
                GeneralDatabaseAccess.LogEvent(EmpNbr, "Utils.GetCurUser", string.Format("Login for {0}", EmpNbr), (tmpUser == null) ? "Fail" : "Success", UserToolLogLevel.Audit);
            }

            Session["CurUser"] = tmpUser;
            return tmpUser;
        }

        #endregion
        //======================
        #region file handling

        public static bool DeleteFile(string Filename, string Requestor) {
            int retryCount = 0;
            bool deleteSuccessful = false;
            while (retryCount++ < 5 && !deleteSuccessful) {
                try {
                    File.Delete(Filename);
                    deleteSuccessful = true;
                } catch (Exception) {                   
                    Thread.Sleep(250);
                }
            }

            return deleteSuccessful;
        }

        public static int LockFileType(string FileType, string ClosePeriod, string UserId,
                  string Requestor, out string ErrMsg) {
            return GeneralDatabaseAccess.LockFileType(FileType, ClosePeriod, UserId, Requestor, out  ErrMsg);
        }

        /// <summary>
        /// This base method is called by override or by valid-key loader to bypass Check of Date/Fact
        /// </summary>
        /// <param name="Filename"></param>
        /// <param name="fileType"></param>
        /// <param name="currentDate"></param>
        /// <param name="owner"></param>
        /// <param name="checkFact"></param>
        /// <param name="message"></param>
        /// <param name="scenario"></param>
        /// <returns></returns>
        public static int LoadExcelToStage(string filename, FileType fileType, DateTime currentDate, string owner, bool checkFact, out string message) {
            switch ((FactTable)fileType.FactTableId) {
                case FactTable.EquipmentUser:
                    return DbAccess.LoadEquipmentExcelToStage(filename, fileType, currentDate, owner, checkFact, out message);
                case FactTable.DataWarehouseUser:
                    return DbAccess.LoadDataWarehouseExcelToStage(filename, fileType, currentDate, owner, checkFact, out message);
                case FactTable.LocationUser:
                    return DbAccess.LoadLocationExcelToStage(filename, fileType, currentDate, owner, checkFact, out message);
                default:
                    return DbAccess.LoadReportingExcelToStage(filename, fileType, currentDate, owner, checkFact, out message);
            }
        }

        public static bool DelUserStgData(FileType hft, DateTime dtNow, string Requestor) {
            return DbAccess.DeleteUserStageData(hft, dtNow, Requestor);
        }

        #endregion // file handling
        //======================
        #region dimension handling

        public static Dimension BuildDimTree(string dimensionName, string tableName, string requestor) {
            ArrayList arrParents = new ArrayList();
            ArrayList arrAll = new ArrayList();
            Dimension root = null;

            ArrayList arrDims = DbAccess.GetDimensions(dimensionName, tableName, requestor);
            
            foreach (Dimension ad in arrDims) {
                if (ad.Parent.Trim().Length == 0) {
                    arrParents.Add(ad);
                    root = ad;
                } else {
                    if (ad.Storage.Equals("Shared Member")) { continue; }

                    int i = arrAll.BinarySearch(ad.MemberName);
                    if (i < 0) { i = -i - 1; }
                    arrAll.Insert(i, ad);
                }
            }

            Dimension hd = null;
            Dimension hParent = null;
            while (arrDims.Count > 0) {
                hd = (Dimension)arrDims[0];
                arrDims.RemoveAt(0);

                //  Find the parent item so that we can add the child
                int idx = arrParents.BinarySearch(hd.Parent);
                if (idx < 0) {
                    //  If we didn't find the Parent in the list, find the parent now in the
                    //  full list and add it to the parent list.
                    int pIdx = arrAll.BinarySearch(hd.Parent);
                    if (pIdx >= 0) {
                        Dimension pd = (Dimension)arrAll[pIdx];
                        idx = arrParents.BinarySearch(pd.MemberName);
                        if (idx < 0)
                            idx = -idx - 1;
                        arrParents.Insert(idx, pd);
                        hParent = pd;
                        arrAll.RemoveAt(pIdx);
                    } else {
                        hParent = null;
                    }
                } else {
                    hParent = (Dimension)arrParents[idx];
                }

                if (hParent != null) {
                    if (hParent.arrChildren == null) {
                        hParent.arrChildren = new ArrayList();
                    }

                    //  Check to see if we should just add it to the end or insert it somewhere
                    // jevans 8/17/2011 loc-sibling is always null and was removed from object
                    hParent.arrChildren.Add(hd);
                }
            }

            return root;
        }

        /// <summary>
        /// Call one of the get-audit methods to return fact joined with audit table
        /// </summary>
        public static ArrayList GetAuditTable(bool GetAll, FactDTO f, string Day, string Month, string Year, out int SkippedRows) {
            int maxRows = GetAll ? 0 : MaxLinesDisplayed;
            //GetEqpAuditTable
            switch (f.TableName) {
                case "Location":
                    return DbAccess.GetLocationAuditTable(f, Month, Year, MaxLinesDisplayed, out  SkippedRows);
                case "Equipment":
                    return DbAccess.GetEquipmentAuditTable(f, Day, Month, Year, MaxLinesDisplayed, out SkippedRows);
                case "Data Warehouse":
                    return DbAccess.GetDataWarehouseAuditTable(f, Month, Year, MaxLinesDisplayed, out SkippedRows);
                default:
                    return DbAccess.GetReportingAuditTable(f, Month, Year, MaxLinesDisplayed, out  SkippedRows);
            }
        }

        public static List<MasterDimension> GetFactDimensions(FactTable factTable, bool is13Month, bool includePeriodAndFacts, bool onlyIncludeUserFeedFields) {
            return GeneralDatabaseAccess.GetFactDimensions(factTable, is13Month, includePeriodAndFacts, onlyIncludeUserFeedFields);
        }

        public static MasterFactTable GetFactTable(string FactTableId, string FactTableName, string Requestor) {
            return GeneralDatabaseAccess.GetFactTable(FactTableId, FactTableName, Requestor);
        }

        public static List<FactTableDTO> GetFactTableNames() {
            return GeneralDatabaseAccess.GetFactTableNames();
        }

        public static ArrayList GetDimYears() {
            return DbAccess.GetDimYears();
        }

        public static ArrayList GetDimensions(string DimType, string TableName, string Requestor) {
            return DbAccess.GetDimensions(DimType, TableName, Requestor);
        }

        #endregion // dimensions
        //======================
        #region Staging Table Routines

        public static int UnpivotFrom13Month(FileType fileType, out string message) {
            switch ((FactTable)fileType.FactTableId) {
                case FactTable.LocationUser:
                   return DbAccess.UnpivotLocationFrom13Month(fileType, out message);
                case FactTable.DataWarehouseUser:
                   return DbAccess.UnpivotDataWarehouseFrom13Month(fileType, out message);
                default:
                    return DbAccess.UnpivotReportingFrom13Month(fileType, out message);
            }
        }

        public static int UnpivotOneMonthFrom13Month(FileType fileType, int fiscalYear, int fiscalMonth, out string message) {
            switch ((FactTable)fileType.FactTableId) {
                case FactTable.LocationUser:
                    return DbAccess.UnpivotLocationOneMonthFrom13Month(fileType, fiscalYear, fiscalMonth, out message);
                case FactTable.DataWarehouseUser:
                    return DbAccess.UnpivotDataWarehouseOneMonthFrom13Month(fileType, fiscalYear, fiscalMonth, out message);
                default:
                    return DbAccess.UnpivotReportingOneMonthFrom13Month(fileType, fiscalYear, fiscalMonth, out message);
            }
        }

        public static string ProcessForcedValues(FileType hft) {
            return DbAccess.ProcessForcedValues(hft);
        }

        public static ArrayList ProcessAutomappedData(FileType fileType, int runStatusId, string fiscalPeriod, out string message, out int rowsSkipped) {
            switch ((FactTable)fileType.FactTableId) {
                case FactTable.LocationUser:
                    return DbAccess.ProcessLocationAutomappedData(fileType, runStatusId, MaxLinesDisplayed, out  message, out rowsSkipped);
                case FactTable.EquipmentUser:
                    return DbAccess.ProcessEquipmentAutomappedData(fileType, runStatusId, MaxLinesDisplayed, out  message, out rowsSkipped);
                case FactTable.DataWarehouseUser:
                    return DbAccess.ProcessDataWarehouseAutomappedData(fileType, runStatusId, MaxLinesDisplayed, fiscalPeriod, out  message, out rowsSkipped);
                default:
                    return DbAccess.ProcessReportingAutomappedData(fileType, runStatusId, MaxLinesDisplayed, fiscalPeriod, out  message, out rowsSkipped);
            }
        }

        public static int CallCompanyLookup(FileType fileType, string requestor) {
            if (fileType.FactTableId == (int)FactTable.LocationUser
                || fileType.FactTableId == (int)FactTable.EquipmentUser
                || fileType.FactTableId == (int)FactTable.DataWarehouseUser)
                return 0;
            else
                return DbAccess.CallCompanyLookup(fileType, requestor);
        }

        public static ArrayList ValidatePeriod(FileType hft, bool CheckPeriod, int month, string Years, int RunStatusId, out int SkippedRows) {
            switch ((FactTable)hft.FactTableId) {
                case FactTable.LocationUser:
                    return DbAccess.ValidateLocationPeriod(hft, CheckPeriod, month, Years, RunStatusId, MaxLinesDisplayed, out SkippedRows);
                case FactTable.EquipmentUser:
                    return DbAccess.ValidateEquipmentPeriod(hft, CheckPeriod, month, Years, RunStatusId, MaxLinesDisplayed, out SkippedRows);
                case FactTable.DataWarehouseUser:
                    return DbAccess.ValidateDataWarehousePeriod(hft, CheckPeriod, month, Years, RunStatusId, MaxLinesDisplayed, out SkippedRows);
                default:
                    return DbAccess.ValidateReportingPeriod(hft, CheckPeriod, month, Years, RunStatusId, MaxLinesDisplayed, out SkippedRows);
            }
        }

        public static bool IsYearValid(FileType fileType, int year, int runStatusId) {
            return DbAccess.IsYearValid(fileType, year, runStatusId);
        }

        public static ArrayList ValidateDuplicateRows(FileType hft, int RunStatusId, out int SkippedRows) {
            return ValidateDuplicateRows(hft, RunStatusId, true, out SkippedRows);
        }

        /// <summary>
        /// This override provides a checkdate flag to indicate the validation is for facts or for valid keys 
        /// </summary>
        /// <param name="hft"></param>
        /// <param name="RunStatusId"></param>
        /// <param name="checkdate">Include fact-date in dup-check SQL </param>
        /// <param name="SkippedRows"></param>
        /// <returns></returns>
        public static ArrayList ValidateDuplicateRows(FileType hft, int RunStatusId, bool checkdate, out int SkippedRows) {
            // jevans 3/12/2012  - 24735 - new device method
            switch ((FactTable)hft.FactTableId) {
                case FactTable.LocationUser:
                    return DbAccess.ValidateLocationDuplicateRows(hft, RunStatusId, MaxLinesDisplayed, out SkippedRows);
                case FactTable.EquipmentUser:
                    return DbAccess.ValidateEquipmentDuplicateRows(hft, RunStatusId, MaxLinesDisplayed, checkdate, out SkippedRows);
                case FactTable.DataWarehouseUser:
                    return DbAccess.ValidateDataWarehouseDuplicateRows(hft, RunStatusId, MaxLinesDisplayed, out SkippedRows);
                default:
                    return DbAccess.ValidateReportingDuplicateRows(hft, RunStatusId, MaxLinesDisplayed, out SkippedRows);
            }
        }

        /// <summary>
        /// called by user input upload to confirm for OUTLOOK uploads that there is only one scenario 
        /// </summary>
        public static bool ValidateSingleScenario(FileType hft, int RunStatusID) {
            return DbAccess.ValidateSingleScenario(hft, RunStatusID);
        }

        public static ArrayList ValidateAdjustmentScenarios(FileType hft, int RunStatusId, out int SkippedRows) {
            string ValidAdjScenarios = ConfigurationManager.AppSettings["ValidAdjScenarios"];
            // jevans 5/10/2011 - restrict size of returned array
            switch ((FactTable)hft.FactTableId) {
                case FactTable.LocationUser:
                    return DbAccess.ValidateLocationAdjustmentScenario(hft, ValidAdjScenarios, RunStatusId, MaxLinesDisplayed, out SkippedRows);
                case FactTable.EquipmentUser:
                    return DbAccess.ValidateEquipmentAdjustmentScenario(hft, ValidAdjScenarios, RunStatusId, MaxLinesDisplayed, out SkippedRows);
                case FactTable.DataWarehouseUser:
                    return DbAccess.ValidateDataWarehouseAdjustmentScenario(hft, ValidAdjScenarios, RunStatusId, MaxLinesDisplayed, out SkippedRows);
                default:
                    return DbAccess.ValidateReportingAdjustmentScenario(hft, ValidAdjScenarios, RunStatusId, MaxLinesDisplayed, out SkippedRows);
            }
        }

        public static ArrayList ValidateDimensionSource(FileType fileType, int runStatusId, out int rowsSkipped) {
            // jevans 5/10/2011 - restrict size of returned array
            // jevans 3/12/2012  - 24735 - new device method
            switch ((FactTable)fileType.FactTableId) {
                case FactTable.LocationUser:
                    return DbAccess.ValidateLocationDimensionSource(fileType, runStatusId, MaxLinesDisplayed, out rowsSkipped);
                case FactTable.EquipmentUser:
                    return DbAccess.ValidateEquipmentDimensionSource(fileType, runStatusId, MaxLinesDisplayed, out rowsSkipped);
                case FactTable.DataWarehouseUser:
                    return DbAccess.ValidateDataWarehouseDimensionSource(fileType, runStatusId, MaxLinesDisplayed, out rowsSkipped);
                default:
                    return DbAccess.ValidateReportingDimensionSource(fileType, runStatusId, MaxLinesDisplayed, out rowsSkipped);
            }
        }

        /// <summary>
        /// check for coa/cor reporting lines
        /// </summary>
        /// <param name="TableName"></param>
        /// <param name="hft"></param>
        /// <param name="RunStatusId"></param>
        /// <param name="SkippedRows"></param>
        /// <returns>arraylist</returns>
        public static ArrayList ValidateCoaCor(FileType hft, int RunStatusId, out int SkippedRows) {
            // jevans 8/8/2011 - max lines is now a local to reduce round trips to AppSettings
            // jevans 5/10/2011 - restrict size of returned array
            switch ((FactTable)hft.FactTableId) {
                // jevans 7/20/2012 - RPTG/Proforma are the only cubes that require COA/COR (CPGA) validation
                case FactTable.Reporting:
                case FactTable.ReportingAdjustment:
                case FactTable.Proforma:
                case FactTable.ProformaAdjustment:
                    return DbAccess.ValidateReportingCoaCor(hft, RunStatusId, MaxLinesDisplayed, out SkippedRows);
                default:
                    SkippedRows = 0;
                    return new ArrayList();
            }
        }

        /// <summary>
        /// call database validation of dimensions
        /// </summary>
        /// <param name="hft"></param>
        /// <param name="RunStatusId"></param>
        /// <param name="Msg"></param>
        /// <param name="SkippedRows"></param>
        /// <returns></returns>
        public static ArrayList ValidateDimensionFields(FileType hft, int RunStatusId, out string Msg, out int SkippedRows) {
            // jevans 8/8/2011 - max lines is now a local to reduce round trips to AppSettings
            // jevans 5/10/2011 - restrict size of returned array
            // jevans 3/12/2012  - 24735 - new device method
            switch ((FactTable)hft.FactTableId) {
                case FactTable.LocationUser:
                    return DbAccess.ValidateLocationDimensionFields(hft, RunStatusId, MaxLinesDisplayed, out  Msg, out  SkippedRows);
                case FactTable.EquipmentUser:
                    return DbAccess.ValidateEquipmentDimensionFields(hft, RunStatusId, MaxLinesDisplayed, out  Msg, out  SkippedRows);
                case FactTable.DataWarehouseUser:
                    return DbAccess.ValidateDataWarehouseDimensionFields(hft, RunStatusId, MaxLinesDisplayed, out  Msg, out  SkippedRows);
                default:
                    return DbAccess.ValidateReportingDimensionFields(hft, RunStatusId, MaxLinesDisplayed, out  Msg, out  SkippedRows);
            }
        }

        /// <summary>
        /// execute stored procedure to move data from stage to fact
        /// </summary>
        /// <param name="Month"></param>
        /// <param name="Year"></param>
        /// <param name="FileType"></param>
        /// <param name="IsAdjustment"></param>
        /// <param name="TargetTable"></param>
        /// <param name="Requestor"></param>
        /// <returns></returns>
        public static int CallProcessDelta(int Month, string Year, FileType hFileType, string Requestor) {
            // jevans 3/12/2012  - 24735 - new device method
            switch ((FactTable)hFileType.FactTableId) {
                case FactTable.LocationUser:
                    return DbAccess.CallLocationProcessDelta(Month, Year, hFileType, Requestor);
                case FactTable.EquipmentUser:
                    return DbAccess.CallEquipmentProcessDelta(Month, Year, hFileType, Requestor);
                case FactTable.DataWarehouseUser:
                    return DbAccess.CallDataWarehouseProcessDelta(Month, Year, hFileType, Requestor);
                default:
                    // jevans 8/20/2011 - this is the only table name left in app settings - stage and destination are 
                    // determined in the master-fact-table 
                    string stgTblTmp = ConfigurationManager.AppSettings["UserInputFinalTbl"];
                    return DbAccess.CallReportingProcessDelta(Month, Year, hFileType, stgTblTmp, Requestor);
            }
        }
        

        // called by opsuploadinput
        public static int CopyInputFileStageToTrans(Int32 RunId, string FileType, string IsAdjustment) {
            return DbAccess.CopyInputFileStageToTrans(RunId, FileType, IsAdjustment);
        }

        public static bool CheckUserDefinedFlds(FileType hft, string LineNbrs, out string Msg) {
            Msg = string.Empty;
            // jevans 8/1/2011 - 24524 - location has new automapping
            // jevans 3/12/2012  - 24735 - new device method
            return DbAccess.CheckUserDefinedFields(hft, LineNbrs, out Msg);
        }

        public static ArrayList GetLoadedRecords(FileType fileType, int fiscalMonth, string fiscalYear, int numberUpdated, out int rowsSkipped) {
            switch ((FactTable)fileType.FactTableId) {
                case FactTable.LocationUser:
                    return DbAccess.GetLocationLoadedRecords(fileType, fiscalMonth, fiscalYear, MaxLinesDisplayed, numberUpdated, out rowsSkipped);
                case FactTable.EquipmentUser:
                    return DbAccess.GetEquipmentLoadedRecords(fileType, fiscalMonth, fiscalYear, MaxLinesDisplayed, numberUpdated, out rowsSkipped);
                case FactTable.DataWarehouseUser:
                    return DbAccess.GetDataWarehouseLoadedRecords(fileType, fiscalMonth, fiscalYear, MaxLinesDisplayed, numberUpdated, out rowsSkipped);
                default:
                    return DbAccess.GetReportingLoadedRecords(fileType, fiscalMonth, fiscalYear, MaxLinesDisplayed, numberUpdated, out rowsSkipped);
            }
        }

        public static int AddToValidation(string lineNumbers, FileType fileType, string requestor, int runStatusId, string month, string years, bool canPostAdjustmentsToAnyPeriod, out string message) {
            switch ((FactTable)fileType.FactTableId) {
                case FactTable.LocationUser:
                    return DbAccess.AddToLocationValidation(lineNumbers, fileType, requestor, month, years, canPostAdjustmentsToAnyPeriod, out message);
                case FactTable.EquipmentUser:
                    return DbAccess.AddToEquipmentValidation(lineNumbers, fileType, requestor, month, years, canPostAdjustmentsToAnyPeriod, out message);
                case FactTable.DataWarehouseUser:
                    return DbAccess.AddToDataWarehouseValidation(lineNumbers, fileType, requestor, month, years, canPostAdjustmentsToAnyPeriod, out message);
                default:
                    return DbAccess.AddToReportingValidation(lineNumbers, fileType.FileTypeCode, requestor, runStatusId, month, years, canPostAdjustmentsToAnyPeriod, fileType.ValidationKeyTable, fileType.Is13Month || fileType.IsOutlook ? fileType.StageYearTable : fileType.StageMonthTable, out message);
            }
        }

        /// <summary>
        /// called by valid key combos 
        /// </summary>
        /// <param name="hft"></param>
        /// <param name="Scenario"></param>
        /// <param name="dtNow"></param>
        /// <param name="SkippedRows"></param>
        /// <returns></returns>
        public static ArrayList ValidateKeyCombinations(FileType hft, DateTime dtNow, out int SkippedRows) {
            switch ((FactTable)hft.FactTableId) {
                case FactTable.LocationUser:
                    return DbAccess.ValidateLocationKeyCombinations(hft, dtNow, MaxLinesDisplayed, out SkippedRows);
                case FactTable.EquipmentUser:
                    return DbAccess.ValidateEquipmentKeyCombinations(hft, dtNow, MaxLinesDisplayed, out SkippedRows);
                case FactTable.DataWarehouseUser:
                    return DbAccess.ValidateDataWarehouseKeyCombinations(hft, dtNow, MaxLinesDisplayed, out SkippedRows);
                default:
                    return DbAccess.ValidateReportingKeyCombinations(hft, dtNow, MaxLinesDisplayed, out SkippedRows);
            }
        }

        #endregion // Staging Table
        //======================
        #region ops upload functions


        // called by OPS upload input  
        // todo: either remove out string, change to return boolean success
        public static string ProcessInputFileForceValues(FileType hft, string TableName, int RunId, out string msg)
        {
            ReturnCodeDTO rc = DbAccess.ProcessInputFileForceValues(hft, TableName, RunId);
            msg = rc.Message;
            return rc.Message;
        }

        // only called by OPS UPLOAD INPUT FILE
        public static int DeleteInputFileStagingData(string StageTableName, string FileType)
        {
            return DbAccess.DeleteInputFileStagingData(StageTableName, FileType);
        }

        // todo delete this override after replacing OUT method
        // called by opsuploadinputfile
        public static int LoadDataInputFileIntoTable(string filename, string tableName, List<MasterDimension> dimensions, FileType fileType, string owner, int runId, out string message, out string scenario) {
            ReturnCodeDTO rc;
            rc = LoadDataInputFileIntoTable(filename, tableName, dimensions, fileType, owner, runId, out  scenario);
            message = rc.Message;
            return rc.ReturnCode;
        }

        public static ReturnCodeDTO LoadDataInputFileIntoTable(string filename, string tableName, List<MasterDimension> dimensions, FileType fileType, string owner, int runId, out string scenario) {
            return DbAccess.LoadDataInputFileIntoTable(filename, tableName, dimensions, fileType, owner, runId, out  scenario);
        }

        // only called by OPS UPLOAD INPUT FILE
        public static bool UtilTruncateTable(string TableName, bool DisableConstraints) {
            return DbAccess.UtilTruncateTable(TableName, DisableConstraints);
        }
        
        #endregion // ops file page
        //======================
        #region key combos

        public static ArrayList GetKeysToBeAdded(FileType fileType, DateTime now, out int rowsSkipped) {
            switch ((FactTable)fileType.FactTableId) {
                case FactTable.LocationUser:
                    return DbAccess.GetLocationKeysToBeAdded(fileType, now, MaxLinesDisplayed, out rowsSkipped);
                case FactTable.EquipmentUser:
                    return DbAccess.GetEquipmentKeysToBeAdded(fileType, now, MaxLinesDisplayed, out rowsSkipped);
                case FactTable.DataWarehouseUser:
                    return DbAccess.GetDataWarehouseKeysToBeAdded(fileType, now, MaxLinesDisplayed, out rowsSkipped);
                default:
                    return DbAccess.GetReportingKeysToBeAdded(fileType, now, MaxLinesDisplayed, out rowsSkipped);
            }
        }

        public static ArrayList GetCurrentKeys(FileType fileType, out int rowsSkipped) {
            switch ((FactTable)fileType.FactTableId) {
                case FactTable.LocationUser:
                    return DbAccess.GetCurrentLocationKeys(fileType, MaxLinesDisplayed, out rowsSkipped);
                case FactTable.EquipmentUser:
                    return EquipmentDatabaseAccess.GetCurrentKeys(fileType, MaxLinesDisplayed, out rowsSkipped);
                case FactTable.DataWarehouseUser:
                    return DbAccess.GetCurrentDataWarehouseKeys(fileType, MaxLinesDisplayed, out rowsSkipped);
                case FactTable.ProductOfferUser:
                    return ProductOfferDatabaseAccess.GetCurrentProdOfferKeys(fileType, MaxLinesDisplayed, out rowsSkipped);
                case FactTable.PlanningActuals:
                    return PlanningActualsDatabaseAccess.GetCurrentKeys(fileType, MaxLinesDisplayed, out rowsSkipped);
                case FactTable.DevicePaymentLoan:
                    return DevicePaymentLoanDatabaseAccess.GetCurrentDPLoanKeys(fileType, MaxLinesDisplayed, out rowsSkipped);
                default:
                    return DbAccess.GetCurrentReportingKeys(fileType, MaxLinesDisplayed, out rowsSkipped);
            }
        }

        /// <summary>
        /// Updates Fact and Validation table with new File Type code based on row id
        /// </summary>
        /// <param name="hft"></param>
        /// <param name="RowID"></param>
        /// <param name="Requestor"></param>
        /// <param name="NbrFactsMoved"></param>
        /// <param name="NbrKeysMoved"></param>
        /// <returns>bool success</returns>
        ///  jevans 6/18/2012 refactored to accept a string of rowids instead of an array
        public static bool MoveKeyCombos(FileType hft, string RowIDs, string OrigFileType, string Requestor, out int NbrFactsMoved, out int NbrKeysMoved)
        {
            return DbAccess.MoveKeyCombos(hft, RowIDs, OrigFileType, Requestor, out  NbrFactsMoved, out  NbrKeysMoved);
        }

        // jevans 7/20/2011 override to move all keys from one type to another
        public static bool MoveAllKeyCombos(FileType destHFT, string OrigFileType, string Requestor, out int NbrFactsMoved, out int NbrKeysMoved)
        {
            return DbAccess.MoveAllKeyCombos(destHFT, OrigFileType, Requestor, out  NbrFactsMoved, out  NbrKeysMoved);
        }

        /// <summary>
        /// override for delete-all keys passes null key 
        /// </summary>
        /// <param name="FileTypeCode"></param>
        /// <param name="Requestor"></param>
        /// <param name="Cnt"></param>
        /// <returns></returns>
        public static bool DelUserInputKey(string FileTypeCode, string Requestor, out int Cnt)
        {
            FileType hft = GetFileType(FileTypeCode, Requestor);
            return DbAccess.DelUserInputKey(hft, hft.ValidationKeyTable, null, Requestor, out Cnt);
        }

        /// <summary>
        /// delete a single key using rowid as index
        /// </summary>
        /// <param name="FileTypeCode"></param>
        /// <param name="KeyValue"></param>
        /// <param name="Requestor"></param>
        /// <param name="Cnt"></param>
        /// <returns></returns>
        public static bool DelUserInputKey(string FileTypeCode, ArrayList KeyValues, string Requestor, out int Cnt)
        {
            FileType hft = GetFileType(FileTypeCode, Requestor);
            return DbAccess.DelUserInputKey(hft, hft.ValidationKeyTable, KeyValues, Requestor, out Cnt);
        }

        /// <summary>
        /// Add keys from user-input page CONTINUE button
        /// </summary>
        /// <param name="hft"></param>
        /// <param name="Owner"></param>
        /// <param name="dAdded"></param>
        /// <param name="Requestor"></param>
        /// <param name="AddCnt"></param>
        /// <returns></returns>
        public static bool AddUserInputKeys(FileType hft, string Owner, string dAdded, string Requestor, out int AddCnt)
        {
            switch ((FactTable)hft.FactTableId)
            {
                case FactTable.LocationUser:
                    return DbAccess.AddLocUserInputKeys(hft, Owner, dAdded, Requestor, out AddCnt);
                case FactTable.EquipmentUser:
                case FactTable.DataWarehouseUser:
                    return DbAccess.AddUserInputKeys(hft, Owner, dAdded, Requestor, out AddCnt);
                default:
                    return DbAccess.AddRptUserInputKeys(hft, Owner, dAdded, Requestor, out AddCnt);
            }
        }

        #endregion // key combos
        //======================
        #region Excel File Routines

        public static int WriteFactDataToCSV(string requestor, FileType fileType, List<MasterDimension> dimensions, MasterFactTable masterFactTable, DateTime reportingPeriod, DateTime startDate, string filename)
        {
            string selectCommand = string.Empty;
            switch (fileType.FactTable) {
                case FactTable.LocationUser:
                    selectCommand = DbAccess.BuildLocationFactDownloadSql(requestor, fileType, dimensions, masterFactTable, reportingPeriod, startDate, filename);
                    return (selectCommand.Length > 0) ? DbAccess.WriteDataToCsv(requestor, filename, fileType.FileTypeCode, selectCommand) : -1;
                case FactTable.EquipmentUser:
                    selectCommand = EquipmentDatabaseAccess.BuildFactDownloadSql(fileType, reportingPeriod, startDate);
                    return (selectCommand.Length > 0) ? DbAccess.WriteDataToCsv(requestor, filename, fileType.FileTypeCode, selectCommand) : -1;
                case FactTable.DataWarehouseUser:
                    selectCommand = DbAccess.BuildDataWarehouseFactDownloadSql(requestor, fileType, dimensions, masterFactTable, reportingPeriod, startDate, filename);
                    return (selectCommand.Length > 0) ? DbAccess.WriteDataToCsv(requestor, filename, fileType.FileTypeCode, selectCommand) : -1;
                case FactTable.ProductOfferUser:
                    selectCommand = ProductOfferDatabaseAccess.BuildProdOfferFactDownloadSql(fileType, reportingPeriod, startDate);
                    return (selectCommand.Length > 0) ? DbAccess.WriteDataToCsv(requestor, filename, fileType.FileTypeCode, selectCommand) : -1;
                case FactTable.PlanningActuals:
                    selectCommand = PlanningActualsDatabaseAccess.BuildFactDownloadSql(fileType, reportingPeriod, startDate);
                    return (selectCommand.Length > 0) ? PlanningActualsDatabaseAccess.WriteDataToCsv(requestor, filename, fileType.FileTypeCode, selectCommand) : -1;
                case FactTable.DevicePaymentLoan:
                    selectCommand = DevicePaymentLoanDatabaseAccess.BuildDPLoanFactDownloadSql(fileType, reportingPeriod, startDate);
                    return (selectCommand.Length > 0) ? DbAccess.WriteDataToCsv(requestor, filename, fileType.FileTypeCode, selectCommand) : -1;
                default:
                    selectCommand = DbAccess.BuildReportingFactDownloadSql(requestor, fileType, dimensions, masterFactTable, reportingPeriod, startDate, filename);
                    return (selectCommand.Length > 0) ? DbAccess.WriteDataToCsv(requestor, filename, fileType.FileTypeCode, selectCommand) : -1;
            }            
        }

        /// <summary>
        /// this new override supports location or proforma fact downloads
        /// </summary>
        /// <param name="fileType"></param>
        /// <param name="requestor"></param>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public static int WriteDataToCSV(FileType fileType, string requestor, string fileName) {
            string sqlText = string.Format("select * from {0} where {1}='{2}'", fileType.DestinationTable, fileType.SourceColumnName, fileType.FileTypeCode);
            switch (fileType.FactTable) {
                case FactTable.PlanningActuals: return PlanningActualsDatabaseAccess.WriteDataToCsv(requestor, fileName, fileType.FileTypeCode, sqlText);
                default: return DbAccess.WriteDataToCsv(requestor, fileName, fileType.FileTypeCode, sqlText);
            }            
        }

        /// <summary>
        /// This version writes validation table data downloads
        /// </summary>
        /// <param name="fileType"></param>
        /// <param name="requestor"></param>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public static int WriteValidationDataToCSV(FileType fileType, string requestor, string fileName) {
            string sqlText = string.Format("select * from {0} where {1}='{2}'", fileType.ValidationKeyTable, fileType.SourceColumnName, fileType.FileTypeCode);
            switch (fileType.FactTable) {
                case FactTable.PlanningActuals: return PlanningActualsDatabaseAccess.WriteDataToCsv(requestor, fileName, fileType.FileTypeCode, sqlText);
                default: return DbAccess.WriteDataToCsv(requestor, fileName, fileType.FileTypeCode, sqlText);
            }         
        }

        public static int WriteDataToCSV(string Requestor, string FileName, string FileCode, string SelCmd) {
            return DbAccess.WriteDataToCsv(Requestor, FileName, FileCode, SelCmd);
        }

        public static bool WriteAuditDataToCSV(string Filename, string SheetName, ArrayList arrData, string Requestor)
        {
            FactDTO testFact = (FactDTO)arrData[0];
            if (testFact.TableName.ToLower() == "fact_location_user")
                return DbAccess.WriteLocationAuditDataToCsv(Filename, SheetName, arrData, Requestor);
            else if (testFact.TableName.ToLower() == "fact_equipment_user")
                return DbAccess.WriteEquipmentAuditDataToCsv(Filename, SheetName, arrData, Requestor);
            else if (testFact.TableName.ToLower() == "fact_dw_user")
                return DbAccess.WriteDataWarehouseAuditDataToCsv(Filename, SheetName, arrData, Requestor);
            else
                return DbAccess.WriteReportingAuditDataToCsv(Filename, SheetName, arrData, Requestor);
        }

        // used by CPGA INFO page
        public static int CopyExcelToTable(string Filename, string SheetName, string TableName, bool bTruncTable, ArrayList arrColInfo,
               out string Msg, string Requestor)
        {
            return DbAccess.CopyExcelToTable(Filename, SheetName, TableName, bTruncTable, arrColInfo,
            out  Msg, Requestor);
        }

        /* used by CPGA info page to create excel download */
        public static int CopyTableToExcel(string Filename, string SheetName, string TableName, bool CreateSheet, ArrayList arrColInfo,
            string Where, out string Msg, string Requestor)
        {
            return DbAccess.CopyTableToExcel(Filename, SheetName, TableName, CreateSheet, arrColInfo, Where, out  Msg, Requestor);
        }
        #endregion
        //======================
        #region File Type Routines

        // called by opsfiletypes
        public static ReturnCodeDTO ValidDimension(string DimName, string ValidationField, string ValTableName, string AliasName, string Value, string ExtraValidationClause)
        {
            return DbAccess.ValidDimension(DimName, ValidationField, ValTableName, AliasName, Value, ExtraValidationClause);
        }

        /// <summary>
        ///  this override returns all types for the provided fact table
        /// </summary>
        /// <param name="factTableId"></param>
        /// <param name="requestor"></param>
        /// <returns></returns>
        public static List<FileType> GetFileTypes(int factTableId, string requestor) {
            return GeneralDatabaseAccess.GetFileTypes(factTableId, string.Empty, requestor);
        }

        /// <summary>
        /// this override returns all types the current user can upload/edit
        /// </summary>
        /// <param name="requestor"></param>
        /// <returns></returns>
        public static List<FileType> GetFileTypes(string requestor) {
            return GeneralDatabaseAccess.GetFileTypes(0, string.Empty, requestor);
        }

        /// <summary>
        /// this override returns a single file type based on code
        /// </summary>
        /// <param name="fileTypeCode"></param>
        /// <param name="requestor"></param>
        /// <returns></returns>
        public static FileType GetFileType(string fileTypeCode, string requestor) {
            List<FileType> fileTypes = GeneralDatabaseAccess.GetFileTypes(0, fileTypeCode, requestor);
            return (fileTypes.Count == 1) ? fileTypes[0] : null;
        }

        public static bool AddUpdateInputFile(FileType fileType, string requestor) {
            return GeneralDatabaseAccess.AddUpdateFileType(fileType, requestor);
        }

        public static bool DeleteInputFileType(string inputFileCode, string requestor) {
            return GeneralDatabaseAccess.DeleteInputFileType(inputFileCode, requestor);
        }

        #endregion
        //======================
        #region PROCESS routines

        // used by BOTH OpsUploadInputFile and UserInputUpload
        public static bool RunStatusComplete(Int32 RunStatusId, string Status, string Message, Int32 RecordsProcessed, string FileName)
        {
            return DbAccess.RunStatusComplete(RunStatusId, Status, Message, RecordsProcessed, FileName);
        }

        public static bool LogMessage(string Message, string SqlCmd, string Trace, int RunStatusId)
        {
            return DbAccess.LogMessage(Message, SqlCmd, Trace, RunStatusId);
        }

        public static List<JobStatusDTO> RetrieveJobStatus(string period) {
            List<JobStatusDTO> list = new List<JobStatusDTO>();
            list.AddRange(PlanningActualsDatabaseAccess.RetrieveJobStatus(period));
            list.AddRange(DbAccess.RetrieveJobStatus(period));
            if (list.Count == 0) list = null;
            return list;
        }

        public static void LogEvent(string Who, string FromLoc, string Action, string Message, UserToolLogLevel lvl)
        {
            GeneralDatabaseAccess.LogEvent(Who, FromLoc, Action, Message, lvl);
        }

        public static void LogEvent(string Who, string FromLoc, string Action, Exception Exception, UserToolLogLevel Level)
        {
            GeneralDatabaseAccess.LogEvent(Who, FromLoc, Action, Exception, Level);
        }

        #endregion
        //======================
        #region autosys handling

        /// <summary>
        ///this function executes an autosys job and returns a status object
        // future use: autosys command line not implemented in UAT/PRD
        /// </summary>
        /// <param name="commandPath"></param>
        /// <param name="jobName"></param>
        /// <returns></returns>
        public static ReturnCodeDTO runSyncAndGetResults(string user, string commandPath, string jobName)
        {
            ReturnCodeDTO rdto = new ReturnCodeDTO();

            rdto.Message = "no results?";
            try
            {
                System.Diagnostics.ProcessStartInfo psi = new System.Diagnostics.ProcessStartInfo(commandPath, jobName);
                psi.RedirectStandardOutput = true;
                psi.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
                psi.UseShellExecute = false;

                System.Diagnostics.Process startJob;
                startJob = System.Diagnostics.Process.Start(psi);
                System.IO.StreamReader strmReader = startJob.StandardOutput;
                startJob.WaitForExit(2000);
                if (startJob.HasExited)
                {
                    rdto.Message = strmReader.ReadToEnd(); //this.processResults.Text = output; 
                    rdto.Success = true;
                }
            }
            catch (Exception ex)
            {
                GeneralDatabaseAccess.LogEvent("", "Utils.cs", "runSyncAndGetResults", ex, UserToolLogLevel.Error);
                rdto.Message = string.Format("An error occurred executing job: {0} <br>{1}<br>", jobName, ex.Message);
                rdto.Success = false;
            }
            return rdto;
        }

        #endregion

    } // end of class 

} // end of namespace