﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace VZ.CFO.MDMFramework.Server.Util
{
    public class ValidationUtil
    {
        public static bool IsEmployeeValidate(string employeeId)
        {
            return  Regex.IsMatch(employeeId, "^[A-Za-z0-9_-]+$");
        }
    }
}
