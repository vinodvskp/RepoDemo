﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Oracle.ManagedDataAccess.Client;
namespace VZ.CFO.MDMFramework.Server.Util
{
    public class DBUtil
    {
        public static int GetTotalRowsFromTable(string tableName, string whereClause, string connectString)
        {
            string queryTotalRecords = string.Format("SELECT COUNT(1) as totalRecords FROM {0} where {1}", tableName, whereClause);

            int returnValue = 0;
            using (OracleConnection conn = new OracleConnection(connectString))
            using (OracleCommand cmd = new OracleCommand(queryTotalRecords, conn))
            {
                conn.Open();
                try
                {
                    using (OracleDataReader dataReader = cmd.ExecuteReader())
                    {
                        int totalRecordsCol = dataReader.GetOrdinal("totalRecords");
                        if (dataReader.Read())
                        {
                            returnValue = dataReader.GetInt32(totalRecordsCol);
                        }

                        dataReader.Close();
                    }
                }
                catch (Exception e)
                {
                    throw;
                }
                finally
                {
                    conn.Close();
                }
            }
            return returnValue;
        }

    }
}
