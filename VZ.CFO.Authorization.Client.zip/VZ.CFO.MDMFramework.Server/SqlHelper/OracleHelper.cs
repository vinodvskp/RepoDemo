﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Server.SqlHelper
{
    public sealed class OracleHelper : IOracleHelper, IDisposable
    {
        /// <summary>
        /// Flag to keep track the object is dispose or not
        /// </summary>
        private bool disposed;

        public OracleHelper()
        { }

        /// <summary>
        /// This method assigns dataRow column values to an array of SqlParameters
        /// </summary>
        /// <param name="commandParameters">Array of SqlParameters to be assigned values</param>
        /// <param name="dataRow">The dataRow used to hold the stored procedure's parameter values</param>
        private void AssignParameterValues(OracleParameter[] commandParameters, DataRow dataRow)
        {
            if ((commandParameters == null) || (dataRow == null))
            {
                // Do nothing if we get no data
                return;
            }

            int i = 0;
            // Set the parameters values
            foreach (OracleParameter commandParameter in commandParameters)
            {
                // Check the parameter name
                if (commandParameter.ParameterName == null ||
                    commandParameter.ParameterName.Length <= 1)
                {
                    throw new Exception(
                    string.Format(
                        "Please provide a valid parameter name on the parameter #{0}, the ParameterName property has the following value: '{1}'.",
                        i, commandParameter.ParameterName));
                }
                if (dataRow.Table.Columns.IndexOf(commandParameter.ParameterName.Substring(1)) != -1)
                {
                    commandParameter.Value = dataRow[commandParameter.ParameterName.Substring(1)];
                }
                i++;
            }
        }

        /// <summary>
        /// This method assigns an array of values to an array of SqlParameters
        /// </summary>
        /// <param name="commandParameters">Array of SqlParameters to be assigned values</param>
        /// <param name="parameterValues">Array of objects holding the values to be assigned</param>
        private void AssignParameterValues(OracleParameter[] commandParameters, object[] parameterValues)
        {
            if ((commandParameters == null) || (parameterValues == null))
            {
                // Do nothing if we get no data
                return;
            }

            // We must have the same number of values as we pave parameters to put them in
            if (commandParameters.Length != parameterValues.Length)
            {
                throw new ArgumentException("Parameter count does not match Parameter Value count.");
            }

            // Iterate through the SqlParameters, assigning the values from the corresponding position in the
            // value array
            for (int i = 0, j = commandParameters.Length; i < j; i++)
            {
                // If the current array value derives from IDbDataParameter, then assign its Value property
                if (parameterValues[i] is IDbDataParameter)
                {
                    IDbDataParameter paramInstance = (IDbDataParameter)parameterValues[i];
                    if (paramInstance.Value == null)
                    {
                        commandParameters[i].Value = DBNull.Value;
                    }
                    else
                    {
                        commandParameters[i].Value = paramInstance.Value;
                    }
                }
                else if (parameterValues[i] == null)
                {
                    commandParameters[i].Value = DBNull.Value;
                }
                else
                {
                    commandParameters[i].Value = parameterValues[i];
                }
            }
        }

        /// <summary>
        /// This method assigns an array of values to an array of SqlParameters
        /// </summary>
        /// <param name="commandParameters">Array of SqlParameters to be assigned values</param>
        /// <param name="parameterValues">Array of objects holding the values to be assigned</param>
        private void UpdateParameterValues(OracleParameter[] commandParameters, object[] parameterValues)
        {
            if ((commandParameters == null) || (parameterValues == null))
            {
                // Do nothing if we get no data
                return;
            }

            // We must have the same number of values as we pave parameters to put them in
            if (commandParameters.Length != parameterValues.Length)
            {
                throw new ArgumentException("Parameter count does not match Parameter Value count.");
            }

            // Iterate through the SqlParameters, assigning the values from the corresponding position in the
            // value array
            for (int i = 0, j = commandParameters.Length; i < j; i++)
            {
                //Update the Return Value
                if (commandParameters[i].Direction == ParameterDirection.ReturnValue)
                {
                    parameterValues[i] = commandParameters[i].Value;
                }

                if (commandParameters[i].Direction == ParameterDirection.InputOutput)
                {
                    parameterValues[i] = commandParameters[i].Value;
                }
            }
        }

        #region CreateCommand
        //public OracleCommand CreateCommand(OracleConnection connection, string spName, params string[] sourceColumns)
        //{
        //    /// If the object is disposed, then throw the ObjectDisposed exception
        //    if (disposed)
        //    {
        //        throw new ObjectDisposedException(GetType().Name);
        //    }
        //    if (connection == null)
        //    {
        //        throw new ArgumentNullException("connection");
        //    }
        //    if (string.IsNullOrEmpty(spName))
        //    {
        //        throw new ArgumentNullException("spName");
        //    }

        //    // Create a SqlCommand
        //    OracleCommand cmd = new OracleCommand(spName, connection);
        //    cmd.CommandType = CommandType.StoredProcedure;

        //    // If we receive parameter values, we need to figure out where they go
        //    if ((sourceColumns != null) && (sourceColumns.Length > 0))
        //    {
        //        // Pull the parameters for this stored procedure from the parameter cache (or discover them & populate the cache)
        //        OracleParameter[] commandParameters = SqlHelperParameterCache.GetSpParameterSet(connection, spName);

        //        // Assign the provided source columns to these parameters based on parameter order
        //        for (int index = 0; index < sourceColumns.Length; index++)
        //        {
        //            commandParameters[index].SourceColumn = sourceColumns[index];
        //        }

        //        // Attach the discovered parameters to the SqlCommand object
        //        AttachParameters(cmd, commandParameters);
        //    }

        //    return cmd;
        //}

        public OracleCommand CreateCommand(OracleConnection connection, string sqlText, params OracleParameter[] cmdParams)
        {
            /// If the object is disposed, then throw the ObjectDisposed exception
            if (disposed)
            {
                throw new ObjectDisposedException(GetType().Name);
            }
            if (connection == null)
            {
                throw new ArgumentNullException("connection");
            }
            if (string.IsNullOrEmpty(sqlText))
            {
                throw new ArgumentNullException("sqlText");
            }

            // Create a SqlCommand
            OracleCommand cmd = new OracleCommand(sqlText, connection);
            cmd.CommandType = CommandType.Text;

            // If we receive parameter values, we need to figure out where they go
            if (cmdParams != null && cmdParams.Length > 0)
            {
                AttachParameters(cmd, cmdParams);
            }
            
            return cmd;
        }
        #endregion

        #region ExecuteReader

        /// <summary>
        /// This method is used to attach array of SqlParameters to a SqlCommand.
        ///
        /// This method will assign a value of DbNull to any parameter with a direction of
        /// InputOutput and a value of null.
        ///
        /// This behavior will prevent default values from being used, but
        /// this will be the less common case than an intended pure output parameter (derived as InputOutput)
        /// where the user provided no input value.
        /// </summary>
        /// <param name="command">The command to which the parameters will be added</param>
        /// <param name="commandParameters">An array of SqlParameters to be added to command</param>
        private void AttachParameters(OracleCommand command, OracleParameter[] commandParameters)
        {
            if (command == null)
            {
                throw new ArgumentNullException("command");
            }
            if (commandParameters != null)
            {
                foreach (OracleParameter p in commandParameters)
                {
                    if (p != null)
                    {
                        // Check for derived output value with no value assigned
                        if ((p.Direction == ParameterDirection.InputOutput ||
                            p.Direction == ParameterDirection.Input) &&
                            (p.Value == null))
                        {
                            p.Value = DBNull.Value;
                        }
                        command.Parameters.Add(p);
                    }
                }
            }
        }

        private void PrepareCommand(OracleCommand command, OracleConnection connection, OracleTransaction transaction, System.Data.CommandType commandType, string commandText, OracleParameter[] commandParameters, out bool mustCloseConnection)
        {
            if (command == null)
            {
                throw new ArgumentNullException("command");
            }
            if (string.IsNullOrEmpty(commandText))
            {
                throw new ArgumentNullException("commandText");
            }

            // If the provided connection is not open, we will open it
            if (connection.State != ConnectionState.Open)
            {
                mustCloseConnection = true;
                connection.Open();
            }
            else
            {
                mustCloseConnection = false;
            }

            // Associate the connection with the command
            command.Connection = connection;

            // Set the command text (stored procedure name or SQL statement)
            command.CommandText = commandText;

            // If we were provided a transaction, assign it
            if (transaction != null)
            {
                if (transaction.Connection == null)
                {
                    throw new ArgumentException("The transaction was rollbacked or commited, please provide an open transaction.", "transaction");
                }
                command.Transaction = transaction;
            }

            // Set the command type
            command.CommandType = commandType;

            // Attach the command parameters if they are provided
            if (commandParameters != null)
            {
                AttachParameters(command, commandParameters);
            }
            return;
        }

        private System.Data.IDataReader ExecuteReaderCommon(OracleConnection connection, OracleTransaction transaction, System.Data.CommandType commandType, string commandText, OracleParameter[] commandParameters)
        {
            if (connection == null)
            {
                throw new ArgumentNullException("connection");
            }

            bool mustCloseConnection = false;
            // Create a command and prepare it for execution
            OracleCommand cmd = new OracleCommand();
            try
            {
                PrepareCommand(cmd, connection, transaction, commandType, commandText, commandParameters, out mustCloseConnection);
                // Create a reader
                OracleDataReader dataReader;
                // Call ExecuteReader assuming connection is owned and managed by caller
                dataReader = cmd.ExecuteReader();

                bool canClear = true;
                foreach (OracleParameter commandParameter in cmd.Parameters)
                {
                    if (commandParameter.Direction != ParameterDirection.Input)
                    {
                        canClear = false;
                    }
                }

                if (canClear)
                {
                    cmd.Parameters.Clear();
                }

                return dataReader;
            }
            catch
            {
                if (mustCloseConnection)
                {
                    connection.Close();
                }
                throw;
            }
        }

        public System.Data.IDataReader ExecuteReader(Oracle.ManagedDataAccess.Client.OracleConnection connection, System.Data.CommandType commandType, string commandText)
        {
            /// If the object is disposed, then throw the ObjectDisposed exception
            if (disposed)
            {
                throw new ObjectDisposedException(GetType().Name);
            }
            // Pass through the call providing null for the set of SqlParameters
            return ExecuteReader(connection, commandType, commandText, (OracleParameter[])null);
        }

        public System.Data.IDataReader ExecuteReader(Oracle.ManagedDataAccess.Client.OracleConnection connection, System.Data.CommandType commandType, string commandText, params OracleParameter[] commandParameters)
        {
            /// If the object is disposed, then throw the ObjectDisposed exception
            if (disposed)
            {
                throw new ObjectDisposedException(GetType().Name);
            }
            // Pass through the call to the private overload using a null transaction value and an externally owned connection
            return ExecuteReaderCommon(connection, (OracleTransaction)null, commandType, commandText, commandParameters);
        }

        public System.Data.IDataReader ExecuteReader(Oracle.ManagedDataAccess.Client.OracleConnection connection, string spName, params object[] parameterValues)
        {
            /// If the object is disposed, then throw the ObjectDisposed exception
            if (disposed)
            {
                throw new ObjectDisposedException(GetType().Name);
            }
            if (connection == null)
            {
                throw new ArgumentNullException("connection");
            }
            if (string.IsNullOrEmpty(spName))
            {
                throw new ArgumentNullException("spName");
            }

            // If we receive parameter values, we need to figure out where they go
            if ((parameterValues != null) && (parameterValues.Length > 0))
            {
                OracleParameter[] commandParameters = SqlHelperParameterCache.GetSpParameterSet(connection, spName);

                AssignParameterValues(commandParameters, parameterValues);

                return ExecuteReader(connection, CommandType.StoredProcedure, spName, commandParameters);
            }
            else
            {
                // Otherwise we can just call the SP without params
                return ExecuteReader(connection, CommandType.StoredProcedure, spName);
            }
        }

        public System.Data.IDataReader ExecuteReader(Oracle.ManagedDataAccess.Client.OracleTransaction transaction, System.Data.CommandType commandType, string commandText)
        {
            /// If the object is disposed, then throw the ObjectDisposed exception
            if (disposed)
            {
                throw new ObjectDisposedException(GetType().Name);
            }
            // Pass through the call providing null for the set of SqlParameters
            return ExecuteReader(transaction, commandType, commandText, (OracleParameter[])null);
        }

        public System.Data.IDataReader ExecuteReader(Oracle.ManagedDataAccess.Client.OracleTransaction transaction, System.Data.CommandType commandType, string commandText, params OracleParameter[] commandParameters)
        {
            /// If the object is disposed, then throw the ObjectDisposed exception
            if (disposed)
            {
                throw new ObjectDisposedException(GetType().Name);
            }
            if (transaction == null)
            {
                throw new ArgumentNullException("transaction");
            }
            if (transaction != null && transaction.Connection == null)
            {
                throw new ArgumentException("The transaction was rollbacked or commited, please provide an open transaction.", "transaction");
            }

            // Pass through to private overload, indicating that the connection is owned by the caller
            return ExecuteReaderCommon(transaction.Connection, transaction, commandType, commandText, commandParameters);
        }

        public System.Data.IDataReader ExecuteReader(Oracle.ManagedDataAccess.Client.OracleTransaction transaction, string spName, params object[] parameterValues)
        {
            /// If the object is disposed, then throw the ObjectDisposed exception
            if (disposed)
            {
                throw new ObjectDisposedException(GetType().Name);
            }
            if (transaction == null)
            {
                throw new ArgumentNullException("transaction");
            }
            if (transaction != null && transaction.Connection == null)
            {
                throw new ArgumentException("The transaction was rollbacked or commited, please provide an open transaction.", "transaction");
            }
            if (string.IsNullOrEmpty(spName))
            {
                throw new ArgumentNullException("spName");
            }

            // If we receive parameter values, we need to figure out where they go
            if ((parameterValues != null) && (parameterValues.Length > 0))
            {
                OracleParameter[] commandParameters = SqlHelperParameterCache.GetSpParameterSet(transaction.Connection, spName);

                AssignParameterValues(commandParameters, parameterValues);

                return ExecuteReader(transaction, CommandType.StoredProcedure, spName, commandParameters);
            }
            else
            {
                // Otherwise we can just call the SP without params
                return ExecuteReader(transaction, CommandType.StoredProcedure, spName);
            }
        }

        public System.Data.IDataReader ExecuteReader(string connectionString, System.Data.CommandType commandType, string commandText)
        {
            /// If the object is disposed, then throw the ObjectDisposed exception
            if (disposed)
            {
                throw new ObjectDisposedException(GetType().Name);
            }
            // Pass through the call providing null for the set of SqlParameters
            return ExecuteReader(connectionString, commandType, commandText, (OracleParameter[])null);
        }

        public System.Data.IDataReader ExecuteReader(string connectionString, System.Data.CommandType commandType, string commandText, params OracleParameter[] commandParameters)
        {
            /// If the object is disposed, then throw the ObjectDisposed exception
            if (disposed)
            {
                throw new ObjectDisposedException(GetType().Name);
            }
            if (string.IsNullOrEmpty(connectionString))
            {
                throw new ArgumentNullException("connectionString");
            }
            OracleConnection connection = null;
            try
            {
                connection = new OracleConnection(connectionString);
                connection.Open();

                // Call the private overload that takes an publicly owned connection in place of the connection string
                return ExecuteReaderCommon(connection, null, commandType, commandText, commandParameters); //change From Internal to External
            }
            catch
            {
                // If we fail to return the SqlDatReader, we need to close the connection ourselves
                if (connection != null)
                {
                    connection.Close();
                }
                throw;
            }
        }


        public System.Data.IDataReader ExecuteReader(string connectionString, string spName, params object[] parameterValues)
        {
            /// If the object is disposed, then throw the ObjectDisposed exception
            if (disposed)
            {
                throw new ObjectDisposedException(GetType().Name);
            }
            IDataReader drReturn;
            if (string.IsNullOrEmpty(connectionString))
            {
                throw new ArgumentNullException("connectionString");
            }
            if (string.IsNullOrEmpty(spName))
            {
                throw new ArgumentNullException("spName");
            }

            // If we receive parameter values, we need to figure out where they go
            if ((parameterValues != null) && (parameterValues.Length > 0))
            {
                OracleParameter[] commandParameters = SqlHelperParameterCache.GetSpParameterSet(connectionString, spName, true);

                AssignParameterValues(commandParameters, parameterValues);

                //return ExecuteReader(connectionString, CommandType.StoredProcedure, spName, commandParameters);
                drReturn = ExecuteReader(connectionString, CommandType.StoredProcedure, spName, commandParameters);

                // if (drReturn.IsClosed == false)
                //     drReturn.Close();

                UpdateParameterValues(commandParameters, parameterValues);
                return drReturn;
            }
            else
            {
                // Otherwise we can just call the SP without params
                //return ExecuteReader(connectionString, CommandType.StoredProcedure, spName);
                drReturn = ExecuteReader(connectionString, CommandType.StoredProcedure, spName);
                return drReturn;
            }
        }
        #endregion
        #region ExecuteReaderTypedParams
        public IDataReader ExecuteReaderTypedParams(OracleConnection connection, string spName, DataRow dataRow)
        {
            /// If the object is disposed, then throw the ObjectDisposed exception
            if (disposed)
            {
                throw new ObjectDisposedException(GetType().Name);
            }
            if (connection == null)
            {
                throw new ArgumentNullException("connection");
            }
            if (string.IsNullOrEmpty(spName))
            {
                throw new ArgumentNullException("spName");
            }

            // If the row has values, the store procedure parameters must be initialized
            if (dataRow != null && dataRow.ItemArray.Length > 0)
            {
                // Pull the parameters for this stored procedure from the parameter cache (or discover them & populate the cache)
                OracleParameter[] commandParameters = SqlHelperParameterCache.GetSpParameterSet(connection, spName);

                // Set the parameters values
                AssignParameterValues(commandParameters, dataRow);

                return this.ExecuteReader(connection, CommandType.StoredProcedure, spName, commandParameters);
            }
            else
            {
                return this.ExecuteReader(connection, CommandType.StoredProcedure, spName);
            }
        }

        public IDataReader ExecuteReaderTypedParams(OracleTransaction transaction, string spName, System.Data.DataRow dataRow)
        {
            /// If the object is disposed, then throw the ObjectDisposed exception
            if (disposed)
            {
                throw new ObjectDisposedException(GetType().Name);
            }
            if (transaction == null)
            {
                throw new ArgumentNullException("transaction");
            }
            if (transaction != null && transaction.Connection == null)
            {
                throw new ArgumentException("The transaction was rollbacked or commited, please provide an open transaction.", "transaction");
            }
            if (string.IsNullOrEmpty(spName))
            {
                throw new ArgumentNullException("spName");
            }

            // If the row has values, the store procedure parameters must be initialized
            if (dataRow != null && dataRow.ItemArray.Length > 0)
            {
                // Pull the parameters for this stored procedure from the parameter cache (or discover them & populate the cache)
                OracleParameter[] commandParameters = SqlHelperParameterCache.GetSpParameterSet(transaction.Connection, spName);

                // Set the parameters values
                AssignParameterValues(commandParameters, dataRow);

                return this.ExecuteReader(transaction, CommandType.StoredProcedure, spName, commandParameters);
            }
            else
            {
                return this.ExecuteReader(transaction, CommandType.StoredProcedure, spName);
            }
        }

        public IDataReader ExecuteReaderTypedParams(string connectionString, string spName, DataRow dataRow)
        {
            /// If the object is disposed, then throw the ObjectDisposed exception
            if (disposed)
            {
                throw new ObjectDisposedException(GetType().Name);
            }
            if (string.IsNullOrEmpty(connectionString))
            {
                throw new ArgumentNullException("connectionString");
            }
            if (string.IsNullOrEmpty(spName))
            {
                throw new ArgumentNullException("spName");
            }

            // If the row has values, the store procedure parameters must be initialized
            if (dataRow != null && dataRow.ItemArray.Length > 0)
            {
                // Pull the parameters for this stored procedure from the parameter cache (or discover them & populate the cache)
                OracleParameter[] commandParameters = SqlHelperParameterCache.GetSpParameterSet(connectionString, spName);

                // Set the parameters values
                AssignParameterValues(commandParameters, dataRow);

                return this.ExecuteReader(connectionString, CommandType.StoredProcedure, spName, commandParameters);
            }
            else
            {
                return this.ExecuteReader(connectionString, CommandType.StoredProcedure, spName);
            }
        }
        #endregion




        /// <summary>
        /// Dispose the object
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Dispose method
        /// </summary>
        /// <param name="disposing"></param>
        private void Dispose(bool disposing)
        {
            if (!disposed && disposing)
            {
                disposed = true;
            }
        }




        
    }
}
