﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Providers.Data;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
using System.Data;
using VZ.CFO.MDMFramework.Contracts.Data.PushNotification;
namespace VZ.CFO.MDMFramework.Server.Providers
{
    public class DbPushNotificationDataProvider : PushNotificationDataProvider
    {
        private System.Timers.Timer mockDBChange = null;
        private int mockCounter = 0;
        private string oracleDependencyId;

        private bool isRunning;

        public DbPushNotificationDataProvider(string connectionString, string encryptionSalt, PushNotificationCallback pushCallback)
            : base(connectionString, encryptionSalt, pushCallback)
        {
            //OnStartService();
        }

        protected override bool OnIsRunning()
        {
            return isRunning;
        }

        public void OnDBNotificationHandler(object src, OracleNotificationEventArgs args)
        {
            List<PushNotification> changedData = new List<PushNotification>();

            //DataRow changedDataRow = args.Details.Rows[0];

            //collect all rowIds that changed
            List<string> rowIdList = new List<string>();
            foreach (DataRow row in args.Details.Rows)
            {
                rowIdList.Add(string.Format("'{0}'", row["Rowid"].ToString()));
            }

            //string rowId = changedDataRow["Rowid"].ToString();
            string query = string.Format("SELECT id, app_name, app_module_name, change_context, last_updated_on, last_updated_by from NOTIFICATION_MASTER WHERE rowid IN ({0})", string.Join(",", rowIdList));
            string id = string.Empty;
            string message = string.Empty;

            //changedData.Add(new PushNotification() { NotificationId = 1, ApplicationName = "VM", ApplicationModuleName = "RL", ChangeContext = "10", LastUpdatedBy = "someone", LastUpdatedOn = DateTime.Now });

            using (OracleConnection connection = new OracleConnection(this.ConnectionString))
            using (OracleCommand command = new OracleCommand(query, connection))
            {
                connection.Open();
                using (OracleDataReader dr = command.ExecuteReader())
                {
                    if (dr.HasRows)
                    {
                        var idCol = dr.GetOrdinal("id");
                        var appNameCol = dr.GetOrdinal("app_name");
                        var appModuleNameCol = dr.GetOrdinal("app_module_name");
                        var changeContextCol = dr.GetOrdinal("change_context");
                        var lastUpdatedOnCol = dr.GetOrdinal("last_updated_on");
                        var lastUpdatedByCol = dr.GetOrdinal("last_updated_by");

                        while (dr.Read())
                        {
                            var pushNotificationData = new PushNotification();
                            pushNotificationData.NotificationId = dr.GetInt64(idCol);
                            pushNotificationData.ApplicationName = dr.GetString(appNameCol);
                            if (dr.IsDBNull(appModuleNameCol) == false)
                            {
                                pushNotificationData.ApplicationModuleName = dr.GetString(appModuleNameCol);
                            }

                            if (dr.IsDBNull(changeContextCol) == false)
                            {
                                pushNotificationData.ChangeContext = dr.GetString(changeContextCol);
                            }

                            if (dr.IsDBNull(lastUpdatedOnCol) == false)
                            {
                                pushNotificationData.LastUpdatedOn = dr.GetDateTime(lastUpdatedOnCol);
                            }

                            if (dr.IsDBNull(lastUpdatedByCol) == false)
                            {
                                pushNotificationData.LastUpdatedBy = dr.GetString(lastUpdatedByCol);
                            }
                            changedData.Add(pushNotificationData);
                        }
                    }
                }
            }
            base.pushCallBack.NotifyItemChanged(changedData.ToArray());
        }

        protected override void OnStartService()
        {

            if (isRunning == false)
            {
                string query = "select ID, APP_NAME, APP_MODULE_NAME, CHANGE_CONTEXT, LAST_UPDATED_ON, LAST_UPDATED_BY from NOTIFICATION_MASTER Where ID > 0";
                using (OracleConnection conn = new OracleConnection(this.ConnectionString))
                using (OracleCommand cmd = new OracleCommand(query, conn))
                {
                    conn.Open();

                    try
                    {
                        cmd.AddRowid = true;
                        OracleDependency oraDep = new OracleDependency(cmd);
                        cmd.Notification.IsNotifiedOnce = false;
                        oraDep.OnChange += new OnChangeEventHandler(OnDBNotificationHandler);

                        oracleDependencyId = oraDep.Id;

                        OracleDataAdapter da = new OracleDataAdapter(cmd);
                        DataSet ds = new DataSet();
                        da.Fill(ds, "NOTIFICATION_MASTER");
                        isRunning = true;

                    }
                    catch
                    {
                        throw;
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
            
            //if(isRunning == false)
            //{
            //    mockDBChange = new System.Timers.Timer(15000);
            //    mockDBChange.Enabled = true;
            //    mockDBChange.Elapsed += mockDBChange_Elapsed;
            //    mockDBChange.Start();
            //    isRunning = true;
            //}
        }

        void mockDBChange_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            List<PushNotification> changedData = new List<PushNotification>();
            changedData.Add(new PushNotification() { NotificationId = 1, ApplicationName = "VM", ApplicationModuleName = "RL", ChangeContext = "10", LastUpdatedBy = "someone", LastUpdatedOn = DateTime.Now });
            changedData.Add(new PushNotification() { NotificationId = 2, ApplicationName = "VM", ApplicationModuleName = "KL", ChangeContext = "100", LastUpdatedBy = "someone", LastUpdatedOn = DateTime.Now });
            base.pushCallBack.NotifyItemChanged(changedData.ToArray());
        }

        protected override void OnStopService()
        {
            if (isRunning)
            {
                OracleDependency oraDep = OracleDependency.GetOracleDependency(oracleDependencyId);
                if (oraDep == null)
                {
                    throw new Exception(string.Format("Unknown Oracle dependency Id - {0}", oracleDependencyId));
                }

                using (OracleConnection conn = new OracleConnection(this.ConnectionString))
                {
                    conn.Open();
                    oraDep.RemoveRegistration(conn);
                    conn.Close();
                }

                //if (mockDBChange != null)
                //{
                //    mockDBChange.Enabled = false;
                //}

                isRunning = false;
            }
        }

        protected override string OnClientSubscription(string clientId, string appName, string appModule)
        {
            throw new NotImplementedException();
        }

        protected override bool OnClientUnSubscribe(string clientId)
        {
            throw new NotImplementedException();
        }

        protected override PushNotificationCallback OnGetPushNotificationCallbackRef()
        {
            return base.pushCallBack;
        }
    }
}
