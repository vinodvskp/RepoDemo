﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA;
using VZ.CFO.MDMFramework.Providers.Data;

namespace VZ.CFO.MDMFramework.Server.Providers
{
    public class DbOpsStatusLogManagerDataProvider : OpsStatusLogManagerDataProvider
    {
        public DbOpsStatusLogManagerDataProvider(string connectionString, string encryptionSalt) : base(connectionString, encryptionSalt) { }


        protected override long OnStartProcess(string module, string comment, string action, bool logStep, string actionType, string source, string target)
        {
            long runStatusId = 0;

            using (OracleConnection oraConn = new OracleConnection(this.ConnectionString))
            using (OracleCommand oraRunStatusCommand = new OracleCommand())
            {
                oraConn.Open();
                try
                {
                    //Get Run Status Id
                    oraRunStatusCommand.Connection = oraConn;
                    oraRunStatusCommand.CommandType = CommandType.StoredProcedure;
                    oraRunStatusCommand.CommandText = "UTILITY.EXTERNAL_PROCESS.start_process";
                    oraRunStatusCommand.BindByName = true;

                    oraRunStatusCommand.Parameters.Add(new OracleParameter("Return_Value", OracleDbType.Int64, ParameterDirection.ReturnValue));
                    oraRunStatusCommand.Parameters.Add(new OracleParameter("module", OracleDbType.Varchar2, module, ParameterDirection.Input));
                    oraRunStatusCommand.Parameters.Add(new OracleParameter("comment", OracleDbType.Varchar2, comment, ParameterDirection.Input));
                    oraRunStatusCommand.Parameters.Add(new OracleParameter("action", OracleDbType.Varchar2, action, ParameterDirection.Input));
                    //oraRunStatusCommand.Parameters.Add(new OracleParameter("log_step", OracleDbType., '1', ParameterDirection.Input));
                    oraRunStatusCommand.Parameters.Add(new OracleParameter("action_type", OracleDbType.Varchar2, actionType, ParameterDirection.Input));
                    oraRunStatusCommand.Parameters.Add(new OracleParameter("source", OracleDbType.Varchar2, source, ParameterDirection.Input));
                    oraRunStatusCommand.Parameters.Add(new OracleParameter("target", OracleDbType.Varchar2, target, ParameterDirection.Input));
                    oraRunStatusCommand.Parameters.Add(new OracleParameter("run_status_id", OracleDbType.Int32, DBNull.Value, ParameterDirection.Input));

                    oraRunStatusCommand.ExecuteNonQuery();
                    runStatusId = long.Parse(oraRunStatusCommand.Parameters["Return_Value"].Value.ToString());
                }
                catch
                {
                    throw;
                }
                finally
                {
                    oraConn.Close();
                }
            }
            return runStatusId;
        }

        protected override void OnStartStep(long runStatusId, string action, string action_type, string source, string target)
        {
            using (OracleConnection oraConn = new OracleConnection(this.ConnectionString))
            using (OracleCommand oraRunStatusCommand = new OracleCommand())
            {
                oraConn.Open();
                try
                {
                    //Get Run Status Id
                    oraRunStatusCommand.Connection = oraConn;
                    oraRunStatusCommand.CommandType = CommandType.StoredProcedure;
                    oraRunStatusCommand.CommandText = "UTILITY.external_process.start_step";

                    oraRunStatusCommand.Parameters.Add(new OracleParameter("@run_status_id", OracleDbType.Int64, runStatusId, ParameterDirection.Input));
                    oraRunStatusCommand.Parameters.Add(new OracleParameter("@action", OracleDbType.Varchar2, action, ParameterDirection.Input));
                    oraRunStatusCommand.Parameters.Add(new OracleParameter("@action_type", OracleDbType.Varchar2, action_type, ParameterDirection.Input));
                    oraRunStatusCommand.Parameters.Add(new OracleParameter("@source", OracleDbType.Varchar2, source, ParameterDirection.Input));
                    oraRunStatusCommand.Parameters.Add(new OracleParameter("@target", OracleDbType.Varchar2, target, ParameterDirection.Input));

                    oraRunStatusCommand.ExecuteNonQuery();

                }
                catch
                {
                    throw;
                }
                finally
                {
                    oraConn.Close();
                }
            }
        }

        protected override void OnEndStep(long runStatusId)
        {
            using (OracleConnection oraConn = new OracleConnection(this.ConnectionString))
            using (OracleCommand oraRunStatusCommand = new OracleCommand())
            {
                oraConn.Open();
                try
                {
                    //Get Run Status Id
                    oraRunStatusCommand.Connection = oraConn;
                    oraRunStatusCommand.CommandType = CommandType.StoredProcedure;
                    oraRunStatusCommand.CommandText = "UTILITY.external_process.end_step";

                    oraRunStatusCommand.Parameters.Add(new OracleParameter("@run_status_id", OracleDbType.Int64, runStatusId, ParameterDirection.Input));

                    oraRunStatusCommand.ExecuteNonQuery();
                }
                catch
                {
                    throw;
                }
                finally
                {
                    oraConn.Close();
                }
            }
        }

        protected override void OnNextStep(long runStatusId, long rows, string comment, string action, string actionType, string source, string target)
        {
            using (OracleConnection oraConn = new OracleConnection(this.ConnectionString))
            using (OracleCommand oraRunStatusCommand = new OracleCommand())
            {
                oraConn.Open();
                try
                {
                    //Get Run Status Id
                    oraRunStatusCommand.Connection = oraConn;
                    oraRunStatusCommand.CommandType = CommandType.StoredProcedure;
                    oraRunStatusCommand.CommandText = "UTILITY.external_process.next_step";

                    oraRunStatusCommand.Parameters.Add(new OracleParameter("@run_status_id", OracleDbType.Int64, runStatusId, ParameterDirection.Input));
                    oraRunStatusCommand.Parameters.Add(new OracleParameter("@rows", OracleDbType.Int64, rows, ParameterDirection.Input));
                    oraRunStatusCommand.Parameters.Add(new OracleParameter("@comment", OracleDbType.Varchar2, comment, ParameterDirection.Input));
                    oraRunStatusCommand.Parameters.Add(new OracleParameter("@action", OracleDbType.Varchar2, action, ParameterDirection.Input));
                    oraRunStatusCommand.Parameters.Add(new OracleParameter("@action_type", OracleDbType.Varchar2, actionType, ParameterDirection.Input));
                    oraRunStatusCommand.Parameters.Add(new OracleParameter("@source", OracleDbType.Varchar2, source, ParameterDirection.Input));
                    oraRunStatusCommand.Parameters.Add(new OracleParameter("@target", OracleDbType.Varchar2, target, ParameterDirection.Input));

                    oraRunStatusCommand.ExecuteNonQuery();
                }
                catch
                {
                    throw;
                }
                finally
                {
                    oraConn.Close();
                }
            }
        }

        protected override void OnEndProcess(long runStatusId, string finalComment)
        {
            using (OracleConnection oraConn = new OracleConnection(this.ConnectionString))
            using (OracleCommand oraRunStatusCommand = new OracleCommand())
            {
                oraConn.Open();
                try
                {
                    //Get Run Status Id
                    oraRunStatusCommand.Connection = oraConn;
                    oraRunStatusCommand.CommandType = CommandType.StoredProcedure;
                    oraRunStatusCommand.CommandText = "UTILITY.external_process.end_process";
                    oraRunStatusCommand.BindByName = true;

                    oraRunStatusCommand.Parameters.Add(new OracleParameter("run_status_id", OracleDbType.Int64, runStatusId, ParameterDirection.Input));
                    /*oraRunStatusCommand.Parameters.Add(new OracleParameter("@status", OracleDbType.Int64, 0, ParameterDirection.Input));
                    oraRunStatusCommand.Parameters.Add(new OracleParameter("@comment", OracleDbType.Varchar2, DBNull.Value, ParameterDirection.Input));
                    oraRunStatusCommand.Parameters.Add(new OracleParameter("@error_message", OracleDbType.Varchar2, DBNull.Value, ParameterDirection.Input));
                    oraRunStatusCommand.Parameters.Add(new OracleParameter("@error_trace", OracleDbType.Varchar2, DBNull.Value, ParameterDirection.Input));
                    oraRunStatusCommand.Parameters.Add(new OracleParameter("@error_sql", OracleDbType.Varchar2, DBNull.Value, ParameterDirection.Input));
                    oraRunStatusCommand.Parameters.Add(new OracleParameter("@final_status", OracleDbType.Varchar2, DBNull.Value, ParameterDirection.Input));*/
                    oraRunStatusCommand.Parameters.Add(new OracleParameter("final_comment", OracleDbType.Varchar2, finalComment, ParameterDirection.Input));

                    oraRunStatusCommand.ExecuteNonQuery();
                }
                catch
                {
                    throw;
                }
                finally
                {
                    oraConn.Close();
                }
            }
        }
        protected override void OnLogEvent(string who, string fromLocation, string action, Exception exception, Contracts.Data.MDUA.UserToolLogLevel logLevel)
        {
            // save to database
            string logMessage = string.Format("Message:{0}<br>Trace: {1}", exception.Message, exception.StackTrace);
            LogEvent(who, fromLocation, action, logMessage, logLevel);

            //StringBuilder message = new StringBuilder();
            //message.AppendFormat("<br>{0}: {1}", "Type", exception.GetType().ToString());
            //message.AppendFormat("<br>{0}: {1}", "From", fromLocation);
            //message.AppendFormat("<br>{0}: {1}", "Method", exception.TargetSite);
            //message.AppendFormat("<br>{0}: {1}", "Action", action);
            //message.AppendFormat("<br>{0}: {1}", "User", who);
            //message.AppendFormat("<br>{0}: {1}", "Message", exception.Message);
            //message.AppendFormat("<br>{0}: {1}", "StackTrace", exception.StackTrace);

            //string subject = string.Format("HypMDUA ({0}): An exception occurred", ConfigurationManager.AppSettings["ServiceName"]);
            //SendEmail(ConfigurationManager.AppSettings["SupportEmail"], subject, message.ToString(), who);
        }

        protected override void OnLogEvent(string who, string fromLocation, string action, string status, Contracts.Data.MDUA.UserToolLogLevel logLevel)
        {
            string sqlText = "web_util.log_event";

            try
            {
                using (OracleConnection connection = new OracleConnection(this.ConnectionString))
                using (OracleCommand command = new OracleCommand(sqlText, connection))
                {
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add(new OracleParameter("@i_logged_by", OracleDbType.Varchar2)).Value = string.IsNullOrEmpty(who) ? " " : who;
                    command.Parameters.Add(new OracleParameter("@i_from_where", OracleDbType.Varchar2)).Value = fromLocation;
                    command.Parameters.Add(new OracleParameter("@i_action", OracleDbType.Varchar2)).Value = (action.Length > 4000) ? action.Substring(0, 3999) : action;
                    command.Parameters.Add(new OracleParameter("@i_status", OracleDbType.Varchar2)).Value = (status.Length > 4000) ? status.Substring(0, 3999) : status;
                    command.Parameters.Add(new OracleParameter("@i_log_level", OracleDbType.Int32)).Value = (short)logLevel;
                    command.ExecuteNonQuery();
                    connection.Close();
                }
            }
            catch { }
        }
    }
}
