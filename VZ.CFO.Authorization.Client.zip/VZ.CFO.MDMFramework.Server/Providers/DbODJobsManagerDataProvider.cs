﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Common;
using VZ.CFO.MDMFramework.Contracts.Data.Config;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA.ODJobs;
using VZ.CFO.MDMFramework.Providers.Data;

namespace VZ.CFO.MDMFramework.Server.Providers
{
    public class DbODJobsManagerDataProvider : ODJobsManagerDataProvider
    {
        #region private variables
        private static readonly string Command = "command";
        private static readonly string PostMethod = "POST";
        private static readonly string Authorization = "Authorization";
        private readonly ESPJobConfig ESPConfig;
        private readonly MDMFramework.Providers.Data.IOpsStatusLogManager opsStatusDbManager;
        #endregion
        public DbODJobsManagerDataProvider(string connectionString, string encryptionSalt, ESPJobConfig espJobConfig, MDMFramework.Providers.Data.IOpsStatusLogManager opsStatusDbManager)
            : base(connectionString, encryptionSalt, espJobConfig, opsStatusDbManager)
        {
            this.ESPConfig = espJobConfig;
            this.opsStatusDbManager = opsStatusDbManager;
        }
        protected override ODJobGroup[] OnGetAllODJobGroups(string userId)
        {
            return GetJobGroups();
        }
        protected override ODJob[] OnGetAllODJobs(string userId, long groupId)
        {
            return GetAllODJobs(userId, groupId);
        }

        protected override ODJob OnGetODJob(string userId, long jobId)
        {
            return GetODJobById(userId, jobId);
        }

        protected override ODJobParamValue[] OnGetODJobParamValues(string userId, long paramId)
        {
            return GetLookUpParamValues(userId, paramId, null);
        }

        protected override ODJobParamValue[] OnGetODJobParamValues(string userId, long paramId, ODJobParamValue[] associatedParamValues)
        {
            return GetLookUpParamValues(userId, paramId, associatedParamValues);
        }

        protected override EspMessage OnTriggerODJob(string userId, ODJobTriggerRequest triggerRequest)
        {
            return TriggerJob(triggerRequest.JobId, userId, triggerRequest.JobParams);
        }

        protected override Task<Contracts.Data.MDUA.ODJobs.EspJobStatus> OnGetODJobStatus(string userId, long jobId)
        {
            return GetJobStatusAsync(userId, jobId);
        }

        protected override EspJobStatus OnGetODJobStatus(string userId, long jobId, long? generation)
        {
            return GetJobStatus(jobId, userId, generation);
        }

        /// <summary>
        /// Calculates Elapsed time from start time
        /// </summary>
        /// <param name="startTime"></param>
        /// <returns></returns>
        private string CalculateElapsedTime(DateTime? startTime)
        {
            string returnValue = string.Empty;
            //if (startTime.HasValue)
            //{
                string destTimezone = TimeZone.CurrentTimeZone.StandardName;
                DateTime convertedTime = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(startTime.Value, ESPConfig.EspTimezone, destTimezone);
                TimeSpan et = DateTime.Now - convertedTime;
                returnValue = et.ToString("c");
            //}

            return returnValue;
        }

        /// <summary>
        /// Retrives All on demand jobs info related to user
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        private ODJobGroup[] GetJobGroups()
        {
            List<ODJobGroup> groupCollection = new List<ODJobGroup>(); 
            string query = "SELECT GROUP_ID, GROUP_NAME FROM OPS_ON_DEMAND_JOB_GROUP";
            using (OracleConnection connection = new OracleConnection(this.ConnectionString))
            {
                try
                {
                    using (OracleCommand command = new OracleCommand(query, connection))
                    {
                        connection.Open();
                        using (OracleDataReader dr = command.ExecuteReader())
                        {
                            if (dr.HasRows)
                            {
                                var idCol = dr.GetOrdinal("GROUP_ID");
                                var groupNameCol = dr.GetOrdinal("GROUP_NAME");
                                while (dr.Read())
                                {
                                    var newJobGroup = new ODJobGroup();
                                    newJobGroup.Id = dr.GetInt64(idCol);
                                    newJobGroup.Name = dr.GetString(groupNameCol);
                                    groupCollection.Add(newJobGroup);
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw;
                }
                finally
                {
                    connection.Close();
                }
            }
            return groupCollection.ToArray();
        }

        /// <summary>
        /// Retrives All on demand jobs info related to user
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        private ODJob[] GetAllODJobs(string userId, long groupId)
        {
            List<ODJob> jobCollection = new List<ODJob>();           
            List<long> userJobIds = new List<long>();
            List<long> jobParamsIds = new List<long>();
            Dictionary<long, List<ODJobParams>> odJobsParamsDic = new Dictionary<long, List<ODJobParams>>();
            Dictionary<long, List<ODJobParams>> odJobsAssociateParamsDic = new Dictionary<long, List<ODJobParams>>();
            string query = "SELECT J.JOB_ID, J.ESP_JOB_ID, J.JOB_NAME, J.JOB_GROUP_ID, J.DESCRIPTION, J.BUTTON_TEXT, J.EVENT, J.SUB_APPL_NAME, J.DATE_CREATED, J.DATE_MODIFIED FROM OPS_ON_DEMAND_JOBS J  INNER JOIN OPS_ON_DEMAND_JOB_ACCESS A ON  J.JOB_ID = A.JOB_ID WHERE A.EMPLOYEE_ID = :userId AND J.JOB_GROUP_ID = :groupId";
            using (OracleConnection connection = new OracleConnection(this.ConnectionString))
            {
                try
                {
                    using (OracleCommand command = new OracleCommand(query, connection))
                    {
                        connection.Open();
                        //command.BindByName = true;
                        command.Parameters.Add(new OracleParameter("userId",OracleDbType.Varchar2));
                        command.Parameters["userId"].Value = userId;
                        command.Parameters.Add(new OracleParameter("groupId", OracleDbType.Decimal));
                        command.Parameters["groupId"].Value = groupId;
                        using (OracleDataReader dr = command.ExecuteReader())
                        {
                            if (dr.HasRows)
                            {
                                var idCol = dr.GetOrdinal("JOB_ID");
                                var groupIdCol = dr.GetOrdinal("JOB_GROUP_ID");
                                var espJobId = dr.GetOrdinal("ESP_JOB_ID");
                                var jobNameCol = dr.GetOrdinal("JOB_NAME");
                                var description = dr.GetOrdinal("DESCRIPTION");
                                var buttonTxt = dr.GetOrdinal("BUTTON_TEXT");
                                var eventCol = dr.GetOrdinal("EVENT");
                                var subAppName = dr.GetOrdinal("SUB_APPL_NAME");
                                var dateCreated = dr.GetOrdinal("DATE_CREATED");
                                var dateModified = dr.GetOrdinal("DATE_MODIFIED");
                                while (dr.Read())
                                {
                                    var newJob = new ODJob();
                                    newJob.Id = dr.GetInt64(idCol);
                                    userJobIds.Add(newJob.Id);
                                    newJob.JobGroupId = dr.GetInt64(groupIdCol);
                                    newJob.Name = dr.IsDBNull(jobNameCol) ? string.Empty : dr.GetString(jobNameCol);
                                    newJob.Description = dr.IsDBNull(description) ? string.Empty : dr.GetString(description);
                                    newJob.UserFriendlyName = dr.IsDBNull(buttonTxt) ? string.Empty : dr.GetString(buttonTxt);
                                    newJob.EspxJobId = dr.GetInt64(espJobId);
                                    newJob.SubApplicationName = dr.IsDBNull(subAppName) ? string.Empty : dr.GetString(subAppName);
                                    if (!dr.IsDBNull(dateCreated))
                                    {
                                        newJob.CreatedOn = dr.GetDateTime(dateCreated);
                                    }
                                    if (!dr.IsDBNull(dateModified))
                                    {
                                        newJob.ModifiedOn = dr.GetDateTime(dateModified);
                                    }
                                    jobCollection.Add(newJob);
                                    odJobsParamsDic.Add(newJob.Id, new List<ODJobParams>());
                                }

                            }
                            else
                            {
                                return jobCollection.ToArray();
                            }
                        }
                    }

                    string paramsQuery = string.Format("SELECT PARAM_ID, JOB_ID, PARAM_NAME,  PARAM_TYPE,  LOOKUP_SQL FROM OPS_ON_DEMAND_JOBS_PARAMS WHERE JOB_id IN ({0}) ORDER BY ORDER_NO ASC", string.Join(",", userJobIds.ToArray()));

                    using (OracleCommand command = new OracleCommand(paramsQuery, connection))
                    {
                        //command.BindByName = true;
                        //command.Parameters.Add(new OracleParameter("userJobIds", OracleDbType.Varchar2));
                        //command.Parameters["userJobIds"].Value = string.Join(",", userJobIds.ToArray());
                        using (OracleDataReader dr = command.ExecuteReader())
                        {
                            if (dr.HasRows)
                            {
                                var paramIdCol = dr.GetOrdinal("PARAM_ID");
                                var jobIdCol = dr.GetOrdinal("JOB_ID");
                                var paramName = dr.GetOrdinal("PARAM_NAME");
                                var paramType = dr.GetOrdinal("PARAM_TYPE");
                                var lookupSql = dr.GetOrdinal("LOOKUP_SQL");

                                while (dr.Read())
                                {
                                    var newJobParam = new ODJobParams();
                                    long jobId = dr.GetInt64(jobIdCol);
                                    newJobParam.Id = dr.GetInt64(paramIdCol);
                                    jobParamsIds.Add(newJobParam.Id);
                                    newJobParam.Name = dr.IsDBNull(paramName) ? string.Empty : dr.GetString(paramName);
                                    if (!dr.IsDBNull(paramType))
                                    {
                                        newJobParam.ParamType = (KnownValues.ODParamType)Enum.Parse(typeof(KnownValues.ODParamType), dr.GetString(paramType));
                                    }
                                    if (!dr.IsDBNull(lookupSql))
                                    {
                                        newJobParam.LookupQuery = dr.GetString(lookupSql);
                                    }


                                    odJobsAssociateParamsDic.Add(newJobParam.Id, new List<ODJobParams>());
                                    if (odJobsParamsDic.ContainsKey(jobId))
                                    {
                                        odJobsParamsDic[jobId].Add(newJobParam);
                                    }
                                }
                            }
                            else
                            {
                                return jobCollection.ToArray(); 
                            }
                        }

                    }

                    string associatedParamsQuery = string.Format("select cp.param_id as cas_param_id, p.param_id , p.job_id, p.param_name, p.param_type, p.lookup_sql, cp.associated_params_id from Ops_On_Demand_Jobs_Params p JOIN Ops_On_Demand_Jobs_Cas_Params cp ON p.param_id = cp.associated_params_id WHERE cp.param_id IN ({0}) order by job_id, cp.order_no", string.Join(",", jobParamsIds.ToArray()));

                    using (OracleCommand associateParamcommand = new OracleCommand(associatedParamsQuery, connection))
                    {

                        using (OracleDataReader dr = associateParamcommand.ExecuteReader())
                        {
                            //associateParamcommand.BindByName = true;
                            ////associateParamcommand.Parameters.Add(new OracleParameter("@jobParamIds", string.Join(",", jobParamsIds.ToArray())));
                            //associateParamcommand.Parameters.Add(new OracleParameter("jobParamIds", OracleDbType.Decimal));
                            //associateParamcommand.Parameters["jobParamIds"].Value = string.Join(",", userJobIds.ToArray());
                            if (dr.HasRows)
                            {
                                var paramIdCol = dr.GetOrdinal("cas_param_id");
                                var assocateparamIdCol = dr.GetOrdinal("param_id");
                                var jobIdCol = dr.GetOrdinal("job_id");
                                var paramName = dr.GetOrdinal("param_name");
                                var paramType = dr.GetOrdinal("param_type");
                                var lookupSql = dr.GetOrdinal("lookup_sql");

                                while (dr.Read())
                                {
                                    var newAssociateParam = new ODJobParams();
                                    long paramId = dr.GetInt64(paramIdCol);
                                    newAssociateParam.Id = dr.GetInt64(assocateparamIdCol);
                                    newAssociateParam.Name = dr.IsDBNull(paramName) ? string.Empty : dr.GetString(paramName);
                                    if (!dr.IsDBNull(paramType))
                                    {
                                        newAssociateParam.ParamType = (KnownValues.ODParamType)Enum.Parse(typeof(KnownValues.ODParamType), dr.GetString(paramType));
                                    }
                                    if (!dr.IsDBNull(lookupSql))
                                    {
                                        newAssociateParam.LookupQuery = dr.GetString(lookupSql);
                                    }                                                                   

                                    if (odJobsAssociateParamsDic.ContainsKey(paramId))
                                    {
                                        odJobsAssociateParamsDic[paramId].Add(newAssociateParam);
                                    }
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw;
                }
                finally
                {
                    connection.Close();
                }
            }
            foreach (var job in jobCollection)
            {
                job.Parameters = odJobsParamsDic[job.Id].ToArray();
                foreach (var param in job.Parameters)
                {
                    param.AssociatedParams = odJobsAssociateParamsDic[param.Id].ToArray();
                }
            }

            return jobCollection.ToArray();
        }
        /// <summary>
        /// Retrieves selected Job info
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="jobId"></param>
        /// <returns></returns>
        private ODJob GetODJobById(string userId, long jobId)
        {
            ODJob selectedJob = new ODJob();

            List<long> jobParamsIds = new List<long>();
            Dictionary<long, List<ODJobParams>> odJobsParamsDic = new Dictionary<long, List<ODJobParams>>();
            Dictionary<long, List<ODJobParams>> odJobsAssociateParamsDic = new Dictionary<long, List<ODJobParams>>();
            string query = "SELECT J.JOB_ID, J.ESP_JOB_ID, J.JOB_NAME,  J.DESCRIPTION, J.BUTTON_TEXT, J.EVENT, J.SUB_APPL_NAME, J.DATE_CREATED, J.DATE_MODIFIED" +
                            " FROM OPS_ON_DEMAND_JOBS J   JOIN OPS_ON_DEMAND_JOB_ACCESS A ON  J.JOB_ID = A.JOB_ID" +
                                                        " JOIN WEB_USERS W ON  W.EMPLOYEE_ID = A.EMPLOYEE_ID" +
                                                        " JOIN WEB_USER_ROLES WR ON  WR.ROLE = W.ROLE" +
                                                        " WHERE A.EMPLOYEE_ID = :userId AND J.JOB_ID = :jobId AND (WR.ROLE = 3 OR WR.ROLE =9)";
            using (OracleConnection connection = new OracleConnection(this.ConnectionString))
            {
                try
                {
                    using (OracleCommand command = new OracleCommand(query, connection))
                    {
                        connection.Open();
                        command.BindByName = true;
                        command.Parameters.Add(new OracleParameter("jobId", OracleDbType.Decimal));
                        command.Parameters["jobId"].Value = jobId;
                        command.Parameters.Add(new OracleParameter("userId", OracleDbType.Varchar2));
                        command.Parameters["userId"].Value = userId;
                        using (OracleDataReader dr = command.ExecuteReader())
                        {
                            if (dr.HasRows)
                            {
                                var idCol = dr.GetOrdinal("JOB_ID");
                                var espJobId = dr.GetOrdinal("ESP_JOB_ID");
                                var jobNameCol = dr.GetOrdinal("JOB_NAME");
                                var description = dr.GetOrdinal("DESCRIPTION");
                                var buttonTxt = dr.GetOrdinal("BUTTON_TEXT");
                                var eventCol = dr.GetOrdinal("EVENT");
                                var subAppName = dr.GetOrdinal("SUB_APPL_NAME");
                                var dateCreated = dr.GetOrdinal("DATE_CREATED");
                                var dateModified = dr.GetOrdinal("DATE_MODIFIED");
                                while (dr.Read())
                                {
                                    selectedJob.Id = dr.GetInt64(idCol);
                                    selectedJob.Name = dr.IsDBNull(jobNameCol) ? string.Empty : dr.GetString(jobNameCol);
                                    selectedJob.Description = dr.IsDBNull(description) ? string.Empty : dr.GetString(description);
                                    selectedJob.UserFriendlyName = dr.IsDBNull(buttonTxt) ? string.Empty : dr.GetString(buttonTxt);
                                    selectedJob.EspxJobId = dr.GetInt64(espJobId);
                                    selectedJob.SubApplicationName = dr.IsDBNull(subAppName) ? string.Empty : dr.GetString(subAppName);
                                    if (!dr.IsDBNull(dateCreated))
                                    {
                                        selectedJob.CreatedOn = dr.GetDateTime(dateCreated);
                                    }
                                    if (!dr.IsDBNull(dateModified))
                                    {
                                        selectedJob.ModifiedOn = dr.GetDateTime(dateModified);
                                    }

                                    odJobsParamsDic.Add(selectedJob.Id, new List<ODJobParams>());
                                }

                            }
                            else 
                            {
                                return selectedJob;
                            }
                        }
                    }

                    string paramsQuery = "SELECT PARAM_ID, JOB_ID, PARAM_NAME,  PARAM_TYPE,  LOOKUP_SQL FROM OPS_ON_DEMAND_JOBS_PARAMS WHERE JOB_ID = :jobId";

                    using (OracleCommand command = new OracleCommand(paramsQuery, connection))
                    {
                        //command.BindByName = true;
                        command.Parameters.Add(new OracleParameter("jobId", OracleDbType.Decimal));
                        command.Parameters["jobId"].Value = jobId;
                        using (OracleDataReader dr = command.ExecuteReader())
                        {
                            if (dr.HasRows)
                            {
                                var paramIdCol = dr.GetOrdinal("PARAM_ID");
                                var jobIdCol = dr.GetOrdinal("JOB_ID");
                                var paramName = dr.GetOrdinal("PARAM_NAME");
                                var paramType = dr.GetOrdinal("PARAM_TYPE");
                                var lookupSql = dr.GetOrdinal("LOOKUP_SQL");

                                while (dr.Read())
                                {
                                    var newJobParam = new ODJobParams();
                                    newJobParam.Id = dr.GetInt64(paramIdCol);
                                    jobParamsIds.Add(newJobParam.Id);
                                    newJobParam.Name = dr.IsDBNull(paramName) ? string.Empty : dr.GetString(paramName);
                                    if (!dr.IsDBNull(paramType))
                                    {
                                        newJobParam.ParamType = (KnownValues.ODParamType)Enum.Parse(typeof(KnownValues.ODParamType), dr.GetString(paramType));
                                    }
                                    if (!dr.IsDBNull(lookupSql))
                                    {
                                        newJobParam.LookupQuery = dr.GetString(lookupSql);
                                    }


                                    odJobsAssociateParamsDic.Add(newJobParam.Id, new List<ODJobParams>());
                                    if (odJobsParamsDic.ContainsKey(jobId))
                                    {
                                        odJobsParamsDic[jobId].Add(newJobParam);
                                    }
                                }
                            }
                            else 
                            {
                                return selectedJob;
                            }
                        }

                    }

                    string associatedParamsQuery = string.Format("select cp.param_id as cas_param_id, p.param_id , p.job_id, p.param_name, p.param_type, p.lookup_sql, cp.associated_params_id from Ops_On_Demand_Jobs_Params p JOIN Ops_On_Demand_Jobs_Cas_Params cp ON p.param_id = cp.associated_params_id WHERE cp.param_id IN ({0}) order by job_id, cp.order_no", string.Join(",", jobParamsIds.ToArray()));

                    using (OracleCommand associateParamcommand = new OracleCommand(associatedParamsQuery, connection))
                    {

                        using (OracleDataReader dr = associateParamcommand.ExecuteReader())
                        {
                            //associateParamcommand.BindByName = true;
                            ////associateParamcommand.Parameters.Add(new OracleParameter("@jobParamIds", string.Join(",", jobParamsIds.ToArray())));
                            //associateParamcommand.Parameters.Add(new OracleParameter("jobParamIds", OracleDbType.Decimal));
                            //associateParamcommand.Parameters["jobParamIds"].Value = string.Join(",", userJobIds.ToArray());
                            if (dr.HasRows)
                            {
                                var paramIdCol = dr.GetOrdinal("cas_param_id");
                                var assocateparamIdCol = dr.GetOrdinal("param_id");
                                var jobIdCol = dr.GetOrdinal("job_id");
                                var paramName = dr.GetOrdinal("param_name");
                                var paramType = dr.GetOrdinal("param_type");
                                var lookupSql = dr.GetOrdinal("lookup_sql");

                                while (dr.Read())
                                {
                                    var newAssociateParam = new ODJobParams();
                                    long paramId = dr.GetInt64(paramIdCol);
                                    newAssociateParam.Id = dr.GetInt64(assocateparamIdCol);
                                    newAssociateParam.Name = dr.IsDBNull(paramName) ? string.Empty : dr.GetString(paramName);
                                    if (!dr.IsDBNull(paramType))
                                    {
                                        newAssociateParam.ParamType = (KnownValues.ODParamType)Enum.Parse(typeof(KnownValues.ODParamType), dr.GetString(paramType));
                                    }
                                    if (!dr.IsDBNull(lookupSql))
                                    {
                                        newAssociateParam.LookupQuery = dr.GetString(lookupSql);
                                    }

                                    if (odJobsAssociateParamsDic.ContainsKey(paramId))
                                    {
                                        odJobsAssociateParamsDic[newAssociateParam.Id].Add(newAssociateParam);
                                    }
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw;
                }
                finally
                {
                    connection.Close();
                }
            }

            selectedJob.Parameters = odJobsParamsDic[selectedJob.Id].ToArray();
            foreach (var param in selectedJob.Parameters)
            {
                param.AssociatedParams = odJobsAssociateParamsDic[param.Id].ToArray();
            }


            return selectedJob;
        }
        /// <summary>
        /// Retrieves selected Job info
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="jobId"></param>
        /// <returns></returns>
        private ODJob GetODJobDetailsById(long jobId, string userId)
        {
            ODJob selectedJob = new ODJob();

            string query = "SELECT J.JOB_ID, J.ESP_JOB_ID, J.JOB_NAME,  J.DESCRIPTION, J.BUTTON_TEXT, J.EVENT, J.SUB_APPL_NAME, J.DATE_CREATED, J.DATE_MODIFIED" +
                            " FROM OPS_ON_DEMAND_JOBS J   JOIN OPS_ON_DEMAND_JOB_ACCESS A ON  J.JOB_ID = A.JOB_ID" +
                                                        " JOIN WEB_USERS W ON  W.EMPLOYEE_ID = A.EMPLOYEE_ID" +
                                                        " JOIN WEB_USER_ROLES WR ON  WR.ROLE = W.ROLE" +
                                                        " WHERE A.EMPLOYEE_ID = :userId AND J.JOB_ID = :jobId AND (WR.ROLE = 3 OR WR.ROLE =9)";
            using (OracleConnection connection = new OracleConnection(this.ConnectionString))
            {
                try
                {
                    using (OracleCommand command = new OracleCommand(query, connection))
                    {
                        connection.Open();
                        command.BindByName = true;
                        command.Parameters.Add(new OracleParameter("jobId", OracleDbType.Decimal));
                        command.Parameters["jobId"].Value = jobId;
                        command.Parameters.Add(new OracleParameter("userId", OracleDbType.Varchar2));
                        command.Parameters["userId"].Value = userId;
                        using (OracleDataReader dr = command.ExecuteReader())
                        {
                            if (dr.HasRows)
                            {
                                var idCol = dr.GetOrdinal("JOB_ID");
                                var espJobId = dr.GetOrdinal("ESP_JOB_ID");
                                var jobNameCol = dr.GetOrdinal("JOB_NAME");
                                var description = dr.GetOrdinal("DESCRIPTION");
                                var buttonTxt = dr.GetOrdinal("BUTTON_TEXT");
                                var eventCol = dr.GetOrdinal("EVENT");
                                var subAppName = dr.GetOrdinal("SUB_APPL_NAME");
                                var dateCreated = dr.GetOrdinal("DATE_CREATED");
                                var dateModified = dr.GetOrdinal("DATE_MODIFIED");
                                while (dr.Read())
                                {
                                    selectedJob.Id = dr.GetInt64(idCol);
                                    selectedJob.Name = dr.IsDBNull(jobNameCol) ? string.Empty : dr.GetString(jobNameCol);
                                    selectedJob.Description = dr.IsDBNull(description) ? string.Empty : dr.GetString(description);
                                    selectedJob.UserFriendlyName = dr.IsDBNull(buttonTxt) ? string.Empty : dr.GetString(buttonTxt);
                                    selectedJob.EspxJobId = dr.GetInt64(espJobId);
                                    selectedJob.SubApplicationName = dr.IsDBNull(subAppName) ? string.Empty : dr.GetString(subAppName);
                                    if (!dr.IsDBNull(dateCreated))
                                    {
                                        selectedJob.CreatedOn = dr.GetDateTime(dateCreated);
                                    }
                                    if (!dr.IsDBNull(dateModified))
                                    {
                                        selectedJob.ModifiedOn = dr.GetDateTime(dateModified);
                                    }                                    
                                }

                            }
                            else
                            {
                                return selectedJob;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw;
                }
                finally
                {
                    connection.Close();
                }
            }
            return selectedJob;
        }        

        /// <summary>
        /// Retrievs look up param values
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="paramId"></param>
        /// <param name="associatedParamValues"></param>
        /// <returns></returns>
        private ODJobParamValue[] GetLookUpParamValues(string userId, long paramId, ODJobParamValue[] associatedParamValues)
        {
            List<ODJobParamValue> paramValues = new List<ODJobParamValue>();
            string lookUpQuery = string.Empty;
            string paramName = string.Empty;
            string paramType = string.Empty;
            /*fortify-issue
            //string paramsQuery = string.Format("SELECT PARAM_NAME, PARAM_TYPE, LOOKUP_SQL FROM OPS_ON_DEMAND_JOBS_PARAMS WHERE PARAM_id = {0}", paramId.ToString());
            */
            string paramsQuery = string.Format("SELECT PARAM_NAME, PARAM_TYPE, LOOKUP_SQL FROM OPS_ON_DEMAND_JOBS_PARAMS WHERE PARAM_id = :paramId");
                using (OracleConnection connection = new OracleConnection(this.ConnectionString))
                {
                    try
                    {
                        using (OracleCommand command = new OracleCommand(paramsQuery, connection))
                        {
                            // Fortify begin
                            command.BindByName = true;
                            OracleParameter p1 = new Oracle.ManagedDataAccess.Client.OracleParameter("paramId", paramId.ToString());
                            command.Parameters.Add(p1);
                            command.CommandText = paramsQuery;
                            // Fortify end
                            connection.Open();
                            using (OracleDataReader dr = command.ExecuteReader())
                            {
                                if (dr.HasRows)
                                {
                                    var param_Name = dr.GetOrdinal("PARAM_NAME");
                                    var lookupSql = dr.GetOrdinal("LOOKUP_SQL");
                                    var par_type = dr.GetOrdinal("PARAM_TYPE");
                                    while (dr.Read())
                                    {
                                        if (!dr.IsDBNull(lookupSql))
                                        {
                                            paramName = dr.GetString(param_Name);
                                            paramType = dr.GetString(par_type);
                                            lookUpQuery = dr.GetString(lookupSql);
                                        }
                                    }
                                }
                            }

                        }
                        if (associatedParamValues != null)
                        {
                            
                            if (associatedParamValues.Count() == 1)
                            {
                                lookUpQuery = string.Format(lookUpQuery, associatedParamValues[0].Value);
                            }
                            else
                            {

                                lookUpQuery = string.Format(lookUpQuery, associatedParamValues.Select(x => x.Value).ToArray());
                                
                            }
                        }
                        else 
                        {
                            lookUpQuery = string.Format(lookUpQuery, paramName);
                        }
                        using (OracleCommand lookUpCommand = new OracleCommand(lookUpQuery, connection))
                        {
                            using (OracleDataReader dr = lookUpCommand.ExecuteReader())
                            {
                                if (dr.HasRows)
                                {
                                    var key = dr.GetOrdinal("Id");
                                    var value = dr.GetOrdinal("Name");
                                    while (dr.Read())
                                    {
                                        ODJobParamValue paramValue = new ODJobParamValue();
                                        paramValue.Key = dr.GetString(key);
                                        if (!dr.IsDBNull(value))
                                        {
                                            paramValue.Value = dr.GetString(value);
                                        }
                                        paramValues.Add(paramValue);
                                    }
                                }
                            }
                        }

                    }
                    catch (Exception ex)
                    {
                        throw;
                    }
                finally
                {
                    connection.Close();
                }
        }
            return paramValues.ToArray();
        }

        private EspMessage TriggerJob(long jobId, string userId, string[] paramValues)
        {
            ODJob selectedJob = GetODJobDetailsById(jobId, userId);
            string jobName = selectedJob.Name;
            string subAppName = selectedJob.SubApplicationName;
            string jobParams = string.Empty;
            //Validate Inputs
            if (string.IsNullOrEmpty(jobName))
            {
                throw new ArgumentException("JobName cannot be null or empty");
            }
            if (string.IsNullOrEmpty(userId))
            {
                throw new ArgumentException("UserId cannot be null or empty");
            }
            int count = 1;
            foreach (string parValue in paramValues)
            {
                if (jobParams != string.Empty)
                {
                    jobParams = jobParams + " " + string.Format(EspKnownValues.EspJobRequest.EspTriggerReqParamFmt, count, parValue);
                }
                else 
                {
                    jobParams = string.Format(EspKnownValues.EspJobRequest.EspTriggerReqParamFmt, count, parValue);
                }

                count++;
            }
            //Prepare Esp Request Message
            EspMessage jobTriggerRequest = new EspMessage();

            if (string.IsNullOrEmpty(selectedJob.SubApplicationName))
            {
                //Trigger ParentJob
                jobTriggerRequest.Info = new EspInfo() { Status = EspKnownValues.EspInfoStatus.Request, Cont = EspKnownValues.EspInfoCont.EOM, Type = EspKnownValues.EspInfoType.Command };
                string espDataRequest = string.Format(EspKnownValues.EspJobRequest.EspTriggerReqtFmtParentApp, EspKnownValues.EspJobRequest.EspTriggerCommand, this.ESPConfig.EspPrefix, jobName, jobParams);
                jobTriggerRequest.Data = new EspData() { Request = espDataRequest };
            }
            else
            {
                //Trigger ChildJob
                jobTriggerRequest.Info = new EspInfo() { Status = EspKnownValues.EspInfoStatus.Request, Cont = EspKnownValues.EspInfoCont.EOM, Type = EspKnownValues.EspInfoType.Command };
                string espDataRequest = string.Format(EspKnownValues.EspJobRequest.EspTriggerReqFmtChildApp, EspKnownValues.EspJobRequest.EspTriggerCommand, this.ESPConfig.EspPrefix, jobName, subAppName, jobParams);
                jobTriggerRequest.Data = new EspData() { Request = espDataRequest };
            }

            //Get Job status
            EspJobStatus espJobStatus = GetJobStatus(userId, jobId);
            EspMessage jobStatusResponse = null;
            if (espJobStatus != null && (espJobStatus.Status == EspJobStatusState.AppNotDefined || espJobStatus.Status == EspJobStatusState.NoMatchingAppOrUnAuthorized || espJobStatus.Status == EspJobStatusState.Completed || espJobStatus.Status == EspJobStatusState.NoPriorHistory))
            {
                jobStatusResponse = TriggerJob(jobTriggerRequest);
            }
            else
            {
                //TODO: Log why trigger is not possible;
                throw new ApplicationException("MDUA-ESP-001: Could not Trigger job because it is active or one of this dependent job is active.");
            }
            //Validate the response
            if (jobStatusResponse == null)
            {
                this.opsStatusDbManager.LogEvent(userId, "DbODJobsManagerDataProvider.cs", "Trigger Job", new ApplicationException("TriggerJob() returned null"), UserToolLogLevel.Error);
                throw new ApplicationException("TriggerJob() returned null");
            }
            else if (jobStatusResponse.Info.Status != EspKnownValues.EspInfoStatus.Success)
            {
                LogError(userId, jobName, jobStatusResponse);
                throw new ApplicationException("Response status from TriggerJob() did not contain success.");
            }

            this.opsStatusDbManager.LogEvent(userId, "DbODJobsManagerDataProvider.cs", string.Format("Trigger Job {0}-{1}-{2}", jobName, subAppName, jobParams), "Success", UserToolLogLevel.Audit);
            return jobStatusResponse;
        
        }
        private EspMessage TriggerJob(EspMessage request)
        {
            EspMessage triggerJobResponse = null;
            triggerJobResponse = ExecuteEspCommandWrapper(request);
            return triggerJobResponse;
        }
        private EspMessage ExecuteEspCommandWrapper(EspMessage request)
        {
            try
            {
                return ExecuteEspCommand(request);
            }
            catch (WebException ex)
            {
                if (ex.Status == WebExceptionStatus.ReceiveFailure || ex.Status == WebExceptionStatus.ConnectionClosed)
                {
                    //Sleep for 2 seconds and retry
                    System.Threading.Thread.Sleep(2000);
                    return ExecuteEspCommand(request);
                }
                else
                {
                    throw ex;
                }
            }

        }
        /// <summary>
        /// Executes a ESP Request
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        private EspMessage ExecuteEspCommand(EspMessage request)
        {
            // Create a request for the URL. 
            string espCommandURL = string.Format("{0}/{1}", this.ESPConfig.EspRestApiUrl, Command);
            EspMessage commandResponse = null;
            Stream PostData = null;
            HttpWebResponse resp = null;
            HttpWebRequest req = null;
            StreamReader loResponseStream = null;
            try
            {
                req = WebRequest.Create(espCommandURL) as HttpWebRequest;
                //keep alive property should be false: otherwise getting random server closed error
                req.KeepAlive = false;
                req.Method = "POST";
                //ESP Rest API requires Basic Authenciation with credentials in the format: BASE64-UTF8(username:password)
                req.Headers.Add(Authorization, string.Format("{0} {1}", "Basic", GetEspAuth()));
                //Prepare post data
                string requestData = Utility.SerializeToJson(request);
                byte[] buffer = Encoding.ASCII.GetBytes(requestData);
                req.ContentLength = buffer.Length;
                req.ContentType = "application/json";
                //Get request stream and write post data
                PostData = req.GetRequestStream();
                PostData.Write(buffer, 0, buffer.Length);
                PostData.Close();
                //Get Response
                resp = req.GetResponseNoException();
                Encoding enc = System.Text.Encoding.GetEncoding(1252);
                loResponseStream = new StreamReader(resp.GetResponseStream(), enc);
                string response = loResponseStream.ReadToEnd();
                loResponseStream.Close();
                resp.Close();
                //Deserialize the response
                try
                {
                    commandResponse = Utility.DeserializeFromJson<EspMessage>(response);
                }
                catch (Exception)
                {
                    const string pat = "list";
                    var loc = response.IndexOf(pat);
                    var msg = response.Substring(loc == -1 ? 0 : loc + pat.Length).Trim('"', ':', '[', ']', '\n', '\r', '\t', '}', ']');
                    commandResponse = new EspMessage { Info = new EspInfo { Status = "jsonerror", Type = "command" }, Data = new EspData { Message = msg } };
                }
                //return the deserilized response back
                return commandResponse;
            }
            finally
            {
                if (PostData != null) PostData.Close();
                if (resp != null) resp.Close();
                if (loResponseStream != null) loResponseStream.Close();
                if (req != null) req = null;
            }

        }


        //private EspMessage ExecuteEspCommand(EspMessage request)
        //{
        //    EspMessage commandResponse = null;

        //    // Create a request for the URL. 
        //    string espCommandURL = string.Format("{0}/{1}", this.ESPConfig.EspRestApiUrl, Command);
        //    System.Net.HttpWebRequest client = System.Net.WebRequest.Create(espCommandURL) as System.Net.HttpWebRequest;
        //    client.Method = "POST";
        //    client.Accept = "application/json";
        //    //keep alive property should be false: otherwise getting random server closed error
        //    client.KeepAlive = false;
        //    //ESP Rest API requires Basic Authenciation with credentials in the format: BASE64-UTF8(username:password)
        //    client.Headers.Add(Authorization, string.Format("{0} {1}", "Basic", GetEspAuth()));
        //    //Prepare post data
        //    string requestData = Utility.SerializeToJson(request);
        //    //byte[] buffer = Encoding.ASCII.GetBytes(requestData);

        //    using (System.Net.WebResponse response = client.GetResponse())
        //    {
        //        using (System.IO.MemoryStream data = new MemoryStream())
        //        {
        //            using (System.IO.Stream responseStream = response.GetResponseStream())
        //            {
        //                responseStream.CopyTo(data);
        //            }

        //            string json = System.Text.Encoding.UTF8.GetString(data.GetBuffer());
        //            commandResponse = Utility.DeserializeFromJson<EspMessage>(json);
        //            return commandResponse;
        //        }

        //    }
            


        //}


        /// <summary>
        /// Returns EspAuth in the format base634-utf8(username:password) 
        /// </summary>
        /// <returns></returns>
        private string GetEspAuth()
        {
            string userName = Utility.Decrypt(this.ESPConfig.EspUserName, base.EncryptionSalt);
            string password = Utility.Decrypt(this.ESPConfig.EspPwd, base.EncryptionSalt);
            return Utility.ConvertToBase64String(string.Format("{0}:{1}", userName, password));
        }

        /// <summary>
        /// Run LAP command without generation
        /// </summary>
        /// <param name="jobName"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        private async Task<EspJobStatus> GetJobStatusAsync(string userId, long jobId)
        {
            var task = Task.Run(() => GetJobStatus(jobId, userId, null));
            return await task;
        }
        /// <summary>
        /// Run LAP command without generation
        /// </summary>
        /// <param name="jobName"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        private  EspJobStatus GetJobStatus(string userId, long jobId)
        {
            return GetJobStatus(jobId, userId, null);
        }
        /// <summary>
        /// Run LAP command with a generation
        /// </summary>
        /// <param name="jobName"></param>
        /// <param name="userId"></param>
        /// <param name="generation"></param>
        /// <returns></returns>
        private EspJobStatus GetJobStatus(long jobId, string userId, long? generation)
        {
            ODJob selectedJob = GetODJobDetailsById(jobId, userId);
            string jobName = selectedJob.Name;
            string subApplName = selectedJob.SubApplicationName;

            return GetJobStatusCore(jobName, subApplName, userId, generation);
 
        }

        private EspJobStatus GetJobStatusCore(string jobName, string subApplName, string userId, long? generation)
        {
            //Validate Inputs
            if (string.IsNullOrEmpty(jobName))
            {
                throw new ArgumentException("jobName cannot be null or empty");
            }
            if (string.IsNullOrEmpty(userId))
            {
                throw new ArgumentException("userId cannot be null or empty");
            }

            //Prepare Esp Request Message
            EspMessage jobStatusRequestAllParentJob = new EspMessage();
            EspMessage jobStatusRequestAllChildJob = new EspMessage();
            EspMessage jobStatusRequestJobs = new EspMessage();
            jobStatusRequestAllParentJob.Info = new EspInfo() { Status = EspKnownValues.EspInfoStatus.Request, Cont = EspKnownValues.EspInfoCont.EOM, Type = EspKnownValues.EspInfoType.Command };
            jobStatusRequestJobs.Info = new EspInfo() { Status = EspKnownValues.EspInfoStatus.Request, Cont = EspKnownValues.EspInfoCont.EOM, Type = EspKnownValues.EspInfoType.Command };

            string espDataRequestAllStatusParentJob = string.Empty;
            string espDataRequestAllStatusChildJob = string.Empty;
            string espDataRequestJobsStatus = string.Empty;

            //Get Status for Parent Job
            espDataRequestAllStatusParentJob = string.Format(EspKnownValues.EspJobRequest.EspStatusRequestFormat, EspKnownValues.EspJobRequest.EspStatusCommand, jobName,
                    (generation == null) ? string.Empty : "." + Convert.ToString(generation), EspLapCommandStatus.ALL);

            //Prepare Request strings for child if specified
            if (!string.IsNullOrEmpty(subApplName))
            {
                //Get Status for Child Job
                espDataRequestAllStatusChildJob = string.Format(EspKnownValues.EspJobRequest.EspSubApplStatusRequestFormat, EspKnownValues.EspJobRequest.EspStatusCommand, jobName,
                        (generation == null) ? string.Empty : "." + Convert.ToString(generation), subApplName, EspLapCommandStatus.ALL);

                jobStatusRequestAllChildJob.Info = new EspInfo() { Status = EspKnownValues.EspInfoStatus.Request, Cont = EspKnownValues.EspInfoCont.EOM, Type = EspKnownValues.EspInfoType.Command };
                jobStatusRequestAllChildJob.Data = new EspData() { Request = espDataRequestAllStatusChildJob };
            }

            espDataRequestJobsStatus = string.Format(EspKnownValues.EspJobRequest.EspStatusRequestFormat, EspKnownValues.EspJobRequest.EspStatusCommand, jobName,
                            (generation == null) ? string.Empty : "." + Convert.ToString(generation), EspLapCommandStatus.JOBS);

            jobStatusRequestAllParentJob.Data = new EspData() { Request = espDataRequestAllStatusParentJob };
            jobStatusRequestJobs.Data = new EspData() { Request = espDataRequestJobsStatus };

            //Get Job Status with ALL Keyword - Parent Job
            EspMessage jobStatusAllMessageParent = GetJobStatus(jobStatusRequestAllParentJob);
            if (jobStatusAllMessageParent.Info.Status == "jsonerror")
            {
                var message = jobStatusAllMessageParent.Data.Message.Replace("\0", string.Empty);
                var status = this.IsNoPriorHistory(message) ? EspJobStatusState.NoPriorHistory : EspJobStatusState.ResponseInBadFormat;
                return new EspJobStatus
                {
                    Status = status,
                    Error = status == EspJobStatusState.NoPriorHistory ? "Warning: there is no prior job history" : message
                };
            }

            EspMessage jobStatusAllMessageChild = new EspMessage();
            EspMessageExtract jobStatusAllMsgExtractChild = new EspMessageExtract();
            EspJobStatus jobStatusChild = new EspJobStatus();

            if (!string.IsNullOrEmpty(subApplName))
            {
                jobStatusAllMessageChild = GetJobStatus(jobStatusRequestAllChildJob);
                jobStatusAllMsgExtractChild = ExtractJobStatus(jobStatusAllMessageChild, jobName);
                jobStatusChild = GetJobStatusFromExtract(jobStatusAllMsgExtractChild);
            }

            //Extract Parent job response
            EspMessageExtract jobStatusAllMsgExtractParent = ExtractJobStatus(jobStatusAllMessageParent, jobName);
            EspJobStatus jobStatusParent = GetJobStatusFromExtract(jobStatusAllMsgExtractParent);

            //Get Job Status with JOBS keyword
            EspMessage jobStatusJobsMessage = GetJobStatus(jobStatusRequestJobs);
            EspMessageExtract jobStatusJobsMsgExtract = ExtractCompletedJobs(jobStatusJobsMessage);
            //Get the Completed and In Complete jobs
            jobStatusParent.CompletedJobs = jobStatusJobsMsgExtract.CompletedJobs;
            jobStatusParent.InCompleteJobs = jobStatusJobsMsgExtract.InCompleteJobs;

            if (string.IsNullOrEmpty(subApplName))
            {
                return jobStatusParent;
            }
            else
            {
                //In some scenerios, child job status doesnt show anticipated end keyword when its successor is running
                if (jobStatusParent.Status == EspJobStatusState.InCompleteDependentJobs)
                {
                    return jobStatusParent;
                }
                else
                {
                    return jobStatusChild;
                }
            }
        }

        private bool IsNoPriorHistory(String message)
        { 
            var marker1 = "YOUR AUTHORITY IS INSUFFICIENT FOR ACCESS, OR APPLICATION  NOT FOUND";
            var marker2 = "APPLICATION NO LONGER ON APPL FILE";
            var upper = message.ToUpper();
            return upper.Contains(marker1) || upper.Contains(marker2);
        }

        private EspMessage GetJobStatus(EspMessage request)
        {
            EspMessage jobStatusResponse = ExecuteEspCommandWrapper(request);
            return jobStatusResponse;
        }
        /// <summary>
        /// Parses the http response from ESP and returns message extract
        /// </summary>
        /// <param name="response"></param>
        /// <param name="jobName"></param>
        /// <returns></returns>
        private EspMessageExtract ExtractJobStatus(EspMessage response, string jobName)
        {
            EspMessageExtract espMessageExtract = new EspMessageExtract();
            if (response.Info != null && response.Info.Status != null)
            {
                if (response.Data != null && response.Data.list != null && response.Data.list.Length > 0)
                {
                    for (int listCounter = 0; listCounter < response.Data.list.Length; listCounter++)
                    {
                        string trimmedString = response.Data.list[listCounter].Trim();
                        trimmedString = trimmedString.ToUpper();

                        if (trimmedString.Contains(EspKnownValues.EspJobResponse.AppNotDefined))
                        {
                            espMessageExtract.IsAppNotDefined = true;
                            //Found in the first line. No need to to look into other status, so can stop parsing here.
                            break;
                        }
                        else if (trimmedString.Contains(EspKnownValues.EspJobResponse.NoMatchingAppOrUnAuthorized))
                        {
                            espMessageExtract.IsNoMatchingAppOrUnAuthorized = true;
                            //Found in the first line. No need to to look into other status, so can stop parsing here.
                            break;
                        }
                        else if (trimmedString.Contains(EspKnownValues.EspJobResponse.InValidAppSpec))
                        {
                            espMessageExtract.IsInvalidAppSpec = true;
                            //Found in the first line. No need to to look into other status, so can stop parsing here.
                            break;

                        }
                        else if (trimmedString.StartsWith(EspKnownValues.EspJobResponse.Appl) && trimmedString.Contains(jobName) && trimmedString.Contains(EspKnownValues.EspJobResponse.Generation))
                        {
                            int genIndex = trimmedString.IndexOf(EspKnownValues.EspJobResponse.Generation);
                            string gen = trimmedString.Substring(genIndex);
                            gen = gen.Replace(EspKnownValues.EspJobResponse.Generation, string.Empty);
                            int endOfGen = gen.IndexOf(" ");
                            gen = endOfGen > 0 ? gen.Substring(0, endOfGen) : gen;
                            long lGen;
                            if (long.TryParse(gen, out lGen))
                            {
                                espMessageExtract.Generation = lGen;
                            }
                            else
                            {
                                //GeneralDatabaseAccess.LogEvent("EspManager.cs", "ExtractJobStatus", "Cannot parse Generation. {0}", trimmedString, UserToolLogLevel.Debug);
                            }

                            if (trimmedString.Contains(EspKnownValues.EspJobResponse.Complete))
                            {
                                //This can be successfull complete or failed complete
                                espMessageExtract.IsComplete = true;
                            }

                            /*if (trimmedString.Contains("APPLWAIT"))
                            {
                                espMessageExtract.IsWaiting = true;
                            }*/
                        }

                        else if (trimmedString.StartsWith(EspKnownValues.EspJobResponse.CreatedAt))
                        {
                            //CREATED AT 17.01 ON WEDNESDAY APRIL 20TH, 2016
                            trimmedString = trimmedString.Replace(EspKnownValues.EspJobResponse.CreatedAt, string.Empty);
                            //17.01 ON WEDNESDAY APRIL 20TH, 2016
                            trimmedString = Utility.FormatEspDateTime(trimmedString);
                            //17.01 WEDNESDAY APRIL 20, 2016

                            DateTime startDate = ParseEspDateTime(trimmedString);
                            //TODO: Validate
                            espMessageExtract.StartedOn = startDate;

                            //If there is a end date, it would be on the next line; Try to get end date and stop parsing
                            if (listCounter + 1 < response.Data.list.Length)
                            {
                                listCounter++;
                                trimmedString = response.Data.list[listCounter].Trim();
                                if (trimmedString.StartsWith(EspKnownValues.EspJobResponse.EndedAt))
                                {
                                    //ENDED AT 17.02 ON WEDNESDAY APRIL 20TH, 2016
                                    trimmedString = trimmedString.Replace(EspKnownValues.EspJobResponse.EndedAt, string.Empty);
                                    //17.02 ON WEDNESDAY APRIL 20TH, 2016
                                    trimmedString = Utility.FormatEspDateTime(trimmedString);
                                    //17.02 WEDNESDAY APRIL 20, 2016
                                    DateTime endDate = ParseEspDateTime(trimmedString);
                                    //TODO: Validate
                                    espMessageExtract.EndedOn = endDate;
                                }
                            }

                            //Continue to parse to see if there is an anticipated end time
                        }
                        else if (trimmedString.StartsWith(EspKnownValues.EspJobResponse.AnticipatedEndTime))
                        {
                            espMessageExtract.HasAnticipatedEndOn = true;
                            if (trimmedString.Contains(EspKnownValues.EspJobResponse.AnticipatedEndTimeNotAvailable) == false)
                            {
                                //ANTICIPATED END TIME: 13.01 ON SATURDAY APRIL 30TH, 2016
                                trimmedString = trimmedString.Replace(EspKnownValues.EspJobResponse.AnticipatedEndTime, string.Empty);
                                //13.01 ON SATURDAY APRIL 30TH, 2016
                                trimmedString = Utility.FormatEspDateTime(trimmedString);
                                //13.01 SATURDAY APRIL 30, 2016
                                DateTime anticipatedEndDate = ParseEspDateTime(trimmedString);
                                //TODO: Validate
                                espMessageExtract.AnticipatedEndOn = anticipatedEndDate;
                            }
                            //stop parsing
                            break;

                        }


                    }
                }
            }
            return espMessageExtract;
        }
        /// <summary>
        /// Generates EspJobStatus from Message Extract
        /// </summary>
        /// <param name="messageExtract"></param>
        /// <returns></returns>
        private EspJobStatus GetJobStatusFromExtract(EspMessageExtract messageExtract)
        {
            EspJobStatus espJobStatus = new EspJobStatus();
            //App Not Defined
            if (messageExtract.IsAppNotDefined == true)
            {
                espJobStatus.Status = EspJobStatusState.AppNotDefined;
                espJobStatus.StartedOn = null;
                espJobStatus.EndedOn = null;
                espJobStatus.AnticipatedEndOn = null;
                espJobStatus.Generation = null;
            }
            //NoMatchingAppOrUnAuthorized
            else if (messageExtract.IsNoMatchingAppOrUnAuthorized == true)
            {
                espJobStatus.Status = EspJobStatusState.NoMatchingAppOrUnAuthorized;
                espJobStatus.StartedOn = null;
                espJobStatus.EndedOn = null;
                espJobStatus.AnticipatedEndOn = null;
                espJobStatus.Generation = null;
            }
            else if (messageExtract.IsInvalidAppSpec == true)
            {
                espJobStatus.Status = EspJobStatusState.IsInvalidAppSpec;
                espJobStatus.StartedOn = null;
                espJobStatus.EndedOn = null;
                espJobStatus.AnticipatedEndOn = null;
                espJobStatus.Generation = null;
            }
            //Completed Successfully or with failure
            else if (messageExtract.IsComplete == true && messageExtract.HasAnticipatedEndOn == false)
            {
                espJobStatus.Status = EspJobStatusState.Completed;
                if (messageExtract.StartedOn.HasValue)
                {
                    espJobStatus.StartedOn = messageExtract.StartedOn.Value.ToString("dddd, MMMM dd, yyyy h:mm tt");
                    espJobStatus.ElapsedTime = CalculateElapsedTime(messageExtract.StartedOn);
                }
                espJobStatus.EndedOn = (messageExtract.EndedOn.HasValue ? messageExtract.EndedOn.Value.ToString("dddd, MMMM dd, yyyy h:mm tt") : string.Empty);
                espJobStatus.AnticipatedEndOn = null;
                espJobStatus.Generation = espJobStatus.Generation;
            }
            //Dependent jobs still running
            else if (messageExtract.IsComplete == false && messageExtract.HasAnticipatedEndOn == true)
            {
                espJobStatus.Status = EspJobStatusState.InCompleteDependentJobs;
                if (messageExtract.StartedOn.HasValue)
                {
                    espJobStatus.StartedOn = messageExtract.StartedOn.Value.ToString("dddd, MMMM dd, yyyy h:mm tt");
                    espJobStatus.ElapsedTime = CalculateElapsedTime(messageExtract.StartedOn);
                }
                espJobStatus.EndedOn = (messageExtract.EndedOn.HasValue ? messageExtract.EndedOn.Value.ToString("dddd, MMMM dd, yyyy h:mm tt") : string.Empty);
                espJobStatus.Generation = espJobStatus.Generation;
                espJobStatus.AnticipatedEndOn = (messageExtract.AnticipatedEndOn.HasValue ? messageExtract.AnticipatedEndOn.Value.ToString("dddd, MMMM dd, yyyy h:mm tt") : string.Empty);
            }
            //Job is complete; Consider the job completed because there is no anticipated
            else if (messageExtract.IsComplete == false && messageExtract.HasAnticipatedEndOn == false)
            {
                espJobStatus.Status = EspJobStatusState.Completed;
                if (messageExtract.StartedOn.HasValue)
                {
                    espJobStatus.StartedOn = messageExtract.StartedOn.Value.ToString("dddd, MMMM dd, yyyy h:mm tt");
                    espJobStatus.ElapsedTime = CalculateElapsedTime(messageExtract.StartedOn);
                }
                espJobStatus.EndedOn = (messageExtract.EndedOn.HasValue ? messageExtract.EndedOn.Value.ToString("dddd, MMMM dd, yyyy h:mm tt") : string.Empty);
                espJobStatus.AnticipatedEndOn = null;
                espJobStatus.Generation = espJobStatus.Generation;
            }

            espJobStatus.TimeZone = ESPConfig.EspTimezone;
            //Ready - Not possible as per ESP team
            return espJobStatus;
        }

        /// <summary>
        /// Get Completed and InComplete Job Names
        /// </summary>
        /// <param name="response"></param>
        /// <returns></returns>
        private  EspMessageExtract ExtractCompletedJobs(EspMessage response)
        {
            EspMessageExtract espMessageExtract = new EspMessageExtract();
            if (response.Info != null && response.Info.Status != null)
            {
                if (response.Data != null && response.Data.list != null && response.Data.list.Length > 0)
                {
                    foreach (string listItem in response.Data.list)
                    {
                        string trimmedString = listItem.Trim();
                        trimmedString = trimmedString.ToUpper();

                        if (trimmedString.StartsWith(EspKnownValues.EspJobResponse.CompletedJobs))
                        {
                            if (trimmedString.Contains(EspKnownValues.EspJobResponse.CompletedJobsNone) == false)
                            {
                                //"COMPLETED JOBS: TEST1, TEST2"
                                espMessageExtract.CompletedJobs = trimmedString.Replace(EspKnownValues.EspJobResponse.CompletedJobs, string.Empty).Trim(); ;
                            }
                        }
                        else if (trimmedString.StartsWith(EspKnownValues.EspJobResponse.InCompleteJobs))
                        {
                            if (trimmedString.Contains(EspKnownValues.EspJobResponse.CompletedJobsNone) == false)
                            {
                                //"INCOMPLETE JOBS: TEST1, TEST2"
                                espMessageExtract.InCompleteJobs = trimmedString.Replace(EspKnownValues.EspJobResponse.InCompleteJobs, string.Empty).Trim();
                            }
                            //Stop parsing since COMPLETED JOBS must have been parsed already before coming to INCOMPLETE JOBS
                            break;
                        }
                    }
                }
            }
            return espMessageExtract;
        }
        /// <summary>
        /// Converts string containing date in the format "HH.mm dddd MMMM dd yyyy"
        /// </summary>
        /// <param name="dateString"></param>
        /// <returns></returns>
        private  DateTime ParseEspDateTime(string dateString)
        {
            DateTime espDate = new DateTime();
            string[] dateFormats = { EspKnownValues.EspJobResponse.EspDateTimeFormatSingleDigitDay, EspKnownValues.EspJobResponse.EspDateTimeFormatDoubleDigitDay };
            if (DateTime.TryParseExact(dateString, dateFormats,
                    new CultureInfo("en-US"),
                    DateTimeStyles.None,
                    out espDate) == false)
            {
                //GeneralDatabaseAccess.LogEvent("ParseEspDateTime", "EspManager.cs", "Error Parsing DateTime", dateString, UserToolLogLevel.Error);
            }
            return espDate;
        }
        /// <summary>
        /// Logs error
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="jobName"></param>
        /// <param name="message"></param>
        private void LogError(string userId, string jobName, EspMessage message)
        {
            string logMessage = string.Empty;
            if (message.Data != null && message.Data.list != null)
            {
                foreach (string s in message.Data.list)
                {
                    logMessage = logMessage + " " + s;
                }
            }
            this.opsStatusDbManager.LogEvent(userId, "EspManager.cs", jobName,
                   new ApplicationException(string.Format("Info.Status:{0}; List: {1}", message.Info.Status, logMessage)), UserToolLogLevel.Error);
            throw new ApplicationException("Response from TriggerJob() did not contain success.");
        }

        protected override EspJobStatus OnGetJobStatus(string jobName, string subApplName, string userId, long? generation)
        {
            return GetJobStatusCore(jobName, subApplName, userId, generation);
        }
    }
    /// <summary>
    /// Class to hold Message Extract
    /// </summary>
    public class EspMessageExtract
    {
        public long? Generation { get; set; }
        public bool IsComplete { get; set; }
        public bool IsAnyDependentProcessRunning { get; set; }
        //public bool IsFailure { get; set; }
        //public bool IsHold { get; set; }
        public bool IsAppNotDefined { get; set; }
        public bool IsNoMatchingAppOrUnAuthorized { get; set; }
        //public bool IsRunning { get; set; }
        //public bool IsWaiting { get; set; }
        public DateTime? StartedOn { get; set; }
        public DateTime? EndedOn { get; set; }
        public bool HasAnticipatedEndOn { get; set; }
        public DateTime? AnticipatedEndOn { get; set; }
        public bool IsInvalidAppSpec { get; set; }
        public string CompletedJobs { get; set; }
        public string InCompleteJobs { get; set; }

    }
}
