﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Providers.Data;
using VZ.CFO.MDMFramework.Contracts.Data.Reporting;
using Oracle.ManagedDataAccess.Client;
using System.Data;


namespace VZ.CFO.MDMFramework.Server.Providers
{
    public class OracleDbReportingDataProvider : ReportingDataProvider
    {
        private readonly Contracts.Data.Config.DbProfile[] dbProfileList;

        public OracleDbReportingDataProvider(string connectionString, string encryptionSalt, Contracts.Data.Config.DbProfile[] dbProfileList)
            : base(connectionString, encryptionSalt)
        {
            this.dbProfileList = dbProfileList;
        }

        private Contracts.Data.Reporting.KnownValues.PaginationType GetPaginationType(string paginationType)
        {
            if (string.IsNullOrEmpty(paginationType))
            {
                return Contracts.Data.Reporting.KnownValues.PaginationType.None;
            }
            else if (paginationType.Equals("S"))
            {
                return Contracts.Data.Reporting.KnownValues.PaginationType.Server;
            }
            else if (paginationType.Equals("C"))
            {
                return Contracts.Data.Reporting.KnownValues.PaginationType.Client;
            }
            else
            {
                return Contracts.Data.Reporting.KnownValues.PaginationType.None;
            }
        }

        private bool GetIsAggregationField(string isAggregationField)
        {
            if (isAggregationField.Equals("N"))
            {
                return false;
            }
            else if (isAggregationField.Equals("Y"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private string GetConnectionStringFromProfileName(string profileName)
        {
            //TODO: Handle null
            var dbProfile = dbProfileList.FirstOrDefault(d => d.Name == profileName);
            return string.Format(dbProfile.ConnectionString, Common.Utility.Decrypt(dbProfile.EncryptedUserName, EncryptionSalt), Common.Utility.Decrypt(dbProfile.EncryptedPassword, EncryptionSalt));
        }

        private List<ReportGroup> GetReportsCore(string userId, long reportGroupId, long reportId)
        {
            List<ReportGroup> reportGroupList = new List<ReportGroup>();
            Dictionary<long, List<Report>> reportListDiction = new Dictionary<long, List<Report>>();
            Dictionary<long, List<ReportField>> reportFieldDiction = new Dictionary<long, List<ReportField>>();
            Dictionary<long, List<CustomMessage>> customMessageDiction = new Dictionary<long, List<CustomMessage>>();

            using (OracleConnection oraConn = new OracleConnection(this.ConnectionString))
            using (OracleCommand oraCommand = new OracleCommand())
            {
                oraConn.Open();

                OracleCommand getReportsCoreCmd = new OracleCommand("MDMFRAMEWORK.get_report_info", oraConn);
                //userInfoUpdateCmd.BindByName = true;
                getReportsCoreCmd.CommandType = CommandType.StoredProcedure;

                getReportsCoreCmd.Parameters.Add(new OracleParameter("i_user_id", OracleDbType.Varchar2)).Value = userId;
                getReportsCoreCmd.Parameters.Add(new OracleParameter("i_report_id", OracleDbType.Long)).Value = reportId;
                getReportsCoreCmd.Parameters.Add(new OracleParameter("i_group_id", OracleDbType.Long)).Value = reportGroupId;
                getReportsCoreCmd.Parameters.Add(new OracleParameter("v_report_obj", OracleDbType.RefCursor, ParameterDirection.Output));
                getReportsCoreCmd.Parameters.Add(new OracleParameter("v_report_fields", OracleDbType.RefCursor, ParameterDirection.Output));
                getReportsCoreCmd.Parameters.Add(new OracleParameter("v_custom_msg", OracleDbType.RefCursor, ParameterDirection.Output));
                
                try
                {
                    using (var dataReader = getReportsCoreCmd.ExecuteReader(CommandBehavior.CloseConnection))
                    {

                        //
                        int groupIdOrdinal = dataReader.GetOrdinal("REPORTING_GROUP_ID");
                        int groupNameOrdinal = dataReader.GetOrdinal("reporting_group_name");
                        int objectNameOrdinal = dataReader.GetOrdinal("REPORTING_OBJECT_NAME");
                        int reportIdOrdinal = dataReader.GetOrdinal("REPORTING_ID");
                        int DisplayNameOrdinal = dataReader.GetOrdinal("REPORTING_DISPLAY_NAME");
                        int descriptionOrdinal = dataReader.GetOrdinal("DESCRIPTION");
                        int repoIdOrdinal = dataReader.GetOrdinal("REPOSITORY_ID");
                        int createdByOrdinal = dataReader.GetOrdinal("CREATED_BY");
                        int lastModifiedByOrdinal = dataReader.GetOrdinal("LAST_MODIFIED_BY");
                        int createdDateOrdinal = dataReader.GetOrdinal("CREATED_DT");
                        int lastModifiedDateOrdinal = dataReader.GetOrdinal("LAST_MODIFIED_DT");
                        int reportingTypeIdOrdinal = dataReader.GetOrdinal("REPORTING_TYPE_ID");
                        int paginationTypeOrdinal = dataReader.GetOrdinal("PAGINATION_TYPE");
                        int filterClauseOrdinal = dataReader.GetOrdinal("FILTER_CLAUSE");
                        int repoNameOrdinal = dataReader.GetOrdinal("REPOSITORY_NAME");
                        int RepoTypeOrdinal = dataReader.GetOrdinal("REPOSITORY_TYPE");
                        int reportingTypeNameOrdinal = dataReader.GetOrdinal("REPORTING_TYPE_NAME");

                        
                        while (dataReader.Read())
                        {

                            var groupId = dataReader.GetInt64(groupIdOrdinal);

                            ReportGroup reportGroup = reportGroupList.FirstOrDefault(g => g.Id == groupId);
                            if (reportGroup == null)
                            {
                                //new group
                                reportGroup = new ReportGroup() 
                                { 
                                    Id = groupId,
                                    Name = dataReader.GetString(groupNameOrdinal)
                                };

                                reportGroupList.Add(reportGroup);
                                reportListDiction.Add(groupId, new List<Report>());
                            }

                            Report report = new Report() 
                            { 
                                Id = dataReader.GetInt64(reportIdOrdinal),
                                ObjectName = dataReader.GetString(objectNameOrdinal),
                                CreatedBy = dataReader.IsDBNull(createdByOrdinal) ? string.Empty : dataReader.GetString(createdByOrdinal),
                                CreatedOn = dataReader.IsDBNull(createdDateOrdinal) ? null : dataReader.GetDateTime(createdDateOrdinal) as DateTime?,
                                Description = dataReader.IsDBNull(descriptionOrdinal) ? string.Empty : dataReader.GetString(descriptionOrdinal),
                                DisplayName = dataReader.IsDBNull(DisplayNameOrdinal) ? string.Empty : dataReader.GetString(DisplayNameOrdinal),
                                FilterClause = dataReader.IsDBNull(filterClauseOrdinal) ? string.Empty : dataReader.GetString(filterClauseOrdinal),
                                LastModifiedBy = dataReader.IsDBNull(lastModifiedByOrdinal) ? string.Empty : dataReader.GetString(lastModifiedByOrdinal),
                                LastModifiedOn = dataReader.IsDBNull(lastModifiedDateOrdinal) ? null : dataReader.GetDateTime(lastModifiedDateOrdinal) as DateTime?,
                                PagingType = dataReader.IsDBNull(paginationTypeOrdinal) ? Contracts.Data.Reporting.KnownValues.PaginationType.None : GetPaginationType(dataReader.GetString(paginationTypeOrdinal)),
                                ReportType = dataReader.IsDBNull(reportingTypeIdOrdinal) ? Contracts.Data.Reporting.KnownValues.ReportType.None : (Contracts.Data.Reporting.KnownValues.ReportType)dataReader.GetInt32(reportingTypeIdOrdinal)
                            };

                            Repository reportRepository = new Repository()
                            {
                                Name = dataReader.IsDBNull(repoNameOrdinal) ? string.Empty : dataReader.GetString(repoNameOrdinal),
                                Type = dataReader.IsDBNull(RepoTypeOrdinal) ? KnownValues.RepositoryType.NONE : (KnownValues.RepositoryType)Enum.Parse(typeof(KnownValues.RepositoryType), dataReader.GetString(RepoTypeOrdinal))
                            };

                            report.Respository = reportRepository;
                            reportListDiction[groupId].Add(report);
                        }

                        if (dataReader.NextResult())
                        {
                            groupIdOrdinal = dataReader.GetOrdinal("reporting_group_id");
                            reportIdOrdinal = dataReader.GetOrdinal("reporting_id");
                            int fieldDisplayNameOrdinal = dataReader.GetOrdinal("FIELD_DISPLAY_NAME");
                            int fieldPhysicalNameOrdinal = dataReader.GetOrdinal("FIELD_PHYSICAL_NAME");
                            int fieldAxisOrdinal = dataReader.GetOrdinal("FIELD_AXIS");
                            int isAggFieldOrdinal = dataReader.GetOrdinal("IS_AGGREGATION_FIELD");
                            int orderNoOrdinal = dataReader.GetOrdinal("ORDER_NO");

                            while (dataReader.Read())
                            {
                                var reportIdFromDb = dataReader.GetInt64(reportIdOrdinal);

                                ReportField reportField = new ReportField() 
                                {
                                    DisplayName = dataReader.IsDBNull(fieldDisplayNameOrdinal) ? string.Empty : dataReader.GetString(fieldDisplayNameOrdinal),
                                    FieldAxis = dataReader.IsDBNull(fieldAxisOrdinal) ? KnownValues.FieldAxis.NONE : (KnownValues.FieldAxis)dataReader.GetInt32(fieldAxisOrdinal),
                                    IsAggreationField = dataReader.IsDBNull(isAggFieldOrdinal) ? false : GetIsAggregationField(dataReader.GetString(isAggFieldOrdinal)),
                                    PhysicalName = dataReader.IsDBNull(fieldPhysicalNameOrdinal) ? string.Empty : dataReader.GetString(fieldPhysicalNameOrdinal)
                                };

                                if (reportFieldDiction.ContainsKey(reportIdFromDb) == false)
                                {
                                    reportFieldDiction.Add(reportIdFromDb, new List<ReportField>());                                    
                                }
                                
                                reportFieldDiction[reportIdFromDb].Add(reportField);
                            }
                        }

                        if (dataReader.NextResult())
                        {
                            groupIdOrdinal = dataReader.GetOrdinal("reporting_group_id");
                            reportIdOrdinal = dataReader.GetOrdinal("reporting_id");
                            int eventNameOrdinal = dataReader.GetOrdinal("event_name");
                            int messageNameOrdinal = dataReader.GetOrdinal("message");
                            
                            while (dataReader.Read())
                            {
                                var reportIdFromDb = dataReader.GetInt64(reportIdOrdinal);
                                CustomMessage customMessage = new CustomMessage() 
                                {
                                    Event = dataReader.IsDBNull(eventNameOrdinal) ? string.Empty : dataReader.GetString(eventNameOrdinal),
                                    Message = dataReader.IsDBNull(messageNameOrdinal) ? string.Empty : dataReader.GetString(messageNameOrdinal)
                                };

                                if (customMessageDiction.ContainsKey(reportIdFromDb) == false)
                                {
                                    customMessageDiction.Add(reportIdFromDb, new List<CustomMessage>());
                                }

                                customMessageDiction[reportIdFromDb].Add(customMessage);
                            }
                        }

                        dataReader.Close();
                    }

                    //consolidate report fields

                    foreach(var groupIdFromDiction in reportListDiction.Keys)
                    {
                        foreach (var reportFromDiction in reportListDiction[groupIdFromDiction])
                        {
                            if (reportFieldDiction.ContainsKey(reportFromDiction.Id))
                            {
                                reportFromDiction.Columns = reportFieldDiction[reportFromDiction.Id].ToArray();
                            }

                            if (customMessageDiction.ContainsKey(reportFromDiction.Id))
                            {
                                reportFromDiction.CustomMessages = customMessageDiction[reportFromDiction.Id].ToArray();
                            }
                        }

                        reportGroupList.FirstOrDefault(g => g.Id == groupIdFromDiction).Reports = reportListDiction[groupIdFromDiction].ToArray();
                    }
                }
                catch (Exception ex)
                {
                    throw;
                }
                finally
                {
                    oraConn.Close();
                }

            }

            return reportGroupList;
        }

        private int GetTotalRowsFromTable(string tableName, string connectString)
        {
            string queryTotalRecords = string.Format("SELECT COUNT(1) as totalRecords FROM {0}", tableName);

            int returnValue = 0;

            using (OracleConnection conn = new OracleConnection(connectString))
            using (OracleCommand cmd = new OracleCommand(queryTotalRecords, conn))
            {
                conn.Open();
                try
                {
                    using (OracleDataReader dataReader = cmd.ExecuteReader())
                    {
                        int totalRecordsCol = dataReader.GetOrdinal("totalRecords");
                        if (dataReader.Read())
                        {
                            returnValue = dataReader.GetInt32(totalRecordsCol);
                        }

                        dataReader.Close();
                    }
                }
                catch (Exception e)
                {
                    throw;
                }
                finally
                {
                    conn.Close();
                }
            }
            return returnValue;
        } 

        private ReportingResponse GetReportsDataCore(string userId, long reportId, int pageNumber, int rowsPerPage, int totalRecords)
        {
            ReportingResponse reportingResponse = new ReportingResponse();

            var report = OnGetReport(userId, reportId);

            if (report == null)
            {
                throw new Exception("Report info cannot be retreived. Either it does not exist or you dont have access");
            }

            /*
             * 0 - column list
             * 1 - table name
             * 2 - start row
             * 3 - end row
             */ 
            //string queryFmt = "select /*+ parallel 16 */ ROWNUM rnum, rowid as urowid, {0} from {1} where rownum between {2} and {3}";

            //{0} - column list
            //{1} - column list 
            //{2} - Mapping Table Name
            //{3} - StartRow
            //{4} - EndRow
            string queryFmt = "SELECT {0} FROM (SELECT ROWNUM rnum, a.* FROM (SELECT 0 as urowid, {1} FROM {2}) a) WHERE rnum BETWEEN {3} AND {4}";

            string reportConnectionString = GetConnectionStringFromProfileName(report.Respository.Name);

            //Calculate Total Records if not known
            if (totalRecords == 0)
            {
                totalRecords = GetTotalRowsFromTable(report.ObjectName, reportConnectionString);
            }

            //Calculate start and end row
            int endRow = pageNumber * rowsPerPage;
            int startRow = (endRow - rowsPerPage) + 1;

            //Calculate total pages
            decimal totalPages = Decimal.Ceiling(Decimal.Divide(totalRecords, rowsPerPage));
            if (endRow > totalRecords)
            {
                endRow = totalRecords;
            }

            //generate column list
            var columnTempList = new List<string>();
            foreach (var reportField in report.Columns)
            {
                columnTempList.Add(reportField.PhysicalName);
            }
            string columnList = string.Join(",", columnTempList.ToArray(), 0, columnTempList.Count);

            //generate query            
            string query = string.Format(queryFmt, columnList, columnList, report.ObjectName, startRow, endRow);

            //Prepare return value
            reportingResponse.ReportingData = new ReportingData();
            reportingResponse.ReportingData.PageNumber = pageNumber;
            reportingResponse.ReportingData.RowsPerPage = rowsPerPage;
            reportingResponse.ReportingData.TotalPages = Convert.ToInt32(totalPages);
            reportingResponse.ReportingData.TotalRows = totalRecords;
            

            //Data structure for column data
            Dictionary<int, List<string>> columnDiction = new Dictionary<int, List<string>>();

            //initialize the column in the column dictionary
            for (var colIndex = 0; colIndex < report.Columns.Length; colIndex++)
            {
                columnDiction.Add(colIndex, new List<string>());
            }

            bool hasData = false;

            using (OracleConnection conn = new OracleConnection(reportConnectionString))
            using (OracleCommand cmd = new OracleCommand(query, conn))
            {
                try
                {
                    conn.Open();
                    using (OracleDataReader dataReader = cmd.ExecuteReader())
                    {
                        if (dataReader.HasRows)
                        {
                            //Read data from table
                            while (dataReader.Read())
                            {
                                for (var colIndex = 0; colIndex < report.Columns.Length; colIndex++)
                                {
                                    columnDiction[colIndex].Add(dataReader.IsDBNull(colIndex) ? "<null>" : Convert.ToString(dataReader.GetValue(colIndex)));
                                }
                            }

                            hasData = true;
                        }
                                               

                        dataReader.Close();
                    }
                }
                catch (Exception e)
                {
                    throw;
                }
                finally
                {
                    conn.Close();
                }
            }

            //Assign the values from column diction to return object
            List<VZ.CFO.MDMFramework.Contracts.Data.ColumnData> reportColumnValuesList = new List<VZ.CFO.MDMFramework.Contracts.Data.ColumnData>();

            if (hasData)
            {
                for (var colIndex = 0; colIndex < report.Columns.Length; colIndex++)
                {
                    reportColumnValuesList.Add(new VZ.CFO.MDMFramework.Contracts.Data.ColumnData() { Values = columnDiction[colIndex].ToArray() });
                }
            }

            reportingResponse.ReportingData.Data = reportColumnValuesList.ToArray();
            return reportingResponse;
        }

        protected override Report OnGetReport(string userId, long reportId)
        {
            var reportGroupList = GetReportsCore(userId, 0, reportId);
            if (reportGroupList.Count > 0 && reportGroupList[0].Reports.Length > 0)
            {
                return reportGroupList[0].Reports[0];
            }
            else
            {
                return null;
            }
        }

        protected override ReportingResponse OnGetReportDataAsync(string userId, long reportId)
        {
            return GetReportsDataCore(userId, reportId, 1, 2500, 0);
        }

        protected override ReportingResponse OnGetReportDataAsync(string userId, long reportId, int pageNumber, int rowsPerPage, int totalRecords)
        {
            return GetReportsDataCore(userId, reportId, pageNumber, rowsPerPage, totalRecords);
        }

        protected override Task<ReportingResponse> OnGetReportDataAsync(string userId, long reportId, Contracts.Data.Reporting.KnownValues.RepositoryType repositoryType)
        {
            throw new NotImplementedException();
        }

        protected override Task<ReportingResponse> OnGetReportDataAsync(string userId, long reportId, Contracts.Data.Reporting.KnownValues.RepositoryType repositoryType, int pageNumber, int rowsPerPage, int totalRecords)
        {
            throw new NotImplementedException();
        }

        protected override ReportGroup[] OnGetReports(string userId)
        {
            var reportGroups = GetReportsCore(userId, 0, 0);
            if (reportGroups.Count > 0)
            {
                return reportGroups.ToArray();
            }
            else
            {
                return null;
            }
        }

        protected override ReportGroup OnGetReportsByGroupId(string userId, long groupId)
        {
            var reportGroups = GetReportsCore(userId, groupId, 0);
            if (reportGroups.Count > 0 && reportGroups[0].Reports.Length > 0)
            {
                return reportGroups[0];
            }
            else
            {
                return null;
            }
        }
    }
}
