﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Data;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables;
using VZ.CFO.MDMFramework.Contracts.Service.MDUA;
using VZ.CFO.MDMFramework.Providers.Data;

namespace VZ.CFO.MDMFramework.Server.Providers
{
    public class DbFactTableUserUploadManagerDataProvider : MDMFramework.Providers.Data.FactTableUserUploadManagerDataProvider
    {
        private readonly Contracts.Data.Config.DbProfile[] dbProfileList;
        private readonly IFactTableManager factTableManager = null;
        private IOpsStatusLogManager opsLogManager = null;

        private readonly int maxRowsPerUpdate = 2000;

        private readonly int maxErrorRowsToDisplay = 30;

        public DbFactTableUserUploadManagerDataProvider(string connectionString, string encryptionSalt, Contracts.Data.Config.DbProfile[] dbProfileList, IFactTableManager factTableManager, IOpsStatusLogManager opsLogManager)
            : base(connectionString, encryptionSalt)
        {
            this.dbProfileList = dbProfileList;
            this.factTableManager = factTableManager;
            this.opsLogManager = opsLogManager;
        }

        private string GetConnectionStringFromProfileName(string profileName)
        {
            //TODO: Move to common
            var dbProfile = dbProfileList.FirstOrDefault(d => d.Name == profileName);
            return string.Format(dbProfile.ConnectionString, Common.Utility.Decrypt(dbProfile.EncryptedUserName, EncryptionSalt), Common.Utility.Decrypt(dbProfile.EncryptedPassword, EncryptionSalt));
        }

        private string GetBindableColumns(List<string> sqlFieldNames)
        {
            //var bindableColumns = string.Format(":{0}", string.Join(", :", sqlFieldNames));
            //return bindableColumns;
            return GetPrefixedColumns(sqlFieldNames, ":");
        }

        private string GetPrefixedColumns(List<string> sqlFieldNames, string prefix)
        {

            var prefixedColumns = string.Format("{0}{1}", prefix, string.Join(", " + prefix, sqlFieldNames));
            return prefixedColumns;
        }

        private FactProcessUploadedFileResponse StageExcelContentsCore(FactProcessUploadedFileRequest request, FactTable factTable, FactFileType factFileType, TableInfo factData)
        {
            //Return Value
            FactProcessUploadedFileResponse response = new FactProcessUploadedFileResponse();
            //validate params

            List<string> sqlFieldNames = new List<string>();
            sqlFieldNames.AddRange(factData.Columns);

            var knownColumns = FactTableKnownValues.GetFactKnownColumns(factFileType.Contains13ColFacts || factFileType.IsOutlook);
            Dictionary<string, List<OracleParameterStatus>> sqlColumnNullList = new Dictionary<string, List<OracleParameterStatus>>();


            for (int colIndex = 0; colIndex < factData.Columns.Length; colIndex++)
            {
                var knownCol = knownColumns.FirstOrDefault(f => f.Name.ToUpper() == factData.Columns[colIndex]);
                if (knownCol != null && knownCol.CanAllowNullNonAdjustment == true)
                {
                    var nullColList = new List<OracleParameterStatus>();
                    for (int rowIndex = 0; rowIndex < factData.Data[colIndex].Values.Length; rowIndex++)
                    {
                        if (factData.Data[colIndex].Values[rowIndex] == null)
                        {
                            nullColList.Add(OracleParameterStatus.NullInsert);
                        }
                        else
                        {
                            nullColList.Add(OracleParameterStatus.Success);
                        }
                    }
                    sqlColumnNullList.Add(knownCol.Name, nullColList);
                }
            }

            //generate insert query
            string stageInsertSql = string.Format("insert into {0} ({1}, source, owner, run_status_id) " +
                    " values ({2}, '{3}', '{4}', '{5}') ",
                    (factFileType.Contains13ColFacts || factFileType.IsOutlook ? factTable.YearlyUploadStageName : factTable.MonthlyUploadStageName),
                    string.Join(",", sqlFieldNames),
                    GetBindableColumns(sqlFieldNames),
                    factFileType.Code,
                    request.UserId,
                    request.RunStatusId
                    );

            int totalRows = factData.Data[0].Values.Length;
            int startIndex = 0, endIndex = 0, totalRowsInCurrentIteration = 0;
            Decimal totalIterations = Decimal.Ceiling(Decimal.Divide(totalRows, maxRowsPerUpdate));

            //get connection string
            var profileConnectionString = GetConnectionStringFromProfileName(factTable.RepoProfile);
            using (OracleConnection conn = new OracleConnection(profileConnectionString))
            using (OracleCommand cmdStage = new OracleCommand(stageInsertSql, conn))
            {

                conn.Open();

                using (OracleTransaction transaction = conn.BeginTransaction())
                {
                    try
                    {
                        for (int iterationCounter = 1; iterationCounter <= totalIterations; iterationCounter++)
                        {
                            endIndex = (iterationCounter * maxRowsPerUpdate) - 1;
                            startIndex = (endIndex - maxRowsPerUpdate) + 1;
                            if (endIndex >= totalRows)
                            {
                                endIndex = totalRows - 1;
                            }
                            totalRowsInCurrentIteration = endIndex - startIndex + 1;

                            //bind columns
                            var paramsList = new List<OracleParameter>();
                            for (int fieldIndex = 0; fieldIndex < sqlFieldNames.Count; fieldIndex++)
                            {
                                var oracleParam = new OracleParameter(sqlFieldNames[fieldIndex], OracleDbType.Varchar2);
                                string[] colDataForCurrentIteration = new string[totalRowsInCurrentIteration];
                                Array.Copy(factData.Data[fieldIndex].Values, startIndex, colDataForCurrentIteration, 0, totalRowsInCurrentIteration);
                                oracleParam.Value = colDataForCurrentIteration;

                                if (sqlColumnNullList.ContainsKey(sqlFieldNames[fieldIndex]))
                                {
                                    //oracleParam.ArrayBindStatus = sqlColumnNullList[sqlFieldNames[fieldIndex]].ToArray();
                                    oracleParam.ArrayBindStatus = new OracleParameterStatus[totalRowsInCurrentIteration];
                                    Array.Copy(sqlColumnNullList[sqlFieldNames[fieldIndex]].ToArray(), startIndex, oracleParam.ArrayBindStatus, 0, totalRowsInCurrentIteration);
                                }

                                paramsList.Add(oracleParam);
                            }

                            cmdStage.BindByName = true;
                            cmdStage.ArrayBindCount = totalRowsInCurrentIteration;
                            cmdStage.Parameters.Clear();
                            cmdStage.Parameters.AddRange(paramsList.ToArray());

                            response.RowsAffected = cmdStage.ExecuteNonQuery();

                        }
                        //bind columns
                        //List<OracleParameter> paramsList = new List<OracleParameter>();
                        //for (int fieldIndex = 0; fieldIndex < sqlFieldNames.Count; fieldIndex++)
                        //{
                        //    //string[] s = Array.Copy( factData.Data[0].Values[0];
                        //    var oracleParam = new OracleParameter(sqlFieldNames[fieldIndex], OracleDbType.Varchar2);
                        //    string[] s = new string[2000];
                        //    Array.Copy(factData.Data[fieldIndex].Values, 0, s, 2000, 2000);
                        //    //{ 
                        //    //    Value = factData.Data[fieldIndex].Values
                        //    //};

                        //    if (sqlColumnNullList.ContainsKey(sqlFieldNames[fieldIndex]))
                        //    {
                        //        oracleParam.ArrayBindStatus = sqlColumnNullList[sqlFieldNames[fieldIndex]].ToArray();
                        //    }

                        //    paramsList.Add(oracleParam);
                        //}

                        //cmdStage.BindByName = true;
                        //cmdStage.ArrayBindCount = factData.Data[0].Values.Length;
                        //cmdStage.Parameters.AddRange(paramsList.ToArray());

                        //cmdStage.ExecuteNonQuery();


                        //commit after delete and update is complete
                        transaction.Commit();

                        response.MessageType = Contracts.Data.MDUA.FactTables.FactTableKnownValues.ResponseMsgType.Success;
                        opsLogManager.LogEvent(request.UserId, "StageExcelContentsCore", string.Format("Run Status Id: {0}", request.RunStatusId), "Success", Contracts.Data.MDUA.UserToolLogLevel.Audit);

                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }

            return response;
        }

        private Contracts.Data.MDUA.FactTables.FactProcessUploadedFileResponse ProcessStagedDataCore(Contracts.Data.MDUA.FactTables.FactProcessUploadedFileRequest request, FactTable factTable, FactFileType factFileType, TableInfo factData)
        {

            List<string> sqlFieldNames = new List<string>();
            sqlFieldNames.AddRange(factData.Columns);

            List<string> displayColumns = new List<string>();
            displayColumns.AddRange(factData.ColumnHeaders);

            List<string> factFieldNames = new List<string>();
            foreach (var dim in factTable.AvailableDimensions)
            {
                factFieldNames.Add(dim.FactColumnName);
            }

            if (request.UploadProcessType == FactTableKnownValues.FactUploadProcessType.FactData)
            {
                var knownColumns = FactTableKnownValues.GetFactKnownColumns(factFileType.Contains13ColFacts || factFileType.IsOutlook);
                factFieldNames.AddRange(knownColumns.Select(x => x.Name));
            }

            //Return Value
            FactProcessUploadedFileResponse response = new FactProcessUploadedFileResponse();
            string fiscalPeriod = (request.ReportingPeriod.Month > 9 ? string.Format("{0}{1}", request.ReportingPeriod.Year, request.ReportingPeriod.Month) : string.Format("{0}0{1}", request.ReportingPeriod.Year, request.ReportingPeriod.Month));

            FactTableKnownValues.StageProcessingStatus sprocStatus = FactTableKnownValues.StageProcessingStatus.None;
            int rowsMergeCount = 0;

            //get connection string
            var profileConnectionString = GetConnectionStringFromProfileName(factTable.RepoProfile);
            using (OracleConnection oraConn = new OracleConnection(profileConnectionString))
            using (OracleCommand oraProcessStageToFactCmd = new OracleCommand())
            {
                oraConn.Open();
                try
                {
                    //Run sproc
                    oraProcessStageToFactCmd.Connection = oraConn;
                    oraProcessStageToFactCmd.CommandType = CommandType.StoredProcedure;
                    oraProcessStageToFactCmd.CommandText = string.Format("{0}.process_stage_to_fact", factTable.ValidationProc);
                    oraProcessStageToFactCmd.BindByName = true;

                    oraProcessStageToFactCmd.Parameters.Add(new OracleParameter("i_run_status_id", OracleDbType.Int32, request.RunStatusId, ParameterDirection.Input));
                    oraProcessStageToFactCmd.Parameters.Add(new OracleParameter("i_user_id", OracleDbType.Varchar2, request.UserId, ParameterDirection.Input));
                    oraProcessStageToFactCmd.Parameters.Add(new OracleParameter("i_file_Type_Id", OracleDbType.Long, factFileType.FileTypeCodeId, ParameterDirection.Input));
                    oraProcessStageToFactCmd.Parameters.Add(new OracleParameter("i_fiscal_period", OracleDbType.Varchar2, fiscalPeriod, ParameterDirection.Input));
                    oraProcessStageToFactCmd.Parameters.Add(new OracleParameter("status", OracleDbType.Int32, ParameterDirection.Output));
                    oraProcessStageToFactCmd.Parameters.Add(new OracleParameter("rows", OracleDbType.Int32, ParameterDirection.Output));
                    oraProcessStageToFactCmd.Parameters.Add(new OracleParameter("is_verify_only", OracleDbType.Int32, request.IsVerifyOnly ? 1 : 0, ParameterDirection.Input));

                    oraProcessStageToFactCmd.ExecuteNonQuery();

                    int procedureStatus = Convert.ToInt32(oraProcessStageToFactCmd.Parameters["status"].Value.ToString());
                    rowsMergeCount = Convert.ToInt32(oraProcessStageToFactCmd.Parameters["rows"].Value.ToString());
                    sprocStatus = (FactTableKnownValues.StageProcessingStatus)procedureStatus;

                    opsLogManager.LogEvent(request.UserId, "ProcessStagedDataCore", "ProcessStagedData", string.Format("Run Status Id {0}; Status - {1}", request.RunStatusId, sprocStatus), Contracts.Data.MDUA.UserToolLogLevel.Audit);
                }
                catch
                {
                    throw;
                }
                finally
                {
                    oraConn.Close();
                }
            }

            //check sproc return values
            response = ProcessStagedDataResults(request.RunStatusId, sprocStatus, factTable, factFileType, displayColumns, sqlFieldNames, rowsMergeCount, factFieldNames);
            response.StageProcessStatus = sprocStatus;

            //Gather transaction level messages
            response.TransactionalMessages = GatherTransactionLevelMessages(request.UserId, request.RunStatusId);

            return response;
        }

        private FactProcessUploadedFileResponse ProcessStagedDataResults(long runStatusId, FactTableKnownValues.StageProcessingStatus status, FactTable factTable, FactFileType factFileType, List<string> displayFieldNames, List<string> sqlFieldNames, int rowsMergeCount, List<string> factFieldNames)
        {
            FactProcessUploadedFileResponse stagedDataResults = new FactProcessUploadedFileResponse()
            {
                RunStatusId = runStatusId
            };
            //Return Value
            TableInfo factData = new TableInfo();

            if (status == FactTableKnownValues.StageProcessingStatus.CriticalValidationsFailed ||
                status == FactTableKnownValues.StageProcessingStatus.AdditionOfKeysRequired)
            {
                var profileConnectionString = GetConnectionStringFromProfileName(factTable.RepoProfile);
                using (OracleConnection oraConn = new OracleConnection(profileConnectionString))
                using (OracleCommand oraProcessStageToFactCmd = new OracleCommand())
                {
                    oraConn.Open();
                    try
                    {
                        oraProcessStageToFactCmd.Connection = oraConn;
                        oraProcessStageToFactCmd.Parameters.Clear();
                        oraProcessStageToFactCmd.CommandType = CommandType.Text;

                        //while fetching data from stage tables use sqlFieldNames
                        var stageTableName = (factFileType.Contains13ColFacts || factFileType.IsOutlook ? factTable.YearlyUploadStageName : factTable.MonthlyUploadStageName);
                        oraProcessStageToFactCmd.CommandText = string.Format("select b.message, {0}, a.source, a.owner, a.run_status_id " +
                                " from {1} a, web_validation_tracking b where a.run_status_id = b.run_status_id and a.line_number = b.line_number " +
                                " and a.run_status_id = :i_run_status_id order by line_number", GetPrefixedColumns(sqlFieldNames, "a."), stageTableName);

                        oraProcessStageToFactCmd.Parameters.Add(new OracleParameter("i_run_status_id", OracleDbType.Int32, runStatusId, ParameterDirection.Input));

                        using (OracleDataReader reader = oraProcessStageToFactCmd.ExecuteReader())
                        {

                            Dictionary<string, List<string>> factResultsDiction = new Dictionary<string, List<string>>();
                            Dictionary<string, int> ordinalDiction = new Dictionary<string, int>();
                            factResultsDiction.Add("message", new List<string>());
                            ordinalDiction.Add("message", reader.GetOrdinal("message"));

                            foreach (var colName in sqlFieldNames)
                            {
                                factResultsDiction.Add(colName, new List<string>());
                                ordinalDiction.Add(colName, reader.GetOrdinal(colName));
                            }

                            factResultsDiction.Add("source", new List<string>());
                            ordinalDiction.Add("source", reader.GetOrdinal("source"));
                            factResultsDiction.Add("owner", new List<string>());
                            ordinalDiction.Add("owner", reader.GetOrdinal("owner"));
                            factResultsDiction.Add("run_status_id", new List<string>());
                            ordinalDiction.Add("run_status_id", reader.GetOrdinal("run_status_id"));

                            reader.FetchSize = oraProcessStageToFactCmd.RowSize * 1500;
                            if (reader.HasRows)
                            {
                                int rowCount = 0;
                                while (reader.Read())
                                {
                                    if (rowCount < maxErrorRowsToDisplay)
                                    {
                                        rowCount++;

                                        //collect the values from dimensions
                                        foreach (var key in ordinalDiction.Keys)
                                        {
                                            factResultsDiction[key].Add(Convert.ToString(reader.GetValue(ordinalDiction[key])));
                                        }
                                    }
                                }
                                reader.Close();

                                List<ColumnData> factResultsData = new List<ColumnData>();
                                var factColumns = new List<string>();
                                foreach (var key in factResultsDiction.Keys)
                                {
                                    //factData.Columns.Add(key);
                                    factColumns.Add(key);
                                    var col = new ColumnData() { Values = factResultsDiction[key].ToArray() };
                                    factResultsData.Add(col);
                                }
                                stagedDataResults.ResponseTableColumns = factColumns.ToArray();
                                stagedDataResults.ResponseTableData = factResultsData.ToArray();
                                //factData.Columns = factColumns.ToArray();
                                //factData.Data = factResultsData.ToArray();
                            }
                        }

                        //set response
                        if (status == FactTableKnownValues.StageProcessingStatus.CriticalValidationsFailed)
                        {
                            stagedDataResults.MessageType = FactTableKnownValues.ResponseMsgType.Error;
                            stagedDataResults.Message = "Issues detected with input file, please refer to the messages in the grid for additional details. The file must be resubmitted.";
                        }
                        else if (status == FactTableKnownValues.StageProcessingStatus.AdditionOfKeysRequired)
                        {
                            stagedDataResults.MessageType = FactTableKnownValues.ResponseMsgType.Error;
                            stagedDataResults.Message = "Key combinations missing for following items (Clicking the next button will add the keys and update the fact table)";
                        }
                    }
                    catch { throw; }
                    finally
                    {
                        oraConn.Close();
                    }
                }
            }
            else if (status == FactTableKnownValues.StageProcessingStatus.CriticalValidationsSuccess)
            {
                stagedDataResults.MessageType = FactTableKnownValues.ResponseMsgType.Success;
                stagedDataResults.Message = "Verification is successful";
            }
            else if (status == FactTableKnownValues.StageProcessingStatus.LoadedToFact || status == FactTableKnownValues.StageProcessingStatus.TransactionLevelWarning)
            {
                List<string> sqlFieldNamesWOPAmt = new List<string>();
                List<string> sqlFieldNamesBaseSelClause = new List<string>();
                string query = string.Empty;

                if (factFileType.Contains13ColFacts)
                {
                    var knownColumns13M = FactTableKnownValues.GetFactKnownColumns(true);
                    var knownColumns = FactTableKnownValues.GetFactKnownColumns(false);
                    //while fetching data from stage tables use displayFieldNames
                    sqlFieldNamesWOPAmt = factFieldNames;
                    sqlFieldNamesWOPAmt.Remove("line_number");
                    sqlFieldNamesWOPAmt.Remove(knownColumns13M[0].Name); //fiscal_period
                    sqlFieldNamesWOPAmt.Remove("amount");

                    sqlFieldNamesBaseSelClause = factFieldNames;

                    //remove line_number, fiscal_year, begbal, jan...dec and amount
                    sqlFieldNamesBaseSelClause.Remove("line_number");
                    foreach (var c in knownColumns13M)
                    {
                        sqlFieldNamesBaseSelClause.Remove(c.Name);
                    }
                    sqlFieldNamesBaseSelClause.Remove("amount");

                    query = string.Format("with base_data as ( select {0} " +
                    " , a.detailed_source, a.owner, a.run_status_id " +
                    " , substr(a.{3}, 0, 4) year, substr(a.{3}, 5, 2) month " +
                    " , a.amount, count(*) over () total_records " +
                    " from {1} a where a.run_status_id = :i_run_status_id) " +
                    " select {2}, detailed_source, owner, run_status_id, year, begbal, jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, dec " +
                    " from ( select * from base_data " +
                    " pivot ( sum(amount)for month in (" +
                    "'00' as begbal, '01' as jan, '02' as feb, '03' as mar, '04' as apr, '05' as may, '06' as jun " +
                    ", '07' as jul, '08' as aug, '09' as sep, '10' as oct, '11' as nov, '12' as dec) ))"
                    , GetPrefixedColumns(sqlFieldNamesBaseSelClause, "a.")
                    , factTable.PhysicalTable
                    , GetPrefixedColumns(sqlFieldNamesWOPAmt, "")
                    , knownColumns[0].Name);
                }
                else
                {
                    //while fetching data from stage tables use displayFieldNames
                    //displayFieldNames.Remove("line_number");
                    query = string.Format("select {0}, a.detailed_source, a.owner, a.run_status_id from {1} a where a.run_status_id = :i_run_status_id"
                        //, GetPrefixedColumns(displayFieldNames, "a.")
                    , GetPrefixedColumns(factFieldNames, "a.")
                    , factTable.PhysicalTable);
                }


                var profileConnectionString = GetConnectionStringFromProfileName(factTable.RepoProfile);
                using (OracleConnection oraConn = new OracleConnection(profileConnectionString))
                using (OracleCommand oraProcessStageToFactCmd = new OracleCommand())
                {
                    oraConn.Open();
                    try
                    {
                        oraProcessStageToFactCmd.Connection = oraConn;
                        oraProcessStageToFactCmd.Parameters.Clear();
                        oraProcessStageToFactCmd.CommandType = CommandType.Text;

                        //var stageTableName = (factFileType.Contains13ColFacts || factFileType.IsOutlook ? factTable.YearlyUploadStageName : factTable.MonthlyUploadStageName);
                        oraProcessStageToFactCmd.CommandText = query;

                        oraProcessStageToFactCmd.Parameters.Add(new OracleParameter("i_run_status_id", OracleDbType.Int32, runStatusId, ParameterDirection.Input));

                        using (OracleDataReader reader = oraProcessStageToFactCmd.ExecuteReader())
                        {

                            Dictionary<string, List<string>> factResultsDiction = new Dictionary<string, List<string>>();
                            Dictionary<string, int> ordinalDiction = new Dictionary<string, int>();

                            //foreach (var colName in sqlFieldNames)
                            foreach (var colName in factFieldNames)
                            {
                                factResultsDiction.Add(colName, new List<string>());
                                ordinalDiction.Add(colName, reader.GetOrdinal(colName));
                            }

                            factResultsDiction.Add("detailed_source", new List<string>());
                            ordinalDiction.Add("detailed_source", reader.GetOrdinal("detailed_source"));
                            factResultsDiction.Add("owner", new List<string>());
                            ordinalDiction.Add("owner", reader.GetOrdinal("owner"));
                            factResultsDiction.Add("run_status_id", new List<string>());
                            ordinalDiction.Add("run_status_id", reader.GetOrdinal("run_status_id"));

                            reader.FetchSize = oraProcessStageToFactCmd.RowSize * 1500;
                            if (reader.HasRows)
                            {
                                int rowCount = 0;
                                while (reader.Read())
                                {
                                    if (rowCount < maxErrorRowsToDisplay)
                                    {
                                        rowCount++;

                                        //collect the values from dimensions
                                        foreach (var key in ordinalDiction.Keys)
                                        {
                                            factResultsDiction[key].Add(Convert.ToString(reader.GetValue(ordinalDiction[key])));
                                        }
                                    }
                                }
                                reader.Close();

                                List<ColumnData> factResultsData = new List<ColumnData>();
                                var factColumns = new List<string>();
                                foreach (var key in factResultsDiction.Keys)
                                {
                                    factColumns.Add(key);
                                    var col = new ColumnData() { Values = factResultsDiction[key].ToArray() };
                                    factResultsData.Add(col);
                                }
                                factData.Columns = factColumns.ToArray();
                                factData.Data = factResultsData.ToArray();
                            }
                        }
                        //set response
                        stagedDataResults.MessageType = FactTableKnownValues.ResponseMsgType.Success;
                        stagedDataResults.Message = string.Format("{0} item(s) were added or modified.", rowsMergeCount);
                        stagedDataResults.ResponseTableColumns = factData.Columns;
                        stagedDataResults.ResponseTableData = factData.Data;
                    }
                    catch { throw; }
                    finally
                    {
                        oraConn.Close();
                    }
                }
            }
            return stagedDataResults;
        }

        private List<TransactionLevelMessage> GatherTransactionLevelMessages(string userId, long runStatusId)
        {
            List<TransactionLevelMessage> messagesList = new List<TransactionLevelMessage>();

            List<string> errorMessages = new List<string>();
            List<string> warningMessages = new List<string>();

            List<ValidationTracking> validationTrackingList = FetchValidationMessages(userId, runStatusId, new FactTableKnownValues.StageProcessingStatus[] { FactTableKnownValues.StageProcessingStatus.TransactionLevelError, FactTableKnownValues.StageProcessingStatus.TransactionLevelWarning });

            foreach (var vt in validationTrackingList)
            {
                if (vt.MessageLevel == (int)FactTableKnownValues.StageProcessingStatus.TransactionLevelWarning
                    && warningMessages.FirstOrDefault(m => m == vt.Message) == null)
                {
                    warningMessages.Add(vt.Message);
                }

                if (vt.MessageLevel == (int)FactTableKnownValues.StageProcessingStatus.TransactionLevelError
                    && errorMessages.FirstOrDefault(m => m == vt.Message) == null)
                {
                    errorMessages.Add(vt.Message);
                }
            }

            if (warningMessages.Count > 0)
            {
                var warningTLM = new TransactionLevelMessage() { MessageType = FactTableKnownValues.StageProcessingStatus.TransactionLevelWarning };
                warningTLM.Messages = warningMessages.ToArray();
                messagesList.Add(warningTLM);
            }
            if (errorMessages.Count > 0)
            {
                var errorTLM = new TransactionLevelMessage() { MessageType = FactTableKnownValues.StageProcessingStatus.TransactionLevelError };
                errorTLM.Messages = errorMessages.ToArray();
                messagesList.Add(errorTLM);
            }

            return messagesList;
        }

        private List<ValidationTracking> FetchValidationMessages(string userId, long runStatusId, FactTableKnownValues.StageProcessingStatus[] messageTypes)
        {
            List<ValidationTracking> validationTrackingList = new List<ValidationTracking>();

            List<int> messageTypeList = new List<int>();
            foreach (FactTableKnownValues.StageProcessingStatus s in messageTypes)
            {
                messageTypeList.Add(Convert.ToInt32(s));
            }

            string messageTypesCombined = string.Join(",", messageTypeList.ToArray());

            using (OracleConnection oraConn = new OracleConnection(this.ConnectionString))
            using (OracleCommand oraCommand = new OracleCommand())
            {
                oraConn.Open();

                OracleCommand userInfoUpdateCmd = new OracleCommand("MDMFRAMEWORK.get_web_validations", oraConn);
                //userInfoUpdateCmd.BindByName = true;
                userInfoUpdateCmd.CommandType = CommandType.StoredProcedure;
                userInfoUpdateCmd.Parameters.Add(new OracleParameter("i_user_id", OracleDbType.Varchar2)).Value = userId;
                userInfoUpdateCmd.Parameters.Add(new OracleParameter("i_run_status_id", OracleDbType.Long)).Value = runStatusId;
                userInfoUpdateCmd.Parameters.Add(new OracleParameter("i_message_types", OracleDbType.Varchar2)).Value = messageTypesCombined;
                userInfoUpdateCmd.Parameters.Add(new OracleParameter("o_result_cur", OracleDbType.RefCursor, ParameterDirection.Output));

                try
                {
                    using (var dataReader = userInfoUpdateCmd.ExecuteReader())
                    {
                        if (dataReader.HasRows == true)
                        {
                            int runStatusIdOrdinal = dataReader.GetOrdinal("run_status_id");
                            int lineNumberOrdinal = dataReader.GetOrdinal("line_number");
                            int messageLevelOrdinal = dataReader.GetOrdinal("message_level");
                            int messageOrdinal = dataReader.GetOrdinal("message");



                            while (dataReader.Read())
                            {
                                var validationTracking = new ValidationTracking()
                                {
                                    RunStatusId = (dataReader.IsDBNull(runStatusIdOrdinal) ? 0 : dataReader.GetInt64(runStatusIdOrdinal)),
                                    LineNumber = (dataReader.IsDBNull(lineNumberOrdinal) ? 0 : dataReader.GetInt64(lineNumberOrdinal)),
                                    MessageLevel = (dataReader.IsDBNull(messageLevelOrdinal) ? 0 : dataReader.GetInt32(messageLevelOrdinal)),
                                    Message = (dataReader.IsDBNull(messageOrdinal) ? string.Empty : dataReader.GetString(messageOrdinal))
                                };

                                validationTrackingList.Add(validationTracking);
                            }
                        }
                        dataReader.Close();
                    }
                }
                catch (Exception ex)
                {
                    throw;
                }
                finally
                {
                    oraConn.Close();
                }

            }


            return validationTrackingList;
        }

        private Contracts.Data.MDUA.FactTables.FactProcessUploadedFileResponse ProcessStagedKeyDataCore(Contracts.Data.MDUA.FactTables.FactProcessUploadedFileRequest request, FactTable factTable, FactFileType factFileType, TableInfo factData)
        {

            List<string> sqlFieldNames = new List<string>();
            sqlFieldNames.AddRange(factData.Columns);

            //Return Value
            FactProcessUploadedFileResponse response = new FactProcessUploadedFileResponse();
            string fiscalPeriod = (request.ReportingPeriod.Month > 9 ? string.Format("{0}{1}", request.ReportingPeriod.Year, request.ReportingPeriod.Month) : string.Format("{0}0{1}", request.ReportingPeriod.Year, request.ReportingPeriod.Month));

            //get connection string
            var profileConnectionString = GetConnectionStringFromProfileName(factTable.RepoProfile);
            using (OracleConnection oraConn = new OracleConnection(profileConnectionString))
            using (OracleCommand oraProcessStageToFactCmd = new OracleCommand())
            {
                oraConn.Open();
                try
                {
                    //Run sproc
                    oraProcessStageToFactCmd.Connection = oraConn;
                    oraProcessStageToFactCmd.CommandType = CommandType.StoredProcedure;
                    oraProcessStageToFactCmd.CommandText = string.Format("{0}.process_staged_key_data", factTable.ValidationProc);
                    oraProcessStageToFactCmd.BindByName = true;

                    oraProcessStageToFactCmd.Parameters.Add(new OracleParameter("i_run_status_id", OracleDbType.Int32, request.RunStatusId, ParameterDirection.Input));
                    oraProcessStageToFactCmd.Parameters.Add(new OracleParameter("i_user_id", OracleDbType.Varchar2, request.UserId, ParameterDirection.Input));
                    oraProcessStageToFactCmd.Parameters.Add(new OracleParameter("i_file_Type_Id", OracleDbType.Long, factFileType.FileTypeCodeId, ParameterDirection.Input));
                    oraProcessStageToFactCmd.Parameters.Add(new OracleParameter("i_fiscal_period", OracleDbType.Varchar2, fiscalPeriod, ParameterDirection.Input));
                    oraProcessStageToFactCmd.Parameters.Add(new OracleParameter("status", OracleDbType.Int32, ParameterDirection.Output));
                    oraProcessStageToFactCmd.Parameters.Add(new OracleParameter("rows", OracleDbType.Int32, ParameterDirection.Output));

                    oraProcessStageToFactCmd.ExecuteNonQuery();

                    int procedureStatus = Convert.ToInt32(oraProcessStageToFactCmd.Parameters["status"].Value.ToString());
                    int rows = Convert.ToInt32(oraProcessStageToFactCmd.Parameters["rows"].Value.ToString());
                    FactTableKnownValues.StageProcessingStatus status = (FactTableKnownValues.StageProcessingStatus)procedureStatus;

                    //check sproc return values
                    response = ProcessStagedKeyDataResults(request.RunStatusId, status, factTable, factFileType, sqlFieldNames);
                    response.StageProcessStatus = status;

                    opsLogManager.LogEvent(request.UserId, "ProcessStagedKeyDataCore", "ProcessStagedKeyData", string.Format("Run Status Id {0}; Status - {1}", request.RunStatusId, status), Contracts.Data.MDUA.UserToolLogLevel.Audit);
                    //response.ResponseTableData = statusResult.Data;
                    //response.ResponseTableColumns = statusResult.Columns;
                }
                catch
                {
                    throw;
                }
                finally
                {
                    oraConn.Close();
                }
            }
            return response;
        }

        private FactProcessUploadedFileResponse ProcessStagedKeyDataResults(long runStatusId, FactTableKnownValues.StageProcessingStatus status, FactTable factTable, FactFileType factFileType, List<string> sqlFieldNames)
        {
            //Return Value
            FactProcessUploadedFileResponse stagedKeyDataResults = new FactProcessUploadedFileResponse()
            {
                RunStatusId = runStatusId
            };

            //TableInfo factData = new TableInfo();

            int rowsSkipped = 0;

            var stageTableName = (factFileType.Contains13ColFacts ? factTable.YearlyUploadStageName : factTable.MonthlyUploadStageName);


            if (status == FactTableKnownValues.StageProcessingStatus.CriticalValidationsFailed)
            {
                var profileConnectionString = GetConnectionStringFromProfileName(factTable.RepoProfile);
                using (OracleConnection oraConn = new OracleConnection(profileConnectionString))
                using (OracleCommand oraProcessStageToFactCmd = new OracleCommand())
                {
                    oraConn.Open();
                    try
                    {
                        oraProcessStageToFactCmd.Connection = oraConn;
                        oraProcessStageToFactCmd.Parameters.Clear();
                        oraProcessStageToFactCmd.CommandType = CommandType.Text;

                        oraProcessStageToFactCmd.CommandText = string.Format("select b.message, {0}, a.source, a.owner, a.run_status_id " +
                                " from {1} a, web_validation_tracking b where a.run_status_id = b.run_status_id and a.line_number = b.line_number " +
                                " and a.run_status_id = :i_run_status_id order by line_number", GetPrefixedColumns(sqlFieldNames, "a."), stageTableName);

                        oraProcessStageToFactCmd.Parameters.Add(new OracleParameter("i_run_status_id", OracleDbType.Int32, runStatusId, ParameterDirection.Input));

                        using (OracleDataReader reader = oraProcessStageToFactCmd.ExecuteReader())
                        {

                            Dictionary<string, List<string>> factResultsDiction = new Dictionary<string, List<string>>();
                            Dictionary<string, int> ordinalDiction = new Dictionary<string, int>();
                            //factResultsDiction.Add("line_number", new List<string>());
                            //ordinalDiction.Add("line_number", reader.GetOrdinal("line_number"));
                            factResultsDiction.Add("message", new List<string>());
                            ordinalDiction.Add("message", reader.GetOrdinal("message"));

                            foreach (var colName in sqlFieldNames)
                            {
                                factResultsDiction.Add(colName, new List<string>());
                                ordinalDiction.Add(colName, reader.GetOrdinal(colName));
                            }

                            factResultsDiction.Add("source", new List<string>());
                            ordinalDiction.Add("source", reader.GetOrdinal("source"));
                            factResultsDiction.Add("owner", new List<string>());
                            ordinalDiction.Add("owner", reader.GetOrdinal("owner"));
                            factResultsDiction.Add("run_status_id", new List<string>());
                            ordinalDiction.Add("run_status_id", reader.GetOrdinal("run_status_id"));

                            reader.FetchSize = oraProcessStageToFactCmd.RowSize * 1500;
                            if (reader.HasRows)
                            {
                                int rowCount = 0;
                                while (reader.Read())
                                {
                                    if (rowCount < maxErrorRowsToDisplay)
                                    {
                                        rowCount++;

                                        //collect the values from dimensions
                                        foreach (var key in ordinalDiction.Keys)
                                        {
                                            factResultsDiction[key].Add(Convert.ToString(reader.GetValue(ordinalDiction[key])));
                                        }
                                    }
                                    else
                                    {
                                        rowsSkipped++;
                                    }
                                }
                                reader.Close();

                                List<ColumnData> factResultsData = new List<ColumnData>();
                                var factColumns = new List<string>();
                                foreach (var key in factResultsDiction.Keys)
                                {
                                    factColumns.Add(key);
                                    //factData.Columns.Add(key);
                                    var col = new ColumnData() { Values = factResultsDiction[key].ToArray() };
                                    factResultsData.Add(col);
                                }

                                stagedKeyDataResults.ResponseTableData = factResultsData.ToArray();
                                stagedKeyDataResults.ResponseTableColumns = factColumns.ToArray();
                                stagedKeyDataResults.MessageType = FactTableKnownValues.ResponseMsgType.Error;

                                string skippedRowsMessage = (rowsSkipped > 0) ? string.Format("The first few rows are displayed, {0} rows were skipped.", rowsSkipped) : string.Empty;
                                stagedKeyDataResults.Message = string.Format("Issues detected with input file, please refer to the messages in the grid for additional details. {0}", skippedRowsMessage);
                                //factData.Data = factResultsData.ToArray();
                                //factData.Columns = factColumns.ToArray();
                            }
                        }
                    }
                    catch { throw; }
                    finally
                    {
                        oraConn.Close();
                    }
                }
            }
            else
            {
                string loadToFactQueryFmt = string.Format("select {0}, a.source, a.owner, a.run_status_id from {1} a where a.run_status_id = :i_run_status_id " +
                    " and line_number in ( select line_number from web_validation_tracking where run_status_id = :i_run_status_id ) " +
                    " order by line_number "
                    , GetPrefixedColumns(sqlFieldNames, "a.")
                    , stageTableName);

                var profileConnectionString = GetConnectionStringFromProfileName(factTable.RepoProfile);
                using (OracleConnection oraConn = new OracleConnection(profileConnectionString))
                using (OracleCommand oraProcessStageToFactCmd = new OracleCommand())
                {
                    oraConn.Open();
                    try
                    {
                        oraProcessStageToFactCmd.Connection = oraConn;
                        oraProcessStageToFactCmd.Parameters.Clear();
                        oraProcessStageToFactCmd.CommandType = CommandType.Text;

                        oraProcessStageToFactCmd.CommandText = loadToFactQueryFmt;

                        oraProcessStageToFactCmd.Parameters.Add(new OracleParameter("i_run_status_id", OracleDbType.Int32, runStatusId, ParameterDirection.Input));

                        using (OracleDataReader reader = oraProcessStageToFactCmd.ExecuteReader())
                        {

                            Dictionary<string, List<string>> factResultsDiction = new Dictionary<string, List<string>>();
                            Dictionary<string, int> ordinalDiction = new Dictionary<string, int>();

                            //factResultsDiction.Add("line_number", new List<string>());
                            //ordinalDiction.Add("line_number", reader.GetOrdinal("line_number"));

                            foreach (var colName in sqlFieldNames)
                            {
                                factResultsDiction.Add(colName, new List<string>());
                                ordinalDiction.Add(colName, reader.GetOrdinal(colName));
                            }

                            factResultsDiction.Add("source", new List<string>());
                            ordinalDiction.Add("source", reader.GetOrdinal("source"));
                            factResultsDiction.Add("owner", new List<string>());
                            ordinalDiction.Add("owner", reader.GetOrdinal("owner"));
                            factResultsDiction.Add("run_status_id", new List<string>());
                            ordinalDiction.Add("run_status_id", reader.GetOrdinal("run_status_id"));

                            reader.FetchSize = oraProcessStageToFactCmd.RowSize * 1500;
                            if (reader.HasRows)
                            {
                                int rowCount = 0;
                                while (reader.Read())
                                {
                                    if (rowCount < maxErrorRowsToDisplay)
                                    {
                                        rowCount++;

                                        //collect the values from dimensions
                                        foreach (var key in ordinalDiction.Keys)
                                        {
                                            factResultsDiction[key].Add(Convert.ToString(reader.GetValue(ordinalDiction[key])));
                                        }
                                    }
                                    else
                                    {
                                        rowsSkipped++;
                                    }
                                }
                                reader.Close();

                                List<ColumnData> factResultsData = new List<ColumnData>();
                                var factColumns = new List<string>();
                                foreach (var key in factResultsDiction.Keys)
                                {
                                    factColumns.Add(key);
                                    var col = new ColumnData() { Values = factResultsDiction[key].ToArray() };
                                    factResultsData.Add(col);
                                }
                                //factData.Data = factResultsData.ToArray();
                                //factData.Columns = factColumns.ToArray();
                                stagedKeyDataResults.ResponseTableData = factResultsData.ToArray();
                                stagedKeyDataResults.ResponseTableColumns = factColumns.ToArray();
                                if (stagedKeyDataResults.ResponseTableColumns.Length > 0)
                                {
                                    stagedKeyDataResults.MessageType = FactTableKnownValues.ResponseMsgType.Success;
                                    string skippedRowsMessage = (rowsSkipped > 0) ? string.Format("The first {0} rows are displayed, {1} rows were skipped. For a complete list of loaded keys, select the Download button.", stagedKeyDataResults.ResponseTableData[0].Values.Length, rowsSkipped) : string.Empty;
                                    stagedKeyDataResults.Message = string.Format("The following {0} key combination(s) will be added to the validation table.  Click Continue to proceed. {1}", stagedKeyDataResults.ResponseTableData[0].Values.Length, skippedRowsMessage);
                                }
                            }
                            else
                            {
                                stagedKeyDataResults.MessageType = FactTableKnownValues.ResponseMsgType.Success;
                                stagedKeyDataResults.Message = "All key combinations from file already exist in the validation table";
                            }
                        }
                    }
                    catch { throw; }
                    finally
                    {
                        oraConn.Close();
                    }
                }
            }
            return stagedKeyDataResults;
        }

        private FactProcessUploadedFileResponse AddKeysFromStagedDataCore(FactTable factTable, FactFileType factFileType, long runStatusId)
        {
            //return value
            FactProcessUploadedFileResponse response = new FactProcessUploadedFileResponse();

            //get connection string
            var profileConnectionString = GetConnectionStringFromProfileName(factTable.RepoProfile);
            using (OracleConnection oraConn = new OracleConnection(profileConnectionString))
            using (OracleCommand oraProcessStageToFactCmd = new OracleCommand())
            {
                oraConn.Open();
                try
                {
                    //Run sproc
                    oraProcessStageToFactCmd.Connection = oraConn;
                    oraProcessStageToFactCmd.CommandType = CommandType.StoredProcedure;
                    oraProcessStageToFactCmd.CommandText = string.Format("{0}.add_keys_from_stage", factTable.ValidationProc);
                    oraProcessStageToFactCmd.BindByName = true;

                    oraProcessStageToFactCmd.Parameters.Add(new OracleParameter("i_run_status_id", OracleDbType.Int32, runStatusId, ParameterDirection.Input));
                    oraProcessStageToFactCmd.Parameters.Add(new OracleParameter("i_file_Type_Id", OracleDbType.Long, factFileType.FileTypeCodeId, ParameterDirection.Input));
                    oraProcessStageToFactCmd.Parameters.Add(new OracleParameter("status", OracleDbType.Varchar2, ParameterDirection.Output));
                    oraProcessStageToFactCmd.Parameters["status"].Size = 30;
                    oraProcessStageToFactCmd.Parameters.Add(new OracleParameter("rows", OracleDbType.Int32, ParameterDirection.Output));

                    oraProcessStageToFactCmd.ExecuteNonQuery();

                    string procedureStatus = oraProcessStageToFactCmd.Parameters["status"].Value.ToString();
                    response.RowsAffected = Convert.ToInt32(oraProcessStageToFactCmd.Parameters["rows"].Value.ToString());

                    if (procedureStatus == "Y")
                    {
                        response.MessageType = FactTableKnownValues.ResponseMsgType.Success;
                        response.Message = string.Format("Successfully added {0} key combinations", response.RowsAffected);
                        opsLogManager.LogEvent(string.Empty, "AddKeysFromStagedDataCore", "Add Keys", string.Format("Run Status Id - {0}; Status - {1}", runStatusId, procedureStatus), Contracts.Data.MDUA.UserToolLogLevel.Audit);
                    }
                    else
                    {
                        response.MessageType = FactTableKnownValues.ResponseMsgType.Error;
                        response.Message = "Error occured upon adding key combinations";
                    }
                }
                catch
                {
                    response.MessageType = FactTableKnownValues.ResponseMsgType.Fatal;
                    response.Message = "Unknown error occurred.";
                    throw;
                }
                finally
                {
                    oraConn.Close();
                }
            }
            return response;
        }

        private FactProcessUploadedFileResponse ProcessMissingKeysAndStagedDataCore(FactProcessUploadedFileRequest request, FactTable factTable, FactFileType factFileType, TableInfo factData)
        {
            var sqlFieldNames = new List<string>(factData.Columns);
            var displayFieldNames = new List<string>(factData.ColumnHeaders);
            var factFieldNames = new List<string>(factTable.AvailableDimensions.Select(d => d.FactColumnName));

            if (request.UploadProcessType == FactTableKnownValues.FactUploadProcessType.FactData)
            {
                var knownColumns = FactTableKnownValues.GetFactKnownColumns(factFileType.Contains13ColFacts || factFileType.IsOutlook);
                factFieldNames.AddRange(knownColumns.Select(x => x.Name));
            }

            //Return Value
            FactProcessUploadedFileResponse response = new FactProcessUploadedFileResponse();

            FactTableKnownValues.StageProcessingStatus sprocStatus = FactTableKnownValues.StageProcessingStatus.None;
            int rowsMergeCount = 0;

            //get connection string
            var profileConnectionString = GetConnectionStringFromProfileName(factTable.RepoProfile);
            using (OracleConnection oraConn = new OracleConnection(profileConnectionString))
            using (OracleCommand oraProcessStageToFactCmd = new OracleCommand())
            {
                oraConn.Open();
                try
                {

                    oraProcessStageToFactCmd.Connection = oraConn;
                    oraProcessStageToFactCmd.Parameters.Clear();
                    oraProcessStageToFactCmd.CommandType = CommandType.StoredProcedure;
                    oraProcessStageToFactCmd.CommandText = string.Format("{0}.add_keys_and_load_to_fact", factTable.ValidationProc);
                    oraProcessStageToFactCmd.BindByName = true;

                    oraProcessStageToFactCmd.Parameters.Add(new OracleParameter("i_run_status_id", OracleDbType.Int32, request.RunStatusId, ParameterDirection.Input));
                    oraProcessStageToFactCmd.Parameters.Add(new OracleParameter("i_user_id", OracleDbType.Varchar2, request.UserId, ParameterDirection.Input));
                    oraProcessStageToFactCmd.Parameters.Add(new OracleParameter("i_file_Type_Id", OracleDbType.Long, factFileType.FileTypeCodeId, ParameterDirection.Input));
                    oraProcessStageToFactCmd.Parameters.Add(new OracleParameter("status", OracleDbType.Int32, ParameterDirection.Output));
                    oraProcessStageToFactCmd.Parameters.Add(new OracleParameter("rows", OracleDbType.Int32, ParameterDirection.Output));

                    oraProcessStageToFactCmd.ExecuteNonQuery();

                    int procedureStatus = Convert.ToInt32(oraProcessStageToFactCmd.Parameters["status"].Value.ToString());
                    rowsMergeCount = Convert.ToInt32(oraProcessStageToFactCmd.Parameters["rows"].Value.ToString());
                    sprocStatus = (FactTableKnownValues.StageProcessingStatus)procedureStatus;

                    opsLogManager.LogEvent(request.UserId, "ProcessMissingKeysAndStagedDataCore", "MissingKeysAndStagedData", string.Format("Run Status Id {0}; Status - {1}", request.RunStatusId, sprocStatus), Contracts.Data.MDUA.UserToolLogLevel.Audit);

                }
                catch { throw; }
                finally
                {
                    oraConn.Close();
                }
            }

            //check sproc return values
            response = ProcessStagedDataResults(request.RunStatusId, sprocStatus, factTable, factFileType, displayFieldNames, sqlFieldNames, rowsMergeCount, factFieldNames);
            response.StageProcessStatus = sprocStatus;
            return response;
        }

        protected override string OnUploadFactFile(string userId, string fileTypeName, string base64EncodedFile)
        {
            throw new NotImplementedException();
        }

        protected override Contracts.Data.MDUA.FactTables.FactProcessUploadedFileResponse OnStageExcelContents(FactProcessUploadedFileRequest request, FactTable factTable, FactFileType factFileType, TableInfo factData)
        {
            return StageExcelContentsCore(request, factTable, factFileType, factData);
        }

        protected override Contracts.Data.MDUA.FactTables.FactProcessUploadedFileResponse OnProcessStagedData(Contracts.Data.MDUA.FactTables.FactProcessUploadedFileRequest request, FactTable factTable, FactFileType factFileType, TableInfo factData)
        {
            if (request.UploadProcessType == FactTableKnownValues.FactUploadProcessType.FactData)
            {
                return ProcessStagedDataCore(request, factTable, factFileType, factData);
            }
            else if (request.UploadProcessType == FactTableKnownValues.FactUploadProcessType.KeyCombo)
            {
                return ProcessStagedKeyDataCore(request, factTable, factFileType, factData);
            }
            else
            {
                throw new InvalidOperationException("Unknown FactUploadProcessType");
            }
        }

        protected override FactProcessUploadedFileResponse OnProcessMissingKeysAndStagedData(FactProcessUploadedFileRequest request, FactTable factTable, FactFileType factFileType, TableInfo factData)
        {
            return ProcessMissingKeysAndStagedDataCore(request, factTable, factFileType, factData);
        }

        protected override Contracts.Data.MDUA.FactTables.FactProcessUploadedFileResponse OnUploadFactData(Contracts.Data.MDUA.FactTables.FactProcessUploadedFileRequest processRequest)
        {
            throw new NotImplementedException();
        }

        protected override string[] OnGetDimYears()
        {
            string queryGetDimYears = "select alias from web_dimensions_tbl where dim_type='YEARS' and not alias is null Order by alias";

            List<string> dimYearList = new List<string>();

            using (OracleConnection conn = new OracleConnection(this.ConnectionString))
            using (OracleCommand cmd = new OracleCommand(queryGetDimYears, conn))
            {
                conn.Open();
                try
                {
                    using (OracleDataReader dataReader = cmd.ExecuteReader())
                    {
                        int aliasCol = dataReader.GetOrdinal("alias");

                        while (dataReader.Read())
                        {
                            dimYearList.Add(dataReader.GetString(aliasCol));
                        }
                        dataReader.Close();
                    }
                }
                catch (Exception e)
                {
                    throw;
                }
                finally
                {
                    conn.Close();
                }
            }

            return dimYearList.ToArray();
        }

        protected override FactProcessUploadedFileResponse OnAddKeysFromStagedData(string userId, long runStatusId, long factTableId, long factFileTypeId)
        {
            var factTable = factTableManager.GetFactTable(userId, factTableId);
            FileTypeRequest ftr = new FileTypeRequest() { FactTableId = factTableId, FileTypeCodeId = factFileTypeId };
            var factFileType = factTableManager.GetFactFileType(userId, ftr);

            if (factTable == null || factFileType == null)
            {
                throw new ArgumentException("factTable or factFileType does not exists");
            }

            return AddKeysFromStagedDataCore(factTable, factFileType, runStatusId);

        }

        protected override string OnUploadFactFileByte(string userId, string fileTypeName, byte[] fileInBytes)
        {
            throw new NotImplementedException();
        }

        private class ValidationTracking
        {
            public long RunStatusId { get; set; }
            public long LineNumber { get; set; }
            public int MessageLevel { get; set; }
            public string Message { get; set; }
        }
    }



}
