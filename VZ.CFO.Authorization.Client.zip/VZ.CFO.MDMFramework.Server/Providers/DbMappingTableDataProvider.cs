﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Data.MappingTableMgmt;
using VZ.CFO.MDMFramework.Providers;
using VZ.CFO.MDMFramework.Server.SqlHelper;
using Oracle.ManagedDataAccess.Client;
namespace VZ.CFO.MDMFramework.Server.Providers
{
    public class DbMappingTableDataProvider : MappingTableDataProvider
    {
        private readonly IOracleHelper oracleHelper;
        private readonly Contracts.Data.Config.DbProfile[] dbProfileList;
        private string resolvedConnectionString = string.Empty;
        private string portalSchemaPrefix = string.Empty;


        private readonly string uniqueRowName = "urowid";

        public DbMappingTableDataProvider(string connectionString, string encryptionSalt, Contracts.Data.Config.DbProfile[] dbProfileList, string portalSchemaPrefix)
            : base(connectionString, encryptionSalt)
        {
            oracleHelper = new OracleHelper();
            this.dbProfileList = dbProfileList;
            this.portalSchemaPrefix = portalSchemaPrefix;
        }

        public DbMappingTableDataProvider(string connectionString, string encryptionSalt, Contracts.Data.Config.DbProfile[] dbProfileList, IOracleHelper oracleHelper, string portalSchemaPrefix)
            : base(connectionString, encryptionSalt)
        {
            this.oracleHelper = oracleHelper;
            this.dbProfileList = dbProfileList;
            this.portalSchemaPrefix = portalSchemaPrefix;
        }

        private enum MappingTableDataType
        {
            Save,
            Migrate
        }

        private MappingTable[] GetMappingTableInfoCore(string userId, long mappingTableId)
        {
            string mappingTableFilterQuery = (mappingTableId == 0 ? string.Empty : string.Format(" AND mtl.mapping_table_id = {0}", mappingTableId));

            string query = string.Format("WITH mapcore as ( " +
            " select mapping_table_id, mapping_table_name, employee_id, role from Mapping_Table_List mt, Web_Users where employee_id = '{0}' " +
            " group by mapping_table_id, mapping_table_name, employee_id, role ) " +
            " select mtl.mapping_table_id, mtl.mapping_table_name, mtl.objectname, mtl.Description, mtl.Repository, mtl.Migration_Repository, mtl.LOW_ENV_MT_SYNONYM, " +
            " mc.role, ua.access_type, v.validation_agent_id, v.agent_name, v.parameters, v.connection_parameters, v.agent_type, mtl.last_validated_on, mtl.last_validated_by, u.last_name as last_validated_by_ln, u.first_name as last_validated_by_fn, mtl.can_skip_validation " +
            " from mapcore mc " +
            " JOIN Mapping_Table_List mtl ON mc.mapping_table_id = mtl.mapping_table_id " +
            " LEFT JOIN user_access ua ON Ua.Accessobj_Type = 'MT' AND Ua.Accessobj_Id = mc.Mapping_Table_Id AND ua.employee_id = Mc.Employee_Id " +
            " LEFT JOIN validation_agent v ON v.validation_agent_id = mtl.validate_agent_id AND ACTIVE = 'Y' " +
            " LEFT JOIN web_users u ON u.employee_id = mtl.last_validated_by " +
            " WHERE ((Mc.Role = 9) OR (Mc.Role <> 9 AND ua.access_id is not null )) {1} " +
            " ORDER BY mc.mapping_table_id, ua.access_Type ", userId, mappingTableFilterQuery);

            string mappingTableColsQueryFmt = " select mtl.mapping_table_id, col_name from Mapping_Table_List mtl " +
            " JOIN Mapping_Table_Columns c ON mtl.Mapping_Table_Id = c.Mapping_Table_Id AND c.Active = 'Y' " +
            " WHERE mtl.mapping_table_id in ({0}) " +
            " ORDER BY mtl.mapping_table_id, col_order ";

            string migrationDepQueryFmt = " select mtl.mapping_table_id, MIGRATION_DEPENDENCY_TYPE, parameters, connection_parameters " +
            " from Mapping_Table_List mtl " +
            " JOIN Migration_Dependency d ON mtl.Mapping_Table_Id = d.Mapping_table_id " +
            " WHERE mtl.mapping_table_id in ({0}) " +
            " ORDER BY mtl.mapping_table_id ";

            Dictionary<long, List<KnownValues.RoleType>> roleTypeDiction = new Dictionary<long, List<KnownValues.RoleType>>();
            Dictionary<long, List<string>> columnsDiction = new Dictionary<long, List<string>>();
            Dictionary<long, List<MigrationDependency>> migrationDepDiction = new Dictionary<long, List<MigrationDependency>>();
            List<long> availableMappingTableIds = new List<long>();

            List<MappingTable> mappingTableList = new List<MappingTable>();
            //using (IDataReader dataReader = oracleHelper.ExecuteReader(this.ConnectionString, CommandType.Text, query))
            using (OracleConnection conn = new OracleConnection(this.ConnectionString))
            using (OracleCommand cmd = new OracleCommand(query, conn))
            {
                conn.Open();
                try
                {
                    using (OracleDataReader dataReader = cmd.ExecuteReader())
                    {
                        int idCol = dataReader.GetOrdinal("mapping_table_id");
                        int nameCol = dataReader.GetOrdinal("mapping_table_name");
                        int objnameCol = dataReader.GetOrdinal("objectname");
                        int descCol = dataReader.GetOrdinal("Description");
                        int repoCol = dataReader.GetOrdinal("Repository");
                        int migRepoCol = dataReader.GetOrdinal("Migration_Repository");
                        int roleCol = dataReader.GetOrdinal("role");
                        int accessTypeCol = dataReader.GetOrdinal("access_type");
                        int vaIdCol = dataReader.GetOrdinal("Validation_Agent_Id");
                        int agentNameCol = dataReader.GetOrdinal("Agent_name");
                        int agentParamCol = dataReader.GetOrdinal("parameters");
                        int agentConnCol = dataReader.GetOrdinal("connection_parameters");
                        int agentTypeCol = dataReader.GetOrdinal("agent_type");
                        int lowEnvSynCol = dataReader.GetOrdinal("LOW_ENV_MT_SYNONYM");
                        int validatedOnCol = dataReader.GetOrdinal("last_validated_on");
                        int validatedByCol = dataReader.GetOrdinal("last_validated_by");
                        int validatedByLNCol = dataReader.GetOrdinal("last_validated_by_ln");
                        int validatedByFNCol = dataReader.GetOrdinal("last_validated_by_fn");
                        int canSkipValiCol = dataReader.GetOrdinal("can_skip_validation");

                        while (dataReader.Read())
                        {
                            long mtId = dataReader.GetInt64(idCol);

                            MappingTable mappingTable = mappingTableList.FirstOrDefault(mt => mt.Id == mtId);

                            if (mappingTable == null)
                            {
                                mappingTable = new MappingTable();
                                mappingTable.Id = dataReader.GetInt64(idCol);
                                availableMappingTableIds.Add(mappingTable.Id);
                                mappingTable.Name = dataReader.GetString(nameCol);
                                mappingTable.PhysicalTable = dataReader.GetString(objnameCol);
                                mappingTable.MappingTableRepository = new Repository() { Name = dataReader.GetString(repoCol) };
                                if (dataReader.IsDBNull(migRepoCol) == false)
                                {
                                    mappingTable.MigrationTableRepository = new Repository() { Name = dataReader.GetString(migRepoCol) };
                                }
                                mappingTable.LowerEnvMapTableSynonym = (dataReader.IsDBNull(lowEnvSynCol) ? string.Empty : dataReader.GetString(lowEnvSynCol));
                                mappingTable.LastValidatedById = (dataReader.IsDBNull(validatedByCol) ? string.Empty : dataReader.GetString(validatedByCol));
                                mappingTable.LastValidatedOn = (dataReader.IsDBNull(validatedOnCol) ? string.Empty : dataReader.GetDateTime(validatedOnCol).ToString("0:MM/dd/yy H:mm:ss zzz"));
                                mappingTable.LastValidatedBy = (dataReader.IsDBNull(validatedByLNCol) ? string.Empty : dataReader.GetString(validatedByLNCol) + ", ") + (dataReader.IsDBNull(validatedByFNCol) ? string.Empty : dataReader.GetString(validatedByFNCol));
                                if(dataReader.IsDBNull(canSkipValiCol) || dataReader.GetString(canSkipValiCol) == "N")
                                {
                                    mappingTable.CanSkipValidation = false;
                                }
                                else
                                {
                                    mappingTable.CanSkipValidation = true;
                                }


                                //Get validation agent
                                if (dataReader.IsDBNull(agentNameCol) == false)
                                {
                                    var validationInfo = new ValidationInfo();
                                    validationInfo.Name = dataReader.GetString(agentNameCol);

                                    var validationTypeString = dataReader.GetString(agentTypeCol);

                                    KnownValues.MappingTableValidationType validationType ;
                                    Enum.TryParse(validationTypeString, out validationType);
                                    validationInfo.ValidationType = validationType;

                                    validationInfo.ValidationType = KnownValues.MappingTableValidationType.SPROC;
                                    List<string> validationParams = new List<string>();
                                    var agentConnVal = dataReader.IsDBNull(agentConnCol) ? string.Empty : dataReader.GetString(agentConnCol);
                                    var agentParamVal = dataReader.IsDBNull(agentParamCol) ? string.Empty : dataReader.GetString(agentParamCol);
                                    validationParams.Add(agentConnVal);
                                    validationParams.Add(agentParamVal);
                                    validationInfo.Parameters = validationParams.ToArray();
                                    mappingTable.Validation = new ValidationInfo[] { validationInfo };
                                }

                                //initialize new columns diction for every maptable
                                columnsDiction.Add(mappingTable.Id, new List<string>() { uniqueRowName });
                                roleTypeDiction.Add(mappingTable.Id, new List<KnownValues.RoleType>());
                                migrationDepDiction.Add(mappingTable.Id, new List<MigrationDependency>());
                                mappingTableList.Add(mappingTable);
                            }

                            //Get Role
                            int role = dataReader.GetInt32(roleCol);
                            if (dataReader.IsDBNull(accessTypeCol))
                            {
                                if (role == 3)
                                {
                                    roleTypeDiction[mappingTable.Id].Add(KnownValues.RoleType.None);
                                }
                            }
                            else
                            {
                                string roleTypeString = dataReader.GetString(accessTypeCol);
                                KnownValues.RoleType accessTypeVal = KnownValues.RoleType.None;
                                Enum.TryParse(roleTypeString, out accessTypeVal);
                                roleTypeDiction[mappingTable.Id].Add(accessTypeVal);
                            }
                        }

                        dataReader.Close();
                    }

                    if (availableMappingTableIds.Count > 0)
                    {
                        using (OracleCommand colCmd = new OracleCommand())
                        using (OracleCommand migdepCmd = new OracleCommand())
                        {
                            //Get Columns from each table
                            colCmd.Connection = conn;
                            colCmd.CommandType = CommandType.Text;
                            string colCmdQuery = string.Format(mappingTableColsQueryFmt, string.Join(",", availableMappingTableIds.ToArray()));
                            colCmd.CommandText = colCmdQuery;

                            using (OracleDataReader colDataReader = colCmd.ExecuteReader())
                            {
                                int idCol = colDataReader.GetOrdinal("mapping_table_id");
                                int mtColNameCol = colDataReader.GetOrdinal("col_name");

                                while (colDataReader.Read())
                                {
                                    long mtId = colDataReader.GetInt64(idCol);

                                    if (columnsDiction.ContainsKey(mtId))
                                    {
                                        columnsDiction[mtId].Add(colDataReader.GetString(mtColNameCol));
                                    }
                                }
                            }


                            //Get Migration Dependency
                            migdepCmd.Connection = conn;
                            migdepCmd.CommandType = CommandType.Text;
                            migdepCmd.CommandText = string.Format(migrationDepQueryFmt, string.Join(",", availableMappingTableIds.ToArray()));

                            using (OracleDataReader migDataReader = migdepCmd.ExecuteReader())
                            {
                                int idCol = migDataReader.GetOrdinal("mapping_table_id");
                                int migTypeCol = migDataReader.GetOrdinal("MIGRATION_DEPENDENCY_TYPE");
                                int paramsCol = migDataReader.GetOrdinal("parameters");
                                int connParamsCol = migDataReader.GetOrdinal("connection_parameters");

                                while (migDataReader.Read())
                                {
                                    long mtId = migDataReader.GetInt64(idCol);
                                    string paramVal = migDataReader.IsDBNull(paramsCol) ? string.Empty : migDataReader.GetString(paramsCol);
                                    string migTypeVal = migDataReader.GetString(migTypeCol);
                                    string connParamsVal = (migDataReader.IsDBNull(connParamsCol) ? string.Empty : migDataReader.GetString(connParamsCol));

                                    KnownValues.MigrationDependencyType migType = KnownValues.MigrationDependencyType.None;
                                    Enum.TryParse(migTypeVal, out migType);

                                    if (migrationDepDiction.ContainsKey(mtId))
                                    {
                                        migrationDepDiction[mtId].Add(new MigrationDependency() { Parameters = paramVal, ConnectionParameters = connParamsVal, Type = migType });
                                    }
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw;
                }
                finally
                {
                    conn.Close();
                }
            }

            foreach (var mt in mappingTableList)
            {
                if (columnsDiction.ContainsKey(mt.Id))
                {
                    mt.Columns = columnsDiction[mt.Id].ToArray();
                }

                if (roleTypeDiction.ContainsKey(mt.Id))
                {
                    mt.UserRoleType = roleTypeDiction[mt.Id].ToArray();
                }

                if (migrationDepDiction.ContainsKey(mt.Id))
                {
                    mt.MigrationDependencies = migrationDepDiction[mt.Id].ToArray();
                }
            }

            return mappingTableList.ToArray();
        }

        private MappingTableDataPage GetMappingTableData(string userId, long mappingTableId, int pageNumber, int rowsPerPage, int totalRecords, MappingTableDataType requestType)
        {
            //Get Mapping Table Info first
            var mappingTableInfo = GetMappingTableInfoCore(userId, mappingTableId);
            //Check if mapping Table Info is retreived
            if(mappingTableInfo.Length != 1)
            {
                throw new Exception("Mapping Table Info could not be retreived.");
            }

            //{0} - column list
            //{1} - column list 
            //{2} - Mapping Table Name
            //{3} - StartRow
            //{4} - EndRow
            string queryFmt = "SELECT urowid, {0} FROM (SELECT ROWNUM rnum, a.* FROM (SELECT rowid as urowid, {1} FROM {2}) a) WHERE rnum BETWEEN {3} AND {4}";
            //string queryFmt = "SELECT ID, INCOLUMN1, INCOLUMN2, INCOLUMN3, OUTCOLUMN4, OUTCOLUMN5 FROM (SELECT ROWNUM rnum, a.* FROM (SELECT * FROM CA_TESTLARGETABLE) a) WHERE rnum BETWEEN {0} AND {1}";

            //Get Mapping Table Connection String
            //If request type is migration, use portal's connection string because it will have read access to lower environment; otherwise current environment
            string mappingTableConnectionString = (requestType == MappingTableDataType.Migrate ? this.ConnectionString : GetConnectionStringFromProfileName(mappingTableInfo[0].MappingTableRepository.Name));
            //string mappingTableConnectionString = (requestType == MappingTableDataType.Migrate ? GetConnectionStringFromProfileName(mappingTableInfo[0].MigrationTableRepository.Name) : GetConnectionStringFromProfileName(mappingTableInfo[0].MappingTableRepository.Name));

            //Calculate Total Records if not known
            if (totalRecords == 0)
            {
                if (requestType == MappingTableDataType.Save)
                {
                    totalRecords = GetTotalRowsFromTable(mappingTableInfo[0].PhysicalTable, mappingTableConnectionString);
                }
                else
                {
                    totalRecords = GetTotalRowsFromTable(mappingTableInfo[0].LowerEnvMapTableSynonym, this.ConnectionString);
                }

            }

            //Calculate start and end row
            int endRow = pageNumber * rowsPerPage;
            int startRow = (endRow - rowsPerPage) + 1;

            //Calculate total pages
            decimal totalPages = Decimal.Ceiling(Decimal.Divide(totalRecords, rowsPerPage));
            if (endRow > totalRecords)
            {
                endRow = totalRecords;
            }



            //generate column list
            string columnList = string.Join(",", mappingTableInfo[0].Columns, 1, mappingTableInfo[0].Columns.Length - 1);

            //generate query
            //If request type is migration, use LowerEnvMapTableSynonym for name because we will connect from portal db; otherwise current environment
            string query = string.Format(queryFmt, columnList, columnList, (requestType == MappingTableDataType.Migrate ? mappingTableInfo[0].LowerEnvMapTableSynonym : mappingTableInfo[0].PhysicalTable), startRow, endRow);

            //Prepare return value
            MappingTableDataPage mappingTableDataPage = new MappingTableDataPage();
            mappingTableDataPage.PageNumber = pageNumber;
            mappingTableDataPage.TotalPages = Convert.ToInt32(totalPages);
            mappingTableDataPage.TotalResults = totalRecords;

            //automatically include unique row column
            var columnListWithURowId = new List<string>();
            //columnListWithURowId.Add("urowid");
            columnListWithURowId.AddRange(mappingTableInfo[0].Columns);
            mappingTableInfo[0].Columns = columnListWithURowId.ToArray();


            //Data structure for column data
            Dictionary<int, List<string>> columnDiction = new Dictionary<int, List<string>>();

            //initialize the column in the column dictionary
            for (var colIndex = 0; colIndex < mappingTableInfo[0].Columns.Length; colIndex++)
            {
                columnDiction.Add(colIndex, new List<string>());
            }

            //using (IDataReader dataReader = oracleHelper.ExecuteReader(mappingTableConnectionString, CommandType.Text, query))
            using (OracleConnection conn = new OracleConnection(mappingTableConnectionString))
            using(OracleCommand cmd = new OracleCommand(query, conn))
            {
                conn.Open();
                try
                {
                    using(OracleDataReader dataReader = cmd.ExecuteReader())
                    {
                        //Read data from table
                        while (dataReader.Read())
                        {
                            for (var colIndex = 0; colIndex < mappingTableInfo[0].Columns.Length; colIndex++)
                            {
                                columnDiction[colIndex].Add( dataReader.IsDBNull(colIndex) ? string.Empty : Convert.ToString(dataReader.GetValue(colIndex)));
                            }
                        }

                        dataReader.Close();
                    }
                }
                catch(Exception e)
                {
                    throw;
                }
                finally
                {
                    conn.Close();
                }
            }

            //Assign the values from column diction to return object
            List<MappingColumnValues> mappingColumnValuesList = new List<MappingColumnValues>();
            for (var colIndex = 0; colIndex < mappingTableInfo[0].Columns.Length; colIndex++)
            {
                mappingColumnValuesList.Add(new MappingColumnValues() { Data = columnDiction[colIndex].ToArray() });
            }

            mappingTableDataPage.Result = mappingColumnValuesList.ToArray();

            return mappingTableDataPage;
        }

        private AuditLogPage GetAuditLogPageData(string userId, long mappingTableId, KnownValues.AuditType auditType, int pageNumber, int rowsPerPage, int totalRecords, string searchKey)
        {
            //{0} - mapping table id
            //{1} - audit Type
            //{2} - Search Filter
            //{3} - StartRow
            //{4} - EndRow

            /* -- fortity issue
            string searchQuery = (string.IsNullOrEmpty(searchKey) ? string.Empty : string.Format(" AND (ACTION LIKE '%{0}%' OR NEW_VALUE LIKE '%{0}%' OR OLD_VALUE LIKE '%{0}%') ", searchKey));

            string queryFmt = "SELECT AUDIT_ID, MAPPING_TABLE_ID, ACTION, ACTION_DATE, NEW_VALUE, OLD_VALUE, Last_Name, First_Name, audit_type, case when last_validated_on > action_date then 'true' else 'false' end \"Is_Validated\", is_validation_overridden " +
                " FROM (SELECT ROWNUM rnum, a.*, m.last_validated_on FROM (SELECT AUDIT_ID, MAPPING_TABLE_ID, ACTION, ACTION_DATE, NEW_VALUE, OLD_VALUE, Last_Name, First_Name, audit_type, is_validation_overridden " +
                " FROM Mapping_Audit_LOG L JOIN WEB_USERS U ON L.ACTION_USER_ID = U.Employee_Id WHERE l.mapping_table_id = {0} and AUDIT_TYPE = {1} {2} ORDER BY L.ACTION_DATE DESC) a JOIN Mapping_Table_List m ON m.mapping_table_id = a.mapping_table_id) WHERE rnum BETWEEN {3} AND {4} ORDER BY ACTION_DATE DESC ";
            */

            // Fortify begin
            string searchQuery = (string.IsNullOrEmpty(searchKey) ? string.Empty : " AND (ACTION LIKE '%'||:searchKey||'%' OR NEW_VALUE LIKE '%'||:searchKey||'%' OR OLD_VALUE LIKE '%'||:searchKey||'%') ");

            string queryFmt = "SELECT AUDIT_ID, MAPPING_TABLE_ID, ACTION, ACTION_DATE, NEW_VALUE, OLD_VALUE, Last_Name, First_Name, audit_type, case when last_validated_on >= action_date then 'true' else 'false' end \"Is_Validated\", is_validation_overridden " +
                " FROM (SELECT ROWNUM rnum, a.*, m.last_validated_on FROM (SELECT AUDIT_ID, MAPPING_TABLE_ID, ACTION, ACTION_DATE, NEW_VALUE, OLD_VALUE, Last_Name, First_Name, audit_type, is_validation_overridden " +
                " FROM Mapping_Audit_LOG L JOIN WEB_USERS U ON L.ACTION_USER_ID = U.Employee_Id WHERE l.mapping_table_id = :mappingTableId and AUDIT_TYPE = :auditType {0} ORDER BY L.ACTION_DATE DESC) a JOIN Mapping_Table_List m ON m.mapping_table_id = a.mapping_table_id) WHERE rnum BETWEEN :startRow AND :endRow ORDER BY ACTION_DATE DESC ";
            // Fortify end

            //Calculate Total Records if not known
            if (totalRecords == 0)
            {
                //totalRecords = GetTotalRowsFromTable("Mapping_Audit_LOG", this.ConnectionString);
                totalRecords = GetTotalRowsFromAuditTable(mappingTableId, auditType, this.ConnectionString, searchKey);
            }

            //Calculate start and end row
            int endRow = pageNumber * rowsPerPage;
            int startRow = (endRow - rowsPerPage) + 1;

            //Calculate total pages
            decimal totalPages = Decimal.Ceiling(Decimal.Divide(totalRecords, rowsPerPage));
            if (endRow > totalRecords)
            {
                endRow = totalRecords;
            }

            //generate query
            /*-fortify issue
            string query = string.Format(queryFmt, mappingTableId, Convert.ToInt32(auditType), searchQuery, startRow, endRow);
            */
            string query = string.Format(queryFmt, searchQuery);

            //Prepare return value
            AuditLogPage auditLogDataPage = new AuditLogPage();
            auditLogDataPage.PageNumber = pageNumber;
            auditLogDataPage.TotalPages = Convert.ToInt32(totalPages);
            auditLogDataPage.TotalResults = totalRecords;

            List<AuditLog> auditLogList = new List<AuditLog>();
            //using (IDataReader dataReader = oracleHelper.ExecuteReader(this.ConnectionString, CommandType.Text, query))
            using(OracleConnection conn = new OracleConnection(this.ConnectionString))
            using(OracleCommand cmd = new OracleCommand(query, conn))
            {
                // Fortify begin
                cmd.BindByName = true;
                OracleParameter p1 = new Oracle.ManagedDataAccess.Client.OracleParameter("mappingTableId", mappingTableId);
                cmd.Parameters.Add(p1);
                OracleParameter p2 = new Oracle.ManagedDataAccess.Client.OracleParameter("auditType", Convert.ToInt32(auditType));
                cmd.Parameters.Add(p2);
                OracleParameter p3 = new Oracle.ManagedDataAccess.Client.OracleParameter("startRow", startRow);
                cmd.Parameters.Add(p3);
                OracleParameter p4 = new Oracle.ManagedDataAccess.Client.OracleParameter("endRow", endRow);
                cmd.Parameters.Add(p4);

                if (string.IsNullOrEmpty(searchKey) == false)
                {
                    OracleParameter p5 = new Oracle.ManagedDataAccess.Client.OracleParameter("searchKey", searchKey);
                    cmd.Parameters.Add(p5);
                }

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = query;
                // Fortify end

                conn.Open();
                try
                {
                    using(OracleDataReader dataReader = cmd.ExecuteReader())
                    {
                        int auditIdCol = dataReader.GetOrdinal("AUDIT_ID");
                        int mappingTableIdCol = dataReader.GetOrdinal("MAPPING_TABLE_ID");
                        int actionCol = dataReader.GetOrdinal("ACTION");
                        int actionDateCol = dataReader.GetOrdinal("ACTION_DATE");
                        int newValCol = dataReader.GetOrdinal("NEW_VALUE");
                        int oldValCol = dataReader.GetOrdinal("OLD_VALUE");
                        int lastNameCol = dataReader.GetOrdinal("Last_Name");
                        int firstNameCol = dataReader.GetOrdinal("First_Name");
                        int auditTypeCol = dataReader.GetOrdinal("audit_type");
                        int isValidatedCol = dataReader.GetOrdinal("Is_Validated");
                        int isValidationOverriddenCol = dataReader.GetOrdinal("is_validation_overridden");
                        //Read data from table
                        while (dataReader.Read())
                        {
                            var auditLog = new AuditLog();
                            auditLog.Id = dataReader.GetInt64(auditIdCol);
                            auditLog.MappingTableId = dataReader.GetInt64(mappingTableIdCol);
                            auditLog.Action = dataReader.GetString(actionCol);
                            auditLog.ActionOn = dataReader.GetDateTime(actionDateCol);
                            auditLog.AuditType = (KnownValues.AuditType)dataReader.GetInt32(auditTypeCol);
                            var lastName = dataReader.GetString(lastNameCol);
                            var firstName = dataReader.GetString(firstNameCol);
                            auditLog.ActionBy = string.Format("{0}, {1}", lastName, firstName);

                            if (auditLog.AuditType == KnownValues.AuditType.DATA)
                            {
                                auditLog.NewValue = (dataReader.IsDBNull(newValCol) ? string.Empty : dataReader.GetString(newValCol));
                                auditLog.OldValue = (dataReader.IsDBNull(oldValCol) ? string.Empty : dataReader.GetString(oldValCol));
                                auditLog.IsDataValidated = (dataReader.IsDBNull(isValidatedCol)) ? false : Convert.ToBoolean(dataReader.GetString(isValidatedCol));
                            }
                            else
                            {
                                if (dataReader.IsDBNull(isValidationOverriddenCol) == false)
                                {
                                    var IsValidationOverriddenString = dataReader.GetString(isValidationOverriddenCol).Trim();
                                    auditLog.IsValidationOverridden = (IsValidationOverriddenString == "Y") ? true : false;
                                }
                            }

                            auditLogList.Add(auditLog);
                        }
                        dataReader.Close();
                    }
                }
                catch (Exception e)
                {
                    throw e;
                }
                finally
                {
                    conn.Close();
                }
            }

            if (auditLogList.Count > 0)
            {
                auditLogDataPage.Result = auditLogList.ToArray();
            }

            return auditLogDataPage;
        }

        //private AuditLogPage GetAuditLogPageDataBySearch(string userId, long mappingTableId, int pageNumber, int rowsPerPage, int totalRecords, string SearchItem)
        //{
        //    //{0} - StartRow
        //    //{1} - EndRow
        //    //{2} - SearchWord

        //    string SearchWord = (SearchItem == null ? string.Empty : string.Format("( WHERE ACTION LIKE '%{0}%' OR NEW_VALUE LIKE '%{0}%' OR OLD_VALUE LIKE '%{0}%')", SearchItem));

        //    string queryFmt = "SELECT AUDIT_ID, MAPPING_TABLE_ID, ACTION, ACTION_DATE, NEW_VALUE, OLD_VALUE, Last_Name, First_Name " +
        //        " FROM (SELECT ROWNUM rnum, a.* FROM (SELECT AUDIT_ID, MAPPING_TABLE_ID, ACTION, ACTION_DATE, NEW_VALUE, OLD_VALUE, Last_Name, First_Name " +
        //        " FROM Mapping_Audit_LOG L JOIN WEB_USERS U ON L.ACTION_USER_ID = U.Employee_Id {2} " +
        //        " ORDER BY L.AUDIT_ID DESC) a) WHERE rnum BETWEEN {0} AND {1}";

        //    //Calculate Total Records if not known
        //    if (totalRecords == 0)
        //    {
        //        totalRecords = GetTotalRowsFromTable("Mapping_Audit_LOG", this.ConnectionString);
        //    }

        //    //Calculate start and end row
        //    int endRow = pageNumber * rowsPerPage;
        //    int startRow = (endRow - rowsPerPage) + 1;

        //    //Calculate total pages
        //    decimal totalPages = Decimal.Ceiling(Decimal.Divide(totalRecords, rowsPerPage));
        //    if (endRow > totalRecords)
        //    {
        //        endRow = totalRecords;
        //    }

        //    //generate query
        //    string query = string.Format(queryFmt, startRow, endRow,SearchWord);

        //    //Prepare return value
        //    AuditLogPage searchAuditLogDataPage = new AuditLogPage();
        //    searchAuditLogDataPage.PageNumber = pageNumber;
        //    searchAuditLogDataPage.TotalPages = Convert.ToInt32(totalPages);
        //    searchAuditLogDataPage.TotalResults = totalRecords;

        //    List<AuditLog> auditLogSearchList = new List<AuditLog>();
        //    using(OracleConnection conn = new OracleConnection(this.ConnectionString))
        //    using(OracleCommand cmd = new OracleCommand(query, conn))
        //    //using (IDataReader dataReader = oracleHelper.ExecuteReader(this.ConnectionString, CommandType.Text, query))
        //    {
        //        conn.Open();
        //        try
        //        {
        //            using (OracleDataReader dataReader = cmd.ExecuteReader())
        //            {
        //                int auditIdCol = dataReader.GetOrdinal("AUDIT_ID");
        //                int mappingTableIdCol = dataReader.GetOrdinal("MAPPING_TABLE_ID");
        //                int actionCol = dataReader.GetOrdinal("ACTION");
        //                int actionDateCol = dataReader.GetOrdinal("ACTION_DATE");
        //                int newValCol = dataReader.GetOrdinal("NEW_VALUE");
        //                int oldValCol = dataReader.GetOrdinal("OLD_VALUE");
        //                int lastNameCol = dataReader.GetOrdinal("Last_Name");
        //                int firstNameCol = dataReader.GetOrdinal("First_Name");
        //                //Read data from table
        //                while (dataReader.Read())
        //                {
        //                    var auditLog = new AuditLog();
        //                    auditLog.Id = dataReader.GetInt64(auditIdCol);
        //                    auditLog.MappingTableId = dataReader.GetInt64(mappingTableIdCol);
        //                    auditLog.Action = dataReader.GetString(actionCol);
        //                    auditLog.ActionOn = dataReader.GetDateTime(actionDateCol);
        //                    auditLog.NewValue = (dataReader.IsDBNull(newValCol) ? string.Empty : dataReader.GetString(newValCol));
        //                    auditLog.OldValue = (dataReader.IsDBNull(oldValCol) ? string.Empty : dataReader.GetString(oldValCol));
        //                    var lastName = dataReader.GetString(lastNameCol);
        //                    var firstName = dataReader.GetString(firstNameCol);
        //                    auditLog.ActionBy = string.Format("{0}, {1}", lastName, firstName);

        //                    auditLogSearchList.Add(auditLog);
        //                }
        //                dataReader.Close();
        //            }
        //        }
        //        catch
        //        { }
        //        finally 
        //        {
        //            conn.Close();
        //        }

        //    }

        //    if (auditLogSearchList.Count > 0)
        //    {
        //        searchAuditLogDataPage.Result = auditLogSearchList.ToArray();
        //    }

        //    return searchAuditLogDataPage;
        //}

        private string GetConnectionStringFromProfileName(string profileName)
        {
            //TODO: Handle null
            var dbProfile = dbProfileList.FirstOrDefault(d => d.Name == profileName);
            return string.Format(dbProfile.ConnectionString, Common.Utility.Decrypt(dbProfile.EncryptedUserName, EncryptionSalt), Common.Utility.Decrypt(dbProfile.EncryptedPassword, EncryptionSalt));
        }

        private int GetTotalRowsFromTable(string mappingTableName, string connectString)
        {
            string queryTotalRecords = string.Format("SELECT COUNT(1) as totalRecords FROM {0}", mappingTableName);

            int returnValue = 0;

            //using (IDataReader dataReader = oracleHelper.ExecuteReader(mappingTableConnectionString, CommandType.Text, query))
            using (OracleConnection conn = new OracleConnection(connectString))
            using (OracleCommand cmd = new OracleCommand(queryTotalRecords, conn))
            {
                conn.Open();
                try
                {
                    using (OracleDataReader dataReader = cmd.ExecuteReader())
                    {
                        int totalRecordsCol = dataReader.GetOrdinal("totalRecords");
                        if (dataReader.Read())
                        {
                            returnValue = dataReader.GetInt32(totalRecordsCol);
                        }

                        dataReader.Close();
                    }
                }
                catch (Exception e)
                {
                    throw;
                }
                finally
                {
                    conn.Close();
                }
            }

            //using (IDataReader dataReader = oracleHelper.ExecuteReader(connectString, CommandType.Text, queryTotalRecords))
            //{
            //    int totalRecordsCol = dataReader.GetOrdinal("totalRecords");
            //    if (dataReader.Read())
            //    {
            //        returnValue = dataReader.GetInt32(totalRecordsCol);
            //    }
            //    dataReader.Close();
            //}
            return returnValue;
        }

        private int GetTotalRowsFromAuditTable(long mappingTableId, KnownValues.AuditType auditType, string connectString, string searchKey)
        {
            string searchQuery = (string.IsNullOrEmpty(searchKey) ? string.Empty : string.Format(" AND (ACTION LIKE '%{0}%' OR NEW_VALUE LIKE '%{0}%' OR OLD_VALUE LIKE '%{0}%' ) ", searchKey));

            string queryTotalRecords = string.Format("SELECT COUNT(1) as totalRecords FROM Mapping_Audit_LOG where mapping_table_ID = {0} and audit_type = {1} {2}", mappingTableId, Convert.ToInt32(auditType), searchQuery);

            int returnValue = 0;

            using (OracleConnection conn = new OracleConnection(connectString))
            using (OracleCommand cmd = new OracleCommand(queryTotalRecords, conn))
            {
                conn.Open();
                try
                {
                    using (OracleDataReader dataReader = cmd.ExecuteReader())
                    {
                        int totalRecordsCol = dataReader.GetOrdinal("totalRecords");
                        if (dataReader.Read())
                        {
                            returnValue = dataReader.GetInt32(totalRecordsCol);
                        }

                        dataReader.Close();
                    }
                }
                catch (Exception e)
                {
                    throw;
                }
                finally
                {
                    conn.Close();
                }
            }

            //using (IDataReader dataReader = oracleHelper.ExecuteReader(connectString, CommandType.Text, queryTotalRecords))
            //{
            //    int totalRecordsCol = dataReader.GetOrdinal("totalRecords");
            //    if (dataReader.Read())
            //    {
            //        returnValue = dataReader.GetInt32(totalRecordsCol);
            //    }
            //    dataReader.Close();
            //}
            return returnValue;
        }

        private long StageRowData(string userId, MappingTable mappingTableInfo, MappingTableWriteRequest writeRequest)
        {

            //Get Run Status Id
            long runStatusId = writeRequest.RunStatusId;

            // 0 - col list (w/o unique row id)
            // 1 - RUN_STATUS_ID
            // 2 - MAPPING_TABLE_ID
            // 3 - col data list (w/o unique row id)
            string stageInsertQueryFmt = "INSERT INTO staging_validation(RUN_STATUS_ID, MAPPING_TABLE_ID, UNIQUE_ROWID, CHANGE_TYPE, LAST_MODIFIED_BY, {0}) "
                + " VALUES ( {1}, {2}, :UNIQUE_ROWID, :CHANGE_TYPE, :LAST_MODIFIED_BY, {3})";

            //check if user has save rights
            //TODO: use user access
            var canSave = true;

            if (canSave == false)
            {
                throw new Exception("User not authorized to save");
            }

            Dictionary<int, List<string>> dataColumnList = new Dictionary<int, List<string>>();
            List<string> changeTypeColList = new List<string>();
            List<string> lastModifiedByList = new List<string>();
            //initialize list in dictionary
            for (int cCounter = 0; cCounter < mappingTableInfo.Columns.Length; cCounter++)
            {
                var dataColumn = new List<string>();
                dataColumnList.Add(cCounter, dataColumn);
            }

            if (writeRequest.AddRecords != null && writeRequest.AddRecords.Length > 0)
            {
                if (mappingTableInfo.Columns.Length != writeRequest.AddRecords.Length)
                {
                    throw new Exception("Request for add rows does not contain data for all columns in mapping table");
                }

                for (int cCounter = 0; cCounter < writeRequest.AddRecords.Length; cCounter++)
                {
                    var dataColumn = dataColumnList[cCounter];
                    dataColumn.AddRange(writeRequest.AddRecords[cCounter].Data);
                }

                changeTypeColList.AddRange(GenerateChangeTypeColList(writeRequest.AddRecords[0].Data.Length, KnownValues.StageChangeTypeAdd));
            }

            if (writeRequest.ModifiedRecords != null && writeRequest.ModifiedRecords.Length > 0)
            {
                if (mappingTableInfo.Columns.Length != writeRequest.ModifiedRecords.Length)
                {
                    throw new Exception("Request for modify rows does not contain data for all columns in mapping table");
                }

                for (int cCounter = 0; cCounter < writeRequest.ModifiedRecords.Length; cCounter++)
                {
                    var dataColumn = dataColumnList[cCounter];
                    dataColumn.AddRange(writeRequest.ModifiedRecords[cCounter].Data);
                }

                changeTypeColList.AddRange(GenerateChangeTypeColList(writeRequest.ModifiedRecords[0].Data.Length, KnownValues.StageChangeTypeModify));
            }

            if (writeRequest.DeletedRecords != null && writeRequest.DeletedRecords.Length > 0)
            {
                //int emptyRowsCount = dataColumnList[0].Count - writeRequest.DeletedRecords.Length;
                var dataColumnURowId = dataColumnList[0];
                dataColumnURowId.AddRange(writeRequest.DeletedRecords);

                //empty data column
                List<string> emptyDataColumn = new List<String>();
                for (var rowIndex = 0; rowIndex < writeRequest.DeletedRecords.Length; rowIndex++)
                {
                    emptyDataColumn.Add(string.Empty);
                }

                //add empty data column for all available column
                for (int colIndex = 1; colIndex < dataColumnList.Count; colIndex++)
                {
                    var dataColumn = dataColumnList[colIndex];
                    dataColumn.AddRange(emptyDataColumn);
                }

                changeTypeColList.AddRange(GenerateChangeTypeColList(writeRequest.DeletedRecords.Length, KnownValues.StageChangeTypeDelete));
            }

            if (changeTypeColList.Count > 0)
            {
                lastModifiedByList.AddRange(GenerateChangeTypeColList(changeTypeColList.Count, userId));
            }

            //Need to validate even when no rows 
            //if (dataColumnList[0].Count == 0)
            //{
            //    throw new Exception("No data for validation or save operation");
            //}


            // 0 - col list (w/o unique row id)
            // 1 - RUN_STATUS_ID
            // 2 - MAPPING_TABLE_ID
            // 3 - col data list (w/o unique row id)

            string dataColList = string.Join(", ", GetStagingColList(mappingTableInfo.Columns.Length - 1, false));
            List<string> bindColList = GetStagingColList(mappingTableInfo.Columns.Length - 1, true);
            string dataColListForBind = string.Join(", ", bindColList);
            //int[] recId = Enumerable.Range(1, dataColumnList[0].Count).ToArray();
            //string query = string.Format(stageInsertQueryFmt, dataColList, runStatusId, writeRequest.MappingTableId, dataColListForBind);

            //Generate Oracle Params
            List<OracleParameter> paramsList = new List<OracleParameter>();

            //bind data for run status id
            //paramsList.Add(new OracleParameter(":REC_ID", OracleDbType.Int64) { Value = recId.ToArray() });

            //bind data for UNIQUE_ROWID
            paramsList.Add(new OracleParameter(":UNIQUE_ROWID", OracleDbType.Varchar2) { Value = dataColumnList[0].ToArray() });

            //bind data for CHANGE_TYPE
            paramsList.Add(new OracleParameter(":CHANGE_TYPE", OracleDbType.Varchar2) { Value = changeTypeColList.ToArray() });

            //bind data for user_id 
            paramsList.Add(new OracleParameter(":LAST_MODIFIED_BY", OracleDbType.Varchar2) { Value = lastModifiedByList.ToArray() });

            //bind data for data columns
            for (int cCounter = 0; cCounter < bindColList.Count; cCounter++)
            {
                paramsList.Add(new OracleParameter(bindColList[cCounter], OracleDbType.Varchar2) { Value = dataColumnList[cCounter+1].ToArray() });
            }

            using (OracleConnection oraConn = new OracleConnection(this.ConnectionString))
            using (OracleCommand oraRunStatusCommand = new OracleCommand())
            using (OracleCommand oraStageCommand = new OracleCommand())
            {
                oraConn.Open();
                using (OracleTransaction transaction = oraConn.BeginTransaction())
                {
                    try
                    {
                        //Get Run Status Id
                        /*oraRunStatusCommand.Connection = oraConn;
                        oraRunStatusCommand.CommandType = CommandType.StoredProcedure;
                        oraRunStatusCommand.CommandText = "MDMFRAMEWORK.start_process";

                        oraRunStatusCommand.Parameters.Add(new OracleParameter("@name", OracleDbType.Varchar2, "MappingTable", ParameterDirection.Input));
                        oraRunStatusCommand.Parameters.Add(new OracleParameter("@file_type", OracleDbType.Varchar2, mappingTableInfo.Name, ParameterDirection.Input));
                        oraRunStatusCommand.Parameters.Add(new OracleParameter("@run_status_id", OracleDbType.Int32, ParameterDirection.Output));

                        oraRunStatusCommand.ExecuteNonQuery();
                        runStatusId = long.Parse(oraRunStatusCommand.Parameters["@run_status_id"].Value.ToString());*/

                        //runStatusId = opsStatusDbManager.StartProcess("MappingTable", Convert.ToString(mappingTableInfo.Id), "stage", true, string.Empty, "ui", string.Empty);
                        //opsStatusDbManager.EndStep(runStatusId);

                        //Dont stage anything if there is no delta
                        if (dataColumnList[0].Count > 0)
                        {
                            //Stage data to table
                            string query = string.Format(stageInsertQueryFmt, dataColList, runStatusId, writeRequest.MappingTableId, dataColListForBind);
                            oraStageCommand.Connection = oraConn;
                            oraStageCommand.CommandType = CommandType.Text;
                            oraStageCommand.CommandText = query;
                            oraStageCommand.BindByName = true;
                            oraStageCommand.ArrayBindCount = dataColumnList[0].Count;  //paramsList.Count;
                            oraStageCommand.Parameters.AddRange(paramsList.ToArray());
                            var returnVal = oraStageCommand.ExecuteNonQuery();
                        }

                        transaction.Commit();
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                    finally
                    {
                        oraConn.Close();
                    }
                }
            }

            return runStatusId;
        }

        private long StageFromChangeControlCore(string userId, MappingTable mappingTableInfo, Contracts.Data.MappingTableMgmt.MappingTableWriteRequest writeRequest)
        {
            long runStatusId = writeRequest.RunStatusId;

            /*
             * 0 - staging table collist in insert
             * 1 - runStatusId
             * 2 - mappingTableId
             * 3 - mapping table collist in select clause
             * 4 - mapping table name (synonym name)
             */
            string stageInsertQueryFmt = "INSERT INTO Staging_Validation (RUN_STATUS_ID, MAPPING_TABLE_ID, UNIQUE_ROWID, CHANGE_TYPE, LAST_MODIFIED_BY, {0}) " +
                        " SELECT {1}, {2}, rowid, 'A', :LAST_MODIFIED_BY, {3} FROM {4} ";

            string stageColList = string.Join(", ", GetStagingColList(mappingTableInfo.Columns.Length - 1, false));
            string mappingTableColList = string.Join(",", Array.FindAll(mappingTableInfo.Columns, s => s != uniqueRowName));
            //Array.TrueForAll(mappingTableInfo.Columns, s => s != uniqueRowName))


            //using (OracleConnection oraConn = new OracleConnection(GetConnectionStringFromProfileName(mappingTableInfo.MigrationTableRepository.Name)))
            //Staging will be always under Portal DB context. Portal DB in migration env will have access to mapping table in lower environment
            using (OracleConnection oraConn = new OracleConnection(this.ConnectionString))
            using (OracleCommand oraRunStatusCommand = new OracleCommand())
            using (OracleCommand oraStageCommand = new OracleCommand())
            //using (OracleCommand oraCommand = oracleHelper.CreateCommand(oraConn, query, paramsList.ToArray()))
            {
                oraConn.Open();
                using (OracleTransaction transaction = oraConn.BeginTransaction())
                {
                    try
                    {
                        //Get Run Status Id
                        //oraRunStatusCommand.Connection = oraConn;
                        //oraRunStatusCommand.CommandType = CommandType.StoredProcedure;
                        //oraRunStatusCommand.CommandText = "UTILITY.PROCESS.add";
                        //oraRunStatusCommand.BindByName = true;

                        //oraRunStatusCommand.Parameters.Add("Return_Value", OracleDbType.Int16, ParameterDirection.ReturnValue);
                        //oraRunStatusCommand.Parameters.Add(new OracleParameter("i_process_name", OracleDbType.Varchar2, "MappingTable", ParameterDirection.Input));
                        //oraRunStatusCommand.Parameters.Add(new OracleParameter("i_as_relates_to", OracleDbType.Varchar2, mappingTableInfo.Name, ParameterDirection.Input));

                        //oraRunStatusCommand.ExecuteNonQuery();
                        //runStatusId = long.Parse(oraRunStatusCommand.Parameters["Return_Value"].Value.ToString());

                        //Stage data from change control mapping table
                        string query = string.Format(stageInsertQueryFmt, stageColList, runStatusId, mappingTableInfo.Id, mappingTableColList, mappingTableInfo.LowerEnvMapTableSynonym);
                        oraStageCommand.Connection = oraConn;
                        oraStageCommand.CommandType = CommandType.Text;
                        oraStageCommand.CommandText = query;
                        oraStageCommand.Parameters.Add(new OracleParameter("LAST_MODIFIED_BY", OracleDbType.Varchar2, userId,ParameterDirection.Input));
                        var returnVal = oraStageCommand.ExecuteNonQuery();

                        transaction.Commit();
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                    finally
                    {
                        oraConn.Close();
                    }
                }
            }



            return runStatusId;
        }

        private int ArchiveStageDataCore(string userId, long runStatusId)
        {
            int returnCode = -1;

            using (OracleConnection oraConn = new OracleConnection(this.ConnectionString))
            using (OracleCommand oraValidateCommand = new OracleCommand())
            {
                oraConn.Open();
                using (OracleTransaction transaction = oraConn.BeginTransaction())
                {
                    try
                    {
                        oraValidateCommand.Connection = oraConn;
                        oraValidateCommand.CommandType = CommandType.StoredProcedure;
                        oraValidateCommand.CommandText = "mdmframework.archive_stage_data";

                        oraValidateCommand.Parameters.Add(new OracleParameter("@i_run_status_id", OracleDbType.Int64, runStatusId, ParameterDirection.Input));
                        oraValidateCommand.ExecuteNonQuery();

                        //if (returnCode != 0)
                        //{
                        //    throw new Exception("Validation sproc encountered error.");
                        //}

                        transaction.Commit();
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                    finally
                    {
                        oraConn.Close();
                    }
                }
            }
            return returnCode;
        }

        private int RunSprocValidation(long runStatusId, long mappingTableId, string sprocName, string connectString, MappingTableDataType validationType)
        {
            int returnCode = -1;

            using (OracleConnection oraConn = new OracleConnection(connectString))
            using (OracleCommand oraValidateCommand = new OracleCommand())
            {
                oraConn.Open();
                using (OracleTransaction transaction = oraConn.BeginTransaction())
                {
                    try
                    {
                        oraValidateCommand.Connection = oraConn;
                        oraValidateCommand.CommandType = CommandType.StoredProcedure;
                        oraValidateCommand.CommandText = sprocName;

                        oraValidateCommand.Parameters.Add(new OracleParameter("@I_RUN_STATUS_ID", OracleDbType.Int64, runStatusId, ParameterDirection.Input));
                        oraValidateCommand.Parameters.Add(new OracleParameter("@I_MAPPING_TABLE_ID", OracleDbType.Int64, mappingTableId, ParameterDirection.Input));
                        oraValidateCommand.Parameters.Add(new OracleParameter("@I_VALIDATION_TYPE", OracleDbType.Varchar2, (validationType == MappingTableDataType.Save ? "S" : "M"), ParameterDirection.Input));
                        oraValidateCommand.Parameters.Add(new OracleParameter("@O_RETURN_CODE", OracleDbType.Int32, ParameterDirection.Output));

                        oraValidateCommand.ExecuteNonQuery();
                        returnCode = int.Parse(oraValidateCommand.Parameters["@O_RETURN_CODE"].Value.ToString());

                        //if (returnCode != 0)
                        //{
                        //    throw new Exception("Validation sproc encountered error.");
                        //}

                        transaction.Commit();

                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                    finally
                    {
                        oraConn.Close();
                    }
                }
            }
            return returnCode;
        }

        private MappingTableWriteResponse WriteMappingData(string userId, long runStatusId, MappingTable mappingTableInfo, MappingTableDataType writeType)
        {
            MappingTableWriteResponse response = new MappingTableWriteResponse() { MappingTableId = mappingTableInfo.Id };
            /*
           MERGE INTO Pmr_Mappings ttbl
            USING (select rec_id, mapping_table_id, Change_Type, unique_rowid, col1, col2, col3, col4, col5
                    from Staging_Validation_Hist 
                    where run_status_id = 5 
                    order by rec_id) sv
            ON (ROWIDTOCHAR(ttbl.rowid) = sv.unique_rowid)
            WHEN MATCHED THEN
                UPDATE SET ttbl.IP_COL_1 = sv.col1, ttbl.IP_COL_2 = sv.col2, ttbl.IP_COL_3 = sv.col3, ttbl.OP_COL_4 = sv.col4, ttbl.OP_COL_5 = sv.col5 
                WHERE SV.CHANGE_TYPE IN ('M')
            WHEN NOT MATCHED THEN
                INSERT (ttbl.IP_COL_1, ttbl.IP_COL_2, ttbl.IP_COL_3, ttbl.OP_COL_4, ttbl.OP_COL_5)
                VALUES (sv.col1, sv.col2, sv.col3, sv.col4, sv.col5)
                WHERE SV.CHANGE_TYPE IN ('A');
             * 
            When using MERGE for the DELETE operation, remember that:
            DELETE  checks the match condition on the target table, not the source. 
            DELETE works only on rows updated during MERGE. Any rows in the target table that are not processed during MERGE are not deleted, even if they match the DELETE condition. 
              */
            //{0} - stage table data column list
            //{1} - runstatusid
            //{2] - update columns
            //{3} - Modify change type
            //{4} - insert mapping table data column list
            //{5} - insert value stage data columns list; same as {0}
            //{6} - Add change type
            //{7} - Mapping table name
            //{8} - PortalDBSchemaPrefix
            string mergeQueryFmt = "MERGE INTO {7} ttbl " +
            " USING (select rec_id, mapping_table_id, Change_Type, unique_rowid, last_modified_by, {0} " +
            " from {8}.Staging_Validation_Hist " +
            " where run_status_id = {1} " +
            " order by rec_id) sv " +
            " ON (ROWIDTOCHAR(ttbl.rowid) = sv.unique_rowid) " +
            " WHEN MATCHED THEN " +
            " UPDATE SET {2}, last_modified_by = SV.last_modified_by " +
            " WHERE SV.CHANGE_TYPE IN ('{3}') " +
            " WHEN NOT MATCHED THEN " +
            " INSERT ({4}, last_modified_by) " +
            " VALUES ({5}, SV.last_modified_by) " +
            " WHERE SV.CHANGE_TYPE IN ('{6}')";

            //generate {0} & {5}
            List<string> stageColList = GetStagingColList(mappingTableInfo.Columns.Length - 1, false);
            string stageTableDataColList = string.Join(",", stageColList);

            string stageTableNotMatchedDataColList = string.Empty;
            if (mappingTableInfo.Columns.Contains("last_modified_by",StringComparer.OrdinalIgnoreCase))
            {
                List<string> stageColListNotMatched = GetStagingColList(mappingTableInfo.Columns.Length - 2, false);
                 stageTableNotMatchedDataColList = string.Join(",", stageColListNotMatched);
            }
            else
            { 
             stageTableNotMatchedDataColList = stageTableDataColList;
            }

            //generate {2}
            List<string> updateColumnsList = new List<string>();

            for (var mtColIndex = 1; mtColIndex < mappingTableInfo.Columns.Length; mtColIndex++)
            {
                if (!mappingTableInfo.Columns[mtColIndex].Equals("LAST_MODIFIED_BY", StringComparison.OrdinalIgnoreCase))
                    updateColumnsList.Add(string.Format("{0}={1}", mappingTableInfo.Columns[mtColIndex], stageColList[mtColIndex - 1]));
            }

            string updateCol = string.Join(",", updateColumnsList);
            //generate 4
            string insertMTDataCol = string.Join(",", mappingTableInfo.Columns, 1, mappingTableInfo.Columns.Length - 1);

            string valueToRemove = "LAST_MODIFIED_BY";
            insertMTDataCol = string.Join(", ", from colName in insertMTDataCol.Split(',')
                                                where colName.Trim().ToUpper() != valueToRemove
                                                select colName);

            string mergeQuery = string.Format(mergeQueryFmt, stageTableDataColList, runStatusId, updateCol, KnownValues.StageChangeTypeModify, insertMTDataCol, stageTableNotMatchedDataColList, KnownValues.StageChangeTypeAdd, mappingTableInfo.PhysicalTable, portalSchemaPrefix);

            //{0} - mapping Table name
            //{1} - runStatusId
            //{2} - ChangeType
            //{3} - PortalDBSchemaPrefix
            string deleteQueryForSave = string.Format("DELETE FROM {0} WHERE ROWID IN (SELECT unique_rowid from {3}.Staging_Validation_Hist WHERE run_status_id = {1} AND Change_Type = '{2}')",
                mappingTableInfo.PhysicalTable, runStatusId, KnownValues.StageChangeTypeDelete, portalSchemaPrefix);
            string updateForDeletedRow = string.Format("UPDATE {0} SET LAST_MODIFIED_BY = :LAST_MODIFIED_BY WHERE ROWID IN (SELECT unique_rowid FROM Staging_Validation_Hist WHERE run_status_id = :run_status_id AND CHANGE_TYPE = 'D')", mappingTableInfo.PhysicalTable);

            string updateDeleteForSave = string.Format("BEGIN {0}; {1}; END;", updateForDeletedRow, deleteQueryForSave);


            string truncateQueryForMigrate = string.Format("DELETE FROM {0}", mappingTableInfo.PhysicalTable);

            string finalDeleteQuery = (writeType == MappingTableDataType.Migrate) ? truncateQueryForMigrate : updateDeleteForSave;


            //**WRONG**Get Change control connection string for save Migration connection string for migrate
            //string connectString = (writeType == MappingTableDataWriteType.Save ? GetConnectionStringFromProfileName(mappingTableInfo.MappingTableRepository.Name) : GetConnectionStringFromProfileName(mappingTableInfo.MigrationTableRepository.Name));

            //Write to mapping table will be always using the mapping table's current environment's connection string which will have read access to staging tables in the same environment
            string connectString = GetConnectionStringFromProfileName(mappingTableInfo.MappingTableRepository.Name);

            List<OracleParameter> paramsList = new List<OracleParameter>();

            using (OracleConnection conn = new OracleConnection(connectString))
            using (OracleCommand cmdDelete = new OracleCommand(finalDeleteQuery, conn))
            using (OracleCommand cmdMerge = new OracleCommand(mergeQuery, conn))
            {
                conn.Open();

                using (OracleTransaction transaction = conn.BeginTransaction())
                {
                    try
                    {
                        if (writeType == MappingTableDataType.Save)
                        {
                            //bind data for UNIQUE_ROWID
                            paramsList.Add(new OracleParameter("LAST_MODIFIED_BY", OracleDbType.Varchar2) { Value = userId });
                            paramsList.Add(new OracleParameter("run_status_id", OracleDbType.Int64) { Value = runStatusId });
                            cmdDelete.Parameters.AddRange(paramsList.ToArray());
                        }

                        //delete the rows marked for deletion first
                        response.RowsDeleted = cmdDelete.ExecuteNonQuery();

                        //update modified rows and insert new rows
                        response.RowsMerged = cmdMerge.ExecuteNonQuery();


                        //commit after delete and update is complete
                        transaction.Commit();

                        response.MessageType = KnownValues.MappingTableWriteResponseMsgType.Success;
                    }
                    catch (OracleException oex)
                    {
                        transaction.Rollback();
                        response.MessageType = KnownValues.MappingTableWriteResponseMsgType.Error;
                        response.MessageCode = oex.Number;
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }

            return response;
        }

        private MappingTableWriteResponse GetRowsWithErrorFromStage(long runStatusId, long mappingTableId)
        {
            MappingTableWriteResponse response = new MappingTableWriteResponse();
            response.MappingTableId = mappingTableId;

            //List<MappingColumnValues> responseColumns = new List<MappingColumnValues>();

            List<string> rowIdColData = new List<string>();
            List<string> validationMessageColData = new List<string>();

            //string query = string.Format("select Unique_Rowid, VALIDATION_MSG from Staging_Validation_Hist WHERE run_status_id = {0} AND Validation_Flag <> 0", runStatusId);
            string query = string.Format("select distinct Unique_Rowid, listagg(VALIDATION_MSG, ', ') within group (order by rec_id) over (partition by unique_rowid) validation_msg from Staging_Validation_Hist WHERE run_status_id = {0} AND Validation_Flag <> 0", runStatusId);


            using (OracleConnection oraConn = new OracleConnection(this.ConnectionString))
            using (OracleCommand oraGetStageCmd = new OracleCommand(query, oraConn))
            {
                try
                {
                    oraConn.Open();

                    OracleDataReader dataReader = oraGetStageCmd.ExecuteReader();

                    int urowidCol = dataReader.GetOrdinal("Unique_Rowid");
                    int validationMsgCol = dataReader.GetOrdinal("VALIDATION_MSG");

                    while (dataReader.Read())
                    {
                        rowIdColData.Add((dataReader.IsDBNull(urowidCol) ? string.Empty : dataReader.GetString(urowidCol)));
                        validationMessageColData.Add((dataReader.IsDBNull(validationMsgCol) ? string.Empty : dataReader.GetString(validationMsgCol)));
                    }

                    dataReader.Close();
                }
                catch
                {
                    throw;
                }
                finally
                {
                    oraConn.Close();
                }
            }

            response.ValidationResults = new MappingColumnValues[]
            {
               new MappingColumnValues() { Data = rowIdColData.ToArray() },
               new MappingColumnValues() { Data = validationMessageColData.ToArray() }
            };

            return response;
        }

        private List<string> GetStagingColList(int columnCount, bool isForBinding)
        {
            string stagingDataColPrefixFmt = (isForBinding == true) ? ":COL{0}" : "COL{0}";

            List<string> colList = new List<string>();
            for (int cCounter = 1; cCounter <= columnCount; cCounter++)
            {
                colList.Add(string.Format(stagingDataColPrefixFmt, cCounter));
            }

            return colList;
        }

        private string[] GenerateChangeTypeColList(int rowCount, string changeType)
        {
            List<string> changeTypeCol = new List<string>();
            for (int rowIndex = 0; rowIndex < rowCount; rowIndex++)
            {
                changeTypeCol.Add(changeType);
            }
            return changeTypeCol.ToArray();
        }

        private MappingTableWriteResponse Validate(string userId, long runStatusId, MappingTable mappingTableInfo, MappingTableDataType validationType)
        {
            MappingTableWriteResponse response = new MappingTableWriteResponse() { MappingTableId = mappingTableInfo.Id };
            //check if the mapping table has any validation associated
            if (mappingTableInfo.Validation == null || mappingTableInfo.Validation.Length == 0 || mappingTableInfo.Validation[0].ValidationType == KnownValues.MappingTableValidationType.None)
            {
                throw new Exception("Mapping Table did not have any validation associcated");
            }

            List<int> validationResultCode = new List<int>();

            //string connectionString = (validationType == MappingTableDataWriteType.Save ? GetConnectionStringFromProfileName(mappingTableInfo.MappingTableRepository.Name) : GetConnectionStringFromProfileName(mappingTableInfo.MigrationTableRepository.Name));
            //Validation will always happen on the context of current environment mapping table db
            string connectionString = GetConnectionStringFromProfileName(mappingTableInfo.MappingTableRepository.Name);

            //Execute Validation Sproc
            foreach (ValidationInfo validationInfo in mappingTableInfo.Validation)
            {
                if (validationInfo.Parameters.Length > 0)
                {
                    switch (validationInfo.ValidationType)
                    {
                        case KnownValues.MappingTableValidationType.SPROC:
                            {
                                validationResultCode.Add(RunSprocValidation(runStatusId, mappingTableInfo.Id, validationInfo.Name, connectionString, validationType));
                                break;
                            }
                        default:
                            {
                                throw new NotImplementedException("Validation Type not supported");
                            }
                    }
                }
            }

            //Get rows that failed validation if any of the validation reported error
            if (validationResultCode.Any(r => r != 0))
            {
                response = GetRowsWithErrorFromStage(runStatusId, mappingTableInfo.Id);
            }

            return response;
        }

        private void WriteAudit(string userId, long mappingTableId, string action, int auditType, bool isValidationOverriden)
        {
            int returnCode = -1;

            using (OracleConnection oraConn = new OracleConnection(this.ConnectionString))
            using (OracleCommand oraAuditCommand = new OracleCommand())
            {
                oraConn.Open();
                using (OracleTransaction transaction = oraConn.BeginTransaction())
                {
                    try
                    {
                        oraAuditCommand.Connection = oraConn;
                        oraAuditCommand.CommandType = CommandType.StoredProcedure;
                        oraAuditCommand.CommandText = "MDMFRAMEWORK.SAVE_MAPPING_TABLE_AUDIT";

                        oraAuditCommand.Parameters.Add(new OracleParameter("@I_MAPPING_TABLE_ID", OracleDbType.Int64, mappingTableId, ParameterDirection.Input));
                        oraAuditCommand.Parameters.Add(new OracleParameter("@I_ACTION", OracleDbType.Varchar2, action, ParameterDirection.Input));
                        oraAuditCommand.Parameters.Add(new OracleParameter("@I_ACTION_USER_ID", OracleDbType.Varchar2, userId, ParameterDirection.Input));
                        oraAuditCommand.Parameters.Add(new OracleParameter("@I_AUDIT_TYPE", OracleDbType.Int64, auditType, ParameterDirection.Input));
                        oraAuditCommand.Parameters.Add(new OracleParameter("@I_IS_VALIDATION_OVERRIDDEN", OracleDbType.Varchar2, (isValidationOverriden == true ? "Y" : "N"), ParameterDirection.Input));
                        oraAuditCommand.ExecuteNonQuery();
                        transaction.Commit();

                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                    finally
                    {
                        oraConn.Close();
                    }
                }
            }
        }

        protected override VZ.CFO.MDMFramework.Contracts.Data.MappingTableMgmt.MappingTable[] OnGetAllMappingTables(string userId)
        {
            return GetMappingTableInfoCore(userId, 0);
        }

        protected override MappingTable OnGetMappingTableInfo(string userId, long mappingTableId)
        {
            MappingTable returnValue = null;
            var mappingTableInfo = GetMappingTableInfoCore(userId, mappingTableId);
            if (mappingTableInfo.Length == 1)
            {
                returnValue = mappingTableInfo[0];
            }
            return returnValue;
        }

        protected override VZ.CFO.MDMFramework.Contracts.Data.MappingTableMgmt.MappingTableDataPage OnGetMappingTable(string userId, long mappingTableId, int pageNumber, int rowsPerPage, int totalRecords)
        {
            return GetMappingTableData(userId, mappingTableId, pageNumber, rowsPerPage, totalRecords, MappingTableDataType.Save);
        }

        protected override VZ.CFO.MDMFramework.Contracts.Data.MappingTableMgmt.MappingTable OnGetMappingTable(string userId, long id, int rowsPerPage)
        {
            MappingTableDataPage mappingTableDataPage = OnGetMappingTable(userId, id, 1, rowsPerPage, 0);

            //Should we return mappingTable Info too? instead could we return the data alone?
            MappingTable mappingTable = new MappingTable()
            {
                Id = id,
                PagingInfo = mappingTableDataPage
            };

            return mappingTable;
        }

        protected override VZ.CFO.MDMFramework.Contracts.Data.MappingTableMgmt.AuditLogPage OnGetAuditDataPage(string userId, long mappingTableId, KnownValues.AuditType auditType, int pageNumber, int rowsPerPage, int totalRecords, string searchKey)
        {
            return GetAuditLogPageData(userId, mappingTableId, auditType, pageNumber, rowsPerPage, totalRecords, searchKey);
        }

        protected override VZ.CFO.MDMFramework.Contracts.Data.MappingTableMgmt.AuditLogPage OnGetAuditData(string userId, long mappingTableId, KnownValues.AuditType auditType, int rowsPerPage, string searchKey)
        {
            return GetAuditLogPageData(userId, mappingTableId, auditType, 1, rowsPerPage, 0, searchKey);
        }

        protected override MappingTableWriteResponse OnMigrateMappingValues(string userId, MappingTableWriteRequest writeRequest)
        {
            throw new NotImplementedException();
        }

        protected override MappingTableDataPage OnGetMappingTableAsync(string userId, long mappingTableId, int pageNumber, int rowsPerPage, int totalRecords)
        {
            return GetMappingTableData(userId, mappingTableId, pageNumber, rowsPerPage, totalRecords, MappingTableDataType.Save);
        }

        protected override string OnExportMappingTable(string userId, long mappingTableId)
        {
            throw new NotImplementedException();
        }

        protected override MappingTableWriteResponse OnSaveMappingTableData(string userId, MappingTable mappingTable, MappingTableWriteRequest writeRequest)
        {
            if (mappingTable == null)
            {
                //Get Mapping Table Info first
                var mappingTableInfo = GetMappingTableInfoCore(userId, writeRequest.MappingTableId);
                //Check if mapping Table Info is retreived
                if (mappingTableInfo.Length != 1)
                {
                    throw new Exception("Mapping Table Info could not be retreived.");
                }
                mappingTable = mappingTableInfo[0];
            }

            return WriteMappingData(userId, writeRequest.RunStatusId, mappingTable, MappingTableDataType.Save);
        }

        protected override MappingTableWriteResponse OnValidationMappingTableData(string userId, MappingTable mappingTable, MappingTableWriteRequest writeRequest)
        {
            if (mappingTable == null)
            {
                //Get Mapping Table Info first
                var mappingTableInfo = GetMappingTableInfoCore(userId, writeRequest.MappingTableId);
                //Check if mapping Table Info is retreived
                if (mappingTableInfo.Length != 1)
                {
                    throw new Exception("Mapping Table Info could not be retreived.");
                }
                mappingTable = mappingTableInfo[0];
            }

            MappingTableWriteResponse response = new MappingTableWriteResponse() { MappingTableId = mappingTable.Id };

            //Stage data for validation
            //long runStatusId = StageRowData(userId, mappingTableInfo[0], writeRequest);

            //Validate data
            response = Validate(userId, writeRequest.RunStatusId, mappingTable, MappingTableDataType.Save);

            //Return validation response
            return response;
        }

        protected override long OnStageMappingTableData(string userId, MappingTable mappingTable, MappingTableWriteRequest writeRequest)
        {
            //Stage data for validation
            return StageRowData(userId, mappingTable, writeRequest);
        }

        protected override long OnArchiveStageData(string userId, long runStatusId)
        {
            return ArchiveStageDataCore(userId, runStatusId);
        }

        protected override long OnStageFromChangeControl(string userId, MappingTable mappingTableInfo, MappingTableWriteRequest writeRequest)
        {
            return StageFromChangeControlCore(userId, mappingTableInfo, writeRequest);
        }

        protected override MappingTableWriteResponse OnValidateMappingTableMigrationData(string userId, MappingTable mappingTable, long runStatusId)
        {
            if (mappingTable == null)
            {
                //Get Mapping Table Info first
                var mappingTableInfo = GetMappingTableInfoCore(userId, mappingTable.Id);
                //Check if mapping Table Info is retreived
                if (mappingTableInfo.Length != 1)
                {
                    throw new Exception("Mapping Table Info could not be retreived.");
                }
                mappingTable = mappingTableInfo[0];
            }

            MappingTableWriteResponse response = new MappingTableWriteResponse() { MappingTableId = mappingTable.Id };

            //Stage data for validation
            //long runStatusId = StageRowData(userId, mappingTableInfo[0], writeRequest);

            //Validate data
            response = Validate(userId, runStatusId, mappingTable, MappingTableDataType.Migrate);

            //Return validation response
            return response;
        }

        protected override MappingTableWriteResponse OnMigrateMappingTableData(string userId, MappingTable mappingTable, MappingTableWriteRequest writeRequest)
        {
            if (mappingTable == null)
            {
                //Get Mapping Table Info first
                var mappingTableInfo = GetMappingTableInfoCore(userId, writeRequest.MappingTableId);
                //Check if mapping Table Info is retreived
                if (mappingTableInfo.Length != 1)
                {
                    throw new Exception("Mapping Table Info could not be retreived.");
                }
                mappingTable = mappingTableInfo[0];
            }

            return WriteMappingData(userId, writeRequest.RunStatusId, mappingTable, MappingTableDataType.Migrate);
        }

        protected override MappingTableDataPage OnGetMappingTableFromLowerEnvAsync(string userId, long mappingTableId, int pageNumber, int rowsPerPage, int totalRecords)
        {
            return GetMappingTableData(userId, mappingTableId, pageNumber, rowsPerPage, totalRecords, MappingTableDataType.Migrate);
        }

        protected override MappingTableDataPage OnGetMappingTableFromLowerEnv(string userId, long mappingTableId, int pageNumber, int rowsPerPage, int totalRecords)
        {
            return GetMappingTableData(userId, mappingTableId, pageNumber, rowsPerPage, totalRecords, MappingTableDataType.Migrate);
        }

        protected override MappingTable OnGetMappingTableFromLowerEnv(string userId, long id, int rowsPerPage)
        {
            MappingTableDataPage mappingTableDataPage = OnGetMappingTableFromLowerEnv(userId, id, 1, rowsPerPage, 0);

            //Should we return mappingTable Info too? instead could we return the data alone?
            MappingTable mappingTable = new MappingTable()
            {
                Id = id,
                PagingInfo = mappingTableDataPage
            };

            return mappingTable;
        }

        protected override void OnWriteMappingTableAuditLog(string userId, long mappingTableId, string action, int auditType, bool isValidationOverriden)
        {
            WriteAudit(userId, mappingTableId, action, auditType, isValidationOverriden);
        }

        protected override void OnUpdateLastValidated(string userId, long mappingTableId)
        {
            string query = "update mapping_table_list set last_validated_by = :last_validated_by, last_validated_on = SYSDATE where mapping_table_id = :mapping_table_id";
            List<OracleParameter> oracleParamList = new List<OracleParameter>();
            oracleParamList.Add(new OracleParameter("last_validated_by", OracleDbType.Varchar2, userId, ParameterDirection.Input));
            oracleParamList.Add(new OracleParameter("mapping_table_id", OracleDbType.Long, mappingTableId, ParameterDirection.Input));

            using (OracleConnection oraConn = new OracleConnection(this.ConnectionString))
            using (OracleCommand oraUpdateValidationCommand = new OracleCommand(query, oraConn))
            {
                try
                {
                    oraUpdateValidationCommand.Parameters.AddRange(oracleParamList.ToArray());
                    oraConn.Open();
                    var r = oraUpdateValidationCommand.ExecuteNonQuery();
                    oraConn.Close();
                }
                catch
                {
                    throw;
                }
                finally
                {
                    oraConn.Close();
                }
            }
        }
    }
}
