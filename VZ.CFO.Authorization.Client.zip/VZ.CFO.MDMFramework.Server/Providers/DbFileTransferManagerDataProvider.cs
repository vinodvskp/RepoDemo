﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA.FileTransfer;
using VZ.CFO.MDMFramework.Providers.Data;

namespace VZ.CFO.MDMFramework.Server.Providers
{
    public class DbFileTransferManagerDataProvider : FileTransferDataProvider
    {

        public DbFileTransferManagerDataProvider(string connectionString, string encryptionSalt)
            : base(connectionString, encryptionSalt)
        { }


        private Contracts.Data.MDUA.FileTransfer.FileTransferProfile[] GetFileTransferProfilesCore(string userId, long profileId)
        {
            List<FileTransferProfile> fileTransferProfileList = new List<FileTransferProfile>();

            string whereClause = profileId == 0 ? string.Empty : " where ft.profile_id = :profile_id ";

            string query = string.Format("with ftcore as " +
                    " (select profile_id, employee_id, role from ops_file_transfer mt, Web_Users where employee_id = :employee_id group by profile_id, employee_id, role) " +
                    " select c.profile_id, ft.profile_name, ft.default_file_name, ft.transfer_type, ft.target_dir, ft.upload_limit, ft.download_limit, ft.filter, ft.permission from ftcore c " +
                    " join ops_file_transfer ft on ft.profile_id = c.profile_id " +
                    " left join user_access ua on Ua.Accessobj_Type = 'FT' AND Ua.Accessobj_Id = c.profile_id AND ua.employee_id = c.Employee_Id " +
                    " {0} " +
                    " order by Ft.Profile_Name", whereClause);


            using (OracleConnection oraConn = new OracleConnection(this.ConnectionString))
            using (OracleCommand oraFTP = new OracleCommand(query, oraConn))
            {
                oraConn.Open();
                try
                {
                    oraFTP.BindByName = true;
                    oraFTP.CommandType = CommandType.Text;
                    oraFTP.Parameters.Add(new OracleParameter("employee_id", OracleDbType.Long, userId, ParameterDirection.Input));

                    if (profileId > 0)
                    {
                        oraFTP.Parameters.Add(new OracleParameter("profile_id", OracleDbType.Long, profileId, ParameterDirection.Input));
                    }

                    using (OracleDataReader reader = oraFTP.ExecuteReader())
                    {
                        int profileIdCol = reader.GetOrdinal("profile_id");
                        int profileNameCol = reader.GetOrdinal("profile_name");
                        int defNameCol = reader.GetOrdinal("default_file_name");
                        int transferTypeCol = reader.GetOrdinal("transfer_type");
                        int targetDirCol = reader.GetOrdinal("target_dir");
                        int uploadLimitCol = reader.GetOrdinal("upload_limit");
                        int downloadLimitCol = reader.GetOrdinal("download_limit");
                        int filterCol = reader.GetOrdinal("filter");
                        int permissionCol = reader.GetOrdinal("permission");

                        while (reader.Read())
                        {
                            var ftProfile = new FileTransferProfile();
                            ftProfile.ProfileId = reader.GetInt64(profileIdCol);
                            ftProfile.ProfileName = reader.GetString(profileNameCol);
                            ftProfile.DefaultFileName = (reader.IsDBNull(defNameCol) ? string.Empty : reader.GetString(defNameCol));
                            ftProfile.TransferType = (FileTransferKnownValues.FileTransferType)Convert.ToInt32(reader.GetString(transferTypeCol));
                            ftProfile.TargetDirectory = reader.GetString(targetDirCol);

                            if (!reader.IsDBNull(uploadLimitCol))
                                ftProfile.UploadLimit = reader.GetInt64(uploadLimitCol);
                            if (!reader.IsDBNull(downloadLimitCol))
                                ftProfile.DownloadLimit = reader.GetInt64(downloadLimitCol);
                            if (!reader.IsDBNull(filterCol))
                                ftProfile.Filter = reader.GetString(filterCol);
                            if (!reader.IsDBNull(permissionCol))
                                ftProfile.Permission = reader.GetInt32(permissionCol);

                            fileTransferProfileList.Add(ftProfile);
                        }
                    }
                }
                finally
                {
                    oraConn.Close();
                }
            }

            return fileTransferProfileList.ToArray();
        }


        protected override Contracts.Data.MDUA.FileTransfer.FileTransferProfile[] OnGetFileTransferProfiles(string userId)
        {
            return GetFileTransferProfilesCore(userId, 0);
        }

        protected override Contracts.Data.MDUA.FileTransfer.FileTransferResponse OnTransferFile(Contracts.Data.MDUA.FileTransfer.FileTransferRequest fileTransferRequest)
        {
            throw new NotImplementedException();
        }

        protected override FileTransferProfile OnGetFileTransferProfile(string userId, long profileId)
        {
            FileTransferProfile ftProfile = null;
            var profiles = GetFileTransferProfilesCore(userId, profileId);
            if (profiles.Length > 0)
            {
                ftProfile = profiles[0];
            }
            return ftProfile;
        }
    }
}
