﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Common;
using VZ.CFO.MDMFramework.Contracts.Data.Config;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables;
using System.Data;
using VZ.CFO.MDMFramework.Providers.Data;
using Oracle.ManagedDataAccess.Client;
using VZ.CFO.MDMFramework.Server.Util;
using VZ.CFO.MDMFramework.Contracts.Data;
using VZ.CFO.MDMFramework.Contracts.Service.MDUA;
namespace VZ.CFO.MDMFramework.Server.Providers
{
    public class DbFactTableManagerDataProvider : FactTableManagerDataProvider
    {
        private readonly int maxErrorRowsToDisplay = 1000;
        private IOpsStatusLogManager opsLogManager = null;
        private readonly Contracts.Data.Config.DbProfile[] dbProfileList;
        public DbFactTableManagerDataProvider(string connectionString, Contracts.Data.Config.DbProfile[] dbProfileList, string encryptionSalt, IOpsStatusLogManager opsLogManager)
            : base(connectionString, encryptionSalt)
        {
            this.dbProfileList = dbProfileList;
            this.opsLogManager = opsLogManager;
        }

        protected override FactTable[] OnGetAllFactTables(string userId)
        {
            List<FactTable> factTableList = new List<FactTable>();
            if (ValidationUtil.IsEmployeeValidate(userId) != true)
            {
                return factTableList.ToArray();
            }
            try
            {
                using (OracleConnection conn = new OracleConnection(this.ConnectionString))
                {
                    string factTableQuery = string.Format(@"select f.fact_table_id, f.fact_table_name, f.fact_table_desc, f.stage_table_year_name, f.stage_table_month_name, f.key_combo_table_name, f.allows_adjustments, f.repo_profile, f.fact_table_with_outline_values, f.VALIDATION_PROC from master_fact_table f where f.fact_table_type = 2  order by fact_table_desc");
                    string dimensionQuery = "select md.fact_table_id, md.stage_table_column_name, m.dimension_id, m.dimension_name, m.dimension_code, m.dimension_type, m.lookup_key, md.needs_validation, md.is_key_combo_field, md.dimension_type_name "
                                             + " from  map_dimension_fact_table md, master_dimension m "
                                             + " where m.DIMENSION_ID = md.DIMENSION_ID "
                                             + " and md.fact_table_id IN (SELECT FACT_TABLE_ID FROM MASTER_FACT_TABLE where fact_table_type = 2) "
                                             + " order by md.fact_table_id, m.dimension_name";
                    string customFieldQuery = "select c.fact_table_id, c.cust_att_name, c.description, c.cust_att_type, c.display_order from ops_fact_cust_att c where c.fact_table_id in (14,15,16)";
                    string autoMapQuery = "select md.fact_table_id, md.dimension_id, am.automap_id, am.description "
                                           + " from map_dimension_fact_table md, ops_map_fact_automap am "
                                           + " where md.fact_table_id = am.fact_table_id "
                                           + " and md.dimension_id = am.tgt_dimension_id "
                                           + " and md.fact_table_id in (SELECT FACT_TABLE_ID FROM MASTER_FACT_TABLE where fact_table_type = 2) "
                                           + " order by md.fact_table_id ";

                    DataSet ds = new DataSet();
                    OracleDataAdapter da = new OracleDataAdapter(factTableQuery, conn);
                    da.Fill(ds, "FactTable");

                    da = new OracleDataAdapter(dimensionQuery, conn);
                    da.Fill(ds, "DimensionTable");

                    da = new OracleDataAdapter(autoMapQuery, conn);
                    da.Fill(ds, "AutoMapTable");

                    da = new OracleDataAdapter(customFieldQuery, conn);
                    da.Fill(ds, "CustomFieldTable");

                    DataRelation dr = new DataRelation("FactTable_Dimensions",
                        ds.Tables["FactTable"].Columns["fact_table_id"],
                        ds.Tables["DimensionTable"].Columns["fact_table_id"]);
                    ds.Relations.Add(dr);

                    dr = new DataRelation("Dimensions_AutoMap",
                        new DataColumn[] { ds.Tables["DimensionTable"].Columns["fact_table_id"], ds.Tables["DimensionTable"].Columns["dimension_id"] },
                        new DataColumn[] { ds.Tables["AutoMapTable"].Columns["fact_table_id"], ds.Tables["AutoMapTable"].Columns["dimension_id"] });
                    ds.Relations.Add(dr);

                    dr = new DataRelation("FactTable_CustomFields",
                    ds.Tables["FactTable"].Columns["fact_table_id"],
                    ds.Tables["CustomFieldTable"].Columns["fact_table_id"]);
                    ds.Relations.Add(dr);

                    for (int i = 0; i < ds.Tables["FactTable"].Rows.Count; i++)
                    {
                        DataRow factTableRow = ds.Tables["FactTable"].Rows[i];
                        FactTable factTable = new FactTable();
                        factTable.Id = Convert.ToInt64(factTableRow["fact_table_id"]);
                        factTable.Name = Convert.ToString(factTableRow["fact_table_name"]);
                        factTable.YearlyUploadStageName = factTableRow["stage_table_year_name"].ToString();
                        factTable.MonthlyUploadStageName = factTableRow["stage_table_month_name"].ToString();
                        factTable.PhysicalTable = factTableRow["fact_table_with_outline_values"].ToString(); //what is this field?
                        factTable.FileTypeKeyComboTableName = factTableRow["key_combo_table_name"].ToString();
                        factTable.AllowAdjustments = factTableRow["allows_adjustments"].ToString().Trim().ToUpper().Equals("Y");
                        factTable.Description = Convert.ToString(factTableRow["fact_table_desc"]);
                        factTable.RepoProfile = factTableRow["repo_profile"].ToString();
                        factTable.ValidationProc = factTableRow["VALIDATION_PROC"].ToString();
                        factTableList.Add(factTable);
                        List<FactDimension> factDimensions = new List<FactDimension>();
                        foreach (DataRow dimensionRow in factTableRow.GetChildRows("FactTable_Dimensions"))
                        {
                            FactDimension factDimension = new FactDimension();
                            factDimension.Code = dimensionRow["dimension_code"].ToString();
                            factDimension.Id = Convert.ToInt64(dimensionRow["dimension_id"]);
                            factDimension.StageTableColumnName = dimensionRow["stage_table_column_name"].ToString();
                            factDimension.FactColumnName = dimensionRow["dimension_type_name"].ToString();
                            factDimension.Name = dimensionRow["dimension_name"].ToString();
                            factDimension.Type = dimensionRow["dimension_type"].ToString();
                            factDimension.LookupKey = dimensionRow["lookup_key"].ToString();
                            factDimension.IsKeyComboField = dimensionRow["is_key_combo_field"].ToString().Trim().ToUpper().Equals("Y");
                            factDimension.NeedsValidation = dimensionRow["needs_validation"].ToString().Trim().ToUpper().Equals("Y");

                            List<FactDimensionDataSource> availableDataSources = new List<FactDimensionDataSource>();
                            FactDimensionDataSource defaultDataSource = new FactDimensionDataSource();
                            defaultDataSource.DataSourceType = FactTableKnownValues.FactColumnDataSourceType.DataFromUserFeed;
                            defaultDataSource.Description = "Data From User Feed";
                            availableDataSources.Add(defaultDataSource);

                            defaultDataSource = new FactDimensionDataSource();
                            defaultDataSource.DataSourceType = FactTableKnownValues.FactColumnDataSourceType.ForcedValue;
                            defaultDataSource.Description = "Forced Value";
                            availableDataSources.Add(defaultDataSource);

                            defaultDataSource = new FactDimensionDataSource();
                            defaultDataSource.DataSourceType = FactTableKnownValues.FactColumnDataSourceType.UserDefinable;
                            defaultDataSource.Description = "User Definable";
                            availableDataSources.Add(defaultDataSource);

                            foreach (DataRow automapRow in dimensionRow.GetChildRows("Dimensions_AutoMap"))
                            {
                                FactDimensionDataSource dataSource = new FactDimensionDataSource();
                                dataSource.Description = automapRow["description"].ToString();
                                dataSource.AutomapId = (automapRow["automap_id"] == DBNull.Value ? (long?)null : Convert.ToInt64(automapRow["automap_id"]));
                                dataSource.DataSourceType = FactTableKnownValues.FactColumnDataSourceType.AutoMap;
                                availableDataSources.Add(dataSource);
                            }
                            factDimension.AvailableDataSources = availableDataSources.ToArray();
                            factDimensions.Add(factDimension);
                        }

                        List<CustomField> customFields = new List<CustomField>();
                        foreach (DataRow customFieldRow in factTableRow.GetChildRows("FactTable_CustomFields"))
                        {
                            CustomField cField = new CustomField();
                            cField.Id = Convert.ToInt64(customFieldRow["cust_att_id"]);
                            cField.Name = customFieldRow["cust_att_name"].ToString();
                            cField.Type = customFieldRow["cust_att_type"].ToString();
                            cField.DisplayOrder = Convert.ToInt32(customFieldRow["display_order"]);
                            customFields.Add(cField);
                        }
                        factTable.AvailableDimensions = factDimensions.ToArray();
                        factTable.AvailableCustomFields = customFields.ToArray();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return factTableList.ToArray();
        }

        protected override FactTable[] OnGetFactFileTypesBasic(string employeeId)
        {
            List<FactTable> factTableList = new List<FactTable>();
            if (ValidationUtil.IsEmployeeValidate(employeeId) != true)
            {
                return factTableList.ToArray();
            }

            string query = "select f.fact_table_id, f.fact_table_name, f.fact_table_type, ft.input_file_code_id, ft.input_file_code, ft.description, ft.is_adjustment, ft.is_13month, ft.is_outlook, ft.is_user_feed, ft.uses_valid_keys, ft.show_on_upload_status from Master_Fact_Table f " +
                                         " join Ops_File_Types ft on f.fact_table_id = ft.fact_table_id " +
                                         " join Ops_user_input_file_access fa on ft.Input_File_Code_Id = fa.Input_File_Code_Id and Fa.Input_File_Code_Id IS NOT NULL " +
                                         " where F.Fact_Table_Type = 2 and fa.employee_id = :employeeId" +
                                         " order by fact_table_name, input_file_code ";

            Dictionary<long, List<FactFileType>> factTableDiction = new Dictionary<long, List<FactFileType>>();

            using (OracleConnection conn = new OracleConnection(this.ConnectionString))
            using (OracleCommand cmd = new OracleCommand(query, conn))
            {
                // Fortify begin
                cmd.BindByName = true;
                if (string.IsNullOrEmpty(employeeId) == false)
                {
                    OracleParameter p1 = new Oracle.ManagedDataAccess.Client.OracleParameter("employeeId", employeeId);
                    cmd.Parameters.Add(p1);
                }
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = query;
                // Fortify end 
                conn.Open();
                try
                {
                    using (OracleDataReader dataReader = cmd.ExecuteReader())
                    {
                        int factTableIdCol = dataReader.GetOrdinal("fact_table_id");
                        int factNameCol = dataReader.GetOrdinal("fact_table_name");
                        int factTypeCol = dataReader.GetOrdinal("fact_table_type");
                        int fileTypeIdCol = dataReader.GetOrdinal("input_file_code_id");
                        int filTypeCodeCol = dataReader.GetOrdinal("input_file_code");
                        int descCol = dataReader.GetOrdinal("description");

                        int isAdjCol = dataReader.GetOrdinal("is_adjustment");
                        int is13MCol = dataReader.GetOrdinal("is_13month");
                        int isOutlookCol = dataReader.GetOrdinal("is_outlook");
                        int isUserFeedCol = dataReader.GetOrdinal("is_user_feed");
                        int useValidKeysCol = dataReader.GetOrdinal("uses_valid_keys");
                        int showUploadStatusCol = dataReader.GetOrdinal("show_on_upload_status");


                        while (dataReader.Read())
                        {
                            var factTableId = dataReader.GetInt64(factTableIdCol);
                            var fileType = new FactFileType()
                            {
                                FactTableId = factTableId,
                                FileTypeCodeId = (dataReader.IsDBNull(fileTypeIdCol) ? 0 : dataReader.GetInt64(fileTypeIdCol)),
                                Description = dataReader.GetString(descCol),
                                Code = dataReader.GetString(filTypeCodeCol),
                                Contains13ColFacts = (dataReader.IsDBNull(is13MCol) == true || dataReader.GetString(is13MCol) == "N") ? false : true,
                                IsAdjustment = (dataReader.IsDBNull(isAdjCol) == true || dataReader.GetString(isAdjCol) == "N") ? false : true,
                                IsOutlook = (dataReader.IsDBNull(isOutlookCol) == true || dataReader.GetString(isOutlookCol) == "N") ? false : true,
                                IsUserFeed = (dataReader.IsDBNull(isUserFeedCol) == true || dataReader.GetString(isUserFeedCol) == "N") ? false : true,
                                UsesValidKeyCombo = (dataReader.IsDBNull(useValidKeysCol) == true || dataReader.GetString(useValidKeysCol) == "N") ? false : true,
                                ShowStatus = (dataReader.IsDBNull(showUploadStatusCol) == true || dataReader.GetString(showUploadStatusCol) == "N") ? false : true
                            };


                            var factTableFind = factTableList.FirstOrDefault(f => f.Id == factTableId);

                            if (factTableFind == null)
                            {
                                var factTableName = dataReader.GetString(factNameCol);
                                var factTableType = (dataReader.IsDBNull(fileTypeIdCol) ? 1 : dataReader.GetInt32(factTypeCol));
                                var factTable = new FactTable
                                {
                                    Id = factTableId,
                                    Name = factTableName,
                                    FactTableType = (FactTableKnownValues.FactTableType)factTableType
                                };
                                factTableList.Add(factTable);
                                factTableDiction.Add(factTableId, new List<FactFileType>() { fileType });
                            }
                            else
                            {
                                factTableDiction[factTableId].Add(fileType);
                            }
                        }
                        dataReader.Close();
                    }

                }
                catch (Exception e)
                {
                    throw;
                }
                finally
                {
                    conn.Close();
                }

                foreach (var factTableId in factTableDiction.Keys)
                {
                    var factTableFind = factTableList.FirstOrDefault(f => f.Id == factTableId);
                    if (factTableFind != null)
                    {
                        factTableFind.FileTypes = factTableDiction[factTableId].ToArray();
                    }
                }

                return factTableList.ToArray();
            }
        }

        protected override FactFileType[] OnGetFactFileTypes(string userId, long factTableId)
        {

            List<FactFileType> fileTypes = new List<FactFileType>();
            if (ValidationUtil.IsEmployeeValidate(userId) != true)
            {
                return fileTypes.ToArray();
            }

            try
            {
                using (OracleConnection conn = new OracleConnection(this.ConnectionString))
                {
                    string factFileTypeQuery = string.Format(
                       @"select l.input_file_code_id, l.input_file_code, l.description, l.dest_table, l.fact_table_id, l.is_adjustment, l.is_13month, l.is_user_feed, l.uses_valid_keys,
                       l.is_outlook, l.show_on_upload_status, l.scheduled_load_date
                       from ops_file_types l inner join ops_user_input_file_access a on l.input_file_code_id = a.input_file_code_id
                       where l.fact_table_id = {0} and a.employee_id =:employee_id", factTableId);

                    string factFileTypeFields = string.Format(@"select t.input_file_code_id, t.input_file_code, f.input_file_field_id, f.automap_id, f.dimension_id, f.forced_value, f.datasrc_type, md.needs_validation
                        from ops_file_types t inner join ops_user_input_file_access a on t.input_file_code_id = a.input_file_code_Id
                        inner join ops_file_type_fields f on t.input_file_code_id = f.input_file_code_id
                        inner join map_dimension_fact_table md on md.fact_table_id = t.fact_table_id and md.dimension_id = f.dimension_id
                        where t.FACT_TABLE_ID = {0} and a.employee_id =:employee_id order by t.input_file_code_id, f.dimension_id ", factTableId
                    );

                    string factFileTypeCustomFields = string.Format(@"select c.cust_att_id, c.cust_att_name, c.description, c.cust_att_type, c.display_order,
                       cv.cust_att_value_id, cv.input_file_code_id, cv.cust_att_value
                        from ops_fact_cust_att c, ops_fact_cust_att_values cv
                        where c.cust_att_id = cv.cust_att_id
                        and c.fact_table_id ={0}", factTableId
                    );
                    DataSet ds = new DataSet();
                    OracleDataAdapter da = new OracleDataAdapter(factFileTypeQuery, conn);
                    da.SelectCommand.Parameters.Add("employee_id", OracleDbType.Varchar2, 20, userId, ParameterDirection.Input);
                    da.Fill(ds, "FileTypeTable");

                    da = new OracleDataAdapter(factFileTypeFields, conn);
                    da.SelectCommand.Parameters.Add("employee_id", OracleDbType.Varchar2, 20, userId, ParameterDirection.Input);
                    da.Fill(ds, "FileTypeFieldTable");

                    da = new OracleDataAdapter(factFileTypeCustomFields, conn);
                    da.Fill(ds, "FileTypeCustomFieldTable");

                    DataRelation dr = new DataRelation("FileType_FileFields",
                        ds.Tables["FileTypeTable"].Columns["input_file_code_id"],
                        ds.Tables["FileTypeFieldTable"].Columns["input_file_code_id"]);
                    ds.Relations.Add(dr);

                    dr = new DataRelation("FileType_FileCustomFields",
                       ds.Tables["FileTypeTable"].Columns["input_file_code_id"],
                       ds.Tables["FileTypeCustomFieldTable"].Columns["input_file_code_id"]);
                    ds.Relations.Add(dr);

                    for (int i = 0; i < ds.Tables["FileTypeTable"].Rows.Count; i++)
                    {
                        DataRow factFileTypeRow = ds.Tables["FileTypeTable"].Rows[i];
                        FactFileType factFileType = new FactFileType();
                        factFileType.Code = factFileTypeRow["input_file_code"].ToString();
                        factFileType.Description = Convert.ToString(factFileTypeRow["description"]);
                        factFileType.FileTypeCodeId = Convert.ToInt64(factFileTypeRow["input_file_code_id"]);
                        factFileType.FactTableId = factTableId;
                        factFileType.Contains13ColFacts = factFileTypeRow["is_13month"].ToString().Trim().ToUpper().Equals("Y");
                        factFileType.IsAdjustment = factFileTypeRow["is_adjustment"].ToString().Trim().ToUpper().Equals("Y");
                        factFileType.IsUserFeed = factFileTypeRow["is_user_feed"].ToString().Trim().ToUpper().Equals("Y");
                        factFileType.ScheduledLoadDate = factFileTypeRow["scheduled_load_date"].ToString();
                        factFileType.ShowStatus = factFileTypeRow["show_on_upload_status"].ToString().Trim().ToUpper().Equals("Y");
                        factFileType.UsesValidKeyCombo = factFileTypeRow["uses_valid_keys"].ToString().Trim().ToUpper().Equals("Y");
                        fileTypes.Add(factFileType);
                        List<FileTypeDimension> factDimensions = new List<FileTypeDimension>();
                        foreach (DataRow dimensionRow in factFileTypeRow.GetChildRows("FileType_FileFields"))
                        {
                            FileTypeDimension factDimension = new FileTypeDimension();

                            factDimension.Id = Convert.ToInt64(dimensionRow["dimension_id"]);
                            factDimension.SelectedDataSource = new FileTypeDimensionDataSource();
                            factDimension.SelectedDataSource.FileFieldId = Convert.ToInt64(dimensionRow["input_file_field_id"]);
                            factDimension.SelectedDataSource.ForcedValue = dimensionRow["forced_value"] == DBNull.Value ? "" : dimensionRow["forced_value"].ToString();
                            factDimension.SelectedDataSource.DataSourceType = (FactTableKnownValues.FactColumnDataSourceType)(Convert.ToInt32(dimensionRow["datasrc_type"]));
                            factDimension.NeedsValidation = dimensionRow["needs_validation"].ToString().Trim().ToUpper().Equals("Y");
                            if (dimensionRow["automap_id"] != DBNull.Value)
                            {
                                factDimension.SelectedDataSource.AutomapId = Convert.ToInt64(dimensionRow["automap_id"]);
                            }
                            factDimensions.Add(factDimension);
                        }
                        List<CustomFieldValue> customFields = new List<CustomFieldValue>();
                        foreach (DataRow customFieldRow in factFileTypeRow.GetChildRows("FileType_FileCustomFields"))
                        {
                            CustomFieldValue cField = new CustomFieldValue();
                            cField.Id = Convert.ToInt64(customFieldRow["cust_att_value_id"]);
                            cField.CustomFieldId = Convert.ToInt64(customFieldRow["cust_att_id"]);
                            cField.FileTypeCodeId = Convert.ToInt64(customFieldRow["input_file_code_id"]);
                            cField.Value = customFieldRow["cust_att_value"].ToString();
                            customFields.Add(cField);
                        }

                        factFileType.FileTypeDimensions = factDimensions.ToArray();
                        factFileType.FileTypeCustomFields = customFields.ToArray();
                    }

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return fileTypes.ToArray();
        }

        protected override FactFileType OnGetFactFileType(string userId, FileTypeRequest fileTypeRequest)
        {
            FactFileType factFileType = null;
            try
            {
                using (OracleConnection conn = new OracleConnection(this.ConnectionString))
                {
                    string factFileTypeQuery = string.Format(
                       @"select l.input_file_code_id, l.input_file_code, l.description, l.dest_table, l.fact_table_id, l.is_adjustment, l.is_13month, l.is_user_feed, l.uses_valid_keys,
                       l.is_outlook, l.show_on_upload_status, l.scheduled_load_date
                       from ops_file_types l where l.fact_table_id = {0} and l.input_file_code_id = {1}", fileTypeRequest.FactTableId, fileTypeRequest.FileTypeCodeId);

                    string factFileTypeFields = string.Format(@"select t.input_file_code_id, t.input_file_code, m.dimension_name, m.dimension_code, m.dimension_type, m.lookup_key, f.input_file_field_id, f.automap_id, f.dimension_id, f.forced_value, f.datasrc_type, md.needs_validation
                        from ops_file_types t inner join ops_file_type_fields f on t.input_file_code_id = f.input_file_code_id
                        inner join map_dimension_fact_table md on md.fact_table_id = t.fact_table_id and md.dimension_id = f.dimension_id                        
                        left join master_dimension m on f.dimension_id = m.dimension_id
                        where t.FACT_TABLE_ID = {0} and t.input_file_code_id = {1}", fileTypeRequest.FactTableId, fileTypeRequest.FileTypeCodeId
                    );

                    string factFileTypeCustomFields = string.Format(@"select c.cust_att_id, c.cust_att_name, c.description, c.cust_att_type, c.display_order,
                        cust_att_value_id, cv.input_file_code_id, cv.cust_att_value
                        from ops_fact_cust_att c, ops_fact_cust_att_values cv
                        where c.cust_att_id = cv.cust_att_id
                        and c.fact_table_id ={0} and cv.input_file_code_id = {1}", fileTypeRequest.FactTableId, fileTypeRequest.FileTypeCodeId
                    );
                    DataSet ds = new DataSet();
                    OracleDataAdapter da = new OracleDataAdapter(factFileTypeQuery, conn);
                    da.Fill(ds, "FileTypeTable");

                    da = new OracleDataAdapter(factFileTypeFields, conn);
                    da.Fill(ds, "FileTypeFieldTable");

                    da = new OracleDataAdapter(factFileTypeCustomFields, conn);
                    da.Fill(ds, "FileTypeCustomFieldTable");

                    DataRelation dr = new DataRelation("FileType_FileFields",
                        ds.Tables["FileTypeTable"].Columns["input_file_code_id"],
                        ds.Tables["FileTypeFieldTable"].Columns["input_file_code_id"]);
                    ds.Relations.Add(dr);

                    dr = new DataRelation("FileType_FileCustomFields",
                       ds.Tables["FileTypeTable"].Columns["input_file_code_id"],
                       ds.Tables["FileTypeCustomFieldTable"].Columns["input_file_code_id"]);
                    ds.Relations.Add(dr);

                    if (ds.Tables["FileTypeTable"].Rows.Count == 1)
                    {
                        DataRow factFileTypeRow = ds.Tables["FileTypeTable"].Rows[0];
                        factFileType = new FactFileType();
                        factFileType.Code = factFileTypeRow["input_file_code"].ToString();
                        factFileType.Description = Convert.ToString(factFileTypeRow["description"]);
                        factFileType.FileTypeCodeId = Convert.ToInt64(factFileTypeRow["input_file_code_id"]);
                        factFileType.FactTableId = fileTypeRequest.FactTableId;
                        factFileType.Contains13ColFacts = factFileTypeRow["is_13month"].ToString().Trim().ToUpper().Equals("Y");
                        factFileType.IsAdjustment = factFileTypeRow["is_adjustment"].ToString().Trim().ToUpper().Equals("Y");
                        factFileType.IsUserFeed = factFileTypeRow["is_user_feed"].ToString().Trim().ToUpper().Equals("Y");
                        factFileType.ScheduledLoadDate = factFileTypeRow["scheduled_load_date"].ToString();
                        factFileType.ShowStatus = factFileTypeRow["show_on_upload_status"].ToString().Trim().ToUpper().Equals("Y");
                        factFileType.UsesValidKeyCombo = factFileTypeRow["uses_valid_keys"].ToString().Trim().ToUpper().Equals("Y");

                        List<FileTypeDimension> factDimensions = new List<FileTypeDimension>();
                        foreach (DataRow dimensionRow in factFileTypeRow.GetChildRows("FileType_FileFields"))
                        {
                            FileTypeDimension factDimension = new FileTypeDimension();

                            factDimension.Id = Convert.ToInt64(dimensionRow["dimension_id"]);

                            factDimension.SelectedDataSource = new FileTypeDimensionDataSource();
                            factDimension.NeedsValidation = dimensionRow["needs_validation"].ToString().Trim().ToUpper().Equals("Y");
                            factDimension.SelectedDataSource.FileFieldId = Convert.ToInt64(dimensionRow["input_file_field_id"]);
                            factDimension.SelectedDataSource.ForcedValue = dimensionRow["forced_value"] == DBNull.Value ? "" : dimensionRow["forced_value"].ToString();
                            factDimension.SelectedDataSource.DataSourceType = (FactTableKnownValues.FactColumnDataSourceType)(Convert.ToInt32(dimensionRow["datasrc_type"]));
                            if (dimensionRow["automap_id"] != DBNull.Value)
                            {
                                factDimension.SelectedDataSource.AutomapId = Convert.ToInt64(dimensionRow["automap_id"]);
                            }
                            factDimensions.Add(factDimension);
                        }
                        List<CustomFieldValue> customFields = new List<CustomFieldValue>();
                        foreach (DataRow customFieldRow in factFileTypeRow.GetChildRows("FileType_FileCustomFields"))
                        {
                            CustomFieldValue cField = new CustomFieldValue();
                            cField.Id = Convert.ToInt64(customFieldRow["cust_att_value_id"]);
                            cField.CustomFieldId = Convert.ToInt64(customFieldRow["cust_att_id"]);
                            cField.FileTypeCodeId = Convert.ToInt64(customFieldRow["input_file_code_id"]);
                            cField.Value = customFieldRow["cust_att_value"].ToString();
                            customFields.Add(cField);
                        }

                        factFileType.FileTypeDimensions = factDimensions.ToArray();
                        factFileType.FileTypeCustomFields = customFields.ToArray();
                    }

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return factFileType;
        }
        protected override FactTable OnGetFactTable(string userId, long factTableId)
        {
            FactTable factTable = null;
            try
            {
                using (OracleConnection conn = new OracleConnection(this.ConnectionString))
                {
                    string factTableQuery = string.Format(@"select f.fact_table_id, f.fact_table_name, f.fact_table_desc, f.stage_table_year_name, f.stage_table_month_name, f.key_combo_table_name, f.allows_adjustments, f.fact_table_with_outline_values, f.repo_profile, f.VALIDATION_PROC from master_fact_table f where f.fact_table_id = {0} and f.fact_table_type = 2  order by fact_table_desc", factTableId);
                    string dimensionQuery = string.Format(@"select md.fact_table_id, md.stage_table_column_name, m.dimension_id, m.dimension_name, m.dimension_code, m.dimension_type, m.lookup_key, md.needs_validation, md.is_key_combo_field, md.dimension_type_name "
                                             + " from  map_dimension_fact_table md, master_dimension m "
                                             + " where m.DIMENSION_ID = md.DIMENSION_ID "
                                             + " and md.fact_table_id = {0} "
                                             + " order by md.fact_table_id, m.dimension_name", factTableId);
                    string customFieldQuery = string.Format(@"select c.fact_table_id, c.cust_att_name, c.description, c.cust_att_type, c.display_order from ops_fact_cust_att c where c.fact_table_id = {0}", factTableId);
                    string autoMapQuery = string.Format(@"select md.fact_table_id, md.dimension_id, am.automap_id, am.description "
                                           + " from map_dimension_fact_table md, ops_map_fact_automap am "
                                           + " where md.fact_table_id = am.fact_table_id "
                                           + " and md.dimension_id = am.tgt_dimension_id "
                                           + " and md.fact_table_id = {0} "
                                           + " order by md.fact_table_id ", factTableId);

                    DataSet ds = new DataSet();
                    OracleDataAdapter da = new OracleDataAdapter(factTableQuery, conn);
                    da.Fill(ds, "FactTable");

                    da = new OracleDataAdapter(dimensionQuery, conn);
                    da.Fill(ds, "DimensionTable");

                    da = new OracleDataAdapter(autoMapQuery, conn);
                    da.Fill(ds, "AutoMapTable");

                    da = new OracleDataAdapter(customFieldQuery, conn);
                    da.Fill(ds, "CustomFieldTable");

                    DataRelation dr = new DataRelation("FactTable_Dimensions",
                        ds.Tables["FactTable"].Columns["fact_table_id"],
                        ds.Tables["DimensionTable"].Columns["fact_table_id"]);
                    ds.Relations.Add(dr);

                    dr = new DataRelation("Dimensions_AutoMap",
                        new DataColumn[] { ds.Tables["DimensionTable"].Columns["fact_table_id"], ds.Tables["DimensionTable"].Columns["dimension_id"] },
                        new DataColumn[] { ds.Tables["AutoMapTable"].Columns["fact_table_id"], ds.Tables["AutoMapTable"].Columns["dimension_id"] });
                    ds.Relations.Add(dr);

                    dr = new DataRelation("FactTable_CustomFields",
                    ds.Tables["FactTable"].Columns["fact_table_id"],
                    ds.Tables["CustomFieldTable"].Columns["fact_table_id"]);
                    ds.Relations.Add(dr);

                    if (ds.Tables["FactTable"].Rows.Count == 1)
                    {
                        DataRow factTableRow = ds.Tables["FactTable"].Rows[0];
                        factTable = new FactTable();
                        factTable.Id = Convert.ToInt64(factTableRow["fact_table_id"]);
                        factTable.Name = Convert.ToString(factTableRow["fact_table_name"]);
                        factTable.YearlyUploadStageName = factTableRow["stage_table_year_name"].ToString();
                        factTable.MonthlyUploadStageName = factTableRow["stage_table_month_name"].ToString();
                        factTable.PhysicalTable = factTableRow["fact_table_with_outline_values"].ToString(); //what is this field?
                        factTable.FileTypeKeyComboTableName = factTableRow["key_combo_table_name"].ToString();
                        factTable.AllowAdjustments = factTableRow["allows_adjustments"].ToString().Trim().ToUpper().Equals("Y");
                        factTable.Description = Convert.ToString(factTableRow["fact_table_desc"]);
                        factTable.RepoProfile = factTableRow["repo_profile"].ToString();
                        factTable.ValidationProc = factTableRow["VALIDATION_PROC"].ToString();

                        List<FactDimension> factDimensions = new List<FactDimension>();
                        foreach (DataRow dimensionRow in factTableRow.GetChildRows("FactTable_Dimensions"))
                        {
                            FactDimension factDimension = new FactDimension();
                            factDimension.Code = dimensionRow["dimension_code"].ToString();
                            factDimension.Id = Convert.ToInt64(dimensionRow["dimension_id"]);
                            factDimension.StageTableColumnName = dimensionRow["stage_table_column_name"].ToString();
                            factDimension.Name = dimensionRow["dimension_name"].ToString();
                            factDimension.Type = dimensionRow["dimension_type"].ToString();
                            factDimension.LookupKey = dimensionRow["lookup_key"].ToString();
                            factDimension.FactColumnName = dimensionRow["dimension_type_name"].ToString();

                            factDimension.IsKeyComboField = dimensionRow["is_key_combo_field"].ToString().Trim().ToUpper().Equals("Y");
                            factDimension.NeedsValidation = dimensionRow["needs_validation"].ToString().Trim().ToUpper().Equals("Y");

                            List<FactDimensionDataSource> availableDataSources = new List<FactDimensionDataSource>();
                            FactDimensionDataSource defaultDataSource = new FactDimensionDataSource();
                            defaultDataSource.DataSourceType = FactTableKnownValues.FactColumnDataSourceType.DataFromUserFeed;
                            defaultDataSource.Description = "Data From User Feed";
                            availableDataSources.Add(defaultDataSource);

                            defaultDataSource = new FactDimensionDataSource();
                            defaultDataSource.DataSourceType = FactTableKnownValues.FactColumnDataSourceType.ForcedValue;
                            defaultDataSource.Description = "Forced Value";
                            availableDataSources.Add(defaultDataSource);

                            defaultDataSource = new FactDimensionDataSource();
                            defaultDataSource.DataSourceType = FactTableKnownValues.FactColumnDataSourceType.UserDefinable;
                            defaultDataSource.Description = "User Definable";
                            availableDataSources.Add(defaultDataSource);

                            foreach (DataRow automapRow in dimensionRow.GetChildRows("Dimensions_AutoMap"))
                            {
                                FactDimensionDataSource dataSource = new FactDimensionDataSource();
                                dataSource.Description = automapRow["description"].ToString();
                                dataSource.AutomapId = (automapRow["automap_id"] == DBNull.Value ? (long?)null : Convert.ToInt64(automapRow["automap_id"]));
                                dataSource.DataSourceType = FactTableKnownValues.FactColumnDataSourceType.AutoMap;
                                availableDataSources.Add(dataSource);
                            }
                            factDimension.AvailableDataSources = availableDataSources.ToArray();
                            factDimensions.Add(factDimension);
                        }

                        List<CustomField> customFields = new List<CustomField>();
                        foreach (DataRow customFieldRow in factTableRow.GetChildRows("FactTable_CustomFields"))
                        {
                            CustomField cField = new CustomField();
                            cField.Id = Convert.ToInt64(customFieldRow["cust_att_id"]);
                            cField.Name = customFieldRow["cust_att_name"].ToString();
                            cField.Type = customFieldRow["cust_att_type"].ToString();
                            cField.DisplayOrder = Convert.ToInt32(customFieldRow["display_order"]);
                            customFields.Add(cField);
                        }
                        factTable.AvailableDimensions = factDimensions.ToArray();
                        factTable.AvailableCustomFields = customFields.ToArray();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return factTable;
        }


        protected override FileTypeResponse OnDeleteFileType(string userId, FileTypeRequest fileTypeRequest)
        {
            FileTypeResponse response = new FileTypeResponse();
            using (OracleConnection conn = new OracleConnection(this.ConnectionString))
            using (OracleCommand cmdDelete = new OracleCommand())
            {
                conn.Open();
                cmdDelete.Connection = conn;

                using (OracleTransaction transaction = conn.BeginTransaction())
                {
                    try
                    {
                        //delete the rows marked for deletion first
                        response = DeleteFileType(userId, fileTypeRequest, cmdDelete);
                        transaction.Commit();
                        opsLogManager.LogEvent(userId, "OnDeleteFileType", string.Format("Delete file type - {0} {1}", fileTypeRequest.FactTableId, fileTypeRequest.FileTypeCodeId), "Success", Contracts.Data.MDUA.UserToolLogLevel.Audit);
                    }
                    catch (OracleException oex)
                    {
                        transaction.Rollback();

                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
            return response;
        }

        protected override FileTypeResponse OnSaveFileType(string userId, FactFileType factFileType)
        {
            FileTypeResponse response = new FileTypeResponse();
            response.FileTypeCodeId = factFileType.FileTypeCodeId;
            if (string.IsNullOrEmpty(factFileType.Code))
            {
                response.Status = 1;
                response.Message = "You must supply a file type.";
                return response;
            }

            factFileType.Code = factFileType.Code.ToUpper();

            if (string.IsNullOrEmpty(factFileType.Description))
            {
                response.Status = 1;
                response.Message = "You must supply a description for the file type.";
                return response;
            }

            if (factFileType.IsUserFeed)
            {
                if (factFileType.Code.IndexOf("ADJ") == -1 && factFileType.Code.IndexOf("USR") == -1)
                {
                    response.Status = 1;
                    response.Message = "The File Type Code must contain either ADJ or USR for a user feed.";
                    return response;
                }
            }
            else
            {
                if (factFileType.Code.IndexOf("ADJ") >= 0 || factFileType.Code.IndexOf("USR") >= 0)
                {
                    response.Status = 1;
                    response.Message = "The Input File Code cannot contain either ADJ or USR for NON user feeds.";
                    return response;
                }
            }
            //check if a particular file type is existing
            long? fileTypeCodeId = IsFileTypeExisted(factFileType.FactTableId, factFileType.Code);
            FactTable factTable = this.OnGetFactTable(userId, factFileType.FactTableId);
            if (factTable == null)
            {
                response.Status = 1;
                response.Message = "Fact table with id " + factFileType.FactTableId + " not found.";
                return response;
            }

            //check if dimensions are missing
            string checkDimensionMessage = string.Empty;
            foreach (FactDimension dimension in factTable.AvailableDimensions)
            {
                var foundDimension = factFileType.FileTypeDimensions.First(item => item.Id == dimension.Id);
                if (foundDimension == null)
                {
                    checkDimensionMessage = checkDimensionMessage + dimension.Name + ",";
                }
            }
            if (!string.IsNullOrEmpty(checkDimensionMessage))
            {
                response.Status = 1;
                response.Message = "Missing dimensions -" + checkDimensionMessage.TrimEnd(',');
                return response;
            }

            string checkDataSourceType = string.Empty;
            foreach (FileTypeDimension dimension in factFileType.FileTypeDimensions)
            {
                FactDimension factDim = factTable.AvailableDimensions.First(item => item.Id == dimension.Id);
                if (factDim != null)
                {
                    var foundDataSource = factDim.AvailableDataSources.First(item => item.DataSourceType == dimension.SelectedDataSource.DataSourceType);
                    if (foundDataSource == null)
                    {
                        checkDataSourceType = checkDataSourceType + factDim.Name + ",";
                    }
                }

            }
            if (!string.IsNullOrEmpty(checkDataSourceType))
            {
                response.Status = 1;
                response.Message = "unknown data source types sent for these dimensions - " + checkDataSourceType.TrimEnd(',');
                return response;
            }

            //validate automap and forced value options on dimensions
            List<string> forcedValueDimensionValidation = new List<string>();

            foreach (FileTypeDimension dimension in factFileType.FileTypeDimensions)
            {
                if (dimension.SelectedDataSource.DataSourceType == FactTableKnownValues.FactColumnDataSourceType.AutoMap && (dimension.SelectedDataSource.AutomapId == 0 || dimension.SelectedDataSource.AutomapId == null))
                {
                    response.Status = 1;
                    response.Message = "One or more dimension with Automap selected, but no automap id is given.";
                    return response;
                }
                if (dimension.SelectedDataSource.DataSourceType == FactTableKnownValues.FactColumnDataSourceType.ForcedValue)
                {
                    if (string.IsNullOrEmpty(dimension.SelectedDataSource.ForcedValue))
                    {
                        response.Status = 1;
                        response.Message = "One or more dimension with Forced Value selected, but no value is given.";
                        return response;
                    }
                    else if (dimension.NeedsValidation)
                    {
                        if (IsValidDimensionValue(factTable, dimension.Code, dimension.SelectedDataSource.ForcedValue) == false)
                        {
                            forcedValueDimensionValidation.Add(dimension.Name);
                        }
                    }
                }
            }

            if (forcedValueDimensionValidation.Count > 0)
            {
                response.Status = 1;
                response.Message = string.Format("One or more dimension(s) have invalid forced values - {0}", string.Join(", ", forcedValueDimensionValidation.ToArray()));
                return response;
            }

            if (fileTypeCodeId != null)
            {
                response = UpdateFileType(userId, factFileType);
                response.FileTypeCodeId = factFileType.FileTypeCodeId;
                if (response.Status == 0)
                {
                    opsLogManager.LogEvent(userId, "OnSaveFileType", string.Format("Update file type - {0}", factFileType.FileTypeCodeId), "Success", Contracts.Data.MDUA.UserToolLogLevel.Audit);
                }
            }
            else if (fileTypeCodeId == null && factFileType.FileTypeCodeId != null)
            {
                //another user has deleted before this user
                //no need to update and notify the current user
                response.Status = 1;
                response.Message = "File Type " + factFileType.Code + " has been removed by another user after you loaded it.";
            }
            else
            {
                response = AddFileType(userId, factFileType);
                if (response.Status == 0)
                {
                    opsLogManager.LogEvent(userId, "OnSaveFileType", string.Format("Add file type - {0}", response.FileTypeCodeId), "Success", Contracts.Data.MDUA.UserToolLogLevel.Audit);
                }
                //response.FileTypeCodeId = factFileType.FileTypeCodeId;
            }
            return response;
        }

        protected override KeyComboResponse OnGetKeyCombinations(string userId, KeyComboRequest keyComboRequest)
        {

            KeyComboResponse resp = new KeyComboResponse();
            FactTable factTable = this.OnGetFactTable(userId, keyComboRequest.FactTableId);
            //to do: need to get the profile name from db table.
            string connectionString = this.OnGetDbConnectionString(factTable.RepoProfile);

            if (factTable == null)
            {
                resp.Status = 1;
                resp.Message = "Fact Table Info could not be retreived.";
                return resp;
            }
            string fileTypeCode = GetFileTypeCodeById(keyComboRequest.FactTableId, keyComboRequest.FileTypeCodeId);

            //{0} - column list
            //{1} - Table Name
            //{2} - File Type Code
            //{3} - Owner
            //{4} - StartRow
            //{5} - EndRow
            //string queryFmt = "SELECT {0} FROM (SELECT ROWNUM rnum, a.* FROM (SELECT rowid as urowid, b.* FROM {1} b) a where a.source ='{2}' and a.owner ='{3}') WHERE rnum BETWEEN {4} AND {5}";
            string queryFmt = "SELECT {0} FROM (SELECT ROWNUM rnum, a.* FROM (SELECT rowid as urowid, b.* FROM {1} b) a where a.source ='{2}') WHERE rnum BETWEEN {3} AND {4}";

            //Calculate Total Records if not known
            int totalRecords = 0;
            if (keyComboRequest.PagingInfo.TotalRows == 0)
            {
                //totalRecords = DBUtil.GetTotalRowsFromTable(factTable.FileTypeKeyComboTableName, "source = '" + fileTypeCode + "' and  owner='" + userId + "'", connectionString);
                totalRecords = DBUtil.GetTotalRowsFromTable(factTable.FileTypeKeyComboTableName, "source = '" + fileTypeCode + "'", connectionString);
            }

            //Calculate start and end row
            int endRow = keyComboRequest.PagingInfo.PageNumber * keyComboRequest.PagingInfo.RowsPerPage;
            int startRow = (endRow - keyComboRequest.PagingInfo.RowsPerPage) + 1;

            //Calculate total pages
            int totalPages = Convert.ToInt32(Decimal.Ceiling(Decimal.Divide(totalRecords, keyComboRequest.PagingInfo.RowsPerPage)));
            if (endRow > totalRecords)
            {
                endRow = Convert.ToInt32(totalRecords);
            }
            string[] keyColumns = GetKeyColumns(factTable.AvailableDimensions);
            //generate column list
            string columnList = string.Join(",", keyColumns);

            //generate query
            //string query = string.Format(queryFmt, columnList, factTable.FileTypeKeyComboTableName, fileTypeCode, userId, startRow, endRow);
            string query = string.Format(queryFmt, columnList, factTable.FileTypeKeyComboTableName, fileTypeCode, startRow, endRow);

            //Prepare return value
            resp.FactTableId = keyComboRequest.FactTableId;
            resp.KeyComboData = new TableValues();
            resp.PagingInfo = new Paging();
            resp.PagingInfo.PageNumber = keyComboRequest.PagingInfo.PageNumber;
            resp.PagingInfo.RowsPerPage = keyComboRequest.PagingInfo.RowsPerPage;
            resp.PagingInfo.TotalPages = totalPages;
            resp.PagingInfo.TotalRows = Convert.ToInt32(totalRecords);
            resp.Columns = keyColumns;
            //Data structure for column data
            Dictionary<int, List<string>> columnDiction = new Dictionary<int, List<string>>();

            //initialize the column in the column dictionary
            for (var colIndex = 0; colIndex < keyColumns.Length; colIndex++)
            {
                columnDiction.Add(colIndex, new List<string>());
            }
            if (totalRecords > 0)
            {
                using (OracleConnection conn = new OracleConnection(connectionString))
                using (OracleCommand cmd = new OracleCommand(query, conn))
                {
                    conn.Open();
                    try
                    {
                        using (OracleDataReader dataReader = cmd.ExecuteReader())
                        {
                            //Read data from table
                            while (dataReader.Read())
                            {
                                for (var colIndex = 0; colIndex < keyColumns.Length; colIndex++)
                                {
                                    columnDiction[colIndex].Add(dataReader.IsDBNull(colIndex) ? string.Empty : Convert.ToString(dataReader.GetValue(colIndex)));
                                }
                            }

                            dataReader.Close();
                        }

                        //Assign the values from column diction to return object
                        List<ColumnData> factDataList = new List<ColumnData>();
                        for (var colIndex = 0; colIndex < keyColumns.Length; colIndex++)
                        {
                            factDataList.Add(new ColumnData() { Values = columnDiction[colIndex].ToArray() });
                        }
                        resp.KeyComboData.Data = factDataList.ToArray();
                        resp.Message = "Retrieved fact key combinations successfully.";
                    }
                    catch (Exception e)
                    {
                        resp.Status = 1;
                        resp.Message = "Error occurred while retrieving fact key combinations :" + e.Message;
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
            else
            {
                resp.Message = "No key combinations found for you.";
            }

            return resp;
        }



        protected override TableInfo OnGetTableInfo(string userId, long tableId)
        {
            FactTable factTable = this.OnGetFactTable(userId, tableId);
            TableInfo tableInfo = new TableInfo();
            //to do: need to get the profile name from db table.
            string connectionString = this.OnGetDbConnectionString(factTable.RepoProfile);
            tableInfo.ConnectionString = connectionString;
            if (factTable == null)
            {
                return null;
            }
            tableInfo.TableId = factTable.Id;
            tableInfo.TableName = factTable.FileTypeKeyComboTableName;
            //tableInfo.TotalRows = DBUtil.GetTotalRowsFromTable(factTable.FileTypeKeyComboTableName, "source = '" + fileTypeCode + "' and  owner=' " + userId + "'", connectionString);
            string[] keyColumns = factTable.AvailableDimensions.Select(d => d.StageTableColumnName).ToArray();
            tableInfo.Columns = keyColumns;
            return tableInfo;
        }

        protected override KeyComboDeleteResponse OnDeleteKeyCombinations(string userId, KeyComboDeleteRequest keyComboDeleteRequest)
        {

            const int maxRowsPerUpdate = 2000;
            int totalRecordsDeleted = 0;
            string sqlText = string.Empty;
            int idsToProcess;
            int index = 0;
            KeyComboDeleteResponse resp = new KeyComboDeleteResponse();
            FactTable factTable = this.OnGetFactTable(userId, keyComboDeleteRequest.FactTableId);
            string fileTypeCode = GetFileTypeCodeById(keyComboDeleteRequest.FactTableId, keyComboDeleteRequest.FileTypeCodeId);
            string connectionString = this.OnGetDbConnectionString(factTable.RepoProfile);

            if (factTable == null)
            {
                resp.Status = 1;
                resp.Message = "Fact Table with id " + keyComboDeleteRequest.FactTableId + " found.";
                return resp;
            }
            if (string.IsNullOrEmpty(fileTypeCode))
            {
                resp.Status = 1;
                resp.Message = "No file type with id " + keyComboDeleteRequest.FileTypeCodeId + " found.";
                return resp;
            }
            if (keyComboDeleteRequest.DeleteOption != KeyComboDeleteRequest.DeleteOptions.All && keyComboDeleteRequest.DeleteOption != KeyComboDeleteRequest.DeleteOptions.Selected)
            {
                resp.Status = 1;
                resp.Message = "Invalid delete option.";
                return resp;
            }
            if (keyComboDeleteRequest.DeleteOption == KeyComboDeleteRequest.DeleteOptions.Selected && (keyComboDeleteRequest.DeleteRecords == null || keyComboDeleteRequest.DeleteRecords.Length == 0))
            {
                resp.Status = 1;
                resp.Message = "No record ids passed for deletion.";
                return resp;
            }
            try
            {
                using (OracleConnection connection = new OracleConnection(connectionString))
                using (OracleCommand command = connection.CreateCommand())
                {
                    connection.Open();

                    if (keyComboDeleteRequest.DeleteOption == KeyComboDeleteRequest.DeleteOptions.All)
                    {
                        sqlText = string.Format(@"delete from {0} where source = :source", factTable.FileTypeKeyComboTableName);
                        command.CommandType = CommandType.Text;
                        command.CommandText = sqlText;
                        command.Parameters.Add(new OracleParameter("source", OracleDbType.Varchar2, fileTypeCode, ParameterDirection.Input));
                        totalRecordsDeleted = command.ExecuteNonQuery();
                        resp.Message = totalRecordsDeleted + " key combination rows deleted.";
                        opsLogManager.LogEvent(userId, "OnDeleteKeyCombinations", string.Format("Delete All Key Combo - {0}", fileTypeCode), "Success", Contracts.Data.MDUA.UserToolLogLevel.Audit);
                    }
                    else
                    {
                        if (keyComboDeleteRequest.DeleteRecords != null && keyComboDeleteRequest.DeleteRecords.Length > 0)
                        {
                            List<string> rowids = keyComboDeleteRequest.DeleteRecords.ToList();
                            using (OracleTransaction transaction = connection.BeginTransaction())
                            {
                                sqlText = string.Format(@"delete from {0} where rowid = chartorowid(:rid)", factTable.FileTypeKeyComboTableName);
                                command.CommandType = CommandType.Text;
                                command.Parameters.Clear();
                                command.CommandText = sqlText;

                                command.Parameters.Add(new OracleParameter(":rid", OracleDbType.Varchar2));
                                command.BindByName = true;

                                totalRecordsDeleted = 0;
                                idsToProcess = rowids.Count;

                                index = 0;

                                while (idsToProcess > maxRowsPerUpdate)
                                {
                                    command.Parameters[0].Value = rowids.GetRange(index, maxRowsPerUpdate).ToArray();
                                    command.ArrayBindCount = maxRowsPerUpdate;
                                    totalRecordsDeleted += command.ExecuteNonQuery();
                                    index += maxRowsPerUpdate;
                                    idsToProcess -= maxRowsPerUpdate;
                                }

                                command.Parameters[0].Value = rowids.GetRange(index, idsToProcess).ToArray();
                                command.ArrayBindCount = idsToProcess;
                                totalRecordsDeleted += command.ExecuteNonQuery();
                                transaction.Commit();
                                resp.Message = totalRecordsDeleted + " key combination rows deleted.";
                                opsLogManager.LogEvent(userId, "OnDeleteKeyCombinations", string.Format("Delete Selected Key Combo - {0}", factTable.FileTypeKeyComboTableName), "Success", Contracts.Data.MDUA.UserToolLogLevel.Audit);
                            }
                        }
                        else
                        {
                            resp.Status = 1;
                            resp.Message = totalRecordsDeleted + "No key combination rowids sent for deletion";
                        }
                    }
                    connection.Close();
                }

            }
            catch (Exception ex)
            {
                resp.Status = 1;
                resp.Message = "Error occurred while deleting key combinations.";
            }

            return resp;
        }

        protected override FactTable OnGetFactTableBasicInfo(string userId, long tableId)
        {
            FactTable factTable = new FactTable();
            using (OracleConnection conn = new OracleConnection(this.ConnectionString))
            using (OracleCommand cmdSelect = new OracleCommand())
            {
                conn.Open();
                cmdSelect.Connection = conn;
                cmdSelect.CommandText = "Select fact_table_id, fact_table_name, stage_table_year_name, stage_table_month_name, fact_table_with_outline_values, key_combo_table_name, allows_adjustments, fact_table_desc, repo_profile from master_fact_table Where fact_table_id =:fact_table_id";
                cmdSelect.Parameters.Add("fact_table_id", OracleDbType.Int64, tableId, ParameterDirection.Input);
                using (OracleDataReader dataReader = cmdSelect.ExecuteReader())
                {
                    try
                    {
                        if (dataReader.Read())
                        {
                            factTable = new FactTable();
                            factTable.Id = Convert.ToInt64(dataReader["fact_table_id"]);
                            factTable.Name = Convert.ToString(dataReader["fact_table_name"]);
                            factTable.YearlyUploadStageName = dataReader["stage_table_year_name"].ToString();
                            factTable.MonthlyUploadStageName = dataReader["stage_table_month_name"].ToString();
                            factTable.PhysicalTable = dataReader["fact_table_with_outline_values"].ToString(); //what is this field?
                            factTable.FileTypeKeyComboTableName = dataReader["key_combo_table_name"].ToString();
                            factTable.AllowAdjustments = dataReader["allows_adjustments"].ToString().Trim().ToUpper().Equals("Y");
                            factTable.Description = Convert.ToString(dataReader["fact_table_desc"]);
                            factTable.RepoProfile = dataReader["repo_profile"].ToString();

                        }
                        dataReader.Close();
                    }
                    catch (Exception ex)
                    {
                        throw;
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
            return factTable;
        }

        protected override string OnGetPagingQueryTemplate()
        {
            return "SELECT {0} FROM (SELECT ROWNUM rnum, a.* FROM (SELECT rowid as urowid, b.* FROM {1} b) a where {2}) WHERE rnum BETWEEN {3} AND {4}";
        }

        protected override string OnGetDbConnectionString(string dbProfileName)
        {
            var dbProfile = dbProfileList.FirstOrDefault(d => d.Name == dbProfileName);
            return string.Format(dbProfile.ConnectionString, Common.Utility.Decrypt(dbProfile.EncryptedUserName, EncryptionSalt), Common.Utility.Decrypt(dbProfile.EncryptedPassword, EncryptionSalt));
        }
        protected override KeyComboMoveResponse OnMoveKeyCombinations(string userId, KeyComboMoveRequest keyComboMoveRequest)
        {
            const int maxRowsPerUpdate = 2000;
            string sqlText = string.Empty;
            int idsToProcess;
            int index = 0;
            int totalFactsMoved = 0;
            int totalKeysMoved = 0;
            KeyComboMoveResponse resp = new KeyComboMoveResponse();
            FactTable factTable = this.OnGetFactTable(userId, keyComboMoveRequest.FactTableId);
            string sourceFileTypeCode = GetFileTypeCodeById(keyComboMoveRequest.FactTableId, keyComboMoveRequest.FileTypeCodeId);
            string targetFileTypeCode = GetFileTypeCodeById(keyComboMoveRequest.FactTableId, keyComboMoveRequest.TargetFileTypeCodeId);
            if (factTable == null)
            {
                resp.Status = 1;
                resp.Message = "No fact table with id " + keyComboMoveRequest.FactTableId + " found.";
                return resp;
            }
            if (string.IsNullOrEmpty(sourceFileTypeCode))
            {
                resp.Status = 1;
                resp.Message = "No source file type with id " + keyComboMoveRequest.FileTypeCodeId + " found.";
                return resp;
            }
            if (string.IsNullOrEmpty(targetFileTypeCode))
            {
                resp.Status = 1;
                resp.Message = "No target file type with id " + keyComboMoveRequest.TargetFileTypeCodeId + " found.";
                return resp;
            }
            if (!string.IsNullOrEmpty(targetFileTypeCode) && targetFileTypeCode == sourceFileTypeCode)
            {
                resp.Status = 1;
                resp.Message = "source file type and target file type are the same. No move can be executed.";
                return resp;
            }

            string connectionString = this.OnGetDbConnectionString(factTable.RepoProfile);

            try
            {
                using (OracleConnection connection = new OracleConnection(connectionString))
                using (OracleCommand command = connection.CreateCommand())
                using (OracleCommand commandFact = connection.CreateCommand())
                {
                    connection.Open();
                    using (OracleTransaction transaction = connection.BeginTransaction())
                    {
                        if (keyComboMoveRequest.MoveOption == KeyComboMoveRequest.MoveOptions.All)
                        {
                            commandFact.CommandText = string.Format(@"update {0} set source = :source where source = :previous_source", factTable.PhysicalTable);
                            commandFact.CommandType = CommandType.Text;
                            commandFact.Parameters.Add(new OracleParameter("source", OracleDbType.Varchar2, targetFileTypeCode, ParameterDirection.Input));
                            commandFact.Parameters.Add(new OracleParameter("previous_source", OracleDbType.Varchar2, sourceFileTypeCode, ParameterDirection.Input));

                            command.CommandText = string.Format(@"update {0} set source = :source where source = :previous_source", factTable.FileTypeKeyComboTableName);
                            command.CommandType = CommandType.Text;
                            command.Parameters.Add(new OracleParameter("source", OracleDbType.Varchar2, targetFileTypeCode, ParameterDirection.Input));
                            command.Parameters.Add(new OracleParameter("previous_source", OracleDbType.Varchar2, sourceFileTypeCode, ParameterDirection.Input));
                            totalFactsMoved = commandFact.ExecuteNonQuery();
                            totalKeysMoved = command.ExecuteNonQuery();
                            opsLogManager.LogEvent(userId, "OnMoveKeyCombinations", string.Format("Move All Key Combo - {0} {1}", sourceFileTypeCode, targetFileTypeCode), "Success", Contracts.Data.MDUA.UserToolLogLevel.Audit);

                        }
                        else
                        {
                            List<string> rowids = keyComboMoveRequest.MoveRecords.ToList();
                            string columnMatch = GeneratedColumnMatch(factTable.AvailableDimensions);
                            command.CommandType = CommandType.Text;
                            command.CommandText = string.Format(@"update {0} set source = '{1}' where rowid = chartorowid(:rid)", factTable.FileTypeKeyComboTableName, targetFileTypeCode);
                            command.Parameters.Add(new OracleParameter(":rid", OracleDbType.Varchar2));
                            command.BindByName = true;

                            commandFact.CommandType = CommandType.Text;
                            commandFact.CommandText = string.Format(
                                @"update {0} set source = '{1}' 
                                  where rowid in (
                                    select /*+ parallel(f 4) */ f.rowid 
                                    from {2} f, {3} v
                                    where v.rowid = chartorowid(:rid) 
                                      and {4}
                                      and f.source = v.source
                                  )", factTable.PhysicalTable, targetFileTypeCode, factTable.PhysicalTable, factTable.FileTypeKeyComboTableName, columnMatch);
                            commandFact.Parameters.Add(new OracleParameter(":rid", OracleDbType.Varchar2));
                            commandFact.BindByName = true;

                            totalKeysMoved = 0;
                            totalFactsMoved = 0;
                            idsToProcess = rowids.Count;

                            index = 0;

                            while (idsToProcess > maxRowsPerUpdate)
                            {
                                command.Parameters[0].Value = rowids.GetRange(index, maxRowsPerUpdate).ToArray();
                                commandFact.Parameters[0].Value = rowids.GetRange(index, maxRowsPerUpdate).ToArray();
                                command.ArrayBindCount = maxRowsPerUpdate;
                                commandFact.ArrayBindCount = maxRowsPerUpdate;
                                totalFactsMoved += commandFact.ExecuteNonQuery();
                                totalKeysMoved += command.ExecuteNonQuery();
                                index += maxRowsPerUpdate;
                                idsToProcess -= maxRowsPerUpdate;
                            }

                            command.Parameters[0].Value = rowids.GetRange(index, idsToProcess).ToArray();
                            commandFact.Parameters[0].Value = rowids.GetRange(index, idsToProcess).ToArray();
                            command.ArrayBindCount = idsToProcess;
                            commandFact.ArrayBindCount = idsToProcess;
                            totalFactsMoved += commandFact.ExecuteNonQuery();
                            totalKeysMoved += command.ExecuteNonQuery();
                        }
                        transaction.Commit();
                    }
                    connection.Close();

                    resp.TotalFactsMoved = totalFactsMoved;
                    resp.TotalKeysMoved = totalKeysMoved;
                    resp.Message = " Facts and Keys moved.";
                    opsLogManager.LogEvent(userId, "OnMoveKeyCombinations", string.Format("Move Selected Key Combo - {0} {1}", factTable.FileTypeKeyComboTableName, targetFileTypeCode), "Success", Contracts.Data.MDUA.UserToolLogLevel.Audit);
                }

            }
            catch (Exception ex)
            {
                resp.Status = 1;
                resp.Message = "Error occurred whiling moving file fact and keys.";
            }
            return resp;
        }

        protected override FactReportingPeriod OnGetCurrentPeriod(string userId, long factTableId)
        {
            FactReportingPeriod currentPeriod = null;
            string currentPeriodInString = string.Empty;

            using (OracleConnection oraConn = new OracleConnection(this.ConnectionString))
            using (OracleCommand oraRunStatusCommand = new OracleCommand())
            {
                oraConn.Open();
                try
                {
                    //Get Run Status Id
                    oraRunStatusCommand.Connection = oraConn;
                    oraRunStatusCommand.CommandType = CommandType.StoredProcedure;
                    oraRunStatusCommand.CommandText = "MDMFRAMEWORK.get_current_period";

                    oraRunStatusCommand.Parameters.Add(new OracleParameter("@i_user_id", OracleDbType.Varchar2, userId, ParameterDirection.Input));
                    oraRunStatusCommand.Parameters.Add(new OracleParameter("@factTableId", OracleDbType.Long, factTableId, ParameterDirection.Input));
                    oraRunStatusCommand.Parameters.Add(new OracleParameter("@o_current_period", OracleDbType.Int32, ParameterDirection.Output));

                    oraRunStatusCommand.ExecuteNonQuery();
                    currentPeriodInString = oraRunStatusCommand.Parameters["@o_current_period"].Value.ToString();
                }
                catch
                {
                    throw;
                }
                finally
                {
                    oraConn.Close();
                }
            }

            if (string.IsNullOrEmpty(currentPeriodInString) == false && currentPeriodInString.Length == 6)
            {
                currentPeriod = new FactReportingPeriod();
                currentPeriod.Month = Convert.ToInt32(currentPeriodInString.Substring(4));
                currentPeriod.Year = Convert.ToInt32(currentPeriodInString.Substring(0, 4));
            }
            else
            {
                throw new MDMFrameworkException("Invalid CurrentPeriod");
            }

            return currentPeriod;
        }

        private FileTypeResponse AddFileType(String userId, FactFileType factFileType)
        {
            FileTypeResponse response = new FileTypeResponse();
            int insertRecords = 0;
            using (OracleConnection conn = new OracleConnection(this.ConnectionString))
            using (OracleCommand cmdDelete = new OracleCommand())
            using (OracleCommand cmdInsertFileType = new OracleCommand())
            {
                conn.Open();
                using (OracleTransaction transaction = conn.BeginTransaction())
                {
                    try
                    {
                        //insert file type record
                        cmdInsertFileType.Connection = conn;
                        cmdInsertFileType.Transaction = transaction;
                        cmdInsertFileType.CommandText = "INSERT INTO OPS_FILE_TYPES "
                                                          + " ( "
                                                          + "  INPUT_FILE_CODE_ID,"
                                                          + "  INPUT_FILE_CODE,"
                                                          + "  DESCRIPTION,"
                                                          + "  IS_ADJUSTMENT,"
                                                          + "  IS_13MONTH,"
                                                          + "  IS_OUTLOOK,"
                                                          + "  IS_USER_FEED,"
                                                          + "   USES_VALID_KEYS,"
                                                          + "   SHOW_ON_UPLOAD_STATUS,"
                                                          + "   SCHEDULED_LOAD_DATE,"
                                                          + "   FACT_TABLE_ID,"
                                                          + "   DEST_TABLE"
                                                          + " )"
                                                          + " VALUES"
                                                          + " ("
                                                          + "   OPS_FILE_TYPE_ID_SEQ.nextval,"
                                                          + "  :INPUT_FILE_CODE,"
                                                          + "  :DESCRIPTION,"
                                                          + "  :IS_ADJUSTMENT,"
                                                          + "  :IS_13MONTH,"
                                                          + "  :IS_OUTLOOK,"
                                                          + "  :IS_USER_FEED,"
                                                          + "  :USES_VALID_KEYS,"
                                                          + "  :SHOW_ON_UPLOAD_STATUS,"
                                                          + "  :SCHEDULED_LOAD_DATE,"
                                                          + "  :FACT_TABLE_ID,"
                                                          + "  :DEST_TABLE"
                                                          + " ) RETURNING INPUT_FILE_CODE_ID INTO :INSERTED_INPUT_FILE_CODE_ID";
                        cmdInsertFileType.Parameters.Clear();
                        long insertedFileTypeId = 0;
                        cmdInsertFileType.Parameters.Add("INPUT_FILE_CODE", OracleDbType.Varchar2, 20, factFileType.Code, ParameterDirection.Input);
                        cmdInsertFileType.Parameters.Add("DESCRIPTION", OracleDbType.Varchar2, 50, factFileType.Description, ParameterDirection.Input);
                        cmdInsertFileType.Parameters.Add("IS_ADJUSTMENT", OracleDbType.Char, 1, factFileType.IsAdjustment ? "Y" : "N", ParameterDirection.Input);
                        cmdInsertFileType.Parameters.Add("IS_13MONTH", OracleDbType.Char, 1, factFileType.Contains13ColFacts ? "Y" : "N", ParameterDirection.Input);
                        cmdInsertFileType.Parameters.Add("IS_OUTLOOK", OracleDbType.Char, 1, factFileType.IsOutlook ? "Y" : "N", ParameterDirection.Input);
                        cmdInsertFileType.Parameters.Add("IS_USER_FEED", OracleDbType.Char, 1, factFileType.IsUserFeed ? "Y" : "N", ParameterDirection.Input);
                        cmdInsertFileType.Parameters.Add("USES_VALID_KEYS", OracleDbType.Char, 1, factFileType.UsesValidKeyCombo ? "Y" : "N", ParameterDirection.Input);
                        cmdInsertFileType.Parameters.Add("SHOW_ON_UPLOAD_STATUS", OracleDbType.Char, 1, factFileType.ShowStatus ? "Y" : "N", ParameterDirection.Input);
                        cmdInsertFileType.Parameters.Add("SCHEDULED_LOAD_DATE", OracleDbType.Varchar2, 50, factFileType.ScheduledLoadDate, ParameterDirection.Input);
                        cmdInsertFileType.Parameters.Add("FACT_TABLE_ID", OracleDbType.Long, factFileType.FactTableId, ParameterDirection.Input);
                        cmdInsertFileType.Parameters.Add("DEST_TABLE", OracleDbType.Varchar2, 40, factFileType.Code, ParameterDirection.Input);
                        cmdInsertFileType.Parameters.Add("INSERTED_INPUT_FILE_CODE_ID", OracleDbType.Int64, ParameterDirection.Output);
                        int retVal = (int)cmdInsertFileType.ExecuteNonQuery();
                        insertRecords = insertRecords + retVal;
                        if (retVal == 1)
                        {
                            insertedFileTypeId = Convert.ToInt64(cmdInsertFileType.Parameters["INSERTED_INPUT_FILE_CODE_ID"].Value.ToString());

                            cmdInsertFileType.Parameters.Clear();
                            cmdInsertFileType.CommandText = "insert into ops_user_input_file_access (employee_id, input_file_code, input_file_code_id) values (:employee_id, null, :input_file_code_id)";
                            cmdInsertFileType.Parameters.Add("employee_id", OracleDbType.Varchar2, 20, userId, ParameterDirection.Input);
                            cmdInsertFileType.Parameters.Add("input_file_code_id", OracleDbType.Int64, insertedFileTypeId, ParameterDirection.Input);
                            insertRecords = +cmdInsertFileType.ExecuteNonQuery();

                            if (factFileType.FileTypeDimensions != null && factFileType.FileTypeDimensions.Length > 0)
                            {
                                cmdInsertFileType.Parameters.Clear();
                                cmdInsertFileType.Parameters.Add("INPUT_FILE_CODE_ID", OracleDbType.Int64, ParameterDirection.Input);
                                cmdInsertFileType.Parameters.Add("DIMENSION_ID", OracleDbType.Int64, ParameterDirection.Input);
                                cmdInsertFileType.Parameters.Add("DATASRC_TYPE", OracleDbType.Int32, ParameterDirection.Input);
                                cmdInsertFileType.Parameters.Add("FORCED_VALUE", OracleDbType.Varchar2, 255, ParameterDirection.Input);
                                cmdInsertFileType.Parameters.Add("AUTOMAP_ID", OracleDbType.Int64, ParameterDirection.Input);
                                cmdInsertFileType.CommandText = "INSERT INTO OPS_FILE_TYPE_FIELDS "
                                                                  + "   ("
                                                                  + "     INPUT_FILE_FIELD_ID,"
                                                                  + "     INPUT_FILE_CODE_ID,"
                                                                  + "     DIMENSION_ID,"
                                                                  + "     DATASRC_TYPE,"
                                                                  + "     FORCED_VALUE,"
                                                                  + "     AUTOMAP_ID"
                                                                  + "   )"
                                                                  + "   VALUES"
                                                                  + "   ("
                                                                  + "     OPS_FILE_TYPE_FIELD_ID_SEQ.nextval ,"
                                                                  + "     :INPUT_FILE_CODE_ID,"
                                                                  + "     :DIMENSION_ID,"
                                                                  + "     :DATASRC_TYPE,"
                                                                  + "     :FORCED_VALUE,"
                                                                  + "     :AUTOMAP_ID"
                                                                  + "    )";
                                foreach (FileTypeDimension dimension in factFileType.FileTypeDimensions)
                                {
                                    cmdInsertFileType.Parameters["INPUT_FILE_CODE_ID"].Value = insertedFileTypeId;
                                    cmdInsertFileType.Parameters["DIMENSION_ID"].Value = dimension.Id;
                                    cmdInsertFileType.Parameters["DATASRC_TYPE"].Value = Convert.ToInt32(dimension.SelectedDataSource.DataSourceType);
                                    cmdInsertFileType.Parameters["FORCED_VALUE"].Value = dimension.SelectedDataSource.ForcedValue;
                                    cmdInsertFileType.Parameters["AUTOMAP_ID"].Value = dimension.SelectedDataSource.AutomapId;
                                    insertRecords = insertRecords + cmdInsertFileType.ExecuteNonQuery();
                                }
                            }

                            if (factFileType.FileTypeCustomFields != null && factFileType.FileTypeCustomFields.Length > 0)
                            {
                                cmdInsertFileType.CommandText = "INSERT INTO OPS_FACT_CUST_ATT_VALUES "
                                                                   + "  ("
                                                                   + "     CUST_ATT_VALUE_ID,"
                                                                   + "     INPUT_FILE_CODE_ID,"
                                                                   + "     CUST_ATT_ID,"
                                                                   + "     CUST_ATT_VALUE"
                                                                   + "   )"
                                                                   + "    VALUES"
                                                                   + "   ("
                                                                   + "     OPS_CUST_ATT_VALUE_ID_SEQ.nextval,"
                                                                   + "     :INPUT_FILE_CODE_ID,"
                                                                   + "     :CUST_ATT_ID,"
                                                                   + "     :CUST_ATT_VALUE"
                                                                   + "   )";
                                cmdInsertFileType.Parameters.Clear();
                                cmdInsertFileType.Parameters.Add("INPUT_FILE_CODE_ID", OracleDbType.Int64, ParameterDirection.Input);
                                cmdInsertFileType.Parameters.Add("CUST_ATT_ID", OracleDbType.Int64, ParameterDirection.Input);
                                cmdInsertFileType.Parameters.Add("CUST_ATT_VALUE", OracleDbType.Varchar2, ParameterDirection.Input);

                                foreach (CustomFieldValue cField in factFileType.FileTypeCustomFields)
                                {
                                    cmdInsertFileType.Parameters["INPUT_FILE_CODE_ID"].Value = insertedFileTypeId;
                                    cmdInsertFileType.Parameters["CUST_ATT_ID"].Value = cField.Id;
                                    cmdInsertFileType.Parameters["CUST_ATT_VALUE"].Value = cField.Value;
                                    insertRecords = insertRecords + cmdInsertFileType.ExecuteNonQuery();
                                }
                            }
                        }

                        transaction.Commit();
                        response.Status = 0;
                        response.FileTypeCodeId = insertedFileTypeId;
                        response.Message = "File type " + factFileType.Code + " has been added (" + insertRecords + " rows)";
                    }
                    catch (OracleException oex)
                    {
                        transaction.Rollback();
                        response.Status = 1;
                        response.Message = " Error occured while adding file type " + factFileType.Code;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        response.Status = 1;
                        response.Message = " Error occured while adding file type " + factFileType.Code;
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
            return response;
        }

        private long? IsFileTypeExisted(long factTableId, string fileTypeCode)
        {
            long? fileTypeCodeId = null;
            using (OracleConnection conn = new OracleConnection(this.ConnectionString))
            using (OracleCommand cmdSelect = new OracleCommand())
            {
                conn.Open();
                cmdSelect.Connection = conn;
                cmdSelect.CommandText = "Select input_file_code_id from OPS_FILE_TYPES Where fact_table_id =:fact_table_id and input_file_code = : input_file_code";
                cmdSelect.Parameters.Add("fact_table_id", OracleDbType.Int64, factTableId, ParameterDirection.Input);
                cmdSelect.Parameters.Add("input_file_code", OracleDbType.Varchar2, 20, fileTypeCode, ParameterDirection.Input);
                using (OracleDataReader dataReader = cmdSelect.ExecuteReader())
                {
                    try
                    {
                        if (dataReader.Read())
                        {
                            fileTypeCodeId = Convert.ToInt64(dataReader["input_file_code_id"]);
                        }
                        dataReader.Close();
                    }
                    catch (Exception ex)
                    {
                        throw;
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
            return fileTypeCodeId;
        }

        protected override string OnGetFileTypeCodeById(long factTableId, long fileTypeCodeId)
        {
            string fileTypeCode = "";
            using (OracleConnection conn = new OracleConnection(this.ConnectionString))
            using (OracleCommand cmdSelect = new OracleCommand())
            {
                conn.Open();
                cmdSelect.Connection = conn;
                cmdSelect.CommandText = "Select input_file_code from OPS_FILE_TYPES Where fact_table_id =:fact_table_id and input_file_code_id = : input_file_code_id";
                cmdSelect.Parameters.Add("fact_table_id", OracleDbType.Int64, factTableId, ParameterDirection.Input);
                cmdSelect.Parameters.Add("input_file_code_id", OracleDbType.Int64, fileTypeCodeId, ParameterDirection.Input);
                using (OracleDataReader dataReader = cmdSelect.ExecuteReader())
                {
                    try
                    {
                        if (dataReader.Read())
                        {
                            fileTypeCode = dataReader["input_file_code"].ToString();
                        }
                        dataReader.Close();
                    }
                    catch (Exception ex)
                    {
                        throw;
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
            return fileTypeCode;
        }

        private FileTypeResponse UpdateFileType(String userId, FactFileType factFileType)
        {
            FileTypeResponse response = new FileTypeResponse();
            int updatedRecords = 0;
            using (OracleConnection conn = new OracleConnection(this.ConnectionString))
            using (OracleCommand cmdDelete = new OracleCommand())
            using (OracleCommand cmdUpdateFileType = new OracleCommand())
            {
                conn.Open();
                using (OracleTransaction transaction = conn.BeginTransaction())
                {
                    try
                    {
                        cmdUpdateFileType.Connection = conn;
                        cmdUpdateFileType.Transaction = transaction;
                        cmdUpdateFileType.CommandText = "UPDATE OPS_FILE_TYPES "
                                                          + " SET "
                                                          + " DESCRIPTION = :DESCRIPTION,"
                                                          + " IS_ADJUSTMENT = :IS_ADJUSTMENT,"
                                                          + " IS_13MONTH = :IS_13MONTH,"
                                                          + " IS_OUTLOOK = :IS_OUTLOOK,"
                                                          + " IS_USER_FEED = :IS_USER_FEED,"
                                                          + " USES_VALID_KEYS = :USES_VALID_KEYS,"
                                                          + " SHOW_ON_UPLOAD_STATUS = :SHOW_ON_UPLOAD_STATUS,"
                                                          + " SCHEDULED_LOAD_DATE = :SCHEDULED_LOAD_DATE,"
                                                          + " DEST_TABLE = :DEST_TABLE"
                                                          + "  WHERE FACT_TABLE_ID = :FACT_TABLE_ID AND INPUT_FILE_CODE_ID = :INPUT_FILE_CODE_ID AND INPUT_FILE_CODE = :INPUT_FILE_CODE";
                        cmdUpdateFileType.Parameters.Clear();
                        cmdUpdateFileType.Parameters.Add("DESCRIPTION", OracleDbType.Varchar2, 50, factFileType.Description, ParameterDirection.Input);
                        cmdUpdateFileType.Parameters.Add("IS_ADJUSTMENT", OracleDbType.Char, 1, factFileType.IsAdjustment ? "Y" : "N", ParameterDirection.Input);
                        cmdUpdateFileType.Parameters.Add("IS_13MONTH", OracleDbType.Char, 1, factFileType.Contains13ColFacts ? "Y" : "N", ParameterDirection.Input);
                        cmdUpdateFileType.Parameters.Add("IS_OUTLOOK", OracleDbType.Char, 1, factFileType.IsOutlook ? "Y" : "N", ParameterDirection.Input);
                        cmdUpdateFileType.Parameters.Add("IS_USER_FEED", OracleDbType.Char, 1, factFileType.IsUserFeed ? "Y" : "N", ParameterDirection.Input);
                        cmdUpdateFileType.Parameters.Add("USES_VALID_KEYS", OracleDbType.Char, 1, factFileType.UsesValidKeyCombo ? "Y" : "N", ParameterDirection.Input);
                        cmdUpdateFileType.Parameters.Add("SHOW_ON_UPLOAD_STATUS", OracleDbType.Char, 1, factFileType.ShowStatus ? "Y" : "N", ParameterDirection.Input);
                        cmdUpdateFileType.Parameters.Add("SCHEDULED_LOAD_DATE", OracleDbType.Varchar2, 50, factFileType.ScheduledLoadDate, ParameterDirection.Input);
                        cmdUpdateFileType.Parameters.Add("DEST_TABLE", OracleDbType.Varchar2, 40, factFileType.Code, ParameterDirection.Input);
                        cmdUpdateFileType.Parameters.Add("FACT_TABLE_ID", OracleDbType.Long, factFileType.FactTableId, ParameterDirection.Input);
                        cmdUpdateFileType.Parameters.Add("INPUT_FILE_CODE_ID", OracleDbType.Int64, factFileType.FileTypeCodeId, ParameterDirection.Input);
                        cmdUpdateFileType.Parameters.Add("INPUT_FILE_CODE", OracleDbType.Varchar2, 20, factFileType.Code, ParameterDirection.Input);

                        updatedRecords = updatedRecords + cmdUpdateFileType.ExecuteNonQuery();
                        if (factFileType.FileTypeDimensions != null && factFileType.FileTypeDimensions.Length > 0)
                        {
                            cmdUpdateFileType.Parameters.Clear();
                            cmdUpdateFileType.Parameters.Add("DATASRC_TYPE", OracleDbType.Int64, ParameterDirection.Input);
                            cmdUpdateFileType.Parameters.Add("FORCED_VALUE", OracleDbType.Varchar2, 255, ParameterDirection.Input);
                            cmdUpdateFileType.Parameters.Add("AUTOMAP_ID", OracleDbType.Int64, ParameterDirection.Input);
                            cmdUpdateFileType.Parameters.Add("INPUT_FILE_FIELD_ID", OracleDbType.Int64, ParameterDirection.Input);
                            cmdUpdateFileType.Parameters.Add("INPUT_FILE_CODE_ID", OracleDbType.Int64, ParameterDirection.Input);
                            cmdUpdateFileType.Parameters.Add("DIMENSION_ID", OracleDbType.Int64, ParameterDirection.Input);

                            cmdUpdateFileType.CommandText = "UPDATE OPS_FILE_TYPE_FIELDS "
                                                                + "   SET "
                                                                + "     DATASRC_TYPE = :DATASRC_TYPE,"
                                                                + "     FORCED_VALUE = :FORCED_VALUE,"
                                                                + "     AUTOMAP_ID = :AUTOMAP_ID"
                                                                + "   WHERE INPUT_FILE_FIELD_ID = :INPUT_FILE_FIELD_ID AND INPUT_FILE_CODE_ID = :INPUT_FILE_CODE_ID And DIMENSION_ID = :DIMENSION_ID";
                            foreach (FileTypeDimension dimension in factFileType.FileTypeDimensions)
                            {
                                cmdUpdateFileType.Parameters["DATASRC_TYPE"].Value = Convert.ToInt32(dimension.SelectedDataSource.DataSourceType);
                                cmdUpdateFileType.Parameters["FORCED_VALUE"].Value = dimension.SelectedDataSource.ForcedValue;
                                cmdUpdateFileType.Parameters["AUTOMAP_ID"].Value = dimension.SelectedDataSource.AutomapId;
                                cmdUpdateFileType.Parameters["INPUT_FILE_FIELD_ID"].Value = dimension.SelectedDataSource.FileFieldId;
                                cmdUpdateFileType.Parameters["INPUT_FILE_CODE_ID"].Value = factFileType.FileTypeCodeId;
                                cmdUpdateFileType.Parameters["DIMENSION_ID"].Value = dimension.Id;

                                updatedRecords = updatedRecords + cmdUpdateFileType.ExecuteNonQuery();
                            }
                        }

                        if (factFileType.FileTypeCustomFields != null && factFileType.FileTypeCustomFields.Length > 0)
                        {
                            cmdUpdateFileType.CommandText = "UPDATE OPS_FACT_CUST_ATT_VALUES "
                                                                + "  SET CUST_ATT_VALUE = : CUST_ATT_VALUE"
                                                                + "  WHERE INPUT_FILE_CODE_ID = :INPUT_FILE_CODE_ID AND CUST_ATT_ID =: CUST_ATT_ID AND CUST_ATT_VALUE_ID = : CUST_ATT_VALUE_ID";

                            cmdUpdateFileType.Parameters.Clear();
                            cmdUpdateFileType.Parameters.Add("CUST_ATT_VALUE_ID", OracleDbType.Int64, ParameterDirection.Input);
                            cmdUpdateFileType.Parameters.Add("INPUT_FILE_CODE_ID", OracleDbType.Int64, ParameterDirection.Input);
                            cmdUpdateFileType.Parameters.Add("CUST_ATT_ID", OracleDbType.Int64, ParameterDirection.Input);
                            cmdUpdateFileType.Parameters.Add("CUST_ATT_VALUE", OracleDbType.Varchar2, ParameterDirection.Input);

                            foreach (CustomFieldValue cField in factFileType.FileTypeCustomFields)
                            {
                                cmdUpdateFileType.Parameters["CUST_ATT_VALUE_ID"].Value = cField.Id;
                                cmdUpdateFileType.Parameters["INPUT_FILE_CODE_ID"].Value = factFileType.FileTypeCodeId;
                                cmdUpdateFileType.Parameters["CUST_ATT_ID"].Value = cField.CustomFieldId;
                                cmdUpdateFileType.Parameters["CUST_ATT_VALUE"].Value = cField.Value;
                                updatedRecords = updatedRecords + cmdUpdateFileType.ExecuteNonQuery();
                            }
                        }


                        transaction.Commit();
                        response.Status = 0;
                        response.FileTypeCodeId = factFileType.FileTypeCodeId;
                        response.Message = "File type " + factFileType.Code + " has been updated (" + updatedRecords + " rows)";
                    }
                    catch (OracleException oex)
                    {
                        transaction.Rollback();
                        response.Status = 1;
                        response.FileTypeCodeId = factFileType.FileTypeCodeId;
                        response.Message = " Error occured while updating file type " + factFileType.Code;
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        response.Status = 1;
                        response.FileTypeCodeId = factFileType.FileTypeCodeId;
                        response.Message = " Error occured while updating file type " + factFileType.Code;
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
            return response;
        }

        private FileTypeResponse DeleteFileType(string userId, FileTypeRequest fileTypeRequest, OracleCommand cmd)
        {
            FileTypeResponse resp = new FileTypeResponse();

            try
            {
                string deleteFileTypeQuery = string.Format(@"begin delete from ops_file_type_fields where input_file_code_id ={0} ;"
                                                                    + " delete from ops_fact_cust_att_values where input_file_code_id ={0}; "
                                                                    + " delete from ops_file_types where input_file_code_id = {0} and fact_table_id = {1}; "
                                                                    + " delete from OPS_USER_INPUT_FILE_ACCESS where input_file_code_id = {0}; end;",
                                                                   fileTypeRequest.FileTypeCodeId, fileTypeRequest.FactTableId);
                cmd.CommandText = deleteFileTypeQuery;
                cmd.ExecuteNonQuery();
                resp.Status = 0;
                resp.Message = "File Type deleted.";
                opsLogManager.LogEvent(userId, "Delete File type", string.Format("Delete File Type - {0} {1}", fileTypeRequest.FileTypeCodeId, fileTypeRequest.FactTableId), "Success", Contracts.Data.MDUA.UserToolLogLevel.Audit);
            }
            catch (Exception ex)
            {
                resp.Status = 1;
                resp.Message = "Error occurrd while deleting file type " + fileTypeRequest.FileTypeCodeId;
                throw ex;
            }
            return resp;
        }


        private string GeneratedColumnMatch(FactDimension[] availableDimensions)
        {
            string[] columns = availableDimensions.Select(d => ("f." + d.Code + "= v." + d.StageTableColumnName)).ToArray();
            return string.Join(" And ", columns);
        }

        private string[] GetKeyColumns(FactDimension[] availableDimensions)
        {
            List<string> columns = availableDimensions.Select(d => d.StageTableColumnName).ToList();
            columns.Insert(0, "urowid");
            return columns.ToArray();
        }


        protected override FactTableSettings OnGetFactTableSetting(string userId)
        {
            string query = "select code, current_value from utility.OPS_CODE_VALUE where code IN ('Environment', 'current_period', 'fbit_allow_user_upload')";

            FactTableSettings settings = new FactTableSettings();

            //using (IDataReader dataReader = oracleHelper.ExecuteReader(mappingTableConnectionString, CommandType.Text, query))
            using (OracleConnection conn = new OracleConnection(this.ConnectionString))
            using (OracleCommand cmd = new OracleCommand(query, conn))
            {
                conn.Open();
                try
                {
                    using (OracleDataReader dataReader = cmd.ExecuteReader())
                    {
                        int codeCol = dataReader.GetOrdinal("code");
                        int valueCol = dataReader.GetOrdinal("current_value");
                        while (dataReader.Read())
                        {
                            var name = dataReader.GetString(codeCol);
                            var value = dataReader.IsDBNull(valueCol) ? string.Empty : dataReader.GetString(valueCol);

                            if (name.ToUpper().Equals("ENVIRONMENT"))
                            {
                                settings.Environment = value;
                            }
                            else if (name.ToUpper().Equals("CURRENT_PERIOD"))
                            {
                                settings.CurrentMonth = value.Substring(4);
                                settings.CurrentYear = value.Substring(0, 4);
                            }
                            else if (name.ToUpper().Equals("FBIT_ALLOW_USER_UPLOAD"))
                            {
                                settings.UserFeedEnabled = value.ToUpper() == "Y" ? true : false;
                            }
                        }

                        dataReader.Close();
                    }
                }
                catch
                {
                    throw;
                }
                finally
                {
                    conn.Close();
                }
            }

            return settings;

        }

        protected override FactProcessUploadedFileResponse OnGetAuditData(string userId, FactAuditRequest auditRequest)
        {
            throw new NotImplementedException();
        }

        protected override FactProcessUploadedFileResponse OnGetAuditData(string userId, FactAuditRequest auditRequest, FactTable factTable)
        {
            FactProcessUploadedFileResponse response = new FactProcessUploadedFileResponse();
            int rowCount = 0;
            int rowsSkipped = 0;
            string queryFilter = string.Empty;
            Dictionary<string, List<string>> factResultsDiction = new Dictionary<string, List<string>>();
            Dictionary<string, int> ordinalDiction = new Dictionary<string, int>();

            var sqlColumnList = new List<string>();
            var ordinalColumnList = new List<string>();
            var orderByColumnList = new List<string>();
            var paramsList = new List<OracleParameter>();

            var knownColumns = FactTableKnownValues.GetFactKnownColumns(false);

            //add fiscal_period column
            sqlColumnList.Add(string.Format("f.{0}", knownColumns[0].Name));
            ordinalColumnList.Add(string.Format("{0}", knownColumns[0].Name));

            //add dimension columns
            foreach (var dim in factTable.AvailableDimensions)
            {
                sqlColumnList.Add(string.Format("f.{0}", dim.FactColumnName));
                ordinalColumnList.Add(string.Format("{0}", dim.FactColumnName));
            }

            //add amount column
            sqlColumnList.Add(string.Format("f.{0}", knownColumns[1].Name));
            ordinalColumnList.Add(string.Format("{0}", knownColumns[1].Name));

            sqlColumnList.Add(string.Format("f.{0}", "source"));
            ordinalColumnList.Add(string.Format("{0}", "source"));
            sqlColumnList.Add(string.Format("f.{0}", "audit_id"));
            ordinalColumnList.Add(string.Format("{0}", "audit_id"));

            //add the columns collected so far into order by list
            orderByColumnList.AddRange(sqlColumnList);

            //add other known audit specific columns
            sqlColumnList.Add(string.Format("f.{0}", "date_created"));
            ordinalColumnList.Add(string.Format("{0}", "date_created"));

            sqlColumnList.Add(string.Format("t.{0} AuditFact", "amount"));
            ordinalColumnList.Add(string.Format("{0}", "AuditFact"));

            sqlColumnList.Add(string.Format("t.{0}", "owner"));
            ordinalColumnList.Add(string.Format("{0}", "owner"));

            sqlColumnList.Add(string.Format("u.{0}", "first_name"));
            ordinalColumnList.Add(string.Format("{0}", "first_name"));

            sqlColumnList.Add(string.Format("u.{0}", "last_name"));
            ordinalColumnList.Add(string.Format("{0}", "last_name"));

            foreach (var criteria in auditRequest.AuditCriteria)
            {
                var dim = factTable.AvailableDimensions.FirstOrDefault(d => d.Id == criteria.Id);
                if (string.IsNullOrEmpty(criteria.UserValue) == false && dim != null)
                {
                    queryFilter += string.Format(" and f.{0} in (:{0}) ", dim.Code);
                    var oraQueryParam = new OracleParameter(dim.Code, OracleDbType.Varchar2);
                    oraQueryParam.Value = criteria.UserValue;
                    paramsList.Add(oraQueryParam);
                }
            }


            /*
             *  {0} - select columns
             *  {1} - fact user table
             *  {2} - fact audit table
             *  {3} - fiscal period column
             *  {4} - filter query
             *  {5} - order by columns
             */
            string query = string.Format(" select {0} from {1} f "
                + " left outer join {2} t on f.audit_id = t.audit_id "
                + " left outer join web_users u on u.employee_id = t.owner "
                + " where f.audit_id is not null and f.{3} = :{3} {4} "
                + " order by {5} ",
                string.Join(", ", sqlColumnList),
                factTable.PhysicalTable,
                factTable.PhysicalTable.ToLower().Replace("user", "audit"),
                knownColumns[0].Name,
                queryFilter,
                string.Join(", ", orderByColumnList)
                );

            //build oracle param in the order of which they appear in the query
            // TODO: check datatype
            var oraFiscalPeriodParam = new OracleParameter(knownColumns[0].Name, OracleDbType.Varchar2);
            string auditMonth = auditRequest.ReportingPeriod.Month > 9 ? string.Format("{0}", auditRequest.ReportingPeriod.Month) : string.Format("0{0}", auditRequest.ReportingPeriod.Month);
            oraFiscalPeriodParam.Value = string.Format("{0}{1}", auditRequest.ReportingPeriod.Year, auditMonth);
            paramsList.Insert(0, oraFiscalPeriodParam);

            string profileConnectionString = this.OnGetDbConnectionString(factTable.RepoProfile);
            using (OracleConnection conn = new OracleConnection(profileConnectionString))
            using (OracleCommand cmd = new OracleCommand(query, conn))
            {
                try
                {

                    cmd.BindByName = true;
                    cmd.Parameters.AddRange(paramsList.ToArray());
                    conn.Open();
                    using (OracleDataReader reader = cmd.ExecuteReader())
                    {
                        foreach (var ordColumn in ordinalColumnList)
                        {
                            factResultsDiction.Add(ordColumn, new List<string>());
                            ordinalDiction.Add(ordColumn, reader.GetOrdinal(ordColumn));
                        }

                        reader.FetchSize = cmd.RowSize * 1500;

                        while (reader.Read())
                        {
                            if (rowCount < maxErrorRowsToDisplay)
                            {
                                rowCount++;

                                //collect the values from dimensions
                                foreach (var key in ordinalDiction.Keys)
                                {
                                    factResultsDiction[key].Add(Convert.ToString(reader.IsDBNull(ordinalDiction[key]) ? string.Empty : reader.GetValue(ordinalDiction[key])));
                                }
                            }
                        }

                        reader.Close();
                    }
                }
                catch { throw; }
                finally
                {
                    conn.Close();
                }
            }

            List<ColumnData> factResultsData = new List<ColumnData>();
            var factColumns = new List<string>();
            foreach (var key in factResultsDiction.Keys)
            {
                //factData.Columns.Add(key);
                factColumns.Add(key);
                var col = new ColumnData() { Values = factResultsDiction[key].ToArray() };
                factResultsData.Add(col);
            }
            response.ResponseTableColumns = factColumns.ToArray();
            response.ResponseTableData = factResultsData.ToArray();

            response.MessageType = FactTableKnownValues.ResponseMsgType.Success;
            response.Message = "";
            return response;
        }

        protected override string[] OnGetDimensionValues(string userId, FactAuditRequest auditRequest, FactTable factTable)
        {
            string dimensionName = string.Empty;
            List<string> dimensionValues = new List<string>();

            if (auditRequest.AuditCriteria != null && auditRequest.AuditCriteria.Length > 0)
            {
                dimensionName = auditRequest.AuditCriteria[0].Code;

                string query = string.Format("select member_name from V_{0}_DIM where upper(dimension_name)=:dimension_name", factTable.PhysicalTable);


                string profileConnectionString = this.OnGetDbConnectionString(factTable.RepoProfile);
                using (OracleConnection conn = new OracleConnection(profileConnectionString))
                using (OracleCommand cmd = new OracleCommand(query, conn))
                {
                    try
                    {
                        cmd.BindByName = true;
                        var param = new OracleParameter("dimension_name", OracleDbType.Varchar2);
                        param.Value = dimensionName;
                        cmd.Parameters.Add(param);
                        conn.Open();
                        using (OracleDataReader reader = cmd.ExecuteReader())
                        {
                            int memberNameCol = reader.GetOrdinal("member_name");

                            while (reader.Read())
                            {
                                dimensionValues.Add(reader.GetString(memberNameCol));
                            }

                            reader.Close();
                        }
                    }
                    catch { throw; }
                    finally
                    {
                        conn.Close();
                    }
                }
            }


            //select parent_name, member_name, alias_name from V_FACT_GL_USER_DIMENSIONS where upper(dimension_name)='AFFILIATE'


            return dimensionValues.ToArray();
        }

        protected override string[] OnGetDimensionValues(string userId, FactAuditRequest auditRequest)
        {
            throw new NotImplementedException();
        }

        private bool IsValidDimensionValue(FactTable factTable, string dimensionName, string dimensionValue)
        {
            bool isValidValue = false;

            var profileConnectionString = OnGetDbConnectionString(factTable.RepoProfile);
            string sqlText = string.Format("{0}.validate_dimension_value", factTable.ValidationProc);

            using (OracleConnection connection = new OracleConnection(profileConnectionString))
            using (OracleCommand command = new OracleCommand(sqlText, connection))
            {
                connection.Open();
                try
                {
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new OracleParameter("@is_valid", OracleDbType.Int32, ParameterDirection.ReturnValue));
                    command.Parameters.Add(new OracleParameter("@i_dimension_name", OracleDbType.Varchar2, dimensionName, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@i_value", OracleDbType.Varchar2, dimensionValue, ParameterDirection.Input));

                    command.ExecuteNonQuery();
                    if (!Convert.ToBoolean(Convert.ToInt32(command.Parameters["@is_valid"].Value.ToString())))
                    {
                        isValidValue = false;
                    }
                    else
                    {
                        isValidValue = true;
                    }
                    connection.Close();
                }
                catch
                {
                    throw;
                }
                finally
                {
                    connection.Close();
                }
            }

            return isValidValue;
        }
    }

}