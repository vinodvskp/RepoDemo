﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.DirectoryServices;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Common;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA.ODJobs;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA.User;
using VZ.CFO.MDMFramework.Contracts.Data.Security;
using VZ.CFO.MDMFramework.Providers.Data;
using VZ.CFO.MDMFramework.Server.SqlHelper;

namespace VZ.CFO.MDMFramework.Server.Providers
{
    public class DbUserAccessDataProvider : UserAccessDataProvider
    {
        //private readonly IOracleHelper oracleHelper;
        private string ldapServer;
        private string ldapUserName;
        private string ldapEncryptedPassword;
        private string ldapGroupName;

        private IOpsStatusLogManager opsLogManager;

        public DbUserAccessDataProvider(string connectionString, string encryptionSalt, string ldapServer, string ldapUserName, string ldapEncryptedPassword, IOpsStatusLogManager opsLogManager, string ldapGroupName)
            : base(connectionString, encryptionSalt)
        {
            //oracleHelper = new OracleHelper();
            this.ldapServer = ldapServer;
            this.ldapUserName = ldapUserName;
            this.ldapEncryptedPassword = Utility.Decrypt(ldapEncryptedPassword, encryptionSalt);
            this.opsLogManager = opsLogManager;
            this.ldapGroupName = ldapGroupName;
        }

        //public DbUserAccessDataProvider(string connectionString, string encryptionSalt, IOracleHelper oracleHelper)
        //    : base(connectionString, encryptionSalt)
        //{
        //    this.oracleHelper = oracleHelper;
        //}

        private UserAccess[] GetUserAccessCore(string employeeId, string accessObjectType)
        {
            /*fortify issue
            string queryFilterAccessObjectType = string.IsNullOrEmpty(accessObjectType) ? string.Empty : string.Format("AND ACCESSOBJ_TYPE = '{0}'", accessObjectType);
            string query = string.Format("SELECT ACCESSOBJ_TYPE, ACCESSOBJ_ID, ACCESS_TYPE FROM USER_ACCESS ua " +
                                            "WHERE ua.Employee_Id = '{0}' {1} ORDER BY ACCESSOBJ_TYPE, ACCESSOBJ_ID", employeeId, queryFilterAccessObjectType);
            */

            string queryFilterAccessObjectType = string.IsNullOrEmpty(accessObjectType) ? string.Empty : string.Format("AND ACCESSOBJ_TYPE = :objectTypeId");
            string query = string.Format("SELECT ACCESSOBJ_TYPE, ACCESSOBJ_ID, ACCESS_TYPE FROM USER_ACCESS ua " +
                                            "WHERE ua.Employee_Id = :employeeId {0} ORDER BY ACCESSOBJ_TYPE, ACCESSOBJ_ID", queryFilterAccessObjectType);

            string odJobsAccessQuery = string.Format("select COUNT(1) as has_odjob_access from Ops_On_Demand_Job_Access where employee_id = :employee_id");
            OracleParameter odJobsAccessparam = new OracleParameter(":employee_id", OracleDbType.Varchar2) { Value = employeeId };

            List<UserAccess> userAccessList = new List<UserAccess>();
            //using (IDataReader dataReader = oracleHelper.ExecuteReader(this.ConnectionString, CommandType.Text, query))
            using(OracleConnection conn = new OracleConnection(this.ConnectionString))
            using(OracleCommand cmd = new OracleCommand(query, conn))
            {
                // Fortify begin
                cmd.BindByName = true;
                OracleParameter p1 = new Oracle.ManagedDataAccess.Client.OracleParameter("employeeId", employeeId);
                cmd.Parameters.Add(p1);

                if (string.IsNullOrEmpty(accessObjectType) == false)
                {
                    OracleParameter p2 = new Oracle.ManagedDataAccess.Client.OracleParameter("objectTypeId", accessObjectType);
                    cmd.Parameters.Add(p2);
                }

                cmd.CommandType = CommandType.Text;
                cmd.CommandText = query;
                // Fortify end 

                conn.Open();
                try
                {
                    using(OracleDataReader dataReader = cmd.ExecuteReader())
                    {
                        int accessObjTypeCol = dataReader.GetOrdinal("ACCESSOBJ_TYPE");
                        int accessObjIdCol = dataReader.GetOrdinal("ACCESSOBJ_ID");
                        int accessTypeCol = dataReader.GetOrdinal("ACCESS_TYPE");

                        while (dataReader.Read())
                        {
                            var accessObjIdVal = dataReader.GetInt32(accessObjIdCol);
                            var accessObjTypeVal = dataReader.GetString(accessObjTypeCol);
                            var accessTypeVal = dataReader.GetString(accessTypeCol);

                            var userAccessSearch = userAccessList.FirstOrDefault(u => u.AccessObjectType == accessObjTypeVal && u.AccessObjectId == accessObjIdVal);
                            if (userAccessSearch == null)
                            {
                                var userAccess = new UserAccess();
                                userAccess.AccessObjectId = dataReader.GetInt32(accessObjIdCol);
                                userAccess.AccessObjectType = dataReader.GetString(accessObjTypeCol);
                                userAccess.AccessType = new string[] { accessTypeVal };
                                userAccessList.Add(userAccess);
                            }
                            else
                            {
                                var accessTypeList = new List<string>();
                                accessTypeList.AddRange(userAccessSearch.AccessType);
                                accessTypeList.Add(accessTypeVal);
                                userAccessSearch.AccessType = accessTypeList.ToArray();
                            }
                        }
                        dataReader.Close();
                    }

                    if (string.IsNullOrEmpty(accessObjectType) || accessObjectType.Equals(Contracts.Data.KnownValues.Security.mdmFrameworkPortalODJAccessObjType))
                    {
                        //Get the odjobaccess count to build generic claims
                        using (OracleCommand odjAccessCmd = new OracleCommand(odJobsAccessQuery, conn))
                        {
                            odjAccessCmd.Parameters.Add(odJobsAccessparam);

                            int odJobAccessCount = Convert.ToInt32(odjAccessCmd.ExecuteScalar());
                            if (odJobAccessCount > 0)
                            {
                                var odjUserAccess = new UserAccess() { AccessObjectId = 0, AccessObjectType = Contracts.Data.KnownValues.Security.mdmFrameworkPortalODJAccessObjType };
                                odjUserAccess.AccessType = new string[] { Contracts.Data.KnownValues.Security.ClaimValues.ODJ.Trigger };

                                userAccessList.Add(odjUserAccess);
                            }
                        }
                    }
                }
                catch(Exception e)
                {
                    throw;
                }
                finally
                {
                    conn.Close();
                }
                
            }
            return userAccessList.ToArray();
        }

        private UserInfo[] GetUsersCore(string employeeId)
        {
            /* fortify issue
            string employeeFilter = string.IsNullOrEmpty(employeeId) ? string.Empty : string.Format("WHERE u.employee_id = '{0}'", employeeId);
             */
            string employeeFilter = string.IsNullOrEmpty(employeeId) ? string.Empty : string.Format("WHERE u.employee_id = :employeeId");
            string query = string.Format("select u.employee_id, u.last_name, u.first_name, u.email, u.role, u.active, u.user_access, u.user_id " +
                                            " from web_users u  left outer join web_user_roles r on u.role = r.role {0} " +
                                            "order by last_name, first_name", employeeFilter);

            List<UserInfo> userList = new List<UserInfo>();
            using (OracleConnection conn = new OracleConnection(this.ConnectionString))
            using (OracleCommand cmd = new OracleCommand(query, conn))
            {
                // Fortify begin
                cmd.BindByName = true;
                if (string.IsNullOrEmpty(employeeId) == false)
                {
                    OracleParameter p1 = new Oracle.ManagedDataAccess.Client.OracleParameter("employeeId", employeeId);
                    cmd.Parameters.Add(p1);
                }
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = query;
                // Fortify end 
                conn.Open();
                try
                {
                    using (OracleDataReader dataReader = cmd.ExecuteReader())
                    {
                        int employeeIdCol = dataReader.GetOrdinal("employee_id");
                        int lastNameIdCol = dataReader.GetOrdinal("last_name");
                        int firstNamemCol = dataReader.GetOrdinal("first_name");
                        int emailCol = dataReader.GetOrdinal("email");
                        int roleIdCol = dataReader.GetOrdinal("role");
                        int activeCol = dataReader.GetOrdinal("active");
                        int userAccessCol = dataReader.GetOrdinal("user_access");
                        int userIdCol = dataReader.GetOrdinal("user_id");

                        while (dataReader.Read())
                        {
                            var user = new UserInfo() 
                            {
                                EmployeeId = dataReader.GetString(employeeIdCol),
                                FirstName = dataReader.GetString(firstNamemCol),
                                LastName = dataReader.GetString(lastNameIdCol),
                                Email = (dataReader.IsDBNull(emailCol) ? string.Empty : dataReader.GetString(emailCol)),
                                UserRole = (PortalUserRole)dataReader.GetInt16(roleIdCol),
                                Active = (dataReader.GetString(activeCol).Trim() == "Y" ? true : false),
                                UserAccess = (dataReader.IsDBNull(userAccessCol) ? string.Empty : dataReader.GetString(userAccessCol)),
                                UserId = (dataReader.IsDBNull(userIdCol) ? "|" : dataReader.GetString(userIdCol))
                            };

                            userList.Add(user);
                        }
                        dataReader.Close();
                    }
                }
                catch (Exception e)
                {
                    throw;
                }
                finally
                {
                    conn.Close();
                }

            }
            return userList.ToArray();
        }

        protected override UserAccess[] OnGetUserAccessByEmployeeId(string employeeId)
        {
            return GetUserAccessCore(employeeId, null);
        }

        protected override Contracts.Data.MDUA.UserAccess[] OnGetUserAccessByUserId(string userId)
        {
            /* fortify-issue
            string query = string.Format("SELECT ACCESSOBJ_TYPE, ACCESSOBJ_ID, ACCESS_TYPE FROM USER_ACCESS ua " +
                                            "JOIN WEB_USERS u on U.Employee_Id = Ua.Employee_Id " +
                                            "WHERE U.user_id = '{0}' ORDER BY ACCESSOBJ_TYPE, ACCESSOBJ_ID", userId);
             */

            string query = "SELECT ACCESSOBJ_TYPE, ACCESSOBJ_ID, ACCESS_TYPE FROM USER_ACCESS ua " +
                                           "JOIN WEB_USERS u on U.Employee_Id = Ua.Employee_Id " +
                                           "WHERE U.user_id =''||:userId||'' ORDER BY ACCESSOBJ_TYPE, ACCESSOBJ_ID";

            List<UserAccess> userAccessList = new List<UserAccess>();
            //using (IDataReader dataReader = oracleHelper.ExecuteReader(this.ConnectionString, CommandType.Text, query))
            using(OracleConnection conn = new OracleConnection(this.ConnectionString))
            using(OracleCommand cmd = new OracleCommand(query, conn))
            {
                // Fortify begin
                cmd.BindByName = true;
                OracleParameter p1 = new Oracle.ManagedDataAccess.Client.OracleParameter("userId", userId);
                cmd.Parameters.Add(p1);
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = query;
                // Fortify end
                conn.Open();

                try
                {
                    using(OracleDataReader dataReader = cmd.ExecuteReader())
                    {
                        int accessObjTypeCol = dataReader.GetOrdinal("ACCESSOBJ_TYPE");
                        int accessObjIdCol = dataReader.GetOrdinal("ACCESSOBJ_ID");
                        int accessTypeCol = dataReader.GetOrdinal("ACCESS_TYPE");

                        while (dataReader.Read())
                        {
                            var accessObjIdVal = dataReader.GetInt32(accessObjIdCol);
                            var accessObjTypeVal = dataReader.GetString(accessObjTypeCol);
                            var accessTypeVal = dataReader.GetString(accessTypeCol);

                            var userAccessSearch = userAccessList.FirstOrDefault(u => u.AccessObjectType == accessObjTypeVal && u.AccessObjectId == accessObjIdVal);
                            if (userAccessSearch == null)
                            {
                                var userAccess = new UserAccess();
                                userAccess.AccessObjectId = dataReader.GetInt32(accessObjIdCol);
                                userAccess.AccessObjectType = dataReader.GetString(accessObjTypeCol);
                                userAccess.AccessType = new string[] { accessTypeVal };
                                userAccessList.Add(userAccess);
                            }
                            else
                            {
                                var accessTypeList = new List<string>();
                                accessTypeList.AddRange(userAccessSearch.AccessType);
                                accessTypeList.Add(accessTypeVal);
                                userAccessSearch.AccessType = accessTypeList.ToArray();
                            }
                        }
                        dataReader.Close();
                    }
                }
                catch(Exception ex)
                {
                    throw;
                }
                finally
                {
                    conn.Close();
                }
            }
            return userAccessList.ToArray();
        }

        protected override bool OnSaveUserAccessByEmployeeId(string userId, string employeeId, string accessObjectType, Contracts.Data.MDUA.UserAccess[] userAccess)
        {
            bool returnValue = false;

            //string deleteQuery = string.Format("DELETE FROM user_access "
            //    + " WHERE employee_id = '{0}' and Accessobj_Type = '{1}'", employeeId, accessObjectType);
            string deleteQuery = "DELETE FROM user_access "
                + " WHERE employee_id = :employee_id and Accessobj_Type = :accessObjectType";

            //string insertQuery = string.Format("INSERT INTO user_access (access_id, employee_id, accessobj_id, accessobj_type, access_type) "
            //    + " VALUES(mdm_user_access.nextval, '{0}', :accessobj_id, :accessobj_type, :access_type)", employeeId);
            string insertQuery = "INSERT INTO user_access (access_id, employee_id, accessobj_id, accessobj_type, access_type) "
                + " VALUES(mdm_user_access.nextval, :employee_id, :accessobj_id, :accessobj_type, :access_type)";

            //legacy access

            List<OracleParameter> clearAccessParamList = new List<OracleParameter>();
            clearAccessParamList.Add(new OracleParameter(":employee_id", OracleDbType.Varchar2) { Value = employeeId });
            clearAccessParamList.Add(new OracleParameter(":accessObjectType", OracleDbType.Varchar2) { Value = accessObjectType });

            List<string> employeeIdValues = new List<string>();
            List<long> accessObjIdValues = new List<long>();
            List<string> accessObjTypeValues = new List<string>();
            List<string> accessTypeValues = new List<string>();
            foreach(UserAccess ua in userAccess)
            {
                foreach(var role in ua.AccessType)
                {
                    employeeIdValues.Add(employeeId);
                    accessObjIdValues.Add(ua.AccessObjectId);
                    accessObjTypeValues.Add(ua.AccessObjectType);
                    accessTypeValues.Add(role);
                }
            }

            List<OracleParameter> paramsList = new List<OracleParameter>();
            //no need of insert if there no user access sent
            if (accessObjIdValues.Count > 0)
            {
                paramsList.Add(new OracleParameter(":employee_id", OracleDbType.Varchar2) { Value = employeeIdValues.ToArray() });
                paramsList.Add(new OracleParameter(":accessobj_id", OracleDbType.Int64) { Value = accessObjIdValues.ToArray() });
                paramsList.Add(new OracleParameter(":accessobj_type", OracleDbType.Varchar2) { Value = accessObjTypeValues.ToArray() });
                paramsList.Add(new OracleParameter(":access_type", OracleDbType.Varchar2) { Value = accessTypeValues.ToArray() });
            }
            
            //using(OracleCommand oraDeleteCmd = oracleHelper.CreateCommand(oraConn, deleteQuery, null))
            //using (OracleCommand oraCommand = oracleHelper.CreateCommand(oraConn, insertQuery, paramsList.ToArray()))
            using (OracleConnection oraConn = new OracleConnection(this.ConnectionString))
            using (OracleCommand oraDeleteCmd = new OracleCommand(deleteQuery, oraConn))
            using (OracleCommand oraCommand = new OracleCommand())
            {
                oraConn.Open();
                using (OracleTransaction transaction = oraConn.BeginTransaction())
                {
                    try
                    {
                        //delete the roles for the user
                        oraDeleteCmd.Parameters.AddRange(clearAccessParamList.ToArray());
                        var delResult = oraDeleteCmd.ExecuteNonQuery();

                        //no need of insert if there no user access sent
                        if (accessObjIdValues.Count > 0)
                        {
                            oraCommand.Connection = oraConn;
                            oraCommand.CommandText = insertQuery;
                            oraCommand.CommandType = CommandType.Text;
                            //insert roles for the user
                            oraCommand.Parameters.AddRange(paramsList.ToArray());
                            oraCommand.BindByName = true;
                            oraCommand.ArrayBindCount = accessTypeValues.Count;
                            var returnVal = oraCommand.ExecuteNonQuery();
                        }
                        transaction.Commit();
                        returnValue = true;

                        opsLogManager.LogEvent(userId, "OnSaveUserAccessByEmployeeId", string.Format("For {0}", employeeId), "Success", UserToolLogLevel.Audit);
                    }
                    catch
                    {
                        transaction.Rollback();
                    }
                    finally
                    {
                        oraConn.Close();
                    }
                }
            }

            return returnValue;
        }

        protected override Claim[] OnGetUserAccess(string id, string authenticationSourceType)
        {
            List<Claim> claimList = new List<Claim>();

            //Perform only is the authentication source type is SSO or LDAP
            if (authenticationSourceType == "Sso" || authenticationSourceType == "LDAP")
            {
                //Dictionary to hold module level access (a.k.a generic access)
                //if user A has write access to at least one mapping table, then he has generic access to mapping table
                //This generic write access for mapping table is required to for the user to access save (or any write) methods in mapping table
                //After user is allowed to access the save method, the check for access for the specific table will be validated by internal logic in the save method
                Dictionary<string, List<string>> genericAccess = new Dictionary<string, List<string>>();

                var userAccessList = OnGetUserAccessByEmployeeId(id);
                
                foreach (UserAccess ua in userAccessList)
                {
                    foreach (string role in ua.AccessType)
                    {
                        //AccessObjectId = 0, denotes generic access. Some modules like Version management has only generic access. 
                        //These modules doesn't need to be converted to generic access so can be skipped
                        if(ua.AccessObjectId != 0)
                        {
                            //check if dictionary contain the access object type; eg: MT
                            if (genericAccess.ContainsKey(ua.AccessObjectType))
                            {
                                //check if access object type contains this role already
                                if(genericAccess[ua.AccessObjectType].Contains(role) == false)
                                {
                                    //AccessObjectType is available in dictionary but not role; so add it in dictionary
                                    genericAccess[ua.AccessObjectType].Add(role);
                                    //Add generic claim for the AccessObjectType and role
                                    claimList.Add(new Claim(string.Format(Contracts.Data.KnownValues.Security.mdmFrameworkClaimTypeFmt, ua.AccessObjectType, "0"), role));
                                }
                            
                            }
                            else
                            {
                                //Dictionary doesnt contain access object type; so initialize an entry for AccessObjectType and role
                                genericAccess.Add(ua.AccessObjectType, new List<string>() { role });
                                //Add generic claim for the AccessObjectType and role
                                claimList.Add(new Claim(string.Format(Contracts.Data.KnownValues.Security.mdmFrameworkClaimTypeFmt, ua.AccessObjectType, "0"), role));
                            }
                        }

                        //Add specific claims (eg. mapping table) and generic claims only for modules that doesnt have specific claims (eg. Version Mgmt)
                        claimList.Add(new Claim(string.Format(Contracts.Data.KnownValues.Security.mdmFrameworkClaimTypeFmt, ua.AccessObjectType, ua.AccessObjectId), role));
                    }
                }

                //Get user info to see roles
                var userInfo = GetUsersCore(id);
                if (userInfo != null && userInfo.Length > 0)
                {
                    //int userRole = Convert.ToInt32(userInfo[0].UserRole);
                    claimList.Add(new Claim(string.Format(Contracts.Data.KnownValues.Security.mdmFrameworkClaimTypeFmt, Contracts.Data.KnownValues.Security.mdmFrameworkPortalUserRoleAccessObjType, "0"), userInfo[0].UserRole.ToString().ToUpper()));

                    var userUploadClaims = GetUserUploadClaims(userInfo[0].UserAccess);
                    if (userUploadClaims.Length > 0)
                    {
                        claimList.AddRange(userUploadClaims);
                    }
                }

                return claimList.ToArray();
            }
            else
            {
                throw new NotImplementedException();
            }
        }

        private Claim[] GetUserUploadClaims(string userAccess)
        {
            List<Claim> userUploadClaims = new List<Claim>();
            if (userAccess.Contains("ADFK"))
            {
                userUploadClaims.Add(new Claim(string.Format(Contracts.Data.KnownValues.Security.mdmFrameworkClaimTypeFmt, Contracts.Data.KnownValues.Security.mdmFrameworkUserUploadAccessObjectType, "0"), 
                    Contracts.Data.KnownValues.Security.ClaimValues.UserUpload.CanAddUserInputKeys));
            }

            if (userAccess.Contains("ADJN"))
            {
                userUploadClaims.Add(new Claim(string.Format(Contracts.Data.KnownValues.Security.mdmFrameworkClaimTypeFmt, Contracts.Data.KnownValues.Security.mdmFrameworkUserUploadAccessObjectType, "0"),
                    Contracts.Data.KnownValues.Security.ClaimValues.UserUpload.CanPostAdjImmediately));
            }

            if (userAccess.Contains("POAP"))
            {
                userUploadClaims.Add(new Claim(string.Format(Contracts.Data.KnownValues.Security.mdmFrameworkClaimTypeFmt, Contracts.Data.KnownValues.Security.mdmFrameworkUserUploadAccessObjectType, "0"),
                    Contracts.Data.KnownValues.Security.ClaimValues.UserUpload.CanPostAdjToAnyPeriod));
            }

            if (userAccess.Contains("ASFT"))
            {
                userUploadClaims.Add(new Claim(string.Format(Contracts.Data.KnownValues.Security.mdmFrameworkClaimTypeFmt, Contracts.Data.KnownValues.Security.mdmFrameworkUserUploadAccessObjectType, "0"),
                    Contracts.Data.KnownValues.Security.ClaimValues.UserUpload.CanAssignUserFileType));
            }

            if (userAccess.Contains("ASAO"))
            {
                userUploadClaims.Add(new Claim(string.Format(Contracts.Data.KnownValues.Security.mdmFrameworkClaimTypeFmt, Contracts.Data.KnownValues.Security.mdmFrameworkUserUploadAccessObjectType, "0"),
                    Contracts.Data.KnownValues.Security.ClaimValues.UserUpload.CanAssignAutosysOD));
            }

            if (userAccess.Contains("ADFT"))
            {
                userUploadClaims.Add(new Claim(string.Format(Contracts.Data.KnownValues.Security.mdmFrameworkClaimTypeFmt, Contracts.Data.KnownValues.Security.mdmFrameworkUserUploadAccessObjectType, "0"),
                    Contracts.Data.KnownValues.Security.ClaimValues.UserUpload.CanAddNewFileType));
            }

            if (userAccess.Contains("MDOL"))
            {
                userUploadClaims.Add(new Claim(string.Format(Contracts.Data.KnownValues.Security.mdmFrameworkClaimTypeFmt, Contracts.Data.KnownValues.Security.mdmFrameworkUserUploadAccessObjectType, "0"),
                    Contracts.Data.KnownValues.Security.ClaimValues.UserUpload.CanModifyOutline));
            }

            if (userAccess.Contains("CPGA"))
            {
                userUploadClaims.Add(new Claim(string.Format(Contracts.Data.KnownValues.Security.mdmFrameworkClaimTypeFmt, Contracts.Data.KnownValues.Security.mdmFrameworkUserUploadAccessObjectType, "0"),
                    Contracts.Data.KnownValues.Security.ClaimValues.UserUpload.CanProcessCpga));
            }

            if (userAccess.Contains("PFAP"))
            {
                userUploadClaims.Add(new Claim(string.Format(Contracts.Data.KnownValues.Security.mdmFrameworkClaimTypeFmt, Contracts.Data.KnownValues.Security.mdmFrameworkUserUploadAccessObjectType, "0"),
                    Contracts.Data.KnownValues.Security.ClaimValues.UserUpload.CanPostToAnyPeriod));
            }

            return userUploadClaims.ToArray();
        }

        protected override UserAccess[] OnGetUserAccessForAccessObjType(string employeeId, string accessObjectType)
        {
            return GetUserAccessCore(employeeId, accessObjectType);
        }

        protected override Menu[] OnGetMenuForUser(System.Security.Claims.Claim[] userClaims)
        {
            throw new NotImplementedException();
        }

        protected override UserInfo[] OnGetAllUsers()
        {
            return GetUsersCore(string.Empty);
        }

        protected override UserInfo OnGetUser(string employeeId)
        {
            UserInfo user = null;
            UserInfo[] userList = GetUsersCore(employeeId);
            if (userList != null && userList.Length == 1)
            {
                user = userList[0];
            }

            return user;
        }

        protected override UserInfo OnGetUserFromLdap(string vzid)
        {
            UserInfo userInfo = null;
            DirectoryEntry entry = new DirectoryEntry();
            entry.Path = this.ldapServer;
            entry.Username = this.ldapUserName;
            entry.Password = Utility.Decrypt(this.ldapEncryptedPassword, this.EncryptionSalt);

            using (DirectorySearcher mySearcher = new DirectorySearcher(entry))
            {
                mySearcher.PageSize = 1;
                mySearcher.CacheResults = false;
                //Add all properties that need to be fetched   
                mySearcher.PropertiesToLoad.Add("samAccountName");
                mySearcher.PropertiesToLoad.Add("employeeid");
                mySearcher.PropertiesToLoad.Add("employeeNumber");
                mySearcher.PropertiesToLoad.Add("mail");
                mySearcher.PropertiesToLoad.Add("sn");
                mySearcher.PropertiesToLoad.Add("givenname");

                mySearcher.SearchScope = SearchScope.Subtree;

                mySearcher.Filter = string.Format("(&(objectCategory=user)(samAccountName={0}))", vzid);
                SearchResult userResult = mySearcher.FindOne();

                if (userResult != null)
                {
                    using (DirectoryEntry de = userResult.GetDirectoryEntry())
                    {
                        userInfo = new UserInfo();
                        userInfo.EmployeeId = Convert.ToString(de.Properties["employeeNumber"].Value);
                        userInfo.UserId = Convert.ToString(de.Properties["samAccountName"].Value);
                        userInfo.Email = Convert.ToString(de.Properties["mail"].Value);
                        userInfo.FirstName = Convert.ToString(de.Properties["givenname"].Value);
                        userInfo.LastName = Convert.ToString(de.Properties["sn"].Value);

                        de.Close();
                    }
                }
            }

            return userInfo;
        }

        protected override bool OnSaveUserInfo(string userId, UserInfo userInfo)
        {
            bool returnValue = false;
            using (OracleConnection oraConn = new OracleConnection(this.ConnectionString))
            using (OracleCommand oraRunStatusCommand = new OracleCommand())
            {
                oraConn.Open();
                try
                {
                    //Get Run Status Id
                    oraRunStatusCommand.Connection = oraConn;
                    oraRunStatusCommand.CommandType = CommandType.StoredProcedure;
                    oraRunStatusCommand.CommandText = "user_util.update_user";

                    oraRunStatusCommand.Parameters.Add(new OracleParameter("@i_employee_id", OracleDbType.Varchar2, userInfo.EmployeeId, ParameterDirection.Input));
                    oraRunStatusCommand.Parameters.Add(new OracleParameter("@i_first_name", OracleDbType.Varchar2, userInfo.FirstName, ParameterDirection.Input));
                    oraRunStatusCommand.Parameters.Add(new OracleParameter("@i_last_name", OracleDbType.Varchar2, userInfo.LastName, ParameterDirection.Input));
                    oraRunStatusCommand.Parameters.Add(new OracleParameter("@i_email", OracleDbType.Varchar2, userInfo.Email, ParameterDirection.Input));
                    oraRunStatusCommand.Parameters.Add(new OracleParameter("@i_user_id", OracleDbType.Varchar2, userInfo.UserId, ParameterDirection.Input));
                    oraRunStatusCommand.Parameters.Add(new OracleParameter("@i_is_active", OracleDbType.Varchar2, userInfo.Active == true ? "Y" : "N", ParameterDirection.Input));

                    oraRunStatusCommand.ExecuteNonQuery();
                    returnValue = true;

                    opsLogManager.LogEvent(userId, "OnSaveUserInfo", string.Format("For {0}", userInfo.EmployeeId), "Success", UserToolLogLevel.Audit);
                }
                catch
                {
                    throw;
                }
                finally
                {
                    oraConn.Close();
                }
            }

            return returnValue;
        }

        protected override bool OnDeleteUserInfo(string employeeId)
        {
            throw new NotImplementedException();
        }

        protected override ODJobGroup[] OnGetODJobAccess(string employeeId)
        {
            return GetODJobAccessCore(employeeId);
        }

        private ODJobGroup[] GetODJobAccessCore(string employeeId)
        {

            List<ODJobGroup> odJobGroupList = new List<ODJobGroup>();
            string odJobsQuery = "select g.group_id, g.group_name, j.job_id, j.job_name, j.button_text, j.description, j.sub_appl_name " +
                                     " from ops_on_demand_jobs j join ops_on_demand_job_group g on j.job_group_id = g.group_id " +                                     
                                     " order by j.button_text";

            string assignedOdJobsQuery = "select g.group_id, g.group_name, j.job_id, j.job_name, j.button_text, j.description, j.sub_appl_name " +
                                    " from ops_on_demand_jobs j join ops_on_demand_job_group g on j.job_group_id = g.group_id " +
                                    " join ops_on_demand_job_access ja on ja.job_id = j.job_id and ja.employee_id = :employee_id " +
                                    " order by j.button_text";

            string query = string.IsNullOrEmpty(employeeId) ? odJobsQuery : assignedOdJobsQuery;

            Dictionary<long, List<ODJob>> jobGroupDiction = new Dictionary<long, List<ODJob>>();

            using (OracleConnection conn = new OracleConnection(this.ConnectionString))
            using (OracleCommand cmd = new OracleCommand(odJobsQuery, conn))
            {
                // Fortify begin
                cmd.BindByName = true;
                if (string.IsNullOrEmpty(employeeId) == false)
                {
                    OracleParameter p1 = new Oracle.ManagedDataAccess.Client.OracleParameter("employee_id", employeeId);
                    cmd.Parameters.Add(p1);
                }
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = query;
                // Fortify end 
                conn.Open();
                try
                {
                    using (OracleDataReader dataReader = cmd.ExecuteReader())
                    {
                        int groupIdCol = dataReader.GetOrdinal("group_id");
                        int groupNameCol = dataReader.GetOrdinal("group_name");
                        int jobIdCol = dataReader.GetOrdinal("job_id");
                        int jobNameCol = dataReader.GetOrdinal("job_name");
                        int buttonTextCol = dataReader.GetOrdinal("button_text");
                        int descCol = dataReader.GetOrdinal("description");
                        int subAppCol = dataReader.GetOrdinal("sub_appl_name");


                        while (dataReader.Read())
                        {
                            var groupId = dataReader.GetInt64(groupIdCol);
                            var odJob = new ODJob();
                            odJob.Id = dataReader.GetInt64(jobIdCol);
                            odJob.JobGroupId = groupId;
                            odJob.Name = dataReader.GetString(jobNameCol);
                            odJob.UserFriendlyName = dataReader.GetString(buttonTextCol);
                            odJob.Description = dataReader.GetString(descCol);
                            odJob.SubApplicationName = (dataReader.IsDBNull(subAppCol) ? string.Empty : dataReader.GetString(subAppCol));

                            var jobGroupFind = odJobGroupList.FirstOrDefault(g => g.Id == groupId);

                            if (jobGroupFind == null)
                            {
                                var groupName = dataReader.GetString(groupNameCol);
                                var odJobGroup = new ODJobGroup()
                                {
                                    Id = groupId,
                                    Name = groupName
                                };
                                odJobGroupList.Add(odJobGroup);
                                jobGroupDiction.Add(groupId, new List<ODJob>() { odJob });
                            }
                            else
                            {
                                jobGroupDiction[groupId].Add(odJob);
                            }
                        }
                        dataReader.Close();
                    }



                }
                catch (Exception e)
                {
                    throw;
                }
                finally
                {
                    conn.Close();
                }

                foreach (var groupId in jobGroupDiction.Keys)
                {
                    var jobGroupFind = odJobGroupList.FirstOrDefault(g => g.Id == groupId);
                    if (jobGroupFind != null)
                    {
                        jobGroupFind.Jobs = jobGroupDiction[groupId].ToArray();
                    }
                }

                return odJobGroupList.ToArray();
            }
        }

        private FactTable[] GetFactFileTypeAccessCore(string employeeId)
        {

            List<FactTable> factTableList = new List<FactTable>();
            string factTableQuery = "select f.fact_table_id, f.fact_table_name, f.fact_table_desc, f.fact_table_type, null as input_file_code_id, lft.input_file_code, lft.description from Master_Fact_Table f " +
                                    " join Ops_User_Input_File lft on f.fact_table_id = lft.fact_table_id " +
                                    " where F.Fact_Table_Type = 1 " +
                                    " union " +
                                    " select f.fact_table_id, f.fact_table_name, f.fact_table_desc, f.fact_table_type, ft.input_file_code_id, ft.input_file_code, ft.description from Master_Fact_Table f " +
                                    " join Ops_File_Types ft on f.fact_table_id = ft.fact_table_id " +
                                    " where F.Fact_Table_Type = 2 " +
                                    " order by fact_table_desc, input_file_code ";

            string assignedFactTableQuery = "select f.fact_table_id, f.fact_table_name, f.fact_table_desc, f.fact_table_type, null as input_file_code_id, lft.input_file_code, lft.description from Master_Fact_Table f " + 
                                         " join Ops_User_Input_File lft on f.fact_table_id = lft.fact_table_id " +
                                         " join Ops_user_input_file_access fa on lft.input_file_code = fa.input_file_code and Fa.Input_File_Code_Id IS NULL " +
                                         " where F.Fact_Table_Type = 1 and fa.employee_id = :employeeIdLegacy " + 
                                         " union " +
                                         " select f.fact_table_id, f.fact_table_name, f.fact_table_desc, f.fact_table_type, ft.input_file_code_id, ft.input_file_code, ft.description from Master_Fact_Table f " +
                                         " join Ops_File_Types ft on f.fact_table_id = ft.fact_table_id " +
                                         " join Ops_user_input_file_access fa on ft.Input_File_Code_Id = fa.Input_File_Code_Id and Fa.Input_File_Code_Id IS NOT NULL " +
                                         " where F.Fact_Table_Type = 2 and fa.employee_id = :employeeIdNew " +
                                         " order by fact_table_name, input_file_code ";

            string query = string.IsNullOrEmpty(employeeId) ? factTableQuery : assignedFactTableQuery;

            Dictionary<long, List<FactFileType>> factTableDiction = new Dictionary<long, List<FactFileType>>();

            using (OracleConnection conn = new OracleConnection(this.ConnectionString))
            using (OracleCommand cmd = new OracleCommand(query, conn))
            {
                // Fortify begin
                cmd.BindByName = true;
                if (string.IsNullOrEmpty(employeeId) == false)
                {
                    OracleParameter p1 = new Oracle.ManagedDataAccess.Client.OracleParameter("employeeIdLegacy", employeeId);
                    OracleParameter p2 = new Oracle.ManagedDataAccess.Client.OracleParameter("employeeIdNew", employeeId);
                    cmd.Parameters.Add(p1);
                    cmd.Parameters.Add(p2);
                }
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = query;
                // Fortify end 
                conn.Open();
                try
                {
                    using (OracleDataReader dataReader = cmd.ExecuteReader())
                    {
                        int factTableIdCol = dataReader.GetOrdinal("fact_table_id");
                        int factNameCol = dataReader.GetOrdinal("fact_table_name");
                        int factDescCol = dataReader.GetOrdinal("fact_table_desc");
                        int factTypeCol = dataReader.GetOrdinal("fact_table_type");
                        int fileTypeIdCol = dataReader.GetOrdinal("input_file_code_id");
                        int filTypeCodeCol = dataReader.GetOrdinal("input_file_code");
                        int descCol = dataReader.GetOrdinal("description");


                        while (dataReader.Read())
                        {
                            var factTableId = dataReader.GetInt64(factTableIdCol);
                            var fileType = new FactFileType() 
                            {
                                FactTableId = factTableId,
                                FileTypeCodeId = (dataReader.IsDBNull(fileTypeIdCol) ? 0 : dataReader.GetInt64(fileTypeIdCol)),
                                Description = dataReader.GetString(descCol),
                                Code = dataReader.GetString(filTypeCodeCol)
                            };

                            var factTableFind = factTableList.FirstOrDefault(f => f.Id == factTableId);

                            if (factTableFind == null)
                            {
                                var factTableName = dataReader.GetString(factNameCol);
                                var factTableDesc = dataReader.GetString(factDescCol);
                                var factTableType = (dataReader.IsDBNull(fileTypeIdCol) ? 1 : dataReader.GetInt32(factTypeCol));
                                var factTable = new FactTable
                                {
                                    Id = factTableId,
                                    Name = factTableName,
                                    Description = factTableDesc,
                                    FactTableType = (FactTableKnownValues.FactTableType)factTableType
                                };
                                factTableList.Add(factTable);
                                factTableDiction.Add(factTableId, new List<FactFileType>() { fileType });
                            }
                            else
                            {
                                factTableDiction[factTableId].Add(fileType);
                            }
                        }
                        dataReader.Close();
                    }



                }
                catch (Exception e)
                {
                    throw;
                }
                finally
                {
                    conn.Close();
                }

                foreach (var factTableId in factTableDiction.Keys)
                {
                    var factTableFind = factTableList.FirstOrDefault(f => f.Id == factTableId);
                    if (factTableFind != null)
                    {
                        factTableFind.FileTypes = factTableDiction[factTableId].ToArray();
                    }
                }

                return factTableList.ToArray();
            }
        }

        protected override FactTable[] OnGetFactFileTypeAccess(string employeeId)
        {
            return GetFactFileTypeAccessCore(employeeId);
        }

        protected override ODJobGroup[] OnGetAllODJobs()
        {
            return GetODJobAccessCore(string.Empty);
        }

        protected override FactTable[] OnGetAllFactFile()
        {
            return GetFactFileTypeAccessCore(string.Empty);
        }

        protected override bool OnSaveLegacyUserAccess(string userId, Contracts.Data.MDUA.User.LegacyUserAccess legacyUserAccess)
        {
            bool returnValue = false;

            //remove all existing access for the specific user
            //insert access into ops_user_input_file_access
            //string fileTypeAccessInsert = string.Format("insert into ops_user_input_file_access (employee_id, input_file_code, input_file_code_id) " +
            //    " values ('{0}', :input_file_code, :input_file_code_id) ", legacyUserAccess.EmployeeId);
            string fileTypeAccessInsert = "insert into ops_user_input_file_access (employee_id, input_file_code, input_file_code_id) " +
                " values (:employee_id, :input_file_code, :input_file_code_id) ";
            
            List<string> fileTypeCodeValueList = new List<string>();
            List<long> fileTypeCodeIdValueList = new List<long>();
            List<OracleParameterStatus> fileTypeCodeNullValueList = new List<OracleParameterStatus>();
            List<OracleParameterStatus> fileTypeCodeIdNullValueList = new List<OracleParameterStatus>();
            List<string> employeeIdValueFileTypeList = new List<string>();

            foreach(FactFileType factFileType in legacyUserAccess.FactFileTypes)
            {
                if(factFileType.FactTableType == FactTableKnownValues.FactTableType.Legacy)
                {
                    fileTypeCodeValueList.Add(factFileType.Code);
                    fileTypeCodeNullValueList.Add(OracleParameterStatus.Success);

                    fileTypeCodeIdValueList.Add(0);
                    fileTypeCodeIdNullValueList.Add(OracleParameterStatus.NullInsert);
                    employeeIdValueFileTypeList.Add(legacyUserAccess.EmployeeId);
                }

                if(factFileType.FactTableType == FactTableKnownValues.FactTableType.Fbit)
                {
                    fileTypeCodeValueList.Add(string.Empty);
                    fileTypeCodeNullValueList.Add(OracleParameterStatus.NullInsert);
                    fileTypeCodeIdValueList.Add(Convert.ToInt64(factFileType.FileTypeCodeId));
                    fileTypeCodeIdNullValueList.Add(OracleParameterStatus.Success);
                    employeeIdValueFileTypeList.Add(legacyUserAccess.EmployeeId);
                }
            }

            //string odJobAccessInsert = string.Format("insert into ops_on_demand_job_access (job_id, employee_id, display_order)" +
            //    "values (:job_id, '{0}', :display_order)", legacyUserAccess.EmployeeId
            //    );
            string odJobAccessInsert = "insert into ops_on_demand_job_access (job_id, employee_id, display_order)" +
                "values (:job_id, :employee_id, :display_order)";

            List<long> jobIdList = new List<long>();
            List<int> displayOrderList = new List<int>();
            List<string> employeeIdValueODJList = new List<string>();

            int displayOrderCounter = 1;
            foreach (ODJob job in legacyUserAccess.ODJobs)
            {
                jobIdList.Add(job.Id);
                displayOrderList.Add(displayOrderCounter++);
                employeeIdValueODJList.Add(legacyUserAccess.EmployeeId);
            }


            using (OracleConnection oraConn = new OracleConnection(this.ConnectionString))
            using (OracleCommand oraRunStatusCommand = new OracleCommand())
            {
                oraConn.Open();
                using (OracleTransaction transaction = oraConn.BeginTransaction())
                {
                    try
                    {

                        if (legacyUserAccess.UserInformation != null)
                        {
                            OracleCommand userInfoUpdateCmd = new OracleCommand("user_util.update_user_access", oraConn);
                            userInfoUpdateCmd.BindByName = true;
                            userInfoUpdateCmd.CommandType = CommandType.StoredProcedure;
                            userInfoUpdateCmd.Parameters.Add(new OracleParameter("update_count", OracleDbType.Int32, ParameterDirection.ReturnValue));
                            userInfoUpdateCmd.Parameters.Add(new OracleParameter("i_employee_id", OracleDbType.Varchar2)).Value = legacyUserAccess.UserInformation.EmployeeId;
                            userInfoUpdateCmd.Parameters.Add(new OracleParameter("i_role", OracleDbType.Int32)).Value = (int)legacyUserAccess.UserInformation.UserRole;
                            userInfoUpdateCmd.Parameters.Add(new OracleParameter("i_user_access", OracleDbType.Varchar2)).Value = legacyUserAccess.UserInformation.UserAccess;
                            userInfoUpdateCmd.ExecuteNonQuery();
                            if (Convert.ToInt32(userInfoUpdateCmd.Parameters["update_count"].Value.ToString()) < 1)
                            {
                                throw new Exception("user_util.update_user_access - update failed");
                            }
                        }

                        oraRunStatusCommand.Connection = oraConn;
                        oraRunStatusCommand.CommandType = CommandType.StoredProcedure;
                        oraRunStatusCommand.CommandText = "user_util.remove_file_types_od_access";
                        oraRunStatusCommand.BindByName = true;
                        oraRunStatusCommand.Parameters.Add(new OracleParameter("i_employee_id", OracleDbType.Varchar2, legacyUserAccess.EmployeeId, ParameterDirection.Input));
                        oraRunStatusCommand.ExecuteNonQuery();


                        //insert file type access if only if available
                        if (legacyUserAccess.FactFileTypes != null && legacyUserAccess.FactFileTypes.Length > 0)
                        {
                            OracleCommand insertFactFileAccessCmd = new OracleCommand();
                            insertFactFileAccessCmd.Connection = oraConn;
                            insertFactFileAccessCmd.CommandType = CommandType.Text;
                            insertFactFileAccessCmd.CommandText = fileTypeAccessInsert;
                            //param for employee_id
                            OracleParameter employeeIdParamFactFileAccess = new OracleParameter("employee_id", OracleDbType.Varchar2);
                            employeeIdParamFactFileAccess.Value = employeeIdValueFileTypeList.ToArray();
                            insertFactFileAccessCmd.Parameters.Add(employeeIdParamFactFileAccess);
                            //param for input_file_code
                            OracleParameter inputFileCodeParamFactFileAccess = new OracleParameter("input_file_code", OracleDbType.Varchar2);
                            inputFileCodeParamFactFileAccess.Value = fileTypeCodeValueList.ToArray();
                            inputFileCodeParamFactFileAccess.ArrayBindStatus = fileTypeCodeNullValueList.ToArray();
                            insertFactFileAccessCmd.Parameters.Add(inputFileCodeParamFactFileAccess);
                            //param for input_file_code_id
                            OracleParameter inputFileCodeIdParamFactFileAccess = new OracleParameter("input_file_code_id", OracleDbType.Long);
                            inputFileCodeIdParamFactFileAccess.Value = fileTypeCodeIdValueList.ToArray();
                            inputFileCodeIdParamFactFileAccess.ArrayBindStatus = fileTypeCodeIdNullValueList.ToArray();
                            insertFactFileAccessCmd.Parameters.Add(inputFileCodeIdParamFactFileAccess);

                            insertFactFileAccessCmd.ArrayBindCount = fileTypeCodeValueList.Count;

                            var insertedRows = insertFactFileAccessCmd.ExecuteNonQuery();
                        }

                        if (legacyUserAccess.ODJobs != null && legacyUserAccess.ODJobs.Length > 0)
                        {
                            OracleCommand insertODJAccessCmd = new OracleCommand();
                            insertODJAccessCmd.Connection = oraConn;
                            insertODJAccessCmd.CommandType = CommandType.Text;
                            insertODJAccessCmd.CommandText = odJobAccessInsert;
                            //param for employee_id
                            //OracleParameter employeeIdParamFactFileAccess = new OracleParameter("employee_id", OracleDbType.Varchar2, legacyUserAccess.EmployeeId, ParameterDirection.Input);
                            //insertFactFileAccessCmd.Parameters.Add(employeeIdParamFactFileAccess);
                            //param for jobId
                            OracleParameter jobIdParamODJAccess = new OracleParameter("job_id", OracleDbType.Long);
                            jobIdParamODJAccess.Value = jobIdList.ToArray();
                            //jobIdParamODJAccess.ArrayBindStatus = fileTypeCodeNullValueList.ToArray();
                            insertODJAccessCmd.Parameters.Add(jobIdParamODJAccess);
                            //param for employeeId
                            OracleParameter employeeIdParamODJAccess = new OracleParameter("employee_id", OracleDbType.Long);
                            employeeIdParamODJAccess.Value = employeeIdValueODJList.ToArray();
                            insertODJAccessCmd.Parameters.Add(employeeIdParamODJAccess);
                            //param for input_file_code_id
                            OracleParameter displayOrderParamODJAccess = new OracleParameter("display_order", OracleDbType.Int32);
                            displayOrderParamODJAccess.Value = displayOrderList.ToArray();
                            //displayOrderParamODJAccess.ArrayBindStatus = fileTypeCodeIdNullValueList.ToArray();
                            insertODJAccessCmd.Parameters.Add(displayOrderParamODJAccess);

                            insertODJAccessCmd.ArrayBindCount = jobIdList.Count;

                            var insertedRows = insertODJAccessCmd.ExecuteNonQuery();
                        }

                        transaction.Commit();
                        returnValue = true;
                        opsLogManager.LogEvent(userId, "OnSaveLegacyUserAccess", string.Format("For {0}", legacyUserAccess.EmployeeId), "Success", UserToolLogLevel.Audit);
                    }
                    catch
                    {
                        transaction.Rollback();
                        throw;
                    }
                    finally
                    {
                        oraConn.Close();
                    }
                }
            }

            return returnValue;
        }



        //protected override Task<UserAccessFlatPage> OnGetUserAccessFlatAsync(string userId, int pageNumber, int rowsPerPage, int totalRecords)
        //{
        //    throw new NotImplementedException();
        //}

        protected override UserAccessFlatPage OnGetUserAccessFlat(string userId, string accessObjectType, int pageNumber, int rowsPerPage, int totalRecords)
        {
            UserAccessFlatPage userAccessFlatPage = new UserAccessFlatPage() 
            { 
                PageNumber = pageNumber,
                TotalPages = 0,
                TotalRows = totalRecords,
                RowsPerPage = rowsPerPage
            };

            List<UserAccessFlat> userAccessList = new List<UserAccessFlat>();

            using (OracleConnection oraConn = new OracleConnection(this.ConnectionString))
            using (OracleCommand oraCommand = new OracleCommand())
            {
                oraConn.Open();

                OracleCommand userInfoUpdateCmd = new OracleCommand("MDMFRAMEWORK.get_user_access", oraConn);
                //userInfoUpdateCmd.BindByName = true;
                userInfoUpdateCmd.CommandType = CommandType.StoredProcedure;
                userInfoUpdateCmd.Parameters.Add(new OracleParameter("i_page_number", OracleDbType.Int32)).Value = pageNumber;
                userInfoUpdateCmd.Parameters.Add(new OracleParameter("i_rows_per_page", OracleDbType.Int32)).Value = rowsPerPage;
                userInfoUpdateCmd.Parameters.Add(new OracleParameter("io_total_recs", OracleDbType.Int32, ParameterDirection.InputOutput)).Value = totalRecords;
                //userInfoUpdateCmd.Parameters.Add(new OracleParameter("io_total_recs", OracleDbType.Int32)).Value = totalRecords;
                userInfoUpdateCmd.Parameters.Add(new OracleParameter("o_result_cur", OracleDbType.RefCursor, ParameterDirection.Output));
                userInfoUpdateCmd.Parameters.Add(new OracleParameter("o_total_pages", OracleDbType.Int32, ParameterDirection.Output));

                try
                {
                    using (var dataReader = userInfoUpdateCmd.ExecuteReader())
                    {
                        userAccessFlatPage.TotalPages = Convert.ToInt32(userInfoUpdateCmd.Parameters["o_total_pages"].Value.ToString());
                        userAccessFlatPage.TotalRows = Convert.ToInt32(userInfoUpdateCmd.Parameters["io_total_recs"].Value.ToString());

                        int moduleNameOrdinal = dataReader.GetOrdinal("module_name");
                        int moduleItemIdOrdinal = dataReader.GetOrdinal("module_item_id");
                        int moduleItemNameOrdinal = dataReader.GetOrdinal("module_item_name");
                        int moduleItemDescOrdinal = dataReader.GetOrdinal("module_item_desc");
                        int employeeIdOrdinal = dataReader.GetOrdinal("employee_id");
                        int userIdOrdinal = dataReader.GetOrdinal("user_id");
                        int accessTypeOrdinal = dataReader.GetOrdinal("access_type");
                        int lastNameOrdinal = dataReader.GetOrdinal("last_name");
                        int firstNameOrdinal = dataReader.GetOrdinal("first_name");


                        while (dataReader.Read())
                        {

                            var userInfo = new UserInfo()
                            {
                                EmployeeId = (dataReader.IsDBNull(employeeIdOrdinal) ? string.Empty : dataReader.GetString(employeeIdOrdinal)),
                                UserId = (dataReader.IsDBNull(userIdOrdinal) ? string.Empty : dataReader.GetString(userIdOrdinal)),
                                LastName = (dataReader.IsDBNull(lastNameOrdinal) ? string.Empty : dataReader.GetString(lastNameOrdinal)),
                                FirstName = (dataReader.IsDBNull(firstNameOrdinal) ? string.Empty : dataReader.GetString(firstNameOrdinal))
                            };

                            var userAccess = new UserAccessFlat()
                            {
                                AccessObjectDescription = (dataReader.IsDBNull(moduleItemDescOrdinal) ? string.Empty : dataReader.GetString(moduleItemDescOrdinal)),
                                AccessObjectId = (dataReader.IsDBNull(moduleItemIdOrdinal) ? 0 : dataReader.GetInt32(moduleItemIdOrdinal)),
                                AccessObjectType = (dataReader.IsDBNull(moduleNameOrdinal) ? string.Empty : dataReader.GetString(moduleNameOrdinal)),
                                AccessType = new string[] { (dataReader.IsDBNull(accessTypeOrdinal) ? string.Empty : dataReader.GetString(accessTypeOrdinal)) },
                                AccessObjectName = (dataReader.IsDBNull(moduleItemNameOrdinal) ? string.Empty : dataReader.GetString(moduleItemNameOrdinal)),
                                User = userInfo
                            };

                            userAccessList.Add(userAccess);
                        }
                        dataReader.Close();
                    }
                }
                catch (Exception ex)
                {
                    throw;
                }
                finally
                {
                    oraConn.Close();
                }
                
            }

            userAccessFlatPage.UserAccessList = userAccessList.ToArray();
            return userAccessFlatPage;
        }

        protected override Contracts.Data.GenericResponse OnRefreshUsersFromADGroup(string employeeId)
        {
            var response = new Contracts.Data.GenericResponse();

            //GetVZIDList from group
            var vzidList = GetUsersVZIDFromADGroup(employeeId, ldapGroupName);
            //Get UserInfo from ADGroup from vzid list
            var userInfoListFromAD = GetUsersFromVZIDList(employeeId, vzidList);
            //Sync DB
            response = SyncDBWithADUserInfo(employeeId, userInfoListFromAD);

            return response;
        }

        protected override VZ.CFO.MDMFramework.Contracts.Data.MDUA.User.HomepageContent OnGetHomepageContent(string employeeId)
        {
            return this.GetHomepageContentDB(employeeId);
        }

        protected override bool OnUpdateHomepageContent(string employeeId, VZ.CFO.MDMFramework.Contracts.Data.MDUA.User.HomepageContent homepageContent)
        {
            return this.UpdateHomepageContent(employeeId, homepageContent);
        }


        private UserInfo[] GetUsersFromVZIDList(string employeeId, string[] vzidList)
        {
            List<UserInfo> userList = new List<UserInfo>();

            if (vzidList == null || vzidList.Length == 0)
            {
                return userList.ToArray();
            }

            DirectoryEntry dirEntry = new DirectoryEntry() { Path = ldapServer, Username = ldapUserName, Password = ldapEncryptedPassword };
            DirectorySearcher mySearcher = new DirectorySearcher(dirEntry);
            mySearcher.PageSize = 10;
            mySearcher.CacheResults = false;

            //Add all properties that need to be fetched   
            mySearcher.PropertiesToLoad.Add("samAccountName");
            mySearcher.PropertiesToLoad.Add("employeeid");
            mySearcher.PropertiesToLoad.Add("employeeNumber");
            mySearcher.PropertiesToLoad.Add("mail");
            mySearcher.PropertiesToLoad.Add("sn");
            mySearcher.PropertiesToLoad.Add("givenname");
            //The search scope specifies how deep the search needs to be, it can be either 
            //"base"- which means only in the current 
            //level, and "OneLevel" which means the
            //base and one level below and then "subtree"-which means the entire tree needs 
            //to be searched.
            mySearcher.SearchScope = SearchScope.Subtree;

            
            foreach (string vzid in vzidList)
            {
                mySearcher.Filter = string.Format("(&(objectCategory=user)(samAccountName={0}))", vzid);

                SearchResultCollection resultUsers = mySearcher.FindAll();
                foreach (SearchResult srUser in resultUsers)
                {
                    try
                    {
                        DirectoryEntry de = srUser.GetDirectoryEntry();
                        //{
                        //  Get the search result from the collection
                        UserInfo userInfo = new UserInfo();
                        userInfo.Email = (string)de.Properties["mail"].Value;
                        userInfo.EmployeeId = (string)de.Properties["employeeNumber"].Value;
                        userInfo.FirstName = (string)de.Properties["givenname"].Value;
                        userInfo.LastName = (string)de.Properties["sn"].Value;
                        userInfo.UserId = (string)de.Properties["samAccountName"].Value;
                        //aui.EmployeeNumber = (string)de.Properties["employeeid"].Value;
                        userList.Add(userInfo);
                        de.Close();
                        //}
                    }

                    catch (Exception ex)
                    {
                        opsLogManager.LogEvent(employeeId, "DbUserAccessDataProvider", "Fetch User Info from AD", ex, UserToolLogLevel.FatalError);
                        throw ex;
                    }
                }
            }
            return userList.ToArray();
        }

        private string[] GetUsersVZIDFromADGroup(string employeeId, string adGroupName)
        {
            List<string> vzidList = new List<string>();

            SearchResult result;

            DirectoryEntry dirEntry = new DirectoryEntry() { Path = ldapServer, Username = ldapUserName, Password = ldapEncryptedPassword };
            
            DirectorySearcher search = new DirectorySearcher(dirEntry);
            search.Filter = string.Format("(cn={0})", adGroupName);
            search.PropertiesToLoad.Add("member");

            try
            {
                result = search.FindOne();
            }
            catch (DirectoryServicesCOMException dsce)
            {
                opsLogManager.LogEvent(employeeId, "DbUserAccessDataProvider", "Search AD", "Failure", UserToolLogLevel.Error);
                throw new MDMFrameworkException("Error searching users from group", dsce.InnerException);
            }

            if (result != null)
            {
                for (int counter = 0; counter < result.Properties["member"].Count; counter++)
                {
                    // "CN=Bellone\\, Patrick bellopa,OU=IT,OU=Users,OU=HQ,DC=uswin,DC=ad,DC=vzwcorp,DC=com"
                    string MemberInfo = (string)result.Properties["member"][counter];
                    int Start = MemberInfo.IndexOf("CN=");
                    if (Start >= 0)
                    {
                        int End = MemberInfo.IndexOf('=', Start + 3);
                        if (End < 0)
                            MemberInfo = MemberInfo.Substring(Start + 3);
                        else
                        {
                            End = MemberInfo.Substring(Start + 3, End - Start).LastIndexOf(',');
                            MemberInfo = MemberInfo.Substring(Start + 3, End);
                        }

                        Start = MemberInfo.LastIndexOf(' ');
                        //arrNames.Add(MemberInfo.Substring(Start + 1));
                        vzidList.Add(MemberInfo.Substring(Start + 1));
                    }
                }
            }

            return vzidList.ToArray();
        }

        private Contracts.Data.GenericResponse SyncDBWithADUserInfo(string employeeId, UserInfo[] userInfoFromAD)
        {
            var response = new Contracts.Data.GenericResponse();

            List<UserInfo> updateFailureList = new List<UserInfo>();

            if (userInfoFromAD == null || userInfoFromAD.Length == 0)
            {
                response.ResponseType = Contracts.Data.KnownValues.ResponseTypes.Error;
                response.Message = "Could not refresh users in database because no user were fetched from AD Group";
                return response;
            }
            int rowCOunt = 0;
            using (OracleConnection oraConn = new OracleConnection(this.ConnectionString))
            {
                oraConn.Open();
                using (OracleTransaction oraTrans = oraConn.BeginTransaction())
                {
                    try
                    {
                        //start refresh
                        using (OracleCommand startRefreshCommand = new OracleCommand("user_util.user_refresh_start", oraConn))
                        {
                            startRefreshCommand.CommandType = CommandType.StoredProcedure;
                            startRefreshCommand.ExecuteNonQuery();
                        }

                        //update user Info
                        using (OracleCommand updateUsersCommand = new OracleCommand("user_util.update_user", oraConn))
                        {
                            updateUsersCommand.CommandType = CommandType.StoredProcedure;
                            updateUsersCommand.Parameters.Add(new OracleParameter("@i_employee_id", OracleDbType.Varchar2));
                            updateUsersCommand.Parameters.Add(new OracleParameter("@i_first_name", OracleDbType.Varchar2));
                            updateUsersCommand.Parameters.Add(new OracleParameter("@i_last_name", OracleDbType.Varchar2));
                            updateUsersCommand.Parameters.Add(new OracleParameter("@i_email", OracleDbType.Varchar2));
                            updateUsersCommand.Parameters.Add(new OracleParameter("@i_user_id", OracleDbType.Varchar2));

                            
                            foreach (var user in userInfoFromAD)
                            {
                                rowCOunt++;
                                updateUsersCommand.Parameters[0].Value = user.EmployeeId;
                                updateUsersCommand.Parameters[1].Value = user.FirstName;
                                updateUsersCommand.Parameters[2].Value = user.LastName;
                                updateUsersCommand.Parameters[3].Value = user.Email;
                                updateUsersCommand.Parameters[4].Value = user.UserId;
                                try 
                                {
                                    updateUsersCommand.ExecuteNonQuery();
                                }
                                catch(Exception ex)
                                {
                                    updateFailureList.Add(user);
                                    opsLogManager.LogEvent(employeeId, "DbUserAccessDataProvider", "update user from ad", ex, UserToolLogLevel.Error);
                                }
                            }
                        }

                        //End Refresh
                        using (OracleCommand endRefreshCommand = new OracleCommand("user_util.user_refresh_end", oraConn))
                        {
                            endRefreshCommand.CommandType = CommandType.StoredProcedure;
                            endRefreshCommand.ExecuteNonQuery();
                        }

                        oraTrans.Commit();
                        
                    }
                    catch
                    {
                        oraTrans.Rollback();
                        throw;
                    }
                    finally
                    {
                        oraConn.Close();
                    }
                }
            }

            if (updateFailureList.Count == 0)
            {
                response.ResponseType = Contracts.Data.KnownValues.ResponseTypes.Success;
                response.Message = "All users have been refreshed.";
            }
            else
            {
                List<string> detailedMessageList = new List<string>();

                foreach (var user in updateFailureList)
                {
                    detailedMessageList.Add(string.Format("{0} - {1} {2}", user.EmployeeId, user.LastName, user.FirstName));
                }

                response.ResponseType = Contracts.Data.KnownValues.ResponseTypes.Warning;
                response.Message = "Users have been refreshed except for " + string.Join(", ", detailedMessageList.ToArray());
            }

            return response;
        }

        private HomepageContent GetHomepageContentDB(string employeeId)
        {
            var homepageContent = new HomepageContent();
            string query = "SELECT ID, CONTENT, TYPE FROM OPS_HOMEPAGE_CONTENT";

            using (OracleConnection conn = new OracleConnection(this.ConnectionString))
            using (OracleCommand cmd = new OracleCommand(query, conn))
            {

                cmd.BindByName = true;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = query;
                conn.Open();
                try
                {
                    using (OracleDataReader dataReader = cmd.ExecuteReader())
                    {
                        int id_col = dataReader.GetOrdinal("ID");
                        int content_col = dataReader.GetOrdinal("CONTENT");
                        int type_col = dataReader.GetOrdinal("TYPE");

                        if (dataReader.Read())
                        {
                            homepageContent = new HomepageContent()
                            {
                                Id = (dataReader.GetInt32(id_col)).ToString(),
                                Content = dataReader.IsDBNull(content_col) ? string.Empty :  dataReader.GetString(content_col),
                                Type = dataReader.IsDBNull(type_col) ? 0 : dataReader.GetInt32(type_col)
                            };
                        }
                        dataReader.Close();
                    }
                }
                catch (Exception) {
                    throw;
                }
                finally
                {
                    conn.Close();
                }

            }
            return homepageContent;
        }

        private bool UpdateHomepageContent(string employeeId, HomepageContent homepageContent)
        {
            bool status = false;

            using (var conn = new OracleConnection(this.ConnectionString))
            using (var cmd = new OracleCommand("MDMFRAMEWORK.save_homepage_content", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new OracleParameter("i_content_id", OracleDbType.Int32) {Value = homepageContent.Id == null ? 0: int.Parse(homepageContent.Id)});
                cmd.Parameters.Add(new OracleParameter("i_content", OracleDbType.Clob) { Value = homepageContent.Content });
                cmd.Parameters.Add(new OracleParameter("i_content_type", OracleDbType.Int32) { Value = homepageContent.Type });
                conn.Open();

                try
                {
                    cmd.ExecuteNonQuery();
                    status = true;
                    opsLogManager.LogEvent(employeeId, "UpdateHomepageContent", "For updating homepage content", "Success", UserToolLogLevel.Audit);
                }
                catch(Exception)
                {
                    throw;
                }
                finally
                {
                    conn.Close();
                }
            }

            return status;
        }
    }
}
