﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Data.Reporting;
using VZ.CFO.MDMFramework.Providers.Data;

namespace VZ.CFO.MDMFramework.Server.Providers
{
    public class ODataReportingDataProvider : ReportingDataProvider
    {
        public ODataReportingDataProvider(string connectionString, string encryptionSalt)
            : base(connectionString, encryptionSalt)
        { }

        protected override Report OnGetReport(string userId, long reportId)
        {
            throw new NotImplementedException();
        }

        protected override ReportingResponse OnGetReportDataAsync(string userId, long reportId)
        {
            throw new NotImplementedException();
        }

        protected override ReportingResponse OnGetReportDataAsync(string userId, long reportId, int pageNumber, int rowsPerPage, int totalRecords)
        {
            throw new NotImplementedException();
        }

        protected override Task<ReportingResponse> OnGetReportDataAsync(string userId, long reportId, KnownValues.RepositoryType repositoryType)
        {
            throw new NotImplementedException();
        }

        protected override Task<ReportingResponse> OnGetReportDataAsync(string userId, long reportId, KnownValues.RepositoryType repositoryType, int pageNumber, int rowsPerPage, int totalRecords)
        {
            throw new NotImplementedException();
        }

        protected override ReportGroup[] OnGetReports(string userId)
        {
            throw new NotImplementedException();
        }

        protected override ReportGroup OnGetReportsByGroupId(string userId, long groupId)
        {
            throw new NotImplementedException();
        }
    }
}
