﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Providers.Data;

namespace VZ.CFO.MDMFramework.Server.Providers
{
    public class TextFileLogProvider : LogProvider
    {
        private static string logLineFormat = "{0}; Location {1}; {2}";

        public TextFileLogProvider(string logLocation) : base(logLocation) { }

        protected override void OnLogMessage(string module, string message)
        {
            LogToTextFile(this.ConnectionString, module, message);
        }

        protected override void OnLogException(string module, Exception ex)
        {
            string message = "";
            message = "Exception: " + ex.Message + Environment.NewLine + ((ex.StackTrace == null) ? string.Empty : ex.StackTrace);
            LogToTextFile(this.ConnectionString, module, message);
        }

        private static void LogToTextFile(string logFilePath, string module, string message)
        {
            FileStream fs = null;
            StreamWriter sw = null;
            String sLogDirectory = logFilePath;
            string logFileName = "MDMFramework.log"; //DateTime.Now.Date.ToString("yyyyMMdd") + ".log";

            try
            {
                if (!Directory.Exists(sLogDirectory))
                    Directory.CreateDirectory(sLogDirectory);

                if (!File.Exists(sLogDirectory + "/" + logFileName))
                    fs = new FileStream(sLogDirectory + "/" + logFileName, FileMode.Create, FileAccess.Write);
                else
                    fs = new FileStream(sLogDirectory + "/" + logFileName, FileMode.Append, FileAccess.Write);

                sw = new StreamWriter(fs);
                sw.WriteLine(string.Format(logLineFormat, DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.fff"), module, message));
                sw.Flush();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message + Environment.StackTrace);
            }
            finally
            {
                if (!sw.Equals(null))
                    sw.Close();

                if (!fs.Equals(null))
                {
                    fs.Close();
                }
            }
        }
    }
}
