﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Oracle.ManagedDataAccess.Client;
using VZ.CFO.MDMFramework.Contracts.Service;
using VZ.CFO.MDMFramework.Contracts.Data;
using VZ.CFO.MDMFramework.Providers.Data;
namespace VZ.CFO.MDMFramework.Server.Providers
{
    public class DbExportTableManagerDataProvider : ExportTableManagerDataProvider
    {
        private ISecurityManager securityManager = null;
        public DbExportTableManagerDataProvider(string connectionString, string encryptionSalt, ISecurityManager securityManager)
            : base(connectionString, encryptionSalt)
        {
            this.securityManager = securityManager;
        }

        protected override TableValuesPage OnGetTableDataPage(TableInfo tableInfo, int pageIndex)
        {
            
            //Data structure for column data
            Dictionary<int, List<string>> columnDiction = new Dictionary<int, List<string>>();

            //initialize the column in the column dictionary
            for (var colIndex = 0; colIndex < tableInfo.Columns.Length; colIndex++)
            {
                columnDiction.Add(colIndex, new List<string>());
            }
            int startRow = 1 + pageIndex * tableInfo.RowsPerPage;
            int endRow = (pageIndex + 1) * tableInfo.RowsPerPage;
            string pagingQuery = string.Format(tableInfo.PagingQueryTemplate, string.Join(",", tableInfo.Columns.ToArray()), tableInfo.TableName, tableInfo.WhereCause, startRow, endRow);
          
            using (OracleConnection conn = new OracleConnection(tableInfo.ConnectionString))
            using (OracleCommand cmd = new OracleCommand(pagingQuery, conn))
            {
                conn.Open();
                try
                {
                    using (OracleDataReader dataReader = cmd.ExecuteReader())
                    {
                        //Read data from table
                        while (dataReader.Read())
                        {
                            for (var colIndex = 0; colIndex < tableInfo.Columns.Length; colIndex++)
                            {
                                columnDiction[colIndex].Add(dataReader.IsDBNull(colIndex) ? string.Empty : Convert.ToString(dataReader.GetValue(colIndex)));
                            }
                        }

                        dataReader.Close();
                    }
                }
                catch (Exception e)
                {
                    throw;
                }
                finally
                {
                    conn.Close();
                }
            }

            //Assign the values from column diction to return object
            List<ColumnData> ColumnValuesList = new List<ColumnData>();
            for (var colIndex = 0; colIndex < tableInfo.Columns.Length; colIndex++)
            {
                ColumnValuesList.Add(new ColumnData() { Values = columnDiction[colIndex].ToArray() });
            }

            TableValuesPage page = new TableValuesPage(); 
            page.Data = ColumnValuesList.ToArray();
            page.PageNumber = pageIndex + 1;
            return page; 
        }

        protected override string OnGetSignedUrlKey(string userId, string content)
        {
            return  securityManager.GetSignedUrlKey(userId, content);
        }

        protected override string OnVerifySignedUrlKey(string content, string signedUrl)
        {
            return securityManager.VerifySignedUrlKey(content, signedUrl);
        }
    }
}