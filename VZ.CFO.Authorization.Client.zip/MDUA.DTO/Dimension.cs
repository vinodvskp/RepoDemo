﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace MDUA.DTO {
    public class Dimension : IComparable {
        // jevans 8/17/2011 - 24524 -  these cols are not in new loc-dim table, and never used
        //public int DimId = 0;
        //public char Location = ' ';
        //public string LocationSibling = "";
        //public string Alias2 = "";
        public string Parent = "";
        public string MemberName = "";
        public string Alias = "";
        public char Consolidation = ' ';
        public string Storage = " ";
        public string Formula = "";
        public string TwoPass = "";
        public string FldComment = "";
        public string LevelNbr = "";
        public string GenerationNbr = "";
        public DateTime LastUpdated;

        //  Mapping Fields
        public string MapId = null;
        public string Function = null;
        public string Product = null;
        public string ServiceType = null;
        public string ReportingLine = null;
        public string SubAccount = null;

        public string AltFunction = null;

        public string CostCenter = null;

        //  Used to create a Tree View
        public ArrayList arrChildren = null;
        public Dimension ParentNode = null;

        public Dimension() {
        }

        #region IComparable Members

        public int CompareTo(object obj) {
            if (obj is Dimension) {
                int Cmp = Parent.CompareTo(((Dimension)obj).Parent);
                if (Cmp != 0)
                    return Cmp;

                return MemberName.CompareTo(((Dimension)obj).MemberName);
            }

            if (obj is string)
                return MemberName.CompareTo(obj);
            throw new Exception("The method or operation is not implemented.");
        }

        #endregion
    }

}
