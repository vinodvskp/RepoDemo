﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MDUA.DTO {
    public class OnDemandJobInfo {
        public int JobId { get; set; }
        public string JobName = "";
        public string Description = "";
        public string ButtonText = "";
        public string Event = "";
        public DateTime DateCreated = DateTime.MinValue;
        public DateTime DateModified = DateTime.MinValue;
        public string SubApplName { get; set; }

        public OnDemandJobInfo() {
        }
    }
}
