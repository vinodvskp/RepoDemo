﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MDUA.DTO {
    [Serializable]
    public class PlanningActualFact : IComparable<PlanningActualFact> {

        public string RowId { get; set; }
        public string Message { get; set; }
        public decimal Line { get; set; }
        public string FiscalPeriod { get; set; }
        public string Scenario { get; set; }
        public string ExternalSegment { get; set; }
        public string Account { get; set; }
        public string GLAccount { get; set; }
        public string BusinessSegment { get; set; }
        public string LineOfBusiness { get; set; }
        public string Product { get; set; }
        public string TechType { get; set; }
        public string Region { get; set; }
        public string ContractTerm { get; set; }
        public string ServiceType { get; set; }
        public string PlannedEntity { get; set; }
        public string Function { get; set; }
        public string Amount { get; set; }
        public string Source { get; set; }
        public decimal AuditId { get; set; }
        public string Owner { get; set; }
        public string RunStatusId { get; set; }
        public DateTime DateCreated { get; set; }
        public DateTime DateModified { get; set; }
        public string Fact_BegBal { get; set; }
        public string Fact_Jan { get; set; }
        public string Fact_Feb { get; set; }
        public string Fact_Mar { get; set; }
        public string Fact_Apr { get; set; }
        public string Fact_May { get; set; }
        public string Fact_Jun { get; set; }
        public string Fact_Jul { get; set; }
        public string Fact_Aug { get; set; }
        public string Fact_Sep { get; set; }
        public string Fact_Oct { get; set; }
        public string Fact_Nov { get; set; }
        public string Fact_Dec { get; set; }
        public string Year { get; set; }
        public UserInfo FactUser { get; set; }
        public string FactAudit { get; set; }

        public PlanningActualFact() {
            RowId = string.Empty;
            Message = string.Empty;
            Line = 0;
            FiscalPeriod = "201001";
            Scenario = string.Empty;
            ExternalSegment = string.Empty;
            Account = string.Empty;
            GLAccount = string.Empty;
            BusinessSegment = string.Empty;
            LineOfBusiness = string.Empty;
            Product = string.Empty;
            TechType = string.Empty;
            Region = string.Empty;
            ContractTerm = string.Empty;
            ServiceType = string.Empty;
            PlannedEntity = string.Empty;
            Function = string.Empty;
            Amount = string.Empty;
            Source = string.Empty;
            AuditId = 0;
            Owner = string.Empty;
            RunStatusId = string.Empty;
            DateCreated = DateTime.MinValue;
            DateModified = DateTime.MinValue;
            Fact_BegBal = string.Empty;
            Fact_Jan = string.Empty;
            Fact_Feb = string.Empty;
            Fact_Mar = string.Empty;
            Fact_Apr = string.Empty;
            Fact_May = string.Empty;
            Fact_Jun = string.Empty;
            Fact_Jul = string.Empty;
            Fact_Aug = string.Empty;
            Fact_Sep = string.Empty;
            Fact_Oct = string.Empty;
            Fact_Nov = string.Empty;
            Fact_Dec = string.Empty;
            Year = string.Empty;
            FactUser = new UserInfo();
            FactAudit = string.Empty;
        }

        public int CompareTo(PlanningActualFact d1) {
            // not implemented
            return 1;
        }

    }
}

