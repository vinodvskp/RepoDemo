﻿using System;

namespace MDUA.DTO
{
    [Serializable]
    public class ChartFieldDTO : IDTO
    {
        #region Attributes
        private int _dimension_Id;
        private string _type;
        private string _dimension_Name;
        private string _ps_Tree_Name;
        private string _lookup_Key;
        private bool _isVisible;
        private bool _isReported;
        #endregion

        public ChartFieldDTO(int DimensionID, string DimensionName, string PSTreeName, string LookupKey, bool IsVisible, bool IsReported)
        {
            this.Dimension_Id = DimensionID;

            this.Dimension_Name = DimensionName;
            this.PS_Tree_Name = PSTreeName;
            this.Lookup_Key = LookupKey;
            this.IsVisible = IsVisible;
            this.IsReported = IsReported;

        }

        #region Properties
        public int Dimension_Id
        {
            get { return _dimension_Id; }
            set { _dimension_Id = value; }
        }
        public string Type
        {
            get { return _type; }
            set { _type = value; }
        }
        public string Dimension_Name
        {
            get { return _dimension_Name; }
            set { _dimension_Name = value; }
        }
        public string PS_Tree_Name
        {
            get { return _ps_Tree_Name; }
            set { _ps_Tree_Name = value; }
        }
        public string Lookup_Key
        {
            get { return _lookup_Key; }
            set { _lookup_Key = value; }
        }
        public bool IsVisible
        {
            get { return _isVisible; }
            set { _isVisible = value; }
        }
        public bool IsReported
        {
            get { return _isReported; }
            set { _isReported = value; }
        }
        #endregion
    }

}