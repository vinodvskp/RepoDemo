using System;
using System.Collections;

namespace MDUA.DTO {
    public enum UserToolLogLevel : short { FatalError = 1, Error = 3, Message = 5, Audit = 7, Debug = 9 }

    public enum UserRole : short { AnonymousUser = 0, ReadOnly = 1, RegUser = 3, Admin = 9 }
      
    public enum FactTable : int {
        Transaction = 1, Reporting = 2, ReportingAdjustment = 3,
        Proforma = 6, ProformaAdjustment = 7,
        LocationUser = 8, EquipmentUser = 9, DataWarehouseUser = 10,
        ProductOfferUser = 11, PlanningActuals = 12, DevicePaymentLoan = 13
    }

    public enum StageProcessingStatus : int {
        None = -1,
        LoadedToFact = 0,
        AdditionOfKeysRequired = 1,
        CriticalValidationsFailed = 2
    }

    //should match with ops_field_sources table
    public enum FileTypeFieldSource {
        UserFeed = 0,
        UserDefinableUserFeed = 1,
        ForcedValue = 2,
        AutomapOnAccount = 3,
        AutomapOnCostCenter = 4,
        AutomapOnFunction = 5,
        AutomapOnLocation = 6,
        AutomapOnVESAccount = 7,
        AutomapFunctionUsingPlannedEntity = 8,
        AutomapLobUsingPlannedEntity = 9,
        AutomapPlannedEntityUsingFunction = 10,
        AutomapPlannedEntityUsingLob = 11,
        CustomAttributeField = 12

    };

    public enum CustomAttributeType {
        TextBox
        , DropDownList
        , CheckBox
    };

    public enum EspJobStatusState
    {
        Unknown,
        AppNotDefined,
        NoMatchingAppOrUnAuthorized,
        IsInvalidAppSpec,
        Completed,
        InCompleteDependentJobs
        //Running,
        //CompletedSuccessfully,
        //Failed,
        //OnHold,
        //Waiting
    }

    public enum EspLapCommandStatus
    {
        ALL,
        INCOMPLETE,
        JOBS,
        JOB
    }
}