﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace MDUA.DTO {
    public class WPProcessInfo {
        public string ProcessCode = "";
        public string AsRelatesTo = "";
        public int ProcessId = 0;
        public string Description = "";

        public ArrayList arrSteps = null;

        public WPProcessInfo() {
        }
    }
}
