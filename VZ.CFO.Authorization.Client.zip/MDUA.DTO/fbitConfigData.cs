﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MDUA.DTO
{
    public class FbitConfigData
    {
        public string SiteSubfolder { get; set; }
        public string OAuthHost { get; set; }
        public string VMServer { get; set; }
        public string MTServer { get; set; }
        public string LDAPServer { get; set; }
        public string SkipSSO { get; set; }
        public string LoginEID { get; set; }
        public string NotificationType { get; set; }
        public string DatascoopServer { get; set; }
    }
}
