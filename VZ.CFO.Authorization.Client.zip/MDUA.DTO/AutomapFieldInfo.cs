﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MDUA.DTO {
    public class AutomapFieldInfo {
        public FactTable Target { get; set; }
        public string ColumnName { get; set; }
        public string AutomapId { get; set; }
        public string Description { get; set; }

        public AutomapFieldInfo() {
            ColumnName = string.Empty;
            AutomapId = string.Empty;
            Description = string.Empty;
        }

    }
}
