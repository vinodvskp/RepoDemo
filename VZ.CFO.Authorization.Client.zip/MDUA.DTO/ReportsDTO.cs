﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MDUA.DTO
{
    [Serializable]
    public class ReportsDTO: IDTO
    {
        #region Attributes
         /// <summary>
         /// 
         /// </summary>
//MESSAGE_CONTENT, DATE_CREATED
  //              FROM VZW_KPI.MASTER_USER_REPORT
    //            order by date_created desc
        private int _message_Id;
        private string _message_content;
        //private date _date_created;
        #endregion

        public ReportsDTO(int MessageID, string MessageContent, date DateCreated)
        {
            this._message_Id = 0 ;

            this.Message_Id = MessageID  ;
            this.Message_Content = MessageContent;
            this.DateCreated = DateCreated; 
        }

        #region Properties
        public int Message_Id
        {
            get { return _message_Id; }
            set { _message_Id = value; }
        }
        public string Message_Content
        {
            get { return _message_content; }
            set { _message_content = value; }
        }
        public date DateCreated 
        {
            get { return _date_created; }
            set { _date_created = value; }
        }
   
        #endregion
    }

}