﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MDUA.DTO {

    public class UserInfo {
        public string EmployeeID = "";
        public string FirstName = "";
        public string LastName = "";
        public string EMail = "";
        public string UserId = "";          //  User's 5+2 ID.
        public UserRole Role = UserRole.ReadOnly;
        public bool Active = false;
        public string UserAccess = "";

        public bool CanAddUserInputKeys {
            get { return UserAccess.IndexOf("|ADFK|") >= 0; }
            set { UpdAccessType("ADFK", value); }
        }
        public bool CanPostAdjImmediately {
            get { return UserAccess.IndexOf("|ADJN|") >= 0; }
            set { UpdAccessType("ADJN", value); }
        }
        public bool CanPostAdjToAnyPeriod {
            get { return UserAccess.IndexOf("|POAP|") >= 0; }
            set { UpdAccessType("POAP", value); }
        }
        public bool CanAssignUserFileType {
            get { return UserAccess.IndexOf("|ASFT|") >= 0; }
            set { UpdAccessType("ASFT", value); }
        }
        
        public bool CanAssignAutosysOD {
            get { return UserAccess.IndexOf("|ASAO|") >= 0; }
            set { UpdAccessType("ASAO", value); }
        }

        public bool CanAddNewFileType {
            get { return UserAccess.IndexOf("|ADFT|") >= 0; }
            set { UpdAccessType("ADFT", value); }
        }

        public bool CanModifyOutline {
            get { return UserAccess.IndexOf("|MDOL|") >= 0; }
            set { UpdAccessType("MDOL", value); }
        }

        public bool CanProcessCpga {
            get { return UserAccess.IndexOf("|CPGA|") >= 0; }
            set { UpdAccessType("CPGA", value); }
        }

        public bool CanPostToAnyPeriod {
            get { return UserAccess.IndexOf("|PFAP|") >= 0; }
            set { UpdAccessType("PFAP", value); }
        }

        public string FullName {
            get { return FirstName + " " + LastName; }
        }

        public UserInfo() {
        }

        private void UpdAccessType(string KeyVal, bool AddIt) {
            int Idx = UserAccess.IndexOf("|" + KeyVal + "|");
            if (AddIt) {
                //  Add a new key type.  If it is already here, just return.
                if (Idx >= 0)
                    return;
                if (UserAccess.Length == 0)
                    UserAccess = "|";
                UserAccess += KeyVal + "|";
            } else {
                //  Remove an existing key.  If it is not here, just return.
                if (Idx < 0)
                    return;
                UserAccess = UserAccess.Substring(0, Idx + 1) +
                    UserAccess.Substring(Idx + KeyVal.Length + 2, UserAccess.Length - Idx);
            }
        }
    }
}
