﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MDUA.DTO {
    public class CustomTargetAttribute {
        public FactTable Target { get; set; }
        public string AttributeName { get; set; }
        public string ColumnName { get; set; }
        public string Description { get; set; }
        public CustomAttributeType AttributeType { get; set; }
        public string[] DropdownItems { get; set; }

        public CustomTargetAttribute() {
            AttributeName = string.Empty;
            ColumnName = string.Empty;
            Description = string.Empty;
            AttributeType = CustomAttributeType.TextBox;
        }
    }
}
