﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MDUA.DTO {
    public class UserOnDemandDescription {

        public string AutomationToolEvent { get; set; }
        public string AutomationToolJobName { get; set; }
        public string ButtonText { get; set; }
        public int? SequenceId { get; set; }
        public int JobId { get; set; }

        public UserOnDemandDescription() {
            AutomationToolEvent = string.Empty;
            AutomationToolJobName = string.Empty;
            ButtonText = string.Empty;
            SequenceId = null;
        }
    }    
}
