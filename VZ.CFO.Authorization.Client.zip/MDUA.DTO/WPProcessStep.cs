﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MDUA.DTO {
    public class WPProcessStep {
        public string ClosePeriod = "";
        public string Step = "";
        public string StepDescription = "";
        public DateTime StartTime = DateTime.MinValue;
        public DateTime EndTime = DateTime.MinValue;
        public string Status = "";
        public string Message = "";
        public int NotificationId = 0;
        public int ExpectedDuration = 0;
        public int SeqNbr = 0;

        public string StatusDesc {
            get {
                switch (Status) {
                    case "S": return "Success";
                    case "P": return "Pending";
                    case "R": return "Running";
                    case "E": return "Error";
                    case "C": return "Canceled";
                    default: return "No Status";
                }
            }
        }

        public WPProcessStep() {
        }
    }
}
