﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MDUA.DTO {
    public class MasterFactTable {
        public int FactTableId = 0;
        public string FactTableName = "";
        public string FactTableDesc = "";
        public string StageTableYearName = "";
        public string StageTableMonthName = "";
        public string PreFactLoadProcedure = "";
        public string KeyComboTableName = "";
        public string FactTableWithValues = ""; // never used?
        public bool IsLegacy = false;
        public bool AllowsAdjustments = false;
        public bool AllowsOutlook { get; set; }

        public MasterFactTable() {
            AllowsOutlook = true;
        }
    }
}
