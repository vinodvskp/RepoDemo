﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MDUA.DTO {
    public class FileTypeField {
        public string FactColumnName = "";
        public string ForcedValue = "";
        public string DimensionTypeName = "";
        public FileTypeFieldSource Source = FileTypeFieldSource.UserFeed;

        public FileTypeField() {
        }

        public FileTypeField(string columnName, string value, FileTypeFieldSource source) {
            FactColumnName = columnName;
            ForcedValue = value;
            Source = source;
        }
    }
}
