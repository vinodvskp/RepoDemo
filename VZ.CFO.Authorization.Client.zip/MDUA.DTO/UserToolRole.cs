﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MDUA.DTO {
    public class UserToolRole {

        public string Role { get; set; }
        public string Description { get; set; }

        public UserToolRole() {
            Role = string.Empty;
            Description = string.Empty;
        }
    } 
}
