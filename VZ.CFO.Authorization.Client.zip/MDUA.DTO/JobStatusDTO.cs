﻿using System;
using System.Collections.Generic;

namespace MDUA.DTO
{
    [Serializable]
    public class JobStatusDTO : IComparable<JobStatusDTO>
    {
        private string _source;
        private DateTime _dtCreate;
        private string _description;
        private string _scheduledLoad;
        private int _scheduledLoadInt;
        private string _owner;
        private string _status;
        private string _message;

        public string Source
        {
            get { return _source; }
            set { _source = value; }
        }
        public DateTime dtCreate
        {
            get { return _dtCreate; }
            set { _dtCreate = value; }
        }
        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }
        public string ScheduledLoad
        {
            get { return _scheduledLoad; }
            set { _scheduledLoad = value; }
        }

        public int  ScheduledLoadInt
        {
            get
            {
                if (_scheduledLoad.Length > 4)
                    if (int.TryParse(_scheduledLoad.Substring(4, _scheduledLoad.Length - 4), out _scheduledLoadInt))
                        return _scheduledLoadInt;
                    else
                        return 0;
                else
                    return 0;
            }
            set
            { //not implemented
            }
        }
        public string Owner
        {
            get { return _owner; }
            set { _owner = value; }
        }
        public string Status
        {
            get { return _status; }
            set { _status = value; }
        }
        public string Message
        {
            get { return _message; }
            set { _message = value; }
        }
 
        // instantiator 
        public JobStatusDTO()
        {
            Source = "";
            dtCreate = DateTime.MinValue;
            Description = "";
            ScheduledLoad = "";
            ScheduledLoadInt = 0;
            Owner = "";
            Status = "";
            Message = "";
        }

        public int CompareTo(JobStatusDTO d1)
        {
            // not implemented
            return 1;
        }

    }
     #region comparisons


        public class SortBySource   : IComparer<JobStatusDTO> 
        {
            private bool _sortDesc = false;

            
            public SortBySource(bool SortDesc)
            {
                _sortDesc = SortDesc;
            }
           
            //  override instatiator 
            public SortBySource()
            {
                _sortDesc = false;
            }

            public int Compare(JobStatusDTO obj1, JobStatusDTO obj2)
            {
                JobStatusDTO si1 = (JobStatusDTO)obj1;
                JobStatusDTO si2 = (JobStatusDTO)obj2;
                if (_sortDesc)
                    return (String.Compare(si2.Source, si1.Source));
                else
                    return (String.Compare(si1.Source, si2.Source));
            }
        }

        public class SortByDescription : IComparer<JobStatusDTO>
        {
            private bool _sortDesc = false;

            public SortByDescription(bool SortDesc)
            {
                _sortDesc = SortDesc;
            }
            public int Compare(JobStatusDTO obj1, JobStatusDTO obj2)
            {
                JobStatusDTO si1 = (JobStatusDTO)obj1;
                JobStatusDTO si2 = (JobStatusDTO)obj2;
                if (_sortDesc)
                    return (String.Compare(si2.Description, si1.Description));
                else
                    return (String.Compare(si1.Description, si2.Description));

            }
        }

        public class SortByCreateDate : IComparer<JobStatusDTO>
        {
            private bool _sortDesc = false;

            public SortByCreateDate(bool SortDesc)
            {
                _sortDesc = SortDesc;
            }
            public int Compare(JobStatusDTO obj1, JobStatusDTO obj2)
            {
                JobStatusDTO si1 = (JobStatusDTO)obj1;
                JobStatusDTO si2 = (JobStatusDTO)obj2;
                if (_sortDesc)
                    return (si2.dtCreate.CompareTo(si1.dtCreate));
                else
                    return (si1.dtCreate.CompareTo(si2.dtCreate));
            }
        }

        public class SortByLoadBy : IComparer<JobStatusDTO>
        {
            private bool _sortDesc = false;

            public SortByLoadBy(bool SortDesc)
            {
                _sortDesc = SortDesc;
            }
            public int Compare(JobStatusDTO obj1, JobStatusDTO obj2)
            {
                JobStatusDTO si1 = (JobStatusDTO)obj1;
                JobStatusDTO si2 = (JobStatusDTO)obj2;

                if (_sortDesc)
                    return (si2.ScheduledLoadInt.CompareTo(si1.ScheduledLoadInt));
                else
                    return (si1.ScheduledLoadInt.CompareTo(si2.ScheduledLoadInt));
            }
        }

        public class SortByStatus : IComparer<JobStatusDTO>
        {
            private bool _sortDesc = false;

            public SortByStatus(bool SortDesc)
            {
                _sortDesc = SortDesc;
            }
            public int Compare(JobStatusDTO obj1, JobStatusDTO obj2)
            {
                JobStatusDTO si1 = (JobStatusDTO)obj1;
                JobStatusDTO si2 = (JobStatusDTO)obj2;

                if (_sortDesc)
                    return (si2.Status.CompareTo(si1.Status));
                else
                    return (si1.Status.CompareTo(si2.Status));
            }
        }

        public class SortByOwner : IComparer<JobStatusDTO>
        {
            private bool _sortDesc = false;

            public SortByOwner(bool SortDesc)
            {
                _sortDesc = SortDesc;
            }
            public int Compare(JobStatusDTO obj1, JobStatusDTO obj2)
            {
                JobStatusDTO si1 = (JobStatusDTO)obj1;
                JobStatusDTO si2 = (JobStatusDTO)obj2;
                if (_sortDesc)
                    return (si2.Owner.CompareTo(si1.Owner));
                else
                    return (si1.Owner.CompareTo(si2.Owner));
            }
        }
        #endregion 
}
