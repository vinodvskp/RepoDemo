﻿using System;
using System.Collections.Generic;

namespace MDUA.DTO
{
    /*
     * select
            s.reportingline,
           s.account,
           s.kpi,
           s.aview,
           s.year,
           s.month,
           s.scenario,
           s.product,
           s.subaccount,
           s.servicetype,
           s.function,
           s.costcenter,
           s.entity,
           s.company,
           s.fact,
           s.modifydate
     */

    [Serializable]
    public class DataLoadDTO
    {
        private string _reportingLine;
        private string _account;
        private string _kpi;
        private string _view;
        private string _year;
        private string _month;
        private string _scenario;
        private string _product;
        private string _subAccount;
        private string _serviceType;
        private string _function;
        private string _costCenter;
        private string _entity;
        private string _company;
        private decimal _fact;
        private DateTime _modifyDate;

        public string ReportingLine
        {
            get { return _reportingLine; }
            set { _reportingLine = value; }
        }
        public string Account
        {
            get { return _account; }
            set { _account = value; }
        }
        public string KPI
        {
            get { return _kpi; }
            set { _kpi = value; }
        }
        public string View
        {
            get { return _view; }
            set { _view = value; }
        }
        public string Year
        {
            get { return _year; }
            set { _year = value; }
        }
        public string Month
        {
            get { return _month; }
            set { _month = value; }
        }
        public string Scenario
        {
            get { return _scenario; }
            set { _scenario = value; }
        }
        public string Product
        {
            get { return _product; }
            set { _product = value; }
        }
        public string SubAccount
        {
            get { return _subAccount; }
            set { _subAccount = value; }
        }
        public string ServiceType
        {
            get { return _serviceType; }
            set { _serviceType = value; }
        }
        public string Function
        {
            get { return _function; }
            set { _function = value; }
        }
        public string CostCenter
        {
            get { return _costCenter; }
            set { _costCenter = value; }
        }
        public string Entity
        {
            get { return _entity; }
            set { _entity = value; }
        }
        public string Company
        {
            get { return _company; }
            set { _company = value; }
        }
        public Decimal Fact
        {
            get { return _fact; }
            set { _fact = value; }
        }
        public DateTime ModifyDate
        {
            get { return _modifyDate; }
            set { _modifyDate = value; }
        }

        // instantiator 
        public DataLoadDTO()
        {

        }

    }
}

  
