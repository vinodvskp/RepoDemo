﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
namespace MDUA.DTO
{
    /// <summary>
    /// Object used for Esp Request and Response
    /// </summary>
    [DataContract]
    public class EspMessage
    {
        /// <summary>
        /// Represents Info object in ESP Rest API payload for command method 
        /// </summary>
        [DataMember(Name="info")]
        public EspInfo Info { get; set; }
        /// <summary>
        /// Represents Data object in ESP Rest API payload for command method
        /// </summary>
        [DataMember(Name = "data")]
        public EspData Data { get; set; }
    }
}
