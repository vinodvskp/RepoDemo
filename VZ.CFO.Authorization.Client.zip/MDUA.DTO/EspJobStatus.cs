﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MDUA.DTO
{
    public class EspJobStatus
    {
        public string Generation { get; set; }
        public EspJobStatusState Status { get; set; }
        public DateTime? StartedOn { get; set; }
        public DateTime? EndedOn { get; set; }
        public DateTime? AnticipatedEndOn { get; set; }
        public string CompletedJobs { get; set; }
        public string InCompleteJobs { get; set; }
    }
}
