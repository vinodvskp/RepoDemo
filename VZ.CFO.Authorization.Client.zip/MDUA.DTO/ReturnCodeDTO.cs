﻿using System;

namespace MDUA.DTO
{
    [Serializable]
    public class ReturnCodeDTO
    {
        private int _returnCode;
        private string _message;
        private bool _success;

        public int ReturnCode
        {
            get { return _returnCode; }
            set { _returnCode = value; }
        }
        public string Message
        {
            get { return _message; }
            set { _message = value; }
        }
        public bool Success
        {
            get { return _success; }
            set { _success = value; }
        }

        public ReturnCodeDTO(int returnCode, string message, bool success)
        {
            this._returnCode = returnCode;
            this._message = message;
            this._success = success;
        }
        public ReturnCodeDTO()
        {
            this._returnCode = -1;
            this._message = "";
            this._success = false;
        }

    }
}