﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace MDUA.DTO {
    public class FileType : IComparable {
        public int FactTableId = 0;
        public string FileTypeCode = "";
        public string Description = "";
        public bool IsAdjustment = false;
        public bool Is13Month = false;
        public bool IsOutlook = false;
        public bool IsUserFeed = true;
        public bool UsesValidKeyCombos = true;
        public bool ShowOnUploadStatus = true;
        public string ScheduledLoadDate = "";
        public string DestinationTable = "";
        public List<FileTypeField> fields = new List<FileTypeField>();
        // jevans 8/1/2011 - 24524 - retail store: add stage and validation tables to file type object 
        public string StageMonthTable = "";
        public string StageYearTable = "";
        public string ValidationKeyTable = "";
        
        public string SourceColumnName {
            get {
                return FactTable == FactTable.LocationUser
                    || FactTable == FactTable.EquipmentUser
                    || FactTable == FactTable.DataWarehouseUser
                    || FactTable == FactTable.ProductOfferUser
                    || FactTable == FactTable.PlanningActuals
                    || FactTable == FactTable.DevicePaymentLoan
                    ? "source" : "prp_rpt_source";
            }            
        }

        public FileType() { }

        public FactTable FactTable {
            get { return (FactTable)FactTableId; }
        }

        #region IComparable Members

        public int CompareTo(object obj) {
            if (obj is string)
                return FileTypeCode.CompareTo(obj);

            if (obj is FileType)
                return FileTypeCode.CompareTo(((FileType)obj).FileTypeCode);

            throw new Exception("The method or operation is not implemented.");
        }

        #endregion
    }

}
