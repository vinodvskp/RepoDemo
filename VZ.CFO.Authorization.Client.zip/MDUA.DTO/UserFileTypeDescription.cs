﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MDUA.DTO {
    public class UserFileTypeDescription {

        public string FactTableDescription { get; set; }
        public string FileTypeCode { get; set; }
        public string Description { get; set; }
        public string EmployeeId { get; set; }

        public UserFileTypeDescription() {
            FactTableDescription = string.Empty;
            FileTypeCode = string.Empty;
            Description = string.Empty;
            EmployeeId = string.Empty;
        }
    }    
}
