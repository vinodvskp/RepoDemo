﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MDUA.DTO {
    public class ExcelToMapInfo {
        public enum FldTypes { DbString, DbInteger, DbDate, DbFloat };

        public string ExcelName = "";
        public string TblColName = "";
        public FldTypes FldType = FldTypes.DbString;
        public int FldLen = 50;
        public string ValIfNull = null;
        public bool MustExist = false;
        public string TrimValues = null;

        public ExcelToMapInfo() {
        }

        public ExcelToMapInfo(string ExlColName, string DbColName, int Len) {
            ExcelName = ExlColName;
            TblColName = DbColName;
            FldLen = Len;
        }

        public ExcelToMapInfo(string ExlColName, string DbColName, FldTypes ColType) {
            ExcelName = ExlColName;
            TblColName = DbColName;
            FldType = ColType;
        }
    }
}
