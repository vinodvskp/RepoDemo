﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MDUA.DTO
{
   
    public class FactComparer : System.Collections.IComparer 
    {
        private bool _sortDesc = false;
        private string _attrib = "";

        public FactComparer(string attribute, bool SortDesc)
        {
            _attrib = attribute;
            _sortDesc = SortDesc;
        }

        public int Compare(Object o1, Object o2)
        {

            string si1 = "";
            string si2 = "";
            if (o1.GetType().ToString() == "MDUA.DTO.FactValidDTO")
            {
                FactValidDTO f1 = (FactValidDTO)o1;
                FactValidDTO f2 = (FactValidDTO)o2;
                switch (_attrib)
                {
                    case "LineNbr":
                        si1 = f1.Line.ToString("0000000");
                        si2 = f2.Line.ToString("0000000");
                        break;
                    case "ReportingLine":
                        si1 = f1.ReportingLine;
                        si2 = f2.ReportingLine;
                        break;
                    case "Account":
                        si1 = f1.Account;
                        si2 = f2.Account;
                        break;
                    case "KPI":
                        si1 = f1.KPI;
                        si2 = f2.KPI;
                        break;
                    case "View":
                        si1 = f1.View;
                        si2 = f2.View;
                        break;
                    case "Scenario":
                        si1 = f1.Scenario;
                        si2 = f2.Scenario;
                        break;
                    case "SubAcct":
                        si1 = f1.SubAccount;
                        si2 = f2.SubAccount;
                        break;
                    case "ServiceType":
                        si1 = f1.ServiceType;
                        si2 = f2.ServiceType;
                        break;
                    case "Function":
                        si1 = f1.Function;
                        si2 = f2.Function;
                        break;
                    case "CostCenter":
                        si1 = f1.CostCenter;
                        si2 = f2.CostCenter;
                        break;
                    case "Entity":
                        si1 = f1.Entity;
                        si2 = f2.Entity;
                        break;
                    case "Company":
                        si1 = f1.Company;
                        si2 = f2.Company;
                        break;
                    case "Equipment":
                        si1 = f1.Equipment;
                        si2 = f2.Equipment;
                        break;
                    case "TechType":
                        si1 = f1.TechType;
                        si2 = f2.TechType;
                        break;
                    case "StoreStatus":
                        si1 = f1.StoreStatus;
                        si2 = f2.StoreStatus;
                        break;
                    case "DesignType":
                        si1 = f1.DesignType;
                        si2 = f2.DesignType;
                        break;
                    case "LocationType":
                        si1 = f1.LocationType;
                        si2 = f2.LocationType;
                        break;
                    case "LocationSubtype":
                        si1 = f1.LocationSubtype;
                        si2 = f2.LocationSubtype;
                        break;
                    case "TierCode":
                        si1 = f1.LocationTierCode;
                        si2 = f2.LocationTierCode;
                        break;
                    case "MethodType":
                        si1 = f1.MethodType;
                        si2 = f2.MethodType;
                        break;
                    case "SaleType":
                        si1 = f1.SaleType;
                        si2 = f2.SaleType;
                        break;
                    case "DiscountType":
                        si1 = f1.DesignType;
                        si2 = f2.DesignType;
                        break;
                }
            }
            else
            {
                FactDTO f1 = (FactDTO)o1;
                FactDTO f2 = (FactDTO)o2;
                switch (_attrib)
                {
                    case "LineNbr":
                        si1 = f1.Line.ToString("0000000");
                        si2 = f2.Line.ToString("0000000");
                        break;
                    case "ReportingLine":
                        si1 = f1.ReportingLine;
                        si2 = f2.ReportingLine;
                        break;
                    case "Account":
                        si1 = f1.Account;
                        si2 = f2.Account;
                        break;
                    case "KPI":
                        si1 = f1.KPI;
                        si2 = f2.KPI;
                        break;
                    case "View":
                        si1 = f1.View;
                        si2 = f2.View;
                        break;
                    case "Scenario":
                        si1 = f1.Scenario;
                        si2 = f2.Scenario;
                        break;
                    case "SubAcct":
                        si1 = f1.SubAccount;
                        si2 = f2.SubAccount;
                        break;
                    case "ServiceType":
                        si1 = f1.ServiceType;
                        si2 = f2.ServiceType;
                        break;
                    case "Function":
                        si1 = f1.Function;
                        si2 = f2.Function;
                        break;
                    case "CostCenter":
                        si1 = f1.CostCenter;
                        si2 = f2.CostCenter;
                        break;
                    case "Entity":
                        si1 = f1.Entity;
                        si2 = f2.Entity;
                        break;
                    case "Company":
                        si1 = f1.Company;
                        si2 = f2.Company;
                        break;
                    case "Equipment":
                        si1 = f1.Equipment;
                        si2 = f2.Equipment;
                        break;
                    case "TechType":
                        si1 = f1.TechType;
                        si2 = f2.TechType;
                        break;
                    case "StoreStatus":
                        si1 = f1.StoreStatus;
                        si2 = f2.StoreStatus;
                        break;
                    case "DesignType":
                        si1 = f1.DesignType;
                        si2 = f2.DesignType;
                        break;
                    case "LocationType":
                        si1 = f1.LocationType;
                        si2 = f2.LocationType;
                        break;
                    case "LocationSubtype":
                        si1 = f1.LocationSubtype;
                        si2 = f2.LocationSubtype;
                        break;
                    case "TierCode":
                        si1 = f1.LocationTierCode;
                        si2 = f2.LocationTierCode;
                        break;
                    case "MethodType":
                        si1 = f1.MethodType;
                        si2 = f2.MethodType;
                        break;
                    case "SaleType":
                        si1 = f1.SaleType;
                        si2 = f2.SaleType;
                        break;
                    case "DiscountType":
                        si1 = f1.DiscountType;
                        si2 = f2.DiscountType;
                        break;
                }
            }


            if (_sortDesc)
                return (String.Compare(si2, si1));
            else
                return (String.Compare(si1, si2));
        }

    }
   
}
