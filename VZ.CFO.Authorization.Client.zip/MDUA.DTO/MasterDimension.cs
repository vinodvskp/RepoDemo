﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MDUA.DTO {
    public class MasterDimension : IComparable {
        public int Id = 0;
        public string FactColumnName = "";
        public string DimensionTypeName = "";
        public string DimensionLabel = "";
        public string DimVariableType = "";
        public string MasterTable = "";
        public string ValidationColumn = "";
        public string IdColumn = "";
        public string Prefix = "";
        public string TableAlias = "";
        public string ExtraValidationClause = "";
        public string KeyComboValidation = "";
        public bool IsIncludedInUserFeed = false;

        public MasterDimension() {
        }

        public MasterDimension(string factColumnName = "", string dimensionLabel = "", string dimVariableType = "") {
            FactColumnName = factColumnName;
            DimensionLabel = dimensionLabel;
            DimVariableType = dimVariableType;
        }

        #region IComparable Members

        public int CompareTo(object obj) {
            if (obj is string)
                return DimensionLabel.CompareTo(obj);

            if (obj is int)
                return Id.CompareTo(obj);

            if (obj is MasterDimension)
                return DimensionLabel.CompareTo(((MasterDimension)obj).DimensionLabel);

            throw new Exception("The method or operation is not implemented.");
        }

        #endregion
    }
}
