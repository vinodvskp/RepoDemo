﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace MDUA.DTO
{
    /// <summary>
    /// Represents Info object in ESP Rest API payload for command method
    /// </summary>
    [DataContract(Name = "info")]
    public class EspInfo
    {
        /// <summary>
        /// Specifies the status of the request. The values are as follows:
        /// req - For request
        /// succ - Request successful
        /// fail - Request failed
        /// warn - Request successful but it produced a warning
        /// inv - Request format is invalid
        /// </summary>
        [DataMember(Name = "status", EmitDefaultValue = false)]
        public string Status { get; set; }
        /// <summary>
        /// Specifies if there are more blocks available for the message; The values are as follows:
        /// eom - End of message. Indicates the only block of the message or the last block of a multi-block message.
        /// more - More blocks are available for the message. Use this value for all but the last block of a multi-block message.
        /// </summary>
        [DataMember(Name = "cont", EmitDefaultValue = false)]
        public string Cont { get; set; }
        /// <summary>
        /// Type can take only "command" as its value
        /// </summary>
        [DataMember(Name = "type", EmitDefaultValue = false)]
        public string Type { get; set; }
    }
}
