﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MDUA.DTO {
    public class WebSettings {
        public DateTime LastProcessed;
        public string LockedBy = "";
        public bool UserFeedEnabled = true;
        public bool CoaCorEnabled = true;
        public string UserFeedUser = "";
        public string CoaCorUser = "";
        public string CurrentPeriod = "";
        public string BroadcastMessage = "";

        public WebSettings() {
        }

        public string CurrentMonth {
            get { return CurrentPeriod.Substring(4); }
            set {
                if (CurrentPeriod.Length < 4)
                    CurrentPeriod = DateTime.Now.Year.ToString();
                CurrentPeriod = CurrentPeriod.Substring(0, 4);
                if (value.Length < 2)
                    CurrentPeriod += "0";
                CurrentPeriod += value;
            }
        }

        public int CurrentMonthInt {
            get {
                int Mnth = 1;
                int.TryParse(CurrentMonth, out Mnth);
                return Mnth;
            }
            set {
                string Mnth = value.ToString();
                CurrentMonth = Mnth;
            }
        }

        public string CurrentMonthString {
            get {
                string[] Months = { "Beginning Balance","January","February","March","April","May","June",
                "July","August","September","October","November","December" };
                int mnth;
                if (int.TryParse(CurrentMonth, out mnth) == false)
                    mnth = 1;
                return Months[mnth];
            }
        }

        public string CurrentYear {
            get { return CurrentPeriod.Substring(0, 4); }
            set {
                if (CurrentPeriod.Length < 4)
                    CurrentPeriod = value;
                else
                    CurrentPeriod = value + CurrentPeriod.Substring(4);
            }
        }
    }
}
