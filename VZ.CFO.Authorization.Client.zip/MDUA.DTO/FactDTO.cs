﻿using System;

namespace MDUA.DTO
{
    [Serializable]
    public class FactDTO : IComparable<FactDTO>
    {
        private string _rowid;
        
        private decimal _line;
        private string _reportingLine;
        private string _account;
        private string _kPI;
        private string _view;
        private string _scenario;
        private string _product;
        private string _subAcct;
        private string _serviceType;
        private string _function;
        private string _costCenter;
        private string _entity;
        private string _company;
        private string _equipment;
        private string _techType;
        // jevans 8/1/2011 - 24524 - new location dims
        private string _storeStatus;
        private string _designType;
        private string _locationType;
        private string _locationSubtype;
        private string _locationTierCode;
        // jevans 3/12/2012 - 24735 - new device dims
        private string _methodType;
        private string _saleType;
        private string _discountType;
        private string _contractTerm;
        private string _programEligible;
        // jevans 4/26/2012 - 24737 - new VES service dims
        private string _previousType;
        private string _branch;
        private string _connectionType;
        private string _owningGeo;
        private string _owningMgr;
        private string _segment;
        private string _version;
        private string _vertical;

        private string _source;
        private string _tabName;
        private DateTime _factDate;
        private string _month;
        private string _year;
        private string _fact;
        private string _factAudit;
        private decimal _auditId;
        private string _fact_BegBal = null;
        private string _fact_Jan = null;
        private string _fact_Feb = null;
        private string _fact_Mar = null;
        private string _fact_Apr = null;
        private string _fact_May = null;
        private string _fact_Jun = null;
        private string _fact_Jul = null;
        private string _fact_Aug = null;
        private string _fact_Sep = null;
        private string _fact_Oct = null;
        private string _fact_Nov = null;
        private string _fact_Dec = null;


        private DateTime _createDate;

        private UserInfo _factUser = null;

        public string ROWID
        {
            get { return _rowid; }
            set { _rowid = value; }
        }
        public decimal Line
        {
            get { return _line; }
            set { _line = value; }
        }
        public string ReportingLine
        {
            get { return _reportingLine; }
            set { _reportingLine = value; }
        }
        public string Account
        {
            get { return _account; }
            set { _account = value; }
        }
        public string KPI
        {
            get { return _kPI; }
            set { _kPI = value; }
        }
        public string View
        {
            get { return _view; }
            set { _view = value; }
        }
        public string Scenario
        {
            get { return _scenario; }
            set { _scenario = value; }
        }
        public string Product
        {
            get { return _product; }
            set { _product = value; }
        }
        public string SubAccount
        {
            get { return _subAcct; }
            set { _subAcct = value; }
        }
        public string ServiceType
        {
            get { return _serviceType; }
            set { _serviceType = value; }
        }
        public string Function
        {
            get { return _function; }
            set { _function = value; }
        }
        public string CostCenter
        {
            get { return _costCenter; }
            set { _costCenter = value; }
        }
        public string Entity
        {
            get { return _entity; }
            set { _entity = value; }
        }
        public string Company
        {
            get { return _company; }
            set { _company = value; }
        }
        public string Equipment
        {
            get { return _equipment; }
            set { _equipment = value; }
        }
        public string PreviousType
        {
            get { return _previousType; }
            set { _previousType = value; }
        }
        
            public string TechType
        {
            get { return _techType; }
            set { _techType = value; }
        }
        // jevans 8/1/2011 - 24524 - new location dims
        public string StoreStatus
        {
            get { return _storeStatus; }
            set { _storeStatus = value; }
        }
        public string DesignType
        {
            get { return _designType; }
            set { _designType = value; }
        }
        public string LocationType
        {
            get { return _locationType; }
            set { _locationType = value; }
        }
        public string LocationSubtype
        {
            get { return _locationSubtype; }
            set { _locationSubtype = value; }
        }
        public string LocationTierCode
        {
            get { return _locationTierCode; }
            set { _locationTierCode = value; }
        }
        // jevans 3/12/2012 - 24735 - new device dims
        public string MethodType
        {
            get { return _methodType; }
            set { _methodType = value; }
        }
        public string SaleType
        {
            get { return _saleType; }
            set { _saleType = value; }
        }
        public string ContractTerm
        {
            get { return _contractTerm; }
            set { _contractTerm = value; }
        }
        public string ProgramEligible {
            get { return _programEligible; }
            set { _programEligible = value; }
        }
        public string DiscountType
        {
            get { return _discountType; }
            set { _discountType = value; }
        }
        // jevans 4/26/2012 - 24737 - new service dims
        public string Branch
        {
            get { return _branch; }
            set { _branch = value; }
        }
        public string ConnectionType
        {
            get { return _connectionType; }
            set { _connectionType = value; }
        }
        public string OwningGeo
        {
            get { return _owningGeo; }
            set { _owningGeo = value; }
        }
        public string OwningMgr
        {
            get { return _owningMgr; }
            set { _owningMgr = value; }
        }
        public string Segment
        {
            get { return _segment; }
            set { _segment = value; }
        }
        public string Version
        {
            get { return _version; }
            set { _version = value; }
        }
        public string Vertical
        {
            get { return _vertical; }
            set { _vertical = value; }
        }
        // end of public dims 
        
        public string Source
        {
            get { return _source; }
            set { _source = value; }
        }
        public string TableName
        {
            get { return _tabName; }
            set { _tabName = value; }
        }
        public string Month
        {
            get { return _month; }
            set { _month = value; }
        }
        public DateTime FactDate
        {
            get { return _factDate; }
            set { _factDate = value; }
        }
        public string Year
        {
            get { return _year; }
            set { _year = value; }
        }
       
        public string Fact
        {
            get
            {
                if (_fact != null)
                    return _fact;
                else
                    return string.Empty;
            }
            set { _fact = value; }
        }

        public string Fact_BegBal
        {
            get { return _fact_BegBal; }
            set { _fact_BegBal = value; }
        }
        public string Fact_Jan
        {
            get { return _fact_Jan; }
            set { _fact_Jan = value; }
        }
        public string Fact_Feb
        {
            get { return _fact_Feb; }
            set { _fact_Feb = value; }
        }
        public string Fact_Mar
        {
            get { return _fact_Mar; }
            set { _fact_Mar = value; }
        }
        public string Fact_Apr
        {
            get { return _fact_Apr; }
            set { _fact_Apr = value; }
        }
        public string Fact_May
        {
            get { return _fact_May; }
            set { _fact_May = value; }
        }
        public string Fact_Jun
        {
            get { return _fact_Jun; }
            set { _fact_Jun = value; }
        }
        public string Fact_Jul
        {
            get { return _fact_Jul; }
            set { _fact_Jul = value; }
        }
        public string Fact_Aug
        {
            get { return _fact_Aug; }
            set { _fact_Aug = value; }
        }
        public string Fact_Sep
        {
            get { return _fact_Sep; }
            set { _fact_Sep = value; }
        }
        public string Fact_Oct
        {
            get { return _fact_Oct; }
            set { _fact_Oct = value; }
        }
        public string Fact_Nov
        {
            get { return _fact_Nov; }
            set { _fact_Nov = value; }
        }
        public string Fact_Dec
        {
            get { return _fact_Dec; }
            set { _fact_Dec = value; }
        }


        public string FactAudit
        {
            get { return _factAudit; }
            set { _factAudit = value; }
        }
        public decimal AuditId
        {
            get { return _auditId; }
            set { _auditId = value; }
        }
        
        public DateTime CreateModifyDate
        {
            get { return _createDate; }
            set { _createDate = value; }
        }

        public UserInfo FactUser
        {
            get
            {
                return _factUser ;
            }
            set
            {
                _factUser = value;
            }
        }
   
        // instantiator 
        public FactDTO()
        {
            Line = 0;
            ROWID = string.Empty;
            ReportingLine = string.Empty;
            Account = string.Empty;
            KPI = string.Empty;
            View = string.Empty;
            Scenario = string.Empty;
            Product = string.Empty;
            SubAccount = string.Empty;
            ServiceType = string.Empty;
            Function = string.Empty;
            CostCenter = string.Empty;
            Entity = string.Empty;
            Company = string.Empty;
            Equipment = string.Empty;
            PreviousType = string.Empty;
            TechType = string.Empty;
            // jevans 8/1/2010 location dims
            StoreStatus = string.Empty;
            DesignType = string.Empty;
            LocationSubtype = string.Empty;
            LocationType = string.Empty;
            LocationTierCode = string.Empty;
            // jevans 3/12/2012 - 24735 - new device dims
            MethodType = string.Empty;
            SaleType = string.Empty;
            ContractTerm = string.Empty;
            ProgramEligible = string.Empty;
            DiscountType = string.Empty;
            // jevans 5/4/2012 - 24735 - new DWH dims
            Branch = string.Empty;
            ConnectionType = string.Empty;
            OwningGeo = string.Empty;
            OwningMgr = string.Empty;
            Segment = string.Empty;
            Version = string.Empty;
            Vertical = string.Empty;

            FactDate = DateTime.MinValue;
            Month = string.Empty;
            Year = string.Empty;
            Source = string.Empty;
            AuditId = 0;
        }

        public int CompareTo(FactDTO d1)
        {
            // not implemented
            return 1;
        }

    } // end of FactDTO

    [Serializable]
    public class FactValidDTO : FactDTO
    {
        string _validSrc = string.Empty;
        string _rptLne = string.Empty;
        string _rptAcct = string.Empty;
        string _rptKPI = string.Empty;
        string _rptView = string.Empty;
        string _rptScenario = string.Empty;
        string _rptProduct = string.Empty;
        string _rptSubAccnt = string.Empty;
        string _rptService = string.Empty;
        string _rptFunc = string.Empty;
        string _rptCostCenter = string.Empty;
        string _rptEntity = string.Empty;
        string _rptCompany = string.Empty;
        string _rptTechType = string.Empty;
        string _rptEquipment = string.Empty;
        string _rptPrevType = string.Empty;
        string _rptStoreStatus = string.Empty;
        string _rptDesignType = string.Empty;
        string _rptLocationType = string.Empty;
        string _rptLocationSubtype = string.Empty;
        string _rptLocationTierCode = string.Empty;
        string _rptMethodType = string.Empty;
        string _rptSaleType = string.Empty;
        string _contractTermValid = string.Empty;
        string _programEligibleValid = string.Empty;
        string _rptDiscountType = string.Empty;
        string _rptBranchValid = string.Empty;
        string _rptConnTypeValid = string.Empty;
        string _rptOwningGeoValid = string.Empty;
        string _rptOwningMgrValid = string.Empty;
        string _rptSegmentValid = string.Empty;
        string _rptVersionValid = string.Empty;
        string _rptVerticalValid = string.Empty;

        string _rptYear = string.Empty;
        string _rptTime = string.Empty;
        string _message = string.Empty;
     
        public string SourceValid
        {
            get { return _validSrc; }
            set { _validSrc = value; }
        }
        public string ReportLineValid
        {
            get { return _rptLne; }
            set { _rptLne = value; }
        }
        public string AccountValid
        {
            get { return _rptAcct; }
            set { _rptAcct = value; }
        }
        public string KPIValid
        {
            get { return _rptKPI; }
            set { _rptKPI = value; }
        }
        public string ViewValid
        {
            get { return _rptView; }
            set { _rptView = value; }
        }
        public string ScenarioValid
        {
            get { return _rptScenario; }
            set { _rptScenario = value; }
        }
        public string ProductValid
        {
            get { return _rptProduct; }
            set { _rptProduct = value; }
        }
        public string SubAcctValid
        {
            get { return _rptSubAccnt; }
            set { _rptSubAccnt = value; }
        }
        public string ServiceValid
        {
            get { return _rptService; }
            set { _rptService = value; }
        }
        public string FunctionValid
        {
            get { return _rptFunc; }
            set { _rptFunc = value; }
        }
        public string CostCenterValid
        {
            get { return _rptCostCenter; }
            set { _rptCostCenter = value; }
        }
        public string CompanyValid
        {
            get { return _rptCompany; }
            set { _rptCompany = value; }
        }
        public string EntityValid
        {
            get { return _rptEntity; }
            set { _rptEntity = value; }
        }
        public string EquipmentValid
        {
            get { return _rptEquipment; }
            set { _rptEquipment = value; }
        }
        public string PreviousTypeValid
        {
            get { return _rptPrevType; }
            set { _rptPrevType = value; }
        }
        public string TechTypeValid
        {
            get { return _rptTechType; }
            set { _rptTechType = value; }
        }

        public string StoreStatusValid
        {
            get { return _rptStoreStatus; }
            set { _rptStoreStatus = value; }
        }
        public string DesignTypeValid
        {
            get { return _rptDesignType; }
            set { _rptDesignType = value; }
        }
        public string LocationTypeValid
        {
            get { return _rptLocationType; }
            set { _rptLocationType = value; }
        }
        public string LocationSubtypeValid
        {
            get { return _rptLocationSubtype; }
            set { _rptLocationSubtype = value; }
        }
        public string LocationTierCodeValid
        {
            get { return _rptLocationTierCode; }
            set { _rptLocationTierCode = value; }
        }
        public string MethodTypeValid
        {
            get { return _rptMethodType; }
            set { _rptMethodType = value; }
        }
        public string SaleTypeValid
        {
            get { return _rptSaleType; }
            set { _rptSaleType = value; }
        }
        public string ContractTermValid
        {
            get { return _contractTermValid; }
            set { _contractTermValid = value; }
        }
        public string ProgramEligibleValid {
            get { return _programEligibleValid; }
            set { _programEligibleValid = value; }
        }
        public string DiscountTypeValid
        {
            get { return _rptDiscountType; }
            set { _rptDiscountType = value; }
        }
        public string BranchValid
        {
            get { return _rptBranchValid; }
            set { _rptBranchValid = value; }
        }
        public string ConnTypeValid
        {
            get { return _rptConnTypeValid; }
            set { _rptConnTypeValid = value; }
        }
        public string OwningGeoValid
        {
            get { return _rptOwningGeoValid; }
            set { _rptOwningGeoValid = value; }
        }
        public string OwningMgrValid
        {
            get { return _rptOwningMgrValid; }
            set { _rptOwningMgrValid = value; }
        }
        public string SegmentValid
        {
            get { return _rptSegmentValid; }
            set { _rptSegmentValid = value; }
        }
        public string VersionValid
        {
            get { return _rptVersionValid; }
            set { _rptVersionValid = value; }
        }
        public string VerticalValid
        {
            get { return _rptVerticalValid; }
            set { _rptVerticalValid = value; }
        }

        public string YearValid
        {
            get { return _rptYear; }
            set { _rptYear = value; }
        }
        public string TimeValid
        {
            get { return _rptTime; }
            set { _rptTime= value; }
        }
        public string Message
        {
            get { return _message; }
            set { _message = value; }
            }
         
    }// end of FactValid

} // end of namespace 

