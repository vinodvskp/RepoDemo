﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
namespace MDUA.DTO
{
    /// <summary>
    /// Represents Data object in ESP Rest API payload for command method
    /// </summary>
    [DataContract(Name="data")]
    public class EspData
    {
        /// <summary>
        /// Property to represent the actual command. Used in request
        /// For example. TRIGGER EU9TST.EU9#TST4
        /// </summary>
        [DataMember(Name = "request", EmitDefaultValue = false)]
        public string Request { get; set; }
        /// <summary>
        /// A copy of the HTTP status code given in the first line of the header. 
        /// Used in response
        /// </summary>
        [DataMember(Name = "status", EmitDefaultValue = false)]
        public string Status { get; set; }
        /// <summary>
        /// An internal error code specific to the server. Used in response
        /// </summary>
        [DataMember(Name = "code", EmitDefaultValue = false)]
        public string Code { get; set; }
        /// <summary>
        /// A copy of the HTTP status message given in the first line of the header 
        /// and an optional message from the server. Used in response
        /// </summary>
        [DataMember(Name = "message", EmitDefaultValue = false)]
        public string Message { get; set; }
        /// <summary>
        /// A list of strings containing the response to a successful request.. Used in response
        /// </summary>
        [DataMember(Name = "list", EmitDefaultValue = false)]
        public string[] list { get; set; }
    }
}
