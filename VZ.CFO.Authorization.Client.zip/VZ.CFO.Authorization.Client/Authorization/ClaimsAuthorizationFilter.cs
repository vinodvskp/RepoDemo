﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.Authorization.Client.Authorization
{
    public sealed class ClaimsAuthorizationFilter : System.Web.Http.Filters.AuthorizationFilterAttribute
    {
        public override void OnAuthorization(System.Web.Http.Controllers.HttpActionContext actionContext)
        {
            if (null == actionContext)
            {
                throw new ArgumentNullException("ActionContext");
            }

            System.Collections.ObjectModel.Collection<ClaimsAuthorizationAttribute> attributes =
                actionContext.ActionDescriptor.ControllerDescriptor.GetCustomAttributes<ClaimsAuthorizationAttribute>();

            string failedClaims = string.Empty;

            if (false == IsAccessAllowed(attributes, actionContext.RequestContext.Principal, out failedClaims))
            {
                //class level attributes are defined and user does NOT have access...
                ClaimsAuthorizationAttribute.Forbidden(actionContext);
            }

            //evaluate action level attributes
            attributes = actionContext.ActionDescriptor.GetCustomAttributes<ClaimsAuthorizationAttribute>();
            if (false == IsAccessAllowed(attributes, actionContext.RequestContext.Principal, out failedClaims))
            {
                ClaimsAuthorizationAttribute.Forbidden(actionContext);
                return;
            }

            base.OnAuthorization(actionContext);
        }

        /// <summary>
        /// Evaluates if user has access based on attribute collection
        /// </summary>
        /// <param name="attributes"></param>
        /// <param name="principal"></param>
        /// <param name="failedClaims"></param>
        /// <returns>True if attributes do not exist or user has access. False if user is not a Bearer or user doesn't posses required claims.</returns>
        private bool IsAccessAllowed(System.Collections.ObjectModel.Collection<ClaimsAuthorizationAttribute> attributes, System.Security.Principal.IPrincipal principal, out string failedClaims)
        {
            failedClaims = string.Empty;

            if (null == attributes || attributes.Count == 0)
            {
                return true;
            }

            System.Security.Claims.ClaimsPrincipal cp = principal as System.Security.Claims.ClaimsPrincipal;
            if (null == cp)
            {
                return false;
            }

            System.Text.StringBuilder sb = new StringBuilder();
            foreach (ClaimsAuthorizationAttribute attr in attributes)
            {
                if (attr.HasAccess(cp))
                {
                    return true;
                }

                if (sb.Length > 0)
                {
                    sb.Append(", ");
                }
                sb.Append(attr.Name);
            }

            failedClaims = sb.ToString();
            return false;
        }
    }
}
