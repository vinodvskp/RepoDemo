﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.Authorization.Client.Authorization
{
    [Serializable]
    [AttributeUsage(AttributeTargets.Method | AttributeTargets.Class, AllowMultiple = true, Inherited = true)]
    public sealed class ClaimsAuthorizationAttribute : Attribute
    {
        public static class CommonClaimValues
        {
            public const string Read = "read";
            public const string Write = "write";
        }

        public string Name { get; private set; }
        public string Value { get; private set; }

        public ClaimsAuthorizationAttribute(string name, string value)
        {
            this.Name = name;
            this.Value = value;
        }

        public static void Forbidden(System.Web.Http.Controllers.HttpActionContext actionContext)
        {
            SetResponse(actionContext, System.Net.HttpStatusCode.Forbidden, "Forbidden");
        }

        public static void Unauthorized(System.Web.Http.Controllers.HttpActionContext actionContext)
        {
            SetResponse(actionContext, System.Net.HttpStatusCode.Unauthorized, "Unauthorized");
        }

        public bool HasAccess(System.Security.Claims.ClaimsPrincipal principal)
        {
            if (null == principal)
            {
                return false;
            }

            return principal.HasClaim(this.Name, this.Value);
        }

        private static void SetResponse(System.Web.Http.Controllers.HttpActionContext actionContext, System.Net.HttpStatusCode status, string message)
        {
            if (null == actionContext)
            {
                throw new ArgumentNullException("actionContext");
            }

            actionContext.Response = new System.Net.Http.HttpResponseMessage(status);
            actionContext.Response.Content = new System.Net.Http.StringContent(message);
            actionContext.Response.RequestMessage = actionContext.Request;
        }
    }
}
