﻿using System;
using System.Threading.Tasks;
using Microsoft.Owin;
using Owin;
using System.Web.Http;
using Microsoft.Owin.Security.DataHandler.Encoder;
using Microsoft.Owin.Security.Jwt;
using Microsoft.Owin.Security;
using System.Threading;
using Microsoft.AspNet.SignalR;
using VZ.CFO.MDMFramework.Services.Controllers;
using Microsoft.Owin.Cors;
using VZ.CFO.MDMFramework.Services.FIlter;

[assembly: OwinStartup(typeof(VZ.CFO.MDMFramework.Services.Startup.Startup))]

namespace VZ.CFO.MDMFramework.Services.Startup
{
    public partial class Startup
    {
        public static void RegisterDataProviders(Configuration.ConfigurationManager config)
        {
            if (config == null)
            {
                throw new ArgumentNullException("config");
            }

            Microsoft.Practices.Unity.UnityContainer container = new Microsoft.Practices.Unity.UnityContainer();

            container.RegisterInstance(typeof(Configuration.ConfigurationManager), typeof(Configuration.ConfigurationManager).Name,
                config, new Microsoft.Practices.Unity.ContainerControlledLifetimeManager());

            container.RegisterInstance(typeof(Providers.MappingTableDataProvider), typeof(Providers.MappingTableDataProvider).Name,
                config.GetMappingTableDataProvider(), new Microsoft.Practices.Unity.ContainerControlledLifetimeManager());

            container.RegisterInstance(typeof(Providers.Data.UserAccessDataProvider), typeof(Providers.Data.UserAccessDataProvider).Name,
                config.GetUserAccessDataProvider(), new Microsoft.Practices.Unity.ContainerControlledLifetimeManager());


            Providers.DataProviderFactory.ActivateFactoryInstace(container);
        }

        public void Configuration(IAppBuilder app)
        {
            // For more information on how to configure your application, visit http://go.microsoft.com/fwlink/?LinkID=316888
            HttpConfiguration config = new HttpConfiguration();
            config.EnableCors();
            config.MapHttpAttributeRoutes();

            ConfigureAuth(app);
            config.Filters.Add(new VZ.CFO.Authorization.Client.Authorization.ClaimsAuthorizationFilter());
            config.Filters.Add(new CustomExceptionFilter());

            app.UseWebApi(config);

            // Branch the pipeline here for requests that start with "/signalr"
            app.Map("/signalr", map =>
            {
                // Setup the CORS middleware to run before SignalR.
                // By default this will allow all origins. You can 
                // configure the set of origins and/or http verbs by
                // providing a cors options with a different policy.
                map.UseCors(CorsOptions.AllowAll);
                var hubConfiguration = new HubConfiguration
                {
                    // You can enable JSONP by uncommenting line below.
                    // JSONP requests are insecure but some older browsers (and some
                    // versions of IE) require JSONP to work cross domain
                    EnableJSONP = true
                };
                // Run the SignalR pipeline. We're not using MapSignalR
                // since this branch already runs under the "/signalr"
                // path.
                map.RunSignalR(hubConfiguration);
            });

            //app.MapSignalR();
        }

        private void ConfigureAuth(IAppBuilder app)
        {
            var issuer = "http://localhost:62236";
            var client = "MDM Portal";
            var secret = TextEncodings.Base64Url.Decode("ac8ee176-1ba7-4b19-bb64-b9e684e6f579");

            // Api controllers with an [Authorize] attribute will be validated with JWT
            app.UseJwtBearerAuthentication(
                new JwtBearerAuthenticationOptions
                {
                    AuthenticationMode = AuthenticationMode.Active,
                    AllowedAudiences = new[] { client },
                    IssuerSecurityTokenProviders = new IIssuerSecurityTokenProvider[]
                    {
                        new SymmetricKeyIssuerSecurityTokenProvider(issuer, secret)
                    }
                });
        }
    }
}
