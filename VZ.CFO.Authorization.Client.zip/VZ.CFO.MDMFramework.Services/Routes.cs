﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VZ.CFO.MDMFramework.Services
{
    public static class Routes
    {
        public const string Root = "api";

        public static class MappingTableMgmt
        {
            //RoutePrefix - used at class level
            public const string Root = Routes.Root + "/MappingTableMgmt";
            //Route - used at method level
            public const string GetAllMappingTables = "GetAllMappingTables";
            public const string GetMappingTableInfo = "GetMappingTableInfo/{mappingTableId}";
            public const string GetMappingTableFirstPageData = "GetMappingTableFirstPageData/{id}/{rowsPerPage}";
            public const string GetMappingTablePageData = "GetMappingTablePageData/{mappingTableId}/{pageNumber}/{rowsPerPage}/{totalRecords}";
            public const string GetMappingTableFirstPageDataFromLowerEnv = "GetMappingTableFirstPageDataFromLowerEnv/{id}/{rowsPerPage}";
            public const string GetMappingTablePageDataFromLowerEnv = "GetMappingTablePageDataFromLowerEnv/{mappingTableId}/{pageNumber}/{rowsPerPage}/{totalRecords}";
            public const string ExportMappingTable = "ExportMappingTable/{mappingTableId}/{signedUrl}";
            public const string GetAuditLogFirstPageData = "GetAuditLogFirstPageData/{mappingTableId}/{auditType}/{rowsPerPage}";
            public const string GetAuditLogPageData = "GetAuditLogPageData/{mappingTableId}/{auditType}/{pageNumber}/{rowsPerPage}/{totalRecords}";
            public const string GetAuditLogSearchFirstPageData = "GetAuditLogSearchFirstPageData/{mappingTableId}/{auditType}/{rowsPerPage}/{searchKey}";
            public const string GetAuditLogSearchPageData = "GetAuditLogSearchPageData/{mappingTableId}/{auditType}/{pageNumber}/{rowsPerPage}/{totalRecords}/{searchKey}";
            public const string SaveMappingTableData = "SaveMappingTableData";
            public const string ValidateMappingTableData = "ValidateMappingTableData";
            public const string MigrateMappingValues = "MigrateMappingValues";
            public const string GetSignedUrlForExportMappingTable = "GetSignedUrlForExportMappingTable/{mappingTableId}";
        }

        public static class PushNotification
        {
            public const string Root = Routes.Root + "/PushNotification";
            public const string ClientSubscription = "ClientSubscribe/{appName}/{appModule}";
        }

        public static class MDUA
        {
            public const string Root = Routes.Root + "/mdua";
            public static class UserAccess
            {
                public const string Root = MDUA.Root + "/useraccess";
                public const string GetUserAccess = "GetUserAccess/{id}/{authenticationType}";
                public const string GetUserAccessByEmployeeId = "GetUserAccessByEmployeeId/{employeeId}";
                public const string GetUserAccessByUserId = "GetUserAccessByUserId/{userId}";
                public const string SaveUserAccessByEmployeeId = "SaveUserAccessByEmployeeId/{employeeId}/{accessObjectType}";
                public const string GetUserAccessForAccessObjType = "GetUserAccessForAccessObjType/{employeeId}/{accessObjectType}";
                public const string GetMenuForUser = "GetMenuForUser";
                public const string GetAllUsers = "GetAllUsers";
                public const string GetUser = "GetAllUsers/{employeeId}";
                public const string GetRolesFromAuthToken = "GetRolesFromAuthToken";
                
                public const string GetUserFromLdap = "GetUserFromLdap/{vzid}";
                public const string SaveUserInfo = "SaveUserInfo";
                public const string DeleteUserInfo = "DeleteUserInfo/{employeeId}";
                public const string GetAllODJobs = "GetAllODJobs";
                public const string GetODJobAccess = "GetODJobAccess/{employeeId}";
                public const string GetFactFileTypeAccess = "GetFactFileTypeAccess/{employeeId}";
                public const string GetAllFactFile = "GetAllFactFile";
                public const string SaveLegacyUserAccess = "SaveLegacyUserAccess";
                public const string GetUserAccessFlat = "GetUserAccessFlat";
                public const string GetSignedUrlForExportUsers = "GetSignedUrlForExportUsers/{exportType}";
                public const string ExportUsers = "ExportUsers/{employeeId=employeeId}/{exportType=exportType}/{signedUrl=signedUrl}";
                public const string RefreshUsersFromADGroup = "RefreshUsersFromADGroup";
                public const string GetHomeMenuItem = "GetHomeMenuItem";
              
                public const string AuditUser = "AuditUser";
                public const string GetHomepageContent = "GetHomepageContent/{eid}";
                public const string PostHomepageContent = "PostHomepageContent/{eid}";
            }

            public static class ODJobs
            {
                public const string Root = MDUA.Root + "/odjobs";
                public const string GetAllODJobGroups = "GetAllODJobGroups";
                public const string GetAllODJobs = "GetAllODJobs/{groupId}";
                public const string GetODJob = "GetODJob/{jobId}";
                public const string GetODJobParamValues = "GetODJobParams/{paramId}";
                public const string GetODJobAssocaiteParamValues = "GetODJobParams";
                public const string TriggerODJob = "TriggerODJob";
                public const string GetODJobStatus = "GetODJobStatus/{jobId}";
                public const string GetODJobStatusByGeneration = "GetODJobStatus/{jobId}/{generation}";
            }

            public static class FactTable
            {
                public const string Root = MDUA.Root + "/facttable";
                public const string GetAllFactTables = "GetAllFactTables";
                public const string GetFactTable = "GetFactTable/{factTableId}";
                public const string GetFactFileTypes = "GetFactFileTypes/{factTableId}";
                public const string GetFactFileTypesBasic = "GetFactFileTypesBasic";
                public const string GetFactFileType = "GetFactFileType";
                public const string DeleteFactFileType = "DeleteFactFileType";
                public const string SaveFactFileType = "SaveFactFileType";
                public const string GetKeyCombinations = "GetKeyCombinations";
                public const string DeleteKeyCombinations = "DeleteKeyCombinations";
                public const string MoveKeyCombinations = "MoveKeyCombinations";
                public const string DownloadFactTable = "DownloadFactTable";
                public const string DownloadKeyCombinations = "DownloadKeyCombinations";
                public const string GetSignedUrlForFactTable = "GetSignedUrlForFactTable";
                public const string GetSignedUrlForKeyCombinations = "GetSignedUrlForKeyCombinations";
                public const string GetFactTableSetting = "GetFactTableSetting";
                public const string GetAuditData = "GetAuditData";
                public const string GetDimensionValues = "GetDimensionValues";
                public const string ExportAuditData = "ExportAuditData";
                public const string GetCurrentPeriod = "GetCurrentPeriod/{factTableId}";
                
            }

            public static class FactTableUserUpload
            {
                public const string Root = MDUA.Root + "/facttableuserupload";
                public const string UploadFactFile = "UploadFactFile";
                public const string UploadFactFileBytes = "UploadFactFileBytes";
                public const string UploadFactData = "UploadFactData";
                public const string GetDimYears = "GetDimYears";
                public const string AddKeysFromStagedData = "AddKeysFromStagedData/{runStatusId}/{factTableId}/{factFileTypeId}";
                public const string AddKeysAndUploadFact = "AddKeysAndUploadFact";
                public const string GetMaxUploadFileSize = "GetMaxUploadFileSize";
            }

            public static class FileTransfer
            {
                public const string Root = MDUA.Root + "/fileTransfer";

                public const string GetFileTransferProfiles = "GetFileTransferProfiles";
                public const string GetFileTransferProfile = "GetFileTransferProfile/{profileId}";
                public const string TransferFile = "TransferFile";
                public const string GetSignedUrlForDownload = "GetSignedUrlForDownload";
                public const string FolderList = "FolderList";
                public const string DownLoad = "Download";
                public const string DeleteFile = "DeleteFile";
                public const string RenameFile = "RenameFile";
            }

            
        }

        public static class Reporting
        {
            public const string Root = Routes.Root + "/reporting";

            public const string GetReports = "GetReports";
            public const string GetReport = "GetReport/{reportId}";
            public const string GetReportData = "GetReportData/{reportId}";
            public const string GetReportDataPage = "GetReportDataPage/{reportId}/{pageNumber}/{rowsPerPage}/{totalRecords}";
            public const string GetSignedUrlForExportReport = "GetSignedUrlForExportReport/{reportId}";
            public const string ExportReport = "ExportReport/{reportId}/{signedUrl}";
        }
    }
}