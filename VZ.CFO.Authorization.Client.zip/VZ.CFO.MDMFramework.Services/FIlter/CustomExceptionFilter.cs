﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http.Filters;
using VZ.CFO.MDMFramework.Common;
using VZ.CFO.MDMFramework.Configuration;
using VZ.CFO.MDMFramework.Contracts.Service;
using VZ.CFO.MDMFramework.Providers;

namespace VZ.CFO.MDMFramework.Services.FIlter
{
    public class CustomExceptionFilter : ExceptionFilterAttribute
    {
        private ILogManager logManager = null;

        public CustomExceptionFilter()
        {
            logManager = GetLogManager();
        }

        public override void OnException(HttpActionExecutedContext actionExecutedContext)
        {
            string exceptionMessage = string.Empty;

            MDMFrameworkException mdmException = actionExecutedContext.Exception as MDMFrameworkException;


            if (actionExecutedContext.Exception.InnerException == null)
            {
                exceptionMessage = actionExecutedContext.Exception.Message;
            }
            else
            {
                exceptionMessage = actionExecutedContext.Exception.InnerException.Message;
            }

            logManager.LogException("Controller", actionExecutedContext.Exception);


            if (mdmException == null)
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent("Error occured during operation"),
                    ReasonPhrase = "Internal Server Error. Please contact system administrator",
                };

                actionExecutedContext.Response = response;
            }
            else if(mdmException.errorCode == ErrorConstants.UnauthorizedAccess)
            {
                var response = new HttpResponseMessage(HttpStatusCode.Unauthorized)
                {
                    Content = new StringContent("Not Authorized"),
                    ReasonPhrase = "Not Authorized. Please contact system administrator",
                };

                actionExecutedContext.Response = response;
            }
            else if (mdmException.errorCode == ErrorConstants.KnownException)
            {
                var response = new HttpResponseMessage(HttpStatusCode.Unauthorized)
                {
                    Content = new StringContent(mdmException.Message),
                    ReasonPhrase = mdmException.errorCode,
                };

                actionExecutedContext.Response = response;
            }
            else
            {
                var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
                {
                    Content = new StringContent("Error occured during operation"),
                    ReasonPhrase = "Internal Server Error. Please contact system administrator",
                };
                
                actionExecutedContext.Response = response;
            }
            

            

        }


        protected DataProviderFactory DataProviderFactory
        {
            get
            {
                if (null == DataProviderFactory.Current)
                {
                    throw new InvalidOperationException("DataProviderFactory has not been properly initialized");
                }

                return DataProviderFactory.Current;
            }
        }

        private ILogManager GetLogManager()
        {
            ConfigurationManager config = DataProviderFactory.GetProvider<ConfigurationManager>();
            return config.GetLogManager() as ILogManager;
        }
    }
}