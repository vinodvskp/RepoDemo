﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using VZ.CFO.MDMFramework.Configuration;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables;
using VZ.CFO.MDMFramework.Contracts.Service.MDUA;

namespace VZ.CFO.MDMFramework.Services.Controllers
{
    [RoutePrefix(Routes.MDUA.FactTableUserUpload.Root)]
    public class FactTableUserUploadController : MDMFrameworkBaseController
    {
        private Contracts.Service.MDUA.IFactTableUserUpload factTableUserUploadManager = null;
        private string userId = string.Empty;

        public FactTableUserUploadController()
        {
            this.factTableUserUploadManager = GetFactTableUserUploadManager();
            this.userId = base.GetCurrentUser();
        }

        private IFactTableUserUpload GetFactTableUserUploadManager()
        {
            ConfigurationManager config = base.DataProviderFactory.GetProvider<ConfigurationManager>();
            return config.GetFactTableUserUploadManager();
        }

        [Route(Routes.MDUA.FactTableUserUpload.UploadFactFile)]
        [HttpPost]
        public string UploadFactFile(UploadFactFile uploadFactFile)
        {
            return factTableUserUploadManager.UploadFactFile(userId, uploadFactFile.FileTypeName, uploadFactFile.Base64EncodedFile);
        }
        [Route(Routes.MDUA.FactTableUserUpload.UploadFactData)]
        [HttpPost]
        public FactProcessUploadedFileResponse UploadFactData(FactProcessUploadedFileRequest processRequest)
        {
            processRequest.UserId = userId;
            return factTableUserUploadManager.UploadFactData(processRequest);
        }

        [Route(Routes.MDUA.FactTableUserUpload.UploadFactFileBytes)]
        [HttpPost]
        public async Task<string> UploadFactFileBytes(string fileName)
        {
            if (!Request.Content.IsMimeMultipartContent())
            {
                throw new InvalidOperationException("Invalid file");
            }

            var provider = new MultipartMemoryStreamProvider();
            await Request.Content.ReadAsMultipartAsync(provider);

            if (provider.Contents.Count > 0)
            {
                var file = provider.Contents[0];
                var dataStream = await file.ReadAsStreamAsync();
                var dataInBytes = StreamToBytes(dataStream);
                return factTableUserUploadManager.UploadFactFileByte(userId, fileName, dataInBytes);
            }
            else
            {
                throw new ApplicationException("Invalid File");
            }
        }

        private static byte[] StreamToBytes(Stream input)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                input.CopyTo(ms);
                return ms.ToArray();
            }
        }

        [Route(Routes.MDUA.FactTableUserUpload.GetDimYears)]
        [HttpGet]
        public string[] GetDimYears()
        {
            return factTableUserUploadManager.GetDimYears();
        }

        [Route(Routes.MDUA.FactTableUserUpload.AddKeysFromStagedData)]
        [HttpPost]
        public FactProcessUploadedFileResponse AddKeysFromStagedData(long runStatusId, long factTableId, long factFileTypeId)
        {
            return factTableUserUploadManager.AddKeysFromStagedData(this.userId, runStatusId, factTableId, factFileTypeId);
        }

        [Route(Routes.MDUA.FactTableUserUpload.AddKeysAndUploadFact)]
        [HttpPost]
        public FactProcessUploadedFileResponse AddKeysAndUploadFact(FactProcessUploadedFileRequest processRequest)
        {
            processRequest.UserId = userId;
            return factTableUserUploadManager.AddKeysAndUploadFact(processRequest);
        }

        [Route(Routes.MDUA.FactTableUserUpload.GetMaxUploadFileSize)]
        [HttpGet]
        public double GetMaxUploadFileSize()
        {
            return factTableUserUploadManager.GetMaxUploadFileSize();
        }

    }
}
