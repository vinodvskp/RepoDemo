﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using VZ.CFO.MDMFramework.Configuration;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA.FileTransfer;
using VZ.CFO.MDMFramework.Contracts.Service.MDUA;

namespace VZ.CFO.MDMFramework.Services.Controllers
{
    [RoutePrefix(Routes.MDUA.FileTransfer.Root)]
    public class FileTransferController : MDUABaseController
    {
        private IFileTransferManager fileTransferManager;
        private string userId = string.Empty;
        private Contracts.Service.ISecurityManager securityManager; 

        public FileTransferController()
            : base()
        {
            this.fileTransferManager = GetFileTransferManager();
            this.userId = GetCurrentUser();
            this.securityManager = GetSecurityManager();
        }

        private Contracts.Service.MDUA.IFileTransferManager GetFileTransferManager()
        {
            ConfigurationManager config = base.DataProviderFactory.GetProvider<ConfigurationManager>();
            return config.GetFileTransferManager();
        }

        public FileTransferController(IFileTransferManager fileTransferManager)
        {
            this.fileTransferManager = fileTransferManager;
        }


        [HttpGet]
        [Route(Routes.MDUA.FileTransfer.GetFileTransferProfiles)]
        public Contracts.Data.MDUA.FileTransfer.FileTransferProfile[] GetFileTransferProfiles()
        {
            return fileTransferManager.GetFileTransferProfiles(userId);
        }

        [HttpGet]
        [Route(Routes.MDUA.FileTransfer.GetFileTransferProfile)]
        public Contracts.Data.MDUA.FileTransfer.FileTransferProfile GetFileTransferProfile(long profileId)
        {
            return fileTransferManager.GetFileTransferProfile(userId, profileId);
        }

        [HttpPost]
        [Route(Routes.MDUA.FileTransfer.TransferFile)]
        public async Task<Contracts.Data.MDUA.FileTransfer.FileTransferResponse> TransferFile(long profileId, string fileName, string path)
        {
            var fileTransferRequest = new FileTransferRequest() { ProfileId = profileId, UserId = userId, FileName = fileName, FilePath = path, RequestType = FileTransferKnownValues.FileTransferRequestType.Upload};

            if (!Request.Content.IsMimeMultipartContent())
            {
                throw new InvalidOperationException("Invalid file");
            }

            var provider = new MultipartMemoryStreamProvider();
            await Request.Content.ReadAsMultipartAsync(provider);

            if (provider.Contents.Count > 0)
            {
                var file = provider.Contents[0];
                var dataStream = await file.ReadAsStreamAsync();
                var dataInBytes = StreamToBytes(dataStream);
                fileTransferRequest.File = dataInBytes;
                return fileTransferManager.TransferFile(fileTransferRequest);
            }
            else
            {
                throw new ApplicationException("Invalid File");
            }   
        }

        [HttpGet]
        [Route(Routes.MDUA.FileTransfer.FolderList)]
        public FileTransferResponse FolderList(long profileId, string path)
        {
            return fileTransferManager.TransferFile(new FileTransferRequest() { ProfileId = profileId, FilePath = path, UserId = userId, RequestType = FileTransferKnownValues.FileTransferRequestType.FolderListing });
        }

        [Route(Routes.MDUA.FileTransfer.GetSignedUrlForDownload)]
        [HttpPost]
        public string GetSignedUrlForExportMappingTable([FromBody] dynamic obj)
        {
            return securityManager.GetSignedUrlKey(userId, obj.path.Value);
        }

        [HttpPost]
        [Route(Routes.MDUA.FileTransfer.DeleteFile)]
        public FileTransferResponse DeleteFile([FromBody] dynamic obj)
        {
            return fileTransferManager.TransferFile(new FileTransferRequest() { ProfileId = obj.profileId, FilePath = obj.path, UserId = userId, RequestType = FileTransferKnownValues.FileTransferRequestType.Delete });
        }

        [HttpPost]
        [Route(Routes.MDUA.FileTransfer.RenameFile)]
        public FileTransferResponse RenameFile([FromBody] dynamic obj)
        {
            return fileTransferManager.TransferFile(new FileTransferRequest() { ProfileId = obj.profileId, FilePath = obj.path, FileName = obj.fileName, UserId = userId, RequestType = FileTransferKnownValues.FileTransferRequestType.Rename });
        }


        [HttpGet]
        [AllowAnonymous]
        [Route(Routes.MDUA.FileTransfer.DownLoad)]
        public async Task<HttpResponseMessage> Download(long profileId, string path, string signedUrl)
        {
            CheckIfApiControllerIsDisposed();

            string verifiedUserId = securityManager.VerifySignedUrlKey(path, signedUrl);
            if (string.IsNullOrEmpty(verifiedUserId)) {
                var msg = new HttpResponseMessage(HttpStatusCode.Unauthorized) { ReasonPhrase = "signedUrl failed validation or expired" };
                throw new HttpResponseException(msg);
            }
            else
            {
                var response = fileTransferManager.TransferFile(new FileTransferRequest { ProfileId = profileId, UserId = verifiedUserId, FilePath = path, RequestType = FileTransferKnownValues.FileTransferRequestType.Download });
                var result = new HttpResponseMessage(HttpStatusCode.OK) { Content = new ByteArrayContent(await ReadAllBytes(response.DownLoadLocation)) };
                result.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment") { FileName = Path.GetFileName(response.DownLoadLocation) };
                result.Content.Headers.ContentType = result.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");
                return result;
            }
        }

        private async Task<byte[]> ReadAllBytes(string path)
        {
            using (var ms = new MemoryStream()) 
            using (var stream = File.Open(path, FileMode.Open))
            {
                int read = 0;
                var buffer = new byte[1024];
                while ((read = await stream.ReadAsync(buffer, 0, buffer.Length)) > 0)
                    ms.Write(buffer, 0, read);

                return ms.ToArray();
            }
        }

        private static byte[] StreamToBytes(Stream input)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                input.CopyTo(ms);
                return ms.ToArray();
            }
        }
    }
}
