﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNet.SignalR;
using VZ.CFO.MDMFramework.Contracts.Service.PushNotification;
using VZ.CFO.MDMFramework.Contracts.Data.PushNotification;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
using System.Data;
using System.Web.Http;
using System.Collections.Concurrent;
using System.Web.Http.Cors;
namespace VZ.CFO.MDMFramework.Services.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*", SupportsCredentials = true)]
    public class PushNotificationHub : MDMFrameworkBaseHub
    {
        private IPushNotificationService pushNotificationManager = null;
        private PushNotificationCallback pushCallback = null;
        private PushNotificationClientInfo clientInfo = null;


        public PushNotificationHub()
        {
            if (pushNotificationManager == null)
            {
                pushNotificationManager = base.GetPushNotificationManager();
                pushCallback = pushNotificationManager.GetPushNotificationCallbackRef();
                pushCallback.ItemChangedHandler += pushCallback_ItemChangedHandler;
            }
        }

        void pushCallback_ItemChangedHandler(object sender, PushNotificationEventArgs e)
        {
            //Push("something changed", true);
            if (e.PushNotifications != null && clientInfo != null)
            {
                List<PushNotification> changes = new List<PushNotification>();
                changes.AddRange(e.PushNotifications);

                foreach (PushNotification item in changes.FindAll(c => c.ApplicationName == clientInfo.ApplicationName && c.ApplicationModuleName == clientInfo.ApplicationModuleName))
                {
                    Push(item);
                }

            }

            // if (string.IsNullOrEmpty(connectedClient) == false)
            // {
            //     Push(connectedClient, "something changed");
            // }
        }

        public void Push(PushNotification item)
        {
            //if (isConnect)
            //{
            //    //Clients.Client(clientId).broadcastMessage(string.Format("Client - {0} connected", clientId));
            //    //Clients.All.broadcastMessage(string.Format("Client - {0} connected", clientId));
            //}
            //else
            //{
            //    Clients.All.broadcastMessage(string.Format("Client - {0} disconnected", clientId));
            //}

            var c = Clients.Client(clientInfo.ClientId);
            if (c != null)
            {
                c.broadcastMessage(item);
            }
        }

        public override System.Threading.Tasks.Task OnConnected()
        {
            string connectionId = Context.ConnectionId;
            string appName = Context.QueryString["app_name"];
            string appModule = Context.QueryString["app_module"];

            if (string.IsNullOrEmpty(appName) == false && string.IsNullOrEmpty(appModule) == false)
            {
                clientInfo = new PushNotificationClientInfo();
                clientInfo.ClientId = connectionId;
                clientInfo.ApplicationName = appName;
                clientInfo.ApplicationModuleName = appModule;
                //Push(connectionId, "connected");
                pushNotificationManager.ClientSubscription(connectionId, appName, appModule);
                return base.OnConnected();
            }
            else
            {
                throw new ArgumentException("Both app_name and app_module needed");
            }
        }

        public override System.Threading.Tasks.Task OnDisconnected(bool stopCalled)
        {
            string connectionId = Context.ConnectionId;
            pushNotificationManager.ClientUnSubscribe(connectionId);
            //Push(connectionId, "disconnected");
            return base.OnDisconnected(stopCalled);
        }

        //private string connectString = "Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=localhost)(PORT=1521)))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=xe)));User Id=ods;Password=Verizon1!;";
        //private bool isStarted = false;
        //private IPushNotificationService pushNotificationManager = null;
        //private Contracts.Data.PushNotification.PushNotificationCallback pushCallBack;
        //public PushNotificationHub()
        //{
        //    pushNotificationManager = base.GetPushNotificationManager();
        //    pushCallBack = pushNotificationManager.GetPushNotificationCallbackRef();
        //    pushCallBack.ItemChangedHandler += pushCallBack_ItemChangedHandler;
        //    //StartService();
        //}

        //void pushCallBack_ItemChangedHandler(object sender, Contracts.Data.PushNotification.PushNotificationEventArgs e)
        //{
        //    PushNotification[] notifications = e.PushNotifications as PushNotification[];
            
        //    if (notifications != null)
        //    {
        //        Push(notifications);
        //    }
        //}

        //public void StartService()
        //{
        //    //if(isStarted == false)
        //    //{
        //    //    string query = "select ID, APP_NAME, APP_MODULE_NAME, CHANGE_CONTEXT, LAST_UPDATED_ON, LAST_UPDATED_BY from NOTIFICATION_MASTER Where ID > 0";
        //    //    using (OracleConnection conn = new OracleConnection(connectString))
        //    //    using (OracleCommand cmd = new OracleCommand(query, conn))
        //    //    {
        //    //        conn.Open();
        //    //        cmd.AddRowid = true;
        //    //        OracleDependency oraDep = new OracleDependency(cmd);
        //    //        cmd.Notification.IsNotifiedOnce = false;
        //    //        oraDep.OnChange += new OnChangeEventHandler(OnDBNotificationHandler);

        //    //        OracleDataAdapter da = new OracleDataAdapter(cmd);
        //    //        DataSet ds = new DataSet();
        //    //        da.Fill(ds, "NOTIFICATION_MASTER");
        //    //    }

        //    //    isStarted = true;
        //    //}

            
        //}

        ////public void OnDBNotificationHandler(object src, OracleNotificationEventArgs args)
        ////{
        ////    DataRow changedDataRow = args.Details.Rows[0];
        ////    string rowId = changedDataRow["Rowid"].ToString();
        ////    string query = "SELECT ID, APP_NAME, APP_MODULE_NAME, CHANGE_CONTEXT, LAST_UPDATED_ON, LAST_UPDATED_BY from NOTIFICATION_MASTER WHERE rowid='{0}'";
        ////    string id = string.Empty;
        ////    string message = string.Empty;
        ////    using (OracleConnection connection = new OracleConnection(connectString))
        ////    using (OracleCommand command = new OracleCommand(query, connection))
        ////    {
        ////        connection.Open();
        ////        using (OracleDataReader dr = command.ExecuteReader())
        ////        {
        ////            if (dr.HasRows)
        ////            {
        ////                var idCol = dr.GetOrdinal("ID");
        ////                var appNameCol = dr.GetOrdinal("APP_NAME");

        ////                while (dr.Read())
        ////                {
        ////                    id = dr.GetString(idCol);
        ////                    message = dr.GetString(messageCol);
        ////                }
        ////            }
        ////        }
        ////    }
        ////    //Send(id, message);
        ////}

        //public void StopService()
        //{
        //    throw new NotImplementedException();
        //}

        //public string ClientSubscription(string appName, string appModule)
        //{
        //    throw new NotImplementedException();
        //}

        //public bool ClientUnSubscribe(string clientId)
        //{
        //    throw new NotImplementedException();
        //}

        //protected Contracts.Data.PushNotification.PushNotificationCallback GetPushNotificationCallbackRef()
        //{
        //    return pushNotificationManager.GetPushNotificationCallbackRef();
        //}

        //public void Push(Contracts.Data.PushNotification.PushNotification[] notifications)
        //{
        //    Clients.All.pushNotify(notifications);
        //}

    }
}