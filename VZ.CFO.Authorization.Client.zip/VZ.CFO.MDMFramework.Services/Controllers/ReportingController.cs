﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using VZ.CFO.MDMFramework.Configuration;

namespace VZ.CFO.MDMFramework.Services.Controllers
{
    [RoutePrefix(Routes.Reporting.Root)]
    public class ReportingController : MDUABaseController
    {
        private Contracts.Service.Reporting.IReportingManager reportingManager = null;
        private string userId = string.Empty;
        private Contracts.Service.ISecurityManager securityManager = null;

        public ReportingController()
        {
            this.reportingManager = GetReportingManager();
            this.userId = base.GetCurrentUser();
            this.securityManager = GetSecurityManager();
        }

        protected Contracts.Service.ISecurityManager GetSecurityManager()
        {
            ConfigurationManager config = DataProviderFactory.GetProvider<ConfigurationManager>();
            return config.GetSecurityManager();
        }

        private Contracts.Service.Reporting.IReportingManager GetReportingManager()
        {
            ConfigurationManager config = base.DataProviderFactory.GetProvider<ConfigurationManager>();
            return config.GetReportingManager();
        }

        [Route(Routes.Reporting.GetReports)]
        public Contracts.Data.Reporting.ReportGroup[] GetReports()
        {
            return reportingManager.GetReports(userId);
        }

        [Route(Routes.Reporting.GetReport)]
        public Contracts.Data.Reporting.Report GetReport(long reportId)
        {
            return reportingManager.GetReport(userId, reportId);
        }

        [Route(Routes.Reporting.GetReportData)]
        public async Task<Contracts.Data.Reporting.ReportingResponse> GetReportData(long reportId)
        {
            return await reportingManager.GetReportDataAsync(userId, reportId);
        }

        [Route(Routes.Reporting.GetReportDataPage)]
        public async Task<Contracts.Data.Reporting.ReportingResponse> GetReportDataPage(long reportId, int pageNumber, int rowsPerPage, int totalRecords)
        {
            return await reportingManager.GetReportDataAsync(userId, reportId, pageNumber, rowsPerPage, totalRecords);
        }

        [Route(Routes.Reporting.GetSignedUrlForExportReport)]
        [HttpGet]
        [AllowAnonymous]
        public string GetSignedUrlForExportReport(long reportId)
        {
            return securityManager.GetSignedUrlKey(userId, string.Format("Report-{0}", reportId));
        }

        [HttpGet]
        [AllowAnonymous]        
        public async Task<HttpResponseMessage> ExportReport(long reportId, string signedUrl)
        {
            //api/reporting/ExportReport?reportId={}&signedUrl={}
            CheckIfApiControllerIsDisposed();

            string verifiedUserId = securityManager.VerifySignedUrlKey(string.Format("Report-{0}", reportId), signedUrl);
            if (string.IsNullOrEmpty(verifiedUserId) == false)
            {
                //Response context
                System.Web.HttpResponse Response = System.Web.HttpContext.Current.Response;

                //Get Base64String from logic
                var base64String = await reportingManager.ExportReport(verifiedUserId, reportId);
                //Convert to binary
                byte[] binary = Convert.FromBase64String(base64String);

                //Send it as result
                var result = new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new ByteArrayContent(binary)
                };
                result.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment")
                {
                    FileName = string.Format("ReportDownload-{0}.csv", reportId)
                };
                result.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");
                return result;
            }
            else
            {
                var msg = new HttpResponseMessage(HttpStatusCode.Unauthorized) { ReasonPhrase = "signedUrl failed validation or expired" };
                throw new HttpResponseException(msg);
            }
        }
    }
}
