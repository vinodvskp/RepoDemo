﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace VZ.CFO.MDMFramework.Services.Controllers
{
    [RoutePrefix("api/VersionManagement")]
    public class VersionManagementController : ApiController
    {
        [Route("GetString")]
        public IHttpActionResult Get()
        {
            return Ok("Hello");
        }
    }
}
