﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using VZ.CFO.MDMFramework.Configuration;
using VZ.CFO.MDMFramework.Contracts.Service.MDUA;
using VZ.CFO.MDMFramework.Providers.Data;

namespace VZ.CFO.MDMFramework.Services.Controllers
{
    [RoutePrefix(Routes.MDUA.ODJobs.Root)]
    public class ODJobsController : MDMFrameworkBaseController
    {
        private IODJobManager odJobManager;
        private string userId = string.Empty;

        /// <summary>
        /// Gets an instance of AuthorizationManager.
        /// </summary>
        /// <returns>Instance of AuthorizationManager.</returns>
        private IODJobManager GetODJobManager()
        {
            ConfigurationManager config = base.DataProviderFactory.GetProvider<ConfigurationManager>();
            return config.GetODJobManager();
        }

        public ODJobsController()
        {
            this.odJobManager = GetODJobManager();
            this.userId = GetCurrentUser();
        }

        public ODJobsController(IODJobManager odJobManager)
        {
            this.odJobManager = odJobManager;
            this.userId = GetCurrentUser();
        }
        [HttpGet]
        [Route(Routes.MDUA.ODJobs.GetAllODJobGroups)]
        public Contracts.Data.MDUA.ODJobs.ODJobGroup[] GetAllODJobGroups()
        {
            return odJobManager.GetAllODJobGroups(this.userId);
        }
        [HttpGet]
        [Route(Routes.MDUA.ODJobs.GetAllODJobs)]
        public Contracts.Data.MDUA.ODJobs.ODJob[] GetAllODJobs(long groupId)
        {
            return odJobManager.GetAllODJobs(this.userId, groupId);
        }

        [HttpGet]
        [Route(Routes.MDUA.ODJobs.GetODJob)]
        public Contracts.Data.MDUA.ODJobs.ODJob GetODJob(long jobId)
        {
            return odJobManager.GetODJob(this.userId, jobId);
        }
        [HttpGet]
        [Route(Routes.MDUA.ODJobs.GetODJobParamValues)]
        public Contracts.Data.MDUA.ODJobs.ODJobParamValue[] GetODJobParamValues(long paramId)
        {
            return odJobManager.GetODJobParamValues(this.userId, paramId);
        }
        [HttpPost]
        [Route(Routes.MDUA.ODJobs.GetODJobAssocaiteParamValues)]
        public Contracts.Data.MDUA.ODJobs.ODJobParamValue[] GetODJobParamValues(VZ.CFO.MDMFramework.Contracts.Data.MDUA.ODJobs.ODJobParamValuesRequest paramValues)
        {
            return odJobManager.GetODJobParamValues(this.userId, paramValues.ParamId, paramValues.ODJobParamValues);
        }
        [HttpPost]
        [Route(Routes.MDUA.ODJobs.TriggerODJob)]
        public Contracts.Data.MDUA.ODJobs.EspMessage TriggerODJob(Contracts.Data.MDUA.ODJobs.ODJobTriggerRequest triggerRequest)
        {
            return odJobManager.TriggerODJob(this.userId, triggerRequest);
        }
        [HttpGet]
        [Route(Routes.MDUA.ODJobs.GetODJobStatus)]
        public async Task<Contracts.Data.MDUA.ODJobs.EspJobStatus> GetODJobStatus(long jobId)
        {
            return await odJobManager.GetODJobStatus(userId, jobId);
        }
        [HttpGet]
        [Route(Routes.MDUA.ODJobs.GetODJobStatusByGeneration)]
        public Contracts.Data.MDUA.ODJobs.EspJobStatus GetODJobStatus(long jobId, long? generation)
        {
            return odJobManager.GetODJobStatus(userId, jobId, generation);
        }
    }
}
