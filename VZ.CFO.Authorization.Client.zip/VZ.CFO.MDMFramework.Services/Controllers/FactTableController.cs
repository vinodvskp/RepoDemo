﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using VZ.CFO.MDMFramework.Configuration;
using VZ.CFO.MDMFramework.Contracts.Service;
using VZ.CFO.MDMFramework.Contracts.Service.MDUA;
using VZ.CFO.MDMFramework.Providers.Data;
using VZ.CFO.MDMFramework.Contracts.Data;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables;
using VZ.CFO.MDMFramework.Server.Util;
using Microsoft.Practices.Unity;

namespace VZ.CFO.MDMFramework.Services.Controllers
{
    [RoutePrefix(Routes.MDUA.FactTable.Root)]
    public class FactTableController : MDUABaseController
    {
        private IFactTableManager factTableManager;
        private IExportTableManager exportTableManager;
        private string userId = string.Empty;

        public FactTableController()
            : base()
        {
            this.factTableManager = GetFactTableManager();
            this.exportTableManager = GetExportTableManager();
            this.userId = GetCurrentUser();
        }

        public FactTableController(IFactTableManager factTableManager, IExportTableManager exportTableManager)
        {
            this.factTableManager = factTableManager;
            this.exportTableManager = exportTableManager;
            this.userId = GetCurrentUser();
        }

        [HttpGet]
        [Route(Routes.MDUA.FactTable.GetAllFactTables)]
        public FactTable[] GetAllFactTables()
        {
            CheckIfApiControllerIsDisposed();
            return factTableManager.GetAllFactTables(this.userId);
        }
        [HttpGet]
        [Route(Routes.MDUA.FactTable.GetFactTable)]
        public FactTable GetFactTable(long factTableId)
        {
            CheckIfApiControllerIsDisposed();
            return factTableManager.GetFactTable(this.userId, factTableId);
        }
        [HttpGet]
        [Route(Routes.MDUA.FactTable.GetFactFileTypes)]
        public FactFileType[] GetFactFileTypes(long factTableId)
        {
            CheckIfApiControllerIsDisposed();
            return factTableManager.GetFactFileTypes(this.userId, factTableId);
        }
        [HttpGet]
        [Route(Routes.MDUA.FactTable.GetFactFileTypesBasic)]
        public FactTable[] GetFactFileTypesBasic()
        {
            CheckIfApiControllerIsDisposed();
            return factTableManager.GetFactFileTypesBasic(this.userId);
        }
        [HttpPost]
        [Route(Routes.MDUA.FactTable.GetFactFileType)]
        public FactFileType GetFactFileType(FileTypeRequest fileTypeRequest)
        {
            CheckIfApiControllerIsDisposed();
            return factTableManager.GetFactFileType(this.userId, fileTypeRequest);
        }
        [HttpPost]
        [Route(Routes.MDUA.FactTable.DeleteFactFileType)]
        public FileTypeResponse DeleteFactFileType(FileTypeRequest fileTypeRequest)
        {
            CheckIfApiControllerIsDisposed();
            return factTableManager.DeleteFileType(this.userId, fileTypeRequest);
        }

        [HttpPost]
        [Route(Routes.MDUA.FactTable.SaveFactFileType)]
        public FileTypeResponse SaveFactFileType(FactFileType factFileType)
        {
            CheckIfApiControllerIsDisposed();
            //to do: validate factFileType
            return factTableManager.SaveFileType(this.userId, factFileType);
        }

        [HttpPost]
        [Route(Routes.MDUA.FactTable.GetKeyCombinations)]
        public KeyComboResponse GetKeyCombinations(KeyComboRequest keyComboRequest)
        {
            CheckIfApiControllerIsDisposed();
            return factTableManager.GetKeyCombinations(this.userId, keyComboRequest);
        }
        [HttpPost]
        [Route(Routes.MDUA.FactTable.DeleteKeyCombinations)]
        public KeyComboDeleteResponse DeleteKeyCombinations(KeyComboDeleteRequest keyComboDeleteRequest)
        {
            CheckIfApiControllerIsDisposed();
            return factTableManager.DeleteKeyCombinations(this.userId, keyComboDeleteRequest);
        }
        [HttpPost]
        [Route(Routes.MDUA.FactTable.MoveKeyCombinations)]
        public KeyComboMoveResponse MoveKeyCombinations(KeyComboMoveRequest keyComboMoveRequest)
        {
            return factTableManager.MoveKeyCombinations(this.userId, keyComboMoveRequest);
        }

        [HttpGet]
        [Route(Routes.MDUA.FactTable.DownloadFactTable)]
        [AllowAnonymous]
        public async Task<HttpResponseMessage> DownloadFactTable([FromUri]FactTableDownloadRequest downloadRequest)
        {
            CheckIfApiControllerIsDisposed();
            TableInfo tableInfo = GetTableInfoForDownload(GetCurrentUser(), downloadRequest);
            tableInfo.PagingQueryTemplate = factTableManager.GetPagingQueryTemplate();
            string signedDownloadParams = downloadRequest.FactTableId + "," + downloadRequest.FileTypeCodeId + "," + downloadRequest.StartPeriod + "," + downloadRequest.EndPeriod;
            string verifiedUserId = exportTableManager.VerifySignedUrlKey(string.Format("{0}-{1}", tableInfo.TableName, signedDownloadParams), downloadRequest.SignedUrl);
            if (string.IsNullOrEmpty(verifiedUserId) == false)
            {
                var based64StringContent = await exportTableManager.ExportTable(GetCurrentUser(), tableInfo);
                return await base.OnExportTable(based64StringContent, tableInfo.TableName);
            }
            else
            {
                HttpResponseMessage resp = new HttpResponseMessage();
                resp.StatusCode = HttpStatusCode.Unauthorized;
                resp.Content = new ByteArrayContent(Encoding.ASCII.GetBytes("Failed to verify your information to access the data."));

                return await Task.Run(() => resp);
            }
        }

        [HttpGet]
        [Route(Routes.MDUA.FactTable.DownloadKeyCombinations)]
        [AllowAnonymous]
        public async Task<HttpResponseMessage> DownloadKeyCombinations([FromUri] FactTableDownloadRequest downloadRequest)
        {
            CheckIfApiControllerIsDisposed();
            TableInfo tableInfo = GetTableInfoForKeyComboDownload(GetCurrentUser(), downloadRequest);
            tableInfo.PagingQueryTemplate = factTableManager.GetPagingQueryTemplate();
            string signedDownloadParams = downloadRequest.FactTableId + "," + downloadRequest.FileTypeCodeId;
            string verifiedUserId = exportTableManager.VerifySignedUrlKey(string.Format("{0}-{1}", tableInfo.TableName, signedDownloadParams), downloadRequest.SignedUrl);
            if (string.IsNullOrEmpty(verifiedUserId) == false)
            {
                var based64StringContent = await exportTableManager.ExportTable(GetCurrentUser(), tableInfo);
                return await base.OnExportTable(based64StringContent, tableInfo.TableName);
            }
            else
            {
                HttpResponseMessage resp = new HttpResponseMessage();
                resp.StatusCode = HttpStatusCode.Unauthorized;
                resp.Content = new ByteArrayContent(Encoding.ASCII.GetBytes("Failed to verify your information to access the data."));

                return await Task.Run(() => resp);
            }
        }

        [Route(Routes.MDUA.FactTable.GetSignedUrlForFactTable)]
        [HttpPost]
        public string GetSignedUrlForFactTable(FactTableDownloadRequest downloadRequest)
        {
            //to do : validate input data on downloadRequest object
            string downloadParams = downloadRequest.FactTableId + "," + downloadRequest.FileTypeCodeId + "," + downloadRequest.StartPeriod + "," + downloadRequest.EndPeriod;
            FactTable factTable = factTableManager.GetFactTableBasicInfo(GetCurrentUser(), downloadRequest.FactTableId);
            return exportTableManager.GetSignedUrlKey(userId, string.Format("{0}-{1}", factTable.PhysicalTable, downloadParams));
        }

        [Route(Routes.MDUA.FactTable.GetSignedUrlForKeyCombinations)]
        [HttpPost]
        public string GetSignedUrlForKeyCombinations(FactTableDownloadRequest downloadRequest)
        {
            //to do : validate input data on downloadRequest object
            string downloadParams = downloadRequest.FactTableId + "," + downloadRequest.FileTypeCodeId;
            FactTable factTable = factTableManager.GetFactTableBasicInfo(GetCurrentUser(), downloadRequest.FactTableId);
            return exportTableManager.GetSignedUrlKey(userId, string.Format("{0}-{1}", factTable.FileTypeKeyComboTableName, downloadParams));
        }

        [Route(Routes.MDUA.FactTable.GetFactTableSetting)]
        public FactTableSettings GetFactTableSetting()
        {
            return factTableManager.GetFactTableSetting(this.userId);
        }

        [Route(Routes.MDUA.FactTable.GetAuditData)]
        [HttpPost]
        public FactProcessUploadedFileResponse GetAuditData(FactAuditRequest auditRequest)
        {
            return factTableManager.GetAuditData(this.userId, auditRequest);
        }

        [Route(Routes.MDUA.FactTable.ExportAuditData)]
        [HttpPost]
        public string ExportAuditData(FactAuditRequest auditRequest)
        {
            return factTableManager.ExportAuditData(this.userId, auditRequest);
        }

        [Route(Routes.MDUA.FactTable.GetDimensionValues)]
        [HttpPost]
        public string[] GetDimensionValues(FactAuditRequest auditRequest)
        {
            return factTableManager.GetDimensionValues(userId, auditRequest);
        }

        [Route(Routes.MDUA.FactTable.GetCurrentPeriod)]
        [HttpGet]
        public FactReportingPeriod GetCurrentPeriod(long factTableId)
        {
            return factTableManager.GetCurrentPeriod(userId, factTableId);
        }


        private Contracts.Service.MDUA.IFactTableManager GetFactTableManager()
        {
            ConfigurationManager config = base.DataProviderFactory.GetProvider<ConfigurationManager>();
            return config.GetFactTableManager();
        }

        private Contracts.Service.IExportTableManager GetExportTableManager()
        {
            ConfigurationManager config = base.DataProviderFactory.GetProvider<ConfigurationManager>();
            return config.GetExportTableManager();
        }

        private TableInfo GetTableInfoForDownload(string userId, FactTableDownloadRequest downloadRequest)
        {
            //FactTable factTable = factTableManager.GetFactTableBasicInfo(userId, downloadRequest.FactTableId);
            FactTable factTable = factTableManager.GetFactTable(userId, downloadRequest.FactTableId);
            TableInfo tableInfo = new TableInfo();
            string connectionString = factTableManager.GetDbConnectionString(factTable.RepoProfile);
            tableInfo.ConnectionString = connectionString;
            if (factTable == null)
            {
                return null;
            }
            string fileTypeCode = factTableManager.GetFileTypeCodeById(downloadRequest.FactTableId, downloadRequest.FileTypeCodeId);
            tableInfo.TableId = factTable.Id;
            tableInfo.TableName = factTable.PhysicalTable;
            tableInfo.RowsPerPage = 1500;
            //todo: here is hard-coded for testing, need to change later. We need alias for inconsistent column names across the tables.
            //string totalRowsWhereCause = string.Format(@"corporate_amt is not null and period >= {0} and period <= {1} and source='{2}'", downloadRequest.StartPeriod, downloadRequest.EndPeriod, "SR.USER");
            //string [] keyColumns = new string[] { "substr(period, 0, 4) as year", "substr(period, 5, 2) as time", "corporate_amt", "owner", "date_modified" };
            //string totalRowsWhereCause = string.Format(@"corporate_amt is not null and period >= {0} and period <= {1} and source='{2}'", downloadRequest.StartPeriod, downloadRequest.EndPeriod, fileTypeCode, userId);
            string totalRowsWhereCausePeriod = string.IsNullOrEmpty(downloadRequest.RunStatusId) ? (string.IsNullOrEmpty(downloadRequest.StartPeriod) || string.IsNullOrEmpty(downloadRequest.EndPeriod) ? string.Empty : string.Format(@"and period >= {0} and period <= {1}", downloadRequest.StartPeriod, downloadRequest.EndPeriod)) :
                                                                                                   string.Format(@"and run_status_id = {0}", downloadRequest.RunStatusId);
            string totalRowsWhereCause = string.Format(@"amount is not null {0} and detailed_source='{1}'", totalRowsWhereCausePeriod, fileTypeCode);
            //string[] keyColumns = new string[] { "substr(period, 0, 4) as year", "substr(period, 5, 2) as time", "amount", "owner", "date_modified" };

            List<string> columns = new List<string>();
            columns.Add("PERIOD");
            columns.AddRange(factTable.AvailableDimensions.Select(d => d.FactColumnName));
            columns.Add("AMOUNT");
            columns.Add("DETAILED_SOURCE");
            columns.Add("OWNER");
            columns.Add("RUN_STATUS_ID");
            columns.Add("DATE_CREATED");
            columns.Add("DATE_MODIFIED");
            columns.Add("AUDIT_ID");
            

            tableInfo.TotalRows = DBUtil.GetTotalRowsFromTable(factTable.PhysicalTable, totalRowsWhereCause, connectionString);
            //tableInfo.ColumnHeaders = new string[] { "Year", "Time", "Amount", "Owner", "Date Modified" };
            tableInfo.ColumnHeaders = columns.ToArray();
            tableInfo.WhereCause = totalRowsWhereCause;
            //tableInfo.Columns = keyColumns;
            tableInfo.Columns = columns.ToArray();
            return tableInfo;
        }

        private TableInfo GetTableInfoForKeyComboDownload(string userId, FactTableDownloadRequest downloadRequest)
        {
            FactTable factTable = factTableManager.GetFactTable(userId, downloadRequest.FactTableId);
            TableInfo tableInfo = new TableInfo();
            string connectionString = factTableManager.GetDbConnectionString(factTable.RepoProfile);
            tableInfo.ConnectionString = connectionString;
            if (factTable == null)
            {
                return null;
            }
            string fileTypeCode = factTableManager.GetFileTypeCodeById(downloadRequest.FactTableId, downloadRequest.FileTypeCodeId);
            tableInfo.TableId = factTable.Id;
            tableInfo.TableName = factTable.FileTypeKeyComboTableName;
            tableInfo.RowsPerPage = 1500;
            string totalRowsWhereCause = string.Format(@"source='{0}'", fileTypeCode);
            tableInfo.TotalRows = DBUtil.GetTotalRowsFromTable(factTable.FileTypeKeyComboTableName, totalRowsWhereCause, connectionString);
            tableInfo.WhereCause = totalRowsWhereCause;
            List<string> columns = factTable.AvailableDimensions.Select(d => (d.StageTableColumnName)).ToList();
            columns.Add("SOURCE");
            columns.Add("OWNER");
            columns.Add("RUN_STATUS_ID");
            columns.Add("DATE_CREATED");
            columns.Add("DATE_MODIFIED");
            tableInfo.Columns = columns.ToArray();
            tableInfo.ColumnHeaders = tableInfo.Columns;
            return tableInfo;
        }
    }
}