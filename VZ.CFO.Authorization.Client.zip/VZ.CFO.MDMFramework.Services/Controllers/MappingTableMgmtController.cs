﻿using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Cors;
using VZ.CFO.Authorization.Client.Authorization;
using VZ.CFO.MDMFramework.Configuration;
using VZ.CFO.MDMFramework.Contracts.Data.MappingTableMgmt;
using VZ.CFO.MDMFramework.Contracts.Service.MappingTableMgmt;
namespace VZ.CFO.MDMFramework.Services.Controllers
{
    [RoutePrefix(Routes.MappingTableMgmt.Root)]    
    public class MappingTableMgmtController : MDMFrameworkBaseController
    {

        private IMappingTableManager mappingTableManager = null;
        private string userId = string.Empty;
        private Contracts.Service.ISecurityManager securityManager = null;

        [InjectionConstructor]
        public MappingTableMgmtController()
        {
            this.mappingTableManager = GetMappingTableManager();
            this.userId = GetCurrentUser();
            this.securityManager = GetSecurityManager();
        }
        
        public MappingTableMgmtController(IMappingTableManager mappingTableManager)
        {
            this.mappingTableManager = mappingTableManager;
            this.userId = GetCurrentUser();
            this.securityManager = GetSecurityManager();
        }

        /// <summary>
        /// Gets an instance of AuthorizationManager.
        /// </summary>
        /// <returns>Instance of AuthorizationManager.</returns>
        private IMappingTableManager GetMappingTableManager()
        {
            ConfigurationManager config = base.DataProviderFactory.GetProvider<ConfigurationManager>();
            return config.GetMappingTableManager();
        }

        

        [HttpGet]
        [Route(Routes.MappingTableMgmt.GetAllMappingTables)]
        //[ClaimsAuthorization(Contracts.Data.KnownValues.Security.ClaimTypes.MappingTableGenericClaim, Contracts.Data.KnownValues.Security.ClaimValues.ReadClaimValue)]
        public Contracts.Data.MappingTableMgmt.MappingTable[] GetAllMappingTables()
        {
            CheckIfApiControllerIsDisposed();
            return mappingTableManager.GetAllMappingTables(userId);
        }

        [HttpGet]
        [Route(Routes.MappingTableMgmt.GetMappingTableInfo)]
        //[ClaimsAuthorization(Contracts.Data.KnownValues.Security.ClaimTypes.MappingTableGenericClaim, Contracts.Data.KnownValues.Security.ClaimValues.ReadClaimValue)]
        public Contracts.Data.MappingTableMgmt.MappingTable GetMappingTableInfo(long mappingTableId)
        {
            CheckIfApiControllerIsDisposed();
            return mappingTableManager.GetMappingTableInfo(userId, mappingTableId);
        }

        [HttpGet]
        [Route(Routes.MappingTableMgmt.GetMappingTablePageData)]
        //[ClaimsAuthorization(Contracts.Data.KnownValues.Security.ClaimTypes.MappingTableGenericClaim, Contracts.Data.KnownValues.Security.ClaimValues.ReadClaimValue)]
        public Contracts.Data.MappingTableMgmt.MappingTableDataPage GetMappingTable(long mappingTableId, int pageNumber, int rowsPerPage, int totalRecords)
        {
            CheckIfApiControllerIsDisposed();
            return mappingTableManager.GetMappingTable(userId, mappingTableId, pageNumber, rowsPerPage, totalRecords);
        }

        [HttpGet]
        [Route(Routes.MappingTableMgmt.GetMappingTableFirstPageData)]
        //[ClaimsAuthorization(Contracts.Data.KnownValues.Security.ClaimTypes.MappingTableGenericClaim, Contracts.Data.KnownValues.Security.ClaimValues.ReadClaimValue)]
        public Contracts.Data.MappingTableMgmt.MappingTable GetMappingTable(long id, int rowsPerPage)
        {
            CheckIfApiControllerIsDisposed();
            return mappingTableManager.GetMappingTable(userId, id, rowsPerPage);
        }

        [HttpGet]
        [Route(Routes.MappingTableMgmt.GetMappingTablePageDataFromLowerEnv)]
        //[ClaimsAuthorization(Contracts.Data.KnownValues.Security.ClaimTypes.MappingTableGenericClaim, Contracts.Data.KnownValues.Security.ClaimValues.ReadClaimValue)]
        public Contracts.Data.MappingTableMgmt.MappingTableDataPage GetMappingTablePageDataFromLowerEnv(long mappingTableId, int pageNumber, int rowsPerPage, int totalRecords)
        {
            CheckIfApiControllerIsDisposed();
            return mappingTableManager.GetMappingTableFromLowerEnv(userId, mappingTableId, pageNumber, rowsPerPage, totalRecords);
        }

        [HttpGet]
        [Route(Routes.MappingTableMgmt.GetMappingTableFirstPageDataFromLowerEnv)]
        //[ClaimsAuthorization(Contracts.Data.KnownValues.Security.ClaimTypes.MappingTableGenericClaim, Contracts.Data.KnownValues.Security.ClaimValues.ReadClaimValue)]
        public Contracts.Data.MappingTableMgmt.MappingTable GetMappingTableFirstPageDataFromLowerEnv(long id, int rowsPerPage)
        {
            CheckIfApiControllerIsDisposed();
            return mappingTableManager.GetMappingTableFromLowerEnv(userId, id, rowsPerPage);
        }

        [HttpPost]
        [Route(Routes.MappingTableMgmt.SaveMappingTableData)]
        //[ClaimsAuthorization(Contracts.Data.KnownValues.Security.ClaimTypes.MappingTableGenericClaim, Contracts.Data.KnownValues.Security.ClaimValues.EditClaimValue)]
        public Contracts.Data.MappingTableMgmt.MappingTableWriteResponse SaveMappingTableData(Contracts.Data.MappingTableMgmt.MappingTableWriteRequest writeRequest)
        {
            CheckIfApiControllerIsDisposed();

            return mappingTableManager.SaveMappingTableData(userId, writeRequest);

            //if(writeRequest == null)
            //{
            //    throw new ArgumentNullException("writeRequest");
            //}

            //if (writeRequest.AddRecords == null && writeRequest.DeletedRecords == null && writeRequest.ModifiedRecords == null)
            //{
            //    throw new ArgumentNullException("All three properties AddRecords, DeletedRecords and ModifiedRecords can't be empty");
            //}

            ////Mocking the return type testing purpose
            //MappingTableWriteResponse response = new MappingTableWriteResponse();
            //response.MappingTableId = writeRequest.MappingTableId;

            //if (writeRequest.IsForceSave == false && writeRequest.AddRecords != null && writeRequest.AddRecords.Length > 0)
            //{
            //    MappingColumnValues col1 = new MappingColumnValues();
            //    MappingColumnValues col2 = new MappingColumnValues();
            //    List<string> col1Data = new List<string>();
            //    List<string> col2Data = new List<string>();

            //    foreach (string uid in writeRequest.AddRecords[0].Data)
            //    {
            //        col1Data.Add(uid);
            //        col2Data.Add("Essbase member not found.");
            //    }

            //    col1.Data = col1Data.ToArray();
            //    col2.Data = col2Data.ToArray();
            //    response.ValidationResults = new MappingColumnValues[] { col1, col2 };
            //}
            //return response;
        }

        //[ClaimsAuthorization(Contracts.Data.KnownValues.Security.ClaimTypes.MappingTableGenericClaim, Contracts.Data.KnownValues.Security.ClaimValues.EditClaimValue)]
        [HttpPost]
        [Route(Routes.MappingTableMgmt.ValidateMappingTableData)]
        public Contracts.Data.MappingTableMgmt.MappingTableWriteResponse ValidationMappingTableData(Contracts.Data.MappingTableMgmt.MappingTableWriteRequest writeRequest)
        {
            CheckIfApiControllerIsDisposed();
            return mappingTableManager.ValidationMappingTableData(userId, writeRequest);
        }

        [HttpGet]
        [Route(Routes.MappingTableMgmt.GetAuditLogPageData)]
        //[ClaimsAuthorization(Contracts.Data.KnownValues.Security.ClaimTypes.MappingTableGenericClaim, Contracts.Data.KnownValues.Security.ClaimValues.ReadClaimValue)]
        public Contracts.Data.MappingTableMgmt.AuditLogPage GetAuditDataPage(long mappingTableId, KnownValues.AuditType auditType, int pageNumber, int rowsPerPage, int totalRecords)
        {
            CheckIfApiControllerIsDisposed();
            return mappingTableManager.GetAuditDataPage(userId, mappingTableId, auditType, pageNumber, rowsPerPage, totalRecords, string.Empty);
        }

        [HttpGet]
        [Route(Routes.MappingTableMgmt.GetAuditLogFirstPageData)]
        //[ClaimsAuthorization(Contracts.Data.KnownValues.Security.ClaimTypes.MappingTableGenericClaim, Contracts.Data.KnownValues.Security.ClaimValues.ReadClaimValue)]
        public Contracts.Data.MappingTableMgmt.AuditLogPage GetAuditData(long mappingTableId, KnownValues.AuditType auditType, int rowsPerPage)
        {
            CheckIfApiControllerIsDisposed();
            return mappingTableManager.GetAuditData(userId, mappingTableId, auditType, rowsPerPage, string.Empty);
        }

        [HttpGet]
        [Route(Routes.MappingTableMgmt.GetAuditLogSearchPageData)]
        //[ClaimsAuthorization(Contracts.Data.KnownValues.Security.ClaimTypes.MappingTableGenericClaim, Contracts.Data.KnownValues.Security.ClaimValues.ReadClaimValue)]
        public Contracts.Data.MappingTableMgmt.AuditLogPage GetAuditLogSearchPageData(long mappingTableId, KnownValues.AuditType auditType, int pageNumber, int rowsPerPage, int totalRecords, string searchKey)
        {
            CheckIfApiControllerIsDisposed();
            return mappingTableManager.GetAuditDataPage(userId, mappingTableId, auditType, pageNumber, rowsPerPage, totalRecords, searchKey);
        }

        [HttpGet]
        [Route(Routes.MappingTableMgmt.GetAuditLogSearchFirstPageData)]
        //[ClaimsAuthorization(Contracts.Data.KnownValues.Security.ClaimTypes.MappingTableGenericClaim, Contracts.Data.KnownValues.Security.ClaimValues.ReadClaimValue)]
        public Contracts.Data.MappingTableMgmt.AuditLogPage GetAuditLogSearchFirstPageData(long mappingTableId, KnownValues.AuditType auditType, int rowsPerPage, string searchKey)
        {
            CheckIfApiControllerIsDisposed();
            return mappingTableManager.GetAuditData(userId, mappingTableId, auditType, rowsPerPage, searchKey);
        }

        //[ClaimsAuthorization(Contracts.Data.KnownValues.Security.ClaimTypes.MappingTableGenericClaim, Contracts.Data.KnownValues.Security.ClaimValues.MT.MigrateClaimValue)]
        [HttpPost]
        [Route(Routes.MappingTableMgmt.MigrateMappingValues)]
        public MappingTableWriteResponse MigrateMappingValues(MappingTableWriteRequest writeRequest)
        {
            CheckIfApiControllerIsDisposed();
            return mappingTableManager.MigrateMappingValues(userId, writeRequest);
        }

        //[Route(Routes.MappingTableMgmt.ExportMappingTable)]
        [HttpGet]
        [AllowAnonymous]
        //[ClaimsAuthorization(Contracts.Data.KnownValues.Security.ClaimTypes.MappingTableGenericClaim, Contracts.Data.KnownValues.Security.ClaimValues.ReadClaimValue)]
        public async Task<HttpResponseMessage> ExportMappingTable(long mappingTableId, string signedUrl)
        {
            CheckIfApiControllerIsDisposed();

            string verifiedUserId = securityManager.VerifySignedUrlKey(string.Format("MappingTable-{0}", mappingTableId), signedUrl);
            if (string.IsNullOrEmpty(verifiedUserId) == false)
            {
                //Response context
                System.Web.HttpResponse Response = System.Web.HttpContext.Current.Response;

                //Get Base64String from logic
                var base64String = await mappingTableManager.ExportMappingTable(verifiedUserId, mappingTableId);
                //Convert to binary
                byte[] binary = Convert.FromBase64String(base64String);

                //Send it as result
                var result = new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new ByteArrayContent(binary)
                };
                result.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment")
                {
                    FileName = string.Format("MappingTableDownload-{0}.csv", mappingTableId)
                };
                result.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");
                return result;
            }
            else
            {
                var msg = new HttpResponseMessage(HttpStatusCode.Unauthorized) { ReasonPhrase = "signedUrl failed validation or expired" };
                throw new HttpResponseException(msg);
            }
        }

        [Route(Routes.MappingTableMgmt.GetSignedUrlForExportMappingTable)]
        [HttpGet]
        public string GetSignedUrlForExportMappingTable(long mappingTableId)
        {
            return securityManager.GetSignedUrlKey(userId, string.Format("MappingTable-{0}", mappingTableId));
        }
    }
}
