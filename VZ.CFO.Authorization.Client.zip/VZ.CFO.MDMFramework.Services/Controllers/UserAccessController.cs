﻿using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.Cors;
using VZ.CFO.MDMFramework.Configuration;
using VZ.CFO.MDMFramework.Contracts.Data;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA;
using VZ.CFO.MDMFramework.Contracts.Data.Security;
using VZ.CFO.MDMFramework.Contracts.Service.MDUA;

namespace VZ.CFO.MDMFramework.Services.Controllers
{
    [RoutePrefix(Routes.MDUA.UserAccess.Root)]
    public class UserAccessController : MDMFrameworkBaseController
    {
        private IUserAccessManager userAccessManager = null;
        private string userId = string.Empty;
        private Contracts.Service.ISecurityManager securityManager = null;

        [InjectionConstructor]
        public UserAccessController()
        {
            this.userAccessManager = GetUserAccessManager();
            this.userId = GetCurrentUser();
            this.securityManager = GetSecurityManager();
        }

        public UserAccessController(IUserAccessManager userAccessManager)
        {
            this.userAccessManager = userAccessManager;
            this.userId = GetCurrentUser();
        }

        private IUserAccessManager GetUserAccessManager()
        {
            ConfigurationManager config = base.DataProviderFactory.GetProvider<ConfigurationManager>();
            return config.GetUserAccessManager();
        }

        [HttpGet]
        [Route(Routes.MDUA.UserAccess.GetUserAccessByEmployeeId)]
        public Contracts.Data.MDUA.UserAccess[] GetUserAccessByEmployeeId(string employeeId)
        {
            return userAccessManager.GetUserAccessByEmployeeId(employeeId);
        }
        
        [HttpGet]
        [Route(Routes.MDUA.UserAccess.GetUserAccessByUserId)]
        public Contracts.Data.MDUA.UserAccess[] GetUserAccessByUserId(string userId)
        {
            return userAccessManager.GetUserAccessByUserId(userId);
        }
        
        [HttpPost]
        [Route(Routes.MDUA.UserAccess.SaveUserAccessByEmployeeId)]
        public bool SaveUserAccessByEmployeeId(string employeeId, string accessObjectType, Contracts.Data.MDUA.UserAccess[] userAccess)
        {
            return userAccessManager.SaveUserAccessByEmployeeId(userId, employeeId, accessObjectType, userAccess);
        }
        
        [HttpGet]
        [Route(Routes.MDUA.UserAccess.GetUserAccess)]
        [AllowAnonymous]
        public Claim[] GetUserAccess(string id, string authenticationType)
        {
            return userAccessManager.GetUserAccess(id, authenticationType);
        }
        [HttpGet]
        [Route(Routes.MDUA.UserAccess.GetUserAccessForAccessObjType)]
        public Contracts.Data.MDUA.UserAccess[] GetUserAccessForAccessObjType(string employeeId, string accessObjectType)
        {
            return userAccessManager.GetUserAccessForAccessObjType(employeeId, accessObjectType);
        }
        
        [HttpGet]
        [Route(Routes.MDUA.UserAccess.GetMenuForUser)]
        public Contracts.Data.MDUA.Menu[] GetMenuForUser()
        {
            CheckIfApiControllerIsDisposed();
            return userAccessManager.GetMenuForUser(base.GetLoggedInUserClaims());
        }

        [HttpGet]
        [Route(Routes.MDUA.UserAccess.GetHomeMenuItem)]
        public Contracts.Data.Config.HomeMenuItem[] GetHomeMenuItem()
        {
            CheckIfApiControllerIsDisposed();
            ConfigurationManager config = base.DataProviderFactory.GetProvider<ConfigurationManager>();
            return config.GetHomeMenuItems();
        }

        [HttpGet]
        [Route(Routes.MDUA.UserAccess.GetAllUsers)]
        public Contracts.Data.MDUA.UserInfo[] GetAllUsers()
        {
            CheckIfApiControllerIsDisposed();
            return userAccessManager.GetAllUsers();
        }
        
        [HttpGet]
        [Route(Routes.MDUA.UserAccess.GetUser)]
        public Contracts.Data.MDUA.UserInfo GetUser(string employeeId)
        {
            CheckIfApiControllerIsDisposed();
            return userAccessManager.GetUser(employeeId);
        }

        [HttpGet]
        [Route(Routes.MDUA.UserAccess.GetRolesFromAuthToken)]
        public System.Security.Claims.Claim[] GetRolesFromAuthToken()
        {
            List<System.Security.Claims.Claim> returnValue = new List<System.Security.Claims.Claim>();
            CheckIfApiControllerIsDisposed();
            if (HttpContext.Current.User != null)
            {
                System.Security.Claims.ClaimsPrincipal principal = HttpContext.Current.User as System.Security.Claims.ClaimsPrincipal;
                System.Security.Claims.ClaimsPrincipal cp = principal as System.Security.Claims.ClaimsPrincipal;
                if (cp != null)
                {
                    returnValue.AddRange(cp.Claims);
                }
            }

            return returnValue.ToArray();

        }

        [HttpGet]
        [Route(Routes.MDUA.UserAccess.GetUserFromLdap)]
        public Contracts.Data.MDUA.UserInfo GetUserFromLdap(string vzid)
        {
            return userAccessManager.GetUserFromLdap(vzid);
        }

        [HttpPost]
        [Route(Routes.MDUA.UserAccess.SaveUserInfo)]
        public bool SaveUserInfo(Contracts.Data.MDUA.UserInfo userInfo)
        {
            return userAccessManager.SaveUserInfo(userId, userInfo);
        }

        [HttpDelete]
        [Route(Routes.MDUA.UserAccess.DeleteUserInfo)]
        public bool DeleteUserInfo(string employeeId)
        {
            return userAccessManager.DeleteUserInfo(userId, employeeId);
        }

        [HttpGet]
        [Route(Routes.MDUA.UserAccess.GetAllODJobs)]
        public Contracts.Data.MDUA.ODJobs.ODJobGroup[] GetAllODJobs()
        {
            return userAccessManager.GetAllODJobs();
        }

        [HttpGet]
        [Route(Routes.MDUA.UserAccess.GetODJobAccess)]
        public Contracts.Data.MDUA.ODJobs.ODJobGroup[] GetODJobAccess(string employeeId)
        {
            return userAccessManager.GetODJobAccess(employeeId);
        }

        [HttpGet]
        [Route(Routes.MDUA.UserAccess.GetFactFileTypeAccess)]
        public Contracts.Data.MDUA.FactTables.FactTable[] GetFactFileTypeAccess(string employeeId)
        {
            return userAccessManager.GetFactFileTypeAccess(employeeId);
        }

        [HttpGet]
        [Route(Routes.MDUA.UserAccess.GetAllFactFile)]
        public Contracts.Data.MDUA.FactTables.FactTable[] GetAllFactFile()
        {
            return userAccessManager.GetAllFactFile();
        }

        [HttpPost]
        [Route(Routes.MDUA.UserAccess.SaveLegacyUserAccess)]
        public bool SaveLegacyUserAccess(Contracts.Data.MDUA.User.LegacyUserAccess legacyUserAccess)
        {
            //Contracts.Data.MDUA.User.LegacyUserAccess lua = new Contracts.Data.MDUA.User.LegacyUserAccess();
            //lua.EmployeeId = "100";
            //lua.FactFileTypes = new Contracts.Data.MDUA.FactTables.FactFileType[] { new Contracts.Data.MDUA.FactTables.FactFileType() { FactTableId = 1, Code = "asdasd" }, new Contracts.Data.MDUA.FactTables.FactFileType() { FactTableId = 1, Code = "asdasd" } };
            //lua.ODJobs = new Contracts.Data.MDUA.ODJobs.ODJob[] { new Contracts.Data.MDUA.ODJobs.ODJob() { Id = 100, Name = "asdasd"} };
            //return lua;
            return userAccessManager.SaveLegacyUserAccess(userId, legacyUserAccess);
        }

        [HttpPost]
        [Route(Routes.MDUA.UserAccess.GetUserAccessFlat)]
        public Contracts.Data.MDUA.UserAccessFlatPage GetUserAccessFlat(Paging pageInfo)
        {
            return userAccessManager.GetUserAccessFlat(userId, string.Empty, pageInfo.PageNumber, pageInfo.RowsPerPage, pageInfo.TotalRows);
        }

        [Route(Routes.MDUA.UserAccess.GetSignedUrlForExportUsers)]
        [HttpGet]
        public string GetSignedUrlForExportUsers(ExportUserType exportType)
        {
            return securityManager.GetSignedUrlKey(userId, string.Format("EU-{0}-{1}", userId, Convert.ToInt32(exportType)));
        }

        [HttpGet]
        [AllowAnonymous]
        [Route(Routes.MDUA.UserAccess.ExportUsers)]
        public async Task<HttpResponseMessage> ExportUsers(string employeeId, ExportUserType exportType, string signedUrl)
        {
            CheckIfApiControllerIsDisposed();
            string verifiedUserId = securityManager.VerifySignedUrlKey(string.Format("EU-{0}-{1}", employeeId, Convert.ToInt32(exportType)), signedUrl);
            if (string.IsNullOrEmpty(verifiedUserId) == false)
            {
                //Response context
                System.Web.HttpResponse Response = System.Web.HttpContext.Current.Response;

                //Get Base64String from logic
                var base64String = await userAccessManager.ExportUsers(verifiedUserId, exportType);
                //Convert to binary
                byte[] binary = Convert.FromBase64String(base64String);

                //Send it as result
                var result = new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new ByteArrayContent(binary)
                };
                result.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment")
                {
                    FileName = string.Format("Export-{0}.csv", exportType)
                };
                result.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");
                return result;
            }
            else
            {
                var msg = new HttpResponseMessage(HttpStatusCode.Unauthorized) { ReasonPhrase = "signedUrl failed validation or expired" };
                throw new HttpResponseException(msg);
            }
        }

        [HttpPost]
        [Route(Routes.MDUA.UserAccess.RefreshUsersFromADGroup)]
        public Contracts.Data.GenericResponse RefreshUsersFromADGroup() 
        {
            return userAccessManager.RefreshUsersFromADGroup(userId);
        }

        [HttpPost]
        [Route(Routes.MDUA.UserAccess.AuditUser)]
        public bool AuditUser(AuditInfo auditInfo)
        {
            auditInfo.EmployeeId = userId;
            userAccessManager.AuditUser(auditInfo);
            return true;
        }

        [Route(Routes.MDUA.UserAccess.GetHomepageContent)]
        public VZ.CFO.MDMFramework.Contracts.Data.MDUA.User.HomepageContent GetHomepageContent(string eid)
        {
            return userAccessManager.GetHomepageContent(eid);
        }

        [HttpPost]
        [Route(Routes.MDUA.UserAccess.PostHomepageContent)]
        public bool PostHomepageContent(string eid, VZ.CFO.MDMFramework.Contracts.Data.MDUA.User.HomepageContent homepageContent)
        {
            return userAccessManager.UpdateHomepageContent(eid, homepageContent);
        }
    }
}
