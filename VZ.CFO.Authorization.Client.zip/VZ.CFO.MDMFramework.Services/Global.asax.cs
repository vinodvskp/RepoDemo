﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Security;
using System.Web.SessionState;

namespace VZ.CFO.MDMFramework.Services
{
    public class Global : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {
            Startup.Startup.RegisterDataProviders(new Configuration.ServerConfigurationManager(new Configuration.FileBasedConfigDataProvider()));

            GlobalConfiguration.Configure(Startup.WebApiConfig.Register);

          
            //GlobalConfiguration.Configuration.Routes.MapHttpRoute(
            //    "Default", 
            //    "{controller}/{id}", 
            //    new { id = RouteParameter.Optional });
        }

        protected void Session_Start(object sender, EventArgs e)
        {

        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {
            //Fortify begin
            this.Response.Headers["X-Content-Type-Options"] = "nosniff";
            //Fortify end
        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {

        }
    }
}