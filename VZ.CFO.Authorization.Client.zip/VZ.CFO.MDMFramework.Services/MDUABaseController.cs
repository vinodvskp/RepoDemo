﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using VZ.CFO.MDMFramework.Configuration;
using VZ.CFO.MDMFramework.Contracts.Service;
using VZ.CFO.MDMFramework.Contracts.Data;

namespace VZ.CFO.MDMFramework.Services
{
   public abstract class MDUABaseController : MDMFrameworkBaseController
    {
        private string userId = string.Empty;
    
        public MDUABaseController()
        {
            this.userId = GetCurrentUser(); 
        }

       //[HttpGet]
       //[AllowAnonymous]
       //[ClaimsAuthorization(Contracts.Data.KnownValues.Security.ClaimTypes.MappingTableGenericClaim, Contracts.Data.KnownValues.Security.ClaimValues.ReadClaimValue)]
        public async Task<HttpResponseMessage> OnExportTable(string base64String, string fileName)
       {
               //Response context
               System.Web.HttpResponse Response = System.Web.HttpContext.Current.Response;

               //Get Base64String from logic
              
               //Convert to binary
               byte[] binary = Convert.FromBase64String(base64String);

               //Send it as result
               HttpResponseMessage result = new HttpResponseMessage(HttpStatusCode.OK)
               {
                   Content = new ByteArrayContent(binary)
               };
               result.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment")
               {
                   FileName = string.Format("{0}-Download.csv", fileName)
               };
               result.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");
               return await Task.Run(() => result) ;
       }

    }
}