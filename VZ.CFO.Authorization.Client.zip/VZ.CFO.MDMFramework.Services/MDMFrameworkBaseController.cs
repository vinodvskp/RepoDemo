﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using Microsoft.Owin.Security;
using System.Security.Claims;
using System.Net.Http;
using System.Web.Http.Cors;
using VZ.CFO.MDMFramework.Services.FIlter;
using VZ.CFO.MDMFramework.Configuration;
namespace VZ.CFO.MDMFramework.Services
{
    [CustomExceptionFilter]
    [Authorize]
    [EnableCors(origins: "*", headers: "*", methods: "*", SupportsCredentials = true)]
    public class MDMFrameworkBaseController : ApiController
    {
        /// <summary>
        /// Flag to hold the detail about the disposed status
        /// </summary>
        private bool disposed;

        /// <summary>
        /// property to hodl data provider factory
        /// </summary>
        protected Providers.DataProviderFactory DataProviderFactory
        {
            get
            {
                if (null == Providers.DataProviderFactory.Current)
                {
                    throw new InvalidOperationException("DataProviderFactory has not been properly initialized");
                }
                return Providers.DataProviderFactory.Current;
            }
        }

        protected Contracts.Service.ISecurityManager GetSecurityManager()
        {
            ConfigurationManager config = DataProviderFactory.GetProvider<ConfigurationManager>();
            return config.GetSecurityManager();
        }

        /// <summary>
        /// method to release unmanaged resources
        /// </summary>
        /// <param name="disposing">Flag to indicate if the object is being disposed</param>
        protected override void Dispose(bool disposing)
        {
            if (disposed)
            {
                return;
            }
            disposed = true;
            base.Dispose(disposing);
        }

        /// <summary>
        /// Checks if this controller instance has already been disposed.
        /// Throws an ObjectDisposedException if this controller is already disposed.
        /// </summary>
        protected void CheckIfApiControllerIsDisposed()
        {
            // Check if this controller instance is already disposed.
            if (disposed)
            {
                throw new ObjectDisposedException(GetType().Name);
            }
        }

        protected string GetCurrentUser()
        {
            string currentUser = string.Empty;
            if (HttpContext.Current.User != null)
            {
                ClaimsPrincipal principal = HttpContext.Current.User as ClaimsPrincipal;
                System.Security.Claims.ClaimsPrincipal cp = principal as System.Security.Claims.ClaimsPrincipal;
                if (cp != null)
                {
                    var userClaim = cp.FindFirst(Contracts.Data.KnownValues.Security.mdmFrameworkUserIdClaim);
                    if (userClaim != null)
                    {
                        currentUser = userClaim.Value;
                    }
                }
            }

            return currentUser;
            //For testing
            //return "3565045889";
        }

        protected System.Security.Claims.Claim[] GetLoggedInUserClaims()
        {
            List<System.Security.Claims.Claim> userClaimList = new List<Claim>();
            string currentUser = string.Empty;
            if (HttpContext.Current.User != null)
            {
                ClaimsPrincipal principal = HttpContext.Current.User as ClaimsPrincipal;
                System.Security.Claims.ClaimsPrincipal cp = principal as System.Security.Claims.ClaimsPrincipal;
                userClaimList.AddRange(cp.Claims);
            }
            return userClaimList.ToArray();
        }

    }
}