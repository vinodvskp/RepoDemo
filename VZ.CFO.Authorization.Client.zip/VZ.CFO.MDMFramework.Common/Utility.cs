﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Common
{
    public static class Utility
    {
        // Fortify begin
        private const int Keysize = 256;
        // This constant determines the number of iterations for the password bytes generation function.
        private const int DerivationIterations = 1000;

        #region Serialization
        /// <summary>
        /// Serialize an object to xml
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static string SerializeObject(object obj)
        {
            if (null == obj)
            {
                throw new ArgumentNullException("obj", "obj cannot be null");
            }
            using (MemoryStream memoryStream = new MemoryStream())
            using (StreamReader reader = new StreamReader(memoryStream))
            {
                DataContractSerializer serializer = new DataContractSerializer(obj.GetType());
                serializer.WriteObject(memoryStream, obj);
                memoryStream.Position = 0;
                return reader.ReadToEnd();
            }
        }

        /// <summary>
        /// De-serialize Request XML to doors request / export request
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="requestXML"></param>
        /// <returns></returns>
        public static T DeserializeObject<T>(string requestXML)
        {
            using (Stream stream = new MemoryStream())
            {
                byte[] data = System.Text.Encoding.UTF8.GetBytes(requestXML);
                stream.Write(data, 0, data.Length);
                stream.Position = 0;
                DataContractSerializer deserializer = new DataContractSerializer(typeof(T));
                return (T)deserializer.ReadObject(stream);
            }
        }


        public static string SerlializeToJsonString(object obj)
        {
            if (null == obj)
            {
                throw new ArgumentNullException("obj", "obj cannot be null");
            }
            using (MemoryStream memoryStream = new MemoryStream())
            using (StreamReader reader = new StreamReader(memoryStream))
            {
                DataContractJsonSerializer serializer = new DataContractJsonSerializer(obj.GetType());
                serializer.WriteObject(memoryStream, obj);
                memoryStream.Position = 0;
                return reader.ReadToEnd();
            }
        }
        #endregion

        #region encryption
        /*public static string Encrypt(string plainText, string password)
        {
            PasswordDeriveBytes pdb = new PasswordDeriveBytes(password
                , new byte[] {
                    0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65,0x64, 0x76, 0x65, 0x64, 0x65, 0x76
                });
            byte[] encryptedData = EncryptCore(plainText, pdb.GetBytes(32), pdb.GetBytes(16));
            return Convert.ToBase64String(encryptedData, Base64FormattingOptions.None);
        }

        public static string Decrypt(string cipherText, string password)
        {
            byte[] cipherBytes = Convert.FromBase64String(cipherText);
            PasswordDeriveBytes pdb = new PasswordDeriveBytes(password
                , new byte[] {
                    0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65,0x64, 0x76, 0x65, 0x64, 0x65, 0x76
                });
            //byte[] decryptedData = Decrypt(cipherBytes, pdb.GetBytes(32), pdb.GetBytes(16));
            //return System.Text.Encoding.Unicode.GetString(decryptedData);
            return DecryptStringFromBytes(cipherBytes, pdb.GetBytes(32), pdb.GetBytes(16));

        }

        private static byte[] DecryptCore(byte[] cipherData, byte[] key, byte[] IV)
        {
            MemoryStream ms = new MemoryStream();
            Rijndael alg = Rijndael.Create();
            alg.Key = key;
            alg.IV = IV;
            CryptoStream cs = new CryptoStream(ms, alg.CreateDecryptor(), CryptoStreamMode.Write);
            cs.Write(cipherData, 0, cipherData.Length);
            cs.Close();
            byte[] decryptedData = ms.ToArray();
            return decryptedData;
        }

        private static byte[] EncryptCore(string plainText, byte[] Key, byte[] IV)
        {
            // Check arguments.
            if (plainText == null || plainText.Length <= 0)
                throw new ArgumentNullException("plainText");
            if (Key == null || Key.Length <= 0)
                throw new ArgumentNullException("Key");
            if (IV == null || IV.Length <= 0)
                throw new ArgumentNullException("Key");
            byte[] encrypted;
            // Create an Rijndael object
            // with the specified key and IV.
            using (Rijndael rijAlg = Rijndael.Create())
            {
                rijAlg.Key = Key;
                rijAlg.IV = IV;

                // Create a decrytor to perform the stream transform.
                ICryptoTransform encryptor = rijAlg.CreateEncryptor(rijAlg.Key, rijAlg.IV);

                // Create the streams used for encryption.
                using (MemoryStream msEncrypt = new MemoryStream())
                {
                    using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                        {

                            //Write all data to the stream.
                            swEncrypt.Write(plainText);
                        }
                        encrypted = msEncrypt.ToArray();
                    }
                }
            }


            // Return the encrypted bytes from the memory stream.
            return encrypted;

        }

        private static string DecryptStringFromBytes(byte[] cipherText, byte[] Key, byte[] IV)
        {
            // Check arguments.
            if (cipherText == null || cipherText.Length <= 0)
                throw new ArgumentNullException("cipherText");
            if (Key == null || Key.Length <= 0)
                throw new ArgumentNullException("Key");
            if (IV == null || IV.Length <= 0)
                throw new ArgumentNullException("Key");

            // Declare the string used to hold
            // the decrypted text.
            string plaintext = null;

            // Create an Rijndael object
            // with the specified key and IV.
            using (Rijndael rijAlg = Rijndael.Create())
            {
                rijAlg.Key = Key;
                rijAlg.IV = IV;

                // Create a decrytor to perform the stream transform.
                ICryptoTransform decryptor = rijAlg.CreateDecryptor(rijAlg.Key, rijAlg.IV);

                // Create the streams used for decryption.
                using (MemoryStream msDecrypt = new MemoryStream(cipherText))
                {
                    using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                        {

                            // Read the decrypted bytes from the decrypting stream
                            // and place them in a string.
                            plaintext = srDecrypt.ReadToEnd();
                        }
                    }
                }

            }

            return plaintext;

        }
        */

        public static string Encrypt(string plainText, string passPhrase)
        {
            // Salt and IV is randomly generated each time, but is preprended to encrypted cipher text
            // so that the same Salt and IV values can be used when decrypting.  
            var saltStringBytes = Generate256BitsOfRandomEntropy();
            var ivStringBytes = Generate256BitsOfRandomEntropy();
            var plainTextBytes = Encoding.UTF8.GetBytes(plainText);
            using (var password = new Rfc2898DeriveBytes(passPhrase, saltStringBytes, DerivationIterations))
            {
                var keyBytes = password.GetBytes(Keysize / 8);
                using (var symmetricKey = new RijndaelManaged())
                {
                    symmetricKey.BlockSize = 256;
                    symmetricKey.Mode = CipherMode.CBC;
                    symmetricKey.Padding = PaddingMode.PKCS7;
                    using (var encryptor = symmetricKey.CreateEncryptor(keyBytes, ivStringBytes))
                    {
                        using (var memoryStream = new MemoryStream())
                        {
                            using (var cryptoStream = new CryptoStream(memoryStream, encryptor, CryptoStreamMode.Write))
                            {
                                cryptoStream.Write(plainTextBytes, 0, plainTextBytes.Length);
                                cryptoStream.FlushFinalBlock();
                                // Create the final bytes as a concatenation of the random salt bytes, the random iv bytes and the cipher bytes.
                                var cipherTextBytes = saltStringBytes;
                                cipherTextBytes = cipherTextBytes.Concat(ivStringBytes).ToArray();
                                cipherTextBytes = cipherTextBytes.Concat(memoryStream.ToArray()).ToArray();
                                memoryStream.Close();
                                cryptoStream.Close();
                                return Convert.ToBase64String(cipherTextBytes);
                            }
                        }
                    }
                }
            }
        }

        public static string Decrypt(string cipherText, string passPhrase)
        {
            // Get the complete stream of bytes that represent:
            // [32 bytes of Salt] + [32 bytes of IV] + [n bytes of CipherText]
            var cipherTextBytesWithSaltAndIv = Convert.FromBase64String(cipherText);
            // Get the saltbytes by extracting the first 32 bytes from the supplied cipherText bytes.
            var saltStringBytes = cipherTextBytesWithSaltAndIv.Take(Keysize / 8).ToArray();
            // Get the IV bytes by extracting the next 32 bytes from the supplied cipherText bytes.
            var ivStringBytes = cipherTextBytesWithSaltAndIv.Skip(Keysize / 8).Take(Keysize / 8).ToArray();
            // Get the actual cipher text bytes by removing the first 64 bytes from the cipherText string.
            var cipherTextBytes = cipherTextBytesWithSaltAndIv.Skip((Keysize / 8) * 2).Take(cipherTextBytesWithSaltAndIv.Length - ((Keysize / 8) * 2)).ToArray();

            using (var password = new Rfc2898DeriveBytes(passPhrase, saltStringBytes, DerivationIterations))
            {
                var keyBytes = password.GetBytes(Keysize / 8);
                using (var symmetricKey = new RijndaelManaged())
                {
                    symmetricKey.BlockSize = 256;
                    symmetricKey.Mode = CipherMode.CBC;
                    symmetricKey.Padding = PaddingMode.PKCS7;
                    using (var decryptor = symmetricKey.CreateDecryptor(keyBytes, ivStringBytes))
                    {
                        using (var memoryStream = new MemoryStream(cipherTextBytes))
                        {
                            using (var cryptoStream = new CryptoStream(memoryStream, decryptor, CryptoStreamMode.Read))
                            {
                                var plainTextBytes = new byte[cipherTextBytes.Length];
                                var decryptedByteCount = cryptoStream.Read(plainTextBytes, 0, plainTextBytes.Length);
                                memoryStream.Close();
                                cryptoStream.Close();
                                return Encoding.UTF8.GetString(plainTextBytes, 0, decryptedByteCount);
                            }
                        }
                    }
                }
            }
        }

        private static byte[] Generate256BitsOfRandomEntropy()
        {
            var randomBytes = new byte[32]; // 32 Bytes will give us 256 bits.
            using (var rngCsp = new RNGCryptoServiceProvider())
            {
                // Fill the array with cryptographically secure random bytes.
                rngCsp.GetBytes(randomBytes);
            }
            return randomBytes;
        }
        // Fortify end 

        /// <summary>
        /// Method to deserialize json. 
        /// TODO: Should be moved to Util. 
        /// Placing it here for time being to avoid circular reference to Business Logic layer
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="json"></param>
        /// <returns></returns>
        public static T DeserializeFromJson<T>(string json)
        {
            var sanitized = santize(json);
            using (Stream stream = new MemoryStream())
            {
                byte[] data = System.Text.Encoding.UTF8.GetBytes(sanitized);
                stream.Write(data, 0, data.Length);
                stream.Position = 0;
                DataContractJsonSerializer deserializer = new DataContractJsonSerializer(typeof(T));
                return (T)deserializer.ReadObject(stream);
            }
        }

        private static string santize(string json)
        {
            // Here is a list of special characters that you can escape when creating a string literal for JSON:
            // \b  Backspace (ASCII code 08)
            // \f  Form feed (ASCII code 0C)
            // \n  New line
            // \r  Carriage return
            // \t  Tab
            // \v  Vertical tab
            // \'  Apostrophe or single quote
            // \"  Double quote
            // \\  Backslash character

            var nstr = Regex.Replace(json, "\n|\t|\r|\v|\f|[\b]", m =>
            {
                switch (m.Value)
                {
                    case "\n": return "\\n";
                    case "\r": return "\\r";
                    case "\b": return "\\b";
                    case "\f": return "\\f";
                    case "\v": return "\\v";
                    case "\t": return "\\t";
                    default: return m.Value;
                }
            });
            return nstr;
        }

        /// <summary>
        ///  Method to Serialize json. 
        ///  TODO: Should be moved to Util. 
        ///  Placing it here for time being to avoid circular reference to Business Logic layer
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static string SerializeToJson(object obj)
        {
            if (null == obj)
            {
                throw new ArgumentNullException("obj", "obj cannot be null");
            }
            using (MemoryStream memoryStream = new MemoryStream())
            using (StreamReader reader = new StreamReader(memoryStream))
            {
                DataContractJsonSerializer serializer = new DataContractJsonSerializer(obj.GetType());
                serializer.WriteObject(memoryStream, obj);
                memoryStream.Position = 0;
                return reader.ReadToEnd();
            }
        }
        public static string ConvertToBase64String(string text)
        {
            byte[] textBytes = System.Text.Encoding.UTF8.GetBytes(text);
            string base64String = Convert.ToBase64String(textBytes);
            return base64String;
        }

        public static string ConvertFromBase64String(string base64Text)
        {
            byte[] textBytes = Convert.FromBase64String(base64Text);
            string clearText = System.Text.Encoding.UTF8.GetString(textBytes);
            return clearText.Trim();
        }        

        /// <summary>
        /// Formats the string containing date to standard date string
        /// </summary>
        /// <param name="dateString"></param>
        /// <returns></returns>
        public static string FormatEspDateTime(string dateString)
        {
            //17.01 ON WEDNESDAY APRIL 20TH, 2016
            dateString = dateString.Replace(" ON", string.Empty);
            //17.01 WEDNESDAY APRIL 20TH, 2016
            dateString = dateString.Replace("ST,", string.Empty);
            dateString = dateString.Replace("TH,", string.Empty);
            dateString = dateString.Replace("ND,", string.Empty);
            dateString = dateString.Replace("RD,", string.Empty);
            //17.01 WEDNESDAY APRIL 20 2016
            return dateString;
        }
        #endregion

        public static string GetExcelConnectionString(string filename)
        {
            string fileExtension = Path.GetExtension(filename).ToLower();
            if (fileExtension.Equals(".xls"))
            {
                return string.Format(@"Provider=Microsoft.Jet.OLEDB.4.0; Data Source={0};Extended Properties=""Excel 8.0;IMEX=1;""", filename);
            }
            else if (fileExtension.Equals(".xlsx"))
            {
                return string.Format(@"Provider=Microsoft.ACE.OLEDB.12.0; Data Source={0};Extended Properties=""Excel 12.0 Xml;IMEX=1;""", filename);
            }
            return string.Empty;
        }

        public static double ConvertBytesToMegabytes(long bytes)
        {
            return (bytes / 1024f) / 1024f;
        }

        public static string SanitizeFileName(string fileName)
        {
            if (string.IsNullOrEmpty(fileName))
            {
                return "SanitizedFileName";
            }

            char[] specialChars = new char[] { '\\', '/', ':', '*', '?', '"', '>', '<', '|', ';' };
            if (fileName.IndexOfAny(specialChars) > 0)
            {
                return "SanitizedFileName";
            }

            return fileName;
        }

        public static string SanitizeFilePath(string validFileLocation, string filePath, string[] allowedFileExtensions)
        {
            string sanitizedFilePath = string.Empty;
            System.IO.FileInfo fileInfo = new FileInfo(filePath);

            List<string> allowedFileExtnList = new List<string>();
            allowedFileExtnList.AddRange(allowedFileExtensions);

            if (fileInfo.DirectoryName != validFileLocation)
            {
                throw new Exception(string.Format("FilePath validation failed. Invalid Directory path - {0}", fileInfo.DirectoryName));
            }

            if (allowedFileExtnList.Contains(fileInfo.Extension.ToLower()) == false)
            {
                throw new Exception(string.Format("FilePath validation failed. Invalid File Extension - {0}", fileInfo.Extension));
            }

            sanitizedFilePath = string.Format("{0}\\{1}", fileInfo.DirectoryName, SanitizeFileName(fileInfo.Name));
            return sanitizedFilePath;
        }
    }

}