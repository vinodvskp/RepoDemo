﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Common
{
    public static class ErrorConstants
    {
        public static readonly string UnauthorizedAccess = "MDMF-ERR-UNAUTH";
        public static readonly string KnownException = "MDMF-ERR-HANDLEDEX";
    }
}
