﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Common
{
    public class MDMFrameworkException : Exception
    {
        public string errorCode { get; set; }

        public MDMFrameworkException()
        {
 
        }

        public MDMFrameworkException(string message) 
            : base(message)
        {
 
        }

        public MDMFrameworkException(string errorCode, string message)
            : base(message)
        {
            this.errorCode = errorCode;
        }

        public MDMFrameworkException(string message, System.Exception inner)
            : base(message, inner)
        {
 
        }

        public MDMFrameworkException(string errorCode, string message, System.Exception inner)
            : base(message, inner)
        {
            this.errorCode = errorCode;
        }
    }
}
