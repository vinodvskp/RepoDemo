﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Configuration;

namespace VZ.CFO.MDMFramework.Common
{
    /// <summary>
    /// Extension Class for WebResponse Object
    /// </summary>
    public static class WebResponseExtension
    {
        private static int RestSvcCallOffsetTime
        {
            get { return Convert.ToInt32(ConfigurationManager.AppSettings["RestSvcRequestOffsetTime"].ToString()); }
        }
        /// <summary>
        /// Extension method for GetResponse.
        /// This is to catch exception triggered when the request failed and 
        /// send the response containing the HTTP Status code for error handling
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        //public static WebResponse GetResponseNoException(this WebRequest request)
        //{
        //    try
        //    {
        //        return (WebResponse)request.GetResponse();
        //    }
        //    catch (WebException we)
        //    {
        //        WebResponse resp = null;
        //        if(we.Response != null)
        //        {
        //            resp = we.Response as WebResponse;
        //            if (resp == null)
        //                throw;
        //        }
        //        return resp;
        //    }
        //}
        public static HttpWebResponse GetResponseNoException(this HttpWebRequest request)
        {
            try
            {
                System.Threading.Thread.Sleep(RestSvcCallOffsetTime);
                return (HttpWebResponse)request.GetResponse();
            }
            catch (WebException we)
            {

                if (we.Status == WebExceptionStatus.ReceiveFailure || we.Status == WebExceptionStatus.ConnectionClosed)
                {
                    throw we;
                }
                HttpWebResponse resp = null;
                if (we.Response != null)
                {
                    resp = we.Response as HttpWebResponse;
                    if (resp == null)
                        throw;
                }
                return resp;
            }
        }
    }
}
