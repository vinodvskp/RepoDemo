﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
namespace VZ.CFO.MDMFramework.Contracts.Data
{
    [DataContract]
    public class ColumnData
    {
        [DataMember]
        public string[] Values { get; set; }

        //[DataMember]
        //public List<string> ValueCollection { get; set; }
    }
}
