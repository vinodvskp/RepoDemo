﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data
{
    [DataContract]
    public class GenericResponse
    {
        [DataMember]
        public KnownValues.ResponseTypes ResponseType { get; set; }
        [DataMember]
        public string Message { get; set; }
    }
}
