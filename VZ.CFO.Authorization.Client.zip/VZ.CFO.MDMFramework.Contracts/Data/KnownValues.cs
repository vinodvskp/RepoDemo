﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data
{
    public static class KnownValues
    {
        public static class Security
        {
            public const string mdmFrameworkClaimTypeFmt = "MDMFramework.{0}.{1}";
            public const string mdmFrameworkUserIdClaim = "urn:verizon.claimidentity";

            public const string mdmFrameworkPortalUserRoleAccessObjType = "UserRole";
            public const string mdmFrameworkPortalODJAccessObjType = "ODJ";

            public const string mdmFrameworkUserUploadAccessObjectType = "UserUpload";

            //Generic Access Claim Types
            public static class ClaimTypes
            {
                public const string PortalUserRoleGenericClaim = "MDMFramework.UserRole.0";
                public const string OnDemandJobsGenericClaim = "MDMFramework.ODJ.0";
                public const string MappingTableGenericClaim = "MDMFramework.MT.0";
                public const string VersionMgmtGenericClaim = "MDMFramework.VM.0";
            }

            //Access Claim Values
            public static class ClaimValues
            {
                public const string ReadClaimValue = "READ";
                public const string EditClaimValue = "EDIT";

                public static class MT
                {
                    public const string MigrateClaimValue = "MIGRATE";
                }

                public static class VM
                {
                    public const string Tracking = "TRACKING";
                }

                public static class ODJ
                {
                    public const string Trigger = "TRIGGER";
                }

                public static class UserUpload
                {
                    public const string CanAddUserInputKeys = "ADFK";
                    public const string CanPostAdjImmediately = "ADJN";
                    public const string CanPostAdjToAnyPeriod = "POAP";
                    public const string CanAssignUserFileType = "ASFT";
                    public const string CanAssignAutosysOD = "ASAO";
                    public const string CanAddNewFileType = "ADFT";
                    public const string CanModifyOutline = "MDOL";
                    public const string CanProcessCpga = "CPGA";
                    public const string CanPostToAnyPeriod = "PFAP";

                    public const string CanPostFactData = "UPLOADFACTDATA";
                }

                public static class UserRole
                {
                    public const string User = "USER";
                    public const string Admin = "ADMINISTRATOR";
                }
            }
        }

        [Serializable]
        public enum ResponseTypes
        {
            Success = 0,
            Error = 1,
            Fatal = 2,
            Warning = 3
        }
    }
}
