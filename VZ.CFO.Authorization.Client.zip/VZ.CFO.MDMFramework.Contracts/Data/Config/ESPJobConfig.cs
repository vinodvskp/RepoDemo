﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.Config
{
    [DataContract(Namespace = "VZ.CFO.MDMFramework.Contracts.Data.Config", Name = "ESPJobConfig")]
    public class ESPJobConfig
    {
        [DataMember]
        public string EspRestApiUrl { get; set; }
        [DataMember]
        public string EspPrefix { get; set; }
        [DataMember]
        public string EspUserName { get; set; }
        [DataMember]
        public string EspPwd { get; set; }
        [DataMember]
        public string RestSvcRequestOffsetTime { get; set; }
        [DataMember]
        public string EspTimezone { get; set; }
        
    }
}
