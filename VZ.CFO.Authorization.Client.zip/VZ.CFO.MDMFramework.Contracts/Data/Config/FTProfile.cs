﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.Config
{
    [DataContract(Namespace = "VZ.CFO.MDMFramework.Contracts.Data.Config", Name = "ftprofile")]
    public class FTProfile
    {
        [DataMember]
        public string HostName { get; set; }
        [DataMember]
        public string ProfileName { get; set; }
        [DataMember]
        public string SshHostKeyFingerprint { get; set; }
        [DataMember]
        public string SshPrivateKeyPath { get; set; }
        [DataMember]
        public string UserName { get; set; }

    }
}
