﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.Config
{
    [DataContract(Namespace = "VZ.CFO.MDMFramework.Contracts.Data.Config", Name = "menuconfig")]
    public class MenuConfig
    {
        [DataMember]
        public Contracts.Data.MDUA.Menu[] AvailableMenus { get; set; }
    }
}
