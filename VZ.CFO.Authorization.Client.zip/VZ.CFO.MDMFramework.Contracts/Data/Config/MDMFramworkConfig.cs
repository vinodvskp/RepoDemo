﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.Config
{
    [DataContract]
    public class MDMFrameworkConfig
    {
        [DataMember(Order=1)]
        public DbProfile[] DbProfileList { get; set; }

        [DataMember(Order=2)]
        public FTProfile[] FtProfileList { get; set; }

        [DataMember(Order=3)]
        public MenuConfig MenuConfiguration { get; set; }

        [DataMember(Order=4)]
        public MessageDictionary[] MessageConfig { get; set; }

        [DataMember(Order=5)]
        public HomeMenuItem[] HomeMenuConfig { get; set; }
    }
}
