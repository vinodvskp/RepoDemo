﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace VZ.CFO.MDMFramework.Contracts.Data.Config
{
    [DataContract]
    public class HomeMenuItem
    {
        [DataMember(Order=1)]
        public string Text { get; set; }

        [DataMember(Order=2)]
        public string Link { get; set; }

        [DataMember(Order=3)]
        public string Extra { get; set; }
    }
}
