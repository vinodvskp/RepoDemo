﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables
{
    [DataContract]
    public class KeyComboMoveRequest : FileTypeRequest
    {
        [Serializable]
        public enum MoveOptions
        {
            None = 0,
            Selected = 1,
            All = 2
        }
        [DataMember]
        public long TargetFileTypeCodeId { get; set; }
        [DataMember]
        public MoveOptions MoveOption { get; set; }
        [DataMember]
        public string[] MoveRecords { get; set; }

    }
}