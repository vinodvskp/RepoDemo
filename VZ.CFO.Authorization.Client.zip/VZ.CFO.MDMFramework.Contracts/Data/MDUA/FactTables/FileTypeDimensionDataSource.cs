﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables
{
    [DataContract]
    public class FileTypeDimensionDataSource
    {
        [DataMember]
        public long FileFieldId { get; set; }
        [DataMember]
        public FactTableKnownValues.FactColumnDataSourceType DataSourceType { get; set; }
        [DataMember]
        public string ForcedValue { get; set; }
        [DataMember]
        public long? AutomapId { get; set; }
    }
}
