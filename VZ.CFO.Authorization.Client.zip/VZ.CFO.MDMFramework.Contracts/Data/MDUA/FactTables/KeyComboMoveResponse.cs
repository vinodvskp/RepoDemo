﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables
{
    [DataContract]
    public class KeyComboMoveResponse : FileTypeResponse
    {
        [DataMember]
        public int TotalFactsMoved { get; set; }
        [DataMember]
        public int TotalKeysMoved { get; set; }
    }
}