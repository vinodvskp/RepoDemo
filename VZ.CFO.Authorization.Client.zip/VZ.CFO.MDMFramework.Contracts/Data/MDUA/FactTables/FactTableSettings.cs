﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables
{
    [DataContract]
    public class FactTableSettings
    {
        [DataMember]
        public string Environment { get; set; }
        [DataMember]
        public bool UserFeedEnabled { get; set; }
        [DataMember]
        public string CurrentMonth { get; set; }
        [DataMember]
        public string CurrentYear { get; set; }
        //[DataMember]
        //public DateTime LastProcessed { get; set; }
        //[DataMember]
        //public string LockedBy { get; set; }
        //[DataMember]
        //public bool UserFeedEnabled { get; set; }
        //[DataMember]    
        //public bool CoaCorEnabled { get; set; }
        //[DataMember]
        //public string UserFeedUser { get; set; }
        //[DataMember]
        //public string CoaCorUser { get; set; }
        //[DataMember]
        //public string CurrentMonth { get; set; }
        //[DataMember]
        //public string CurrentYear { get; set; }
        //[DataMember]
        //public string BroadcastMessage { get; set; }
    }
}
