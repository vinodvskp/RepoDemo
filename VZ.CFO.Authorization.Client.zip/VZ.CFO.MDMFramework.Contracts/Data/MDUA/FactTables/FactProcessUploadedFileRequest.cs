﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables
{
    [DataContract]
    public class FactProcessUploadedFileRequest
    {
        [DataMember]
        public string UserId { get; set; }

        [DataMember]
        public string UploadedFileName { get; set; }

        [DataMember]
        public string SignedUrl { get; set; }

        [DataMember]
        public long FactTableId { get; set; }

        [DataMember]
        public long FileTypeCodeId { get; set; }

        [DataMember]
        public FactReportingPeriod ReportingPeriod { get; set; }

        [DataMember]
        public FactTableKnownValues.FactUploadProcessType UploadProcessType { get; set; }

        [DataMember]
        public long RunStatusId { get; set; }

        [DataMember]
        public bool IsVerifyOnly { get; set; }
    }
}
