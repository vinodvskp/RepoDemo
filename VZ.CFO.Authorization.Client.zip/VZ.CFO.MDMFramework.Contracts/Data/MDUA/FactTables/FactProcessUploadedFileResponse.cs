﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables
{
    [DataContract]
    public class FactProcessUploadedFileResponse
    {
        [DataMember]
        public FactTableKnownValues.ResponseMsgType MessageType { get; set; }
        [DataMember]
        public string Message { get; set; }
        [DataMember]
        public string[] ResponseTableColumns { get; set; }
        [DataMember]
        public ColumnData[] ResponseTableData { get; set; }
        [DataMember]
        public int RowsAffected { get; set; }
        [DataMember]
        public long RunStatusId { get; set; }
        [DataMember]
        public FactTableKnownValues.StageProcessingStatus StageProcessStatus { get; set; }
        [DataMember]
        public List<TransactionLevelMessage> TransactionalMessages { get; set; }
    }
}
