﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables
{
    [DataContract]
    public class FactTable
    {
        [DataMember]
        public long Id { get; set; }
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string PhysicalTable { get; set; }
        [DataMember]
        public string Description { get; set; }
        [DataMember]
        public string MonthlyUploadStageName { get; set; }
        [DataMember]
        public string YearlyUploadStageName { get; set; }
        [DataMember]
        public string FileTypeKeyComboTableName { get; set; }
        [DataMember]
        public bool AllowAdjustments { get; set; }
        public string RepoProfile {get;set;}
        [DataMember]
        public FactDimension[] AvailableDimensions { get; set; }
        [DataMember]
        public CustomField[] AvailableCustomFields { get; set; }
        [DataMember]
        public string ValidationProc { get; set; }
        [DataMember]
        public FactTableKnownValues.FactTableType FactTableType { get; set; }
        [DataMember]
        public FactFileType[] FileTypes { get; set; }
    }
}