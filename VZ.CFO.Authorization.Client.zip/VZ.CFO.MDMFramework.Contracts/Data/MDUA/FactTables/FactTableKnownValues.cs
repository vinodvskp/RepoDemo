﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables
{
    [Serializable]
    public class FactTableKnownValues
    {
        [Serializable]
        public enum FactColumnDataSourceType
        {
            DataFromUserFeed = 0,
            UserDefinable = 1,
            ForcedValue = 2,
            AutoMap = 3
        }

        [Serializable]
        public enum ResponseMsgType
        {
            None = 0,
            Error = 1,
            Success = 2,
            Fatal = 3
        }

        [Serializable]
        public enum FactUploadType
        {
            None = 0,
            Month = 1,
            Yearly = 2
        }
        
        [Serializable]
        public enum FactUploadProcessType
        {
            FactData = 0,
            KeyCombo = 1,
            AddKeysAndUploadFact = 2
        }

        [Serializable]
        public enum FactKnownColumnValidationType
        {
            None = 0,
            ShortData = 1,
            DoubleData = 2,
            IntData = 3
        }

        [Serializable]
        public enum FactTableType
        {
            None = 0,
            Legacy = 1,
            Fbit = 2
        }

        [Serializable]
        public enum StageProcessingStatus : int
        {
            None = -3,
            TransactionLevelWarning = -2,
            TransactionLevelError = -1,
            LoadedToFact = 0,
            AdditionOfKeysRequired = 1,
            CriticalValidationsFailed = 2,
            CriticalValidationsSuccess = 3
        }

        public static readonly string[] FactMonthTypeUploadKnownColumns = new string[] { "PERIOD", "AMOUNT"};
        public static readonly string[] FactYearTypeUploadKnownColumns = new string[] { "FISCAL_YEAR", "BEGBAL", "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", 
            "AUG", "SEP", "OCT", "NOV", "DEC" };
        
        public static readonly string[] FactMonthTypeUploadKnownStgColumns = new string[] { "PERIOD", "AMOUNT" };
        public static readonly string[] FactYearTypeUploadKnownStgColumns = new string[] { "FISCAL_YEAR", "BEGBAL", "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", 
            "AUG", "SEP", "OCT", "NOV", "DEC" };

        public static readonly string[] FactMonthTypeUploadKnownStgColumnsForBind = new string[] { ":PERIOD", ":AMOUNT" };
        public static readonly string[] FactYearTypeUploadKnownStgColumnsForBind = new string[] { ":FISCAL_YEAR", ":BEGBAL", ":JAN", ":FEB", ":MAR", ":APR", ":MAY", ":JUN", ":JUL", 
            ":AUG", ":SEP", ":OCT", ":NOV", ":DEC" };

        public static FactKnownColumn[] GetFactKnownColumns(bool isYearly)
        {

            List<FactKnownColumn> factKnownColumns = new List<FactKnownColumn>();

            if (isYearly)
            {
                factKnownColumns.Add(new FactKnownColumn() { Name = "FISCAL_YEAR", DataType = "short", ValidationType = FactKnownColumnValidationType.ShortData, PeformNullCheckForAdjustment = false, CanAllowNullNonAdjustment = false });
                factKnownColumns.Add(new FactKnownColumn() { Name = "BEGBAL", DataType = "double", ValidationType = FactKnownColumnValidationType.DoubleData, PeformNullCheckForAdjustment = false, CanAllowNullNonAdjustment = true });
                factKnownColumns.Add(new FactKnownColumn() { Name = "JAN", DataType = "double", ValidationType = FactKnownColumnValidationType.DoubleData, PeformNullCheckForAdjustment = false, CanAllowNullNonAdjustment = true });
                factKnownColumns.Add(new FactKnownColumn() { Name = "FEB", DataType = "double", ValidationType = FactKnownColumnValidationType.DoubleData, PeformNullCheckForAdjustment = false, CanAllowNullNonAdjustment = true });
                factKnownColumns.Add(new FactKnownColumn() { Name = "MAR", DataType = "double", ValidationType = FactKnownColumnValidationType.DoubleData, PeformNullCheckForAdjustment = false, CanAllowNullNonAdjustment = true });
                factKnownColumns.Add(new FactKnownColumn() { Name = "APR", DataType = "double", ValidationType = FactKnownColumnValidationType.DoubleData, PeformNullCheckForAdjustment = false, CanAllowNullNonAdjustment = true });
                factKnownColumns.Add(new FactKnownColumn() { Name = "MAY", DataType = "double", ValidationType = FactKnownColumnValidationType.DoubleData, PeformNullCheckForAdjustment = false, CanAllowNullNonAdjustment = true });
                factKnownColumns.Add(new FactKnownColumn() { Name = "JUN", DataType = "double", ValidationType = FactKnownColumnValidationType.DoubleData, PeformNullCheckForAdjustment = false, CanAllowNullNonAdjustment = true });
                factKnownColumns.Add(new FactKnownColumn() { Name = "JUL", DataType = "double", ValidationType = FactKnownColumnValidationType.DoubleData, PeformNullCheckForAdjustment = false, CanAllowNullNonAdjustment = true });
                factKnownColumns.Add(new FactKnownColumn() { Name = "AUG", DataType = "double", ValidationType = FactKnownColumnValidationType.DoubleData, PeformNullCheckForAdjustment = false, CanAllowNullNonAdjustment = true });
                factKnownColumns.Add(new FactKnownColumn() { Name = "SEP", DataType = "double", ValidationType = FactKnownColumnValidationType.DoubleData, PeformNullCheckForAdjustment = false, CanAllowNullNonAdjustment = true });
                factKnownColumns.Add(new FactKnownColumn() { Name = "OCT", DataType = "double", ValidationType = FactKnownColumnValidationType.DoubleData, PeformNullCheckForAdjustment = false, CanAllowNullNonAdjustment = true });
                factKnownColumns.Add(new FactKnownColumn() { Name = "NOV", DataType = "double", ValidationType = FactKnownColumnValidationType.DoubleData, PeformNullCheckForAdjustment = false, CanAllowNullNonAdjustment = true });
                factKnownColumns.Add(new FactKnownColumn() { Name = "DEC", DataType = "double", ValidationType = FactKnownColumnValidationType.DoubleData, PeformNullCheckForAdjustment = false, CanAllowNullNonAdjustment = true });
            }
            else
            {
                factKnownColumns.Add(new FactKnownColumn() { Name = "PERIOD", DataType = "int", ValidationType = FactKnownColumnValidationType.IntData, PeformNullCheckForAdjustment = false, CanAllowNullNonAdjustment = false });
                factKnownColumns.Add(new FactKnownColumn() { Name = "AMOUNT", DataType = "double", ValidationType = FactKnownColumnValidationType.DoubleData, PeformNullCheckForAdjustment = true, CanAllowNullNonAdjustment = false });
            }

            return factKnownColumns.ToArray();
        }

    }
}
