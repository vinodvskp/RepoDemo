﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables
{
    [DataContract]
    public class FactTableDownloadRequest
    {
        [DataMember]
        public long FactTableId { get; set; }
        [DataMember]
        public long FileTypeCodeId{ get; set; }
        [DataMember]
        public string StartPeriod { get; set; }
        [DataMember]
        public string EndPeriod { get; set; }
        [DataMember]
        public string SignedUrl { get; set; }
        [DataMember]
        public string RunStatusId { get; set; }
    }
}
