﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables
{
    [DataContract]
    public class KeyComboDeleteRequest:FileTypeRequest
    {
        [Serializable]
        public enum DeleteOptions
        {
            Selected = 0,
            All = 1
        }

        [DataMember]
        public DeleteOptions DeleteOption { get; set; }
        [DataMember]
        public string[] DeleteRecords{ get; set; }
    
    }  
}
