﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables
{
    [DataContract]
    public class FileTypeDimension : FactDimension
    {
        //[DataMember]
        //public long? Id {get;set;}
        [DataMember]
        public FileTypeDimensionDataSource SelectedDataSource { get; set; }

        /// <summary>
        /// Used to carry the value for search criteria
        /// </summary>
        [DataMember]
        public string UserValue { get; set; }
    }
}
