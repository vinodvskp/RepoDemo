﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables
{
    public class FactDimensionDataSource : FileTypeDimensionDataSource
    {
        [DataMember]
        public String Description { get; set; }
    }
}
