﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables
{
    [DataContract]
    public class FactFileType
    {
        [DataMember]
        public long? FileTypeCodeId { get; set; }
        [DataMember]
        public long FactTableId { get; set; }
        [DataMember]
        public string Code { get; set; }
        [DataMember]
        public string Description { get; set; }
        [DataMember]
        public string ScheduledLoadDate { get; set; }
        [DataMember]
        public bool IsUserFeed { get; set; }
        [DataMember]
        public bool IsAdjustment { get; set; }
        [DataMember]
        public bool IsOutlook { get; set; }
        [DataMember]
        public bool Contains13ColFacts { get; set; }
        [DataMember]
        public bool UsesValidKeyCombo { get; set; }
        [DataMember]
        public String DestTable { get; set; }
        [DataMember]
        public bool ShowStatus { get; set; }
        [DataMember]
        public FileTypeDimension[] FileTypeDimensions { get; set; }
        [DataMember]
        public CustomFieldValue[] FileTypeCustomFields { get;set;}
        [DataMember]
        public string LastLoadedDate { get; set; }
        [DataMember]
        public string LastLoadedBy { get; set; }  
        [DataMember]
        public FactTableKnownValues.FactTableType FactTableType { get; set; }
    }
}
