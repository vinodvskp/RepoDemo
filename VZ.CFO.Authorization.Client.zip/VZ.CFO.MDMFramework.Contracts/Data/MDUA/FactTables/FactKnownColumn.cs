﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables
{
    [DataContract]
    public class FactKnownColumn
    {
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public FactTableKnownValues.FactKnownColumnValidationType ValidationType { get; set; }
        [DataMember]
        public string DataType { get; set; }
        [DataMember]
        public bool CanAllowNullNonAdjustment { get; set; }
        [DataMember]
        public bool PeformNullCheckForAdjustment { get; set; }
    }
}
