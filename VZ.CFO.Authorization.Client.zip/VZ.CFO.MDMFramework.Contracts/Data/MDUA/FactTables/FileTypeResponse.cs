﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables
{
    [DataContract]
    public class FileTypeResponse
    {
        [DataMember]
        public int Status { get; set; }
        [DataMember]
        public string Message { get; set; }
        [DataMember]
        public long? FileTypeCodeId { get; set; }
    }
}
