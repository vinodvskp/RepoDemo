﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using VZ.CFO.MDMFramework.Contracts.Data;
namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables
{
    [DataContract]
    public class KeyComboRequest: FileTypeRequest
    {
        [DataMember]
        public Paging PagingInfo { get; set; }
    }
}
