﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA
{
    public enum AccessObjectType
    {
        MappingTables = 1,
        VersionManagement = 2
    }
    [Serializable]
    public enum EspJobStatusState
    {
        Unknown = 0,
        AppNotDefined = 1,
        NoMatchingAppOrUnAuthorized = 2,
        IsInvalidAppSpec = 3,
        Completed = 4,
        InCompleteDependentJobs = 5,
        ResponseInBadFormat = 6,
        NoPriorHistory = 7
        //Running,
        //CompletedSuccessfully,
        //Failed,
        //OnHold,
        //Waiting
    }

    public enum EspLapCommandStatus
    {
        ALL,
        INCOMPLETE,
        JOBS,
        JOB
    }

    [Serializable]
    public enum PortalUserRole
    {
        None = 0,
        ReadOnly = 1,
        User = 3,
        Administrator = 9
    }

    [Serializable]
    public enum UserToolLogLevel : short 
    { 
        FatalError = 1, 
        Error = 3, 
        Message = 5, 
        Audit = 7, 
        Debug = 9    
    }

    [Serializable]
    public enum ExportUserType
    {
        None = 0,
        UsersView = 1,
        UserAccessView = 2
    }
}
