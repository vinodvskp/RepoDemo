﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA.ODJobs;

namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA.User
{
    [DataContract]
    public class LegacyUserAccess
    {
        [DataMember]
        public string EmployeeId { get; set; }
        [DataMember]
        public FactFileType[] FactFileTypes  { get; set; }
        [DataMember]
        public ODJob[] ODJobs { get; set; }
        [DataMember]
        public UserInfo UserInformation { get; set; }
    }
}
