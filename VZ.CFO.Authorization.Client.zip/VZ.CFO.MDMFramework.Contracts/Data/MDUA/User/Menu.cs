﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA
{
    [DataContract]
    public class Menu
    {
        [DataMember]
        public string Id { get; set; }
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public bool IsClickable { get; set; }
        [DataMember]
        public bool IsEnabled { get; set; }
        [DataMember]
        public Menu[] SubMenus { get; set; }
        [DataMember]
        public bool CanDisplay { get; set; }
        [DataMember]
        public VZ.CFO.MDMFramework.Contracts.Data.Security.Claim[] RequiredClaims { get; set; }
        [DataMember]
        public string RelativePath { get; set; }
    }
}
