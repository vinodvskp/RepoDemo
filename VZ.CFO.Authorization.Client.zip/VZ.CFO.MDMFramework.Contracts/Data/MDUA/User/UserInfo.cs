﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA
{
    [DataContract]
    public class UserInfo
    {
        [DataMember]
        public string EmployeeId { get; set; }
        [DataMember]
        public string FirstName{ get; set; }
        [DataMember]
        public string LastName { get; set; }
        [DataMember]
        public string Email { get; set; }
        [DataMember]
        public string UserId { get; set; }
        [DataMember]
        public bool Active { get; set; }
        [DataMember]
        public PortalUserRole UserRole { get; set; }
        [DataMember]
        public string UserAccess { get; set; }

        [DataMember]
        public bool CanAddNewFileKeys { get; set; }//ADFK
        [DataMember]
        public bool CanPostAdjImm { get; set; }//ADJN
        [DataMember]
        public bool CanPostAdjAnyPeriod { get; set; }//POAP
        [DataMember]
        public bool CanAssignFileTypesForUser { get; set; }//ASFT
        [DataMember]
        public bool CanAssignODJ { get; set; }//ASAO
        [DataMember]
        public bool CanAddNewFileTypes { get; set; }//ADFT
        [DataMember]
        public bool CanModifyOutline { get; set; }//MDOL
        [DataMember]
        public bool CanProcessCPGA { get; set; }//CPGA
        [DataMember]
        public bool CanPostUserFeedsForPrevPer { get; set; }//PFAP
    }
}


