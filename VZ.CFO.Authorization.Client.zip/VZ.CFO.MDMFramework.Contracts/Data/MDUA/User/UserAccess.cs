﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA
{
    [DataContract]
    public class UserAccess
    {
        [DataMember]
        public string AccessObjectType { get; set; }
        [DataMember]
        public int AccessObjectId { get; set; }
        [DataMember]
        public string[] AccessType { get; set; }
        [DataMember]
        public string AccessObjectName { get; set; }
    }
}
