﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA.ODJobs
{
    public class KnownValues
    {
        [Serializable]
        public enum ODParamType
        {
            None = 0,
            Freetext = 1,
            Lookup = 2,
            CascadingLookup = 3
        }
    }
}
