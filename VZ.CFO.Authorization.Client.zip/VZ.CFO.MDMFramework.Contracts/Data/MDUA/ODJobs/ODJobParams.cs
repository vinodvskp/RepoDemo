﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA.ODJobs
{
    [DataContract]
    public class ODJobParams
    {
        [DataMember]
        public long Id { get; set; }
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public KnownValues.ODParamType ParamType { get; set; }
        [DataMember]
        public string LookupQuery { get; set; }
        [DataMember]
        public ODJobParamValue[] ParamValues { get; set; }
        [DataMember]
        public ODJobParams[] AssociatedParams { get; set; }
    }
}
