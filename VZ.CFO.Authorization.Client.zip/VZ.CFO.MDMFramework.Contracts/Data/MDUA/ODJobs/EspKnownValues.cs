﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA.ODJobs
{
    public class EspKnownValues
    {
        public static class EspInfoStatus
        {
            //used in Request
            public static readonly string Request = "req";
            /// Request successful
            public static readonly string Success ="succ";
            /// Request failed
            public static readonly string Failure = "fail";
            /// Request successful but it produced a warning
            public static readonly string Warning = "warn";
            /// Request format is invalid
            public static readonly string Invalid ="inv";
        }

        public static class EspInfoCont
        {
            public static readonly string EOM = "eom";
            public static readonly string More = "more";
        }

        public static class EspInfoType
        {
            public static readonly string Command = "command";
        }

        public static class EspJobResponse
        {
            public static readonly string AppNotDefined = "ESPWSS1141W";
            public static readonly string NoMatchingAppOrUnAuthorized = "ESPWSS1142W";
            public static readonly string InValidAppSpec = "ESPWSS1824E";
            public static readonly string Appl = "APPL";
            public static readonly string Generation = "GEN ";
            public static readonly string Complete = "COMPLETE";
            public static readonly string CreatedAt = "CREATED AT ";
            public static readonly string EndedAt = "ENDED AT ";
            public static readonly string AnticipatedEndTime = "ANTICIPATED END TIME: ";
            public static readonly string AnticipatedEndTimeNotAvailable = "Not Available";
            public static readonly string EspDateTimeFormatSingleDigitDay = "HH.mm dddd MMMM d yyyy";
            public static readonly string EspDateTimeFormatDoubleDigitDay = "HH.mm dddd MMMM dd yyyy";
            public static readonly string CompletedJobs = "COMPLETED JOBS:";
            public static readonly string CompletedJobsNone = "(NONE)";
            public static readonly string InCompleteJobs = "INCOMPLETE JOBS:";
        }
        

        public static class EspJobRequest
        {
            public static readonly string EspStatusRequestFormat = "{0} {1}{2} {3}";//LAP EU9#TST5.0 ALL
            public static readonly string EspSubApplStatusRequestFormat = "{0} {1}{2} SUBAPPL({3}) {4}";//LAP EU9#TST5.0 SUBAPPL(SUBAPPL1) ALL
            public static readonly string EspTriggerReqtFmtParentApp = "{0} {1}.{2} ADD CS {3}";//TRIGGER EU9TST.EU9#TST5 ADD USER1('valueforuser1') CS
            public static readonly string EspTriggerReqParamFmt = "USER{0}('{1}')";
            public static readonly string EspTriggerReqFmtChildApp = "{0} {1}.{2} SUBAPPL({3}) ADD CS {4}";//TRIGGER EU9TST.EU9#TST5 SUBAPPL(SUBAPPL1) ADD USER1('valueforuser1') CS
            public static readonly string EspStatusCommand = "LAP";
            public static readonly string EspTriggerCommand = "TRIGGER";
            
        }
    }
}
