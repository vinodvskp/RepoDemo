﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA.ODJobs
{
    [DataContract]
    public class EspJobStatus
    {
        [DataMember]
        public string Generation { get; set; }
        [DataMember]
        public EspJobStatusState Status { get; set; }
        [DataMember]
        public string StartedOn { get; set; }
        [DataMember]
        public string EndedOn { get; set; }
        [DataMember]
        public string AnticipatedEndOn { get; set; }
        [DataMember]
        public string CompletedJobs { get; set; }
        [DataMember]
        public string InCompleteJobs { get; set; }
        [DataMember]
        public string ElapsedTime { get; set; }
        [DataMember]
        public string TimeZone { get; set; }
        [DataMember]
        public string Error { get; set; }
    }
}
