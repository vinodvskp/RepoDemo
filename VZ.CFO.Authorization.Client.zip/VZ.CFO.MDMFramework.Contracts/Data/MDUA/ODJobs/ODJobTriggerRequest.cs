﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA.ODJobs
{
    [DataContract]
    public class ODJobTriggerRequest
    {
        [DataMember]
        public long JobId   { get; set; }
        [DataMember]
        public string[] JobParams { get; set; }
    }
}
