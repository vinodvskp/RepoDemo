﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA.ODJobs
{
    [DataContract]
    public class ODJob
    {
        [DataMember]
        public long Id { get; set; }
        [DataMember]
        public long EspxJobId { get; set; }
        [DataMember]
        public long JobGroupId { get; set; }
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string SubApplicationName { get; set; }
        [DataMember]
        public string Description { get; set; }
        [DataMember]
        public ODJobParams[] Parameters { get; set; }
        [DataMember]
        public string UserFriendlyName { get; set; }
        [DataMember]
        public string Event { get; set; }
        [DataMember]
        public DateTime CreatedOn { get; set; }
        [DataMember]
        public DateTime ModifiedOn { get; set; }
    }
}
