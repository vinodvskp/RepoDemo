﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA.FileTransfer
{
    [DataContract]
    public class FileTransferRequest
    {
        [DataMember]
        public long ProfileId { get; set; }
        [DataMember]
        public string FileBase64String { get; set; }
        [DataMember]
        public string FileName { get; set; }
        [DataMember]
        public string UserId { get; set; }
        [DataMember]
        public byte[] File { get; set; }
        [DataMember]
        public FileTransferKnownValues.FileTransferRequestType RequestType { get;  set;}
        [DataMember]
        public string FilePath { get; set; }
    }
}
