﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA.FileTransfer
{
    [Serializable]
    public class FileTransferKnownValues
    {
        [Serializable]
        public enum FileTransferType
        {
            SFTP = 0
        }

        [Serializable]
        public enum MessageTypes
        {
            Success = 0,
            Error = 1,
            Fatal = 2
        }

        [Serializable]
        public enum FileTransferRequestType
        {
            Upload = 0,
            Download = 1,
            FolderListing = 2,
            Delete = 3,
            Rename = 4
        }
    }
}
