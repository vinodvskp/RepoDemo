﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA.FileTransfer
{
    [DataContract]
    public class FileTransferFileInfo
    {
        [DataMember]
        public char FileType { get; set; }  // - for reulgar file, D for directory, L for symbolic link

        [DataMember]
        public string Path { get; set; }

        [DataMember]
        public string FullName { get; set; }

        [DataMember]
        public string Name { get; set; }

        [DataMember]
        public long Length { get; set; }

        [DataMember]
        public bool IsDirectory { get; set; }

        [DataMember]
        public String LastModifiedTime { get; set; }

        [DataMember]
        public List<FileTransferFileInfo> Files { get; set; }

        [DataMember]
        public String TimeZone { get; set; }

        [DataMember]
        public string Oldpath { get; set; }
        [DataMember]
        public string Oldname { get; set; }
        [DataMember]
        public string Oldfullname { get; set; }
    }
}
