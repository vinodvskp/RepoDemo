﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA.FileTransfer
{
    [DataContract]
    public class FileTransferProfile
    {
        const long MB = 1024 * 1024;
        const long GB = 1024 * 1024 * 1024;

        [DataMember]
        public long ProfileId { get; set; }
        [DataMember]
        public string ProfileName { get; set; }
        [DataMember]
        public string DefaultFileName { get; set; }
        [DataMember]
        public FileTransferKnownValues.FileTransferType TransferType { get; set; }
        [DataMember]
        public string TargetDirectory { get; set; }

        private long _uploadLimit = 500 * MB;
        [DataMember]
        public long UploadLimit
        {
            get { return _uploadLimit; }
            set { _uploadLimit = value; }
        }

        private long _downloadLimit = 2 * GB;
        [DataMember]
        public long DownloadLimit 
        { 
            get { return _downloadLimit; }
            set { _downloadLimit = value; }
        }

        public long DownLoadLimitInGB
        {
            get { return _downloadLimit / GB; }
        }

        public long UploadLimitInMB
        {
            get { return _uploadLimit / MB;  }
        }
        [DataMember]
        public int DestinationOsType { get; set; }  // 0: linux, 1: windows

        [DataMember]
        public string Filter { get; set; }

        [DataMember]
        public int Permission { get; set; } // 0 means only browse, 1 means download only, 2 means upload only, 3 means both download & upload
    }
}
