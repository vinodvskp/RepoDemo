﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.MDUA.FileTransfer
{
    [DataContract]
    public class FileTransferResponse
    {
        [DataMember]
        public FileTransferKnownValues.MessageTypes MessageType { get; set; }
        [DataMember]
        public string Message { get; set; }

        [DataMember]
        public FileTransferFileInfo Folder { get; set; }

        [DataMember]
        public bool ActionStatus { get; set; }

        public String DownLoadLocation { get; set; }
    }
}
