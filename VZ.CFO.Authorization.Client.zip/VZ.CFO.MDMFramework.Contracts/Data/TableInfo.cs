﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data
{
    public class TableInfo:TableValues
    {
        public long TableId { get; set; }
        public string TableName { get; set; }
        public string[] Columns { get; set; }
        public string[] ColumnHeaders { get; set; }
        public int RowsPerPage { get; set; }
        public int TotalPages {
            get
            {
                return (int)Math.Ceiling(Convert.ToDecimal(TotalRows) / Convert.ToDecimal(RowsPerPage));
            }
        }
        public int TotalRows{  get;set; }
        public string PagingQueryTemplate{ get; set; }
        public string WhereCause { get; set; }
        public string ConnectionString { get; set; }

    }
}
