﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data
{
    [DataContract]
    public class PagingInfo
    {
        [DataMember]
        public int PageNumber { get; set; }
        [DataMember]
        public int TotalPages { get; set; }
        [DataMember]
        public int TotalResults { get; set; }
    }
}
