﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA;

namespace VZ.CFO.MDMFramework.Contracts.Data
{
    [DataContract]
    public class AuditInfo
    {
        [DataMember]
        public string EmployeeId { get; set; }
        [DataMember]
        public string Location { get; set; }
        [DataMember]
        public string Action { get; set; }
        [DataMember]
        public string Status { get; set; }
        [DataMember]
        public UserToolLogLevel LogLevel { get; set; }
    }
}
