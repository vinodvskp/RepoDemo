﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
namespace VZ.CFO.MDMFramework.Contracts.Data
{
    [DataContract]
    public class TableValuesPage:Paging
    {
        [DataMember]
        public ColumnData[] Data { get; set; }
       
    }
}
