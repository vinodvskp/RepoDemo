﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.PushNotification
{
    public class PushNotificationCallback
    {
        public event EventHandler<PushNotificationEventArgs> ItemChangedHandler = delegate { };

        public void NotifyItemChanged(PushNotification[] pushNotificationlist)
        {
            PushNotificationEventArgs pnea = new PushNotificationEventArgs() { PushNotifications = pushNotificationlist };
            this.ItemChangedHandler(this, pnea);
        }
    }
}
