﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.PushNotification
{
    [DataContract]
    public class PushNotificationClientInfo
    {
        [DataMember]
        public string ClientId { get; set; }
        [DataMember]
        public string ApplicationName { get; set; }
        [DataMember]
        public string ApplicationModuleName { get; set; }

    }
}
