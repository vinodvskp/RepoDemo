﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.PushNotification
{
    [DataContract]
    public class PushNotification : PushNotificationClientInfo
    {
        [DataMember]
        public long NotificationId { get; set; }

        [DataMember]
        public string ChangeContext { get; set; }
        [DataMember]
        public DateTime LastUpdatedOn { get; set; }
        [DataMember]
        public string LastUpdatedBy { get; set; }
    }
}
