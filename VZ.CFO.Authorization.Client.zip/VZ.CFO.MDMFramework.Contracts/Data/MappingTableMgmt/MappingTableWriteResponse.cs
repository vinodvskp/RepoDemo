﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.MappingTableMgmt
{
    [DataContract]
    public class MappingTableWriteResponse
    {
        [DataMember]
        public long MappingTableId { get; set; }
        [DataMember]
        public MappingColumnValues[] ValidationResults { get; set; }
        [DataMember]
        public int RowsDeleted { get; set; }
        [DataMember]
        public int RowsMerged { get; set; }
        [DataMember]
        public string Message { get; set; }
        [DataMember]
        public KnownValues.MappingTableWriteResponseMsgType MessageType { get; set; }
        [DataMember]
        public int MessageCode { get; set; }
    }
}
