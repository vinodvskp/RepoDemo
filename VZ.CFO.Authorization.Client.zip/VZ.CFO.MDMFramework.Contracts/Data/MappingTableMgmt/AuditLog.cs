﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.MappingTableMgmt
{
    [DataContract]
    public class AuditLog
    {
        [DataMember]
        public long Id { get; set; }
        [DataMember]
        public long MappingTableId { get; set; }
        [DataMember]
        public string Action { get; set; }
        [DataMember]
        public string ActionBy { get; set; }
        [DataMember]
        public DateTime ActionOn { get; set; }
        [DataMember]
        public string OldValue { get; set; }
        [DataMember]
        public string NewValue { get; set; }
        [DataMember]
        public KnownValues.AuditType AuditType { get; set; }
        [DataMember]
        public bool IsDataValidated { get; set; }
        [DataMember]
        public bool IsValidationOverridden { get; set; }
    }
}
