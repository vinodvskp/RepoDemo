﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.MappingTableMgmt
{
    public class ValidationInfo
    {
        public KnownValues.MappingTableValidationType ValidationType { get; set; }
        public string Name { get; set; }
        public string[] Parameters { get; set; }
    }
}
