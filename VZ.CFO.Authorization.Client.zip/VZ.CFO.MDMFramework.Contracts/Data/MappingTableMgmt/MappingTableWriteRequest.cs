﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.MappingTableMgmt
{
    [DataContract]
    public class MappingTableWriteRequest
    {
        [DataMember]
        public long MappingTableId { get; set; }
        [DataMember]
        public MappingColumnValues[] AddRecords { get; set; }
        [DataMember]
        public MappingColumnValues[] ModifiedRecords { get; set; }
        [DataMember]
        public string[] DeletedRecords { get; set; }
        [DataMember]
        public bool IsForceSave { get; set; }
        [DataMember]
        public long RunStatusId { get; set; }
        [DataMember]
        public KnownValues.RequestType RequestType { get; set; }
    }
}