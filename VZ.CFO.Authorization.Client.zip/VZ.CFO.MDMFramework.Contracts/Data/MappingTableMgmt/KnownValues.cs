﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.MappingTableMgmt
{
    [Serializable]
    public class KnownValues
    {
        [Serializable]
        public enum MappingTableValidationType
        {
            None = 0,
            SPROC = 1
        }

        [Serializable]
        public enum MigrationDependencyType
        {
            None = 0,
            ESPX = 1
        }

        [Serializable]
        public enum RoleType
        {
            None = 0,
            READ = 1,
            EDIT = 2,
            MIGRATE = 3
        }

        [Serializable]
        public enum AuditType
        {
            None = 0,
            DATA = 1,
            TABLE = 2
        }
        
        [Serializable]
        public enum RequestType
        {
            None = 0,
            EDIT = 1,
            MIGRATE = 2
        }

        [Serializable]
        public enum MappingTableWriteResponseMsgType
        { 
            None = 0,
            Error = 1,
            Success = 2
        }

        public const string StageChangeTypeAdd = "A";
        public const string StageChangeTypeModify = "M";
        public const string StageChangeTypeDelete = "D";
    }
}
