﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.MappingTableMgmt
{
    [DataContract]
    public class MappingTableDataPage : PagingInfo
    {
        [DataMember]
        public MappingColumnValues[] Result { get; set; }
    }
}
