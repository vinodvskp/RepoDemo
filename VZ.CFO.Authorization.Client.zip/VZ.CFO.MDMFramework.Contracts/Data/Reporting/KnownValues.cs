﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.Reporting
{
    [Serializable]
    public class KnownValues
    {
        [Serializable]
        public enum PaginationType
        {
            None = 0,
            Client = 1,
            Server = 2
        }

        [Serializable]
        public enum ReportType
        {
            None = 0,
            FlatTable = 1,
            PivotTable = 2,
            Charts = 3
        }

        [Serializable]
        public enum RepositoryType
        {
            NONE,
            ORCL,
            ODATA,
            MSSQL,
            TERADATA
        }

        [Serializable]
        public enum FieldAxis
        {
            NONE = 0,
            XAXIS = 1,
            YAXIS = 2            
        }
    }
}
