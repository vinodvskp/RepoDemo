﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.Reporting
{
    [DataContract]
    public class CustomMessage
    {
        [DataMember]
        public string Event { get; set; }
        [DataMember]
        public string Message { get; set; }
    }
}
