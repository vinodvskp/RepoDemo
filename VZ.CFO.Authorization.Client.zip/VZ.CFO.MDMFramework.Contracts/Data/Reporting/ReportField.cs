﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.Reporting
{
    [DataContract]
    public class ReportField
    {
        [DataMember]
        public string DisplayName { get; set; }
        [DataMember]
        public string PhysicalName { get; set; }
        [DataMember]
        public KnownValues.FieldAxis FieldAxis { get; set; }
        [DataMember]
        public bool IsAggreationField { get; set; }
    }
}
