﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.Reporting
{
    [DataContract]
    public class Report
    {
        [DataMember]
        public long Id { get; set; }
        [DataMember]
        public string DisplayName { get; set; }
        [DataMember]
        public string ObjectName { get; set; }
        [DataMember]
        public string Description { get; set; }
        [DataMember]
        public ReportField[] Columns {get; set;}
        [DataMember]
        public Repository Respository { get; set; }
        [DataMember]
        public string CreatedBy { get; set; }
        [DataMember]
        public string LastModifiedBy { get; set; }
        [DataMember]
        public KnownValues.ReportType ReportType { get; set; }
        [DataMember]
        public KnownValues.PaginationType PagingType { get; set; }
        [DataMember]
        public string FilterClause { get; set; }
        [DataMember]
        public CustomMessage[] CustomMessages { get; set; }
        [DataMember]
        public DateTime? CreatedOn { get; set; }
        [DataMember]
        public DateTime? LastModifiedOn { get; set; }
    }
}
