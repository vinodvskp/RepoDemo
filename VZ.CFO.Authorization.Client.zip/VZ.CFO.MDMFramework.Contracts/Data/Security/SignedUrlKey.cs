﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Data.Security
{
    [DataContract]
    public class SignedUrlKey
    {
        [DataMember]
        public DateTime ExpiresOn { get; set; }
        [DataMember]
        public string SignedForUser { get; set; }
        [DataMember]
        public string SignedForContent { get; set; }
    }
}
