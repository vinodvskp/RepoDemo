﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Service.MappingTableMgmt
{
    /// <summary>
    /// Interface for mapping table business logic and data layer methods
    /// </summary>
    public interface IMappingTableManager
    {
        /// <summary>
        /// Get all mapping tables registered with the framework that the user has access to
        /// Does not fetch the table data and audit details
        /// </summary>
        /// <returns>Get all mapping tables registered with the framework that the user has access to</returns>
        Data.MappingTableMgmt.MappingTable[] GetAllMappingTables(string userId);
        /// <summary>
        /// Get specific mapping table registered with the framework that the user has access to
        /// Does not fetch the table data and audit details
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        Data.MappingTableMgmt.MappingTable GetMappingTableInfo(string userId, long mappingTableId);
        /// <summary>
        /// Gets mapping table data for a specific page
        /// </summary>
        /// <param name="User Id">User Id of the user requesting the operation</param>
        /// <param name="mappingTableId">Mapping Table Id</param>
        /// <param name="pageNumber">Specific page for which the data is fetched for</param>
        /// <param name="rowsPerPage">Number of rows per page</param>
        /// <param name="totalRecords">Total number records in the table. 0 if unknown.</param>
        /// <returns>Gets mapping table data for a specific page</returns>
        Task<Data.MappingTableMgmt.MappingTableDataPage> GetMappingTableAsync(string userId, long mappingTableId, int pageNumber, int rowsPerPage, int totalRecords);
        Data.MappingTableMgmt.MappingTableDataPage GetMappingTable(string userId, long mappingTableId, int pageNumber, int rowsPerPage, int totalRecords);
        Task<Data.MappingTableMgmt.MappingTableDataPage> GetMappingTableFromLowerEnvAsync(string userId, long mappingTableId, int pageNumber, int rowsPerPage, int totalRecords);
        Data.MappingTableMgmt.MappingTableDataPage GetMappingTableFromLowerEnv(string userId, long mappingTableId, int pageNumber, int rowsPerPage, int totalRecords);
        Data.MappingTableMgmt.MappingTable GetMappingTableFromLowerEnv(string userId, long id, int rowsPerPage);
        /// <summary>
        /// Get MappingTable data for the id
        /// This will return the first page of the data along with MappingTableDataPage property
        /// </summary>
        /// <param name="User Id">User Id of the user requesting the operation</param>
        /// <param name="id">Mapping Table Id</param>
        /// <returns>MappingTable with first page of the data along with MappingTableDataPage property</returns>
        Data.MappingTableMgmt.MappingTable GetMappingTable(string userId, long id, int rowsPerPage);
        /// <summary>
        /// Saves the mapping table data. This will only save the delta. Optionally validates
        /// TODO: Do we need another flag for checking the migration dependency?
        /// </summary>
        /// <param name="User Id">User Id of the user requesting the operation</param>
        /// <param name="mappingTable">Delta mapping table data</param>
        /// <param name="isForceSave">flag to skip validations</param>
        /// <returns>Boolean with success or failure</returns>
        Data.MappingTableMgmt.MappingTableWriteResponse SaveMappingTableData(string userId, Data.MappingTableMgmt.MappingTableWriteRequest writeRequest);
        /// <summary>
        /// Performs Validation
        /// TODO: Do we need paging here?
        /// </summary>
        /// <param name="User Id">User Id of the user requesting the operation</param>
        /// <param name="mappingTable">Delta mapping table data</param>
        /// <returns>Returns the data that failed validation with the first column representing row specific validation message</returns>
        Data.MappingTableMgmt.MappingTableWriteResponse ValidationMappingTableData(string userId, Data.MappingTableMgmt.MappingTableWriteRequest writeRequest);
        /// <summary>
        /// Gets audit logs for a specific mapping table and page
        /// </summary>
        /// <param name="User Id">User Id of the user requesting the operation</param>
        /// <param name="mappingTableId">Mapping Table Id</param>
        /// <param name="pageNumber">Specific page for which the data is fetched for</param>
        /// <param name="rowsPerPage">Number of rows per page</param>
        /// <param name="totalRecords">Total number records in the table. 0 if unknown.</param>
        /// <returns></returns>
        Data.MappingTableMgmt.AuditLogPage GetAuditDataPage(string userId, long mappingTableId, Data.MappingTableMgmt.KnownValues.AuditType auditType, int pageNumber, int rowsPerPage, int totalRecords, string searchKey);
        /// <summary>
        /// Get Audit Data for a specific mapping Table Id
        /// This will return the first page of the audit log
        /// </summary>
        /// <param name="User Id">User Id of the user requesting the operation</param>
        /// <param name="mappingTableId"></param>
        /// <returns></returns>
        Data.MappingTableMgmt.AuditLogPage GetAuditData(string userId, long mappingTableId, Data.MappingTableMgmt.KnownValues.AuditType auditType, int rowsPerPage, string searchKey);
        /// <summary>
        /// Method to Migrate data from change control environment
        /// </summary>
        /// <param name="User Id">User Id of the user requesting the operation</param>
        /// <param name="mappingTableId">Mapping Table Id</param>
        /// <returns>Flag to denote if the migration is success or failure</returns>
        Data.MappingTableMgmt.MappingTableWriteResponse MigrateMappingValues(string userId, Data.MappingTableMgmt.MappingTableWriteRequest writeRequest);
        Task<string> ExportMappingTable(string userId, long mappingTableId);
    }
}
