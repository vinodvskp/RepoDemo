﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Data.Security;
namespace VZ.CFO.MDMFramework.Contracts.Service
{
    public interface ISecurityManager
    {
        string GetSignedUrlKey(string userId, string content);
        string VerifySignedUrlKey(string content, string key);
        string GetContentFromSignedUrl(string userId, string signedUrl);
    }
}
