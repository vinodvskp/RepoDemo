﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Service.PushNotification
{
    public interface IPushNotificationService
    {
        bool IsRunning();

        void StartService();
        void StopService();
        string ClientSubscription(string clientId, string appName, string appModule);
        bool ClientUnSubscribe(string clientId);
        Data.PushNotification.PushNotificationCallback GetPushNotificationCallbackRef();
    }
}
