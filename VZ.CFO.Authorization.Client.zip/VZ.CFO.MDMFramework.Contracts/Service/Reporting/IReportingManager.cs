﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Data.Reporting;
namespace VZ.CFO.MDMFramework.Contracts.Service.Reporting
{
    public interface IReportingManager
    {
        ReportGroup[] GetReports(string userId);        
        //Report[] GetReports(string userId);
        ReportGroup GetReportsByGroupId(string userId, long groupId);
        Report GetReport(string userId, long reportId);
        Task<ReportingResponse> GetReportDataAsync(string userId, long reportId);
        Task<ReportingResponse> GetReportDataAsync(string userId, long reportId, int pageNumber, int rowsPerPage, int totalRecords);
        Task<string> ExportReport(string userId, long reportId);
    }
}
