﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Data;
namespace VZ.CFO.MDMFramework.Contracts.Service
{
    public interface IExportTableManager
    {
        Task<string> ExportTable(string userId,TableInfo tableInfo);
        string GetSignedUrlKey(string userId, string content);
        string VerifySignedUrlKey(string content, string signedUrl);
    }
}
