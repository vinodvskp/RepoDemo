﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Contracts.Service
{
    public interface ILogManager
    {
        void LogMessage(string module, string message);
        void LogException(string module, System.Exception ex);
    }
}
