﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables;
using VZ.CFO.MDMFramework.Contracts.Data;
namespace VZ.CFO.MDMFramework.Contracts.Service.MDUA
{
    public interface IFactTableManager
    {
        FactTable[] GetAllFactTables(string userId);
        FactTable GetFactTable(string userId, long factTableId);
        FactFileType[] GetFactFileTypes(string userId, long factTableId);
        FactTable[] GetFactFileTypesBasic(string userId);
        FactFileType GetFactFileType(string userId, FileTypeRequest fileTypeRequest);
        FileTypeResponse SaveFileType(string userId, FactFileType factFileType);
        FileTypeResponse DeleteFileType(string userId, FileTypeRequest fileTypeRequest);
        KeyComboResponse GetKeyCombinations(string userId, KeyComboRequest keyComboRequest);
        KeyComboDeleteResponse DeleteKeyCombinations(string userId, KeyComboDeleteRequest keyComboDeleteRequest);
        KeyComboMoveResponse MoveKeyCombinations(string userId, KeyComboMoveRequest keyComboMoveRequest);
        TableInfo GetTableInfo(string userId, long tableId);
        FactTable GetFactTableBasicInfo(string userId, long tableId);
        FactTableSettings GetFactTableSetting(string userId);
        string GetDbConnectionString(string dbProfileName);
        string GetFileTypeCodeById(long factTableId,long fileTypeCodeId);
        string GetPagingQueryTemplate();

        FactProcessUploadedFileResponse GetAuditData(string userId, FactAuditRequest auditRequest);
        string[] GetDimensionValues(string userId, FactAuditRequest auditRequest);
        FactReportingPeriod GetCurrentPeriod(string userId, long factTableId);
        string ExportAuditData(string userId, FactAuditRequest auditRequest);
    }
}
