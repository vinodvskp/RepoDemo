﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA.FileTransfer;

namespace VZ.CFO.MDMFramework.Contracts.Service.MDUA
{
    public interface IFileTransferManager
    {
        FileTransferProfile[] GetFileTransferProfiles(string userId);

        FileTransferProfile GetFileTransferProfile(string userId, long profileId);

        FileTransferResponse TransferFile(FileTransferRequest fileTransferRequest);
    }
}
