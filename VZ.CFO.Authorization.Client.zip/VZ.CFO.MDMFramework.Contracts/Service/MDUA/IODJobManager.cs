﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA.ODJobs;
namespace VZ.CFO.MDMFramework.Contracts.Service.MDUA
{
    public interface IODJobManager
    {
        ODJobGroup[] GetAllODJobGroups(string userId);
        ODJob[] GetAllODJobs(string userId, long groupId);
        ODJob GetODJob(string userId,long jobId);
        ODJobParamValue[] GetODJobParamValues(string userId, long paramId);
        ODJobParamValue[] GetODJobParamValues(string userId, long paramId, ODJobParamValue[] associatedParamValues);
        EspMessage TriggerODJob(string userId, ODJobTriggerRequest triggerRequest);
        Task<EspJobStatus> GetODJobStatus(string userId, long jobId);
        EspJobStatus GetODJobStatus(string userId, long jobId, long? generation);
        EspJobStatus GetJobStatus(string jobName, string subApplName, string userId, long? generation);
    }
}
