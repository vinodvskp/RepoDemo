﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Data;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA;
using VZ.CFO.MDMFramework.Contracts.Data.Security;
namespace VZ.CFO.MDMFramework.Contracts.Service.MDUA
{
    public interface IUserAccessManager
    {

        Data.MDUA.UserInfo[] GetAllUsers();
        Data.MDUA.UserInfo GetUser(string employeeId);
        Claim[] GetUserAccess(string id, string authenticationSourceType);
        Data.MDUA.UserAccess[] GetUserAccessByEmployeeId(string employeeId);
        Data.MDUA.UserAccess[] GetUserAccessByUserId(string userId);
        Data.MDUA.UserAccess[] GetUserAccessForAccessObjType(string employeeId, string accessObjectType);
        bool SaveUserAccessByEmployeeId(string userId, string employeeId, string accessObjectType, Data.MDUA.UserAccess[] userAccess);
        Data.MDUA.Menu[] GetMenuForUser(System.Security.Claims.Claim[] userClaims);

        Data.MDUA.UserInfo GetUserFromLdap(string vzid);
        bool SaveUserInfo(string userId, Data.MDUA.UserInfo userInfo);
        bool SaveLegacyUserAccess(string userId, Data.MDUA.User.LegacyUserAccess legacyUserAccess);
        bool DeleteUserInfo(string userId, string employeeId);
        Data.MDUA.ODJobs.ODJobGroup[] GetAllODJobs();
        Data.MDUA.ODJobs.ODJobGroup[] GetODJobAccess(string employeeId);
        Data.MDUA.FactTables.FactTable[] GetFactFileTypeAccess(string employeeId);
        Data.MDUA.FactTables.FactTable[] GetAllFactFile();

        Task<string> ExportUsers(string userId, ExportUserType exportType);
        Task<Data.MDUA.UserAccessFlatPage> GetUserAccessFlatAsync(string userId, int pageNumber, int rowsPerPage, int totalRecords);
        Data.MDUA.UserAccessFlatPage GetUserAccessFlat(string userId, string accessObjectType, int pageNumber, int rowsPerPage, int totalRecords);

        Data.GenericResponse RefreshUsersFromADGroup(string employeeId);

        void AuditUser(AuditInfo auditInfo);
        VZ.CFO.MDMFramework.Contracts.Data.MDUA.User.HomepageContent GetHomepageContent(string employeeId);
        bool UpdateHomepageContent(string employeeId, VZ.CFO.MDMFramework.Contracts.Data.MDUA.User.HomepageContent homepageContent);
    }
}
