﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables;

namespace VZ.CFO.MDMFramework.Contracts.Service.MDUA
{
    public interface IFactTableUserUpload
    {
        string UploadFactFile(string userId, string fileTypeName, string base64EncodedFile);
        string UploadFactFileByte(string userId, string fileTypeName, byte[] fileInBytes);
        FactProcessUploadedFileResponse UploadFactData(FactProcessUploadedFileRequest processRequest);
        string[] GetDimYears();
        FactProcessUploadedFileResponse AddKeysFromStagedData(string userId, long runStatusId, long factTableId, long factFileTypeId);
        FactProcessUploadedFileResponse AddKeysAndUploadFact(FactProcessUploadedFileRequest processRequest);
        double GetMaxUploadFileSize();
    }
}
