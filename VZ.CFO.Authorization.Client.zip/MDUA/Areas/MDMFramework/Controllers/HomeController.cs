﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MDUA.Areas.MDMFramework.Controllers
{
    public class HomeController : Controller
    {
        // GET: MDMFramework/Home
        public ActionResult Index()
        {
            ViewBag.ldap_server = ConfigurationManager.AppSettings["ldap_server"].ToString();
            ViewBag.mt_server = ConfigurationManager.AppSettings["mt_server"].ToString();
            ViewBag.vm_server = ConfigurationManager.AppSettings["vm_server"].ToString();
            ViewBag.oauth_host = ConfigurationManager.AppSettings["oauth_host"].ToString();
            ViewBag.site_subfolder = ConfigurationManager.AppSettings["site_subfolder"].ToString();
            ViewBag.notification_type = ConfigurationManager.AppSettings["notification_type"].ToString();
            ViewBag.drm_link = ConfigurationManager.AppSettings["drm_link"].ToString();
            ViewBag.datascoop_server = ConfigurationManager.AppSettings["datascoop_server"].ToString();

            bool canSkipSso = Convert.ToBoolean(ConfigurationManager.AppSettings["skip_sso"].ToString());
            if (canSkipSso)
            {
                ViewBag.login_eid = ConfigurationManager.AppSettings["login_eid"].ToString();
            }
            else if (Request.Headers["EID"] != null)
            {
                ViewBag.login_eid = Request.Headers["EID"].ToString();
            }

            return View();
        }

        public ActionResult Test()
        {
            return View();
        }
    }
}