﻿using System.Web.Mvc;

namespace MDUA.Areas.MDMFramework
{
    public class MDMFrameworkAreaRegistration : AreaRegistration 
    {
        public override string AreaName 
        {
            get 
            {
                return "MDMFramework";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context) 
        {
            context.MapRoute(
                "MDMFramework_default",
                "MDMFramework/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}