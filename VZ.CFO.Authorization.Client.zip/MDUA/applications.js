
/* Application Main Module & Router setting */

(function () {

    var vmApp = angular.module('vmApp', ['ngTouch', 'ui.router', 'common', 'angularSpinners', 'ui.grid', 'ui.grid.edit', 'ui.grid.rowEdit', 'ui.grid.importer', 'ui.grid.resizeColumns', 'ui.grid.selection', 'ui.grid.exporter', 'ui.grid.autoResize', 'ui.bootstrap', 'ui.grid.pagination']);

    var scrollContent = function () {
        $('html, body').animate({ scrollTop: -10000 }, 100);

    };

    vmApp.config(['serverVariableServiceProvider', '$logProvider', '$stateProvider', '$urlRouterProvider', '$httpProvider',

    function (serverVariableServiceProvider, $logProvider, $stateProvider, $urlRouterProvider, $httpProvider) {

        $logProvider.debugEnabled(true);

        $urlRouterProvider.otherwise('/');

        //FRPA-6429 this is required for prevent IE caching issue on get methods
        //initialize get if not there
        if (!$httpProvider.defaults.headers.get) {
            $httpProvider.defaults.headers.get = {};
        }
        //disable IE ajax request caching
        $httpProvider.defaults.headers.get['If-Modified-Since'] = 'Mon, 26 Jul 1997 05:00:00 GMT';
        // extra
        $httpProvider.defaults.headers.get['Cache-Control'] = 'no-cache';
        $httpProvider.defaults.headers.get['Pragma'] = 'no-cache';
        
        $stateProvider

        .state('home', {
            url: '/',
            templateUrl: serverVariableServiceProvider.$get().SITE_SUBFOLDER() + 'vmApp/templates/home.html',
            controller: 'homeController as hc',
            data: { displayName: 'Home' }
        })
        .state('error', {
            url: '/error',
            templateUrl: serverVariableServiceProvider.$get().SITE_SUBFOLDER() + 'vmApp/templates/error.html',
            data: { displayName: 'Error' }
        })
        .state('versionManagement', {
            url: '/selfServe/versionManagement',
            templateUrl: serverVariableServiceProvider.$get().SITE_SUBFOLDER() + 'vmApp/templates/versionmanagment.html',
            controller: 'versionManagementController as vm',
            data: { displayName: 'Version Management' }
        })
        .state('userUploads', {
            url: '/selfServe/userUploadParent/manageFileTypes',
            templateUrl: serverVariableServiceProvider.$get().SITE_SUBFOLDER() + 'mduaApp/templates/userUploads.html',
            controller: 'userUploadsController as uvm',
            data: { displayName: 'Manage File Types' }
        })
        .state('userUploadFeed', {
            url: '/selfServe/userUploadParent/userUpload',
            templateUrl: serverVariableServiceProvider.$get().SITE_SUBFOLDER() + 'mduaApp/templates/userUploadFeed.html',
            controller: 'userUploadFeedController as uufc',
            data: { displayName: 'User Upload' }
        })
		 .state('userUploads.keyComboUpload', {
		     url: '/keyComboUpload/:factTableId/:fileTypeCodeId/:fileTypeUsesValidKeyCombo',
		     templateUrl: serverVariableServiceProvider.$get().SITE_SUBFOLDER() + 'mduaApp/templates/userKeyComboUploadStep.html',
		     controller: 'userKeyComboUploadStepController as uufc',
		     data: { displayName: 'Manage File Types' }
		 })
          .state('userUploadFeed.factDataUpload', {
              url: '/factDataUpload',
              templateUrl: serverVariableServiceProvider.$get().SITE_SUBFOLDER() + 'mduaApp/templates/userFactDataUploadStep.html',
              controller: 'userFactDataUploadStepController as uufc',
              data: { displayName: 'User Upload' }
          })
            .state('userUploadFeed.keyComboUpload', {
                url: '/keyComboUpload/:factTableId/:fileTypeCodeId/:fileTypeUsesValidKeyCombo',
                templateUrl: serverVariableServiceProvider.$get().SITE_SUBFOLDER() + 'mduaApp/templates/userKeyComboUploadStep.html',
                controller: 'userKeyComboUploadStepController as uufc',
                data: { displayName: 'User Upload' }
            })
	     .state('dashboard', {
	         url: '/selfServe/versionManagement/dashboard',
	         templateUrl: serverVariableServiceProvider.$get().SITE_SUBFOLDER() + 'vmApp/templates/versionmanagment.html',
	         controller: 'versionManagementController as vm',
	         data: { displayName: 'Dashboard' }
	     })
    	.state('createRequest', {
    	    url: '/selfServe/versionManagement/createRequest',
    	    templateUrl: serverVariableServiceProvider.$get().SITE_SUBFOLDER() + 'vmApp/templates/createrequest.html',
    	    controller: 'createRequestController as vmcr',
    	    onEnter: scrollContent,
    	    data: { displayName: 'Create Request' }
    	})
    	.state('requestDetails', {
    	    url: '/selfServe/versionManagement/requestTracking/requestDetails',
    	    templateUrl: serverVariableServiceProvider.$get().SITE_SUBFOLDER() + 'vmApp/templates/requestdetails.html',
    	    controller: 'requestDetailsController as vmrd',
    	    onEnter: scrollContent,
    	    data: { displayName: 'Request Details' }
    	})
	     .state('requestTracking', {
	         url: '/selfServe/versionManagement/requestTracking',
	         templateUrl: serverVariableServiceProvider.$get().SITE_SUBFOLDER() + 'vmApp/templates/requesttracking.html',
	         controller: 'requestTrackingController as vmrt',
	         data: { displayName: 'Track Request' }
	     })
	     .state('manage', {
	         url: '/selfServe/mappingTable/manage',
	         templateUrl: serverVariableServiceProvider.$get().SITE_SUBFOLDER() + 'mtApp/templates/MappingTable.html',
	         controller: 'mappingTablesController as mmt',
	         data: { displayName: 'Manage' }
	     })
	     .state('mappingTable', {
	         url: '/selfServe/mappingTable',
	         templateUrl: serverVariableServiceProvider.$get().SITE_SUBFOLDER() + 'mtApp/templates/MappingTable.html',
	         controller: 'mappingTablesController as mmt',
	         data: { displayName: 'Mapping Tables' }
	     })
	     .state('audit', {
	         url: '/selfServe/mappingTable/audit',
	         templateUrl: serverVariableServiceProvider.$get().SITE_SUBFOLDER() + 'mtApp/templates/MappingTableAudit.html',
	         controller: 'mappingTablesAuditController as mta',
	         data: { displayName: 'Audit' }
	     })
        .state('userProfile', {
            url: '/adminFunctions/userProfile',
            templateUrl: serverVariableServiceProvider.$get().SITE_SUBFOLDER() + 'mduaApp/templates/userprofile.html',
            controller: 'userProfileController as up',
            data: { displayName: 'User Profile' }
        })
        .state('userProfileQS', {
            url: '/adminFunctions/userProfile/:employeeId',
            templateUrl: serverVariableServiceProvider.$get().SITE_SUBFOLDER() + 'mduaApp/templates/userprofile.html',
            controller: 'userProfileController as up',
            data: { displayName: 'User Profile' }
        })
        .state('jobs', {
            url: '/selfServe/jobs',
            templateUrl: serverVariableServiceProvider.$get().SITE_SUBFOLDER() + 'mduaApp/templates/ondemandjobs.html',
            controller: 'onDemandJobsController as od',
            data: { displayName: 'Jobs' }
        })
        .state('onDemandJobs', {
            url: '/selfServe/jobs/onDemandJobs',
            templateUrl: serverVariableServiceProvider.$get().SITE_SUBFOLDER() + 'mduaApp/templates/ondemandjobs.html',
            controller: 'onDemandJobsController as od',
            data: { displayName: 'On Demand Jobs' }
        })
        .state('manageFileTypes', {
            url: '/selfServe/mdua/manageFileTypes',
            templateUrl: serverVariableServiceProvider.$get().SITE_SUBFOLDER() + 'mduaApp/templates/manageFileTypes.html',
            controller: 'manageFileTypesController as mft',
            data: { displayName: 'On Demand Jobs' }
        })
        .state('factAudit', {
            url: '/selfServe/userUploadParent/auditTableDownload',
            templateUrl: serverVariableServiceProvider.$get().SITE_SUBFOLDER() + 'mduaApp/templates/factaudit.html',
            controller: 'factAuditController as fa',
            data: { displayName: 'Audit Table Download' }
        })
        .state('factDownload', {
            url: '/selfServe/userUploadParent/factTableDownload',
            templateUrl: serverVariableServiceProvider.$get().SITE_SUBFOLDER() + 'mduaApp/templates/factdownload.html',
            controller: 'factDownloadController as fa',
            data: { displayName: 'Fact Table Download' }
        })
        .state('fileTransfer', {
            url: '/selfServe/fileTransferParent/fileTransfer',
            templateUrl: serverVariableServiceProvider.$get().SITE_SUBFOLDER() + 'mduaApp/templates/fileTransfer.html',
            controller: 'fileTransferController as ft',
            data: { displayName: 'File Transfer' }
        })
        .state('datascoopApp', {
            url: '/selfServe/datascoop/datascoopApp',
            templateUrl: serverVariableServiceProvider.$get().SITE_SUBFOLDER() + 'dataScoopApp/templates/cubeAutoDataScoop.html',
            controller: 'ApplicationManagementController as appMgmt',
            data: { displayName: 'Manage Applications' }
        })
        .state('manageUsers', {
            url: '/adminFunctions/manageUsers',
            templateUrl: serverVariableServiceProvider.$get().SITE_SUBFOLDER() + 'mduaApp/templates/manageUsers.html',
            controller: 'manageUsersController as muc',
            data: { displayName: 'Manage Users' }
        })
        .state('reporting', {
            url: '/selfServe/reporting',
            templateUrl: serverVariableServiceProvider.$get().SITE_SUBFOLDER() + 'mtApp/templates/reporting.html',
            controller: 'reportingController as rpt',
            data: {displayName: 'Reporting'}
        });


        $httpProvider.interceptors.push('noCacheInterceptorService');

    }]);

    vmApp.run(['$templateCache', '$rootScope', '$log', '$state', '$stateParams', 'errorHandlerService', 'notificationSubscriberService', 'userMenuService', function ($templateCache, $rootScope, $log, $state, $stateParams, errorHandlerService, notificationSubscriberService, userMenuService) {

        var fdmAlertTemplate = '<div ng-repeat="alert in currentAlerts" class="alert {{alert.type}} clearfix" role="alert" id="bootstrapAlert">'
            + '<a class="close" data-dismiss="alert" ng-click="removeAlert(alert)" href="">&times;</a>'
            + '<span class="alert-icon"></span>'
            + '<p>{{alert.message}}</p>'
            + '</div>';
        $templateCache.put('fdm_alerts.html', fdmAlertTemplate);

        $rootScope.$state = $state;
        $rootScope.$stateParams = $stateParams;

        $rootScope.$on('ngRepeatFinished', function (ngRepeatFinishedEvent) {
            jQuery('.vzbs-dropdown').each(function (index, value) {
                var len = jQuery(this).find(jQuery('.dropdown-menu li')).length;
                if (len > 5) {
                    jQuery(this).find('.dropdown-menu').addClass('adjust-block');
                }
            });
        });

        $rootScope.$on('$stateChangeError', function (event, toState, toParams, fromState, fromParams, error) {

            $log.error('An error occured while changing states', error);
            $log.debug('event', event);
            $log.debug('toState', toState);
            $log.debug('toParams', toParams);
            $log.debug('fromState', fromState);
            $log.debug('fromParams', fromParams);

        });

        $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
            if (fromState.name == 'manage' || fromState.name == 'mappingTable') {
                //restore this template when leaving mapping table page
                $templateCache.put("ui-grid/uiGridViewport", $templateCache.get("ui-grid/uiGridViewport_original"));
            }
            switch (fromState.name) {
                case "requestDetails":
                    notificationSubscriberService.disconnectSubscriber("VM_RequestDetails");
                    break;
                case "versionManagement":
	       	      case "dashboard":
                    notificationSubscriberService.disconnectSubscriber("VM_Dashboard");
                    break;

                default:
            }

            var userMenu = userMenuService.getUserMenu();
            if (userMenu.length > 0 && toState.data.displayName != "Error") {
                var hasMenuItemAccess = userMenuService.hasMenuItemAccess(userMenu, toState.data.displayName);
                if (hasMenuItemAccess == false) {
                    event.preventDefault();
                    errorHandlerService.addError("No Page Access.");
                    $state.go("error");
                }
            }
            if (userMenu.length == 0 && toState.name != "home") {
                $state.go("home");
            }

       });
    }])

}());
