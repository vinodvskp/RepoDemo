﻿using System;
using System.Collections;
using System.Drawing;
using System.Text;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using MDUA.DataAccess;
using MDUA.BusinessLogic;
using MDUA.DTO;
using System.Collections.Generic;

public partial class MoveKeyCombos : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
        try {
            Master.PageTitle = "Move Key Combinations";
            //Master.NavInstructionsVisible = true;
            if (!Master.SignedIn(UserRole.RegUser)) {
                return;
            }

            if (!Master.curUser.CanAddUserInputKeys) {
                try {
                    Master.PendingMessage = "You don't have access to Move Key Combinations.";
                    Server.Transfer("~/Default.aspx");
                } catch (System.Threading.ThreadAbortException) {
                    // thread was aborted ... do nothing
                }
            }

            if (!IsPostBack) {
                //  Get a list of File types that this user can upload
                List<FileType> fileTypes = Utils.GetFileTypes(Master.curUser.EmployeeID);

                //  If this user doesn't have any file types that they can upload,
                //  Go back to the default page.
                if (fileTypes == null || fileTypes.Count == 0) {
                    try {
                        Master.PendingMessage = "You don't have access to Move Key Combinations.";
                        Server.Transfer("~/Default.aspx");
                    } catch (System.Threading.ThreadAbortException) {
                        // thread was aborted ... do nothing
                    }
                }

                foreach (FileType fileType in fileTypes) {
                    if (fileType.UsesValidKeyCombos) {
                        ddlFileType.Items.Add(new ListItem(string.Format("{0} ({1})", fileType.Description, fileType.FileTypeCode), fileType.FileTypeCode));
                    }
                }

                //  If there are items, put in a default item so that they don't accidentally
                //  upload to the first file type because they forgot to change the file type.
                ddlFileType.Items.Insert(0, new ListItem("Select File Type...", string.Empty));
            } else {
                litJavaScript.Text = "";
            }
        } catch (System.Threading.ThreadAbortException) { // thread was aborted ... do nothing 
        } catch (Exception ex) {
            Utils.LogEvent(Master.curUser.EmployeeID, "MoveKeyCombos.aspx", "Page_Load", ex, UserToolLogLevel.Error);
            Master.Message = HypMDUA.ERROR_MESSAGE;
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e) {
        try {
            Server.Transfer("~/MoveKeyCombos.aspx");
        } catch (System.Threading.ThreadAbortException) {
            // thread was aborted ... do nothing
        }
    }

    protected void btnDisplay_Click(object sender, EventArgs e) {
        try {
            if (ddlFileType.SelectedValue == "") {
                gvResults.Visible = false;
                litSkippedRows.Visible = false;
                Master.Message = "You must select a File Type to display";
                return;
            }

            Master.Message = "";
            FileType currentFileType = Utils.GetFileType(ddlFileType.SelectedValue, Master.curUser.EmployeeID);
            int SkippedRows = 0;
            // jevans 5/10/2011 -- restrict rows displayed 
            ArrayList a = Utils.GetCurrentKeys(currentFileType, out SkippedRows);
            if (a == null) {
                throw new Exception("GetCurrentKeys returned null array");
            }
            if (a.Count == 0) {
                pnlDestFile.Visible = false;
                gvResults.Visible = false;
                litSkippedRows.Visible = false;
                Master.Message = "There are currently no keys defined for the selected File Type.";
                return;
            }

            FillGrid(currentFileType, a, SkippedRows);

            //  Get a list of File types that this user can upload
            List<FileType> fileTypes = Utils.GetFileTypes(Master.curUser.EmployeeID);

            //  If this user doesn't have any file types that they can upload,
            //  Go back to the default page.
            if (fileTypes == null || fileTypes.Count == 0) {
                Master.PendingMessage = "You don't have access to Move Key Combinations.";
                Server.Transfer("~/Default.aspx");
            }

            ddlDestFileType.Items.Clear();
            foreach (FileType destinationFileType in fileTypes) {
                if (destinationFileType.UsesValidKeyCombos 
                    && destinationFileType.DestinationTable.Equals(currentFileType.DestinationTable) 
                    && !destinationFileType.FileTypeCode.Equals(currentFileType.FileTypeCode) ) {
                    ddlDestFileType.Items.Add(new ListItem(string.Format("{0} ({1})", destinationFileType.Description, destinationFileType.FileTypeCode), destinationFileType.FileTypeCode));
                }
            }

            if (ddlDestFileType.Items.Count == 0) {
                Master.Message = "There are no other File Types that use the same destination table.";
                pnlDestFile.Visible = false;
                return;
            }
            //  If there are items, put in a default item so that they don't accidentally
            //  upload to the first file type because they forgot to change the file type.
            ddlDestFileType.Items.Insert(0, new ListItem("Select File Type...", string.Empty));
        } catch (System.Threading.ThreadAbortException) {
            // thread was aborted ... do nothing
        } catch (Exception ex) {
            Utils.LogEvent(Master.curUser.EmployeeID, "MoveKeyCombos.aspx", "btnDisplay_Click", ex, UserToolLogLevel.Error);
            Master.Message = HypMDUA.ERROR_MESSAGE;
        }
    }
   

    private int FillGrid(FileType fileType, ArrayList results,  int skippedRows) {
        // save array in session for page/sort 
        Session["ArrayList"] = results;
        gvResults.Visible = true;

        pnlDestFile.Visible=Master.curUser.CanAddUserInputKeys ;

        // cell index is zero based, so subtract one to count columns  
        int Cnt = gvResults.Columns.Count - 1;

        try {
            switch (fileType.FactTable) {
                case FactTable.PlanningActuals:
                    foreach (DataControlField column in gvResults.Columns) {
                        switch (column.HeaderText) {
                            case "Account":
                            case "Cust Account":
                                column.Visible = true;
                                column.HeaderText = "Account";
                                break;
                            case "GL Account":
                            case "Product":
                            case "Contract Term":
                            case "Tech Type":
                            case "Region":
                            case "ServiceType":
                            case "Scenario":
                            case "Function":
                            case "External Segment":
                            case "Business Segment":
                            case "Line of Business":
                            case "Planned Entity":
                            case "Run Status Id":
                                column.Visible = true;
                                break;
                            default:
                                column.Visible = false;
                                break;
                        }
                    }
                    break;

                case FactTable.ProductOfferUser:
                    foreach (DataControlField column in gvResults.Columns) {
                        switch (column.HeaderText) {
                            case "Account":
                            case "Cust Account":
                                column.Visible = true;
                                column.HeaderText = "Account";
                                break;
                            case "Entity":
                            case "Location":
                                column.HeaderText = "Entity";
                                break;
                            case "Product":
                            case "Cost Cntr":
                            case "Cost Center":
                            case "Contract Term":
                            case "Connection Type":
                            case "Segment":
                            case "ReportingLine":
                            case "Rptng Line":
                            case "Equipment":
                            case "ServiceType":
                            case "Srv Type":
                            case "Scenario":
                            case "Function":
                            case "Organization":
                            case "Org Chart":
                            case "Account Size":
                            case "HRHV":
                            case "Ethnicity":
                            case "Run Status Id":
                                column.Visible = true;
                                break;
                            default:
                                column.Visible = false;
                                break;
                        }
                    }
                    break;

                case FactTable.EquipmentUser:
                    foreach (DataControlField column in gvResults.Columns) {
                        switch (column.HeaderText) {
                            case "Account":
                            case "Cust Account":
                                column.Visible = false;
                                break;
                            case "Entity":
                            case "Location":
                                column.HeaderText = "Entity";
                                column.Visible = true;
                                break;
                            case "ReportingLine":
                            case "Rptng Line":
                            case "Cost Center":
                            case "Cost Cntr":
                            case "Method Type":
                            case "Methodology Type":
                            case "Sale Type":
                            case "Discount Type":
                            case "Contract Term":
                            case "KPI":
                            case "View":
                            case "Equipment":
                            case "ServiceType":
                            case "Service Type":
                            case "Srv Type":
                            case "Scenario":
                            case "Function":
                            case "Tech Type":
                            case "Run Status Id":
                                column.Visible = true;
                                break;
                            default:
                                column.Visible = false;
                                break;
                        }
                    }
                    break;
                case FactTable.DevicePaymentLoan:
                    foreach (DataControlField column in gvResults.Columns)
                    {
                        switch (column.HeaderText)
                        {
                            case "Aging":
                            case "Collection Status":
                            case "Contract Term":
                            case "Credit Risk Type":
                            case "Entities":
                            case "Equipment":
                            case "Customer Tenure":
                            case "Deact Change Reason":
                            case "FICO":
                            case "Function":
                            case "Loan Tenure":
                            case "Loan Vintage":
                            case "First Payment Made":
                            case "Original Loan Equipment":
                            case "Reporting Line":
                            case "Rptng Line":
                            case "Scenario":
                            case "ServiceType":
                            case "Service Type":
                            case "Srv Type":
                            case "Tranche":
                            case "Upg Elig":
                            case "WriteOff Reason":
                            case "Bill System Customer Type":
                            case "Loan Status":
                            case "Treasury Tenure":
                            case "Run Status Id":
                                column.Visible = true;
                                break;
                            default:
                                column.Visible = false;
                                break;
                        }
                    }
                    break;
                default:
                    bool isLocation = fileType.FactTableId == (int)FactTable.LocationUser;
                    bool isEquipment = fileType.FactTableId == (int)FactTable.EquipmentUser;
                    bool isDataWarehouse = fileType.FactTableId == (int)FactTable.EquipmentUser;

                    foreach (DataControlField column in gvResults.Columns) {
                        switch (column.HeaderText) {
                            case "Account":
                            case "Cust Account":
                                column.Visible = !isEquipment;
                                column.HeaderText = isDataWarehouse ? "Cust Account" : "Account";
                                break;
                            case "Entity":
                            case "Location":
                                column.HeaderText = isLocation ? "Location" : "Entity";
                                break;
                            case "Product":
                            case "Sub Acct":
                                column.Visible = !isEquipment;
                                break;
                            case "Cost Cntr":
                                column.Visible = !isDataWarehouse;
                                break;
                            case "Company":
                                column.Visible = !isEquipment && !isDataWarehouse && !isLocation;
                                break;
                            case "Store Status":
                            case "Design Type":
                            case "Loc Type":
                            case "Loc Subtype":
                            case "Loc Tier Code":
                                column.Visible = isLocation;
                                break;
                            case "Method Type":
                            case "Methodology Type":
                            case "Sale Type":
                            case "Discount Type":
                                column.Visible = isEquipment;
                                break;
                            case "Contract Term":
                                column.Visible = isEquipment || isDataWarehouse; ;
                                break;
                            case "Program Eligible":
                                column.Visible = isDataWarehouse;
                                break;
                            case "Branch":
                            case "Connection Type":
                            case "Owning Geography":
                            case "Owning Manager":
                            case "Segment":
                            case "Version":
                            case "Vertical":
                            case "Previous Type":
                                column.Visible = isDataWarehouse;
                                break;
                            case "Organization":
                            case "Org Chart":
                            case "Account Size":
                            case "HRHV":
                            case "Ethnicity":
                            case "Run Status Id":
                                column.Visible = false;
                                break;
                            case "GL Account":
                            case "Region":
                            case "External Segment":
                            case "Business Segment":
                            case "Line of Business":
                            case "Planned Entity":
                            case "Fiscal Period":
                            case "Aging":
                            case "Entities":
                            case "Customer Tenure":
                            case "Credit Risk Type":
                            case "Loan Tenure":
                            case "Loan Vintage":
                            case "Collection Status":
                            case "FICO":
                            case "Upg Elig":
                            case "Tranche":
                            case "Original Loan Equipment":
                            case "First Payment Made":
                            case "WriteOff Reason":
                            case "Deact Change Reason":
                            case "Bill System Customer Type":
                            case "Loan Status":
                            case "Treasury Tenure":
                                column.Visible = false;
                                break;
                            default:
                                column.Visible = true;
                                break;
                        }
                        
                    }
                    break;
            }
           
            // jevans 5/10/2011 -- check for skipped rows in error results
            if (skippedRows > 0) {
                litSkippedRows.Visible = true;
                litSkippedRows.Text = string.Format("{0} rows were skipped.", skippedRows);
                Master.Message += string.Format("<p>The first {0} rows are displayed, {1} rows were skipped.", results.Count, skippedRows);
            } else {
                litSkippedRows.Visible = false;
            }

            // bind grid to array 
            gvResults.DataSource = results;
            gvResults.DataBind();

        }
        catch (Exception ex)
        {
            //  Log the error to a table.
            Utils.LogEvent(Master.curUser.EmployeeID, "MoveKeyCombos.aspx", "FillTable", ex, UserToolLogLevel.Error);
            Master.Message = HypMDUA.ERROR_MESSAGE;
        }

        return results.Count;
    }

    protected void btnMove_Click(object sender, EventArgs e) {
        int totalFactsMoved = 0;
        int totalKeysMoved = 0;
        try {
            if (ddlDestFileType.Items.Count == 0 || ddlDestFileType.SelectedIndex == 0) {
                Master.Message = "You must select a destination file type.";
                return;
            }

            if (gvResults.GetSelectedIndices() == null || gvResults.GetSelectedIndices().Length == 0) {
                Master.Message = "No key(s) were selected to move.";
                return;
            }
            FileType fileType = Utils.GetFileType(ddlDestFileType.SelectedValue, Master.curUser.EmployeeID);

            if (fileType.FactTable == FactTable.ProductOfferUser 
                || fileType.FactTable == FactTable.EquipmentUser
                || fileType.FactTable == FactTable.PlanningActuals
                || fileType.FactTable == FactTable.DevicePaymentLoan)
            {
                List<string> rowids = new List<string>();
                foreach (int index in gvResults.GetSelectedIndices()) {
                    rowids.Add((string)gvResults.DataKeys[index].Value);
                }
                try {
                    switch (fileType.FactTable) {
                        case FactTable.ProductOfferUser:
                            ProductOfferDatabaseAccess.MoveKeys(fileType, ddlFileType.SelectedValue, rowids, false, out totalFactsMoved, out totalKeysMoved);
                            break;
                        case FactTable.EquipmentUser:
                            EquipmentDatabaseAccess.MoveKeys(fileType, ddlFileType.SelectedValue, rowids, false, out totalFactsMoved, out totalKeysMoved);
                            break;
                        case FactTable.PlanningActuals:
                            PlanningActualsDatabaseAccess.MoveKeys(fileType, ddlFileType.SelectedValue, rowids, false, out totalFactsMoved, out totalKeysMoved);
                            break;
                        case FactTable.DevicePaymentLoan:
                            DevicePaymentLoanDatabaseAccess.MoveKeys(fileType, ddlFileType.SelectedValue, rowids, false, out totalFactsMoved, out totalKeysMoved);
                            break;

                    }
                    Master.PendingMessage = string.Format("{0} {1} key combinations were moved to {2} ({3} fact rows updated)"
                        , totalKeysMoved, ddlFileType.SelectedValue, ddlDestFileType.SelectedValue, totalFactsMoved);
                } catch {
                    Master.PendingMessage = HypMDUA.ERROR_MESSAGE;
                }
                                
            } else {                
                //jevans 6/18/2012 build a comma delimited string of rowids instead of an array
                //ArrayList RowIds = new ArrayList();
                string sRowids = string.Empty;
                // for each row checked 
                foreach (int index in gvResults.GetSelectedIndices()) {
                    // RowIds.Add((string)gvResults.DataKeys[index].Value);
                    sRowids += (string)gvResults.DataKeys[index].Value + ",";
                }
                
                if (gvResults.GetSelectedIndices().Length > 1000) {
                    Master.Message = string.Format("You selected {0} keys, which is too many to move. Use the 'Move all button or select fewer key combinations.", gvResults.GetSelectedIndices().Length.ToString());
                    return;
                }
                sRowids = sRowids.Substring(0, sRowids.Length - 1);
                //  jevans 6/18/2012 refactored to accept a string of rowids instead of an array
                Utils.MoveKeyCombos(fileType, sRowids, ddlFileType.SelectedValue, Master.curUser.EmployeeID, out totalFactsMoved, out totalKeysMoved);
                // prepare result message 
                if (totalFactsMoved >= 0) {
                    Master.PendingMessage = string.Format("The {0} {1} Key Combinations selected caused {2} rows to be moved in the fact table",
                           gvResults.GetSelectedIndices().Length, ddlFileType.SelectedValue, totalFactsMoved);
                } else {
                    throw new Exception("MoveKeyCombo returned negative fact count");
                }
                if (fileType.UsesValidKeyCombos) {
                    if (totalKeysMoved >= 0) {
                        Master.PendingMessage += string.Format(" and {0} Key Combinations were moved in the Valid Key Combinations table.",
                            totalKeysMoved);
                    } else {
                        throw new Exception("MoveKeyCombo returned negative key count");
                    }
                }
            }            
            
            Utils.LogEvent(Master.curUser.EmployeeID, "MoveKeyCombos.aspx", "btnMoveAll_Click", Master.PendingMessage, UserToolLogLevel.Audit);
            Server.Transfer("~/MoveKeyCombos.aspx");
        }
        catch (System.Threading.ThreadAbortException)
        {
            // thread was aborted ... do nothing
        }
        catch (Exception ex)
        {
            Utils.LogEvent(Master.curUser.EmployeeID, "MoveKeyCombos.aspx", "btnMove_Click", ex, UserToolLogLevel.Error);
            Master.Message = HypMDUA.ERROR_MESSAGE;
        }
    } // end move button  

    protected void btnMoveAll_Click(object sender, EventArgs e) {
        int totalFactsMoved = 0;
        int totalKeysMoved = 0;
        try {
            if (ddlDestFileType.SelectedIndex == 0)  {
                Master.Message = "You must select a file type that you want to move these items to.";
                return;
            }
                        
            FileType fileType = Utils.GetFileType(ddlDestFileType.SelectedValue, Master.curUser.EmployeeID);

            if (fileType.FactTable == FactTable.ProductOfferUser 
                || fileType.FactTable == FactTable.EquipmentUser
                || fileType.FactTable == FactTable.PlanningActuals
                || fileType.FactTable == FactTable.DevicePaymentLoan)
            {
                try {
                    switch (fileType.FactTable) {
                        case FactTable.ProductOfferUser:
                            ProductOfferDatabaseAccess.MoveKeys(fileType, ddlFileType.SelectedValue, null, true, out totalFactsMoved, out totalKeysMoved);
                            break;
                        case FactTable.EquipmentUser:
                            EquipmentDatabaseAccess.MoveKeys(fileType, ddlFileType.SelectedValue, null, true, out totalFactsMoved, out totalKeysMoved);
                            break;
                        case FactTable.PlanningActuals:
                            PlanningActualsDatabaseAccess.MoveKeys(fileType, ddlFileType.SelectedValue, null, true, out totalFactsMoved, out totalKeysMoved);
                            break;
                        case FactTable.DevicePaymentLoan:
                            DevicePaymentLoanDatabaseAccess.MoveKeys(fileType, ddlFileType.SelectedValue, null, true, out totalFactsMoved, out totalKeysMoved);
                            break;
                    }
                } catch {
                    Master.PendingMessage = HypMDUA.ERROR_MESSAGE;
                }

                Master.PendingMessage = string.Format("{0} {1} key combinations were moved to {2}. {3} fact rows were updated"
                        , totalKeysMoved, ddlFileType.SelectedValue, ddlDestFileType.SelectedValue, totalFactsMoved);   
            } else {
                // jevans 4/4/2012 - refactored to return boolean, with out fars for key counts 
                if (Utils.MoveAllKeyCombos(fileType, ddlFileType.SelectedValue, Master.curUser.EmployeeID, out totalFactsMoved, out totalKeysMoved)) {
                    Master.PendingMessage = string.Format("Moving All {0} Key Combinations caused {1} rows to be moved in the fact table",
                          ddlFileType.SelectedValue, totalFactsMoved);
                } else {
                    Master.PendingMessage = HypMDUA.ERROR_MESSAGE;
                }
                if (fileType.UsesValidKeyCombos) {
                    if (totalKeysMoved >= 0) {
                        Master.PendingMessage += string.Format(" and {0} Key Combinations were moved in the Valid Key Combinations table.",
                            totalKeysMoved);
                    } else {
                        Master.PendingMessage = HypMDUA.ERROR_MESSAGE;
                    }
                }
            }
            Utils.LogEvent(Master.curUser.EmployeeID, "MoveKeyCombos.aspx", "btnMoveAll_Click", Master.PendingMessage, UserToolLogLevel.Audit);
            Server.Transfer("~/MoveKeyCombos.aspx");
        }
        catch (System.Threading.ThreadAbortException)
        {
            // thread was aborted ... do nothing
        }
        catch (Exception ex)
        {
            Utils.LogEvent(Master.curUser.EmployeeID, "MoveKeyCombos.aspx", "btnMoveAll_Click", ex, UserToolLogLevel.Error);
            Master.Message = HypMDUA.ERROR_MESSAGE;
        }

    } // end move ALL button  

    protected void gvResults_Sorting(object sender, GridViewSortEventArgs e)
    {
                //Retrieve the table from the session object.
        ArrayList a = Session["ArrayList"] as ArrayList;

        if (a != null)
        {
            IComparer f = (IComparer)new FactComparer(e.SortExpression, SortOrderAlternate(e.SortExpression));
            a.Sort(f);
            gvResults.DataSource = a;
            gvResults.DataBind();
            gvResults.PageIndex = 0;
        }
    } // end sorting 

    public bool SortOrderAlternate(String currentSortExpression)
    {
        String previousSortExpression = (String)Session["SortExpression"];
        bool bReturn = false;
        if (previousSortExpression == null)
        {
            //first sort, set to default ASC
            currentSortExpression += " ASC";
        }
        else
        {
            if (previousSortExpression.StartsWith(currentSortExpression))
            {
                //same column re-sort, set to opposite order
                if (previousSortExpression.EndsWith("ASC"))
                {
                    currentSortExpression += " desc";
                    bReturn = true;
                }
                else
                    currentSortExpression += " ASC";
            }
            else
            {
                //new column sort, set to default ASC
                currentSortExpression += " ASC";
            }
        }
        Session.Remove("SortExpression");
        Session.Add("SortExpression", currentSortExpression);
        return bReturn;
    }

} // end of class 

