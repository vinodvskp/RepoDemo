﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
//using MDUA.DataAccess;
using MDUA.BusinessLogic;
using MDUA.DTO;
using System.Collections.Generic;

public partial class OpsFactDownload : System.Web.UI.Page {
    public class SortByAlias : IComparer {
        public int Compare(object obj1, object obj2) {
            Dimension dim1 = (Dimension)obj1;
            Dimension dim2 = (Dimension)obj2;

            return -(String.Compare(dim1.Alias, dim2.Alias));
        }
    }

    protected void Page_Load(object sender, EventArgs e) {
        Master.PageTitle = "Fact Table Download";
        //Master.NavInstructionsVisible = true;
        if (!IsPostBack) {
            List<FileType> fileTypes = Utils.GetFileTypes(Master.curUser.EmployeeID);

            //  If this user doesn't have any file types that they can upload,
            //  Go back to the default page.
            // jevans 5/23/2012 - if web settings is null, database is not available.
            if (fileTypes == null) {
                Master.Message = "MDUA could not load web settings from the database, and cannot continue.  <P>" + HypMDUA.ERROR_MESSAGE;
                return;
            } 

            if (fileTypes.Count == 0) {
                try {
                    Master.PendingMessage = "You don't have access to any file types.";
                    Response.Redirect("Default.aspx");
                } catch (System.Threading.ThreadAbortException) {
                    // thread was aborted ... do nothing
                }
            }

            //  If there are items, put in a default item so that they don't accidentally
            //  upload to the first file type because they forgot to change the file type.
            ddlFileType.Items.Add(new ListItem("Select File Type...", string.Empty));

            foreach (FileType fileType in fileTypes) {
                ddlFileType.Items.Add(new ListItem(string.Format("{0} ({1})", fileType.Description, fileType.FileTypeCode), fileType.FileTypeCode));
            }

            WebSettings settings = Utils.LoadWebSetting(Master.curUser.EmployeeID);
            // jevans 5/23/2012 - if web settings is null, database is not available.
            if (settings == null) {
                Master.Message = "MDUA could not load web settings from the database, and cannot continue.  <P>" + HypMDUA.ERROR_MESSAGE;
                return;
            }
            ddlMonths.SelectedValue = settings.CurrentMonth;

            ArrayList yearsDimension = Utils.GetDimensions("YEARS", "web_dimensions_tbl", Master.curUser.EmployeeID);
            yearsDimension.Sort(new SortByAlias());
            ddlYears.Items.Clear();
            foreach (Dimension dimension in yearsDimension) {
                if (dimension.Alias.Trim().Length > 0)
                    ddlYears.Items.Add(dimension.Alias.Trim());
            }
        } else {
            Master.Message = "";
        }
    }

    protected void btnDownload_Click(object sender, EventArgs e) {
        try {
            Master.Message = string.Empty;
            if (ddlFileType.SelectedValue == "") {
                Master.Message = "You must select a File Type to download before pressing the 'Download' button.";
                return;
            }

            FileType fileType = Utils.GetFileType(ddlFileType.SelectedValue, Master.curUser.EmployeeID);
            List<MasterDimension> dimensionList = Utils.GetFactDimensions(fileType.FactTable, fileType.Is13Month, false, false);
            MasterFactTable factTable = Utils.GetFactTable(fileType.FactTableId.ToString(), "", Master.curUser.EmployeeID);

            DateTime reportingPeriod = new DateTime(int.Parse(ddlYears.SelectedValue), int.Parse(ddlMonths.SelectedValue), 1);
            DateTime startPeriod = reportingPeriod.AddMonths(-int.Parse(ddlPriorPeriods.SelectedValue));
            // jevans - 24735 4/19/2012 set period to end of month for equipment downloads
            reportingPeriod = reportingPeriod.AddMonths(1).AddDays(-1);

            string Filename = string.Format("Downloads/{1}_{2}_{0}.csv", DateTime.Now.ToString("yyyyMMdd_HHmmss"), Master.curUser.UserId, fileType.FileTypeCode);
            Filename = Server.MapPath(Filename);

             if (dimensionList.Count == 0)
                // create error email
                throw new Exception("OpsFactDownload failed to load dimension array");

            // now build select sql 
            Utils.LogEvent(Master.curUser.EmployeeID, "OpsFactDownload.aspx", "btnDownload_Click", "Calling WriteFactDataToExcel", UserToolLogLevel.Message);
            switch (Utils.WriteFactDataToCSV(Master.curUser.EmployeeID, fileType, dimensionList, factTable, reportingPeriod, startPeriod, Filename)) {
                case 0:
                    Master.Message = "There was no Fact data found for the selected type and period. ";
                    break;
                case -1:
                    Master.Message = HypMDUA.ERROR_MESSAGE;
                    break;
                default:
                    Utils.LogEvent(Master.curUser.EmployeeID, "OpsFactDownload", "btnDownload_Click", "Passing control to downloadfile.aspx", UserToolLogLevel.Message);
                    Response.Redirect(string.Format("DownloadFile.aspx?DocName={0}&Del=Y", Filename));
                    break;
            }
        } catch (System.Threading.ThreadAbortException) { 
            /* thread was aborted ... do nothing */ 
        } catch (Exception ex) {
            Master.Message = HypMDUA.ERROR_MESSAGE;
            Utils.LogEvent(Master.curUser.EmployeeID, "OpsFactDownload.aspx", "btnDownload_Click", ex, UserToolLogLevel.Error);
        }
    }

}
