﻿(function () {
    angular.module('vmApp').service('fileTransferService', ['$q', '$http', 'constantService', 'authenticationService', 'serverVariableService', fileTransferService]);

    function fileTransferService($q, $http, constantService, authenticationService, serverVariableService) {
        var self = this;


        self.getFileTransferProfiles = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getFileTransferProfilesWorker, successCallback, errorCallback);
        };

        self.transferFile = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, transferFileWorker, successCallback, errorCallback);
        };

        self.deleteFile = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, deleteFileWorker, successCallback, errorCallback);
        };

        self.renameFile = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, renameFileWorker, successCallback, errorCallback);
        };

        this.getSignedKey = function (payload) {
            return authenticationService.simpleServiceDispatcher(payload, getSignedKeyWorker);
        };

        this.listFolder = function (payload) {
            return authenticationService.simpleServiceDispatcher(payload, listFolderWorker);
        };

        this.getDownloadUrl = function () {
            return serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/fileTransfer/download';
        }

        function listFolderWorker(token, payload) {
            return $http({
                    method: 'GET',
                    headers: { 'Authorization': token },
                    url: serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/fileTransfer/folderlist?profileid=' + payload.profileId + '&path=' + payload.path
                  }).then(function (response) {
                        return $q.when(response.data);
                  }).catch(function (err) {
                      return $q.reject("listing folder does not return data");
                 });
        }

        function getFileTransferProfilesWorker(authToken, payload) {
            return $http({
                method: 'GET',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/fileTransfer/GetFileTransferProfiles'
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return groups data");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }

        function transferFileWorker(authToken, payload) {
            return $http({
                method: 'POST',
                transformRequest: angular.identity,
                headers: { 'Authorization': authToken, 'Content-Type': undefined },
                url: serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/fileTransfer/TransferFile?profileId=' + payload.ProfileId + '&fileName=' + payload.FileName + '&path=' + payload.Path,
                data: payload.File
            })
             .then(function (response) {
                 if (response.status == 200) {
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return groups data");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }

        function deleteFileWorker(authToken, payload) {
            return $http({
                method: 'POST',
                headers: { 'Authorization': authToken, 'Content-Type': 'application/json' },
                url: serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/fileTransfer/DeleteFile',
                data: payload
            })
             .then(function (response) {
                 if (response.status == 200) {
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return groups data");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }

        function renameFileWorker(authToken, payload) {
            return $http({
                method: 'POST',
                headers: { 'Authorization': authToken, 'Content-Type': 'application/json' },
                url: serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/fileTransfer/RenameFile',
                data: payload
            })
             .then(function (response) {
                 if (response.status == 200) {
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return groups data");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }

        function getSignedKeyWorker(authToken, payload) {
            return $http({
                method: 'POST',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/fileTransfer/GetSignedUrlForDownload',
                data: {path: payload.path }
            }).then(function (response) {
                return $q.when(response.data);
            }).catch(function (err) {
                return $q.reject(err);
            });
        }
    }

}());