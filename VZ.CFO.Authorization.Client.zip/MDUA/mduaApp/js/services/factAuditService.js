﻿(function () {
    angular.module('vmApp')
  .service('factAuditService', ['$q', '$http', 'constantService', 'authenticationService', 'serverVariableService', factAuditService]);

    function factAuditService($q, $http, constantService, authenticationService, serverVariableService) {
        var self = this;


        self.getAuditData = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getAuditDataWorker, successCallback, errorCallback);
        }

        self.getDimensionValues = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getDimensionValuesWorker, successCallback, errorCallback);
        }

        self.exportAuditData = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, exportAuditDataWorker, successCallback, errorCallback);
        }

        function getAuditDataWorker(authToken, payload) {
            return $http({
                method: 'POST',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/facttable/GetAuditData',
                data: payload
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return groups data");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }

        function getDimensionValuesWorker(authToken, payload) {
            return $http({
                method: 'POST',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/facttable/GetDimensionValues',
                data: payload
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return groups data");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }

        function exportAuditDataWorker(authToken, payload) {
            return $http({
                method: 'POST',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/facttable/ExportAuditData',
                data: payload
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return groups data");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }
    }


}());