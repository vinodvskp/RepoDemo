﻿(function () {
    angular.module('vmApp')
  .service('manageFileTypesService', ['$q', '$http', 'constantService', 'authenticationService', 'serverVariableService', manageFileTypesService]);

    function manageFileTypesService($q, $http, constantService, authenticationService, serverVariableService) {
        var self = this;
    }


}());