﻿(function () {
    angular.module('vmApp')
  .service('manageUsersService', ['$q', '$http', 'constantService', 'authenticationService', 'serverVariableService', manageUsersService]);

    function manageUsersService($q, $http, constantService, authenticationService, serverVariableService) {
        var self = this;

        self.getUserAccessFlat = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getUserAccessFlatWorker, successCallback, errorCallback);
        }

        self.getSignedKeyForExport = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getSignedKeyForExportWorker, successCallback, errorCallback);
        }

        self.refreshUsersFromAD = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, refreshUsersFromADWorker, successCallback, errorCallback);
        }

        function getUserAccessFlatWorker(authToken, payload) {
            return $http({
                method: 'POST',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_USERS_ENDPOINT() + '/GetUserAccessFlat',
                data: payload.data
            })
             .then(function (response) {
                 if (response.status == 200) {
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return future versions data");
                 }
             }, function (response) {
                 var resp = response;
                 //console.log("getRequestTypes service call failed");
                 return $q.reject(resp);
             });
        }

        function getSignedKeyForExportWorker(authToken, payload) {
            return $http({
                method: 'GET',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_USERS_ENDPOINT() + '/GetSignedUrlForExportUsers/' + payload.exportType,
            })
             .then(function (response) {
                 if (response.status == 200) {
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return future versions data");
                 }
             }, function (response) {
                 var resp = response;
                 //console.log("getRequestTypes service call failed");
                 return $q.reject(resp);
             });
        }

        function refreshUsersFromADWorker(authToken, payload) {
            return $http({
                method: 'POST',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_USERS_ENDPOINT() + '/RefreshUsersFromADGroup',
            })
             .then(function (response) {
                 if (response.status == 200) {
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return future versions data");
                 }
             }, function (response) {
                 var resp = response;
                 //console.log("getRequestTypes service call failed");
                 return $q.reject(resp);
             });
        }
        
    }


}());