﻿(function () {
    angular.module('vmApp')
  .service('factDownloadService', ['$q', '$http', 'constantService', 'authenticationService', 'serverVariableService', factDownloadService]);

    function factDownloadService($q, $http, constantService, authenticationService, serverVariableService) {
        var self = this;


        self.getFactDownloadSignedUrl = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getFactDownloadSignedUrlWorker, successCallback, errorCallback);
        }

        function getFactDownloadSignedUrlWorker(authToken, payload) {
            return $http({
                method: 'POST',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/facttable/GetSignedUrlForFactTable',
                data: payload
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return groups data");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }
    }


}());