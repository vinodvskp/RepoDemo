﻿(function () {
    angular.module('vmApp')
  .service('userProfileService', ['$q', '$http', 'constantService', 'authenticationService', 'serverVariableService', userProfileService]);

    function userProfileService($q, $http, constantService, authenticationService, serverVariableService) {
        var self = this;
        var _userProfileVM = null;

        self.setUserProfileVM = function (employeeId, userId, accessObjectType) {
            self._userProfileVM = new userProfileViewModel(employeeId, userId, accessObjectType);
        }

        self.getUserAccessForAccessObjType = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getUserAccessForAccessObjTypeWorker, successCallback, errorCallback);
        }

        self.SaveUserAccessByEmployeeId = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, saveUserAccessByEmployeeIdWorker, successCallback, errorCallback);
        }

        self.getAllUsers = function(payload, successCallback, errorCallback){
            authenticationService.serviceCallDispatcher(payload, getAllUsersWorker, successCallback, errorCallback);
        }
        self.getUser = function(payload, successCallback, errorCallback){
            authenticationService.serviceCallDispatcher(payload, getUserWorker, successCallback, errorCallback);
        }

        self.getAllFactFiles = function(payload, successCallback, errorCallback){
            authenticationService.serviceCallDispatcher(payload, getAllFactFilesWorker, successCallback, errorCallback);
        }

        self.getFactFileTypeAccess = function(payload, successCallback, errorCallback){
            authenticationService.serviceCallDispatcher(payload, getFactFileTypeAccessWorker, successCallback, errorCallback);
        }

        self.getAllODJobs = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getAllODJobsWorker, successCallback, errorCallback);
        }

        self.getODJobAccess = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getODJobAccessWorker, successCallback, errorCallback);
        }

        self.saveLegacyUserAccess = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, saveLegacyUserAccessWorker, successCallback, errorCallback);
        }

        self.getAllDSApplications = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getAllDSApplicationsWorker, successCallback, errorCallback);
        }

        self.saveUser = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, saveUserWorker, successCallback, errorCallback);
        }

        self.getAllReports = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getAllReportsWorker, successCallback, errorCallback);
        }

        function getUserAccessForAccessObjTypeWorker(authToken, payload) {
            return $http({
                method: 'get',
                headers: { 'Authorization': authToken },
                //url: serverVariableService.MDUA_USERS_ENDPOINT() + '/GetUserAccessForAccessObjType/' + self._userProfileVM.employeeId + '/' + self._userProfileVM.accessObjectType,
                url: serverVariableService.MDUA_USERS_ENDPOINT() + '/GetUserAccessForAccessObjType/' + payload.employeeId + '/' + payload.accessObjectType,
                data: payload
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return user access data");
                 }
             }, function (response) {
                 var resp = response;
                 //console.log("getRequestTypes service call failed");
                 return $q.reject(resp);
             });
        }
        function saveUserAccessByEmployeeIdWorker(authToken, payload) {
                return $http({
                    method: 'post',
                    headers: { 'Authorization': authToken },
                    url: serverVariableService.MDUA_USERS_ENDPOINT() + '/SaveUserAccessByEmployeeId/' + payload.employeeId + '/' + payload.accessObjectType,
                    data: payload.data
                })
             .then(function (response) {
                 if (response.status == 200) {
                     return $q.when(response);
                 }
                 else {
                     return $q.reject("request call does not return future versions data");
                 }
             }, function (response) {
                 var resp = response;
                 //console.log("getRequestTypes service call failed");
                 return $q.reject(resp);
             });
        }

        function getAllUsersWorker(authToken, payload) {
            return $http({
                method: 'get',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_USERS_ENDPOINT() + '/GetAllUsers'
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return user access data");
                 }
             }, function (response) {
                 var resp = response;
                 //console.log("getRequestTypes service call failed");
                 return $q.reject(resp);
             });
        }

        function getUserWorker(authToken, payload) {
            return $http({
                method: 'get',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_USERS_ENDPOINT() + '/GetAllUsers/' + payload.employeeId
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return user access data");
                 }
             }, function (response) {
                 var resp = response;
                 //console.log("getRequestTypes service call failed");
                 return $q.reject(resp);
             });
        }

        function getFactFileTypeAccessWorker(authToken, payload){
            return $http({
                method: 'get',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_USERS_ENDPOINT() + '/GetFactFileTypeAccess/' + payload.employeeId
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return fact file access data");
                 }
             }, function (response) {
                 var resp = response;
                 //console.log("getRequestTypes service call failed");
                 return $q.reject(resp);
             });
        }

        function getAllFactFilesWorker(authToken, payload){
            return $http({
                method: 'get',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_USERS_ENDPOINT() + '/GetAllFactFile'
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return all fact file data");
                 }
             }, function (response) {
                 var resp = response;
                 //console.log("getRequestTypes service call failed");
                 return $q.reject(resp);
             });
        }

        function getAllODJobsWorker(authToken, payload) {
            return $http({
                method: 'get',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_USERS_ENDPOINT() + '/GetAllODJobs'
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return fact file access data");
                 }
             }, function (response) {
                 var resp = response;
                 //console.log("getRequestTypes service call failed");
                 return $q.reject(resp);
             });
        }

        function getODJobAccessWorker(authToken, payload) {
            return $http({
                method: 'get',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_USERS_ENDPOINT() + '/GetODJobAccess/' + payload.employeeId
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return all fact file data");
                 }
             }, function (response) {
                 var resp = response;
                 //console.log("getRequestTypes service call failed");
                 return $q.reject(resp);
             });
        }

        function saveLegacyUserAccessWorker(authToken, payload) {
            return $http({
                method: 'post',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_USERS_ENDPOINT() + '/SaveLegacyUserAccess',
                data: payload.data
            })
             .then(function (response) {
                 if (response.status == 200) {
                     return $q.when(response);
                 }
                 else {
                     return $q.reject("request call does not return future versions data");
                 }
             }, function (response) {
                 var resp = response;
                 //console.log("getRequestTypes service call failed");
                 return $q.reject(resp);
             });
        }

        function getAllDSApplicationsWorker(authToken, payload) {
            return $http({
                method: 'get',
                headers: { 'Authorization': authToken },
                url: serverVariableService.DATASCOOP_ENDPOINT() + '/ApplicationMgrService.svc/RestService/GetApplications?employeeId=' + payload.employeeId
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return fact file access data");
                 }
             }, function (response) {
                 var resp = response;
                 //console.log("getRequestTypes service call failed");
                 return $q.reject(resp);
             });
        }

        function saveUserWorker(authToken, payload) {
            return $http({
                method: 'post',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_USERS_ENDPOINT() + '/SaveUserInfo',
                data: payload.data
            })
         .then(function (response) {
             if (response.status == 200) {
                 return $q.when(response);
             }
             else {
                 return $q.reject("request call does not return future versions data");
             }
         }, function (response) {
             var resp = response;
             //console.log("getRequestTypes service call failed");
             return $q.reject(resp);
         });
        }

        function getAllReportsWorker(authToken, payload) {
            return $http({
                method: 'get',
                headers: { 'Authorization': authToken },
                url: serverVariableService.HOST_URL() + '/api/reporting/getreports'
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return fact file access data");
                 }
             }, function (response) {
                 var resp = response;
                 //console.log("getRequestTypes service call failed");
                 return $q.reject(resp);
             });
        }
    }

    function userProfileViewModel(employeeId, userId, accessObjectType) {
        var self = this;
        self.employeeId = employeeId,
        self.userId = userId,
        self.accessObjectType = accessObjectType
    }


}());