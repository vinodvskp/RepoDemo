﻿(function () {
    angular.module('vmApp')
  .service('onDemandJobsService', ['$q', '$http', 'constantService', 'authenticationService', 'serverVariableService', onDemandJobsService]);

    function onDemandJobsService($q, $http, constantService, authenticationService, serverVariableService) {
        var self = this;


        self.getAllODJobGroups = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getAllODJobGroupsWorker, successCallback, errorCallback);
        }

        self.getAllODJobsByGroupId = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getAllODJobsByGroupIdWorker, successCallback, errorCallback);
        }

        self.getODJobParamValues = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getODJobParamValuesWorker, successCallback, errorCallback);
        }

        self.getODJobAssociateParamValues = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getODJobAssocaiteParamValuesWorker, successCallback, errorCallback);
        }

        self.getODJobStatusByGeneration = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getODJobStatusByGenerationWorker, successCallback, errorCallback);
        }

        self.triggerODJob = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, triggerODJobWorker, successCallback, errorCallback);
        }

        function getAllODJobGroupsWorker(authToken, payload) {
            return $http({
                method: 'GET',
                headers: { 'Authorization': authToken },
                url: serverVariableService.ODJOBS_ENDPOINT() + '/GetAllODJobGroups',
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return groups data");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }

        function getAllODJobsByGroupIdWorker(authToken, payload) {
            return $http({
                method: 'GET',
                headers: { 'Authorization': authToken },
                url: serverVariableService.ODJOBS_ENDPOINT() + '/GetAllODJobs/' + payload.groupId,
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return groups data");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }

        function getODJobParamValuesWorker(authToken, payload) {
            return $http({
                method: 'GET',
                headers: { 'Authorization': authToken },
                url: serverVariableService.ODJOBS_ENDPOINT() + '/GetODJobParams/' + payload.paramId,
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     var modifiedResponse = { paramId: payload.paramId, data: response.data };
                     return $q.when(modifiedResponse);
                 }
                 else {
                     return $q.reject("request call does not return groups data");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }

        function getODJobAssocaiteParamValuesWorker(authToken, payload) {

            return $http({
                method: 'POST',
                headers: { 'Authorization': authToken },
                url: serverVariableService.ODJOBS_ENDPOINT() + '/GetODJobParams',
                data: payload
            })
             .then(function (response) {
                 if (response.status == 200) {

                     var modifiedResponse = { paramId: payload.ParamId, data: response.data };
                     return $q.when(modifiedResponse);
                 }
                 else {
                     return $q.reject("request call does not return recent activity data");
                 }
             }, function (response) {
                 var resp = response;
                 //console.log("getRequestTypes service call failed");
                 return $q.reject(resp);
             });
        }

        function getODJobStatusByGenerationWorker(authToken, payload) {
            return $http({
                method: 'GET',
                headers: { 'Authorization': authToken },
                url: serverVariableService.ODJOBS_ENDPOINT() + '/GetODJobStatus/' + payload.jobId + '/' + payload.generation,
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response);
                 }
                 else {
                     return $q.reject("request call does not return groups data");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }

        function triggerODJobWorker(authToken, payload) {

            return $http({
                method: 'POST',
                headers: { 'Authorization': authToken },
                url: serverVariableService.ODJOBS_ENDPOINT() + '/TriggerODJob',
                data: payload
            })
             .then(function (response) {
                 if (response.status == 200) {

                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return recent activity data");
                 }
             }, function (response) {
                 var resp = response;
                 //console.log("getRequestTypes service call failed");
                 return $q.reject(resp);
             });
        }
    }


}());