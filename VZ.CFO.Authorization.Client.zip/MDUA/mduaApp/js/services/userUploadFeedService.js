﻿(function () {

    angular.module('vmApp')
    	.service('userUploadFeedService', ['$q', '$http', 'constantService', 'authenticationService', 'serverVariableService', userUploadFeedService]);

    function userUploadFeedService($q, $http, constantService, authenticationService, serverVariableService) {

        var self = this;
        var deferredRequest = $q.defer();

        self.getDimYears = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getDimYearsWorker, successCallback, errorCallback);
        }

        self.getAllFileTypes = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getAllFileTypesWorker, successCallback, errorCallback);
        }

        self.uploadFactFile = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, uploadFactFileWorker, successCallback, errorCallback);
        }

        self.uploadFactData = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, uploadFactDataWorker, successCallback, errorCallback);
        }

        self.addKeysAndUploadFact = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, addKeysAndUploadFactWorker, successCallback, errorCallback);
        }

        self.getMaxUploadFileLimit = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getMaxUploadFileLimitWorker, successCallback, errorCallback);
        }

        self.getCurrentPeriod = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getCurrentPeriodWorker, successCallback, errorCallback);
        }

        function getCurrentPeriodWorker(authToken, payload) {
            return $http({
                method: 'GET',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/facttable/GetCurrentPeriod' + '/' + payload.factTableId,
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return groups data");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }

        function getDimYearsWorker(authToken, payload) {
            return $http({
                method: 'GET',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/facttableuserupload/GetDimYears',
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return groups data");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }

        function getAllFileTypesWorker(authToken, payload) {
            return $http({
                method: 'GET',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/facttable/GetFactFileTypesBasic',
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return groups data");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }

        function uploadFactFileWorker(authToken, payload) {
            return $http({
                method: 'POST',
                transformRequest: angular.identity,
                headers: { 'Authorization': authToken, 'Content-Type': undefined },
                url: serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/facttableuserupload/UploadFactFileBytes?fileName=' + payload.data.FileTypeName,
                data: payload.data.File
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return groups data");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }

        function uploadFactDataWorker(authToken, payload) {
            return $http({
                method: 'POST',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/facttableuserupload/UploadFactData',
                data: payload.data
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return groups data");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }

        function addKeysAndUploadFactWorker(authToken, payload) {
            return $http({
                method: 'POST',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/facttableuserupload/AddKeysAndUploadFact',
                data: payload.data
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return groups data");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }

        function getMaxUploadFileLimitWorker(authToken, payload) {
            return $http({
                method: 'GET',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/facttableuserupload/GetMaxUploadFileSize',
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return groups data");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }


    }
}());

