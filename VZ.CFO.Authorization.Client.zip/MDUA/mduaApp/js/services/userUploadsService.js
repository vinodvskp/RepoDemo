﻿
(function () {
    angular.module('vmApp')
.service('userUploadsService', ['$q', '$http', 'authenticationService', 'serverVariableService', userUploadsService]);

    function userUploadsService($q, $http, authenticationService, serverVariableService) {
        var self = this;

        self.getAllFactTable = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getAllFactTableWorker, successCallback, errorCallback);
        }

        function getAllFactTableWorker(authToken, payload) {
            return $http({
                method: 'GET',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/facttable/GetAllFactTables',
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return groups data");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }

        self.getFactTable = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getFactTableWorker, successCallback, errorCallback);
        }

        function getFactTableWorker(authToken, payload) {
            return $http({
                method: 'GET',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/facttable/GetFactFileTypes/' + payload.facttableId
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not returnFactFileTypes data");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }


        self.getFileType = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getFileTypeWorker, successCallback, errorCallback);
        }

        function getFileTypeWorker(authToken, payload) {
            return $http({
                method: 'POST',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/facttable/GetFactFileType',
                data: { FactTableId: payload.factTableId, FileTypeCodeId: payload.fileTypeCodeId }
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not returnFactFileTypes data");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }

        self.saveFiletype = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, saveFiletypeWorker, successCallback, errorCallback);
        }

        function saveFiletypeWorker(authToken, payload) {
            return $http({
                method: 'POST',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/facttable/SaveFactFileType',
                data: payload
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not returnFactFileTypes data");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }

        self.uploadFactFile = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, uploadFactFileWorker, successCallback, errorCallback);
        }

        function uploadFactFileWorker(authToken, payload) {
            return $http({
                method: 'POST',
                transformRequest: angular.identity,
                headers: { 'Authorization': authToken, 'Content-Type': undefined },
                url: serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/facttableuserupload/UploadFactFileBytes?fileName=' + payload.FileTypeName,
                data: payload.File
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not returnFactFileTypes data");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }

        self.uploadFactData = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, uploadFactDataWorker, successCallback, errorCallback);
        }

        function uploadFactDataWorker(authToken, payload) {
            return $http({
                method: 'POST',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/facttableuserupload/UploadFactData',
                data: payload
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("uploadFactDataWorker failed");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }

        self.addKeysFromStagedData = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, addKeysFromStagedDataWorker, successCallback, errorCallback);
        }

        function addKeysFromStagedDataWorker(authToken, payload) {
            return $http({
                method: 'POST',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/facttableuserupload/AddKeysFromStagedData/' + payload.RunStatusId + '/' + payload.FactTableId + '/' + payload.FileTypeCodeId
                //data: payload
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("uploadFactDataWorker failed");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }

        self.deleteFileType = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, deleteFileTypeWorker, successCallback, errorCallback);
        }

        function deleteFileTypeWorker(authToken, payload) {
            return $http({
                method: 'POST',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/facttable/DeleteFactFileType',
                data: payload
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("uploadFactDataWorker failed");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }

        self.getKeyCombinations = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getKeyCombinationsWorker, successCallback, errorCallback);
        }

        function getKeyCombinationsWorker(authToken, payload) {
            return $http({
                method: 'POST',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/facttable/GetKeyCombinations',
                data: payload
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("getKeyCombinationsWorker failed");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }

        self.deleteKeyCombinations = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, deleteKeyCombinationsTypeWorker, successCallback, errorCallback);
        }

        function deleteKeyCombinationsTypeWorker(authToken, payload) {
            return $http({
                method: 'POST',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/facttable/DeleteKeyCombinations',
                data: payload
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("getKeyCombinationsWorker failed");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }

        self.moveKeyCombinations = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, moveKeyCombinationsWorker, successCallback, errorCallback);
        }

        function moveKeyCombinationsWorker(authToken, payload) {
            return $http({
                method: 'POST',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/facttable/MoveKeyCombinations',
                data: payload
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("getKeyCombinationsWorker failed");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }

        self.getFactDownloadSignedUrl = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getFactDownloadSignedUrlWorker, successCallback, errorCallback);
        }

        function getFactDownloadSignedUrlWorker(authToken, payload) {
            return $http({
                method: 'POST',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/facttable/GetSignedUrlForKeyCombinations',
                data: payload
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("getFactDownloadSignedUrlWorker failed");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }

        self.DownloadKeyCombinations = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, moveKeyCombinationsWorker, successCallback, errorCallback);
        }

        function DownloadKeyCombinationsWorker(authToken, payload) {
            return $http({
                method: 'POST',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/facttable/DownloadKeyCombinations?FactTableId=' + payload.FactTableId + '&FileTypeCodeId=' + payload.FileTypeCodeId + '&SignedUrl',
                data: payload
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("DownloadKeyCombinationsWorker failed");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }

        function handleSuccessRequest(data, status, headers, config) {
            if (data != null) {
                deferredRequest.resolve(data);
            } else
                deferredRequest.reject('No Data Exception');
        }

        function handleFailureRequest(data) {
            deferredRequest.reject(data);
        }

    }

}());
