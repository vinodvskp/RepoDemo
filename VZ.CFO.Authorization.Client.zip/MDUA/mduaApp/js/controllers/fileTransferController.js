﻿
(function ($) {

    angular.module('vmApp')
        .controller('fileTransferController', ['$scope', 'fileTransferService', '$uibModal', 'spinnerService', 'serverVariableService','uiGridConstants','$filter',fileTransferController])
        .controller('removeModalInstanceController', ['$uibModalInstance',function ($uibModalInstance){
            var self = this;
             self.ok = function ($event) {
                  $uibModalInstance.close("OK");
             }
             self.cancel = function () {
               $uibModalInstance.dismiss('cancel');
             };
       
        }])
    function fileTransferController($scope, fileTransferService, $uibModal, spinnerService, serverVariableService,uiGridConstants,$filter) {
        var self = $scope;
        self.viewModel = new FileTransferPfofileViewModel();

        $scope.strLimit = 6;

        self.validationSummary = [];
        self.closeValidationSummary = function (index) {
            self.validationSummary.splice(index, 1);
        };

        self.availableFileTransferProfiles = [];
        self.selectedFTProfile = null;
        self.uploadedFileName = null;
        self.uploadedFileB64 = null;
        self.uploadedFile = null;
        self.selectedFile = null;
        $scope.folders = [];
        $scope.trash = [];
        $scope.dataToggle = true;
        $scope.selectedFTProfile = null;
        $scope.profilePath = [];
        $scope.folderInfo = null;
        $scope.searchArray = [];
        $scope.currentFolder = null;
        $scope.folderArray = [];
 
        //ftGridOptions
        self.ftGridOptions = {            
            rowTemplate: '<div ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.colDef.name" class="ui-grid-cell" ng-class="{ \'ui-grid-row-header-cell\': col.isRowHeader, \'red-text\': grid.appScope.rowFormatter( row ) }" ui-grid-cell></div>',
            enableRowSelection: true,
            enableRowHeaderSelection: true,
            multiSelect: false,
            modifierKeysToMultiSelect : false,
            noUnselect : true,
            enableFiltering: false,
            enableSorting: true,
            enableColumnMenus: false,
            columnDefs: self.viewModel.ListSearchColDefs,
            data: [],
            minRowsToShow: 14
        };

        //Edit cell values
        self.ftGridOptions.onRegisterApi = function (gridApi) {
            self.gridApi = gridApi;   
            self.gridApi.selection.on.rowSelectionChanged($scope, function (row) {
                if (row.isSelected === true) {
                    self.viewModel.selectedDataset = row.entity;
                }
                else {
                    self.viewModel.selectedDataset = null;
                }
            });

            self.gridApi.edit.on.afterCellEdit(self,function(rowEntity, colDef, newValue, oldValue){ 
                if(oldValue !== newValue) {
                    self.spinnerSemaphoreVM.addSemaphore();
                    self.ftGridOptions.data = [];
                    fileTransferService.renameFile({ fileName: rowEntity.Name, path: rowEntity.Path, profileId: $scope.selectedFTProfile.ProfileId }, renameCallback, errorCallback);
                }
             });  
        };

        self.showAlert = function (alertType, message) {
            self.validationSummary.push({ type: alertType, msg: message });
        }

        self.spinnerSemaphoreVM = new spinnerSemaphoreViewModel(spinnerService);

        self.onLoad = function () {
            self.spinnerSemaphoreVM.addSemaphore();
            fileTransferService.getFileTransferProfiles({}, getFileTransferProfilesCallback, errorCallback);
        };

        $scope.onFTProfileSelect = function (item) {
            $scope.uploadedFileName = null;
            $scope.uploadedFileB64 = null;
            $scope.uploadedFile = null;
            $scope.selectedFile = null;
            $scope.folders = [];
            $scope.trash = [];

            $scope.selectedFTProfile = item;
            $scope.loadFiles(self.selectedFTProfile.ProfileId, '');
        }

        self.onFileSelect = function (fileUpload) {
            var files = fileUpload.files;
            if (files.length > 0) {
                if (window.FormData !== undefined) {
                    var data = new FormData();
                    data.append("file0", files[0]);
                    self.uploadedFile = data;
                    self.uploadedFileName = files[0].name;
                    self.uploadedFileSize = files[0].size;
                    $scope.$apply();
                }
                else {
                    self.showAlert('danger', 'Your browser does not support file upload. Please use another browser.');
                }
            }
        };

        $scope.onUpload = function () {
            let transferRequest = null;
            if ($scope.selectedFTProfile == null) {
                $scope.showAlert('danger', 'Select a profile to transfer file.');
                return
            }

            if (!$scope.uploadedFileName) {
                $scope.showAlert('danger', 'You have to choose a file to upload.');
                return;
            }

            if ($scope.uploadedFileSize > $scope.selectedFTProfile.UploadLimit) {
                $scope.showAlert('danger', 'Your file exceeds the defined limit for uploading.');
                return;
            }
            $scope.ftGridOptions.data = [];
            $scope.selectedFile = null; //clear selected file if any
            $scope.spinnerSemaphoreVM.addSemaphore();
            if($scope.currentFolder === null){
                transferRequest = new FileTransferRequestViewModel($scope.selectedFTProfile.ProfileId, "", $scope.uploadedFileName, $scope.uploadedFile, "");
            } else{
                transferRequest = new FileTransferRequestViewModel($scope.selectedFTProfile.ProfileId, "", $scope.uploadedFileName, $scope.uploadedFile, $scope.currentFolder.Path);
            }
            fileTransferService.transferFile(transferRequest, uploadCallback, errorCallback);
        };

        $scope.loadFiles = function (profileId, path, forRefresh) {
            $scope.spinnerSemaphoreVM.addSemaphore();
            fileTransferService.listFolder({ profileId: profileId, path: path }).then(function (data) {
                if($scope.profilePath.length == 0){
                    $scope.profilePath.push(data.Folder.Name.toLocaleLowerCase());  
                    $scope.folderArray.push(data.Folder);
                }
                 $scope.selectedFTProfile.DefaultFileName = data.Folder.Name;
                 $scope.folderInfo = mapToFolderViewModel(data.Folder);
                 listView($scope.folderInfo,self);
                 searchView($scope.folderInfo.Files, self.searchArray)
                if (!forRefresh)
                    toFolders($scope.folderInfo);
                $scope.spinnerSemaphoreVM.reduceSemaphore();
            }).catch(function (err) {
                errorCallback(err);
            });
        };

        $scope.onNavClick = function (fileName, folders) {
            let oldProfilePath = $scope.profilePath;
            $scope.profilePath = [];
            if(($scope.selectedFTProfile.DefaultFileName.toLocaleLowerCase() === fileName) || (oldProfilePath[0] === fileName)){     
                $scope.profilePath.push(fileName);
                $scope.ftGridOptions.data = folders[0].Files;
                $scope.folderInfo = folders[0].Files;
            } else {
                $scope.profilePath.push(folders[0].Name.toLocaleLowerCase());
                for(var i=0;i<folders[0].Files.length;i++){
                    if(folders[0].Files[i].Name === fileName){
                        $scope.profilePath.push(fileName);
                        $scope.ftGridOptions.data = folders[0].Files[i].Files;
                        $scope.folderInfo = folders[0].Files[i].Files;
                    } else if(folders[0].Files[i].Files !== null  && folders[0].Files[i].Name === oldProfilePath[1]){
                        for(var j=0;j<folders[0].Files[i].Files.length > 0;j++){
                            if(folders[0].Files[i].Files[j].Name === fileName){
                                $scope.profilePath.push(folders[0].Files[i].Name);
                                $scope.profilePath.push(folders[0].Files[i].Files[j].Name);
                                $scope.ftGridOptions.data = folders[0].Files[i].Files[j].Files;
                                $scope.folderInfo = folders[0].Files[i].Files[j].Files;
                            }

                        }
                    }
                }
            }
        };
        

        //Loding all data into singe flatten array
        function searchView(folderData, searchArray){
            for(var i=0;i<folderData.length;i++){
                if(folderData[i].IsDirectory && folderData[i].Files.length > 0){
                    self.searchArray.push(folderData[i]);
                    if(folderData[i].Files.length > 0){
                        nestedSubFolders(folderData[i].Files,searchArray);
                    }
                   
                } else{
                    self.searchArray.push(folderData[i]);
                }
                
            }
        }
       function nestedSubFolders(folderData,searchArray){
            for(var j=0;j<folderData.length;j++){
                if(folderData[j].IsDirectory && folderData[j].Files.length > 0){
                    self.searchArray.push(folderData[j]);
                    searchView(folderData[j].Files, searchArray)
                }else{
                    self.searchArray.push(folderData[j]);
                }
            }
       }

       $scope.refreshData = function() {
        $scope.ftGridOptions.data = $filter('filter')($scope.searchArray, $scope.searchText);
      };
        $scope.onDownload = function () {
            $scope.selectedFile = self.gridApi.selection.getSelectedRows()[0];
            if (!$scope.selectedFile) {
                $scope.showAlert('danger', 'Please select a file for downloading.');
            }
            else if($scope.selectedFile.Length > $scope.selectedFTProfile.DownloadLimit) {
                $scope.showAlert('danger', 'File size exceed the defined limit.')
            }
            else {
                $scope.spinnerSemaphoreVM.addSemaphore();
                fileTransferService.getSignedKey({ path: $scope.selectedFile.Path }).then(function (data) {
                    toDownLoad(data);
                    $scope.spinnerSemaphoreVM.reduceSemaphore();
                }).catch(function (err) {
                    errorCallback(err);
                });
            }
        };

        $scope.onDelete = function () {
        var modalInstance = $uibModal.open({
            templateUrl: 'removeModalContent.html', //refers to modal content
            controller: 'removeModalInstanceController as rmc', //inner controller
            scope: $scope, //scope elements
            ariaLabelledBy: 'modal-title',
            ariaDescribedBy: 'modal-body',
        });

        modalInstance.result.then(function (confirm) {
            $scope.selectedFile = self.gridApi.selection.getSelectedRows()[0];
            if (!$scope.selectedFile) {
               $scope.showAlert('danger', 'Please select a file for delete...');
            } 
            $scope.presentFolderData = $scope.ftGridOptions.data;
            $scope.ftGridOptions.data = []; 
            $scope.spinnerSemaphoreVM.addSemaphore();
            fileTransferService.deleteFile({profileId : $scope.selectedFTProfile.ProfileId, path:$scope.selectedFile.Path }, deleteCallback, errorCallback);
            }, function () {
              console.log('Modal dismissed at: ' + new Date());
            });
        };
    
        $scope.notDownloadable = function () {
            return $scope.selectedFTProfile == null ? true : !($scope.selectedFTProfile.Permission & 1);
        };

        $scope.notUploadable = function () {
            return $scope.selectedFTProfile == null ? true : !($scope.selectedFTProfile.Permission & 2);
        };

        $scope.onRefresh = function () {
            if($scope.currentFolder === null){
                $scope.loadFiles($scope.selectedFTProfile.ProfileId, "", true);
            }else{
                let profilePathName =  $scope.profilePath.pop();
                $scope.profilePath.push(profilePathName);
                for(var i=0;i<$scope.folderArray.length;i++){
                    if((profilePathName == $scope.folderArray[i].Name) || profilePathName == $scope.folderArray[i].Name.toLocaleLowerCase()){
                        $scope.currentFolder = $scope.folderArray[i];
                    }
                }
                if($scope.currentFolder.Path === null){
                    $scope.currentFolder.Path = "";
                }
                $scope.loadFiles($scope.selectedFTProfile.ProfileId, $scope.currentFolder.Path, true);
            }   
        };

        $scope.onToggle = function (){
            $scope.folderInfo = $scope.ftGridOptions.data;
            $scope.dataToggle = !$scope.dataToggle;
        }

        $scope.renderFolderText = function (v){
            console.log(v);
            return '<div>test</div>'
        }

        function getFileTransferProfilesCallback(response) {
            self.availableFileTransferProfiles.splice(0, self.availableFileTransferProfiles.length);
            for (var idx = 0; idx < response.length; idx++) {
                self.availableFileTransferProfiles.push(new FileTransferViewModel(response[idx]));
            }
            self.spinnerSemaphoreVM.reduceSemaphore();
        }

        function uploadCallback(response) {
            self.showAlert('success', 'File Successfully uploaded.');
            let folderInfo = mapToFolderViewModel(response.Folder);
            self.ftGridOptions.data = folderInfo.Files;
            $scope.uploadedFileName = null;
            document.querySelector('.import-file input[type=file]').value = null;
            self.spinnerSemaphoreVM.reduceSemaphore();
        }

        function deleteCallback(response) {
            self.showAlert('success', 'File Successfully deleted.');
            var i = self.presentFolderData.indexOf(self.selectedFile);
            if(i != -1) {
                self.presentFolderData.splice(i, 1);
            }
            self.ftGridOptions.data = self.presentFolderData;
            self.spinnerSemaphoreVM.reduceSemaphore();
        }

        function renameCallback(response) {
            if(response.Folder != null){
                self.showAlert('success', 'File Successfully Updated.');
                if(self.folderInfo.Files != null && self.folderInfo.Files.length > 0){
                    self.folderInfo = self.folderInfo.Files;
                }
                if(self.folderInfo.length>0){
                    for(var i=0;i<self.folderInfo.length;i++){
                        if (self.folderInfo[i].Path === response.Folder.Oldpath) {
                            self.folderInfo[i].Name = response.Folder.Name;
                            self.folderInfo[i].Path = response.Folder.Path;
                        }
                    }
                } else if (self.folderInfo.Path === response.Folder.Oldpath) {
                    self.folderInfo.Name = response.Folder.Name;
                    self.folderInfo.Path = response.Folder.Path;
                }
            }
            self.ftGridOptions.data = self.folderInfo;          
            self.spinnerSemaphoreVM.reduceSemaphore();
        }

        function errorCallback(data) {
            self.validationSummary.push({ type: 'danger', msg: 'Error occured. Refresh the page and try again.' });
            self.spinnerSemaphoreVM.reduceSemaphore();
        }

        function toFolders(folder) {
            $scope.folders.push(folder);
        }

        function listView(folderInfo,self){
         //  self.orginalData = folderInfo;
           self.ftGridOptions.data = folderInfo.Files;
         //  self.options.data = folderInfo.Files;
        }

        function updateCurrentFolder(folder) {
             $scope.folders.splice(-1, 1, folder);
        }
        function toDownLoad(token) {
            let url = fileTransferService.getDownloadUrl() + '?profileid=' + $scope.selectedFTProfile.ProfileId + '&path=' + $scope.selectedFile.Path + '&signedUrl=' + token;
            window.open(url);
        }

        function mapToFolderViewModel(folderFromServer) {
            for(var i=0;i<folderFromServer.Files.length;i++){
                var extn = getFileExtension(folderFromServer.Files[i].Name,folderFromServer.Files[i].IsDirectory);
               folderFromServer.Files[i]['fileType'] = extn;
            }
            return folderFromServer;
        }

        // Adding file extension type for list, icon view
        function getFileExtension(name, directory){
            let fileType = null;
            if(!directory){
                let fileName = name;
                let extn = fileName.substr(fileName.lastIndexOf('.')+1).toLowerCase();
                if(extn === "pdf"){
                    fileType = "Adobe Acrobat Document";
                }else if(extn === "txt"){
                    fileType = "Text File";
                }else if(extn === "docx" || extn ==="doc"){
                    fileType = "Microsoft Word Document";
                }else if(extn === "xlsx" || extn ==="xls"){
                    fileType = "Microsoft Excel Worksheet";
                }
            } else if(directory) {
                fileType = "File folder";
            }  
            return fileType; 
        }
        
        // loading inisde folder data - icon view
        $scope.onItemSelect = function (file) {
            loadUpdatedCellData(file,self);
        };

        // loading inisde folder data - list view
        $scope.reLoad = function(row, $event) {
            loadUpdatedCellData(row.entity,self);
      
        }
        //commom function to load update data for list view and folder view
        function loadUpdatedCellData(entity,self){
            $scope.currentFolder = entity;
            $scope.folderArray.push(entity);
            self.spinnerSemaphoreVM.addSemaphore();
            self.ftGridOptions.data = [];
            let profileName = $scope.selectedFTProfile.ProfileName.toLocaleLowerCase();
            self.profilePath.push(entity.Name);
            self.folderInfo = entity.Files;
            listView(entity,self);
            self.spinnerSemaphoreVM.reduceSemaphore();
        }


        self.onLoad();
    }


     //view Search Model
     function FileTransferPfofileViewModel() {
        var self = this;
        self.RowsPerPage = 200;
     
        //ColumnDefs for Users View
        self.ListSearchColDefs = [
                            { name: 'isDirectory', displayName: 'isDirectory', field: 'IsDirectory', enableCellEdit: false,visible: false }, 
                            { name: '', displayName: '', field: 'view', enableCellEdit: false, width: "1%",cellTemplate: '<i ng-if="row.entity.IsDirectory == true" class="fa fa-folder" aria-hidden="true" ng-click="grid.appScope.reLoad(row, $event)" style="font-size: 15px;margin-left:5px;padding-top:10px;"></i><i ng-if="row.entity.IsDirectory == false" class="fa fa-3x fa-file-text-o" style="font-size: 15px;margin-left:5px;padding-top:10px;"></i>' }, 
                            { name: 'Name', displayName: 'Name', field: 'Name', enableCellEdit: true, cellTemplate: '<span style="line-height:32px;">{{row.entity.Name}}</span>' },
                            { name: 'Path', displayName: 'Path', field: 'FullName', enableCellEdit: false, width: "25%"},
                            { name: 'DateModified', displayName: 'Date Modified', field: 'LastModifiedTime', enableCellEdit: false, width: "15%"},
                            { name: 'Type', displayName: 'Type', field: 'fileType', enableCellEdit: true, width: "20%" },
                            { name: 'Size', displayName: 'Size', field: 'Length', enableCellEdit: false,  width: "10%" }
        ];
    }

    function renderFolderText(v) {
        console.log(v);
        return '<div>test</div>' 
    }
    

    //view models
    function FileTransferViewModel(fileTransferProfile) {
        "use strict";
        this.ProfileId = fileTransferProfile.ProfileId;
        this.ProfileName = fileTransferProfile.ProfileName;
        this.DefaultFileName = fileTransferProfile.DefaultFileName;
        this.TransferType = fileTransferProfile.TransferType;
        this.TargetDirectory = fileTransferProfile.TargetDirectory;
        this.selectedFTProfileFlag = true;
        this.DownloadLimit = fileTransferProfile.DownloadLimit;
        this.UploadLimit = fileTransferProfile.UploadLimit;
        this.Filter = fileTransferProfile.Filter;
        this.Permission = fileTransferProfile.Permission;

        this.Files = [];
    }

    function FileTransferRequestViewModel(profileId, fileBase64String, fileName, file, path) {
        "use strict";
        this.ProfileId = profileId;
        this.FileBase64String = fileBase64String;
        this.FileName = fileName;
        this.File = file;
        this.Path = path;
    }

    function spinnerSemaphoreViewModel(spinnerService) {
        var self = this;
        self.semaphore = 0;
        self.addSemaphore = function () {
            self.semaphore++;
            if (self.semaphore == 1) {
                spinnerService.show("overlaySpinner");
            }
        };
        self.reduceSemaphore = function () {
            self.semaphore--;
            if (self.semaphore == 0) {
                spinnerService.hide("overlaySpinner");
            }
        };
    }    
})(window.jQuery);
