﻿
(function ($) {

    angular.module('vmApp')
        .controller('userFactDataUploadStepController', ['$scope', '$state', '$stateParams', '$location', 'userUploadFeedService', '$uibModal', 'spinnerService', 'serverVariableService', 'factDownloadService', userFactDataUploadStepController])


    function userFactDataUploadStepController($scope, $state, $stateParams, $location, userUploadFeedService, $uibModal, spinnerService, serverVariableService, factDownloadService) {

        var self = $scope;

        self.$parent.FactDataUploadChildScope = $scope;

        self.fileUploadTabVM = null;
        self.CurrentStep = null;

        self.FileTypeId = $stateParams[0]; //$location.search().fileTypeId;
        //self.FileTypeCode = $location.search().fileTypeCode;

        //response grid
        self.responseGridVM = null;
        self.responseGridViewUrl = serverVariableService.SITE_SUBFOLDER() + "mduaApp/templates/responseTableView.html";

        self.validationStepVM = null;

        function fileLoaded(filename, dataUri) {
            var strArray = dataUri.split(",");
            var base64Str = strArray[strArray.length - 1];

            self.fileUploadTabVM.FileForUploadInbase64 = base64Str;
            self.fileUploadTabVM.FileDisplayText = filename;
            self.fileUploadTabVM.IsFileLoading = "complete";

            $scope.$apply();
        }

        var initializeDragAndDrop = function (dropperElmClassName) {
            if (typeof window.FileReader === 'undefined')
                alert('File API & FileReader not supported');

            var dropper = $(dropperElmClassName)[0];
            dropper.ondragover = function () { $(dropper).addClass('hover'); return false; };
            dropper.ondragend = function () { $(dropper).removeClass('hover'); return false; };

            dropper.ondrop = function (e) {

                self.fileUploadTabVM.IsFileLoading = "loading";
                $scope.$apply();


                e.preventDefault();
                var files = [].slice.call(e.dataTransfer.files);
                if (files.length > 0 && window.FormData !== undefined) {
                    var data = new FormData();
                    data.append("file0", files[0]);
                    self.fileUploadTabVM.File = data;
                    self.fileUploadTabVM.IsFileLoading = "complete";
                    self.fileUploadTabVM.FileDisplayText = files[0].name;
                    $scope.$apply();
                }
                else {
                    alert('Your browser does not support upload. Please use another browser.');
                }
                //files.forEach(function (file) {
                //    var reader = new FileReader();
                //    reader.onload = function (event) {
                //        fileLoaded(file.name, event.target.result);
                //    };
                //    reader.readAsDataURL(file);
                //    $(dropper).removeClass('hover');
                //});
                return false;
            };
        }

        self.onLoad = function () {
            if (self.$parent.CurrentStep == 0) {
                $state.go("userUploadFeed");
            }
            else {
                initializeDragAndDrop(".dropper");
                self.gotoChildStep(2);
                self.initController();
            }
        }

        self.onSelectMonth = function (selectedMonth) {
            self.fileUploadTabVM.SelectedMonth = selectedMonth;
        }

        self.onSelectYear = function (selectedYear) {
            self.fileUploadTabVM.SelectedYear = selectedYear;
        }

        self.onFileSelect = function (fileUpload) {
            self.fileUploadTabVM.IsFileLoading = "loading";
            $scope.$apply();
            var files = fileUpload.files;
            if (files.length > 0) {
                if (window.FormData !== undefined) {
                    var data = new FormData();
                    data.append("file0", files[0]);
                    self.fileUploadTabVM.File = data;
                    self.fileUploadTabVM.IsFileLoading = "complete";
                    self.fileUploadTabVM.FileDisplayText = files[0].name;
                    $scope.$apply();
                }
                else {
                    self.$parent.showAlert('danger', 'Your browser does not support file upload. Please use another browser.');
                }
                //var fileReader = new FileReader();
                //fileReader.readAsDataURL(files[0]);

                //fileReader.onload = function (event) {
                //    self.fileUploadTabVM.FileForUploadInbase64 = event.target.result.split(',')[1];
                //    self.fileUploadTabVM.FileDisplayText = files[0].name;
                //    self.fileUploadTabVM.IsFileLoading = "complete";
                //    $scope.$apply();
                //}
            }


        }

        self.onCancelUpload = function () {
            $("#fileform")[0].reset();
            self.fileUploadTabVM.FileForUploadInbase64 = null;
            self.fileUploadTabVM.FileDisplayText = null;
            self.fileUploadTabVM.IsFileLoading = "complete";
        }

        self.onVerify = function () {
            if (self.validateStep()) {
                if (self.CurrentStep >= 2) {
                    self.processStep(true);
                }
            }
        }

        self.onNext = function () {       
            if (self.validateStep()) {
                if (self.CurrentStep >= 2) {
                    self.processStep();
                }
            }
        }

        self.onBack = function () {
            if (self.CurrentStep === 3 || self.CurrentStep === 4) {
                self.CurrentStep = 2;
                self.$parent.setCurrentStep(2);
            }
            else if (self.CurrentStep === 2) {
                self.CurrentStep = null;
                //self.$parent.setCurrentStep(1);
                self.$parent.gotoStep(2, 1);
            }
        }

        self.validateStep = function () {
            var isValidatedSuccess = true;
            if (self.CurrentStep == 2) {
                //check if month and year are selected
                if (self.fileUploadTabVM.SelectedMonth == null) {
                    isValidatedSuccess = false;
                    self.$parent.showAlert('danger', 'Select Month to proceed');
                }

                if (self.fileUploadTabVM.SelectedYear == null) {
                    isValidatedSuccess = false;
                    self.$parent.showAlert('danger', 'Select Month to year');
                }

                if (self.fileUploadTabVM.File == null) {
                    isValidatedSuccess = false;
                    self.$parent.showAlert('danger', 'Choose .xls or .xlsx file to proceed');
                }
            }

            return isValidatedSuccess;
        }

        self.processStep = function (verifyOnly) {

            if (self.CurrentStep == 2) {
                //upload file
                var fileRequest = new UploadFactFileViewModel(serverVariableService.USER_EID(), self.fileUploadTabVM.FileDisplayText, '', self.fileUploadTabVM.File);
                //spinner logic
                self.spinnerSemaphoreVM.addSemaphore();
                userUploadFeedService.uploadFactFile({ data: fileRequest }, function (response) { uploadFactFileCallback(response, verifyOnly); }, errorCallback);
                //upload data
            }
            else if (self.CurrentStep == 3) {

                if (self.validationStepVM != null && self.validationStepVM.ProcessStatus == 1) {
                    var request = new FileUploadRequestViewModel("", "", "",
                    self.$parent.SelectedFactTable.FactTableId, self.$parent.SelectedFileType.FileTypeCodeId, "", "", self.validationStepVM.RunStatusId);
                    //spinner logic
                    self.spinnerSemaphoreVM.addSemaphore();
                    userUploadFeedService.addKeysAndUploadFact({ data: request }, uploadFactDataCallback, errorCallback);
                }
                else {
                    self.onLoad();
                }

            }
            else if (self.CurrentStep == 4) {
                self.onLoad();
            }
        }

        self.gotoChildStep = function (stepNumber) {
            if (self.canGotoStep(stepNumber)) {
                self.CurrentStep = stepNumber;
                self.$parent.setCurrentStep(stepNumber);
                //self.$parent.CurrentStep = stepNumber;
                return true;
            }
            else {
                return false;
            }
        }

        self.canGotoStep = function (stepNumber) {

            if (self.CurrentStep == null && stepNumber == 2) {
                return true;
            }

            if (self.CurrentStep == stepNumber) {
                return false;
            }

            if (self.fileUploadTabVM.UploadedDataContainsErrors == null && (stepNumber == 3 || stepNumber == 4)) {
                return false;
            }

            if (self.fileUploadTabVM.UploadedDataContainsErrors == true && stepNumber == 4) {
                return false;
            }

            if (self.fileUploadTabVM.UploadedDataContainsErrors == false && stepNumber == 3) {
                return false;
            }

            return true;
        }

        self.onDownloadFact = function () {

            var reportingPeriod = self.fileUploadTabVM.SelectedYear + '' + self.fileUploadTabVM.SelectedMonth.id;

            var factDownloadrequest = new FactDownloadRequestViewModel(self.$parent.SelectedFactTable.FactTableId,
                self.$parent.SelectedFileType.FileTypeCodeId,
                reportingPeriod, reportingPeriod, '');

            self.spinnerSemaphoreVM.addSemaphore();
            factDownloadService.getFactDownloadSignedUrl(factDownloadrequest, getFactDownloadSignedUrlCallback, errorCallback);
        }

        self.initController = function () {
            self.responseGridVM = null;
            self.validationStepVM = null;
            self.fileUploadTabVM = new FileUploadTabViewModel();
            //Load Dimension Years
            if (self.fileUploadTabVM.AvailableYears.length == 0) {
                userUploadFeedService.getDimYears([], getDimYearsCallback, errorCallback);
            }
            //clear upload
            self.onCancelUpload();
            //set MaxUploadFileSize
            self.fileUploadTabVM.MaxUploadFileSize = self.$parent.MaxUploadFileSize;
        }

        //callback
        function getDimYearsCallback(response) {

            //clear available years list
            self.fileUploadTabVM.AvailableYears.splice(0, self.fileUploadTabVM.AvailableYears.length);
            self.fileUploadTabVM.SelectedYear = null;

            for (var idx = 0; idx < response.length; idx++) {
                self.fileUploadTabVM.AvailableYears.push(response[idx]);
            }

            //set current period            
            if (self.$parent != null) {
                self.fileUploadTabVM.SelectedYear = self.$parent.SelectedFactTable.currentYear; //self.$parent.FactTableSettings.CurrentYear;
                //var findMonth = $.grep(self.fileUploadTabVM.AvailableMonths, function (p) { return p.id == self.$parent.FactTableSettings.CurrentMonth; });
                var findMonth = $.grep(self.fileUploadTabVM.AvailableMonths, function (p) { return p.id == self.$parent.SelectedFactTable.currentMonth; });
                if (findMonth.length == 1) {
                    self.fileUploadTabVM.SelectedMonth = findMonth[0];
                }
            }



        }

        function getFactDownloadSignedUrlCallback(response) {
            self.spinnerSemaphoreVM.reduceSemaphore();
            var reportingPeriod = self.fileUploadTabVM.SelectedYear + '' + self.fileUploadTabVM.SelectedMonth.id;
            var exportUrl = serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/facttable/DownloadFactTable';
            exportUrl = exportUrl + '?FactTableId=' + self.$parent.SelectedFactTable.FactTableId + "&FileTypeCodeId=" + self.$parent.SelectedFileType.FileTypeCodeId;
            exportUrl = exportUrl + '&StartPeriod=' + reportingPeriod + "&EndPeriod=" + reportingPeriod;
            exportUrl = exportUrl + '&SignedUrl=' + response + "&RunStatusId=" + (!!self.runstatusid ? self.runstatusid : '');
            window.open(exportUrl);
        }

        function uploadFactFileCallback(response, verifyOnly) {

            if (response.length > 0) {

                //spinner logic
                self.spinnerSemaphoreVM.reduceSemaphore();

                var request = new FileUploadRequestViewModel("", self.fileUploadTabVM.FileDisplayText,
                    response, self.$parent.SelectedFactTable.FactTableId, self.$parent.SelectedFileType.FileTypeCodeId, self.fileUploadTabVM.SelectedMonth.id,
                    self.fileUploadTabVM.SelectedYear, "", verifyOnly);

                //spinner logic
                self.spinnerSemaphoreVM.addSemaphore();
                userUploadFeedService.uploadFactData({ data: request }, uploadFactDataCallback, errorCallback);
            }

        }


        function showTransactionLevelMessages(transactionMessageList) {
            for (var tlErrorInd = 0; tlErrorInd < transactionMessageList.length; tlErrorInd++) {
                //TL Error
                if (transactionMessageList[tlErrorInd].MessageType == -1) {
                    var rlErrorMessages = transactionMessageList[tlErrorInd].Messages;
                    for (var errorMsgInd = 0; errorMsgInd < rlErrorMessages.length; errorMsgInd++) {
                        self.$parent.showAlert('danger', rlErrorMessages[errorMsgInd]);
                    }
                }
                    //TL Warning
                else if (transactionMessageList[tlErrorInd].MessageType == -2) {
                    var rlWarningMessages = transactionMessageList[tlErrorInd].Messages;
                    for (var warningMsgInd = 0; warningMsgInd < rlWarningMessages.length; warningMsgInd++) {
                        self.$parent.showAlert('warning', rlWarningMessages[warningMsgInd]);
                    }
                }
            }
        }

        function uploadFactDataCallback(response) {
            var r = response;
            //spinner logic
            self.spinnerSemaphoreVM.reduceSemaphore();

            if (response.MessageType == 1 || response.MessageType == 3) {
                self.$parent.showAlert('danger', response.Message);
                if (response.ResponseTableColumns != null && response.ResponseTableData != null) {
                    self.responseGridVM = new ResponseDataGridViewModel(response.ResponseTableColumns, response.ResponseTableData);
                }
                self.fileUploadTabVM.UploadedDataContainsErrors = true;
                self.validationStepVM = new ValidationStepViewModel(response.RunStatusId, response.StageProcessStatus);

                
                self.gotoChildStep(3);
            }

            if (response.MessageType == 2) {
                self.spinnerSemaphoreVM.addSemaphore();

                if (response.ResponseTableColumns != null && response.ResponseTableData != null) {
                    self.responseGridVM = new ResponseDataGridViewModel(response.ResponseTableColumns, response.ResponseTableData);

                }
                self.fileUploadTabVM.UploadedDataContainsErrors = false;
                self.runstatusid = response.RunStatusId;
                self.gotoChildStep(4);
                
                self.$parent.showAlert('success', response.Message);
                self.spinnerSemaphoreVM.reduceSemaphore();
            }

            showTransactionLevelMessages(response.TransactionalMessages);
        }




        function errorCallback(data) {
            self.$parent.showAlert('danger', 'Error occured. Refresh the page and try again.');
            self.spinnerSemaphoreVM.reduceSemaphore();
            console.log(data);
        }

        self.onLoad();

    }


    //view model
    function FileUploadTabViewModel() {
        var self = this;
        self.AvailableMonths = [];
        self.AvailableYears = [];
        self.SelectedMonth = null;
        self.SelectedYear = null;
        self.FileForUploadInbase64 = null;
        self.FileDisplayText = null;
        self.IsUploaded = false;

        self.File = null;

        self.AvailableFileTypes = [];
        self.SelectedFileType = null;

        self.UploadedDataContainsErrors = null;

        self.IsFileLoading = "complete";

        self.setAvailableMonths = function () {
            //clear months list if present
            self.AvailableMonths.splice(0, self.AvailableMonths.length);
            self.AvailableMonths.push({ id: '01', value: 'January' });
            self.AvailableMonths.push({ id: '02', value: 'February' });
            self.AvailableMonths.push({ id: '03', value: 'March' });
            self.AvailableMonths.push({ id: '04', value: 'April' });
            self.AvailableMonths.push({ id: '05', value: 'May' });
            self.AvailableMonths.push({ id: '06', value: 'June' });
            self.AvailableMonths.push({ id: '07', value: 'July' });
            self.AvailableMonths.push({ id: '08', value: 'August' });
            self.AvailableMonths.push({ id: '09', value: 'September' });
            self.AvailableMonths.push({ id: '10', value: 'October' });
            self.AvailableMonths.push({ id: '11', value: 'November' });
            self.AvailableMonths.push({ id: '12', value: 'December' });
            self.AvailableMonths.push({ id: '00', value: 'Beginning Balance' });
        }
        self.setAvailableMonths();

        self.MaxUploadFileSize = null;
    }

    function ValidationStepViewModel(runStatusId, processStatus) {
        var self = this;
        self.RunStatusId = runStatusId;
        self.ProcessStatus = processStatus;
    }

    function UploadFactFileViewModel(userId, fileTypeName, base64EncodedFile, file) {
        var self = this;
        self.UserId = userId;
        self.FileTypeName = fileTypeName;
        self.Base64EncodedFile = base64EncodedFile;
        self.File = file;
    }

    function FileUploadRequestViewModel(userId, uploadedFileName, signedUrl, factTableId, fileTypeCodeId, month, year, runStatusId, verifyOnly) {

        var self = this;
        self.UserId = userId;
        self.UploadedFileName = uploadedFileName;
        self.SignedUrl = signedUrl;
        self.FactTableId = factTableId;
        self.FileTypeCodeId = fileTypeCodeId;
        self.ReportingPeriod = { Month: month, Year: year };
        self.UploadProcessType = 0;
        self.RunStatusId = runStatusId;
        self.IsVerifyOnly = !!verifyOnly;
    }

    function ResponseDataGridViewModel(columns, data) {
        var self = this;

        self.Columns = columns;
        self.Data = data;
        self.Rows = [];
        self.GridColumnDefs = [];

        self.getGridWidth = function () {
            return $('#userUploadFeedGrid').width();
        };

        self.calculateTotalColumnWidth = function (colList) {
            var totalColWidth = 0;
            var colListVM = { "totalColWidth": totalColWidth, "colWidthList": [] };
            for (var colInd = 0; colInd < colList.length; colInd++) {
                var colWidth = self.calculateColWidth(colList[colInd]);
                colListVM.totalColWidth = colListVM.totalColWidth + colWidth;
                colListVM.colWidthList.push(colWidth);
            }
            return colListVM;
        }

        self.isColumnWidthComputationNeeded = function (colList, gridWidth) {
            var colListVM = self.calculateTotalColumnWidth(colList);
            var isNeeded = false;
            if (colListVM.totalColWidth > gridWidth) {
                isNeeded = true;
            }
            $.extend(colListVM, { "isColWidthComputeNeeded": isNeeded });
            return colListVM;
        }

        self.calculateColWidth = function (columnText) {
            var coltextLength = columnText.length;
            return (coltextLength * 15);
        }

        self.PivotData = function () {

            //
            var colListVM = self.isColumnWidthComputationNeeded(self.Columns, self.getGridWidth());

            for (var colIndex = 0; colIndex < self.Columns.length; colIndex++) {
                var colDef = new GridColumnDefViewModel(self.Columns[colIndex], 'Data[' + colIndex + ']', true, (colListVM.isColWidthComputeNeeded === true ? self.calculateColWidth(self.Columns[colIndex]) : ''));
                self.GridColumnDefs.push(colDef);
            }

            for (var rowIndex = 0; rowIndex < self.Data[0].Values.length; rowIndex++) {
                var trvm = new TableRowViewModel();

                for (var colIndex = 0; colIndex < self.Data.length; colIndex++) {
                    trvm.Data.push(self.Data[colIndex].Values[rowIndex]);
                }
                self.Rows.push(trvm);

            }
            //for (var rowIndex = 0; rowIndex < self.Data[0].length; rowIndex++) {
            //    var trvm = new TableRowViewModel();
            //    //trvm.RowId = rowIndex;

            //    //push empty data for validation
            //    trvm.Data.push("");
            //    for (var colIndex = 0; colIndex < self.Data.length; colIndex++) {
            //        trvm.Data.push(self.Data[colIndex][rowIndex]);

            //        self.Rows.push(trvm);
            //    }
            //}
        };

        self.gridOptions = {
            enableSelectAll: true,
            enableRowSelection: true,
            enableFiltering: false,
            enableSorting: true,
            columnDefs: self.GridColumnDefs,
            data: self.Rows,
            showGridFooter: true,
            exporterPdfDefaultStyle: { fontSize: 9 },
            exporterPdfTableStyle: { margin: [30, 30, 30, 30] },
            exporterPdfTableHeaderStyle: { fontSize: 10, bold: true, italics: true, color: 'red' },
            exporterPdfHeader: { text: "My Header", style: 'headerStyle' },
            exporterPdfFooter: function (currentPage, pageCount) {
                return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
            },
            exporterPdfCustomFormatter: function (docDefinition) {
                docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
                docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
                return docDefinition;
            },
            exporterPdfOrientation: 'portrait',
            exporterPdfPageSize: 'LETTER',
            exporterPdfMaxGridWidth: 500,
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location"))
        };


        self.createGrid = function (columns, data) {
            //self.clearGrid();
            self.gridOptions = new GridOptionsViewModel(false, false, columns, data, 20);
        }

        self.clearGrid = function () {
            self.gridOptions = null;
            //raise event
        }


        if (self.Columns.length > 0) {
            self.PivotData();
        }


        //self.createGrid();
    }

    function TableRowViewModel() {
        var self = this;
        self.Data = [];
        self.IsSelected = false;
    }

    function GridColumnDefViewModel(name, field, isVisible, width) {
        var self = this;
        self.name = name;
        self.field = field;
        self.enableCellEdit = false;
        self.visible = isVisible;

        if (width != null && width != '') {
            self.width = width;
        }

        //self.cellClass = function (grid, row, col, rowRenderIndex, colRenderIndex) {
        //    if (row.entity.ValidationType == "1") {
        //        return "red";
        //    }
        //};
        self.filter = undefined;


    }

    function GridOptionsViewModel(enableFiltering, enableSorting, columns, data, minRowsToShow) {
        var self = this;

        self.columnDefs = [];

        for (var colInd = 0; colInd < columns.length; columns++) {
            self.columnDefs.push({ name: columns[colInd], field: columns[colInd], enableCellEdit: false, width: 200 });
        }

        self.enableFiltering = enableFiltering;
        self.enableSorting = enableSorting;
        self.data = data;
        self.minRowsToShow = minRowsToShow;
    }

    function FactDownloadRequestViewModel(factTableId, fileTypeCodeId, startPeriod, endPeriod, signedUrl) {
        var self = this;
        self.FactTableId = factTableId;
        self.FileTypeCodeId = fileTypeCodeId;
        self.StartPeriod = startPeriod;
        self.EndPeriod = endPeriod;
        self.SignedUrl = signedUrl;
    }


})(window.jQuery);