﻿(function (module) {

    module.controller('userUploadsController', ["$scope", "$uibModal", "$state", "$q", "userUploadsService", "alertingService", "spinnerService", "mainService", "userProfileService", "userUploadFeedService",
        function userUploadsController($scope, $uibModal, $state, $q, userUploadsService, alertingService, spinnerService, mainService, userProfileService, userUploadFeedService) {
            $scope.heading = "Manage Fact File Types";
            $scope.EDV_heading = "Edit Default Value";
            $scope.isDimensionUpdated = false;
            $scope.vm = {};
            $scope.vm.pagedFactTableFileTypes = [];
            $scope.factTablesPages = 0;
            var itemsPerPage = 5;
            $scope.dimensionItemsPerPage = 20;
            $scope.fileTypesCurrentPage = 0;
            $scope.fileTypesTotalPages = [];
            var fileTypesCurIndex = 0;
            $scope.vm.validationSummary = [];

            $scope.MaxUploadFileSize = null;

            $scope.showAlert = function (alertType, message) {
                $scope.vm.validationSummary.push({ type: alertType, msg: message });
            }

            var getKeyCombinations = function (factTableId, fileTypeCodeId, successCallBack, failureCallBack) {
                $scope.vm.showImportedKeyCombinations = false;
                var reqData = {
                    FactTableId: factTableId,
                    FileTypeCodeId: fileTypeCodeId,
                    PagingInfo: {
                        PageNumber: 1,
                        RowsPerPage: 10,
                    }
                };

                spinnerService.show("overlaySpinner");
                return userUploadsService.getKeyCombinations(reqData, function (response) {
                    spinnerService.hide("overlaySpinner");
                    $scope.showAlert('success', response.Message);
                    successCallBack(response);
                }, function (error) {
                    $scope.showAlert('danger', response.Message);
                    spinnerService.hide("overlaySpinner");
                    failureCallBack(error);
                });
            }

            var updateFileTypeDimensions = function () {
                angular.forEach($scope.factTableFileTypes, function (fileType, i) {
                    var factTable = $scope.factTables.filter(function (f) { return f.Id == fileType.FactTableId })[0];
                    if (factTable) {
                        angular.forEach(fileType.FileTypeDimensions, function (dimension, i) {
                            var dim = factTable.AvailableDimensions.filter(function (d) { return d.Id == dimension.Id })[0];
                            if (dim) {
                                dimension.Name = dim.Name;
                                dimension.Code = dim.Code;
                                dimension.Type = dim.Type;
                                dimension.LookupKey = dim.LookupKey;
                                dimension.AvailableInStage = dim.AvailableInStage;
                                var selectedDataSource = dim.AvailableDataSources.filter(function (d) { return d.DataSourceType == dimension.SelectedDataSource.DataSourceType; })[0];
                                if (selectedDataSource) {
                                    dimension.SelectedDataSource.Description = selectedDataSource.Description;
                                }
                            }
                            else {
                                // selected dimension is not found in available dimensions.
                            }
                        });
                    }
                });
            }

            $scope.closeValidationSummary = function (index) {
                $scope.vm.validationSummary.splice(index, 1);
            };

            $scope.saveFiletype = function (newUpdatedFactData) {
                var deferred = $q.defer();
                if (!$scope.factTableFileTypes) {
                    $scope.factTableFileTypes = [];
                }

                var fileTypeData = {
                    FactTableId: newUpdatedFactData.FactTableId,
                    FileTypeCodeId: newUpdatedFactData.FileTypeCodeId,
                    Description: newUpdatedFactData.Description,
                    Code: newUpdatedFactData.Code,
                    ScheduledLoadDate: newUpdatedFactData.ScheduledLoadDate,
                    IsUserFeed: newUpdatedFactData.IsUserFeed,
                    IsAdjustment: newUpdatedFactData.IsAdjustment,
                    IsOutlook: newUpdatedFactData.IsOutlook,
                    Contains13ColFacts: newUpdatedFactData.Contains13ColFacts,
                    UsesValidKeyCombo: newUpdatedFactData.UsesValidKeyCombo,
                    DestTable: newUpdatedFactData.Desttable,
                    ShowStatus: newUpdatedFactData.ShowStatus,
                    FileTypeDimensions: newUpdatedFactData.FileTypeDimensions
                }

                spinnerService.show("overlaySpinner");
                userUploadsService.saveFiletype(fileTypeData, function (data) {
                    spinnerService.hide("overlaySpinner");
                    $scope.createEditFactTableData.response = data;
                    if (data.Status != 0) {
                        $scope.vm.validationSummary.push({ type: "danger", msg: data.Message });
                        deferred.resolve(data);
                        return;
                    }
                    else {
                        $scope.createEditFileTypeForm.$setPristine();
                        $scope.isDimensionUpdated = false;
                        $scope.vm.validationSummary.push({ type: "success", msg: data.Message });
                    }
                    var editedFileType = $scope.factTableFileTypes.filter(function (f) { return f.FileTypeCodeId == data.FileTypeCodeId })[0];
                    if (editedFileType && newUpdatedFactData.FileTypeCodeId) {
                        angular.extend(editedFileType, fileTypeData);

                        for (var i = 0; i < $scope.createEditFactTableData.FileTypeDimensions.length; i++) {
                            var dimFromDB = $scope.vm.selectedFileType.FileTypeDimensions.filter(function (f) { return f.Id == $scope.createEditFactTableData.FileTypeDimensions[i].Id })[0];
                            $scope.createEditFactTableData.FileTypeDimensions[i].SelectedDataSource.FileFieldId = dimFromDB.SelectedDataSource.FileFieldId;
                        }
                        deferred.resolve(data);
                    }
                    else {
                        userUploadsService.getFileType({ factTableId: $scope.vm.selectedFactTable.Id, fileTypeCodeId: data.FileTypeCodeId },
                            function (response) {
                                getFileTypeCallback(response);
                                deferred.resolve(response);
                            },
                            function (error) {
                                spinnerService.hide("overlaySpinner");
                                deferred.reject(error);
                            }
                        );
                    }

                    // $scope.factTableFileTypes.push(data);
                }, function (error) {
                    spinnerService.hide("overlaySpinner");
                    deferred.reject(error);
                });

                return deferred.promise;
            }

            function getFileTypeCallback(response) {

                $scope.createEditFactTableData.FileTypeCodeId = response.FileTypeCodeId;
                $scope.createEditFactTableData.FileTypeDimensions = $scope.createEditFactTableData.FileTypeDimensions.map(function (d) {
                    d.FileTypeCodeId = $scope.createEditFactTableData.FileTypeCodeId;
                    return d;
                });
                $scope.factTableFileTypes.push($scope.createEditFactTableData);


                for (var i = 0; i < $scope.createEditFactTableData.FileTypeDimensions.length; i++) {
                    var dimFromDB = response.FileTypeDimensions.filter(function (f) { return f.Id == $scope.createEditFactTableData.FileTypeDimensions[i].Id })[0];
                    $scope.createEditFactTableData.FileTypeDimensions[i].SelectedDataSource.FileFieldId = dimFromDB.SelectedDataSource.FileFieldId;
                }


                resetFileTypesGrid($scope.factTableFileTypes, 0);
            }
            $scope.confirmAndSaveFileType = function () {
                var defer = $q.defer();
                $scope.confirmSaveFileType = $uibModal.open({
                    animation: true,
                    templateUrl: 'confirmSaveFileType.html',
                    size: 'lg',
                    scope: $scope,
                    windowClass: "dimension-form-container"
                });
                return $scope.confirmSaveFileType.result.then(function (isConfirmed) {
                    if (isConfirmed) {
                        return $scope.saveFiletype($scope.createEditFactTableData).then(function (response) {
                            //Reset createEdit Data
                            defer.resolve(response);
                            // $state.go("userUploads");                                
                        }, function (error) {
                            showAlert("Failed to save file type.");
                            defer.reject(error);
                        });
                    }
                    else {
                        defer.resolve();
                    }
                });

                return defer.promise;
            }

            $scope.saveNextFileType = function (newUpdatedFactData) {
                //Move to step 3 when next button is clicked from step 2
                if (!$scope.createEditFactTableData.UsesValidKeyCombo || !$scope.CurrentUser.CanAddNewFileKeys) {
                    return;
                }
                if ($scope.createEditFileTypeForm.$dirty || $scope.isDimensionUpdated) {

                    $scope.confirmAndSaveFileType().then(function (response) {
                        if ($scope.createEditFactTableData.response && $scope.createEditFactTableData.response.Status != 0) {
                            $scope.confirmGoToStepThree = $uibModal.open({
                                animation: true,
                                templateUrl: 'confirmGoToStepThree.html',
                                size: 'lg',
                                scope: $scope,
                                windowClass: "dimension-form-container"
                            });
                            $scope.confirmGoToStepThree.result.then(function (isConfirmed) {
                                if (isConfirmed) {
                                    $scope.nextToStepThree();
                                }
                            });
                            return;
                        }
                        else {
                            $scope.nextToStepThree();
                        }

                    });
                }
                else {
                    $scope.nextToStepThree();
                }
            }

            $scope.nextToStepThree = function () {
                $scope.vm.showStepThree = true;
                $scope.vm.showStepTwo = $scope.vm.showStepOne = $scope.vm.showStepFour = false;
                $state.go("userUploads.keyComboUpload", {
                    factTableId: $scope.vm.selectedFileType.FactTableId,
                    fileTypeCodeId: $scope.vm.selectedFileType.FileTypeCodeId,
                    fileTypeUsesValidKeyCombo: $scope.createEditFactTableData.UsesValidKeyCombo
                });
            }

            $scope.backToStepOne = function () {
                //Move to step 1 when back button is clicked from step 2
                $scope.vm.showStepOne = true;
                $scope.vm.showStepTwo = $scope.vm.showStepThree = $scope.vm.showStepFour = false;
                //Reset createEdit Data
                resetFactTableData();
                $state.go("userUploads");
            }
            $scope.backFileType = function () {
                //Move to step 1 when back button is clicked from step 2
                if ($scope.vm.showStepTwo && ($scope.createEditFileTypeForm.$dirty || $scope.isDimensionUpdated)) {
                    $scope.confirmAndSaveFileType().then(function () {
                        if ($scope.createEditFactTableData.response && $scope.createEditFactTableData.response.Status == 0) {
                            $scope.backToStepOne();
                        }
                    }, function (error) {
                        showAlert("Failed to save file type.");
                    });
                }
                else {
                    $state.go("userUploads");
                    $scope.vm.showStepOne = true;
                    $scope.vm.showStepTwo = $scope.vm.showStepThree = $scope.vm.showStepFour = false;
                }
            }

            function getFactTableSettingsCallback(response) {
                $scope.FactTableSettings = response;
            }

            function errorCallback(data) {
                $scope.vm.validationSummary.push({ type: 'danger', msg: 'Error occured. Refresh the page and try again.' });
                console.log(data);
            }

            function getUserCallback(response) {
                $scope.CurrentUser = response;
            }

            function factTableDataSuccessCallback(factTableData) {
                $scope.factTables = factTableData;
                $scope.factTables.tableData = $scope.createEditFactTableData;
                spinnerService.hide("overlaySpinner");
            }

            function factTableDataErrorCallback(response) {
                alertingService.addDanger("getMenu call -Error:" + response);
                spinnerService.hide("overlaySpinner");
            }

            function resetFactTableData() {
                $scope.createEditFactTableData = {
                    Code: "",
                    Description: "",
                    ScheduleLoadDate: "",
                    Settings: {
                        IsUserFeed: false,
                        Contains13ColFacts: false,
                        IsAdjustment: false,
                        UsesValidKeyCombo: false,
                        ShowStatus: false,
                        IsOutlook: false,
                    },
                    Dimensions: [{}, {}]
                };
            }

            function getMaxUploadFileLimitCallback(response) {
                $scope.MaxUploadFileSize = response;
            }

            init = function () {

                $scope.vm.showStepOne = true, //initially shows first step.
				$scope.vm.showStepTwo = false,
				$scope.vm.showStepThree = false,
				$scope.vm.showStepFour = false

                $scope.factTableFileTypes = [];
                resetFactTableData();
                spinnerService.show("overlaySpinner");
                userProfileService.getUser({ employeeId: mainService.eidService() }, getUserCallback, errorCallback);
                mainService.getFactTableSettings({}, getFactTableSettingsCallback, errorCallback);
                userUploadsService.getAllFactTable({}, factTableDataSuccessCallback, factTableDataErrorCallback);
                userUploadFeedService.getMaxUploadFileLimit([], getMaxUploadFileLimitCallback, errorCallback);
            }

            $scope.ok = function () {
                $scope.isDimensionUpdated = $scope.isDimensionUpdated || $scope.vm.dimension, $scope.vm.clonedDimension;
                angular.extend($scope.vm.dimension, $scope.vm.clonedDimension);
                $scope.dimensionEditModalPopup.close(true);
            };

            $scope.cancel = function () {
                $scope.dimensionEditModalPopup.dismiss('cancel');
            };

            var resetFileTypesGrid = function (factTableFileTypes, curPageNum) {
                $scope.factTableFileTypes = factTableFileTypes;
                updateFileTypeDimensions();
                var totalPages = Math.ceil($scope.factTableFileTypes.length / itemsPerPage);
                $scope.fileTypesTotalPages = Array.apply(null, { length: totalPages + 1 }).map(Number.call, Number).slice(1);
                if (curPageNum) {
                    curPageNum = curPageNum < $scope.totalPages ? curPageNum : 0;
                    var lastItemIndex = curPageNum == 0 ? itemsPerPage : curPageNum * itemsPerPage;
                } else {
                    curPageNum = 0;
                }
                $scope.vm.pagedFactTableFileTypes = $scope.factTableFileTypes.slice(curPageNum, lastItemIndex);
                fileTypesCurIndex += itemsPerPage;
            }

            $scope.onSelectFactTable = function (selectedFactTable) {
                $scope.vm.selectedFileType = undefined;
                $scope.vm.selectedFactTable = selectedFactTable;
                resetFactTableData();
                spinnerService.show("overlaySpinner");
                userUploadsService.getFactTable({
                    facttableId: selectedFactTable.Id
                }, function (factTableFileTypes) {
                    resetFileTypesGrid(factTableFileTypes, 0);
                    $scope.clearKeyCombinations(); // clear the previous key combinations.
                    spinnerService.hide("overlaySpinner");
                }, function () {
                    spinnerService.hide("overlaySpinner");
                });
            }

            $scope.goToFileTypesPage = function (pageNumber) {
                var curIndex = (pageNumber - 1) * itemsPerPage;
                var lastIndex = curIndex + itemsPerPage < $scope.factTableFileTypes.length - 1 ? curIndex + itemsPerPage : $scope.factTableFileTypes.length - 1;
                lastIndex = curIndex == 0 ? lastIndex : lastIndex + 1;
                $scope.vm.pagedFactTableFileTypes = $scope.factTableFileTypes.slice(curIndex, lastIndex);
                $scope.fileTypesCurrentPage = pageNumber;
            }

            $scope.goToFileTypesNextPage = function () {
                if ($scope.fileTypesCurrentPage < $scope.fileTypesTotalPages.length) {
                    $scope.goToFileTypesPage($scope.fileTypesCurrentPage + 1);
                }
            }

            $scope.goToFileTypesPreviousPage = function () {
                if ($scope.fileTypesCurrentPage > 0) {
                    $scope.goToFileTypesPage($scope.fileTypesCurrentPage - 1);
                }
            }

            //$scope.goToGridPage = function (pageNumber, datasource, destinationSource, itemsperPage, currentPage) {
            //    var curIndex = (pageNumber - 1) * itemsperPage;
            //    if (curIndex <= datasource.length - 1) {
            //        var lastIndex = curIndex + itemsperPage < datasource.length - 1 ? curIndex + itemsperPage : datasource.length - 1;
            //        lastIndex = curIndex == 0 ? lastIndex : lastIndex + 1;
            //        $scope.vm.pagedFileTypeDimensions = datasource.slice(curIndex, lastIndex);
            //        currentPage = pageNumber;
            //    }
            //}

            //$scope.dimensionsGridGoNext = function () {
            //    if ($scope.dimensionsCurrentPage < $scope.dimensionsTotalPages.length) {
            //        $scope.dimensionsCurrentPage += 1;
            //        $scope.goToGridPage($scope.dimensionsCurrentPage + 1, $scope.createEditFactTableData.FileTypeDimensions, $scope.vm.pagedFileTypeDimensions, itemsPerPage);
            //    }
            //}

            //$scope.dimensionsGridGoPrevious = function () {
            //    if ($scope.dimensionsCurrentPage > 0) {
            //        $scope.dimensionsCurrentPage -= 1;
            //        $scope.goToGridPage($scope.dimensionsCurrentPage - 1, $scope.createEditFactTableData.FileTypeDimensions, $scope.vm.pagedFileTypeDimensions, $scope.dimensionItemsPerPage);
            //    }
            //}

            $scope.onNextToStepTwo = function (isNewFileType) {
                if (!$scope.createEditFactTableData) {
                    return;
                }
                if ($scope.vm.selectedFileType && !isNewFileType) {
                    resetFactTableData();
                    $scope.createEditFactTableData = angular.copy($scope.vm.selectedFileType);
                }
                if ($scope.vm.selectedFileType || isNewFileType) {
                    $scope.vm.showStepTwo = true;
                    $scope.vm.showStepOne = $scope.vm.showStepThree = $scope.vm.showStepFour = false;
                    $scope.dimensionsCurrentPage = 0;
                    var totalPages = Math.ceil($scope.createEditFactTableData.FileTypeDimensions.length / $scope.dimensionItemsPerPage)
                    $scope.dimensionsTotalPages = Array.apply(null, { length: totalPages + 1 }).map(Number.call, Number).slice(1);
                    //$scope.vm.pagedFileTypeDimensions = $scope.createEditFactTableData.FileTypeDimensions.slice(0, $scope.dimensionItemsPerPage);
                }
                else {
                    $scope.showModel("No File type is selected, please select one.");
                    // no file type is selected, show warning to user
                }
            }

            $scope.onNextToStepFour = function () {
                if ($scope.createEditFactTableData.UsesValidKeyCombo) {
                    $state.go('userUploads');
                    $scope.vm.showStepFour = true;
                    $scope.vm.showStepOne = $scope.vm.showStepTwo = $scope.vm.showStepThree = false
                    $scope.vm.srcKeyCombinations = [];
                    $scope.vm.srcKeyCombinationsData = {};
                    $scope.vm.srcFileType = undefined;
                }
            }

            $scope.truncatedString = function (s) {
                if ($scope.vm.showStepFour != null && $scope.vm.showStepFour == true)
                {
                    if (s.length > 10) {
                        return ' (' + s.substring(0, 25) + '...)';
                    }
                    else {
                        return '(' + s + ')';
                    }
                }
            }

            $scope.onBackToStepTwo = function () {
                //Move to step 2 when back button is clicked from step 3
                $scope.vm.showStepTwo = true;
                $scope.vm.showStepOne = $scope.vm.showStepThree = $scope.vm.showStepFour = false;
                $state.go('userUploads');

            }
            $scope.onBackToStepThree = function () {
                $scope.vm.showStepThree = true;
                $scope.vm.showStepTwo = $scope.vm.showStepOne = $scope.vm.showStepFour = false;
                $state.go("userUploads.keyComboUpload", {
                    factTableId: $scope.vm.selectedFileType.FactTableId,
                    fileTypeCodeId: $scope.vm.selectedFileType.FileTypeCodeId
                });
            }

            $scope.editDimension = function (dimension) {
                $scope.vm.clonedDimension = angular.copy(dimension);
                $scope.vm.dimension = dimension;
                $scope.availableDimensions = $scope.vm.selectedFactTable.AvailableDimensions;
                var dim = $scope.vm.selectedFactTable.AvailableDimensions.filter(function (d) { return d.Id == dimension.Id })[0];
                $scope.selectedDimensionAvailableDataSources = dim.AvailableDataSources;
                $scope.dimensionEditModalPopup = $uibModal.open({
                    animation: true,
                    templateUrl: 'editDimension.html',
                    size: 'lg',
                    scope: $scope,
                    windowClass: "dimension-form-container"
                });
            }

            $scope.onSelectDimensionDataSource = function (dataSource) {
                $scope.vm.clonedDimension.SelectedDataSource.DataSourceType = dataSource.DataSourceType;
                $scope.vm.clonedDimension.SelectedDataSource.Description = dataSource.Description;
                $scope.vm.clonedDimension.SelectedDataSource.ForcedValue = dataSource.ForcedValue;
                $scope.vm.clonedDimension.SelectedDataSource.AutomapId = dataSource.AutomapId;

            }

            $scope.onSelectDimension = function (dimension) {
                $scope.vm.clonedDimension.AvailableInStage = dimension.AvailableInStage;
                $scope.vm.clonedDimension.Code = dimension.Code;
                $scope.vm.clonedDimension.Id = dimension.Id;
                $scope.vm.clonedDimension.LookupKey = dimension.LookupKey;
                $scope.vm.clonedDimension.Name = dimension.Name;
                $scope.vm.clonedDimension.Type = dimension.Type;
                var dim = $scope.vm.selectedFactTable.AvailableDimensions.filter(function (d) { return d.Id == dimension.Id })[0];
                $scope.selectedDimensionAvailableDataSources = dim.AvailableDataSources;
            }

            $scope.addNewFileType = function () {
                $scope.createEditFactTableData = new FileTypeViewModel({});
                $scope.createEditFactTableData.FactTableId = $scope.vm.selectedFactTable.Id;
                $scope.vm.selectedFileType = $scope.createEditFactTableData;
                var dimensions = [];
                angular.forEach($scope.vm.selectedFactTable.AvailableDimensions, function (dim, i) {
                    var selectedDataSource = angular.copy(dim.AvailableDataSources[0]);
                    var dimension = new DimensionViewModel(dim);
                    dimension.SelectedDataSource = selectedDataSource;
                    dimensions.push(dimension);
                });
                $scope.createEditFactTableData.FileTypeDimensions = dimensions;
                $scope.onNextToStepTwo(true);
            }

            var deleteFileTypeFromSource = function (dataSource, delFileType) {
                var delFile = dataSource.filter(function (f) { return f.FileTypeCodeId == $scope.vm.selectedFileType.FileTypeCodeId && f.factTableId == $scope.vm.selectedFileType.factTableId })[0];
                if (delFile) {
                    var delIndex = dataSource.indexOf(delFile);
                    if (delIndex >= 0) {
                        dataSource.splice(dataSource.indexOf(delFile), 1);
                    }
                }
                return dataSource;
            }

            $scope.deleteFileType = function () {
                if ($scope.vm.selectedFileType) {
                    var delFileType = {
                        FactTableId: $scope.vm.selectedFileType.FactTableId,
                        FileTypeCodeId: $scope.vm.selectedFileType.FileTypeCodeId
                    };

                    $scope.deleteFileTypeModal = $uibModal.open({
                        animation: true,
                        templateUrl: 'deleteFileTypeModalPopUp.html',
                        size: 'sm',
                        scope: $scope,
                        windowClass: "alert-popup-container"
                    });
                    $scope.deleteFileTypeModal.result.then(function (isConfirmed) {
                        if (isConfirmed) {
                            spinnerService.show("overlaySpinner");
                            userUploadsService.deleteFileType(delFileType, function (response) {
                                spinnerService.hide("overlaySpinner");
                                if (response) {
                                    $scope.factTableFileTypes = deleteFileTypeFromSource($scope.factTableFileTypes, delFileType);
                                    $scope.vm.pagedFactTableFileTypes = deleteFileTypeFromSource($scope.vm.pagedFactTableFileTypes, delFileType);
                                    $scope.vm.selectedFileType = undefined;
                                    $scope.vm.validationSummary.push({ type: "success", msg: response.Message });
                                }
                            }, function (error) {
                                spinnerService.hide("overlaySpinner");
                            })
                        }
                    });
                }
                else {
                    $scope.showModel("No file type selected to delete");
                }
            }

            var reArrangeKeyCombinations = function (keyCombinationsData) {
                if (!keyCombinationsData) {
                    return [];
                }
                var totalRows = keyCombinationsData.map(function (d) { return d.Values.length; }).sort(function (a, b) { return b - a; })[0];
                var rows = Array.apply(null, { length: totalRows + 1 }).map(Number.call, Number).slice(1)
                var keyCombinations = [];
                angular.forEach(rows, function (row, i) {
                    var values = keyCombinationsData.map(function (d) { if (d.Values.length - 1 >= i) return d.Values[i]; });
                    values.splice(0, 1);
                    var keyCombination = {
                        id: keyCombinationsData[0].Values[i],
                        values: values
                    };

                    keyCombinations.push(keyCombination);
                });

                return keyCombinations;
            }

            $scope.uploadFactFile = function (uploadFileData) {
                $scope.vm.invalidKeyCombinations = false;
                if (!uploadFileData) {
                    // file data not available, skip the uploading
                    return;
                }
                var fileMetadata = {
                    "FileTypeName": uploadFileData.name,
                    "Base64EncodedFile": uploadFileData.fileData
                };
                spinnerService.show("overlaySpinner");
                userUploadsService.uploadFactFile(fileMetadata, function (response) {
                    spinnerService.hide("overlaySpinner");
                    if (response) {
                        var factData = {
                            SignedUrl: response,
                            FactTableId: $scope.factTableId,
                            FileTypeCodeId: $scopefileTypeCodeId,
                        }
                        spinnerService.show("overlaySpinner");
                        userUploadsService.uploadFactData(factData, function (dataResponse) {
                            var msgType = dataResponse.MessageType != 2 ? "danger" : "success";
                            $scope.vm.validationSummary.push({ type: msgType, msg: dataResponse.Message });
                            spinnerService.hide("overlaySpinner");
                            var keyCombinations = reArrangeKeyCombinations(dataResponse.ResponseTableData);
                            $scope.vm.importKeyCombinationsData = dataResponse;
                            $scope.vm.importKeyCombinations = keyCombinations;
                        }, function (error) {
                            spinnerService.hide("overlaySpinner");
                        });
                        // file uploaded sucessfully.
                    }

                    else {
                        $scope.vm.invalidKeyCombinations = true;
                    }
                }, function (error) {
                    spinnerService.hide("overlaySpinner");
                    $scope.vm.invalidKeyCombinations = true;
                });
            }

            $scope.moveKeyCombinations = function (isMoveAll) {
                var moveKeyCombinationIds = $scope.vm.srcKeyCombinations.filter(function (k) { return k.selected; }).map(function (k) { return k.id; });
                if (!isMoveAll && moveKeyCombinationIds.length == 0) {
                    return;
                }
                var moveCombinationsData = {
                    FactTableId: $scope.vm.selectedFileType.FactTableId,
                    FileTypeCodeId: $scope.vm.srcFileType.FileTypeCodeId,
                    TargetFileTypeCodeId: $scope.vm.selectedFileType.FileTypeCodeId,
                    MoveOption: isMoveAll ? 2 : 1,

                };
                if (!isMoveAll) {
                    moveCombinationsData.MoveRecords = moveKeyCombinationIds;
                }
                spinnerService.show("overlaySpinner");
                userUploadsService.moveKeyCombinations(moveCombinationsData, function (response) {
                    spinnerService.hide("overlaySpinner");

                    if (response.Status == 0) {
                        $scope.vm.validationSummary.push({ type: "success", msg: response.Message });
                        //key combinations moved successfully.
                    }
                    else {
                        $scope.vm.validationSummary.push({ type: "danger", msg: response.Message });
                    }
                }, function (error) {
                    spinnerService.hide("overlaySpinner");
                    $scope.vm.validationSummary.push({ type: "danger", msg: response.Message });
                })
            }

            $scope.moveAllKeyCombinations = function () {
                $scope.moveKeyCombinations(true);
            }

            $scope.clearKeyCombinations = function () {
                $scope.vm.keyCombinations = [];
                $scope.vm.keyCombinationsData = {};
            }

            $scope.getSrcFileTypeKeyCombinations = function (fileType) {
                $scope.vm.srcFileType = fileType;
                getKeyCombinations($scope.vm.selectedFileType.FactTableId, fileType.FileTypeCodeId, function (response) {
                    $scope.vm.srcKeyCombinationsData = response;
                    $scope.vm.srcKeyCombinations = reArrangeKeyCombinations(response.KeyComboData.Data);
                });
            }

            $scope.resetDimension = function (dimension) {
                console.log($scope);
                var factTable = $scope.factTables.filter(function (f) { return f.Id == $scope.createEditFactTableData.FactTableId; })[0];
                var dimFromFileType = $scope.vm.selectedFileType.FileTypeDimensions.filter(function (f) { return f.Id == dimension.Id })[0];
                var fileFieldId = dimFromFileType.SelectedDataSource.FileFieldId;
                if (factTable) {
                    var oDimension = factTable.AvailableDimensions.filter(function (d) { return d.Id == dimension.Id })[0];
                    dimension.SelectedDataSource = oDimension.AvailableDataSources[0];
                    dimension.SelectedDataSource.FileFieldId = fileFieldId;
                }
            }

            $scope.showModel = function (description) {
                $scope.alertPopUpdescription = description;
                $scope.alertPopUp = $uibModal.open({
                    animation: true,
                    templateUrl: 'alertPopup.html',
                    size: 'sm',
                    scope: $scope,
                    windowClass: "alert-popup-container"
                });
                $scope.alertPopUp.result.then(function (isConfirmed) {
                    $scope.alertPopUpdescription = "";
                });
            }

            $scope.onFileSelect = function (fileUpload) {
                $scope.vm.uploadedFileData.IsFileLoading = "loading";
                // $scope.$apply();
                var files = fileUpload.files;
                if (files.length > 0) {
                    var fileReader = new FileReader();
                    fileReader.readAsDataURL(files[0]);

                    fileReader.onload = function (event) {
                        $scope.vm.uploadedFileData.FileForUploadInbase64 = event.target.result.split(',')[1];
                        $scope.vm.uploadedFileData.FileDisplayText = files[0].name;
                        $scope.vm.uploadedFileData.IsFileLoading = "complete";
                        $scope.$apply();
                    }
                }


            }

            $scope.selectAllSrcKeyCombos = function (isAllSelected) {
                $scope.vm.srcKeyCombinations = $scope.vm.srcKeyCombinations.map(function (k) { k.selected = isAllSelected; return k; });
            }


            init();
            // starts controller here.
        }])


    function FileTypeViewModel(args) {
        this.Code = args.Code || "";
        this.Description = args.Description || "";
        this.ScheduleLoadDate = args.ScheduleLoadDate || "";
        this.IsUserFeed = this.IsUserFeed || false,
        this.Contains13ColFacts = args.Contains13ColFacts || false,
        this.IsAdjustment = args.IsAdjustment || false,
        this.UsesValidKeyCombo = args.UsesValidKeyCombo || false,
        this.ShowStatus = args.ShowStatus || false,
        this.IsOutlook = args.IsOutlook || false,
        this.FileTypeDimensions = args.FileTypeDimensions || [];
        this.FactTableId = args.FactTableId;
        this.FileTypeCodeId = args.FileTypeCodeId;
        this.DestTable = args.DestTable;
        this.LastLoadedBy = args.LastLoadedBy;
        this.LastLoadedDate = args.LastLoadedDate;
        this.FileTypeCustomFields = args.FileTypeCustomFields || [];
    };

    function DimensionViewModel(args) {
        this.AvailableInStage = args.AvailableInStage || false;
        this.Code = args.Code;
        this.Id = args.Id;
        this.LookupKey = args.LookupKey;
        this.Name = args.Name;
        this.StageTableColumnName = args.StageTableColumnName;
        this.Type = args.Type;
        this.SelectedDataSource = args.SelectedDataSource;
        this.NeedsValidation = args.NeedsValidation;

    }

})(angular.module('vmApp'));