﻿
(function ($) {

    angular.module('vmApp')
        .controller('factDownloadController', ['$scope', 'factDownloadService', '$uibModal', 'spinnerService', 'userUploadFeedService', 'serverVariableService', factDownloadController])

    function factDownloadController($scope, factDownloadService, $uibModal, spinnerService, userUploadFeedService, serverVariableService) {

        var self = $scope;

        self.validationSummary = [];
        self.closeValidationSummary = function (index) {
            self.validationSummary.splice(index, 1);
        };

        self.showAlert = function (alertType, message) {
            self.validationSummary.push({ type: alertType, msg: message });
        }

        self.factDownloadVM = null;
        self.spinnerSemaphoreVM = new spinnerSemaphoreViewModel(spinnerService);

        self.onLoad = function () {
            self.spinnerSemaphoreVM.addSemaphore();
            self.factDownloadVM = new FactDownloadViewModel();
            userUploadFeedService.getAllFileTypes([], getAllFactFilesCallback, errorCallback);

            //Load Dimension Years
            if (self.factDownloadVM.AvailableYears.length == 0) {
                self.spinnerSemaphoreVM.addSemaphore();
                userUploadFeedService.getDimYears([], getDimYearsCallback, errorCallback);
            }
        };

        self.onSelectFileType = function (item) {
            self.factDownloadVM.SelectedFileType = item;
        }

        self.onSelectYear = function (item) {
            self.factDownloadVM.SelectedYear = item;
        }

        self.onSelectMonth = function (item) {
            self.factDownloadVM.SelectedMonth = item;
        }

        self.onSelectPriorPeriod = function (item) {
            self.factDownloadVM.SelectedPriorPeriod = item;
        }

        self.onDownload = function () {
            if (self.factDownloadVM.SelectedFileType == null) {
                self.showAlert('danger', 'Select a File Type to continue with download.');
            }

            if (self.factDownloadVM.SelectedYear == null) {
                self.showAlert('danger', 'Select a Year to continue with download.');
            }

            if (self.factDownloadVM.SelectedMonth == null) {
                self.showAlert('danger', 'Select a Month to continue with download.');
            }

            //calculate start period based on prior period
            self.factDownloadVM.calculateStartEndDate();

            var factDownloadrequest = new FactDownloadRequestViewModel(self.factDownloadVM.SelectedFileType.FactTableId,
                self.factDownloadVM.SelectedFileType.FileTypeCodeId,
                self.factDownloadVM.StartDate, self.factDownloadVM.EndDate, '');

            self.spinnerSemaphoreVM.addSemaphore();
            factDownloadService.getFactDownloadSignedUrl(factDownloadrequest, getFactDownloadSignedUrlCallback, errorCallback);

        }

        //call backs
        function getAllFactFilesCallback(response) {
            //clear available file types
            self.factDownloadVM.AvailableFileTypes.splice(0, self.factDownloadVM.AvailableFileTypes.length);

            for (var factFileCounter = 0; factFileCounter < response.length; factFileCounter++) {
                for (var fileTypeCounter = 0; fileTypeCounter < response[factFileCounter].FileTypes.length; fileTypeCounter++) {
                    self.factDownloadVM.AvailableFileTypes.push(new FileTypeViewModel(response[factFileCounter].FileTypes[fileTypeCounter], response[factFileCounter]));
                }
            }
            self.spinnerSemaphoreVM.reduceSemaphore();
            
        }

        function getDimYearsCallback(response) {

            //clear available years list
            self.factDownloadVM.AvailableYears.splice(0, self.factDownloadVM.AvailableYears.length);
            self.factDownloadVM.SelectedYear = null;

            for (var idx = 0; idx < response.length; idx++) {
                self.factDownloadVM.AvailableYears.push(response[idx]);
            }

            self.spinnerSemaphoreVM.reduceSemaphore();
        }

        function getFactDownloadSignedUrlCallback(response) {
            self.spinnerSemaphoreVM.reduceSemaphore();
            var exportUrl = serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/facttable/DownloadFactTable';
            exportUrl = exportUrl + '?FactTableId=' + self.factDownloadVM.SelectedFileType.FactTableId + "&FileTypeCodeId=" + self.factDownloadVM.SelectedFileType.FileTypeCodeId;
            exportUrl = exportUrl + '&StartPeriod=' + self.factDownloadVM.StartDate + "&EndPeriod=" + self.factDownloadVM.EndDate;
            exportUrl = exportUrl + '&SignedUrl=' + response;
            window.open(exportUrl);
        }

        function errorCallback(data) {
            self.validationSummary.push({ type: 'danger', msg: 'Error occured. Refresh the page and try again.' });
            console.log(data);
            self.spinnerSemaphoreVM.reduceSemaphore();
        }

        //Load Page
        self.onLoad();
    }

    //view models
    function FactDownloadViewModel() {
        var self = this;
        self.AvailableMonths = [];
        self.AvailableYears = [];
        self.AvailableFileTypes = ['gl', 'hc'];
        self.AvailablePriorPeriods = [];

        self.SelectedMonth = null;
        self.SelectedYear = null;
        self.SelectedFileType = null;
        self.SelectedPriorPeriod = null;

        self.StartDate = null;
        self.EndDate = null;

        self.calculateStartEndDate = function () {
            var startDate = new Date(self.SelectedYear, parseInt(self.SelectedMonth.id) - 1);
            startDate.setMonth(startDate.getMonth() - self.SelectedPriorPeriod);
            var endDate = new Date(self.SelectedYear, parseInt(self.SelectedMonth.id) - 1);
            var startMonth = startDate.getMonth() + 1;
            self.StartDate = startDate.getFullYear() + '' + (startMonth > 9 ? startMonth : '0' + startMonth);
            self.EndDate = self.SelectedYear + self.SelectedMonth.id;
        }

        self.setAvailableMonths = function () {
            //clear months list if present
            self.AvailableMonths.splice(0, self.AvailableMonths.length);
            self.AvailableMonths.push({ id: '01', value: 'January' });
            self.AvailableMonths.push({ id: '02', value: 'February' });
            self.AvailableMonths.push({ id: '03', value: 'March' });
            self.AvailableMonths.push({ id: '04', value: 'April' });
            self.AvailableMonths.push({ id: '05', value: 'May' });
            self.AvailableMonths.push({ id: '06', value: 'June' });
            self.AvailableMonths.push({ id: '07', value: 'July' });
            self.AvailableMonths.push({ id: '08', value: 'August' });
            self.AvailableMonths.push({ id: '09', value: 'September' });
            self.AvailableMonths.push({ id: '10', value: 'October' });
            self.AvailableMonths.push({ id: '11', value: 'November' });
            self.AvailableMonths.push({ id: '12', value: 'December' });
        }
        self.setPriorPeriods = function () {
            self.AvailablePriorPeriods.splice(0, self.AvailablePriorPeriods.length);
            for (var p = 0; p < 12; p++) {
                self.AvailablePriorPeriods.push(p);
            }

            self.SelectedPriorPeriod = self.AvailablePriorPeriods[0];
        }
        self.setAvailableMonths();
        self.setPriorPeriods();
    }

    function FileTypeViewModel(fileType, factTable) {
        var self = this;
        self.FileTypeCodeId = fileType.FileTypeCodeId;
        self.Code = fileType.Code;
        self.UsesValidKeyCombo = fileType.UsesValidKeyCombo;

        self.FactTableId = factTable.Id;
        self.FactTableName = factTable.Name;
        self.FactTableType = factTable.FactTableType;

        self.isSelected = false;
    }

    function spinnerSemaphoreViewModel(spinnerService) {
        var self = this;
        self.semaphore = 0;
        self.addSemaphore = function () {
            self.semaphore++;
            if (self.semaphore == 1) {
                spinnerService.show("overlaySpinner");
            }
        };
        self.reduceSemaphore = function () {
            self.semaphore--;
            if (self.semaphore == 0) {
                spinnerService.hide("overlaySpinner");
            }
        };
    }

    function FactDownloadRequestViewModel(factTableId, fileTypeCodeId, startPeriod, endPeriod, signedUrl) {
        var self = this;
        self.FactTableId = factTableId;
        self.FileTypeCodeId = fileTypeCodeId;
        self.StartPeriod = startPeriod;
        self.EndPeriod = endPeriod;
        self.SignedUrl = signedUrl;
    }

})(window.jQuery);