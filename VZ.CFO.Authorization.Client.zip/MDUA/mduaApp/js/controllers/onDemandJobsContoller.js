﻿
(function ($) {

    angular.module('vmApp')
        .controller('onDemandJobsController', ['$scope', 'onDemandJobsService', '$uibModal', 'spinnerService', onDemandJobsController])
        .controller('triggerModalInstanceController', ['$uibModalInstance', function ($uibModalInstance) {
            var self = this;
            self.ok = function ($event) {
                $uibModalInstance.close("OK");
            }
            self.cancel = function () {
                $uibModalInstance.dismiss('cancel');
            };

        }]);

    function onDemandJobsController($scope, onDemandJobsService, $uibModal, spinnerService) {

        var self = $scope;
        self.constParamTypeFreeText = 1;
        self.constParamTypeLookup = 2;
        self.constParamTypeCascadeLookup = 3;

        self.validationSummary = [];
        self.closeValidationSummary = function (index) {
            self.validationSummary.splice(index, 1);
        };

        //self.groupList = [{ id: '1', name: 'All' }, { id: '2', name: 'PMR' }];
        self.groupList = [];
        self.jobList = [];
        var paramList = [{ id: 1, name: 'DRM', type: 'lookup', paramValues: [], selectedParamValue: null, associatedParams: null, associatedParamValueResolvedList: [] }, { id: 2, name: 'Hierarchy', type: 'cascadelookup', paramValues: [], selectedParamValue: null, associatedParams: [1], associatedParamValueResolvedList: [] }, { id: 3, name: 'Something Else', type: 'cascadelookup', paramValues: [], selectedParamValue: null, associatedParams: [1, 2], associatedParamValueResolvedList: [] }, { id: 4, name: 'free', type: 'freetext', paramValues: [], selectedParamValue: null, associatedParamValueResolvedList: [] }];

        var paramValueList = [{ id: 1, values: [{ id: 'drm1', name: 'drm1' }, { id: 'drm2', name: 'drm2' }, { id: 'drm3', name: 'drm3' }] }, { id: 2, values: [{ id: 'h1', name: 'h1' }, { id: 'h2', name: 'h2' }, { id: 'h3', name: 'h3' }] }, { id: 3, values: [{ id: 's1', name: 'S1' }, { id: 'S2', name: 's2' }, { id: 's3', name: 's3' }] }];

        self.selectedGroup = null;
        self.selectedJob = null;
        self.selectedJobStatus = null;
        self.isGroupsFieldLoading = false;
        self.isJobsFieldLoading = false;
        self.isJobStatusLoading = false;


        self.watcherDictionary = [];
        self.cascadeLookupDictionary = [];
        


        self.onLoad = function () {

            self.isGroupsFieldLoading = true;
            //get groups
            onDemandJobsService.getAllODJobGroups([], getAllODJobGroupsCallback, errorCallback);
        };
        self.onSelectGroup = function (group) {
            //set selectedGroup
            self.selectedGroup = group;
            //reset selectedJob
            self.selectedJob = null;
            //reset selectedJobStatus
            self.selectedJobStatus = null;
            //show spinner
            self.isJobsFieldLoading = true;
            
            //clear Job List
            self.jobList.splice(0, self.jobList.length);
            //Populate Job Dropdown
            onDemandJobsService.getAllODJobsByGroupId({ groupId: self.selectedGroup.Id }, getAllODJobsByGroupIdCallback, errorCallback);
        };

        self.onSelectJob = function (job) {
            self.selectedJob = job;
            //reset selectedJobStatus
            self.selectedJobStatus = null;
            //Resolve all lookup params
            ResolveLookups();
            //Get Status of the job
            refreshJobStatus(job.id, 0);
        };

        self.onTrigger = function () {
            console.log('tr');

            var modalInstance = $uibModal.open({
                templateUrl: 'triggerModalContent.html', //refers to modal content
                controller: 'triggerModalInstanceController as tmc', //inner controller
                scope: $scope, //scope elements
                ariaLabelledBy: 'modal-title',
                ariaDescribedBy: 'modal-body',
            });
            modalInstance.result.then(function (confirm) {
                var validationMsg = validateTrigger();
                if (validationMsg == '') {

                    var selectedValues = GetSelectedParamValues();

                    var payload = { JobId: self.selectedJob.id, JobParams: selectedValues };
                    
                    spinnerService.show("overlaySpinner");
                    onDemandJobsService.triggerODJob(payload, triggerODJobCallback, triggerErrorCallback);
                }
                else {
                    self.validationSummary.push({ type: 'danger', msg: 'One or more job parameters are empty (' + validationMsg + ')' });
                }
            }, function () {
                console.log('Modal dismissed at: ' + new Date());
            });
        }

        self.onRefreshJobStatus = function () {
            refreshJobStatus(self.selectedJob.id, 0);
        }

        

        self.onParamDropDownChange = function (selectedValue, param) {
            param.selectedParamValue = selectedValue;
            if (param.selectedParamValue != null) {
                //Resolve Dependent Cascading Lookups
                ResolveDependentCascadingLookups(param);
            }
        };

        function ResolveLookups() {
            if (self.selectedJob.params != null && self.selectedJob.params != undefined)
            {
                for (var paramIndex = 0; paramIndex < self.selectedJob.params.length; paramIndex++) {
                    var workingParam = self.selectedJob.params[paramIndex];
                    if (workingParam.paramType === self.constParamTypeLookup) {

                        //show spinner while param is loading
                        workingParam.isLoading = true;
                        //call service to resolve values for lookup
                        onDemandJobsService.getODJobParamValues({ paramId: workingParam.id }, getODJobParamValuesCallback, errorCallback);
                    }
                }
            }
        }

        function ResolveDependentCascadingLookups(param) {

            //list to hold affected dropdowns because this change
            var affectedParams = [];

            for (var paramIndex = 0; paramIndex < self.selectedJob.params.length; paramIndex++) {
                var workingParam = self.selectedJob.params[paramIndex];
                var isChangeValueReplaced = false;


                if (workingParam.id != param.id && workingParam.paramType === self.constParamTypeCascadeLookup) {

                    if (affectedParams.length > 0) {
                        var isworkingParamAffected = false;

                        for (var wpaIndex = 0; wpaIndex < affectedParams.length; wpaIndex++) {
                            if (workingParam.associatedParams.indexOf(affectedParams[wpaIndex]) > -1) {
                                //reduce the asso. resolved it since its dependent on affected param
                                workingParam.associatedParamValueResolvedList.splice($.inArray(affectedParams[wpaIndex], workingParam.associatedParamValueResolvedList), 1);
                                isworkingParamAffected = true;
                            }
                        }

                        if (isworkingParamAffected) {
                            //clear this 
                            workingParam.selectedParamValue = null;
                            workingParam.paramValues = [];
                            //add this param to affected list so that its dependent params can be reset too
                            if (affectedParams.indexOf(workingParam.id) == -1) {
                                affectedParams.push(workingParam.id);
                            }
                        }
                    }
                    if (workingParam.associatedParams.indexOf(param.id) > -1) {

                        if ($.inArray(param.id, workingParam.associatedParamValueResolvedList) < 0) {
                            isChangeValueReplaced = true;
                            workingParam.associatedParamValueResolvedList.push(param.id);
                            //workingParam.associatedParamValueResolveCount++;
                        }
                        else {
                            isChangeValueReplaced = false;
                            workingParam.selectedParamValue = null;
                            workingParam.paramValues = [];
                            if (affectedParams.indexOf(workingParam.id) == -1) {
                                affectedParams.push(workingParam.id);
                            }

                            //remove the changed param from associatedParamValueResolvedList
                            //workingParam.associatedParamValueResolvedList.splice($.inArray(param.id, workingParam.associatedParamValueResolvedList), 1);
                        }

                        //Check is the cascading lookup can be resolved
                        if (CanResolveValues(workingParam, param) === true) {
                            //Resolve cascading lookup
                            var paramValuesRequest = GenerateParamValuesRequest(workingParam.id);
                            //show spinner while this param is loading
                            workingParam.isLoading = true;
                            onDemandJobsService.getODJobAssociateParamValues(paramValuesRequest, getODJobAssociateParamValuesCallback, errorCallback);
                            //workingParam.paramValues = paramValueList[paramIndex].values;
                        }

                    }
                
                }

            }
        }

        function CanResolveValues(workingParam, changedParam) {
            var canResolve = false;
            //get the working Param from selectedJob
            if (workingParam.associatedParamValueResolvedList.length === workingParam.associatedParams.length) {
                canResolve = true;
            }
            return canResolve;

            ////get the working Param from selectedJob
            //var workingParam = $.grep(self.selectedJob.params, function (p) { return p.id === workingParamId; });
            //if (workingParam.length > 0) {

            //    if (workingParam[0].associatedParamValueResolvedList.length === workingParam[0].associatedParams.length) {
            //        canResolve = true;
            //    }
            //    //check if the changedParam is the only dependant param
            //    //if (workingParam[0].associatedParams != null && workingParam[0].associatedParams.length == 1 && $.inArray(changedParamId, workingParam[0].associatedParams) >= 0) {
            //        //canResolve = true;
            //    //}
            //}
            //return canResolve;
            //var workingParam = $.grep(self.selectedJob.params, function (m) { return m.mappingTableId == mappingAccessRoles[mtIndex].AccessObjectId; });
        }
        
        function GenerateParamValuesRequest(paramId) {
            if (self.selectedJob.params != null && self.selectedJob.params != undefined) {
                //get param from selectedJob
                var workingParam = $.grep(self.selectedJob.params, function (p) { return p.id == paramId; });
                if (workingParam.length > 0) {

                    var odJobParamValuesObject = [];
                    //iterate through the associated params and get selectedValues
                    for (var apIndex = 0; apIndex < workingParam[0].associatedParams.length; apIndex++) {
                        var associatedParam = $.grep(self.selectedJob.params, function (p) { return p.id == workingParam[0].associatedParams[apIndex]; });
                        if (associatedParam.length > 0) {
                            //push the selected value into array
                            odJobParamValuesObject.push(associatedParam[0].selectedParamValue);
                        }
                    }

                    return { ParamId: paramId, ODJobParamValues: odJobParamValuesObject };
                }
            }
        }

        function refreshJobStatus(jobId, generation) {
            //Set this property so that refresh button can be disabled to avoid double processing
            $scope.isJobStatusLoading = true;

            onDemandJobsService.getODJobStatusByGeneration({ jobId: jobId, generation: generation }, getODJobStatusByGenerationCallback, getODJobStatusByGenerationerrorCallback);
        }

        function validateTrigger() {

            var validationMsg = '';
            if (self.selectedJob == null) {
                validationMsg = 'Select a job to trigger.'
            }
            
            if (self.selectedJob.params != null && self.selectedJob.params != undefined && self.selectedJob.params.length > 0) {
                for (var pIndex = 0; pIndex < self.selectedJob.params.length; pIndex++) {
                    var val = self.selectedJob.params[pIndex].selectedParamValue;
                    if (val == undefined || val == null || val == '') {
                        validationMsg = validationMsg + self.selectedJob.params[pIndex].name + ' ';
                    }
                    else if (val.length > 68) {
                        validationMsg = validationMsg + self.selectedJob.params[pIndex].name + ' has value greater than 68 chars';
                    }
                }
            }

            return validationMsg;
        }

        function GetSelectedParamValues() {
            var selectedParamValues = [];
            if (self.selectedJob.params != null && self.selectedJob.params != undefined && self.selectedJob.params.length > 0) {
                for (var pIndex = 0; pIndex < self.selectedJob.params.length; pIndex++) {
                    var val = self.selectedJob.params[pIndex].selectedParamValue;
                    selectedParamValues.push(val.Key);
                }
            }

            return selectedParamValues;
        }

        //call backs
        function getAllODJobGroupsCallback(groupsResponse) {
            self.groupList = groupsResponse;
            self.isGroupsFieldLoading = false;
        }

        function getAllODJobsByGroupIdCallback(jobsResponse) {
            //clear Job List
            self.jobList.splice(0, self.jobList.length);
            if (jobsResponse != null && jobsResponse != undefined) {
                for (var jobIndex = 0; jobIndex < jobsResponse.length; jobIndex++) {
                    self.jobList.push(new jobViewModel(jobsResponse[jobIndex]));
                }
            }

            self.isJobsFieldLoading = false;
        }

        function getODJobParamValuesCallback(paramValuesResponse) {
            //get the param from selected job
            var workingParam = $.grep(self.selectedJob.params, function (p) { return p.id == paramValuesResponse.paramId; });
            if (workingParam.length > 0) {
                workingParam[0].paramValues = paramValuesResponse.data;
                //hide spinner 
                workingParam[0].isLoading = false;
            }
            else {
                console.log('Failed to get param');
            }
        }

        function getODJobAssociateParamValuesCallback(paramValuesResponse) {
            //get the param from selected job
            var workingParam = $.grep(self.selectedJob.params, function (p) { return p.id == paramValuesResponse.paramId; });
            if (workingParam.length > 0) {
                workingParam[0].paramValues = paramValuesResponse.data;
                //hide spinner 
                workingParam[0].isLoading = false;
            }
            else {
                console.log('Failed to get param');
            }
        }

        function getODJobStatusByGenerationCallback(jobStatusResponse) {
            self.selectedJobStatus = new jobStatusViewModel(jobStatusResponse.data);
            self.isJobStatusLoading = false;
        }

        function triggerODJobCallback(triggerJobResponse) {

            spinnerService.hide("overlaySpinner");
            //check if the trigger is success
            self.validationSummary.push({ type: 'success', msg: 'Job successfully triggered' });
            //refresh Job Status
            refreshJobStatus($scope.selectedJob.id, 0);
        }

        function triggerErrorCallback(data) {
            spinnerService.hide("overlaySpinner");
            self.validationSummary.push({ type: 'danger', msg: 'Job trigger failed' });
        }

        function getODJobStatusByGenerationerrorCallback(data){
            self.validationSummary.push({ type: 'danger', msg: 'Job status failed' });
            self.isJobStatusLoading = false;
        }

        function errorCallback(data) {
            self.validationSummary.push({ type: 'danger', msg: 'Error occured. Refresh the page and try again.' });
            console.log(data);
        }

        //Load Page
        self.onLoad();
    }

    //view models
    function jobViewModel(job) {
        var self = this;
        self.id = job.Id;
        self.name = job.Name;
        self.subAppName = job.SubApplicationName;
        self.displayName = job.UserFriendlyName;
        self.description = job.Description;
        self.params = [];
        self.event = job.event;

        self.addParams = function (paramList) {
            //add params
            for (var pIndex = 0; pIndex < paramList.length; pIndex++) {
                self.params.push(new jobParamViewModel(paramList[pIndex], null, []));
            }
        };

        if (job.Parameters != null && job.Parameters != undefined) {
            self.addParams(job.Parameters);
        }
        
    }

    function jobParamViewModel(param, selectedParamValue, associatedParamValueResolvedList) {
        //id: 1, name: 'DRM', type: 'lookup', paramValues: [], selectedParamValue: null, associatedParams: null, associatedParamValueResolvedList: []
        var self = this;
        self.id = param.Id;
        self.name = param.Name;
        self.paramType = param.ParamType;
        self.paramValues = param.ParamValues; //TODO: make sure it is empty initially
        self.associatedParams = [];
        self.associatedParamObjects = [];
        self.selectedParamValue = selectedParamValue;
        self.associatedParamValueResolvedList = associatedParamValueResolvedList;
        self.isLoading = false;
        self.addAssociatedParams = function (paramList) {
            //add associatedParams
            for (var pIndex = 0; pIndex < paramList.length; pIndex++) {
                self.associatedParams.push(paramList[pIndex].Id);
                self.associatedParamObjects.push(new jobParamViewModel(paramList[pIndex], null, []));
            }
        };

        if (param.AssociatedParams != null && param.AssociatedParams != undefined) {
            self.addAssociatedParams(param.AssociatedParams);
        }
    }

    function jobStatusViewModel(jobStatus) {
        var self = this;
        self.statusHeader = '';
        self.status = '';
        self.startedOn = '';
        self.endedOn = '';
        self.elapsedTime = '';
        self.enableTriggerButton = false;
        self.statusHeaderClass = '';

        self.constJobStatusUnknown = 0;
        self.constJobStatusAppNotDefined = 1;
        self.constJobStatusNoMatchingAppOrUnAuthorized = 2;
        self.constJobStatusIsInvalidAppSpec = 3;
        self.constJobStatusCompleted = 4;
        self.constJobStatusInCompleteDependentJobs = 5;
        self.constJobStatusResponseInBadFormat = 6;
        self.constJobStatusNoPriorHistory = 7;

        self.setJobStatus = function (jobStatus) {
            switch (jobStatus.Status)
            {
                case self.constJobStatusAppNotDefined:
                case self.constJobStatusNoMatchingAppOrUnAuthorized:
                    self.statusHeader = 'Last Run';
                    self.status = 'N/A';
                    self.startedOn = 'N/A';
                    self.endedOn = 'N/A';
                    self.elapsedTime = 'N/A'
                    self.enableTriggerButton = true;
                    break;
                case self.constJobStatusIsInvalidAppSpec:
                    self.statusHeader = 'Last Run';
                    self.status = 'Job Not Found';
                    self.startedOn = 'N/A';
                    self.endedOn = 'N/A';
                    self.elapsedTime = 'N/A'
                    self.enableTriggerButton = false;
                    break;
                case self.constJobStatusCompleted:
                    self.statusHeader = 'Last Run';
                    self.status = 'Completed';
                    self.startedOn = formatDate(jobStatus.StartedOn, jobStatus.TimeZone);
                    self.endedOn = formatDate(jobStatus.EndedOn, jobStatus.TimeZone); //return n/a if invalid date
                    self.elapsedTime = 'N/A'
                    self.enableTriggerButton = true;
                    break;
                case self.constJobStatusInCompleteDependentJobs:
                    self.statusHeader = 'Running Currently';
                    self.statusHeaderClass = 'textRed'
                    self.status = 'Dependent processes are running or on hold. (' + jobStatus.InCompleteJobs + ')';
                    self.startedOn = formatDate(jobStatus.StartedOn, jobStatus.TimeZone);
                    self.endedOn = 'N/A';
                    self.elapsedTime = jobStatus.ElapsedTime;
                    self.enableTriggerButton = false;
                    break;
                case self.constJobStatusUnknown:
                    self.statusHeader = 'Last Run';
                    self.status = 'Unknown';
                    self.startedOn = formatDate(jobStatus.StartedOn, jobStatus.TimeZone);
                    self.endedOn = formatDate(jobStatus.EndedOn, jobStatus.TimeZone);
                    self.elapsedTime = 'N/A';
                    self.enableTriggerButton = false;
                    break;
                case self.constJobStatusResponseInBadFormat:
                    self.statusHeader = 'Last Run';
                    self.startedOn = self.endedOn = self.elapsedTime = 'N/A';
                    self.status = "Esp job reponse in bad json format or contain invalid characters, please contact Esp admin. Partial information is: " + jobStatus.Error;
                    break;
                case self.constJobStatusNoPriorHistory:
                    self.statusHeader = self.startedOn = self.endedOn = self.elapsedTime = 'N/A';
                    self.status = jobStatus.Error;
                    self.enableTriggerButton = true;
            }
        };

        self.setJobStatus(jobStatus);
    }

    function formatDate(d, tz) {
        var returnValue = 'N/A';
        if (d != null && d != undefined && d != '') {
            returnValue = d + ' (' + tz + ')';
        }
        return returnValue;
    }

})(window.jQuery);