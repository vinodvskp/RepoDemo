﻿(function (module) {

    module.controller('userUploadFeedController', ["$scope", "$state", "userUploadFeedService", "alertingService", "spinnerService", "userProfileService", "mainService", userUploadFeedController]);

    function userUploadFeedController($scope, $state, userUploadFeedService, alertingService, spinnerService, userProfileService, mainService) {
        var self = $scope;

        self.AvailableFactTables = [];
        self.SelectedFileType = null;
        self.SelectedFactTable = null;

        self.isFileTypeLoading = false;

        self.CurrentUser = null;
        //self.FactTableSettings = null;

        self.stepVM = [];

        self.CurrentStep = 0;

        self.FactDataUploadChildScope = null;

        self.MaxUploadFileSize = null;

        self.setCurrentStep = function (stepNumber) {
            self.CurrentStep = stepNumber;
            for (var stepIndex = 0; stepIndex < 4; stepIndex++) {
                self.stepVM[stepIndex].IsActive = (stepNumber == (stepIndex + 1));
            }
        }
        self.gotoStep = function (fromStepNumber, toStepNumber) {
            
            if (fromStepNumber == toStepNumber) {
                return false;
            }

            if (toStepNumber == 1 && self.stepVM.length > 0 && self.stepVM[0].IsAvailable == false) {
                return false;
            }

            if ((fromStepNumber == null || fromStepNumber == 1) && toStepNumber > 1) {
                //self.CurrentStep = toStepNumber;
                self.setCurrentStep(toStepNumber);
                $state.go("userUploadFeed.factDataUpload");
            }
            else if ((fromStepNumber == null || fromStepNumber > 1) && toStepNumber == 1) {
                //self.CurrentStep = toStepNumber;
                self.setCurrentStep(toStepNumber);
                $state.go("userUploadFeed.keyComboUpload", {
                    factTableId: self.SelectedFactTable.FactTableId,
                    fileTypeCodeId: self.SelectedFileType.FileTypeCodeId,
                    fileTypeUsesValidKeyCombo: self.SelectedFileType.UsesValidKeyCombo
                });
            }
            else if (fromStepNumber > 1 && toStepNumber > 1) {
                //if (self.$$childTail.gotoChildStep(toStepNumber)) {
                if (self.FactDataUploadChildScope.gotoChildStep(toStepNumber)) {
                    //self.CurrentStep = toStepNumber;
                    self.setCurrentStep(toStepNumber);
                }
                //$state.go("userUploadFeed.factDataUpload");
            }
        }

        //Alerts
        self.validationSummary = [];
        self.closeValidationSummary = function (index) {
            self.validationSummary.splice(index, 1);
        };
        self.showAlert = function (alertType, message) {
            self.validationSummary.push({ type: alertType, msg: message });
        }

        //Spinner
        self.spinnerSemaphoreVM = new spinnerSemaphoreViewModel(spinnerService);

        //handlers

        function onLoad() {

            //Load all file types
            self.isFileTypeLoading = true;
            userProfileService.getUser({ employeeId: mainService.eidService() }, getUserCallback, errorCallback);
            //Current period is specific to fact table, so fetching this info upon fact table type
            //mainService.getFactTableSettings({}, getFactTableSettingsCallback, errorCallback);
            userUploadFeedService.getAllFileTypes([], getAllFactFilesCallback, errorCallback);
            userUploadFeedService.getMaxUploadFileLimit([], getMaxUploadFileLimitCallback, errorCallback);
        }

        self.initializeSteps = function () {
            self.stepVM.splice(0, self.stepVM.length);

            var isImportKeyStepAvailable = self.CurrentUser.CanAddNewFileKeys == true && self.SelectedFileType.UsesValidKeyCombo == true;

            self.stepVM.push(new StepViewModel('Import Key Combinations', true, isImportKeyStepAvailable));
            self.stepVM.push(new StepViewModel('File Upload', false, !isImportKeyStepAvailable));
            self.stepVM.push(new StepViewModel('Validations', false, true));
            self.stepVM.push(new StepViewModel('Success', false, true));

            if (isImportKeyStepAvailable) {
                self.setCurrentStep(1);
                self.gotoStep(null, 1);
            }
            else {
                self.setCurrentStep(2);
                self.gotoStep(null, 2);
            }
        }

        self.onSelectFileType = function (selectedFileType) {
            self.SelectedFileType = selectedFileType;
            if (self.FactDataUploadChildScope != null) {
                self.FactDataUploadChildScope.initController();
            }
            
            self.initializeSteps();
        }

        self.onSelectFactTable = function (selectedFactTable) {
            self.SelectedFactTable = selectedFactTable;
            //clear selected file type
            self.SelectedFileType = null;
            //clear steps
            self.stepVM.splice(0, self.stepVM.length);

            if (selectedFactTable.currentMonth == null || selectedFactTable.currentYear == null) {
                spinnerService.show("overlaySpinner");
                userUploadFeedService.getCurrentPeriod({ factTableId: selectedFactTable.FactTableId }, getCurrentPeriodSuccessCallback, getCurrentPeriodErrorCallback);
            }

        }
        
        //callbacks

        function getCurrentPeriodSuccessCallback(response) {
            self.SelectedFactTable.setCurrentMonth(response.Month);
            self.SelectedFactTable.currentYear = response.Year;
            spinnerService.hide("overlaySpinner");
        }

        function getCurrentPeriodErrorCallback(response) {
            self.validationSummary.push({ type: 'danger', msg: 'Error fetching current period for selected fact table.' });
            spinnerService.hide("overlaySpinner");
        }

        function getUserCallback(response) {
            self.CurrentUser = response;
        }

        /*function getFactTableSettingsCallback(response) {
            self.FactTableSettings = response;
        }*/

        function getAllFactFilesCallback(response) {
            //clear available fact tables
            self.AvailableFactTables.splice(0, self.AvailableFactTables.length);

            for (var factFileCounter = 0; factFileCounter < response.length; factFileCounter++) {
                var factTable = new FactTableViewModel(response[factFileCounter]);
                for (var fileTypeCounter = 0; fileTypeCounter < response[factFileCounter].FileTypes.length; fileTypeCounter++) {
                    factTable.FileTypes.push(new FileTypeViewModel(response[factFileCounter].FileTypes[fileTypeCounter]));
                }
                self.AvailableFactTables.push(factTable);
            }
            self.isFileTypeLoading = false;
        }

        function getMaxUploadFileLimitCallback(response) {
            self.MaxUploadFileSize = response;
        }

        function errorCallback(data) {
            self.validationSummary.push({ type: 'danger', msg: 'Error occured. Refresh the page and try again.' });
            console.log(data);
        }
        
        //Onload
        onLoad();
    }

    //view model

    //function userUploadFeedViewModel() {
    //    var self = this;
    //    self.AvailableFileTypes = [];
    //    self.SelectedFileType = null;
    //}


    function FactTableViewModel(factTable) {
        var self = this;
        self.FactTableId = factTable.Id;
        self.FactTableName = factTable.Name;
        self.FactTableType = factTable.FactTableType;
        self.FileTypes = [];
        self.currentMonth = null;
        self.currentYear = null;
        self.setCurrentMonth = function (cm) {
            if (cm >= 0 && cm <= 9) {
                self.currentMonth = '0' + cm;
            }
            else {
                self.currentMonth = cm;
            }
        };
    }

    function FileTypeViewModel(fileType) {
        var self = this;
        self.FileTypeCodeId = fileType.FileTypeCodeId;
        self.Code = fileType.Code;
        self.UsesValidKeyCombo = fileType.UsesValidKeyCombo;
        self.Description = fileType.Description;
        self.DisplayText = fileType.IsAdjustment === true ?
                                                fileType.Code + ' || Incremental || ' + truncatedString(fileType.Description)
                                                :
                                                fileType.Code + ' || Replace || ' + truncatedString(fileType.Description);
        self.Contains13ColFacts = fileType.Contains13ColFacts;
        self.IsAdjustment = fileType.IsAdjustment;
        self.isSelected = false;
    }

    function spinnerSemaphoreViewModel(spinnerService) {
        var self = this;
        self.semaphore = 0;
        self.addSemaphore = function () {
            self.semaphore++;
            if (self.semaphore == 1) {
                spinnerService.show("overlaySpinner");
            }
        };
        self.reduceSemaphore = function () {
            self.semaphore--;
            if (self.semaphore == 0) {
                spinnerService.hide("overlaySpinner");
            }
        };
    }

    function StepViewModel(name, isActive, isAvailable) {
        var self = this;
        self.Name = name;
        self.IsActive = isActive;
        self.IsAvailable = isAvailable;
    }

    function truncatedString(s) {
        if (s.length > 15) {
            return s.substring(0, 15) + '...';
        }
        else {
            return s;
        }
    }
})(angular.module('vmApp'));