
(function () {

    angular.module('vmApp')
        .controller('createRequestController', ['$scope','$q','$log','serverVariableService','localStoreService', 'alertingService','mainService','orderByFilter','createRequestService','spinnerService',createRequestController]);

    function createRequestController($scope,$q,$log,serverVariableService,localStoreService,alertingService,mainService,orderByFilter,createRequestService,spinnerService) { 
    	var self = this;
    	//todo: get request type data from service
    	self.transactionHeaders = ["Target Version","Transaction ID", "User Name", "Action","Version","Hierarchy","Node","Property","From Value","From Origin","To Value","To Origin"];
    	self.transactionColumnNames = ["targetVersion","TransactionID", "UserName", "Action","Version","Hierarchy","Node","Property","FromValue","FromOrigin","ToValue","ToOrigin"];
        self.showDeltaTable = false;
    	self.sortByColName =self.transactionColumnNames [0];
    	self.sortReverse = true;
    	self.requestTypes = {
    			'buttonLabel':'Select an option',
    			'items': [],
    			'selectedItem':null,
    			'status': { 'isopen':false},
    			'required': null
    	};
    	
    	self.futureVersions = {
    			'buttonLabel':'Select an option',
    			'items': [],
    			'selectedItem':null,
    			'status': { 'isopen':false},
    	        'show': false,
    	        'required':null
    	};
    	self.enableSubmitButton = false;
    	self.showExclusions = false;

    	self.profile =[];
    	self.exclusions = {"required": null,"show":false};// hierachary
    	self.exclusions.leftList =[]; 
    	self.exclusions.rightList =[];
    	self.exclusions.fullList = [];
    	self.transDelta = [];
    	self.transView = [];
        self.inputCache = {"process":"", "futureVersion":"","exclusions":[]};

    	//todo: get delta transactions from service 
    	createRequestService.getRequestTypes({},requestTypesCallback,errorCallback);
    	createRequestService.getProfile({},profileCallback, errorCallback);
    	//createRequestService.getFutureVersions({},futureVersionsCallback, errorCallback);
    	 self.gridOptions = {
    			    columnDefs:  [{name:"targetVersion",field:"targetVersion"},
    			                  {name:"TransactionId",field:"i_TRANSACTION_ID"},
    			                  {name:"UserName",field:"c_USER_NAME"},
    			                  {name:"Action",field:"c_ACTION"},
    			                  {name:"Version",field:"c_VERSION_ABBREV"},
    			                  {name: "Hierarchy",field:"c_HIERARCHY_ABBREV"},
    			                  {name: "Node",field:"c_NODE_ABBREV"},
    			                  {name:"Property",field:"c_PROPERTY_ABBREV"},
    			                  {name:"FromValue",field:"x_FROM_VALUE"},
    			                  {name:"FromOrigin",field:"c_FROM_ORIGIN"},
    			                  {name:"ToValue",field:"x_TO_VALUE}"},
    			                  {name:"ToOrigin",field:"c_TO_ORIGIN"}],
    	            enableFiltering: false,
    	            enableSorting: true,
    	            showGridFooter: true,
    	        };
    	
    	self.selectRequestType = function( item ) {
    		self.exclusions.required = false;
    		self.futureVersions.required = false;
    		self.requestTypes.selectedItem = item;
    		self.requestTypes.buttonLabel = item.requestType;
    		self.requestTypes.required = null;
    		self.futureVersions.show = showFutureVersions(self.requestTypes.selectedItem.requestType);
    		self.exclusions.show = showExclusions(self.requestTypes.selectedItem.requestType);
    		if (self.futureVersions.show == true) {
    			createRequestService.getFutureVersions({},futureVersionsCallback, errorCallback);
    		}
    		if (self.exclusions.show) {
    			createRequestService.getHierarchiesByVersion({'version':item.versionType},hierarchiesByVersionCallback, errorCallback);
    		}
 		};
 		
 		self.selectFutureVersion = function (item){
 			self.futureVersions.selectedItem = item;
    		self.futureVersions.buttonLabel = item.versionName + '(' + item.application + ')';
    		self.exclusions.show = showExclusions(self.requestTypes.selectedItem.requestType);
    		self.futureVersions.required = null;
 		}
 	

 		this.transactionSortBy = function (colName) {
 	        this.sortReverse = (colName !== null && this.sortByColName === colName)
 	            ? !this.sortReverse : false;
 	        this.sortByColName = colName;
 	        this.deltaTransactions = orderByFilter(this.deltaTransactions, this.sortByColName, this.sortReverse);
 	       
 	    };
 	    
 	    self.calculateDelta = function() {
 	    	var payload ={};
 	    	self.transView =[];
 	    	self.transDelta =[];
 	    	//1.todo: make a service call to retrieve transaction delta
 	    	//2. show transactions in table - should we make the table display portion a child view?
 	    	if(!self.requestTypes.selectedItem) {
 	    		self.requestTypes.required = true;
 	    		return;
 	    	}
 	    	var selectedRequestType = self.requestTypes.selectedItem.requestType;
 	    	switch (selectedRequestType) {
 	    	  case "Emergency":
 	    		  payload ={"process":"ER"};
 	    		  self.inputCache.process ="ER";
 	    		  break;
 	    	  case "ERP":
 	    		  payload ={"process":"ERP"};
 	    		  self.inputCache.process="ERP";
 	    		  break;
 	    	  case "Open Blackout Period":
 	    		 payload ={"process":"OBP"};
 	    		 self.inputCache.process ="OBP";
 	    	     break;
 	    	  case "Close Blackout Period":
 	    		 
 	    		 var selectedExclusions = self.getSelectedExclusions();
 	    		
 	    		 if(selectedExclusions.length==0) {
 	    			self.exclusions.required = true;
 	    			return;
 	    		 }
 	    		
 	    	     payload = {"process":"CBP", "exclusions": selectedExclusions};
 	    	     self.inputCache.process ="CBP";
 	    	     self.inputCache.exclusions = selectedExclusions;
 	    	     break;
 	    	  case "Future":
 	    		 self.exclusions.required = false;
 	    		 if(!self.futureVersions.selectedItem) {
 	    			self.futureVersions.required = true;
	    			 return;
	    		 } 
  	    	     payload = {"process":"PFR","futureVersion":self.futureVersions.selectedItem.versionName};
  	    	     self.inputCache.process ="PFR";
	    	     self.inputCache.futureVersion = self.futureVersions.selectedItem.versionName;
  	    	     break;
 	    	  default:
 	    	    console.log("no request type selected");
 	    	}
 	    	self.futureVersions.required = null;
 	    	spinnerService.show("overlaySpinner");
 	    	createRequestService.calculateTransDelta(payload,transDeltaCallback, errorCallback);
 	    	self.exclusions.leftList = self.exclusions.fullList;
 	    	self.exclusions.rightList = [];
 	    }
 	    
 	    self.submitRequest = function() {
 	    	var payload = {};
 	    	payload.process = self.inputCache.process;
 	    	payload.futureVersion = self.inputCache.futureVersion;
 	    	payload.exclusions = self.inputCache.exclusions;
 	    	payload.delta = self.transDelta;
 	    	console.log(payload);
 	    	spinnerService.show("overlaySpinner");
 	    	createRequestService.submitRequest(payload,submitRequestCallback, errorCallback);
 	    }
 	    
 	    self.getSelectedExclusions = function() {
 	    	//this function is a hack for getting selectedExclusions - because there isn't a simple angular-way available to handle the drag-n-drop lists.
 	    	var selectedExclusions = [];
 	    	jQuery("#exclusionRightList > li").each(function() { selectedExclusions.push(jQuery(this).text());});
 	    	self.exclusions.rightList = selectedExclusions;
 	    	self.exclusions.leftList = jQuery(self.exclusions.fullList).not(selectedExclusions).get();
 	    	return selectedExclusions;
 	    }
 	    
 		function requestTypesCallback(response) {
    		self.requestTypes.items = response.data;
    	}
    	
 		function futureVersionsCallback(response) {
    		self.futureVersions.items = response.data;
    	}
 		
 		function transDeltaCallback(response) {
 			self.transDelta =[];
    		self.transDelta.push.apply(self.transDelta,response.data);
    		self.transView = buildTransView (self.transDelta);
    		
    		self.gridOptions.data = self.transView;
    		console.log(self.transView);
    		self.showDeltaTable = true;
    		spinnerService.hide("overlaySpinner");
    		if(self.transDelta.length > 0) {
    			self.enableSubmitButton = true;
    		}
    		else {
    			self.enableSubmitButton = false;
    		}
    	}
 		
 		function createBigdataSet(row)
 		{
 			for(var i =1; i < 350000; i++) {
 				self.transView.push(JSON.parse(JSON.stringify(row)));
 			}
 			
 		}
 		function submitRequestCallback(response){
 			console.log(response);
 			spinnerService.hide("overlaySpinner");
 		}
 		
 		function buildTransView (transDelta) {
 			var tView= [];
 			for(var i = 0; i < transDelta.length; i++){
 				if(transDelta[i].drmTransaction.length >0) {
 					for(var k=0; transDelta[i].drmTransaction[k]; k++) {
 						var transItem = mergeObjects({"targetVersion":transDelta[i].targetVersion}, transDelta[i].drmTransaction[k]);
 						tView.push(transItem);
 					}
 				}
 		    }
 			return tView;
 		}
 		
 		function mergeObjects(obj, src) {
	 		for (var key in src) {
	 		        if (src.hasOwnProperty(key)) {
	 		           if ( src[key] === null) {
	 		        	   obj[key] = "";
	 		           }
	 		           else {
	 		        	  obj[key] = src[key];
	 		           }
	 		        }
	 		        	
	 		}
	 		return obj;
        }
 		
    	function errorCallback(data) {
    		console.log(data);
    		spinnerService.hide("overlaySpinner");
    	}	
    	
    	function profileCallback(response) {
    		self.profile = response.data;
    	}
    	
    	function hierarchiesByVersionCallback(response) {
    		self.exclusions.leftList =[];
    		self.exclusions.fullList =[];
    		self.exclusions.leftList.push.apply(self.exclusions.leftList,response.data);
    		self.exclusions.fullList.push.apply(self.exclusions.fullList,response.data);
    	}
    	
    	function showFutureVersions (selectedRequestType)
    	{
    		var canShow;
    		if (selectedRequestType =="Future") {
    			canShow = true;
    		}
    		else {
    			canShow = false;
    		}
    		return canShow;
    	}
    	
  
    	function showExclusions (selectedRequestType)
    	{
    		var canShow;
    		if(selectedRequestType =="Close Blackout Period"){
    			canShow = true
    		}
    		else {
    			canShow = false;
    		}
    			
    		return canShow;
    	}
    	    
    }   	   	

}());