﻿
(function ($) {

    angular.module('vmApp')
        .controller('factAuditController', ['$scope', 'factAuditService', '$uibModal', 'spinnerService', 'userUploadsService', 'userUploadFeedService', 'serverVariableService', factAuditController]);

    function factAuditController($scope, factAuditService, $uibModal, spinnerService, userUploadsService, userUploadFeedService, serverVariableService) {

        var self = $scope;

        self.validationSummary = [];
        self.closeValidationSummary = function (index) {
            self.validationSummary.splice(index, 1);
        };
        self.factAuditViewModel = null;

        self.isFactTableFieldLoading = false;
        self.isYearsFieldLoading = false;

        self.showAlert = function (alertType, message) {
            self.validationSummary.push({ type: alertType, msg: message });
        }

        self.spinnerSemaphoreVM = new spinnerSemaphoreViewModel(spinnerService);




        self.responseGridVM = null;
        self.responseGridViewUrl = serverVariableService.SITE_SUBFOLDER() + "mduaApp/templates/responseTableView.html";

        self.dimValuesGridVM = null;
        self.dimValuesGridGridApi = null;

        self.onLoad = function () {

            self.factAuditViewModel = new FactAuditViewModel();

            self.spinnerSemaphoreVM.addSemaphore();
            userUploadsService.getAllFactTable({}, getAllFactTableCallback, errorCallback);

            self.spinnerSemaphoreVM.addSemaphore();
            userUploadFeedService.getDimYears({}, getDimYearsCallback, errorCallback);

        }

        self.onSelectFactTable = function (selectedItem) {
            self.factAuditViewModel.SelectedFactTable = selectedItem;
            self.factAuditViewModel.Clear();
            self.responseGridVM = null;
        }

        self.onSelectYear = function (selectedItem) {
            self.factAuditViewModel.SelectedYear = selectedItem;
        }

        self.onSelectMonth = function (selectedItem) {
            self.factAuditViewModel.SelectedMonth = selectedItem;
        }

        self.onFilterClick = function (dim) {
            self.spinnerSemaphoreVM.addSemaphore();
            self.factAuditViewModel.SelectedDimensionForFilter = dim;
            var auditRequest = new FactAuditRequestViewModel(self.factAuditViewModel.SelectedFactTable.Id, '', '', [dim]);

            factAuditService.getDimensionValues(auditRequest, getDimensionValuesCallback, errorCallback);

        }

        self.onSelectDimensionValue = function (dimValue) {
            self.factAuditViewModel.SelectedDimensionForFilter.UserValue = dimValue;
            //$uibModalInstance.close("OK");
        }

        self.onViewClick = function () {

            if (self.factAuditViewModel.SelectedYear == null) {
                self.showAlert('danger', 'Select a year to continue');
            }

            if (self.factAuditViewModel.SelectedMonth == null) {
                self.showAlert('danger', 'Select a month to continue');
            }

            var auditRequest = new FactAuditRequestViewModel(self.factAuditViewModel.SelectedFactTable.Id, self.factAuditViewModel.SelectedMonth.id,
                self.factAuditViewModel.SelectedYear, self.factAuditViewModel.SelectedFactTable.AvailableDimensions);

            self.spinnerSemaphoreVM.addSemaphore();
            factAuditService.getAuditData(auditRequest, getAuditDataCallback, errorCallback);
        }

        self.onDownloadClick = function () {
            if (self.factAuditViewModel.SelectedYear == null) {
                self.showAlert('danger', 'Select a year to continue');
            }

            if (self.factAuditViewModel.SelectedMonth == null) {
                self.showAlert('danger', 'Select a month to continue');
            }

            var auditRequest = new FactAuditRequestViewModel(self.factAuditViewModel.SelectedFactTable.Id, self.factAuditViewModel.SelectedMonth.id,
                self.factAuditViewModel.SelectedYear, self.factAuditViewModel.SelectedFactTable.AvailableDimensions);

            self.spinnerSemaphoreVM.addSemaphore();
            factAuditService.exportAuditData(auditRequest, exportAuditDataCallback, errorCallback);
        }


        self.onOk = function () {
            var vm = self.dimValuesGridGridApi.selection.getSelectedRows();
            if (vm != null && vm.length > 0) {
                self.factAuditViewModel.SelectedDimensionForFilter.UserValue = vm[0].Data[0];
                self.factAuditViewModel.Mode = 'main';
            }
            else {
                self.factAuditViewModel.Mode = 'main';
            }
        }

        self.onCancel = function () {
            self.factAuditViewModel.Mode = 'main';
        }
        //call backs

        function exportAuditDataCallback(response) {
            var binaryString = window.atob(response);
            var blob = new Blob([binaryString], { type: "text/plain;charset=utf-8" });
            saveAs(blob, "AuditDownload.csv");
            //var sampleArr = base64ToArrayBuffer(response);
            //saveByteArray("ExportAudit", sampleArr);
            self.spinnerSemaphoreVM.reduceSemaphore();
        }

        function getAllFactTableCallback(response) {
            self.factAuditViewModel.AvailableFactTables.splice(0, self.factAuditViewModel.AvailableFactTables.length);
            for (var idx = 0; idx < response.length; idx++) {
                self.factAuditViewModel.AvailableFactTables.push(new FactTableViewModel(response[idx]));
            }
            self.spinnerSemaphoreVM.reduceSemaphore();
        }

        function getDimYearsCallback(response) {
            self.factAuditViewModel.AvailableYears.splice(0, self.factAuditViewModel.AvailableYears);
            for (var idx = 0; idx < response.length; idx++) {
                self.factAuditViewModel.AvailableYears.push(response[idx]);
            }
            self.spinnerSemaphoreVM.reduceSemaphore();
        }

        function getAuditDataCallback(response) {
            var r = response;

            self.responseGridVM = new ResponseDataGridViewModel(response.ResponseTableColumns, response.ResponseTableData);

            self.spinnerSemaphoreVM.reduceSemaphore();
        }

        function getDimensionValuesCallback(response) {

            self.dimValuesGridVM = new DimensionListGridViewModel(['Dimension Values'], response, $scope);
            self.factAuditViewModel.Mode = 'filter';
            self.spinnerSemaphoreVM.reduceSemaphore();


        }


        function errorCallback(data) {
            self.showAlert('danger', 'Error occured. Refresh the page and try again.');
            console.log(data);
            self.spinnerSemaphoreVM.reduceSemaphore();
        }

        //Load Page
        self.onLoad();
    }

    //view models
    function FactAuditViewModel() {
        var self = this;
        self.AvailableMonths = [];
        self.AvailableYears = [];
        self.AvailableFactTables = ['gl', 'hc'];

        self.SelectedMonth = null;
        self.SelectedYear = null;
        self.SelectedFactTable = null;

        self.AvailableDimensionValues = [];
        self.SelectedDimensionForFilter = null;

        self.Mode = "main";

        self.Clear = function () {
            self.AvailableDimensionValues.splice(0, self.AvailableDimensionValues.length);
            self.SelectedDimensionForFilter = null;
        }

        self.setAvailableMonths = function () {
            //clear months list if present
            self.AvailableMonths.splice(0, self.AvailableMonths.length);
            self.AvailableMonths.push({ id: '01', value: 'January' });
            self.AvailableMonths.push({ id: '02', value: 'February' });
            self.AvailableMonths.push({ id: '03', value: 'March' });
            self.AvailableMonths.push({ id: '04', value: 'April' });
            self.AvailableMonths.push({ id: '05', value: 'May' });
            self.AvailableMonths.push({ id: '06', value: 'June' });
            self.AvailableMonths.push({ id: '07', value: 'July' });
            self.AvailableMonths.push({ id: '08', value: 'August' });
            self.AvailableMonths.push({ id: '09', value: 'September' });
            self.AvailableMonths.push({ id: '10', value: 'October' });
            self.AvailableMonths.push({ id: '11', value: 'November' });
            self.AvailableMonths.push({ id: '12', value: 'December' });
        }
        self.setAvailableMonths();
    }

    function FactTableViewModel(factTable) {

        var self = this;

        self.Id = factTable.Id;
        self.Name = factTable.Name;
        self.Description = factTable.Description;
        self.AvailableDimensions = [];

        self.SetAvailableDimensions = function (d) {
            self.AvailableDimensions.splice(0, self.AvailableDimensions.length);
            for (var idx = 0; idx < d.length; idx++) {
                self.AvailableDimensions.push(new DimensionViewModel(d[idx]));
            }
        }

        self.SetAvailableDimensions(factTable.AvailableDimensions);
    }

    function DimensionViewModel(dim) {

        var self = this;
        self.Id = dim.Id;
        self.Name = dim.Name;
        self.Code = dim.Code;
        self.UserValue = "";
    }

    function FactAuditRequestViewModel(factTableId, month, year, auditCriteria) {
        var self = this;
        self.FactTableId = factTableId;
        self.ReportingPeriod = { Month: month, Year: year };
        self.AuditCriteria = auditCriteria;
    }


    function spinnerSemaphoreViewModel(spinnerService) {
        var self = this;
        self.semaphore = 0;
        self.addSemaphore = function () {
            self.semaphore++;
            if (self.semaphore == 1) {
                spinnerService.show("overlaySpinner");
            }
        };
        self.reduceSemaphore = function () {
            self.semaphore--;
            if (self.semaphore == 0) {
                spinnerService.hide("overlaySpinner");
            }
        };
    }

    function ResponseDataGridViewModel(columns, data) {
        var self = this;

        self.Columns = columns;
        self.Data = data;
        self.Rows = [];
        self.GridColumnDefs = [];

        self.getGridWidth = function () {
            return $('#userUploadFeedGrid').width();
        };

        self.calculateTotalColumnWidth = function (colList) {
            var totalColWidth = 0;
            var colListVM = { "totalColWidth": totalColWidth, "colWidthList": [] };
            for (var colInd = 0; colInd < colList.length; colInd++) {
                var colWidth = self.calculateColWidth(colList[colInd]);
                colListVM.totalColWidth = colListVM.totalColWidth + colWidth;
                colListVM.colWidthList.push(colWidth);
            }
            return colListVM;
        }

        self.isColumnWidthComputationNeeded = function (colList, gridWidth) {
            var colListVM = self.calculateTotalColumnWidth(colList);
            var isNeeded = false;
            if (colListVM.totalColWidth > gridWidth) {
                isNeeded = true;
            }
            $.extend(colListVM, { "isColWidthComputeNeeded": isNeeded });
            return colListVM;
        }

        self.calculateColWidth = function (columnText) {
            var coltextLength = columnText.length;
            return (coltextLength * 15);
        }

        self.PivotData = function () {

            //
            var colListVM = self.isColumnWidthComputationNeeded(self.Columns, self.getGridWidth());

            for (var colIndex = 0; colIndex < self.Columns.length; colIndex++) {
                var colDef = new GridColumnDefViewModel(self.Columns[colIndex], 'Data[' + colIndex + ']', true, (colListVM.isColWidthComputeNeeded === true ? self.calculateColWidth(self.Columns[colIndex]) : ''));
                self.GridColumnDefs.push(colDef);
            }

            for (var rowIndex = 0; rowIndex < self.Data[0].Values.length; rowIndex++) {
                var trvm = new TableRowViewModel();

                for (var colIndex = 0; colIndex < self.Data.length; colIndex++) {
                    trvm.Data.push(self.Data[colIndex].Values[rowIndex]);
                }
                self.Rows.push(trvm);

            }
            //for (var rowIndex = 0; rowIndex < self.Data[0].length; rowIndex++) {
            //    var trvm = new TableRowViewModel();
            //    //trvm.RowId = rowIndex;

            //    //push empty data for validation
            //    trvm.Data.push("");
            //    for (var colIndex = 0; colIndex < self.Data.length; colIndex++) {
            //        trvm.Data.push(self.Data[colIndex][rowIndex]);

            //        self.Rows.push(trvm);
            //    }
            //}
        };

        self.gridOptions = {
            enableSelectAll: true,
            enableRowSelection: true,
            enableFiltering: false,
            enableSorting: true,
            columnDefs: self.GridColumnDefs,
            data: self.Rows,
            showGridFooter: true,
            exporterPdfDefaultStyle: { fontSize: 9 },
            exporterPdfTableStyle: { margin: [30, 30, 30, 30] },
            exporterPdfTableHeaderStyle: { fontSize: 10, bold: true, italics: true, color: 'red' },
            exporterPdfHeader: { text: "My Header", style: 'headerStyle' },
            exporterPdfFooter: function (currentPage, pageCount) {
                return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
            },
            exporterPdfCustomFormatter: function (docDefinition) {
                docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
                docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
                return docDefinition;
            },
            exporterPdfOrientation: 'portrait',
            exporterPdfPageSize: 'LETTER',
            exporterPdfMaxGridWidth: 500,
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location"))
        };


        self.createGrid = function (columns, data) {
            //self.clearGrid();
            self.gridOptions = new GridOptionsViewModel(false, false, columns, data, 20);
        }

        self.clearGrid = function () {
            self.gridOptions = null;
            //raise event
        }


        if (self.Columns.length > 0) {
            self.PivotData();
        }


        //self.createGrid();
    }

    function TableRowViewModel() {
        var self = this;
        self.Data = [];
        self.IsSelected = false;
    }

    function GridColumnDefViewModel(name, field, isVisible, width) {
        var self = this;
        self.name = name;
        self.field = field;
        self.enableCellEdit = false;
        self.visible = isVisible;

        if (width != null && width != '') {
            self.width = width;
        }

        //self.cellClass = function (grid, row, col, rowRenderIndex, colRenderIndex) {
        //    if (row.entity.ValidationType == "1") {
        //        return "red";
        //    }
        //};
        self.filter = undefined;


    }

    function GridOptionsViewModel(enableFiltering, enableSorting, columns, data, minRowsToShow) {
        var self = this;

        self.columnDefs = [];

        for (var colInd = 0; colInd < columns.length; columns++) {
            self.columnDefs.push({ name: columns[colInd], field: columns[colInd], enableCellEdit: false, width: 200 });
        }

        self.enableFiltering = enableFiltering;
        self.enableSorting = enableSorting;
        self.data = data;
        self.minRowsToShow = minRowsToShow;
    }

    function DimensionListGridViewModel(columns, data, $scope) {
        var self = this;

        self.Columns = columns;
        self.Data = data;
        self.Rows = [];
        self.GridColumnDefs = [];


        self.getGridWidth = function () {
            return $('#userUploadFeedGrid').width();
        };

        self.calculateTotalColumnWidth = function (colList) {
            var totalColWidth = 0;
            var colListVM = { "totalColWidth": totalColWidth, "colWidthList": [] };
            for (var colInd = 0; colInd < colList.length; colInd++) {
                var colWidth = self.calculateColWidth(colList[colInd]);
                colListVM.totalColWidth = colListVM.totalColWidth + colWidth;
                colListVM.colWidthList.push(colWidth);
            }
            return colListVM;
        }

        self.isColumnWidthComputationNeeded = function (colList, gridWidth) {
            var colListVM = self.calculateTotalColumnWidth(colList);
            var isNeeded = false;
            if (colListVM.totalColWidth > gridWidth) {
                isNeeded = true;
            }
            $.extend(colListVM, { "isColWidthComputeNeeded": isNeeded });
            return colListVM;
        }

        self.calculateColWidth = function (columnText) {
            var coltextLength = columnText.length;
            return (coltextLength * 15);
        }

        self.SetData = function () {

            var colDef = new GridColumnDefViewModel(self.Columns[0], 'Data[0]', true, '');
            self.GridColumnDefs.push(colDef);

            for (var rowIndex = 0; rowIndex < self.Data.length; rowIndex++) {
                var trvm = new TableRowViewModel();
                trvm.Data.push(self.Data[rowIndex]);
                self.Rows.push(trvm);
            }
        };

        self.gridOptions = {
            enableSelectAll: false,
            enableRowSelection: true,
            enableFiltering: false,
            enableSorting: true,
            columnDefs: self.GridColumnDefs,
            data: self.Rows,
            multiSelect : false,
            showGridFooter: true,
            exporterPdfDefaultStyle: { fontSize: 9 },
            exporterPdfTableStyle: { margin: [30, 30, 30, 30] },
            exporterPdfTableHeaderStyle: { fontSize: 10, bold: true, italics: true, color: 'red' },
            exporterPdfHeader: { text: "My Header", style: 'headerStyle' },
            exporterPdfFooter: function (currentPage, pageCount) {
                return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
            },
            exporterPdfCustomFormatter: function (docDefinition) {
                docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
                docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
                return docDefinition;
            },
            exporterPdfOrientation: 'portrait',
            exporterPdfPageSize: 'LETTER',
            exporterPdfMaxGridWidth: 500,
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location"))
        };

        self.gridOptions.onRegisterApi = function (gridApi) {
            //set gridApi on scope
            $scope.dimValuesGridGridApi = gridApi;
            //$scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.OPTIONS);
        };


        self.createGrid = function (columns, data) {
            //self.clearGrid();
            self.gridOptions = new GridOptionsViewModel(false, false, columns, data, 20);
        }

        self.clearGrid = function () {
            self.gridOptions = null;
            //raise event
        }


        if (self.Columns.length > 0) {
            self.SetData();
        }


        //self.createGrid();
    }

})(window.jQuery);