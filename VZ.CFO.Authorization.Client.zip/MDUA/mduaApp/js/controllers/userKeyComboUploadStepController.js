﻿(function (module) {

    module.controller('userKeyComboUploadStepController', ["$scope", "$state", "$uibModal", "$stateParams", "userUploadsService", "alertingService", "spinnerService", "serverVariableService", "uiGridConstants", "mainService",
        function userKeyComboUploadStepController($scope, $state, $uibModal, $stateParams, userUploadsService, alertingService, spinnerService, serverVariableService, uiGridConstants, mainService) {
            $scope.vm = {};
            $scope.responseGridVM = null;
            $scope.gridApi = null;
            $scope.responseGridViewUrl = serverVariableService.SITE_SUBFOLDER() + "mduaApp/templates/responseTableView.html";
            $scope.pagerVM = new PagerViewModel();
            $scope.showKeyComboContinueButton = false;
            $scope.isDeleteAll = false;
            $scope.isImportMode = true;
            $scope.factSettings = null;
            $scope.MaxUploadFileSize = $scope.$parent.MaxUploadFileSize;

            //function fileLoaded(filename, dataUri) {
            //    var strArray = dataUri.split(",");
            //    var base64Str = strArray[strArray.length - 1];
            //    $scope.vm.uploadedFileData = {
            //        name: filename,
            //        FileForUploadInbase64: base64Str
            //    };

            //    $scope.$apply();
            //}

            var initializeDragAndDrop = function (dropperElmClassName) {
                if (typeof window.FileReader === 'undefined')
                    alert('File API & FileReader not supported');
                var dropper = $(dropperElmClassName)[0];
                dropper.ondragover = function () { $(dropper).addClass('hover'); return false; };
                dropper.ondragend = function () { $(dropper).removeClass('hover'); return false; };
                dropper.ondrop = function (e) {
                    e.preventDefault();
                    var files = [].slice.call(e.dataTransfer.files);

                    if (files.length > 0 && window.FormData !== undefined) {
                        var data = new FormData();
                        data.append("file0", files[0]);

                        $scope.vm.uploadedFileData = {
                            name: files[0].name,
                            FileForUploadInbase64: '',
                            File: data,
                            IsFileLoading: "complete"
                        };

                        $scope.$apply();
                    }
                    else {
                        alert('Your browser does not support upload. Please use another browser.');
                    }

                    //files.forEach(function (file) {
                    //    var reader = new FileReader();
                    //    reader.onload = function (event) {
                    //        fileLoaded(file.name, event.target.result);
                    //    };
                    //    reader.readAsDataURL(file);
                    //    $(dropper).removeClass('hover');
                    //});
                    return false;
                };
            }

            var getKeyCombinations = function (factTableId, fileTypeCodeId, pageNumber, successCallBack, failureCallBack) {
                $scope.vm.showImportedKeyCombinations = false;
                var reqData = {
                    FactTableId: factTableId,
                    FileTypeCodeId: fileTypeCodeId,
                    PagingInfo: {
                        PageNumber: pageNumber,
                        RowsPerPage: $scope.pagerVM.itemsPerPage,
                    }
                };

                spinnerService.show("overlaySpinner");
                return userUploadsService.getKeyCombinations(reqData, function (response) {
                    spinnerService.hide("overlaySpinner");
                    $scope.$parent.showAlert('success', response.Message);
                    successCallBack(response);
                }, function (error) {
                    $scope.$parent.showAlert('danger', 'Error while fetching key combinations. Contact administrator.');
                    spinnerService.hide("overlaySpinner");
                    failureCallBack(error);
                });
            }

            var reArrangeKeyCombinations = function (keyCombinationsData, hasURowId) {
                if (!keyCombinationsData) {
                    return [];
                }
                var totalRows = keyCombinationsData.map(function (d) { return d.Values.length; }).sort(function (a, b) { return b - a; })[0];
                var rows = Array.apply(null, { length: totalRows + 1 }).map(Number.call, Number).slice(hasURowId ? 1 : 0)
                var keyCombinations = [];
                angular.forEach(rows, function (row, i) {
                    var values = keyCombinationsData.map(function (d) { if (d.Values.length - 1 >= i) return d.Values[i]; });
                    if (hasURowId) {
                        values.splice(0, 1);
                    }
                    var keyCombination = {
                        id: keyCombinationsData[0].Values[i],
                        values: values
                    };

                    keyCombinations.push(keyCombination);
                });

                return keyCombinations;
            }


            var init = function () {
                spinnerService.show("overlaySpinner");
                $scope.factTableId = $stateParams.factTableId;
                $scope.fileTypeCodeId = $stateParams.fileTypeCodeId;
                $scope.fileTypeUsesValidKeyCombo = $stateParams.fileTypeUsesValidKeyCombo;
                mainService.getFactTableSettings({}, getFactTableSettingsCallback, errorCallback);
                console.log("key combo route initiated.");
                initializeDragAndDrop(".dropper");

            }

            $scope.onCancelUpload = function () {
                $("#fileform")[0].reset();
                $scope.vm.uploadedFileData = undefined
            }

            $scope.uploadFactFile = function (uploadFileData) {
                $scope.vm.invalidKeyCombinations = false;
                $scope.isImportMode = true;
                if (!uploadFileData) {
                    // file data not available, skip the uploading
                    return;
                }
                var fileMetadata = {
                    "FileTypeName": uploadFileData.name,
                    "Base64EncodedFile": '',
                    "File": uploadFileData.File
                };
                spinnerService.show("overlaySpinner");
                userUploadsService.uploadFactFile(fileMetadata, function (response) {
                    spinnerService.hide("overlaySpinner");
                    if (response) {
                        //var selectedYear = $scope.$parent.FactTableSettings.CurrentYear, selectedMonth;
                        //var findMonth = $.grep($scope.AvailableMonths, function (p) { return p.id == $scope.$parent.FactTableSettings.CurrentMonth; });
                        //if (findMonth.length == 1) {
                        //    selectedMonth = findMonth[0];
                        //}
                        var factData = new fileUploadFactDataViewModel({
                            SignedUrl: response,
                            FactTableId: $scope.factTableId,
                            FileTypeCodeId: $scope.fileTypeCodeId,
                            UploadProcessType: "1",
                            ReportingPeriod: {
                                "Month": $scope.factSettings.CurrentMonth,
                                "Year": $scope.factSettings.CurrentYear
                            }
                        });
                        spinnerService.show("overlaySpinner");
                        userUploadsService.uploadFactData(factData, function (dataResponse) {
                            $scope.hideImportKeyCombosContinueBtn = dataResponse.MessageType != 2;
                            var msgType = dataResponse.MessageType != 2 ? "danger" : "success";
                            $scope.$parent.showAlert(msgType, dataResponse.Message);
                            spinnerService.hide("overlaySpinner");
                            //var keyCombinations = reArrangeKeyCombinations(dataResponse.ResponseTableData, dataResponse.ResponseTableColumns[0] == "urowid");
                            $scope.vm.importKeyCombinationsData = dataResponse;
                            //$scope.vm.importKeyCombinations = keyCombinations;
                            //$scope.vm.showImportedKeyCombinations = true;

                            if (dataResponse.MessageType == 2 && dataResponse.ResponseTableData != null) {
                                $scope.showKeyComboContinueButton = true;
                            }

                            $scope.responseGridVM = new ResponseDataGridViewModel(dataResponse.ResponseTableColumns, dataResponse.ResponseTableData, false);


                        }, function (error) {
                            $scope.hideImportKeyCombosContinueBtn = true;
                            spinnerService.hide("overlaySpinner");
                            $scope.$parent.showAlert("danger", "Error occured during operation");
                        });
                        // file uploaded sucessfully.
                    }

                    else {
                        $scope.vm.invalidKeyCombinations = true;
                    }
                }, function (error) {
                    spinnerService.hide("overlaySpinner");
                    $scope.vm.invalidKeyCombinations = true;
                });
            }

            $scope.onBackToStepTwo = function () {
                if ($scope.$parent.onBackToStepTwo) {
                    $scope.$parent.onBackToStepTwo();
                }

            }

            $scope.onGetKeyCombinations = function (pageNumber) {
                $scope.isImportMode = false;
                getKeyCombinations($scope.factTableId, $scope.fileTypeCodeId, pageNumber, function (response) {

                    $scope.responseGridVM = new ResponseDataGridViewModel(response.Columns, response.KeyComboData.Data, true);

                    $scope.pagerVM.setPagingInfo(response.PagingInfo.PageNumber, response.PagingInfo.RowsPerPage, response.PagingInfo.TotalPages, response.PagingInfo.TotalRows);

                    //$scope.vm.keyCombinationsData = response;
                    //$scope.vm.keyCombinations = reArrangeKeyCombinations(response.KeyComboData.Data, response.Columns[0] == "urowid");
                });
            }

            $scope.addKeysFromStagedData = function () {

                var metadata = {

                    RunStatusId: $scope.vm.importKeyCombinationsData.RunStatusId,
                    FactTableId: $scope.factTableId,
                    FileTypeCodeId: $scope.fileTypeCodeId,
                };

                userUploadsService.addKeysFromStagedData(metadata, function (response) {
                    $scope.vm.showImportedKeyCombinations = false;
                    $scope.hideImportKeyCombosContinueBtn = true;
                    if (response) {
                        var msgType = "";
                        if (response.MessageType == 2) {
                            msgType = "success";
                            // $scope.hideImportKeyCombosContinueBtn = true;
                        } else {
                            msgType = "danger";
                        }
                        $scope.$parent.showAlert(msgType, response.Message);
                        $scope.vm.importKeyCombAddKeysResponse = response;
                        $scope.showKeyComboContinueButton = false;
                        $scope.responseGridVM = null;
                    }
                    else {
                        $scope.$parent.showAlert('danger', "response is null");
                        $scope.showKeyComboContinueButton = false;
                    }
                }, function (error) {
                    $scope.$parent.vm.validationSummary.push({ type: 'danger', msg: "Error in import key combinations" });
                    $scope.vm.importKeyCombAddKeysResponse = error;
                })
            }

            $scope.getKeyCombinations = function (factTableId, fileTypeCodeId, successCallBack, failureCallBack) {
                $scope.vm.showImportedKeyCombinations = false;

                var reqData = {
                    FactTableId: factTableId,
                    FileTypeCodeId: fileTypeCodeId,
                    PagingInfo: {
                        PageNumber: $scope.pagerVM.currentPage,
                        RowsPerPage: $scope.pagerVM.itemsPerPage,
                    }
                };
                spinnerService.show("overlaySpinner");
                return userUploadsService.getKeyCombinations(reqData, function (response) {
                    spinnerService.hide("overlaySpinner");
                    successCallBack(response);
                }, function (error) {
                    spinnerService.hide("overlaySpinner");
                    failureCallBack(error);
                });
            }

            $scope.confirmDeleteKeyCombination = function (isDeleteAll) {

                $scope.isDeleteAll = isDeleteAll;

                if (isDeleteAll == false) {
                    var selectedRows = $scope.gridApi.selection.getSelectedRows();

                    if (selectedRows.length == 0) {
                        $scope.$parent.showAlert('danger', "No Key combinations selected to delete");
                        return;
                    }
                }

                $scope.deleteKeyComboModalPopup = $uibModal.open({
                    animation: true,
                    templateUrl: 'confirmDeleteKeyCombination.html',
                    size: 'sm',
                    scope: $scope
                });


                //var deleteKeyCombinationIds = $scope.vm.keyCombinations.filter(function (k) { return k.selected; }).map(function (k) { return k.id; });
                //if (deleteKeyCombinationIds.length == 0) {
                //    $scope.$parent.showModel("No Key combinations selected to delete");
                //    return;
                //}
                //$scope.deleteKeyComboModalPopup = $uibModal.open({
                //    animation: true,
                //    templateUrl: 'confirmDeleteKeyCombination.html',
                //    size: 'sm',
                //    scope: $scope
                //});
            }

            $scope.onFileSelect = function (fileUpload) {
                $scope.vm.uploadedFileData = {};
                $scope.vm.uploadedFileData.IsFileLoading = "loading";
                var files = fileUpload.files;
                if (files.length > 0) {
                    if (window.FormData !== undefined) {
                        var data = new FormData();
                        data.append("file0", files[0]);
                        $scope.vm.FileForUploadInbase64 = '';
                        $scope.vm.uploadedFileData.File = data;
                        $scope.vm.uploadedFileData.IsFileLoading = "complete";
                        $scope.vm.uploadedFileData.name = files[0].name;
                        $scope.$apply();
                    }
                    else {
                        self.$parent.showAlert('danger', 'Your browser does not support file upload. Please use another browser.');
                    }


                    //var fileReader = new FileReader();
                    //fileReader.readAsDataURL(files[0]);

                    //fileReader.onload = function (event) {
                    //    $scope.vm.uploadedFileData.FileForUploadInbase64 = event.target.result.split(',')[1];
                    //    $scope.vm.uploadedFileData.name = files[0].name;
                    //    $scope.vm.uploadedFileData.IsFileLoading = "complete";
                    //    $scope.$apply();
                    //}
                }
            }

            $scope.deleteKeyCombinations = function () {

                var selectedIds = [];

                if ($scope.isDeleteAll == false) {

                    var selectedRows = $scope.gridApi.selection.getSelectedRows();

                    if (selectedRows.length === 0) {
                        // no combintaions to delete
                        $scope.deleteKeyComboModalPopup.close(true);
                        return;
                    }
                    else {
                        for (var idx = 0; idx < selectedRows.length; idx++) {
                            selectedIds.push(selectedRows[idx].Data[0]);
                        }
                    }
                }

                var deleteData = {
                    FactTableId: $scope.factTableId,
                    FileTypeCodeId: $scope.fileTypeCodeId,
                    DeleteOption: $scope.isDeleteAll ? 1 : 0,
                    DeleteRecords: selectedIds
                };


                //var deleteKeyCombinationIds = $scope.vm.keyCombinations.filter(function (k) { return k.selected; }).map(function (k) { return k.id; });
                //if (deleteKeyCombinationIds.length == 0) {
                //    // no combintaions to delete
                //    $scope.deleteKeyComboModalPopup.close(true);
                //    return;
                //}
                //var deleteOption = $scope.isAllCombosSelected ? 2 : 1;
                //var deleteData = {
                //    FactTableId: $scope.factTableId,
                //    FileTypeCodeId: $scope.fileTypeCodeId,
                //    DeleteOption: deleteOption,
                //    DeletedRecords: deleteKeyCombinationIds
                //};

                spinnerService.show("overlaySpinner");
                userUploadsService.deleteKeyCombinations(deleteData, function (response) {
                    spinnerService.hide("overlaySpinner");
                    if (response.Status == 0) {
                        $scope.$parent.showAlert('success', response.Message);
                        $scope.responseGridVM = null;
                        //$scope.vm.keyCombinations = $scope.vm.keyCombinations.filter(function (k) { return deleteKeyCombinationIds.indexOf(k.id) == -1 });
                    }
                    else {
                        $scope.$parent.showAlert('danger', response.Message);
                    }
                    $scope.deleteKeyComboModalPopup.close(true);
                }, function (error) {
                    spinnerService.hide("overlaySpinner");
                    $scope.$parent.showAlert('danger', 'Error occured.');
                    $scope.deleteKeyComboModalPopup.close(true);
                });
            }

            $scope.selectAllKeyCombos = function () {
                $scope.vm.keyCombinations = $scope.vm.keyCombinations.map(function (k) { k.selected = true; return k; });
                $scope.isAllCombosSelected = true;
            }

            $scope.onSelectKeyCombo = function () {
                $scope.isAllCombosSelected = $scope.vm.keyCombinations.filter(function (k) { return !k.selected; }).length == 0;
            }

            function getFactTableSettingsCallback(response) {
                $scope.factSettings = response;
                spinnerService.hide("overlaySpinner");
            }

            $scope.DownloadFile = function () {

                var factDownloadrequest = new FactDownloadRequestViewModel($scope.factTableId, $scope.fileTypeCodeId, '', '', '');

                userUploadsService.getFactDownloadSignedUrl(factDownloadrequest, getFactDownloadSignedUrlCallback, errorCallback);

                function getFactDownloadSignedUrlCallback(response) {
                    var exportUrl = serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/facttable/DownloadKeyCombinations';
                    exportUrl = exportUrl + '?FactTableId=' + $scope.factTableId + "&FileTypeCodeId=" + $scope.fileTypeCodeId;
                    exportUrl = exportUrl + '&StartPeriod=' + null + "&EndPeriod=" + null;
                    exportUrl = exportUrl + '&SignedUrl=' + response;
                    window.open(exportUrl);
                }
            }

            init();

            //view models
            function ResponseDataGridViewModel(columns, data) {
                var self = this;

                self.Columns = columns;
                self.Data = data;
                self.Rows = [];
                self.GridColumnDefs = [];
                self.getGridWidth = function () {
                    return $('#userUploadFeedGrid').width();
                };

                self.calculateTotalColumnWidth = function (colList) {
                    var totalColWidth = 0;
                    var colListVM = { "totalColWidth": totalColWidth, "colWidthList": [] };
                    for (var colInd = 0; colInd < colList.length; colInd++) {
                        var colWidth = self.calculateColWidth(colList[colInd]);
                        colListVM.totalColWidth = colListVM.totalColWidth + colWidth;
                        colListVM.colWidthList.push(colWidth);
                    }
                    return colListVM;
                }

                self.isColumnWidthComputationNeeded = function (colList, gridWidth) {
                    var colListVM = self.calculateTotalColumnWidth(colList);
                    var isNeeded = false;
                    if (colListVM.totalColWidth > gridWidth) {
                        isNeeded = true;
                    }
                    $.extend(colListVM, { "isColWidthComputeNeeded": isNeeded });
                    return colListVM;
                }

                self.calculateColWidth = function (columnText) {
                    var coltextLength = columnText.length;
                    return (coltextLength * 15);
                }

                self.PivotData = function () {

                    //
                    var colListVM = self.isColumnWidthComputationNeeded(self.Columns, self.getGridWidth());

                    if (self.Columns && self.Data) {
                        for (var colIndex = 0; colIndex < self.Columns.length; colIndex++) {
                            var colDef = new GridColumnDefViewModel(self.Columns[colIndex], 'Data[' + colIndex + ']', self.Columns[colIndex] == "urowid" ? false : true, (colListVM.isColWidthComputeNeeded === true ? self.calculateColWidth(self.Columns[colIndex]) : ''));
                            self.GridColumnDefs.push(colDef);
                        }

                        for (var rowIndex = 0; rowIndex < self.Data[0].Values.length; rowIndex++) {
                            var trvm = new TableRowViewModel();

                            for (var colIndex = 0; colIndex < self.Data.length; colIndex++) {
                                trvm.Data.push(self.Data[colIndex].Values[rowIndex]);
                            }
                            self.Rows.push(trvm);

                        }
                    }
                };

                self.gridOptions = {
                    enableSelectAll: true,
                    enableRowSelection: true,
                    multiSelect: true,
                    enableFiltering: false,
                    enableSorting: true,
                    columnDefs: self.GridColumnDefs,
                    data: self.Rows,
                    showGridFooter: true,
                    exporterPdfDefaultStyle: { fontSize: 9 },
                    exporterPdfTableStyle: { margin: [30, 30, 30, 30] },
                    exporterPdfTableHeaderStyle: { fontSize: 10, bold: true, italics: true, color: 'red' },
                    exporterPdfHeader: { text: "My Header", style: 'headerStyle' },
                    exporterPdfFooter: function (currentPage, pageCount) {
                        return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
                    },
                    exporterPdfCustomFormatter: function (docDefinition) {
                        docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
                        docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
                        return docDefinition;
                    },
                    exporterPdfOrientation: 'portrait',
                    exporterPdfPageSize: 'LETTER',
                    exporterPdfMaxGridWidth: 500,
                    exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location"))
                };

                //$scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.OPTIONS);

                self.createGrid = function (columns, data) {
                    //self.clearGrid();
                    self.gridOptions = new GridOptionsViewModel(false, false, columns, data, 20);
                }

                self.clearGrid = function () {
                    self.gridOptions = null;
                    //raise event
                }

                self.gridOptions.onRegisterApi = function (gridApi) {
                    //set gridApi on scope
                    $scope.gridApi = gridApi;
                    //$scope.gridApi.selection.on.rowSelectionChanged(self, function (row) {
                    //    //if (row.isSelected === true) {
                    //    //    self.selectedUser = row.entity;
                    //    //}
                    //    //else {
                    //    //    self.selectedUser = null;
                    //    //}

                    //    var msg = 'row selected ' + row.isSelected;
                    //    $log.log(msg);
                    //});

                    //gridApi.selection.on.rowSelectionChangedBatch(self, function (rows) {
                    //    var msg = 'rows changed ' + rows.length;
                    //    $log.log(msg);
                    //});

                    $scope.gridApi.core.notifyDataChange(uiGridConstants.dataChange.OPTIONS);
                };


                if (self.Columns.length > 0) {
                    self.PivotData();
                }
            }

            function TableRowViewModel() {
                var self = this;
                self.Data = [];
                self.IsSelected = false;
            }

            function GridColumnDefViewModel(name, field, isVisible, width) {
                var self = this;
                self.name = name;
                self.field = field;
                self.enableCellEdit = false;
                self.visible = isVisible;

                if (width != null && width != '') {
                    self.width = width;
                }

                //self.cellClass = function (grid, row, col, rowRenderIndex, colRenderIndex) {
                //    if (row.entity.ValidationType == "1") {
                //        return "red";
                //    }
                //};
                self.filter = undefined;


            }

            function GridOptionsViewModel(enableFiltering, enableSorting, columns, data, minRowsToShow) {
                var self = this;

                self.columnDefs = [];

                for (var colInd = 0; colInd < columns.length; columns++) {
                    self.columnDefs.push({ name: columns[colInd], field: columns[colInd], enableCellEdit: false, width: 200 });
                }

                self.enableFiltering = enableFiltering;
                self.enableSorting = enableSorting;
                self.data = data;
                self.minRowsToShow = minRowsToShow;
            }

            function PagerViewModel() {
                var self = this;
                self.pageSizes = {
                    'items': [50, 100, 200, 300],
                    'selectedItem': 50
                };
                self.itemsPerPage = self.pageSizes.selectedItem;
                self.currentPage = 1;
                self.totalItems = 1;
                self.totalPages = 1;

                self.setPagingInfo = function (currentPageNumber, rowsPerPage, totalPages, totalRows) {
                    self.itemsPerPage = self.pageSizes.selectedItem;
                    self.currentPage = currentPageNumber;
                    self.totalItems = totalRows;
                    self.totalPages = totalPages;
                }

                self.onPageChange = function () {
                    $scope.onGetKeyCombinations(self.currentPage);
                }
            }

            function FactDownloadRequestViewModel(factTableId, fileTypeCodeId, startPeriod, endPeriod, signedUrl) {
                var self = this;
                self.FactTableId = factTableId;
                self.FileTypeCodeId = fileTypeCodeId;
                self.StartPeriod = startPeriod;
                self.EndPeriod = endPeriod;
                self.SignedUrl = signedUrl;
            }

            function errorCallback(data) {
                $scope.$parent.showAlert('danger', 'Error occured. Refresh the page and try again.');
                console.log(data);
            }
        }])




})(angular.module('vmApp'));

function fileUploadFactDataViewModel(args) {

    this.SignedUrl = args.SignedUrl,
    this.FactTableId = args.FactTableId,
    this.FileTypeCodeId = args.FileTypeCodeId,
    this.UploadProcessType = args.UploadProcessType,
    this.ReportingPeriod = args.ReportingPeriod
}