﻿
(function ($) {

    angular.module('vmApp')
        .controller('userProfileController', ['$scope', 'userProfileService', 'mappingTablesService', 'uiGridConstants', 'spinnerService', 'serverVariableService', '$state', '$stateParams', 'fileTransferService', 'onDemandJobsService', 'reportingService', userProfileController]);


    function userProfileController($scope, userProfileService, mappingTablesService, uiGridConstants, spinnerService, serverVariableService, $state, $stateParams, fileTransferService, onDemandJobsService, reportingService) {

        vzbsDropdown();

        var self = this;

        self.employeeId = $stateParams.employeeId;

        //view models
        self.user = null;
        self.mappingRolesVM = []; //view model instance to hold mapping table roles
        self.versionMgmtVM = null;  //view model instance to hold version management roles
        self.spinnerSemaphore = new spinnerSemaphoreViewModel(spinnerService); //view model instance to hold semaphore for spinner show/hide
        self.alertsVM = new alertsViewModel(); //view model instance to hold alerts
        self.allUsers = [];
        self.allPortalRoles = [{ id: 1, name: 'Read Only' }, { id: 3, name: 'User' }, { id: 9, name: 'Administrator' }];

        self.fileTypeVM = null;
        self.onDemandJobAccessVM = null;
        self.fileTransferAccessVM = null;

        self.datascoopTemplatesVM = [];
        self.datascoopApplicationsVM = [];
        self.reportAccessVM = null;

        //properties
        var dsEndpoint = serverVariableService.DATASCOOP_ENDPOINT();
        self.hasDatascoopModule = (dsEndpoint == null || dsEndpoint == undefined || dsEndpoint.trim() == '') ? false : true;

        self.totalSaveRequests = self.hasDatascoopModule ? 8 : 6; //if datascoop module is not present on this env, 2 save requests not needed
        self.loggedInUser = null;

        

        self.saveSemphore = self.totalSaveRequests;

        //Mapping Table Grid Options
        self.mtRoleGridOptions = {
            enableFiltering: false,
            enableSorting: false,
            enableColumnMenus: false,
            columnDefs: [
                          { name: 'mappingTableName', field: 'mappingTableName', enableCellEdit: false },
                          { name: 'read', field: 'accessTypes[0].hasAccess', type: 'boolean', enableFiltering: false, enableCellEdit: false, cellTemplate: '<input type="checkbox" ng-model="row.entity.accessTypes[0].hasAccess">' },
                          { name: 'edit', field: 'accessTypes[1].hasAccess', type: 'boolean', enableFiltering: false, cellTemplate: '<input type="checkbox" style="text-align: center" ng-model="row.entity.accessTypes[1].hasAccess">' },
                          { name: 'migrate', field: 'accessTypes[2].hasAccess', type: 'boolean', enableFiltering: false, cellTemplate: '<input type="checkbox" ng-model="row.entity.accessTypes[2].hasAccess">' }
            ],
            data: self.mappingRolesVM,
            minRowsToShow: 10
        };

        //DA Template Grid Options
        self.dsRoleGridOptions = {
            enableFiltering: false,
            enableSorting: false,
            enableColumnMenus: false,
            columnDefs: [
                          { name: 'applicationName', field: 'ApplicationName', enableCellEdit: false },
                          { name: 'templateName', field: 'TemplateName', enableCellEdit: false },
                          { name: 'edit', field: 'CanEdit', type: 'boolean', enableFiltering: false, cellTemplate: '<input type="checkbox" ng-model="row.entity.CanEdit">' }
            ],
            data: self.datascoopTemplatesVM,
            minRowsToShow: 10
        };

        //DA Application Grid Options
        self.dsaRoleGridOptions = {
            enableFiltering: false,
            enableSorting: false,
            enableColumnMenus: false,
            columnDefs: [
                          { name: 'applicationName', field: 'ApplicationName', enableCellEdit: false },
                          { name: 'edit', field: 'CanEdit', type: 'boolean', enableFiltering: false, cellTemplate: '<input type="checkbox" ng-model="row.entity.CanEdit">' }
            ],
            data: self.datascoopApplicationsVM,
            minRowsToShow: 10
        };

        //functions
        self.LoadPage = function () {
            userProfileService.getAllUsers({}, getAllUsersCallback, errorCallback);
        };

        self.LoadPage();

        //Call back methods
        function getVersionMgmtAccessRolesCallback(versionMgmtRoles) {
            var availableVersionMgmtRoles = [{ Id: 1, Name: "READ" }, { Id: 2, Name: "EDIT" }, { Id: 3, Name: "TRACKING" }];
            var availableAccessTypeVMList = [];
            var assignedAccessTypeVMList = [];

            for (var rIndex = 0; rIndex < availableVersionMgmtRoles.length; rIndex++) {
                if (versionMgmtRoles.length > 0 &&  $.inArray(availableVersionMgmtRoles[rIndex].Name, versionMgmtRoles[0].AccessType) >= 0) {
                    //if user has access set hasAccess property to true
                    assignedAccessTypeVMList.push(new accessTypeViewModel(availableVersionMgmtRoles[rIndex].Id, availableVersionMgmtRoles[rIndex].Name, true));
                }
                else {
                    //false otherwise
                    availableAccessTypeVMList.push(new accessTypeViewModel(availableVersionMgmtRoles[rIndex].Id, availableVersionMgmtRoles[rIndex].Name, false));
                }
            }
            self.versionMgmtVM = new versionMgmtViewModel(availableAccessTypeVMList, assignedAccessTypeVMList);
            self.spinnerSemaphore.reduceSemaphore();
        }

        function allMappingTablesCallback(response) {            
            var resp = response;            
            var availableMappingTables = mappingTablesService.getSelectableTables();

            self.mappingRolesVM.splice(0, self.mappingRolesVM.length);


            //get all available roles for mapping table
            var allMtRoles = mappingTablesService.getAllRoles();

            //iterate through all available mappingTable and create mappingTableViewModel with default accessType
            for (var mtIndex = 0; mtIndex < availableMappingTables.length; mtIndex++) {
                //TODO: check if this can be moved out of for loop
                //array to hold all access roles with hasAccess property false
                var accessTypeVMList = [];
                for (var rIndex = 0; rIndex < allMtRoles.length; rIndex++) {
                    accessTypeVMList.push(new accessTypeViewModel(allMtRoles[rIndex].Id, allMtRoles[rIndex].Name, false));
                }
                self.mappingRolesVM.push(new mappingTableViewModel(availableMappingTables[mtIndex].Id, availableMappingTables[mtIndex].Name, accessTypeVMList, false, false, false));
            }
            self.spinnerSemaphore.reduceSemaphore();

            //Get Mapping Table roles
            self.spinnerSemaphore.addSemaphore();
            //var upvm = new userProfileService.setUserProfileVM(self.user.EmployeeId, null, 'MT');
            var payload = new UserProfileViewModel(self.user.EmployeeId, null, 'MT');
            userProfileService.getUserAccessForAccessObjType(payload, getMappingAccessRolesCallback, errorCallback);
        }

        function getMappingAccessRolesCallback(mappingAccessRoles) {            
            //self.mappingRolesVM = []

            //get all available roles for mapping table
            var allMtRoles = mappingTablesService.getAllRoles();

            //iterate through all mapping table that user has access to
            for (var mtIndex = 0; mtIndex < mappingAccessRoles.length; mtIndex++) {
                //array to hold accessType for a mapping table
                var accessTypeVMList = [];
                //iterate all available roles and set hasAccess property based on user's access
                for (var roleIndex = 0; roleIndex < allMtRoles.length; roleIndex++) {
                    if ($.inArray(allMtRoles[roleIndex].Name, mappingAccessRoles[mtIndex].AccessType) >= 0) {
                        //if user has access set hasAccess property to true
                        accessTypeVMList.push(new accessTypeViewModel(allMtRoles[roleIndex].Id, allMtRoles[roleIndex].Name, true));
                    }
                    else {
                        //false otherwise
                        accessTypeVMList.push(new accessTypeViewModel(allMtRoles[roleIndex].Id, allMtRoles[roleIndex].Name, false));
                    }
                }

                //find the mappingTable item from mappingRolesVM
                var mtvm = $.grep(self.mappingRolesVM, function (m) { return m.mappingTableId == mappingAccessRoles[mtIndex].AccessObjectId; });

                if (mtvm.length > 0) {
                    //overwrite accessTypes
                    mtvm[0].accessTypes = accessTypeVMList;
                }
            }
            self.spinnerSemaphore.reduceSemaphore();
        }

        function saveVersionMgmtRolesCallback(response) {
            self.saveSemphore--;
            self.spinnerSemaphore.reduceSemaphore();

            //show success message after all save requests complete
            if (self.saveSemphore == 0) {
                self.alertsVM.addSuccessMessage('User Profile saved successfully.');
                self.saveSemphore = self.totalSaveRequests;
            }
        }

        function saveFileTransferRolesCallback(response) {
            self.saveSemphore--;
            self.spinnerSemaphore.reduceSemaphore();

            //show success message after all save requests complete
            if (self.saveSemphore == 0) {
                self.alertsVM.addSuccessMessage('User Profile saved successfully.');
                self.saveSemphore = self.totalSaveRequests;
            }
        }

        function getAllUsersCallback(response) {
            for (var userIndex = 0; userIndex < response.length; userIndex++) {
                var userVMItem = new userViewModel(response[userIndex]);
                userVMItem.UserRoleName = getUserRole(response[userIndex].UserRole);
                self.allUsers.push(userVMItem);
            }

            //self.user = self.allUsers[0];

            if (self.employeeId != undefined) {
                var findUser = $.grep(self.allUsers, function (u) {
                    return (u.EmployeeId === self.employeeId);
                });

                if (findUser.length > 0) {
                    self.selectUser(findUser[0]);
                }

            }

            var loggedInUserSearch = $.grep(self.allUsers, function (u) { return u.EmployeeId == serverVariableService.USER_EID() });            
            
            //Dont save mapping tables if the logged in user is not ADMIN. this is because non-admin themselves will not have access to mapping tables
            if (loggedInUserSearch != null && loggedInUserSearch.length > 0) {
                self.loggedInUser = loggedInUserSearch[0];
                if (loggedInUserSearch[0].UserRole != 9) {
                    //non admins cannot save mapping table so reduce
                    self.totalSaveRequests = 3;
                    self.saveSemphore = self.totalSaveRequests;
                }
            }
        }

        function getAllFactFilesCallback(response) {
            self.fileTypeVM = null;

            var availableFileTypes = [];

            for (var factFileCounter = 0; factFileCounter < response.length; factFileCounter++) {
                for (var fileTypeCounter = 0; fileTypeCounter < response[factFileCounter].FileTypes.length; fileTypeCounter++) {
                    availableFileTypes.push(new FileTypeViewModel(response[factFileCounter].FileTypes[fileTypeCounter], response[factFileCounter]));
                }
            }

            self.fileTypeVM = new FileTypeAccessViewModel(availableFileTypes, []);

            self.spinnerSemaphore.reduceSemaphore();

            //Get available fileTypes
            self.spinnerSemaphore.addSemaphore();
            userProfileService.getFactFileTypeAccess({ employeeId: self.user.EmployeeId }, getFactFileTypeAccessCallback, errorCallback);
        }

        function getFactFileTypeAccessCallback(response) {
            if (self.fileTypeVM != null) {
                //clear assignedList
                self.fileTypeVM.assignedFileTypes.splice(0, self.fileTypeVM.assignedFileTypes.length);

                for (var factFileCounter = 0; factFileCounter < response.length; factFileCounter++) {
                    var factFile = response[factFileCounter];
                    for (var fileTypeCounter = 0; fileTypeCounter < factFile.FileTypes.length; fileTypeCounter++) {
                        var fileType = factFile.FileTypes[fileTypeCounter];
                        var findFactFileFromAvailable = $.grep(self.fileTypeVM.availableFileTypes, function (f) {
                            return (f.FactTableType == 1 ? f.Code === fileType.Code : f.FileTypeCodeId === fileType.FileTypeCodeId);
                        });

                        if (findFactFileFromAvailable.length > 0) {
                            self.fileTypeVM.assignedFileTypes.push(findFactFileFromAvailable[0]);
                            self.fileTypeVM.availableFileTypes.splice($.inArray(findFactFileFromAvailable[0], self.fileTypeVM.availableFileTypes), 1);
                        }
                    }
                }
            }

            self.spinnerSemaphore.reduceSemaphore();
        }

        function getAllODJobsCallback(response) {
            self.onDemandJobAccessVM = null;

            var availableJobs = [];

            for (var groupCounter = 0; groupCounter < response.length; groupCounter++) {
                for (var jobCounter = 0; jobCounter < response[groupCounter].Jobs.length; jobCounter++) {
                    availableJobs.push(new OnDemandJobViewModel(response[groupCounter].Jobs[jobCounter], response[groupCounter]));
                }
            }

            self.onDemandJobAccessVM = new OnDemandJobAccessViewModel(availableJobs, []);

            self.spinnerSemaphore.reduceSemaphore();

            //Get available fileTypes
            self.spinnerSemaphore.addSemaphore();
            userProfileService.getODJobAccess({ employeeId: self.user.EmployeeId }, getODJobAccessCallback, errorCallback);
        }

        function getODJobAccessCallback(response) {
            if (self.onDemandJobAccessVM != null) {
                //clear assignedList
                self.onDemandJobAccessVM.assignedJobs.splice(0, self.onDemandJobAccessVM.assignedJobs.length);

                for (var groupCounter = 0; groupCounter < response.length; groupCounter++) {
                    var group = response[groupCounter];
                    for (var jobCounter = 0; jobCounter < group.Jobs.length; jobCounter++) {
                        var job = group.Jobs[jobCounter];
                        var findJobFromAvailable = $.grep(self.onDemandJobAccessVM.availableJobs, function (j) {
                            return (j.Id === job.Id && j.GroupName === group.Name);
                        });

                        if (findJobFromAvailable.length > 0) {
                            self.onDemandJobAccessVM.assignedJobs.push(findJobFromAvailable[0]);
                            self.onDemandJobAccessVM.availableJobs.splice($.inArray(findJobFromAvailable[0], self.onDemandJobAccessVM.availableJobs), 1);
                        }
                    }
                }
            }
            self.spinnerSemaphore.reduceSemaphore();

            //Get All Job Groups
            self.spinnerSemaphore.addSemaphore();
            onDemandJobsService.getAllODJobGroups({}, getODJobGroupsCallback, errorCallback);
        }

        function getFTAccessRolesCallback(response) {

            if (self.fileTransferAccessVM != null) {
                for (var idx = 0; idx < response.length; idx++) {
                    var ft = $.grep(self.fileTransferAccessVM.availableProfiles, function (p) { return p.ProfileId == response[idx].AccessObjectId });
                    if (ft.length > 0) {
                        self.fileTransferAccessVM.toggleItemSelection(ft[0]);
                    }
                }
                self.fileTransferAccessVM.assignSelected();
            }
            self.spinnerSemaphore.reduceSemaphore();
        }

        function getFileTransferProfilesCallback(response) {
            self.fileTransferAccessVM = null;

            var availableProfiles = [];
            
            for (var idx = 0; idx < response.length; idx++) {
                availableProfiles.push(new FileTransferViewModel(response[idx]));
            }

            self.fileTransferAccessVM = new FileTransferAccessViewModel(availableProfiles, []);
            self.spinnerSemaphore.reduceSemaphore();
            
            //Get assigned profiles
            self.spinnerSemaphore.addSemaphore();
            //var upvm = new userProfileService.setUserProfileVM(self.user.EmployeeId, null, 'FT');
            var payload = new UserProfileViewModel(self.user.EmployeeId, null, 'FT');
            userProfileService.getUserAccessForAccessObjType(payload, getFTAccessRolesCallback, errorCallback);
            
        }

        function getAllDSApplicationsCallback(response) {
            self.datascoopTemplatesVM.splice(0, self.datascoopTemplatesVM.length);
            self.datascoopApplicationsVM.splice(0, self.datascoopApplicationsVM.length);

            for (var appIndex = 0; appIndex < response.length; appIndex++) {
                var dsApp = response[appIndex];
                if (dsApp.CubeTemplates != null) {
                    for (var tIndex = 0; tIndex < dsApp.CubeTemplates.length; tIndex++) {
                        self.datascoopTemplatesVM.push(new DSTemplateViewModel(dsApp.CubeTemplates[tIndex], dsApp));
                    }
                }

                self.datascoopApplicationsVM.push(new DSApplicationViewModel(dsApp));
            }

            self.spinnerSemaphore.reduceSemaphore();

            //Get Datascoop Roles
            self.spinnerSemaphore.addSemaphore();
            //var upvm = new userProfileService.setUserProfileVM(self.user.EmployeeId, null, 'DST');
            var payloadDST = new UserProfileViewModel(self.user.EmployeeId, null, 'DST');
            userProfileService.getUserAccessForAccessObjType(payloadDST, getDatascoopRolesCallback, errorCallback);

            self.spinnerSemaphore.addSemaphore();
            //var upvmdsa = new userProfileService.setUserProfileVM(self.user.EmployeeId, null, 'DSA');
            var payloadDSA = new UserProfileViewModel(self.user.EmployeeId, null, 'DSA');
            userProfileService.getUserAccessForAccessObjType(payloadDSA, getDatascoopAppRolesCallback, errorCallback);
        }

        function getDatascoopRolesCallback(response) {
            if (response != null && response.length > 0) {
                for (var tIndex = 0; tIndex < response.length; tIndex++) {
                    //find the DS templat item from DSVM
                    var dsvm = $.grep(self.datascoopTemplatesVM, function (m) { return m.TemplateId == response[tIndex].AccessObjectId; });
                    if (dsvm.length > 0) {
                        //overwrite accessTypes
                        dsvm[0].CanEdit = true;
                    }
                }
            }
            self.spinnerSemaphore.reduceSemaphore();
        }

        function getDatascoopAppRolesCallback(response) {
            if (response != null && response.length > 0) {
                for (var tIndex = 0; tIndex < response.length; tIndex++) {
                    //find the DS templat item from DSVM
                    var dsvm = $.grep(self.datascoopApplicationsVM, function (m) { return m.ApplicationId == response[tIndex].AccessObjectId; });
                    if (dsvm.length > 0) {
                        //overwrite accessTypes
                        dsvm[0].CanEdit = true;
                    }
                }
            }
            self.spinnerSemaphore.reduceSemaphore();
        }

        function getODJobGroupsCallback(response) {
            if (self.onDemandJobAccessVM != null) {
                //clear groups
                self.onDemandJobAccessVM.jobGroups.splice(0, self.onDemandJobAccessVM.jobGroups.length);

                //add one virtual group "All"
                self.onDemandJobAccessVM.jobGroups.push(new OnDemandJobGroupViewModel({Id: '0', Name: 'All'}));

                for (var gInd = 0; gInd < response.length; gInd++) {
                    self.onDemandJobAccessVM.jobGroups.push(new OnDemandJobGroupViewModel(response[gInd]));
                }

                //select 'ALL' by default
                self.onDemandJobAccessVM.selectedJobGroup = self.onDemandJobAccessVM.jobGroups[0];
            }
            self.spinnerSemaphore.reduceSemaphore();
        }

        function getReportsCallback(response) {
            self.reportAccessVM = null;

            var availableReports = [];
            var availableReportGroup = [];

            for (var groupIdx = 0; groupIdx < response.length; groupIdx++) {
                availableReportGroup.push(response[groupIdx]);

                for (var reportIdx = 0; reportIdx < response[groupIdx].Reports.length; reportIdx++) {
                    availableReports.push(new ReportViewModel(response[groupIdx].Id, response[groupIdx].Name, response[groupIdx].Reports[reportIdx]));
                }
                
            }

            self.reportAccessVM = new ReportAccessViewModel(availableReportGroup, availableReports, []);
            self.spinnerSemaphore.reduceSemaphore();

            //Get assigned profiles
            self.spinnerSemaphore.addSemaphore();
            var payload = new UserProfileViewModel(self.user.EmployeeId, null, 'RPT');
            userProfileService.getUserAccessForAccessObjType(payload, getRPTAccessRolesCallback, errorCallback);

        }

        function getRPTAccessRolesCallback(response) {

            if (self.reportAccessVM != null) {
                for (var idx = 0; idx < response.length; idx++) {
                    var rpt = $.grep(self.reportAccessVM.availableReports, function (p) { return p.Id == response[idx].AccessObjectId });
                    if (rpt.length > 0) {
                        self.reportAccessVM.toggleItemSelection(rpt[0]);
                    }
                }
                self.reportAccessVM.assignSelected();
            }
            self.spinnerSemaphore.reduceSemaphore();
        }

        function saveReportRolesCallback(response) {
            self.saveSemphore--;
            self.spinnerSemaphore.reduceSemaphore();

            //show success message after all save requests complete
            if (self.saveSemphore == 0) {
                self.alertsVM.addSuccessMessage('User Profile saved successfully.');
                self.saveSemphore = self.totalSaveRequests;
            }
        }

        //event handlers
        self.selectUser = function (selectedUser) {
            self.user = selectedUser;
            self.user.SetFileProperties();
            //self.mappingRolesVM = [];

            //Get available fileTypes
            self.spinnerSemaphore.addSemaphore();
            userProfileService.getAllFactFiles({}, getAllFactFilesCallback, errorCallback);

            //Get avaiable od jobs
            self.spinnerSemaphore.addSemaphore();
            userProfileService.getAllODJobs({}, getAllODJobsCallback, errorCallback);

            //Get available file transfer profiles
            self.spinnerSemaphore.addSemaphore();
            fileTransferService.getFileTransferProfiles({}, getFileTransferProfilesCallback, errorCallback);

            //Get available mapping tables
            self.spinnerSemaphore.addSemaphore();
            mappingTablesService.getAllMappingTables({}, allMappingTablesCallback, errorCallback);

            //Get Version Management roles
            self.spinnerSemaphore.addSemaphore();
            //var upvm = new userProfileService.setUserProfileVM(self.user.EmployeeId, null, 'VM');
            var payload = new UserProfileViewModel(self.user.EmployeeId, null, 'VM');
            userProfileService.getUserAccessForAccessObjType(payload, getVersionMgmtAccessRolesCallback, errorCallback);

            //Get Datascoop roles
            if (self.hasDatascoopModule) {
                self.spinnerSemaphore.addSemaphore();
                userProfileService.getAllDSApplications({ employeeId: serverVariableService.USER_EID() }, getAllDSApplicationsCallback, errorCallback);
            }

            //Get available reports
            self.spinnerSemaphore.addSemaphore();
            userProfileService.getAllReports({}, getReportsCallback, errorCallback);
        }
        self.saveUserProfileHandler = function () {
            console.log('came to save');            
            //Sync data change
            self.versionMgmtVM.assignedRoles = self.getAssignedVMUserRoles();
            self.versionMgmtVM.availableRoles = self.getAvailableVMUserRoles();

            //var loggedInUser = $.grep(self.allUsers, function (u) { return u.EmployeeId == serverVariableService.USER_EID() });
            //Dont save mapping tables if the logged in user is not ADMIN. this is because non-admin themselves will not have access to mapping tables
            if (self.loggedInUser != null && self.loggedInUser.UserRole == 9)
            {
                saveMappingTableRoles();
                if (self.hasDatascoopModule) {
                    saveDatascoopRoles();
                }
            }

            //Save User Info
            userProfileService.saveUser({ "data": self.user }, saveVersionMgmtRolesCallback, errorCallback);

            //Save Version Management Roles            
            saveVersionMgmtRoles();
            saveFileTransferRoles();
            saveLegacyUserAccess();
            saveReportRoles();

        }

        self.toggleMapTblRoleFilterHandler = function () {
            self.mtRoleGridOptions.enableFiltering = !self.mtRoleGridOptions.enableFiltering;
            self.mtRoleGridOptions.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
        };
        self.selectRole = function (selectedRole) {
            self.user.UserRole = selectedRole.id;
            self.user.UserRoleName = selectedRole.name;
        }

        self.selectGroup = function (selectedGroup) {
            self.onDemandJobAccessVM.selectedJobGroup = selectedGroup;
            self.onDemandJobAccessVM.filterJobGroupId = selectedGroup.JobGroupId;
            console.log('group - ' + selectedGroup.GroupName + ' is selected.' );
        }

        self.selectReportGroup = function (selectedGroup) {
            self.reportAccessVM.selectedReportGroup = selectedGroup;
            self.reportAccessVM.filterReportGroupId = selectedGroup.Id;
            console.log('report group - ' + selectedGroup.Name + ' is selected.');
        }

        //private methods
        self.getAssignedVMUserRoles = function () {
            //this function is a hack for getting selectedExclusions - because there isn't a simple angular-way available to handle the drag-n-drop lists.
            var selectedRoles = [];
            jQuery("#exclusionRightList > li").each(function () {
                var r = JSON.parse(jQuery(this).attr('role'));
                r.hasAccess = true;
                selectedRoles.push(r);
            });
            return selectedRoles;
        }

        self.getAvailableVMUserRoles = function () {
            //this function is a hack for getting selectedExclusions - because there isn't a simple angular-way available to handle the drag-n-drop lists.
            var availableRoles = [];
            jQuery("#exclusionleftlist > li").each(function () {
                var r = JSON.parse(jQuery(this).attr('role'));
                r.hasAccess = false;
                availableRoles.push(r);
            });
            return availableRoles;
        }

        function saveMappingTableRoles() {
            self.spinnerSemaphore.addSemaphore();
            var userAccessList = [];
            for (var mInd = 0; mInd < self.mappingRolesVM.length; mInd++) {
                var ua = new UserAccess('MT', self.mappingRolesVM[mInd].mappingTableId, []);
                for (var rInd = 0; rInd < self.mappingRolesVM[0].accessTypes.length; rInd++) {
                    if (self.mappingRolesVM[mInd].accessTypes[rInd].hasAccess === true) {
                        ua.AccessType.push(self.mappingRolesVM[mInd].accessTypes[rInd].accessTypeName);
                    }
                }
                userAccessList.push(ua);
            }

            var payload = {
                employeeId: self.user.EmployeeId,
                accessObjectType: 'MT',
                data: userAccessList
            };

            userProfileService.SaveUserAccessByEmployeeId(payload, saveVersionMgmtRolesCallback, errorCallback);
        }

        function saveUserCallback(response) {
            self.saveSemphore--;
            self.spinnerSemaphore.reduceSemaphore();
        }

        function saveVersionMgmtRoles() {
            self.spinnerSemaphore.addSemaphore();

            var roleData = [];
            roleData.push(new UserAccess('VM', 0, []));
            for (var rInd = 0; rInd < self.versionMgmtVM.assignedRoles.length; rInd++) {
                roleData[0].AccessType.push(self.versionMgmtVM.assignedRoles[rInd].accessTypeName);
            }

            var payload = {
                employeeId: self.user.EmployeeId,
                accessObjectType: 'VM',
                data: roleData
            };

            userProfileService.SaveUserAccessByEmployeeId(payload, saveVersionMgmtRolesCallback, errorCallback);
        }

        function saveFileTransferRoles() {
            self.spinnerSemaphore.addSemaphore();

            var userAccessList = [];
            
            for (var rInd = 0; rInd < self.fileTransferAccessVM.assignedProfiles.length; rInd++) {
                var ua = new UserAccess('FT', self.fileTransferAccessVM.assignedProfiles[rInd].ProfileId, ['EDIT']);
                userAccessList.push(ua);
            }

            var payload = {
                employeeId: self.user.EmployeeId,
                accessObjectType: 'FT',
                data: userAccessList
            };

            userProfileService.SaveUserAccessByEmployeeId(payload, saveFileTransferRolesCallback, errorCallback);
        }

        function saveLegacyUserAccess() {
            var legacyUserAccess = { EmployeeId: self.user.EmployeeId, FactFileTypes: [], ODJobs: [], UserInformation: null }

            for (var ftInd = 0; ftInd < self.fileTypeVM.assignedFileTypes.length; ftInd++) {
                legacyUserAccess.FactFileTypes.push(self.fileTypeVM.assignedFileTypes[ftInd]);
            }

            for (var ftInd = 0; ftInd < self.onDemandJobAccessVM.assignedJobs.length; ftInd++) {
                legacyUserAccess.ODJobs.push(self.onDemandJobAccessVM.assignedJobs[ftInd]);
            }

            legacyUserAccess.UserInformation = self.user;

            userProfileService.saveLegacyUserAccess({ data: legacyUserAccess }, saveVersionMgmtRolesCallback, errorCallback);

        }

        function saveDatascoopRoles() {
            //Prepare payload for template save
            self.spinnerSemaphore.addSemaphore();
            var userAccessList = [];
            for (var tInd = 0; tInd < self.datascoopTemplatesVM.length; tInd++) {
                if (self.datascoopTemplatesVM[tInd].CanEdit == true) {
                    var ua = new UserAccess('DST', self.datascoopTemplatesVM[tInd].TemplateId, ['EDIT']);
                    userAccessList.push(ua);
                }
            }

            var payload = {
                employeeId: self.user.EmployeeId,
                accessObjectType: 'DST',
                data: userAccessList
            };

            //Prepare payload for application save
            self.spinnerSemaphore.addSemaphore();
            var userAccessDSAList = [];
            for (var tInd = 0; tInd < self.datascoopApplicationsVM.length; tInd++) {
                if (self.datascoopApplicationsVM[tInd].CanEdit == true) {
                    var ua = new UserAccess('DSA', self.datascoopApplicationsVM[tInd].ApplicationId, ['EDIT']);
                    userAccessDSAList.push(ua);
                }
            }

            var payloadDSA = {
                employeeId: self.user.EmployeeId,
                accessObjectType: 'DSA',
                data: userAccessDSAList
            };

            userProfileService.SaveUserAccessByEmployeeId(payload, saveVersionMgmtRolesCallback, errorCallback);
            userProfileService.SaveUserAccessByEmployeeId(payloadDSA, saveVersionMgmtRolesCallback, errorCallback);
        }

        function saveReportRoles() {
            self.spinnerSemaphore.addSemaphore();

            var userAccessList = [];

            for (var rInd = 0; rInd < self.reportAccessVM.assignedReports.length; rInd++) {
                var ua = new UserAccess('RPT', self.reportAccessVM.assignedReports[rInd].Id, ['READ']);
                userAccessList.push(ua);
            }

            var payload = {
                employeeId: self.user.EmployeeId,
                accessObjectType: 'RPT',
                data: userAccessList
            };

            userProfileService.SaveUserAccessByEmployeeId(payload, saveReportRolesCallback, errorCallback);
        }

        function errorCallback(data) {
            self.alertsVM.addErrorMessage('Error occured. Try again or contact system administrator');
            console.log(data);
            self.spinnerSemaphore.reduceSemaphore();
            spinnerService.hide("overlaySpinner");
            self.saveSemphore = self.totalSaveRequests;
        }

        function getUserRole(roleid) {
            var role = $.grep(self.allPortalRoles, function (r) { return r.id == roleid });
            if (role.length > 0) {
                return role[0].name;
            }
            else {
                return null;
            }
            
        }
    }

    //view models
    function userViewModel(userData) {
        var self = this;
        self.EmployeeId = userData.EmployeeId;
        self.UserId = userData.UserId;
        self.FirstName = userData.FirstName;
        self.LastName = userData.LastName;
        self.Email = userData.Email;
        self.Active = userData.Active;
        self.UserRole = userData.UserRole;
        self.UserRoleName = null;
        self.UserAccess = userData.UserAccess;
        self.FullName = userData.LastName + ", " + userData.FirstName;
        self.CanPostAdjImm = false;
        self.CanPostAdjAnyPeriod = false;
        self.CanAddNewFileTypes = false;
        self.CanAddNewFileKeys = false;
        self.CanAssignFileTypesForUser = false;
        self.CanAssignODJ = false;
        self.CanModifyOutline = false;
        self.CanProcessCPGA = false;
        self.CanPostUserFeedsForPrevPer = false;

        self.SetFileProperties = function () {
            if (self.UserAccess.length > 0) {
                if (self.UserAccess.indexOf("ADFK") >= 0) {
                    self.CanAddNewFileKeys = true;
                }

                if (self.UserAccess.indexOf("ADJN") >= 0) {
                    self.CanPostAdjImm = true;
                }

                if (self.UserAccess.indexOf("POAP") >= 0) {
                    self.CanPostAdjAnyPeriod = true;
                }

                if (self.UserAccess.indexOf("ASFT") >= 0) {
                    self.CanAssignFileTypesForUser = true;
                }
                if (self.UserAccess.indexOf("ASAO") >= 0) {
                    self.CanAssignODJ = true;
                }
                if (self.UserAccess.indexOf("ADFT") >= 0) {
                    self.CanAddNewFileTypes = true;
                }
                if (self.UserAccess.indexOf("MDOL") >= 0) {
                    self.CanModifyOutline = true;
                }
                if (self.UserAccess.indexOf("CPGA") >= 0) {
                    self.CanProcessCPGA = true;
                }
                if (self.UserAccess.indexOf("PFAP") >= 0) {
                    self.CanPostUserFeedsForPrevPer = true;
                }
            }
        }
    }

    function mappingTableViewModel(id, name, accessTypes, hasReadAccess, hasEditAccess, hasMigrateAccess) {
        var self = this;
        self.mappingTableId = id;
        self.mappingTableName = name;
        self.accessTypes = accessTypes;
        self.canRead = hasReadAccess;
        self.canEdit = hasEditAccess;
        self.canMigrate = hasMigrateAccess;
    }

    function accessTypeViewModel(id, name, hasAccess) {
        var self = this;
        self.accessTypeId = id;
        self.accessTypeName = name;
        self.hasAccess = hasAccess;
    }

    function versionMgmtViewModel(availableRoles, assignedRoles) {
        var self = this;
        self.availableRoles = availableRoles;
        self.assignedRoles = assignedRoles;
    }

    function FileTypeAccessViewModel(availableFileTypes, assignedFileTypes) {
        var self = this;
        self.availableFileTypes = availableFileTypes;
        self.assignedFileTypes = assignedFileTypes;
        self.assignAll = function () {
            for (var availableIndex = 0; availableIndex < self.availableFileTypes.length; availableIndex++) {
                var movableFileType = self.availableFileTypes[availableIndex];
                //add it to assignedList
                self.assignedFileTypes.push(movableFileType);
            }

            //clear availableFileTypes
            self.availableFileTypes.splice(0, self.availableFileTypes.length);
        };
        self.unAssignAll = function () {
            for (var assignedIndex = 0; assignedIndex < self.assignedFileTypes.length; assignedIndex++) {
                var movableFileType = self.assignedFileTypes[assignedIndex];                
                //add it to availableFileTypes
                self.availableFileTypes.push(movableFileType);
            }
            //clear assignedList
            self.assignedFileTypes.splice(0, self.assignedFileTypes.length);

        };
        self.assignSelected = function () {
            var movedItem = [];

            for (var availableIndex = 0; availableIndex < self.availableFileTypes.length; availableIndex++) {
                var movableFileType = self.availableFileTypes[availableIndex];
                if (movableFileType.isSelected === true) {
                    movableFileType.isSelected = false;
                    movedItem.push(movableFileType);
                    //add it to assignedList
                    self.assignedFileTypes.push(movableFileType);
                }
            }

            for (var removeIndex = 0; removeIndex < movedItem.length; removeIndex++) {
                //clear availableFileTypes that were moved
                self.availableFileTypes.splice($.inArray(movedItem[removeIndex], self.availableFileTypes), 1);
            }
            
        };
        self.unAssignSelected = function () {
            var movedItem = [];

            for (var assignedIndex = 0; assignedIndex < self.assignedFileTypes.length; assignedIndex++) {
                var movableFileType = self.assignedFileTypes[assignedIndex];
                if (movableFileType.isSelected === true) {
                    movableFileType.isSelected = false;
                    movedItem.push(movableFileType);
                    //add it to availableFileTypes
                    self.availableFileTypes.push(movableFileType);
                }
            }

            for (var removeIndex = 0; removeIndex < movedItem.length; removeIndex++) {
                //clear availableFileTypes that were moved
                self.assignedFileTypes.splice($.inArray(movedItem[removeIndex], self.assignedFileTypes), 1);
            }
        };
        self.toggleItemSelection = function (item) {
            item.isSelected = !item.isSelected;
        };
    }

    function FileTypeViewModel(fileType, factTable) {
        var self = this;
        self.FileTypeCodeId = fileType.FileTypeCodeId;
        self.Code = fileType.Code;
        self.Description = fileType.Description;

        self.FactTableId = factTable.Id;
        self.FactTableName = factTable.Name;
        self.FactTableDesc = factTable.Description;
        self.FactTableType = factTable.FactTableType;

        self.isSelected = false;
    }

    function OnDemandJobAccessViewModel(availableJobs, assignedJobs) {
        var self = this;
        self.availableJobs = availableJobs;
        self.assignedJobs = assignedJobs;
        self.jobGroups = [];
        self.selectedJobGroup = null;
        self.filterJobGroupId = 0;
        self.assignAll = function () {
            for (var availableIndex = 0; availableIndex < self.availableJobs.length; availableIndex++) {
                var movableItem = self.availableJobs[availableIndex];
                //add it to assignedList
                self.assignedJobs.push(movableItem);
            }

            //clear availableJobs
            self.availableJobs.splice(0, self.availableJobs.length);
        };
        self.unAssignAll = function () {
            for (var assignedIndex = 0; assignedIndex < self.assignedJobs.length; assignedIndex++) {
                var movableItem = self.assignedJobs[assignedIndex];
                //add it to availableFileTypes
                self.availableJobs.push(movableItem);
            }
            //clear assignedList
            self.assignedJobs.splice(0, self.assignedJobs.length);

        };
        self.assignSelected = function () {
            var movedItem = [];

            for (var availableIndex = 0; availableIndex < self.availableJobs.length; availableIndex++) {
                var movableFileType = self.availableJobs[availableIndex];
                if (movableFileType.isSelected === true) {
                    movableFileType.isSelected = false;
                    movedItem.push(movableFileType);
                    //add it to assignedList
                    self.assignedJobs.push(movableFileType);
                }
            }

            for (var removeIndex = 0; removeIndex < movedItem.length; removeIndex++) {
                //clear availableFileTypes that were moved
                self.availableJobs.splice($.inArray(movedItem[removeIndex], self.availableJobs), 1);
            }

        };
        self.unAssignSelected = function () {
            var movedItem = [];

            for (var assignedIndex = 0; assignedIndex < self.assignedJobs.length; assignedIndex++) {
                var movableItem = self.assignedJobs[assignedIndex];
                if (movableItem.isSelected === true) {
                    movableItem.isSelected = false;
                    movedItem.push(movableItem);
                    //add it to availableFileTypes
                    self.availableJobs.push(movableItem);
                }
            }

            for (var removeIndex = 0; removeIndex < movedItem.length; removeIndex++) {
                //clear availableFileTypes that were moved
                self.assignedJobs.splice($.inArray(movedItem[removeIndex], self.assignedJobs), 1);
            }
        };
        self.toggleItemSelection = function (item) {
            item.isSelected = !item.isSelected;
        };
    }

    function OnDemandJobGroupViewModel(jobGroup) {
        var self = this;
        self.JobGroupId = jobGroup.Id;
        self.GroupName = jobGroup.Name;
    }

    function OnDemandJobViewModel(job, group) {
        var self = this;
        self.JobGroupId = group.Id;
        self.GroupName = group.Name;
        self.Id = job.Id;
        self.UserFriendlyName = job.UserFriendlyName;
        self.Name = job.Name;
        self.Description = job.Description
    }

    function FileTransferAccessViewModel(availableProfiles, assignedProfiles) {
        var self = this;
        self.availableProfiles = availableProfiles;
        self.assignedProfiles = assignedProfiles;
        self.assignAll = function () {
            for (var availableIndex = 0; availableIndex < self.availableProfiles.length; availableIndex++) {
                var movableItem = self.availableProfiles[availableIndex];
                //add it to assignedList
                self.assignedProfiles.push(movableItem);
            }

            //clear availableJobs
            self.availableProfiles.splice(0, self.availableProfiles.length);
        };
        self.unAssignAll = function () {
            for (var assignedIndex = 0; assignedIndex < self.assignedProfiles.length; assignedIndex++) {
                var movableItem = self.assignedProfiles[assignedIndex];
                //add it to availableFileTypes
                self.availableProfiles.push(movableItem);
            }
            //clear assignedList
            self.assignedProfiles.splice(0, self.assignedProfiles.length);

        };
        self.assignSelected = function () {
            var movedItem = [];

            for (var availableIndex = 0; availableIndex < self.availableProfiles.length; availableIndex++) {
                var movableFileType = self.availableProfiles[availableIndex];
                if (movableFileType.isSelected === true) {
                    movableFileType.isSelected = false;
                    movedItem.push(movableFileType);
                    //add it to assignedList
                    self.assignedProfiles.push(movableFileType);
                }
            }

            for (var removeIndex = 0; removeIndex < movedItem.length; removeIndex++) {
                //clear availableFileTypes that were moved
                self.availableProfiles.splice($.inArray(movedItem[removeIndex], self.availableProfiles), 1);
            }

        };
        self.unAssignSelected = function () {
            var movedItem = [];

            for (var assignedIndex = 0; assignedIndex < self.assignedProfiles.length; assignedIndex++) {
                var movableItem = self.assignedProfiles[assignedIndex];
                if (movableItem.isSelected === true) {
                    movableItem.isSelected = false;
                    movedItem.push(movableItem);
                    //add it to availableFileTypes
                    self.availableProfiles.push(movableItem);
                }
            }

            for (var removeIndex = 0; removeIndex < movedItem.length; removeIndex++) {
                //clear availableFileTypes that were moved
                self.assignedProfiles.splice($.inArray(movedItem[removeIndex], self.assignedProfiles), 1);
            }
        };
        self.toggleItemSelection = function (item) {
            item.isSelected = !item.isSelected;
        };
    }

    function FileTransferViewModel(fileTransferProfile) {
        var self = this;
        self.ProfileId = fileTransferProfile.ProfileId;
        self.ProfileName = fileTransferProfile.ProfileName;
        self.DefaultFileName = fileTransferProfile.DefaultFileName;
        self.TransferType = fileTransferProfile.TransferType;
        self.TargetDirectory = fileTransferProfile.TargetDirectory;

        self.isSelected = false;
    }

    function UserAccess(accessObjectType, accessObjectId, accessType) {
        var self = this;
        self.AccessObjectType = accessObjectType;
        self.AccessObjectId = accessObjectId;
        self.AccessType = accessType;
    }

    function spinnerSemaphoreViewModel(spinnerService) {
        var self = this;
        self.semaphore = 0;
        self.addSemaphore = function () {
            self.semaphore++;
            if (self.semaphore == 1) {
                spinnerService.show("overlaySpinner");
            }
        };
        self.reduceSemaphore = function () {
            self.semaphore--;
            if (self.semaphore == 0) {
                spinnerService.hide("overlaySpinner");
            }
        };
    }

    function alertsViewModel() {
        var self = this;
        self.successMessages = [];
        self.errorMessages = [];
        self.addSuccessMessage = function (message) {
            self.clearSuccessMessage();
            self.successMessages.push(message);
        };
        self.addErrorMessage = function (message) {
            self.clearErrorMessage();
            self.errorMessages.push(message);
        };
        self.clearSuccessMessage = function () {
            self.successMessages = [];
        }
        self.clearErrorMessage = function () {
            self.errorMessages = [];
        }
    }

    function DSTemplateViewModel(templateData, applicationData)
    {
        var self = this;
        self.TemplateId = templateData.Id;
        self.TemplateName = templateData.Name;
        self.ApplicationId = applicationData.Id;
        self.ApplicationName = applicationData.Name;
        self.CanEdit = false;
    }

    function DSApplicationViewModel(applicationData) {
        var self = this;
        self.ApplicationId = applicationData.Id;
        self.ApplicationName = applicationData.Name;
        self.CanEdit = false;
    }

    function UserProfileViewModel(employeeId, userId, accessObjectType) {
        var self = this;
        self.employeeId = employeeId,
        self.userId = userId,
        self.accessObjectType = accessObjectType
    }

    function ReportGroupViewModel(reportGroup) {
        var self = this;
        self.Id = reportGroup.Id;
        self.Name = reportGroup.Name;
        self.Reports = [];        
    }

    function ReportViewModel(groupId, groupName, report) {
        var self = this;
        self.GroupId = groupId;
        self.GroupName = groupName;
        self.Id = report.Id;
        self.DisplayName = report.DisplayName;
        self.Description = report.Description;
        self.ObjectName = report.ObjectName;
        self.IsSelected = false;
    }

    function ReportAccessViewModel(availableReportGroups, availableReports, assignedReports) {
        var self = this;

        self.selectedReportGroup = null;
        self.filterReportGroupId = 0;

        self.availableReportGroups = availableReportGroups;
        self.availableReports = availableReports;
        self.assignedReports = assignedReports;
        self.assignAll = function () {
            for (var availableIndex = 0; availableIndex < self.availableReports.length; availableIndex++) {
                var movableItem = self.availableReports[availableIndex];
                //add it to assignedList
                self.assignedReports.push(movableItem);
            }

            //clear availableJobs
            self.availableReports.splice(0, self.availableReports.length);
        };
        self.unAssignAll = function () {
            for (var assignedIndex = 0; assignedIndex < self.assignedReports.length; assignedIndex++) {
                var movableItem = self.assignedReports[assignedIndex];
                //add it to availableFileTypes
                self.availableReports.push(movableItem);
            }
            //clear assignedList
            self.assignedReports.splice(0, self.assignedReports.length);

        };
        self.assignSelected = function () {
            var movedItem = [];

            for (var availableIndex = 0; availableIndex < self.availableReports.length; availableIndex++) {
                var movableReport = self.availableReports[availableIndex];
                if (movableReport.isSelected === true) {
                    movableReport.isSelected = false;
                    movedItem.push(movableReport);
                    //add it to assignedList
                    self.assignedReports.push(movableReport);
                }
            }

            for (var removeIndex = 0; removeIndex < movedItem.length; removeIndex++) {
                //clear availableFileTypes that were moved
                self.availableReports.splice($.inArray(movedItem[removeIndex], self.availableReports), 1);
            }

        };
        self.unAssignSelected = function () {
            var movedItem = [];

            for (var assignedIndex = 0; assignedIndex < self.assignedReports.length; assignedIndex++) {
                var movableItem = self.assignedReports[assignedIndex];
                if (movableItem.isSelected === true) {
                    movableItem.isSelected = false;
                    movedItem.push(movableItem);
                    //add it to availableFileTypes
                    self.availableReports.push(movableItem);
                }
            }

            for (var removeIndex = 0; removeIndex < movedItem.length; removeIndex++) {
                //clear availableFileTypes that were moved
                self.assignedReports.splice($.inArray(movedItem[removeIndex], self.assignedReports), 1);
            }
        };
        self.toggleItemSelection = function (item) {
            item.isSelected = !item.isSelected;
        };
    }

})(window.jQuery);