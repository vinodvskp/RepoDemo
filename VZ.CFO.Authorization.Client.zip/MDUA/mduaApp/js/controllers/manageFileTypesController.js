﻿
(function ($) {

    angular.module('vmApp')
        .controller('manageFileTypesController', ['$scope', 'manageFileTypesService', '$uibModal', 'spinnerService', manageFileTypesController])
        .controller('manageFileTypesModalInstanceController', ['$uibModalInstance', function ($uibModalInstance) {
            var self = this;
            self.ok = function ($event) {
                $uibModalInstance.close("OK");
            }
            self.cancel = function () {
                $uibModalInstance.dismiss('cancel');
            };

        }]);

    function manageFileTypesController($scope, manageFileTypesService, $uibModal, spinnerService) {

        var self = $scope;

        $('.nav-tabs > li a[title]').tooltip();

        //Wizard
        $('a[data-toggle="tab"]').on('show.bs.tab', function (e) {

            var $target = $(e.target);

            if ($target.parent().hasClass('disabled')) {
                return false;
            }
        });

        $(".next-step").click(function (e) {

            var $active = $('.wizard .nav-tabs li.active');
            $active.next().removeClass('disabled');
            nextTab($active);

        });
        $(".prev-step").click(function (e) {

            var $active = $('.wizard .nav-tabs li.active');
            prevTab($active);

        });

        self.factTableList = [];
        self.selectedFactTable = null;
        self.fileTypesList = [];
        self.selectedFileType = null;

        self.onLoad = function () {
            //Mock Data
            self.getFactTables();
        }

        self.getFactTables = function () {
            self.factTableList.splice(0, self.factTableList.length);
            self.factTableList.push(new factTableViewModel(1, 'Fact GL'));
            self.factTableList.push(new factTableViewModel(2, 'Fact Headcount'));
        }

        self.onFactTableSelect = function (item) {
            self.selectedFactTable = item;
            //clear fact type list
            self.fileTypesList.splice(0, self.fileTypesList.length);

            if (item.Id === 1) {
                self.fileTypesList.push(new fileTypeViewModel(1, 'Fact GL user upload', 'user upload for fact gl', [1, 2], []));
                self.fileTypesList.push(new fileTypeViewModel(1, 'Fact GL adj', 'adj for fact gl', [1, 2], []));
            }
            else {
                self.fileTypesList.push(new fileTypeViewModel(1, 'Fact HC user upload', 'user upload for fact hc', [1, 2], [{ name: dim1, value: dim1Value }, { name: dim2, value: dim2Value }]));
                self.fileTypesList.push(new fileTypeViewModel(1, 'Fact HC adj', 'adj for fact hc', [1, 2], [{ name: dim1, value: dim1Value }, { name: dim2, value: dim2Value }]));
            }
        }

        self.onLoad();
        
    }

    //view models
    function factTableViewModel(id, name) {
        var self = this;
        self.Id = id;
        self.Name = name;
    }

    function fileTypeViewModel(id, name, description, settings, defaultValues) {
        var self = this;
        self.Id = id;
        self.Name = name;
        self.Description = description;
        self.Settings = settings;
        self.DefaultValues = defaultValues;
    }

})(window.jQuery);