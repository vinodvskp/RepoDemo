﻿
(function ($) {

    angular.module('vmApp')
        .controller('manageUsersController', ['$scope', '$sce', 'manageUsersService', '$uibModal', 'spinnerService', 'serverVariableService', 'uiGridConstants', 'userProfileService', '$state', manageUsersController]);

    function manageUsersController($scope, $sce, manageUsersService, $uibModal, spinnerService, serverVariableService, uiGridConstants, userProfileService, $state) {
        var self = this;

        self.viewModel = new ManageUsersViewModel();

        self.validationSummary = [];
        self.closeValidationSummary = function (index) {
            self.validationSummary.splice(index, 1);
        };
        self.showAlert = function (alertType, message) {
            self.validationSummary.push({ type: alertType, msg: message });
        }

        //muGridOptions
        self.muGridOptions = {            
            rowTemplate: '<div ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.colDef.name" class="ui-grid-cell" ng-class="{ \'ui-grid-row-header-cell\': col.isRowHeader, \'red-text\': grid.appScope.rowFormatter( row ) }" ui-grid-cell></div>',
            enableRowSelection: true,
            enableRowHeaderSelection: false,
            multiSelect: false,
            modifierKeysToMultiSelect : false,
            noUnselect : true,
            enableFiltering: false,
            enableSorting: true,
            enableColumnMenus: false,
            columnDefs: self.viewModel.UserViewColDefs,
            data: self.viewModel.UserList,
            minRowsToShow: 14
        };

        self.muGridOptions.onRegisterApi = function (gridApi) {
            self.gridApi = gridApi;
            self.gridApi.selection.on.rowSelectionChanged($scope, function (row) {
                if (self.viewModel.SelectedView == self.viewModel.AvailableViews[0]) {
                    if (row.isSelected === true) {
                        self.viewModel.SelectedUser = row.entity;
                    }
                    else {
                        self.viewModel.SelectedUser = null;
                    }
                }
            });

            self.gridApi.grid.appScope.rowFormatter = function (row) {                
                return self.gridApi.grid.appScope.muc.viewModel.SelectedView === self.gridApi.grid.appScope.muc.viewModel.AvailableViews[0] && row.entity.Active === 'No';
            };
        };

        

        //Handlers
        self.onLoad = function () {
            if (self.viewModel.SelectedView == self.viewModel.AvailableViews[0]) {
                //Get all users
                self.loadUsersViewData();
            }
            else {
                //user access view
                self.loadUserAccessViewData();
            }
        }

        self.onViewChange = function () {
            //clear selected user
            self.viewModel.SelectedUser = null;

            if (self.viewModel.SelectedView == self.viewModel.AvailableViews[0]) {
                self.setUsersView(false);
            }
            else {
                self.setUserAccessView();
            }
        }

        self.loadUsersViewData = function () {
            userProfileService.getAllUsers({}, getAllUsersCallback, errorCallback);
            spinnerService.show("overlaySpinner");
        }

        self.loadUserAccessViewData = function () {
            manageUsersService.getUserAccessFlat({ data: new PageViewModel(1, self.viewModel.RowsPerPage, 0, 0) }, getUserAccessFirstPageFlatCallback, errorCallback);
            spinnerService.show("overlaySpinner");
        }

        self.setUsersView = function (IsforcedRefresh) {
            self.muGridOptions.columnDefs = self.viewModel.UserViewColDefs;
            self.muGridOptions.data = self.viewModel.UserList;
            self.muGridOptions.enableRowSelection = true;
            self.gridApi.core.notifyDataChange(uiGridConstants.dataChange.OPTIONS);

            if (IsforcedRefresh === true || self.viewModel.IsUsersViewDataLoaded == false) {
                self.loadUsersViewData();
            }
            self.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
        }

        self.setUserAccessView = function () {
            self.muGridOptions.columnDefs = self.viewModel.UserAccessViewColDefs;
            self.muGridOptions.data = self.viewModel.UserAccessList;
            self.muGridOptions.enableRowSelection = false;
            self.gridApi.core.notifyDataChange(uiGridConstants.dataChange.OPTIONS);

            if (self.viewModel.IsUserAccessViewDataLoaded == false) {
                self.loadUserAccessViewData();
            }
            self.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
        }

        self.onFilterToggle = function () {
            self.muGridOptions.enableFiltering = !self.muGridOptions.enableFiltering;
            self.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
        }

        self.onEditUser = function () {
            if (self.viewModel.SelectedUser != null) {
                $state.go("userProfileQS", {
                    employeeId: self.viewModel.SelectedUser.EmployeeId
                });
            }
        }

        self.onExport = function () {
            var exportType = self.viewModel.SelectedView == self.viewModel.AvailableViews[0] ? 1 : 2;
            if (self.viewModel.SelectedView == self.viewModel.AvailableViews[0]) {
                manageUsersService.getSignedKeyForExport({ "exportType": 1 }, getSignedKeyForUsersViewExportCallback, errorCallback);
            }
            else {
                manageUsersService.getSignedKeyForExport({ "exportType": 2 }, getSignedKeyForUserAccessViewExportCallback, errorCallback);
            }
            
        }

        self.onRefreshUserFromAD = function () {
            spinnerService.show("overlaySpinner");
            manageUsersService.refreshUsersFromAD({}, refreshUsersFromADCallback, errorCallback);
        }

        //call backs
        function getAllUsersCallback(response) {
            //clear all users
            self.viewModel.UserList.splice(0, self.viewModel.UserList.length);
            self.viewModel.IsUsersViewDataLoaded = false;
            for (var uInd = 0; uInd < response.length; uInd++) {
                self.viewModel.UserList.push(new userViewModel(response[uInd]));
            }
            self.viewModel.IsUsersViewDataLoaded = true;
            spinnerService.hide("overlaySpinner");
        }

        function getUserAccessFirstPageFlatCallback(response) {
            //clear all pages
            self.viewModel.UserAccessPages.splice(0, self.viewModel.UserAccessPages.length);
            self.viewModel.IsUserAccessViewDataLoaded = false;

            //Set Total Number of pages and rows
            self.viewModel.TotalUserAccessPages = response.TotalPages;
            self.viewModel.TotalUserAccessRows = response.TotalResults;
            self.viewModel.UserAccessPages.push(new UserAccessPageViewModel(response));

            //get other pages
            for (pCount = 2; pCount <= self.viewModel.TotalUserAccessPages; pCount++) {
                manageUsersService.getUserAccessFlat({ data: new PageViewModel(pCount, self.viewModel.RowsPerPage, self.viewModel.TotalUserAccessPages, self.viewModel.TotalUserAccessRows) }, getUserAccessMorePageFlatCallback, errorCallback);
            }

        }

        function getUserAccessMorePageFlatCallback(response) {
            //Set Total Number of pages and rows
            self.viewModel.UserAccessPages.push(new UserAccessPageViewModel(response));

            //check if all pages loaded
            if (self.viewModel.UserAccessPages.length == self.viewModel.TotalUserAccessPages) {

                for (var pNumber = 1; pNumber <= self.viewModel.UserAccessPages.length; pNumber++) {
                    var findPage = $.grep(self.viewModel.UserAccessPages, function (p) { return p.PageInfo.PageNumber == pNumber; });
                    if (findPage.length > 0) {
                        self.viewModel.appendUserAccessList(findPage[0].UserAccessList);
                        console.log('page - ' + pNumber + ' of ' + self.viewModel.UserAccessPages.length + 'loaded');
                    }
                }
                spinnerService.hide("overlaySpinner");
                self.viewModel.IsUserAccessViewDataLoaded = true;
                console.log("All pages loaded");
            }
        }

        function getSignedKeyForUsersViewExportCallback(response) {            
            var exportURL = serverVariableService.MDUA_USERS_ENDPOINT() + '/ExportUsers?employeeId=' + serverVariableService.USER_EID() + '&exportType=1&signedUrl=' + response;
            window.open(exportURL);
        }

        function getSignedKeyForUserAccessViewExportCallback(response) {
            var exportURL = serverVariableService.MDUA_USERS_ENDPOINT() + '/ExportUsers?employeeId=' + serverVariableService.USER_EID() + '&exportType=2&signedUrl=' + response;
            window.open(exportURL);
        }

        function refreshUsersFromADCallback(response) {
            
            //Success
            if (response.ResponseType == 0) {
                self.showAlert("success", response.Message);
            }
            else if (response.ResponseType == 1) {
                self.showAlert("danger", response.Message);
            }
            else if (response.ResponseType == 2) {
                self.showAlert("danger", response.Message);
            }
            else if (response.ResponseType == 3) {
                self.showAlert("info", response.Message);
            }
            else {
                console.log(response.ResponseType);
                console.log(response.Message);
            }
            spinnerService.hide("overlaySpinner");

            //Automatically set view to User view to refresh user list
            self.viewModel.SelectedView = self.viewModel.AvailableViews[0];
            //force to pull user list after ad refresh
            self.setUsersView(true);
        }

        function errorCallback(data) {
            self.showAlert("danger", "Error occured. Try again or contact system administrator");
            console.log(data);
            spinnerService.hide("overlaySpinner");
        }
        //Load Page
        self.onLoad();
    }

    //view models
    function ManageUsersViewModel() {
        var self = this;

        self.RowsPerPage = 200;
        //Available views
        self.AvailableViews = ['Users View', 'User Access View'];
        //Select Users View by default
        self.SelectedView = self.AvailableViews[0];
        //ColumnDefs for Users View
        self.UserViewColDefs = [
                          { name: 'EmployeeId', displayName: 'Employee Id', field: 'EmployeeId', enableCellEdit: false },
                          { name: 'UserId', displayName: 'User Id', field: 'UserId', enableCellEdit: false },
                          { name: 'LastName', displayName: 'Last Name', field: 'LastName', enableCellEdit: false },
                          { name: 'FirstName', displayName: 'First Name', field: 'FirstName', enableCellEdit: false },
                          { name: 'Active', displayName: 'Active', field: 'Active', enableCellEdit: false }
        ];
        //ColumnDefs for Users View
        self.UserAccessViewColDefs = [
                          { name: 'ModuleName', displayName: 'Module Name', field: 'ModuleName', enableCellEdit: false },
                          { name: 'ModuleItemName', displayName: 'Module Item Name', field: 'ModuleItemName', enableCellEdit: false },
                          { name: 'EmployeeId', displayName: 'Employee Id', field: 'EmployeeId', enableCellEdit: false },
                          { name: 'LastName', displayName: 'Last Name', field: 'LastName', enableCellEdit: false },
                          { name: 'FirstName', displayName: 'First Name', field: 'FirstName', enableCellEdit: false },
                          { name: 'Access', displayName: 'Access', field: 'Access', enableCellEdit: false }
        ];

        
        self.UserAccessPages = [];
        self.TotalUserAccessPages = 0;
        self.TotalUserAccessRows = 0;

        self.IsUsersViewDataLoaded = false;
        self.IsUserAccessViewDataLoaded = false;

        self.UserList = [];
        self.UserAccessList = [];
        self.SelectedUser = null;

        self.appendUserAccessList = function (userAccessList) {
            for (var idx = 0; idx < userAccessList.length; idx++) {
                self.UserAccessList.push(new UserAccessViewModel(userAccessList[idx]));
            }
        }
    }


    function userViewModel(user) {
        var self = this;
        self.EmployeeId  = user.EmployeeId;
        self.FirstName = user.FirstName;
        self.LastName = user.LastName;
        self.UserId = user.UserId;
        self.Active = (user.Active === true) ? 'Yes' : 'No';
        self.UserRole = user.UserRole;
    }

    function UserAccessPageViewModel(userAccessPage){
        var self = this;
        self.PageInfo = new PageViewModel(userAccessPage.PageNumber, userAccessPage.RowsPerPage, userAccessPage.TotalPages, userAccessPage.TotalRows);
        self.UserAccessList = userAccessPage.UserAccessList;
        //for (var idx = 0; idx < userAccessPage.UserAccessList.length; idx++) {
        //    self.UserAccessList.push(new UserAccessViewModel(userAccessPage.UserAccessList[idx]));
        //}
        
    }

    function UserAccessViewModel(accessInfo) {
        var self = this;
        self.ModuleName = accessInfo.AccessObjectType;
        self.ModuleItemName = accessInfo.AccessObjectName;
        self.ModuleItemDescription = accessInfo.AccessObjectDescription;
        //self.User = new userViewModel(accessInfo.User);
        self.Access = accessInfo.AccessType[0];
        self.FirstName = accessInfo.User.FirstName;
        self.LastName = accessInfo.User.LastName;
        self.EmployeeId = accessInfo.User.EmployeeId;
    }

    function PageViewModel(pageNumber, rowsPerPage, totalPages, totalRows) {
        var self = this;
        self.PageNumber = pageNumber;
        self.RowsPerPage = rowsPerPage;
        self.TotalPages = totalPages;
        self.TotalRows = totalRows;
    }

})(window.jQuery);