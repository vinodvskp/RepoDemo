﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Optimization;
namespace MDUA.App_Start
{
    public class BundleConfig
    {
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                "~/jscript/lib/angular.min.js",
                "~/jscript/lib/angular-animate.min.js",
                "~/jscript/lib/angular-touch.min.js",
                "~/jscript/lib/ui-router.js",
                "~/jscript/lib/exclusions.js",
                "~/jscript/lib/angular-spinners.min.js",
                "~/vzbootstrap-angular/ui-bootstrap-tpls.min.js",
                "~/jscript/xdomain.min.js",
                "~/vzbootstrap/scripts/jquery.min.js",
                "~/vzbootstrap/scripts/bootstrap.min.js",
                "~/vzbootstrap/scripts/vzbootstrap.min.js",
                "~/vzbootstrap/vz-components/vz-search/vz-search.min.js",
                "~/jscript/FileSaver.js",
                "~/jscript/lib/jquery.signalR-2.2.1.min.js"
                ));


            bundles.Add(new ScriptBundle("~/bundles/uigrid").Include(
                "~/angular-ui-grid/ui-grid.min.js",
                "~/jscript/lib/csv.js",
                "~/jscript/lib/pdfmake.js",
                "~/jscript/lib/vfs_fonts.js"
                ));

            

            bundles.Add(new ScriptBundle("~/bundles/angularservices").Include(
                "~/common/common.js",
                "~/vmApp/security/security.js",
                "~/applications.js",
                "~/common/js/directives/workSpinner.js",
                "~/common/js/directives/pageAlerts.js",
                "~/common/js/directives/errorHandler.js",
                "~/common/js/directives/fileDrop.js",
                "~/common/js/directives/ngEnter.js",
                "~/common/js/services/requestCounterService.js",
                "~/common/js/services/alertingService.js",
                "~/common/js/services/localStoreService.js",
                "~/common/js/services/notificationSubscriberService.js",
                "~/common/js/services/errorHandlerService.js",
                "~/common/js/services/noCacheInterceptorService.js",
                "~/common/js/services/confirmModalService.js",
                "~/common/js/services/userMenuService.js",
                "~/common/js/services/userRoleService.js",
                "~/vmApp/js/services/constantService.js",
                "~/vmApp/js/services/serverVariableService.js",
                "~/vmApp/js/services/mainService.js",
                "~/vmApp/js/services/createRequestService.js",
                "~/vmApp/js/services/requestDetailsService.js",
                "~/vmApp/js/services/requestTrackingService.js",
                "~/vmApp/js/services/authenticationService.js",
                "~/vmApp/js/services/storeService.js",
                "~/vmApp/js/services/tinymceService.js",
                "~/jscript/lib/tinymce/tinymce.min.js",
                "~/dataScoopApp/js/services/ApplicationManagementService.js",
                "~/mtApp/js/services/mappingTablesService.js",
                "~/mtApp/js/services/mappingTablesAuditService.js",
                "~/mduaApp/js/services/userProfileService.js",
                "~/mduaApp/js/services/onDemandJobsService.js",
                "~/mduaApp/js/services/userUploadsService.js",
                "~/mduaApp/js/services/userUploadFeedService.js",
                "~/mduaApp/js/services/manageUsersService.js",
                "~/vmApp/js/controllers/mainController.js",
                "~/vmApp/js/controllers/homeController.js",
                "~/vmApp/js/controllers/createRequestController.js",
                "~/vmApp/js/controllers/requestDetailsController.js",
                "~/vmApp/js/controllers/requestTrackingController.js",
                "~/vmApp/js/controllers/versionManagementController.js",
                "~/dataScoopApp/js/Filters.js",
                "~/mtApp/js/controllers/mappingTablesController.js",
                "~/mtApp/js/controllers/mappingTablesStaticDataController.js",
                "~/mtApp/js/controllers/mappingTablesAuditController.js",
                "~/mduaApp/js/controllers/userProfileController.js",                
                "~/mduaApp/js/controllers/onDemandJobsContoller.js",
                "~/mduaApp/js/controllers/manageFileTypesController.js",
                "~/mduaApp/js/controllers/userUploadsController.js",                
                "~/mduaApp/js/controllers/userUploadFeedController.js",
                "~/mduaApp/js/controllers/userFactDataUploadStepController.js",
                "~/mduaApp/js/controllers/userKeyComboUploadStepController.js",
                "~/common/js/controllers/menuController.js",
                "~/common/js/controllers/userProfileMenuController.js",
                "~/mduaApp/js/controllers/factAuditController.js",
                "~/mduaApp/js/services/factAuditService.js",
                "~/mduaApp/js/controllers/factDownloadController.js",
                "~/mduaApp/js/services/factDownloadService.js",
                "~/mduaApp/js/controllers/fileTransferController.js",
                "~/mduaApp/js/services/fileTransferService.js",
                "~/dataScoopApp/js/controllers/ApplicationManagementController.js",
                "~/mduaApp/js/controllers/manageUsersController.js",
                "~/mtApp/js/controllers/reportingcontroller.js",
                "~/mtApp/js/services/reportingservice.js"
                ));

            bundles.Add(new ScriptBundle("~/bundles/angulardirectives").Include(
                "~/vmApp/js/directives/onFinishRender.js",
                "~/vmApp/js/directives/modal.js",
                "~/vmApp/js/directives/fileModel.js",
                "~/vmApp/js/directives/pageBreadCrumb.js",
                "~/vmApp/js/directives/fileUpload.js",
                "~/common/js/directives/fileDrop.js",
                "~/common/js/directives/fileDropper.js",
                "~/common/js/directives/fileRead.js"
                ));


            bundles.Add(new StyleBundle("~/bundles/bootstrapstyles").Include(
                "~/vzbootstrap/styles/bootstrap.min.css",
                "~/vzbootstrap/styles/vzbootstrap.min.css",
                "~/vmApp/styles/font-awesome.min.css",
                "~/vzbootstrap-angular/vzbsangular-styles.min.css"
                ));

            bundles.Add(new StyleBundle("~/bundles/portalstyles").Include(
                "~/angular-ui-grid/ui-grid.min.css",
                "~/vmApp/styles/vmApp.css",
                "~/mtApp/styles/mtApp.css",
                "~/mduaApp/styles/mduaApp.css",
                "~/mduaApp/styles/base64-encoder.css",
                "~/dataScoopApp/styles/dataScoopApp.css"
                ));

        }
    }
}