using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using MDUA.BusinessLogic;
using MDUA.DTO;
using System.Drawing;
using System.IO;

public partial class OpsFileKeys : System.Web.UI.Page
{
   public delegate string DetermineMsgText( );
    private ArrayList arrDims = null;

    protected void Page_Load(object sender, EventArgs e)
    {
        Master.PageTitle = "Input File Keys";
        Master.NavInstructionsVisible = true;

        //  Regular Users can't add keys
        if (Master.SignedIn(UserRole.RegUser) == false)
            return;
        btnAdd.Visible = Master.curUser.CanAddUserInputKeys;
        fuNewKey.Enabled = Master.curUser.CanAddUserInputKeys;

        if (IsPostBack == false)
        {
            ShowSelectionControls(false);
        }
    }
  
    protected void ddlCube_SelectedIndexChanged(object sender, EventArgs e)
    {
        //  Get a list of File types that this user can upload
        string[] spInfo = ddlCube.SelectedValue.Split(';');
        ArrayList arrTypes = Utils.GetInputFiles(spInfo[0], Master.curUser.EmployeeID);
        hfMasterTableId.Value = spInfo[0];
        hfStageYear.Value = spInfo[1];
        hfStageMonth.Value = spInfo[2];
        hfPreFactLoad.Value = spInfo[3];
        hfKeyComboTable.Value = spInfo[4];

        ShowSelectionControls(true);
        ddlFileType.Items.Clear();
        foreach (HypFileType hft in arrTypes)
        {
            if (hft.UsesValidKeyCombos == false)
                continue;

            ListItem li = new ListItem();
            li.Text = string.Format("{0} ({1})", hft.Description, hft.Code);
            li.Value = hft.Code;
            ddlFileType.Items.Add(li);
        }

        //  If this user doesn't have any file types that they can upload,
        //  Go back to the default page.
        if (ddlFileType.Items.Count == 0)
        {
            Master.Message = "You don't have access to load any keys for this Fact Table type";
            ShowSelectionControls(false);
            return;
        }

        //  If there are items, put in a default item so that they don't accidentally
        //  upload to the first file type because they forgot to change the file type.
        ListItem sel = new ListItem();
        sel.Value = "";
        sel.Text = "Select Input File Type...";
        ddlFileType.Items.Insert(0, sel);
    }

    private void ShowSelectionControls(bool bShow)
    {
        lblFileType.Visible = bShow;
        lblInputFile.Visible = bShow;
        ddlFileType.Visible = bShow;
        fuNewKey.Visible = bShow;
        divButtons.Style["display"] = bShow ? "block" : "none";

        //  Only hide these if we are hiding everything.  But don't show them
        //  automatically when we show everything.
        if (bShow == false)
            divSelBtns.Style["display"] = "none";
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        divSelBtns.Style["display"] = "none";
        tblKeys.Visible = false;

        //  Make sure that they picked a file type and selected a file.
        if (ddlFileType.SelectedValue == "")
        {
            Master.Message = "You must select a File Type first";
            return;
        }

        if (fuNewKey.HasFile == false)
        {
            Master.Message = "You must select a file which contains the keys to add.";
            return;
        }

        hfCmd.Value = "Add";
        string Filename = "";

        //  Check to see if someone else is running a process that we should be waiting for.
        HypFileType hft = Utils.GetInputFile(ddlFileType.SelectedValue, Master.curUser.EmployeeID);

        int myRunId = Utils.RunStatusAdd("INPUT_FILE", "201001", "In Progress", "Running", Master.curUser.UserId, ddlFileType.SelectedValue);
        hfRunStatusId.Value = myRunId.ToString();

        DateTime dtNow = DateTime.Now;
        try
        {
            //  Upload the file and load the data based on the extension of the file.
            string DestDir = string.Format("Archive/{0}{1}", DateTime.Now.Year, DateTime.Now.Month);
            DestDir = Server.MapPath(DestDir);
            if (Directory.Exists(DestDir) == false)
                Directory.CreateDirectory(DestDir);

            Filename = DestDir + string.Format("\\{0}-{1}-{2}-{3}{4}",
                Master.curUser.UserId,
                hfMasterTableId.Value,
                hft.Code,
                dtNow.ToString("yyyyMMdd_HHmmss"),
                Path.GetExtension(fuNewKey.FileName));
            fuNewKey.SaveAs(Filename);


             int TotRecsAdded = 0;

            //  Load the contents of the file and then delete the input file.
            string TableName = hft.is13Month ? hfStageYear.Value : hfStageMonth.Value;
            arrDims = Utils.GetFactDimensions(hfMasterTableId.Value, hft.is13Month, false, true);
            ArrayList arrFacts = Facts.GetFacts();
            string scenario;
            ReturnCodeDTO rc =   Utils.LoadDataInputFileIntoTable(Filename, TableName, arrDims, hft, Master.curUser.UserId, myRunId, out scenario);
            hfScenario.Value = scenario;
            Utils.DeleteFile(Filename, Master.curUser.EmployeeID);

            //  If not successful, an error was logged the routine created the error message.
            if (rc.Success == false || rc.ReturnCode == -1)
            {
                Master.Message = rc.Message ;
                return;
            }
            
            //  Setup Error Table with all the columns
            SetupErrorTable();

            //  All Data Manipulation and Validation routines will throw errors if there is an 
            //  issue, so we don't need to check return codes from any of the routines.
            //  Check to see if there are any field that have forced values.
            rc = Utils.ProcessInputFileForceValues(hft, TableName, myRunId);
            if (rc.Success == false)
            {
                Master.Message = rc.Message;
                return;
            }

            arrFacts = Utils.ValidateAdjScenario(TableName, hft, arrDims, myRunId);
            if (arrFacts.Count > 0)
            {
                FillTable(arrFacts, null, string.Format("The Scenario must only contain {0}adjustment scenarios.", (hft.isAdjustment ? "" : "non-")));
                //DisplayPopUpMessage("The file must be resubmitted.");
                Master.Message = "The file has Scenarios that do not match the file definition.";
                return;
            }

            //  Make sure all the data is valid
            arrFacts=Utils.ValidateDimensionFields(TableName, hft, myRunId);
            if (arrFacts.Count > 0)
            {
                FillTable(arrFacts, null, string.Format("The Scenario must only contain {0}adjustment scenarios.", (hft.isAdjustment ? "" : "non-")));
                //DisplayPopUpMessage("The file must be resubmitted.");
                Master.Message = "There are Invalid Field Values in the User Feed.  Check individual lines for more information.";
                return;
            }
                             


            //  Check for any duplicate records
            ValidateDuplicateRows(TableName, hft,  myRunId);

            //  If the key combinations exist under a different file type, warn the user.
            ValidateKeyCombinations(TableName, hft, Scenario, Rdr, dtNow, myRunId);

            DisplayRecsToBeAdded(TableName, hft, Scenario, Rdr, dtNow, myRunId);
        }
        catch (Exception exAll)
        {
            divSelBtns.Style["display"] = "none";
            Utils.LogEvent(Master.curUser.EmployeeID, "OpsFIleKeysaspx", "btnAdd_Click", exAll, LogLevel.Error);
            Master.Message = HypMDUA.ERROR_MESSAGE;
        }
 
        Utils.DelUserInputFile(dtNow, Master.curUser.EmployeeID);
    }
    
    protected void btnCancel_Click(object sender, EventArgs e)
    {

    }
    
    protected void btnContinue_Click(object sender, EventArgs e)
    {

    }
    
    protected void btnDelete_Click(object sender, EventArgs e)
    {

    }

    private void SetupErrorTable()
    {
        tblKeys.Rows[0].Cells.Clear();
        tblKeys.Rows[0].Cells.Add(new TableCell());
        tblKeys.Rows[0].Cells[0].Text = "Line Nbr";
        foreach (MasterDimension md in arrDims)
        {
            TableCell tcHdr = new TableCell();
            tcHdr.Text = md.Code;
            tblKeys.Rows[0].Cells.Add(tcHdr);
        }
    }
    
    

    public void ValidateDuplicateRows(string TableName, HypFileType hft, BasicOraReader Rdr, int RunId)
    {
        string Cmd = "Select count(s.*)";
        string Flds = "";
        foreach (MasterDimension md in arrDims)
            Flds += ",s." + md.Code;
        Cmd += Flds;
        Cmd += string.Format(" from {0} s where s.run_status_id={1}", TableName, RunId);
        Cmd += " group by " + Flds.Substring(1);
        Cmd += " having count(s.*) > 1";

        if (Rdr.Open(Cmd) == true && Rdr.oraRdr.HasRows == true)
        {
            FillTable(Rdr, null, "This row is duplicated in the file.  It appears as many times as indicated by the Line Nbr column.");
            //DisplayPopUpMessage("The file must be resubmitted.");
            throw new Exception("There are duplicate rows in the file.  The Line Nbr column shows how many times this combination repeats.");
        }
    }

    public void ValidateDimensionFields(string TableName, HypFileType hft, BasicOraReader Rdr, int RunId)
    {
        string AddlFlds = "";
        string Joins = "";
        string Where = "";
        string Cmd = "Select s.Line_Nbr";
        foreach (MasterDimension md in arrDims)
        {
            Cmd += ",s." + md.Code;
            if (md.MasterTable.Length > 0)
            {
                AddlFlds += string.Format(",{0}.{1}", md.TableAlias,
                    md.ValidationColumn);
                Joins += string.Format(" left outer join {0} {1} on s.{2}={1}.{3} ",
                    md.MasterTable, md.TableAlias, md.Code, md.ValidationColumn);
                if (md.ExtraValidationClause.Length > 0)
                    Joins += " and " + md.ExtraValidationClause;
                if (Where.Length > 0)
                    Where += " or ";
                Where += string.Format(" {0}.{1} is null", md.TableAlias,
                    md.ValidationColumn);
            }
        }

        Cmd += AddlFlds;
        Cmd += string.Format(" from {0} s", TableName);
        Cmd += Joins;
        Cmd += string.Format(" where s.run_status_id={0} and (", RunId);
        Cmd += Where + ") order by s.Line_Nbr";

        if (Rdr.Open(Cmd) == true && Rdr.oraRdr.HasRows == true)
        {
            int Cnt = FillTable(Rdr, CheckNotFoundFlds, null);
            //DisplayPopUpMessage("The file must be resubmitted.");
            throw new Exception("There are Invalid Field Values in the User Feed.  Check individual lines for more information.");
        }
    }

    private string CheckNotFoundFlds(BasicOraReader Rdr)
    {
        string Msg = "The following field(s) are not valid: ";
        foreach (MasterDimension md in arrDims)
        {
            if (md.MasterTable.Length > 0 && md.ValidationColumn.Length > 0)
            {
                int Col = Rdr.oraRdr.GetOrdinal(md.ValidationColumn);
                if (Col >= 0)
                    if (Rdr.oraRdr.IsDBNull(Col) == true)
                        Msg += md.Code + "    ";
            }
        }
        return Msg;
    }

    public void ValidateKeyCombinations(string TableName, HypFileType hft, string Scenario, BasicOraReader Rdr,
        DateTime dtNow, int RunId)
    {
        //  Check to see if these key combinations exist already in the key combination table for
        //  another file type.
        string Cmd = "Select s.Line_Nbr";
        string Joins = "";
        string CmboJoin = string.Format(" join {0} CMBO on CMBO.FILE_TYPE != '{1}'",
            hfKeyComboTable.Value, hft.Code);
        foreach (MasterDimension md in arrDims)
        {
            Cmd += ",s." + md.Code;
            Joins += string.Format(" join {0} {1} on s.{2}={1}.{3}",
                md.MasterTable, md.TableAlias, md.Code, md.ValidationColumn);
            CmboJoin += string.Format(" and CMBO.{0}={1}.{0}",
                md.IdColumn, md.TableAlias);
        }

        Cmd += string.Format(",CMBO.FILE_TYPE from {0} s", TableName);
        Cmd += Joins + CmboJoin;
        Cmd += string.Format(" where s.run_status_id={0} ", RunId);
        Cmd += " order by s.Line_Nbr";

        if (Rdr.Open(Cmd) == true && Rdr.oraRdr.HasRows == true)
        {
            tblKeys.Visible = true;
            int Cnt = FillTable(Rdr, DisplayInvalidKeyCombo, null);
            //DisplayPopUpMessage("The file must be resubmitted.");
            //throw new Exception("Warning: some key combinations already exist for other file types.  Check individual lines for more information.");
        }
    }

    private string DisplayInvalidKeyCombo(BasicOraReader Rdr)
    {
        return "This key combination already exists for " + Rdr.oraRdr.GetString(arrDims.Count + 1);
    }

    public int DisplayRecsToBeAdded(string TableName, HypFileType hft, string Scenario, BasicOraReader Rdr,
        DateTime dtNow, int RunId)
    {
        //  Check to see if these key combinations exist already in the key combination table for
        //  another file type.
        string Cmd = "Select s.Line_Nbr";
        string Joins = "";
        string CmboJoin = string.Format(" left outer join {0} CMBO on CMBO.FILE_TYPE = '{1}'",
            hfKeyComboTable.Value, hft.Code);
        foreach (MasterDimension md in arrDims)
        {
            Cmd += ",s." + md.Code;
            Joins += string.Format(" join {0} {1} on s.{2}={1}.{3}",
                md.MasterTable, md.TableAlias, md.Code, md.ValidationColumn);
            CmboJoin += string.Format(" and CMBO.{0}={1}.{0}",
                md.IdColumn, md.TableAlias);
        }

        Cmd += string.Format(" from {0} s", TableName);
        Cmd += Joins + CmboJoin;
        Cmd += string.Format(" where s.run_status_id={0} and CMBO.FILE_TYPE is null", RunId);
        Cmd += " order by s.Line_Nbr";

        int NbrToAdd = 0;
        if (Rdr.Open(Cmd) == true && Rdr.oraRdr.HasRows == true)
        {
            tblKeys.Visible = true;
            divSelBtns.Style["display"] = "none";
            NbrToAdd = FillTable(Rdr, null, null);

            if (NbrToAdd > 0)
            {
                Master.Message = "The following key combinations will be added to the validation table.  Do you want to continue?";
                btnContinue.Visible = true;
                btnCancel.Visible = true;
                btnAdd.Visible = false;
                ddlFileType.Enabled = false;
            }
        }

        if (NbrToAdd == 0)
        {
            Master.Message = "There are no items that don't already exist in the validation table.";
            btnContinue.Visible = false;
            btnCancel.Visible = false;
            btnAdd.Visible = true;
            tblKeys.Visible = false;
        }

        return NbrToAdd;
    }

    private int FillTable(ArrayList arr, DetermineMsgText GetMsg, string DefaultMsg)
    {
        Color AltBgnd = Color.FromArgb(231, 242, 254); //#E7F2FE
        Color RegBgnd = Color.White;
        int MainRowCnt = 0;

        pnlHFs.Controls.Clear();
        int FldCnt = tblKeys.Rows[0].Cells.Count;
        while (Rdr.oraRdr.Read())
        {
            ++MainRowCnt;

            //  Create a row for the budget group.
            TableRow tr = new TableRow();
            tr.ForeColor = Color.Black;
            tr.BackColor = (((MainRowCnt & 1) == 1) ? RegBgnd : AltBgnd);
            tblKeys.Rows.Add(tr);

            for (int c = 0; c < FldCnt; c++)
            {
                TableCell tc = new TableCell();
                tc.Text = string.Format("{0}", arr[c]);
                tr.Cells.Add(tc);
            }

            //  Now Check to see if there is an error to be displayed.
            string ErrMsg = "";
            if (GetMsg != null)
                ErrMsg = GetMsg(Rdr);
            else
                if (DefaultMsg != null && DefaultMsg.Length > 0)
                    ErrMsg = DefaultMsg;

            if (ErrMsg.Length > 0)
            {
                tr.ForeColor = Color.Red;
                TableRow trErr = new TableRow();
                trErr.BackColor = tr.BackColor;
                TableCell tcErr = new TableCell();
                tcErr.ColumnSpan = tr.Cells.Count;
                tcErr.Text = ErrMsg;
                tcErr.ForeColor = Color.Red;
                trErr.Cells.Add(tcErr);
                tblKeys.Rows.Add(trErr);
                btnContinue.Visible = false;
                btnAdd.Visible = true;
            }
            else
            {
                string Data = "";
                for (int i = 0; i < tr.Cells.Count; i++)
                    Data += tr.Cells[i].Text + "|";
                HiddenField hf = new HiddenField();
                hf.ID = string.Format("hf{0}", MainRowCnt);
                hf.Value = Data;
                pnlHFs.Controls.Add(hf);
            }
        }
        hfNbrItems.Value = MainRowCnt.ToString();
        return MainRowCnt;
    }
}
