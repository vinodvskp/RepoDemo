﻿using System;
using System.Collections;
using System.Configuration;
using System.IO;
using System.Web.UI.WebControls;
using MDUA.BusinessLogic;
using MDUA.DTO;
using MDUA.DataAccess;
using System.Collections.Generic;

public partial class UserInputUpload : System.Web.UI.Page
{
    #region locals
    // the delegate to create error messages is called against rows returned by validator
    public delegate string DetermineMsgText(FactValidDTO a);

    private string InvalidKeyFlds = "";
    private WebSettings settings = new WebSettings();

    /* needed for pagination 
    protected global::System.Web.UI.WebControls.TableCell tcPageCount;
    protected global::System.Web.UI.WebControls.TableCell tcRowCount;
    protected global::System.Web.UI.WebControls.Label lblPageCount;
    protected global::System.Web.UI.WebControls.Label lblRowCount;
    */
    #endregion

    #region events
    protected void Page_Load(object sender, EventArgs e) {
        Master.PageTitle = "User Input Upload";
        //BS
        //Master.NavInstructionsVisible = true;
        settings = Utils.LoadWebSetting(Master.curUser.EmployeeID);
        // jevans 5/23/2012 - if web settings is null, database is not available.
        if (settings == null) {
            Master.Message = "MDUA could not load web settings from the database, and cannot continue.  <P>" + HypMDUA.ERROR_MESSAGE;
            return;
        }
        if (!IsPostBack) {
            ArrayList aYears = Utils.GetDimYears();
            foreach (string s in aYears)
                ddlYears.Items.Add(s);
            // pnlGridHead.Visible = false;
            // Session.Remove ("ArrayList")  ;
            if (!settings.UserFeedEnabled) {
                try {
                    Master.PendingMessage = "User File Uploads have been Disabled.  Check with the Financial Team to find out when they will be available.";
                    Response.Redirect("~/Default.aspx");
                } catch (System.Threading.ThreadAbortException)
                {
                    // thread was aborted ... do nothing
                }
            }

            ddlMonths.SelectedValue = settings.CurrentMonthInt.ToString();
            ddlYears.SelectedValue = settings.CurrentYear;
            ddlMonths.Enabled = Master.curUser.CanPostToAnyPeriod || Master.curUser.Role == UserRole.Admin;
            ddlYears.Enabled = Master.curUser.CanPostToAnyPeriod;

            //  Get a list of File types that this user can upload
            List<FileType> fileTypes = Utils.GetFileTypes( Master.curUser.EmployeeID);

            //  If this user doesn't have any file types that they can upload,
            //  Go back to the default page.
            if (fileTypes == null || fileTypes.Count == 0)
            {
                try
                {
                    if (fileTypes == null)
                        Master.PendingMessage = HypMDUA.ERROR_MESSAGE;
                    else
                        Master.PendingMessage = "You don't have access to upload files";
                    Response.Redirect("~/Default.aspx");
                }
                catch (System.Threading.ThreadAbortException)
                {
                    // thread was aborted ... do nothing
                }
            }

            foreach (FileType hft in fileTypes) {                
                ddlFileType.Items.Add(new ListItem(string.Format("{0} ({1})", hft.Description, hft.FileTypeCode), hft.FileTypeCode));
            }

            //  If there are items, put in a default item so that they don't accidentally
            //  upload to the first file type because they forgot to change the file type.
            ddlFileType.Items.Insert(0, new ListItem("Select File Type...", string.Empty));
        } else {
            // postback 
        }
        //  If the File Type was passed in as a parameter, process the file using the 
        //  information passed in.  The information would be passed in if the user 
        //  selected a legacy file from the new File Upload page.  The requests will come
        //  from OpsUploadInputFile.aspx.  We only need to check the query strings if this
        //  is not a post back.  If it is a post back, we should have already processed these.
        if (!IsPostBack && Request.QueryString["FILE_TYPE"] != null && Request.QueryString["FILE_TYPE"].Length > 0) {
            foreach (ListItem li in ddlFileType.Items)
                if (li.Value.StartsWith(Request.QueryString["FILE_TYPE"])) {
                    li.Selected = true;
                    break;
                }
            ddlMonths.SelectedValue = Request.QueryString["MONTH"];
            ddlYears.SelectedValue = Request.QueryString["YEAR"];
            string fn = Request.QueryString["FN"];
            FileType hft = Utils.GetFileType(ddlFileType.SelectedValue, Master.curUser.EmployeeID);
            ProcessUploadFile(fn, hft);
            return;
        }
    }

    protected void btnUpload_Click(object sender, EventArgs e) {
        btnDownload.Visible = false;
        Master.Message = "";
        litPopupMsg.Text = "";
        // jevans 4/24/2012 - hide grid from last upload until results are calculated
        gvResults.Visible = false;
        litSkippedRows.Visible = false;
        ShowContinueItems(false);
        // this was defined in page load
        //HypWebSettings Settings = Utils.LoadWebSetting(Master.curUser.EmployeeID);
        
        if (!settings.UserFeedEnabled) {
            Master.Message = "User File Uploads have been Disabled.  Check with the Financial Team to find out when they will be available.";
            return;
        }

        //  Make sure that they picked a file type and selected a file.
        if (ddlFileType.SelectedValue == "") {
            Master.Message = "You must select a File Type first";
            return;
        }

        if (!fuUserFile.HasFile) {
            Master.Message = "You must select a File to upload.";
            return;
        }

        //  Now get the file type information so that we can     see if this is a legacy file.
        FileType fileType = Utils.GetFileType(ddlFileType.SelectedValue, Master.curUser.EmployeeID);

        // jevans 3/29/2011 - check for fiscal period of CPGA uploads:
        if (fileType.DestinationTable.StartsWith("CPGA_") && int.Parse(ddlYears.SelectedValue) < 2009) {
            Master.Message = "CPGA adjustment upload for period prior to 2009 is not currently supported";
            return;
        }

        //  Save the file now in case this is a Legacy Request.
        System.Diagnostics.Debug.WriteLine(DateTime.Now);
        string filename = "";
        try {
            //  Upload the file and load the data based on the extension of the file.
            string destinationDirectory = string.Format("Archive/{0}{1}", DateTime.Now.Year, DateTime.Now.Month);
            destinationDirectory = Server.MapPath(destinationDirectory);
            if (!Directory.Exists(destinationDirectory))
                Directory.CreateDirectory(destinationDirectory);

            filename = destinationDirectory + string.Format("\\{0}-{1}-{2}{3}", Master.curUser.UserId, fileType.FileTypeCode
                , DateTime.Now.ToString("yyyyMMdd_HHmmss"), Path.GetExtension(fuUserFile.FileName));
            fuUserFile.SaveAs(filename);
            hfFileName.Value = filename;
        } catch (Exception exFile) {
            if (filename.Length > 0) {
                Utils.DeleteFile(filename, Master.curUser.EmployeeID);
            }
            Master.Message = "An error occurred trying to save the file: " + exFile.Message;
            return;
        }
        System.Diagnostics.Debug.WriteLine(DateTime.Now);
        
        switch ((FactTable)fileType.FactTableId) {
            case FactTable.EquipmentUser:
            case FactTable.ProductOfferUser:
            case FactTable.PlanningActuals:
            case FactTable.DevicePaymentLoan:
                ProcessExcelFile(filename, fileType);
                break;
            default:
                ProcessUploadFile(filename, fileType);
                break;
        }
    }

    protected void btnDownload_Click(object sender, EventArgs e)
    {
        //  Make sure that they picked a file type and selected a file.
        litPopupMsg.Text = "";
        btnDownload.Visible = false;
        if (ddlFileType.SelectedValue == "")
        {
            Master.Message = "You must select a File Type first";
            return;
        }

        //  Check to see if someone else is running a process that we should be waiting for.
        //string[] Codes = ddlFileType.SelectedValue.Split(';');
        //HypFileType hft = Utils.GetFileType(Codes[0], Master.curUser.EmployeeID);
        FileType hft = Utils.GetFileType(ddlFileType.SelectedValue, Master.curUser.EmployeeID);


        string Filename = string.Format("Downloads/{1}_{2}_{0}.csv",
            DateTime.Now.ToString("yyyyMMdd_HHmmss"),
            Master.curUser.UserId, hft.FileTypeCode);
        Filename = Server.MapPath(Filename);
        switch (Utils.WriteDataToCSV(hft, Master.curUser.EmployeeID, Filename))
        {
            case 0:
                Master.Message = "There was no Fact data found for the selected type and period. ";
                break;
            case -1:
                Master.Message = HypMDUA.ERROR_MESSAGE;
                break;
            default:
                try {
                    Response.Redirect(string.Format("DownloadFile.aspx?DocName={0}&Del=Y", Filename));
                } catch (System.Threading.ThreadAbortException) { /* thread was aborted ... do nothing */}
                break;
        }
    }

    protected void btnContinue_Click(object sender, EventArgs e) {
        string message;
        ArrayList results;
        StageProcessingStatus status = StageProcessingStatus.None;
        int rows;
        int rowsSkipped;

        FileType fileType = Utils.GetFileType(ddlFileType.SelectedValue, Master.curUser.EmployeeID);
        if (fileType.FactTableId == (int)FactTable.ProductOfferUser || fileType.FactTableId == (int)FactTable.EquipmentUser || fileType.FactTableId == (int)FactTable.PlanningActuals || fileType.FactTableId == (int)FactTable.DevicePaymentLoan)
        {
            try {
                if (fileType.FactTableId == (int)FactTable.ProductOfferUser) {
                    results = ProductOfferDatabaseAccess.ProcessMissingKeysAndStagedData(int.Parse(hfRunStatusId.Value), fileType, Master.curUser.EmployeeID, out status, out rows, out rowsSkipped);
                }
                else if (fileType.FactTableId == (int)FactTable.PlanningActuals)
                {
                    results = PlanningActualsDatabaseAccess.ProcessMissingKeysAndStagedData(int.Parse(hfRunStatusId.Value), fileType, Master.curUser.EmployeeID, out status, out rows, out rowsSkipped);
                }
                else if (fileType.FactTableId == (int)FactTable.DevicePaymentLoan)
                {
                    results = DevicePaymentLoanDatabaseAccess.ProcessMissingKeysAndStagedData(int.Parse(hfRunStatusId.Value), fileType, Master.curUser.EmployeeID, out status, out rows, out rowsSkipped);
                }
                else
                {
                    results = EquipmentDatabaseAccess.ProcessMissingKeysAndStagedData(int.Parse(hfRunStatusId.Value), fileType, Master.curUser.EmployeeID, out status, out rows, out rowsSkipped);
                }
                switch (status) {
                    case StageProcessingStatus.AdditionOfKeysRequired:
                        Master.Message = "Key combinations missing for following items (clicking the continue button will add the keys and update the fact table):";
                        ShowContinueItems(true);
                        FillGrid(results, fileType, true, true, rowsSkipped);
                        break;
                    case StageProcessingStatus.CriticalValidationsFailed:
                        Master.Message = "Issues detected with input file, please refer to the messages in the grid for additional details";
                        DisplayPopUpMessage("The file must be resubmitted.");
                        FillGrid(results, fileType, true, true, rowsSkipped);
                        break;
                    case StageProcessingStatus.LoadedToFact:
                        Master.Message = string.Format("<br>{0} item(s) were added or modified.", rows);
                        Utils.LogEvent(Master.curUser.EmployeeID, "UserInputUpload", "Uploaded User File " + fileType.FileTypeCode, string.Format("{0} item(s) were added or modified.", rows), UserToolLogLevel.Audit);
                        FillGrid(results, fileType, false, false, rowsSkipped);
                        break;
                }
            } catch (Exception exception) {
                Master.Message = exception.Message;
                //Utils.DeleteFile(hfFileName.Value, Master.curUser.EmployeeID);
                //Utils.RunStatusComplete(int.Parse(hfRunStatusId.Value), "Error", exception.Message.Length > 0 ? exAll.Message : "Invalid Key Combinations", 0, fileType.StgMonthTable);
                //Utils.DelProcessLog(SeqNbr, Master.curUser.EmployeeID);
            }
            ShowContinueItems(false, Master.Message);
        } else {
            //jevans 12/27/2010 - it appears filltable must populate invalid lines
            String InvalidKeyFlds = Session["InvalidKeyFlds"].ToString();            
            int NbrAdded = Utils.AddToValidation(InvalidKeyFlds,
                fileType,
                Master.curUser.EmployeeID,
                int.Parse(hfRunStatusId.Value),
                ddlMonths.SelectedValue,
                ddlYears.SelectedValue,
                Master.curUser.CanPostToAnyPeriod,
                out message);

            if (message.Length > 0) {
                ShowContinueItems(false, HypMDUA.ERROR_MESSAGE);
                return;
            }

            Utils.LogEvent(Master.curUser.EmployeeID, "UserInputUpload", "User Added Key Combinations",
                string.Format("{0} new key combinations where added", NbrAdded), UserToolLogLevel.Audit);

            //  Check to see if someone else is running a process that we should be waiting for.
            int MyRunId = int.Parse(hfRunStatusId.Value);
            string TableName = string.Empty;

            try {
                //  If this is an adjustment and the user can post to any month or this is an outlook
                //  where everyone is supplied, use whatever month was entered on the record; otherwise,
                //  get the current month from the Current Month table.
                int month = -1;
                string Years = "2008";
                bool CheckPeriod = true;
                if ((fileType.IsAdjustment == true && Master.curUser.CanPostAdjToAnyPeriod == true) || fileType.IsOutlook == true || fileType.Is13Month == true)
                    CheckPeriod = false;

                if (CheckPeriod) {
                    int.TryParse(ddlMonths.SelectedValue, out month);
                    Years = ddlYears.SelectedValue;
                }

                DateTime dtNow = DateTime.Now;
                FinishProcessingData(fileType, MyRunId, month, Years, dtNow);
            } catch (Exception exAll) {
                Master.Message = exAll.Message;
                Utils.DeleteFile(hfFileName.Value, Master.curUser.EmployeeID);
                Utils.RunStatusComplete(int.Parse(hfRunStatusId.Value), "Error", exAll.Message.Length > 0 ? exAll.Message : "Invalid Key Combinations", 0, fileType.StageMonthTable);
                //Utils.DelProcessLog(SeqNbr, Master.curUser.EmployeeID);
            }
            ShowContinueItems(false, Master.Message);
        }        
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        ShowContinueItems(false);
    }

    /* no pagination
    protected void lbPageSize_SelectedIndexChanged(object sender, EventArgs e)
    {
        int ps;
        if (int.TryParse(lbPageSize.SelectedValue, out ps))
            gvResults.PageSize = ps;
        // go to first page
        gvResults.PageIndex = 0;
        ArrayList a = (ArrayList)Session["ArrayList"];
        int i = a == null ? 0 : a.Count;
        //jevans 7/14/2011 there is no pagination 
        //buildPageCount(i);
        litPopupMsg.Text = "";
    }

    protected void lbPageSelect_SelectedIndexChanged(object sender, EventArgs e)
    {
        ArrayList a = (ArrayList)Session["ArrayList"];
        gvResults.DataSource = a;
        gvResults.DataBind();
        // go to selected page
        int ps;
        if (int.TryParse(lbPageSelect.SelectedValue, out ps))
            gvResults.PageIndex = ps;
        int i = a == null ? 0 : a.Count;
        //jevans 7/14/2011 there is no pagination 
        // buildPageCount(i);
        litPopupMsg.Text = "";

    }

    protected void gvResults_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        int ps;
        if (int.TryParse(lbPageSize.SelectedValue, out ps))
            gvResults.PageSize = ps;
        if (e.NewPageIndex < 0)
            gvResults.PageIndex = 0;
        else if (e.NewPageIndex > gvResults.PageCount - 1)
            gvResults.PageIndex = gvResults.PageCount - 1;
        else
            gvResults.PageIndex = e.NewPageIndex;
    }

    protected void gvResults_PageIndexChanged(object sender, EventArgs e)
    {
        try
        {
            int ps;
            if (int.TryParse(lbPageSize.SelectedValue, out ps))
                gvResults.PageSize = ps;

            //Bind the DataGrid again with the Data Source 
            ArrayList a = (ArrayList)Session["ArrayList"];
            gvResults.DataSource = a;
            gvResults.DataBind();
            //jevans 7/14/2011 there is no pagination 
            //int i = a == null ? 0 : a.Count;
            //buildPageCount(i);

            if (gvResults.PageCount > 1)
            {
                ///* not sure this is needed?
                //            int start = (((gvResults.PageIndex + 1) * (gvResults.PageSize)) - ((gvResults.PageSize - 1)));
                //            int end = ((gvResults.PageIndex + 1) * (gvResults.PageSize));
                //            if (end > a.Count)
                //                end = a.Count;
                //            this.gvResults.AllowPaging = true;
                //        }
                //        else
                //        {
                //            this.gvResults.AllowPaging = false;
 
            }
            litPopupMsg.Text = "";
        }
        catch (Exception ex)
        {
            Utils.LogEvent(Master.curUser.EmployeeID, "gvResults_PageIndexChanged", "", ex, LogLevel.Error);
            Master.Message = HypMDUA.ERROR_MESSAGE;
        }

    }

    */
    
    protected void gvResults_Sorting(object sender, GridViewSortEventArgs e)
    {

        //Retrieve the table from the session object.
     
        ArrayList a = Session["ArrayList"] as ArrayList;

        if (a != null)
        {

            IComparer f = (IComparer)new FactComparer(e.SortExpression, SortOrderAlternate(e.SortExpression));
            a.Sort(f);
            //            gvResults.PageSize = int.Parse(lbPageSize.SelectedValue);
            // go to first page
            gvResults.DataSource = a;
            gvResults.DataBind();
            gvResults.PageIndex = 0;
            litPopupMsg.Text = "";
        }
    }

    public bool SortOrderAlternate(String currentSortExpression)
    {
        String previousSortExpression = (String)Session["SortExpression"];
        bool bReturn = false;
        if (previousSortExpression == null)
        {
            //first sort, set to default ASC
            currentSortExpression += " ASC";
        }
        else
        {

            if (previousSortExpression.StartsWith(currentSortExpression))
            {
                //same column re-sort, set to opposite order
                if (previousSortExpression.EndsWith("ASC"))
                {
                    currentSortExpression += " desc";
                    bReturn = true;
                }
                else
                    currentSortExpression += " ASC";
            }
            else
            {
                //new column sort, set to default ASC
                currentSortExpression += " ASC";
            }
        }

        Session.Remove("SortExpression");
        Session.Add("SortExpression", currentSortExpression);

        return bReturn;
    }

    #endregion

    #region validation routines

    /// <summary>
    /// The main function to process the file submitted
    /// </summary>
    /// <param name="filename"></param>
    protected void ProcessUploadFile(string filename, FileType fileType) {
        string errorMessage = string.Empty;
        string years = ddlYears.SelectedValue;
        string closePeriod;
        int runStatusId;
        int totalRecordsAdded = 0;
        int month = -1;
        bool statusIsGood = false;
        
        closePeriod = ddlYears.SelectedValue + ((ddlMonths.SelectedValue.Length == 1) ? "0" : string.Empty) + ddlMonths.SelectedValue;

        hfFileName.Value = filename;
        statusIsGood = GetNewRunStatusId(filename, fileType, closePeriod, out errorMessage, out runStatusId);
        hfRunStatusId.Value = runStatusId.ToString();
        try {
            if (statusIsGood && runStatusId > 0) {
                if (LoadFileIntoTable(filename, fileType, ref totalRecordsAdded) 
                    && ProcessForceValues(fileType)
                    && AutoMapData(fileType, month, years)
                    && MapCompanyField(fileType)
                    && ValidatePeriod(fileType, ref month, years)
                    && CheckForDuplicates(fileType)
                    && ValidateScenario(fileType)
                    && ValidateDimensionSource(fileType)
                    && ValidateCoaCor(fileType)
                    && ValidateDimensionFields(fileType)
                    && FinishProcessingData(fileType, runStatusId, month, years, DateTime.Now)) {
                } else {
                    if (!btnContinue.Visible)
                        DisplayPopUpMessage("The file must be resubmitted.");
                    if (Master.Message == string.Empty)
                        throw new Exception("An unhandled error occured during validation routines, and Master Message is empty. ");
                    Utils.RunStatusComplete(int.Parse(hfRunStatusId.Value), "Error", Master.Message, 0, fileType.StageMonthTable);
                }
            } else {
                Master.Message = errorMessage;
                Utils.RunStatusComplete(int.Parse(hfRunStatusId.Value), "Error", Master.Message, 0, fileType.StageMonthTable);
            }
        } catch (Exception ex) {
            Master.Message = ex.Message;
            //  We don't want to delete the file if there is no Message.  This means that the exception
            //  Is because there are some invalid keys, but the user can add them if they click ok.
            if (ex.Message.Length > 0)
                Utils.DeleteFile(filename, Master.curUser.EmployeeID);
            int i = 0;
            int.TryParse(hfRunStatusId.Value, out i);
            Utils.RunStatusComplete(i, "Error", ex.Message.Length > 0 ? ex.Message : "Invalid Key Combinations", 0, fileType.StageMonthTable);
            Utils.LogEvent(Master.curUser.EmployeeID, "UserInputUpload", "ProcessUploadFIle", ex, UserToolLogLevel.Error);
            btnDownload.Visible = false;
        }
    }

    /// <summary>
    /// New Routine for ProdOffer
    /// </summary>
    /// <param name="filename"></param>
    protected void ProcessExcelFile(string filename, FileType fileType) {
        string errorMessage = string.Empty;
        int runStatusId = 0;
        int totalRecordsAdded = 0;
        int rowsSkipped;
        ArrayList results;
        int rows;
        string message;
        StageProcessingStatus status = StageProcessingStatus.None;
        FactTable factTable = (FactTable)fileType.FactTableId;
        string fiscalPeriod = string.Format(ddlMonths.SelectedValue.Length == 1 ? "{0}0{1}" : "{0}{1}", ddlYears.SelectedValue, ddlMonths.SelectedValue);
        btnDownload.Visible = false;
        
        hfFileName.Value = filename;

        try
        {
            switch (Path.GetExtension(filename).ToLower())
            {
                case ".xls":
                case ".xlsx":
                    switch (factTable)
                    {
                        case FactTable.PlanningActuals:
                            totalRecordsAdded = PlanningActualsDatabaseAccess.LoadExcelToStage(filename, fileType, Master.curUser.UserId, true, out message, out runStatusId);
                            break;
                        case FactTable.ProductOfferUser:
                            totalRecordsAdded = ProductOfferDatabaseAccess.LoadProductOfferExcelToStage(filename, fileType, Master.curUser.UserId, true, out message, out runStatusId);
                            break;
                        case FactTable.EquipmentUser:
                            totalRecordsAdded = EquipmentDatabaseAccess.LoadExcelToStage(filename, fileType, Master.curUser.UserId, true, out message, out runStatusId);
                            break;
                        case FactTable.DevicePaymentLoan:
                            totalRecordsAdded = DevicePaymentLoanDatabaseAccess.LoadDPLoanExcelToStage(filename, fileType, Master.curUser.UserId, true, out message, out runStatusId);
                            break;
                        default: message = string.Empty; break;
                    }

                    switch (totalRecordsAdded)
                    {
                        case -2: Master.Message = HypMDUA.ERROR_MESSAGE; break; // Exception occurred
                        case -1: Master.Message = message; break; // Error occured during routine
                        case 0: Master.Message = "There were no rows found in the uploaded spreadsheet"; break;
                        default:
                            hfRunStatusId.Value = runStatusId.ToString();
                            //DisplayPopUpMessage("File has been staged [run_status_id:" + hfRunStatusId.Value + "]");

                            switch (factTable)
                            {
                                case FactTable.PlanningActuals:
                                    results = PlanningActualsDatabaseAccess.ProcessStagedData(runStatusId, fiscalPeriod, fileType, Master.curUser.EmployeeID, out status, out message, out rows, out rowsSkipped);
                                    break;
                                case FactTable.ProductOfferUser:
                                    results = ProductOfferDatabaseAccess.ProcessStagedData(runStatusId, fiscalPeriod, fileType, Master.curUser.EmployeeID, out status, out message, out rows, out rowsSkipped);
                                    break;
                                case FactTable.EquipmentUser:
                                    results = EquipmentDatabaseAccess.ProcessStagedData(runStatusId, fiscalPeriod, fileType, Master.curUser.EmployeeID, out status, out message, out rows, out rowsSkipped);
                                    break;
                                case FactTable.DevicePaymentLoan:
                                    results = DevicePaymentLoanDatabaseAccess.ProcessStagedData(runStatusId, fiscalPeriod, fileType, Master.curUser.EmployeeID, out status, out message, out rows, out rowsSkipped);
                                    break;
                                default:
                                    rows = 0;
                                    rowsSkipped = 0;
                                    results = new ArrayList();
                                    break;
                            }

                            switch (status)
                            {
                                case StageProcessingStatus.AdditionOfKeysRequired:
                                    Master.Message = "Key combinations missing for following items (clicking the continue button will add the keys and update the fact table):";
                                    ShowContinueItems(true);
                                    FillGrid(results, fileType, true, true, rowsSkipped);
                                    break;
                                case StageProcessingStatus.CriticalValidationsFailed:
                                    Master.Message = "Issues detected with input file, please refer to the messages in the grid for additional details";
                                    DisplayPopUpMessage("The file must be resubmitted.");
                                    FillGrid(results, fileType, true, true, rowsSkipped);
                                    break;
                                case StageProcessingStatus.LoadedToFact:
                                    Master.Message = string.Format("{0} item(s) were added or modified.", rows);
                                    btnDownload.Visible = true;
                                    FillGrid(results, fileType, false, false, rowsSkipped);
                                    Utils.LogEvent(Master.curUser.EmployeeID, "UserInputUpload", "Uploaded User File " + fileType.FileTypeCode, string.Format("{0} item(s) were added or modified.", rows), UserToolLogLevel.Audit);
                                    break;
                            }

                            break;
                    }

                    break;
                default:
                    Master.Message = "Invalid file format.  The upload file must end in .XLS or .XLSX";
                    break;
            }
             
        } catch (Exception ex) {
            Master.Message = ex.Message;
            //  We don't want to delete the file if there is no Message.  This means that the exception
            //  Is because there are some invalid keys, but the user can add them if they click ok.
            if (ex.Message.Length > 0)
                Utils.DeleteFile(filename, Master.curUser.EmployeeID);
            int i = 0;
            int.TryParse(hfRunStatusId.Value, out i);
            Utils.RunStatusComplete(i, "Error", ex.Message.Length > 0 ? ex.Message : "Invalid Key Combinations", 0, fileType.StageMonthTable);
            Utils.LogEvent(Master.curUser.EmployeeID, "UserInputUpload", "ProcessUploadFIle", ex, UserToolLogLevel.Error);
            btnDownload.Visible = false;
        }
    }



    /// <summary>
    /// Loads the file into the table and performs some tests
    /// </summary>
    /// <returns>Status  - true/false</returns>
    private bool LoadFileIntoTable(string filename, FileType fileType, ref int totalRecordsAdded) {
        bool status = false;
        string message = "";
        // jevans 11/22/2010 - add 2007 extension 
        string path = Path.GetExtension(filename).ToLower();
        if (path.Equals(".xls") || path.Equals(".xlsx")) {
            totalRecordsAdded = Utils.LoadExcelToStage(filename, fileType, DateTime.Now, Master.curUser.UserId, true, out message);
        } else {
            Master.Message = "Invalid file format.  The upload file must end in .XLS or .XLSX";
            return false;
        }

        //  If -2 was returned from the Load data routine, there was an EXCEPTION error, probably in the OraWriter object 
        if (totalRecordsAdded == -2) {
            Master.Message = HypMDUA.ERROR_MESSAGE;
            status = false;
        }
        //  If -1 was returned from the Load data routine, there was a USER error and the routine set the error message.
        else if (totalRecordsAdded == -1) {
            Master.Message = message;
            status = false;
        } else if (totalRecordsAdded == 0) {
            Master.Message = "There were no rows found in the uploaded spreadsheet";
            status = false;
        } else {
            status = true;
        }
        return status;
    }

    /// <summary>
    /// All Data Manipulation and Validation routines will throw errors if there is an 
    ///  issue, so we don't need to check return codes from any of the routines.
    ///  Check to see if there are any field that have forced values.
    /// </summary>
    /// <param name="fileType"></param>
    /// <param name="TableName"></param>
    /// <returns>Status  - true/false</returns>
    private bool ProcessForceValues(FileType fileType) {
        //  All Data Manipulation and Validation routines will throw errors if there is an 
        //  issue, so we don't need to check return codes from any of the routines.
        //  Check to see if there are any field that have forced values.
        bool status = false;
        Utils.LogMessage("Processing Forced Values", "", null, int.Parse(hfRunStatusId.Value));

        string message = Utils.ProcessForcedValues(fileType);
        if (message.Length > 0) {
            Master.Message = HypMDUA.ERROR_MESSAGE;
        } else {
            status = true;
        }
        return status;
    }

    /// <summary>
    /// Automap the Data
    /// </summary>
    /// <param name="fileType"></param>
    /// <param name="TableName"></param>
    /// <returns>Status  - true/false</returns>
    private bool AutoMapData(FileType fileType,  int month, string year) {
        bool status = false;
        Utils.LogMessage("Validating all data was Auto mapped", "", null, int.Parse(hfRunStatusId.Value));
        string message = "";
        int skippedRows = 0;
        // jevans - 24735 - automap now requires current period
        string fiscal_period = string.Format(ddlMonths.SelectedValue.Length == 1 ? "{0}0{1}" : "{0}{1}", ddlYears.SelectedValue, ddlMonths.SelectedValue);
        ArrayList a = Utils.ProcessAutomappedData(fileType, int.Parse(hfRunStatusId.Value), fiscal_period, out message, out skippedRows);
        if (a == null || a.Count > 0) {
            Master.Message = HypMDUA.ERROR_MESSAGE;
            if (a != null && a.Count > 0) {
                foreach (FactValidDTO f in a) {
                    f.Message = AutomapFailedErrors(f, fileType);
                }// end for each 

                gvResults.Columns[1].HeaderText = "Line";
                Master.Message = "There was an error automapping the displayed items.";
                FillGrid(a, fileType, true, true, skippedRows);
            }
        } else {
            status = true;
        }
        return status;
    }

    /// <summary>
    /// Call the routine that maps the company field.
    /// </summary>
    /// <param name="fileType"></param>
    /// <param name="TableName"></param>
    /// <returns>Status  - true/false</returns>
    private bool MapCompanyField(FileType fileType) {
        bool status = false;
        if (Utils.CallCompanyLookup(fileType, Master.curUser.EmployeeID) == -1) {
            Master.Message = "The Company Field could not be mapped successfully.  Check the file's Entity values";
        } else {
            status = true; 
        }
        return status;
    }

    /// <summary>
    /// validate period based on isOutlook Flag
    /// </summary>
    /// <param name="fileType"></param>
    /// <param name="Msg"></param> 
    /// <param name="TableName"></param>
    /// <param name="a"></param>
    private bool ValidatePeriod(FileType fileType, ref int month, string years) {
        bool status = false;
        bool checkPeriod = true;
        try {
            int.TryParse(ddlMonths.SelectedValue, out month);


            
            // jevans 24735 4/4/2012 - do not check period of EQUIPMENT fact if user CanPostToAnyPeriod
            if ((fileType.IsAdjustment && Master.curUser.CanPostAdjToAnyPeriod)
                || (Master.curUser.CanPostToAnyPeriod && fileType.FactTableId== (int)FactTable.EquipmentUser)
                || fileType.IsOutlook || fileType.Is13Month) {

                checkPeriod = false;
                month = -1;
            }

            if (fileType.Is13Month) {
                if (Utils.IsYearValid(fileType, Convert.ToInt32(years), int.Parse(hfRunStatusId.Value))) {
                    status = true;
                } else {
                    Master.Message = "The Excel spreadsheet contains records with a different year than the selected year.";
                }
            } else {
                int skippedRows = 0;
                ArrayList a = null;
                a = Utils.ValidatePeriod(fileType, checkPeriod, month, years, int.Parse(hfRunStatusId.Value), out skippedRows);

                if (a == null || a.Count > 0) {
                    Master.Message = HypMDUA.ERROR_MESSAGE;
                    if (a != null && a.Count > 0) {
                        foreach (FactValidDTO f in a) {
                            f.Message = CheckCurrentPeriod(f);
                        } 
                        Master.Message = "There was an error with the Period of the displayed items.";
                        FillGrid(a, fileType, true, false, skippedRows);
                        DisplayPopUpMessage("The file must be resubmitted.");
                    }
                } else {
                    status = true;
                }
            }
        } catch (Exception ex) {
            Master.Message = HypMDUA.ERROR_MESSAGE;
            Utils.LogEvent(Master.curUser.EmployeeID, "UserInputUpload.aspx", "ValidatePeriod", ex, UserToolLogLevel.Error);
        }

        return status;
    }

    /// <summary>
    /// Check for any duplicate records in the file
    /// </summary>
    /// <param name="fileType"></param>
    /// <returns>Status  - true/false</returns>
    private bool CheckForDuplicates(FileType fileType) {
        bool status = false;
        int skippedRows = 0;
        ArrayList a = Utils.ValidateDuplicateRows(fileType, int.Parse(hfRunStatusId.Value), out skippedRows);
        if (a == null) {
            status = false;
            Master.Message = HypMDUA.ERROR_MESSAGE;
        } else {
            if (a.Count > 0) {
                gvResults.Columns[1].HeaderText = "Dup Count";
                Master.Message = "There are duplicate rows in the file.  The first column shows how many times the combination repeats.";
                FillGrid(a, fileType, true, true, skippedRows);
            } else {
                status = true;
            }
        }
        return status;
    }

    /// <summary>
    /// validate scenarios for outlook and adjustment file types
    /// </summary>
    /// <param name="hft"></param>
    /// <returns></returns>
    private bool ValidateScenario(FileType hft) {
        bool status = false;
        try  {
            //  If this is an Outlook file type, make sure all scenarios are the same.
            if (hft.IsOutlook) {
                status = Utils.ValidateSingleScenario(hft, int.Parse(hfRunStatusId.Value));
                if (!status) {
                    Master.Message = "The Outlook File has more than one Scenario defined in the file.";
                }
                // STOP PROCESSING
                return status;
            } // end of if outlook 
          
            int skippedRows = 0;
            ArrayList a = Utils.ValidateAdjustmentScenarios(hft, int.Parse(hfRunStatusId.Value), out skippedRows);
            if (a == null) {
                Master.Message = HypMDUA.ERROR_MESSAGE;
            } else {
                if (a.Count == 0) {
                    status = true;
                } else {
                    string validAdjustmentScenarios = ConfigurationManager.AppSettings["ValidAdjScenarios"];
                    int Last = validAdjustmentScenarios.LastIndexOf('|');
                    if (Last > 0) {
                        validAdjustmentScenarios = validAdjustmentScenarios.Substring(0, Last) + " or " +
                            validAdjustmentScenarios.Substring(Last + 1);
                    }
                    validAdjustmentScenarios = validAdjustmentScenarios.Replace("|", ", ");

                    gvResults.Columns[1].HeaderText = "Line";
                    Master.Message = string.Format("The file has Scenarios that are {0}adjustment scenarios {1}",
                       (hft.IsAdjustment ? "not " : ""), validAdjustmentScenarios);
                    FillGrid(a, hft, true, true, skippedRows);
                    DisplayPopUpMessage("The file must be resubmitted.");
                    status = false;
                } // end of if count 
            } // end of if array is not null
        } catch (Exception ex) {
            Master.Message = HypMDUA.ERROR_MESSAGE;
            Utils.LogEvent(Master.curUser.EmployeeID, "UserInputUpload.aspx", "ValidateScenario", ex, UserToolLogLevel.Error);
        }
        return status;
    }

    /// <summary>
    ///  Check to see if any records to be added already exist in the fact table, but under a different source.
    /// </summary>
    /// <param name="fileType"></param>
    /// <param name="scenario"></param>
    /// <returns></returns>
    private bool ValidateDimensionSource(FileType fileType)
    {
        bool status = false;
        int skippedRows;
        ArrayList a = Utils.ValidateDimensionSource(fileType, int.Parse(hfRunStatusId.Value), out skippedRows);
        if (a == null) {
            Master.Message = HypMDUA.ERROR_MESSAGE;
        } else if (a.Count > 0) {
            foreach (FactValidDTO f in a) {
                f.Message = DisplayAlternateSourceError(f);
            }

            Master.Message = "The following records exist in the fact table under a different File Type.  Check individual lines for more information.";
            FillGrid(a, fileType, true, true, skippedRows);
        } else {
            status = true;
        }
        return status;
    }

    /// <summary>
    ///  If COA/COR is disabled, don't allow the records to be loaded.
    /// </summary>
    /// <param name="fileType"></param>
    /// <returns></returns>
    private bool ValidateCoaCor(FileType fileType) {
        bool status = false;
        
        if (settings.CoaCorEnabled 
            || fileType.FactTable == FactTable.EquipmentUser 
            || fileType.FactTable == FactTable.DataWarehouseUser
            || fileType.FactTable == FactTable.ProductOfferUser
            || fileType.FactTable == FactTable.PlanningActuals
            || fileType.FactTable == FactTable.DevicePaymentLoan)
        {
            status = true;
        } else {
            int skippedRows = 0;
            ArrayList a = Utils.ValidateCoaCor(fileType, int.Parse(hfRunStatusId.Value), out skippedRows);
            if (a == null) {
                Master.Message = HypMDUA.ERROR_MESSAGE;
            } else if (a.Count == 0) {
                status = true;
            } else {
                foreach (FactValidDTO f in a) {
                    f.Message = "Reporting Line is COA/COR";
                }
                gvResults.Columns[1].HeaderText = "Line";
                Master.Message = "COA/COR accounts are disabled and the file contains COA/COR Reporting Lines.";
                FillGrid(a, fileType, true, true, skippedRows);
            }
        } // end of else disabled 
        return status;
    }

    /// <summary>
    /// compare uploaded dimensions to master-dim and/or valid key combos
    /// </summary>
    /// <param name="Cnt"></param>
    /// <param name="fileType"></param>
    /// <param name="TableName"></param>
    /// <returns>Status  - true/false</returns>
    private bool ValidateDimensionFields( FileType fileType) {
        //  If they don't define valid key combinations, validate the fields against the outlines.
        string message = string.Empty;
        bool status = false;
        int skippedRows = 0;
        ArrayList a = Utils.ValidateDimensionFields(fileType, 0, out message, out skippedRows);
        if (a == null) {
            Master.Message = HypMDUA.ERROR_MESSAGE;
        } else {
            if (a.Count == 0) {
                status = true;
            } else {
                Master.Message = string.Format("There are Invalid Key{0} in the User Feed.  Check individual lines for more information.",
                    fileType.UsesValidKeyCombos ? " Combinations" : "s");
                // set message Delegate based on file type ValidKey flag
                DetermineMsgText validKeysHandler = null;
                InvalidKeyFlds = "";
                if (fileType.UsesValidKeyCombos) {
                    validKeysHandler = CheckMissingKeys;
                } else {
                    validKeysHandler = CheckNotFoundFields;
                }
                // fill table with ValidateDimensionFields results 
                foreach (FactValidDTO f in a) {
                    f.Message = validKeysHandler(f);
                }
                gvResults.Columns[1].HeaderText = "Line";
                if (fileType.UsesValidKeyCombos) {
                    if (InvalidKeyFlds.Length > 1) {
                        InvalidKeyFlds = InvalidKeyFlds.Substring(1);
                    }
                    string[] invKeys = InvalidKeyFlds.Split(',');
                    //  If there are invalid keys and all the invalid keys aren't defined in other file types, check
                    //  to see if they are user definable.  If they are, ask the user if they would like to 
                    //  just add the keys instead.
                    if (a.Count == invKeys.Length) {
                        //hfLineNbrs.Value = InvalidKeyFlds;
                        // jevans 7/5/2012 - check array length because >1k causes error
                        if (invKeys.Length > 1000) {
                            Master.Message = "There are more than 1000 user-defined keys that must be added, but that will cause an error.  Please upload to the Valid Key page first.";
                            return false;
                        }
                        // jevans 10/24/2011 - refactor to return boolean in case of program error in method
                        if (!Utils.CheckUserDefinedFlds(fileType, InvalidKeyFlds, out message)) {
                            Master.Message = HypMDUA.ERROR_MESSAGE;
                            return false;
                        } else {
                            if (message.Length > 0) {
                                //Master.Message = "There are Invalid Field Values or Key Combinations in the User Feed. ";
                                // jevans 1/6/2011 - 'Check User Fields' found an error so STOP PROCESSING
                                Master.Message = message;
                            } else {
                                // jevans 1/20/2011 - never show continue button, this function has been removed 
                                // jevans 5/4/2011 - show continue button, this function was actually required for user-defined fields
                                ShowContinueItems(true, message);
                                // jevans 12/27/2010 save keys for continue button 
                                Session["InvalidKeyFlds"] = InvalidKeyFlds;
                            }
                        }
                    } else {
                        // invalid keys 
                        Master.Message = "There are Invalid Field Values or Key Combinations in the User Feed.  Check individual lines for more information.";
                    } //  
                }// end of UsesValidKeyCombos
                FillGrid(a, fileType, true, true, skippedRows);
            } // end of valid dimensions a.Count > 0 
        }
        return status;
    }

    /// <summary>
    /// Function gets the new Run ID and also checks if the file can be locked for use.
    /// If the file can not be locked or there is an active lock then the fn displays an error message.
    /// </summary>
    /// <param name="filename"></param>
    /// <param name="fileType"></param>
    /// <param name="closePeriod"></param>
    /// <param name="errorMessage"></param>
    /// <param name="runStatusId"></param>
    private bool GetNewRunStatusId(string filename, FileType fileType, string closePeriod, out string errorMessage, out int runStatusId) {
        bool status = false;
        runStatusId = -1;
        runStatusId = Utils.LockFileType(fileType.FileTypeCode, closePeriod, Master.curUser.UserId, Master.curUser.EmployeeID, out errorMessage);
        
        if (runStatusId < 0) {
            Master.Message = errorMessage;
            Utils.DeleteFile(filename, Master.curUser.EmployeeID);
            DisplayPopUpMessage("The file must be resubmitted.");
        } else {
            hfRunStatusId.Value = runStatusId.ToString();
            //  Now Log all the specific information about this file type so that it can be used if we need to trouble shoot anything.
            string logMessage = string.Format("Loading {0}: is_adjustment={1}, is_13month={2}, is_outlook={3}, is_user_feed={4}, uses_valid_keys={5}, fact_table_id={6}, dest_table={7}"
                , fileType.FileTypeCode, fileType.IsAdjustment, fileType.Is13Month, fileType.IsOutlook, fileType.IsUserFeed, fileType.UsesValidKeyCombos, fileType.FactTableId, fileType.DestinationTable);
            //Utils.LogMessage(LogMsg, null, null, myRunId);

            logMessage = "";
            foreach (FileTypeField fields in fileType.fields) {
                if (logMessage.Length > 0) {
                    logMessage += ",  ";
                }
                logMessage += string.Format("MemberName: {0}, Source={1}, ForcedValue={2}", fields.FactColumnName, fields.Source, fields.ForcedValue);
            }
            //Utils.LogMessage(LogMsg, null, null, myRunId);
            status = true;
        }
        return status;
    }

    /// <summary>
    /// save uploaded records to fact table and display results 
    /// </summary>
    /// <returns>Status  - true/false</returns>
    protected bool FinishProcessingData(FileType fileType, int runStatusId, int month, string years, DateTime now) {
        bool status = false;
        try {
            btnDownload.Visible = false;
            //  Call the stored procedure to process the added items.
            int rowsUpdated = 0;
            string message = "";
            Utils.LogMessage("Copy data to fact table",  null, null, runStatusId);

            if (fileType.Is13Month || fileType.IsOutlook) {
                status = true;

                if (fileType.IsAdjustment) {
                    if (Utils.UnpivotFrom13Month(fileType, out message) > 0) {
                        int recordCount = Utils.CallProcessDelta(month, years, fileType, Master.curUser.EmployeeID);
                        if (recordCount == -1) {
                            Master.Message = HypMDUA.ERROR_MESSAGE;
                            status = false;
                        }
                        rowsUpdated += recordCount;
                    } else {
                        Master.Message = HypMDUA.ERROR_MESSAGE;
                        status = false;
                    }
                } else {
                    for (int m = 0; m <= 12; m++) {
                        if (Utils.UnpivotOneMonthFrom13Month(fileType, Convert.ToInt32(years), m, out message) > 0) {
                            int recordCount = Utils.CallProcessDelta(m, years, fileType, Master.curUser.EmployeeID);
                            if (recordCount == -1) {
                                Master.Message = HypMDUA.ERROR_MESSAGE;
                                status = false;
                                break;
                            }
                            rowsUpdated += recordCount;
                        } else {
                            Master.Message = HypMDUA.ERROR_MESSAGE;
                            status = false;
                            break;
                        }

                    }// end of for each month
                }
                
            } else {
                rowsUpdated = Utils.CallProcessDelta(month, years, fileType, Master.curUser.EmployeeID);
                if (rowsUpdated == -1) {
                    Master.Message = HypMDUA.ERROR_MESSAGE;
                } else {
                    status = true;
                }
            }
            if (status) {
                int skippedRows = 0;
                // jevans 2/22/2012 - refactor to pass update count and restrict rows returned
                ArrayList a = Utils.GetLoadedRecords(fileType, month, years, rowsUpdated, out skippedRows);
                Master.Message = string.Format("{0} item(s) were added or modified.", rowsUpdated);
                // delete the uploaded data
                Utils.DelUserStgData(fileType, now, Master.curUser.EmployeeID);
                // log success 
                Utils.LogEvent(Master.curUser.EmployeeID, "UserInputUpload", "Uploaded User File " + fileType.FileTypeCode
                    , string.Format("{0} item(s) were added or modified.", rowsUpdated), UserToolLogLevel.Audit);
                // mark run as complete 
                Utils.RunStatusComplete(runStatusId, "Complete", string.Format("{0} item(s) were added or modified.", rowsUpdated), rowsUpdated, fileType.FileTypeCode);
                btnDownload.Visible = true;

                if (a == null || FillGrid(a, fileType, false, false, skippedRows) < 0) {
                    Master.Message += "The data was loaded successfully, and the log has been updated, but the display of records failed." + HypMDUA.ERROR_MESSAGE;
                }
            }
        } catch (Exception ex) {
            Utils.LogEvent(Master.curUser.EmployeeID, "UserInputUpload.aspx", "FinishProcessingData", ex, UserToolLogLevel.Error);
            status = false;
            Master.Message = HypMDUA.ERROR_MESSAGE;

        }
        if (!status) {
            Master.Message += "  Process Failed";
        }
        return status;
    }

    #endregion

    #region error checking Delegates
    /// <summary>
    /// DetermineMsgText delegate
    /// </summary>
    /// <param name="a"></param>
    /// <returns>string - error message</returns>
    public string AutomapFailedErrors(FactValidDTO f, FileType fileType) {
        string message = string.Empty;
        switch ((FactTable)fileType.FactTableId) {
            case FactTable.DataWarehouseUser:
                if (f.ReportingLine == string.Empty) message += " Reporting Line, ";
                if (f.Product == string.Empty) message += " Product, ";
                if (f.SubAccount == string.Empty) message += " SubAccount, ";
                if (f.ServiceType == string.Empty) message += " Service Type,";
                if (f.Function == string.Empty) message += " Function,";
                if (f.Branch == string.Empty) message += " Branch,";
                if (f.OwningGeo == string.Empty) message += " Owning Geo,";
                if (f.OwningMgr == string.Empty) message += " Owning Mgr,";
                if (f.Vertical == string.Empty) message += " Vertical,";
                break;
            case FactTable.EquipmentUser:
                if (f.ReportingLine == string.Empty) message += " Reporting Line, ";
                if (f.Product == string.Empty) message += " Product, ";
                if (f.SubAccount == string.Empty) message += " SubAccount, ";
                if (f.ServiceType == string.Empty) message += " Service Type,";
                if (f.Function == string.Empty) message += " Function,";
                if (f.CostCenter == string.Empty) message += " Cost Center,";
                break;
            case FactTable.LocationUser:
                if (f.ReportingLine == string.Empty) message += " Reporting Line, ";
                if (f.Product == string.Empty) message += " Product, ";
                if (f.SubAccount == string.Empty) message += " SubAccount, ";
                if (f.ServiceType == string.Empty) message += " Service Type,";
                if (f.Function == string.Empty) message += " Function,";
                if (f.CostCenter == string.Empty) message += " Cost Center,";
                if (f.StoreStatus == string.Empty) message += " Store Status,";
                if (f.DesignType == string.Empty) message += " Design Type,";
                if (f.LocationType == string.Empty) message += " Location Type,";
                if (f.LocationSubtype == string.Empty) message += " Location Subtype,";
                if (f.LocationTierCode == string.Empty) message += " Location Tier Code,";
                break;
            default:
                if (f.ReportingLine == string.Empty) message += " Reporting Line, ";
                if (f.Product == string.Empty) message += " Product, ";
                if (f.SubAccount == string.Empty) message += " SubAccount, ";
                if (f.ServiceType == string.Empty) message += " Service Type,";
                if (f.Function == string.Empty) message += " Function,";
                break;
        }
        if (message.Length > 0) {
            message = "The following did not auto map successfully: " + message.TrimEnd(',');
        }
        return message;
    }

    /// <summary>
    /// delegate DetermineMsgText
    /// </summary>
    /// <param name="a"></param>
    /// <returns>string - error message</returns>
    public string CheckCurrentPeriod(FactValidDTO f) {
        if (f.FactDate != DateTime.MinValue) {
            if (
                (f.FactDate.Month != int.Parse(ddlMonths.SelectedValue) || f.FactDate.Year != int.Parse(ddlYears.SelectedValue))
                 && !Master.curUser.CanPostToAnyPeriod
                )
                return string.Format("The fact date {0} is not valid for Month/Year Selection above.", f.FactDate.ToString("MM/dd/yyyy"));
        } else {
            int month = 0;
            if (!int.TryParse(f.Month, out month)) {
                return "The month is not a valid month value.  It must be a value in the range of 0 to 12.";
            }
            if (month < 0 || month > 12) {
                return "The month is not a valid month value.  It must be a value in the range of 0 to 12.";
            } else {
                if (f.Month != ddlMonths.SelectedValue || f.Year != ddlYears.SelectedValue) {
                    return string.Format("The period {0}/{1} is not valid for Month/Year Selection above.", f.Month, f.Year);
                }
            }
        }
        //  Check the field that validates year against the outline.  If the outline year is null, 
        //  then they have an invalid Year.
        if (f.YearValid == string.Empty) {
            return "The year is not a valid year.  It must be a defined year in the Years outline.";
        }
        // this should never happen! 
        return "Either Month or Year was in an invalid format";
    }

    /// <summary>
    /// delegate DetermineMsgText
    /// </summary>
    /// <param name="a"></param>
    /// <returns>string - error message</returns>
    private string CheckNotFoundFields(FactValidDTO f) {
        string message = string.Empty;
        
        switch ((FactTable)int.Parse(f.TableName))
        {
            case FactTable.LocationUser:
                if (f.ReportLineValid == string.Empty) message = "Reporting Line,";
                if (f.AccountValid == string.Empty) message +=  " Account,";
                if (f.ViewValid == string.Empty) message += " View,";
                if (f.YearValid == string.Empty) message += " Year,";
                if (f.ScenarioValid == string.Empty) message += " Scenario,";
                if (f.ProductValid == string.Empty) message += " Product,";
                if (f.SubAcctValid == string.Empty) message += " SubAccount,";
                if (f.ServiceValid == string.Empty) message += " Service Type,";
                if (f.FunctionValid == string.Empty) message += " Function,";
                if (f.KPIValid == string.Empty) message += " KPI,";
                if (f.CostCenterValid == string.Empty) message += " Cost Center,";
                if (f.EntityValid == string.Empty) message += " Location,";
                if (f.EquipmentValid == string.Empty) message += " Equipment,";
                if (f.TechTypeValid == string.Empty) message += " TechType,";
                if (f.StoreStatusValid == string.Empty) message += " Store Status,";
                if (f.DesignTypeValid == string.Empty) message += " Design Type,";
                if (f.LocationTypeValid == string.Empty) message += " Location Type,";
                if (f.LocationSubtypeValid == string.Empty) message += " Location Subtype,";
                if (f.LocationTierCodeValid == string.Empty) message += " Loc Tier Code,";
                break;
            case FactTable.EquipmentUser:
                if (f.ReportLineValid == string.Empty) message = "Reporting Line,";
                if (f.ViewValid == string.Empty) message += " View,";
                if (f.YearValid == string.Empty) message += " Year,";
                if (f.ScenarioValid == string.Empty) message += " Scenario,";
                if (f.ServiceValid == string.Empty) message += " Service Type,";
                if (f.FunctionValid == string.Empty) message += " Function,";
                if (f.KPIValid == string.Empty) message += " KPI,";
                if (f.CostCenterValid == string.Empty) message += " Cost Center,";
                if (f.EntityValid == string.Empty) message += " Entity,";
                if (f.EquipmentValid == string.Empty) message += " Equipment,";
                if (f.TechTypeValid == string.Empty) message += " TechType,";
                if (f.MethodTypeValid == string.Empty) message += " Methodology Type,";
                if (f.SaleTypeValid == string.Empty) message += " Sale Type,";
                if (f.DiscountTypeValid == string.Empty) message += " Discount Type,";
                if (f.ContractTermValid == string.Empty) message += " Contract Term,";
                break;
            case FactTable.DataWarehouseUser:
                if (f.ReportLineValid == string.Empty) message = "Reporting Line,";
                if (f.AccountValid == string.Empty) message +=  "Cust Account,";
                if (f.ViewValid == string.Empty) message += " View,";
                if (f.YearValid == string.Empty) message += " Year,";
                if (f.ScenarioValid == string.Empty) message += " Scenario,";
                if (f.ProductValid == string.Empty) message += " Product,";
                if (f.SubAcctValid == string.Empty) message += " SubAccount,";
                if (f.ServiceValid == string.Empty) message += " Service Type,";
                if (f.FunctionValid == string.Empty) message += " Function,";
                if (f.KPIValid == string.Empty) message += " KPI,";
                if (f.EntityValid == string.Empty) message += " Entity,";
                if (f.EquipmentValid == string.Empty) message += " Equipment,";
                if (f.PreviousTypeValid == string.Empty) message += " Previous Type,";
                if (f.TechTypeValid == string.Empty) message += " TechType,";
                if (f.BranchValid == string.Empty) message += " Branch,";
                if (f.ConnTypeValid == string.Empty) message += " Connection Type,";
                if (f.OwningGeoValid == string.Empty) message += " Owning Geo,";
                if (f.OwningMgrValid == string.Empty) message += " Owning Mgr,";
                if (f.SegmentValid == string.Empty) message += " Segment,";
                if (f.VerticalValid == string.Empty) message += " Vertical,";
                if (f.VersionValid == string.Empty) message += " Version,";
                if (f.ContractTermValid == string.Empty) message += " Contract Term,";
                if (f.ProgramEligibleValid == string.Empty) message += " Program Eligible,";
                break;
            default:
                if (f.ReportLineValid == string.Empty) message = "Reporting Line,";
                if (f.AccountValid == string.Empty) message +=  " Account,";
                if (f.ViewValid == string.Empty) message += " View,";
                if (f.YearValid == string.Empty) message += " Year,";
                if (f.ScenarioValid == string.Empty) message += " Scenario,";
                if (f.ProductValid == string.Empty) message += " Product,";
                if (f.SubAcctValid == string.Empty) message += " SubAccount,";
                if (f.ServiceValid == string.Empty) message += " Service Type,";
                if (f.FunctionValid == string.Empty) message += " Function,";
                if (f.KPIValid == string.Empty) message += " KPI,";
                if (f.CostCenterValid == string.Empty) message += " Cost Center,";
                if (f.EntityValid == string.Empty) message += " Entity,";
                if (f.CompanyValid == string.Empty) message += " Company,";
                if (f.EquipmentValid == string.Empty) message += " Equipment,";
                if (f.TechTypeValid == string.Empty) message += " TechType,";
                break;
        } 
        
        if (message.Length > 0)
            message = "The following are invalid: " + message.TrimEnd(',');
        return message;
    }

    /// <summary>
    /// delegate DetermineMsgText
    /// </summary>
    /// <param name="a"></param>
    /// <returns>string - error message</returns>
    private string CheckMissingKeys(FactValidDTO f)
    {
        if (f.Source == string.Empty) {
            InvalidKeyFlds += string.Format(",{0}", f.Line);
            return "This line does not have a valid key combination.";
        } else {
            return string.Format("This key combination is defined for the file type of '{0}'", f.Source);
        }
    }

    /// <summary>
    /// delegate DetermineMsgText
    /// </summary>
    /// <param name="f">Fact Data Transport Object</param>
    /// <returns>string - error message</returns>
    private string DisplayAlternateSourceError(FactDTO f)
    {
        return string.Format("This record exists in the '{0}' File Type",
            f.Source);
    }
    #endregion

    #region format routines

    // jevans 5/20/2011 FillGrid replaces FillTable for pagination project

    private int FillGrid(ArrayList a, FileType fileType, bool showErrorColumn, bool showLineNumber, int skippedLines)
    {
        int c = -1;
        try {
         
            // save array in session for page/sort 
            Session["ArrayList"] = a;
            gvResults.Visible = true;

            switch (fileType.FactTable) {
                case FactTable.PlanningActuals:
                    foreach (DataControlField column in gvResults.Columns) {
                        switch (column.HeaderText) {
                            case "Account":
                            case "Cust Account":
                                column.Visible = true;
                                column.HeaderText = "Account";
                                break;
                            case "GL Account":
                            case "Product":
                            case "Contract Term":
                            case "Tech Type":
                            case "Region":
                            case "ServiceType":
                            case "Scenario":
                            case "Function":
                            case "External Segment":
                            case "Business Segment":
                            case "Line of Business":
                            case "Planned Entity":
                            case "Run Status Id":
                                column.Visible = true;
                                break;
                            case "Fiscal Period":
                            case "Amount":
                                column.Visible = !fileType.Is13Month;
                                break;
                            case "Year":
                            //case "Beg Bal":
                            case "Jan":
                            case "Feb":
                            case "Mar":
                            case "Apr":
                            case "May":
                            case "Jun":
                            case "Jul":
                            case "Aug":
                            case "Sep":
                            case "Oct":
                            case "Nov":
                            case "Dec":
                                column.Visible = fileType.Is13Month;
                                break;
                            default:
                                column.Visible = false;
                                break;
                        }
                    }
                    break;

                case FactTable.ProductOfferUser:
                    foreach (DataControlField column in gvResults.Columns) {
                        switch (column.HeaderText) {
                            case "Account":
                            case "Cust Account":
                                column.Visible = true;
                                column.HeaderText = "Account";
                                break;
                            case "Entity":
                            case "Location":
                                column.HeaderText = "Entity";
                                break;
                            case "Product":
                            case "Cost Center":
                            case "Contract Term":
                            case "Connection Type":
                            case "Segment":
                            case "ReportingLine":
                            case "Rptng Line":
                            case "Equipment":
                            case "ServiceType":
                            case "Srv Type":
                            case "Scenario":
                            case "Function":
                            case "Organization":
                            case "Org Chart":
                            case "Account Size":
                            case "HRHV":
                            case "Ethnicity":
                            case "Run Status Id":
                                column.Visible = true;
                                break;
                            case "Fact Date":
                            case "Amount":
                                column.Visible = !fileType.Is13Month;
                                break;
                            case "Year":
                            //case "Beg Bal":
                            case "Jan":
                            case "Feb":
                            case "Mar":
                            case "Apr":
                            case "May":
                            case "Jun":
                            case "Jul":
                            case "Aug":
                            case "Sep":
                            case "Oct":
                            case "Nov":
                            case "Dec":
                                column.Visible = fileType.Is13Month;
                                break;
                            default:
                                column.Visible = false;
                                break;
                        }
                    }
                    break;
                case FactTable.EquipmentUser:
                    foreach (DataControlField column in gvResults.Columns) {
                        switch (column.HeaderText) {
                            case "Account":
                            case "Cust Account":
                                column.Visible = false;
                                break;
                            case "Entity":
                            case "Location":
                                column.HeaderText = "Entity";
                                column.Visible = true;
                                break;
                            case "ReportingLine":
                            case "Rptng Line":
                            case "Cost Center":                            
                            case "Methodology Type":
                            case "Sale Type":
                            case "Discount Type":
                            case "Contract Term":
                            case "KPI":
                            case "View":                            
                            case "Equipment":
                            case "ServiceType":
                            case "Service Type":
                            case "Srv Type":
                            case "Scenario":
                            case "Function":
                            case "Tech Type":
                            case "Run Status Id":
                                column.Visible = true;
                                break;
                            case "Fact Date":
                            case "Amount":
                                column.Visible = !fileType.Is13Month;
                                break;
                            case "Year":
                            //case "Beg Bal":
                            case "Jan":
                            case "Feb":
                            case "Mar":
                            case "Apr":
                            case "May":
                            case "Jun":
                            case "Jul":
                            case "Aug":
                            case "Sep":
                            case "Oct":
                            case "Nov":
                            case "Dec":
                                column.Visible = fileType.Is13Month;
                                break;
                            default:
                                column.Visible = false;
                                break;
                        }
                    }
                    break;
                case FactTable.DevicePaymentLoan:
                    foreach (DataControlField column in gvResults.Columns)
                    {
                        switch (column.HeaderText)
                        {
                            //case "Entity":
                            //    column.HeaderText = "Entities";
                            //    break;
                            case "Aging":
                            case "Collection Status":
                            case "Contract Term":
                            case "Credit Risk Type":
                            case "Entities":
                            case "Equipment":
                            case "Customer Tenure":
                            case "Deact Change Reason":
                            case "FICO":
                            case "Function":
                            case "Loan Tenure":
                            case "Loan Vintage":
                            case "First Payment Made":
                            case "Original Loan Equipment":
                            case "Reporting Line":
                            case "Rptng Line":
                            case "Scenario":
                            case "ServiceType":
                            case "Service Type":
                            case "Srv Type":
                            case "Tranche":
                            case "Upg Elig":
                            case "WriteOff Reason":
                            case "Bill System Customer Type":
                            case "Loan Status":
                            case "Treasury Tenure":
                            case "Run Status Id":
                                column.Visible = true;
                                break;
                            case "Fiscal Period":
                            case "Amount":
                                column.Visible = !fileType.Is13Month;
                                break;
                            case "Year":
                            //case "Beg Bal":
                            case "Jan":
                            case "Feb":
                            case "Mar":
                            case "Apr":
                            case "May":
                            case "Jun":
                            case "Jul":
                            case "Aug":
                            case "Sep":
                            case "Oct":
                            case "Nov":
                            case "Dec":
                                column.Visible = fileType.Is13Month;
                                break;
                            default:
                                column.Visible = false;
                                break;
                        }
                    }
                    break;
                default:
                    bool isLocation = fileType.FactTableId == (int)FactTable.LocationUser;
                    bool isEquipment = fileType.FactTableId == (int)FactTable.EquipmentUser;
                    bool isDataWarehouse = fileType.FactTableId == (int)FactTable.DataWarehouseUser;

                    foreach (DataControlField column in gvResults.Columns) {
                        switch (column.HeaderText) {
                            case "Account":
                            case "Cust Account":
                                column.Visible = !isEquipment;
                                column.HeaderText = isDataWarehouse ? "Cust Account" : "Account";
                                break;
                            case "Entity":
                            case "Location":
                                column.HeaderText = isLocation ? "Location" : "Entity";
                                break;
                            case "Product":
                            case "Sub Acct":
                                column.Visible = !isEquipment;
                                break;
                            case "Cost Center":
                                column.Visible = !isDataWarehouse;
                                break;
                            case "Company":
                                column.Visible = !isEquipment && !isDataWarehouse && !isLocation;
                                break;
                            case "Store Status":
                            case "Design Type":
                            case "Loc Type":
                            case "Loc Subtype":
                            case "Loc Tier Code":
                                column.Visible = isLocation;
                                break;
                            case "Methodology Type":
                            case "Sale Type":
                            case "Discount Type":
                            case "Fact Date":
                                column.Visible = isEquipment;
                                break;
                            case "Contract Term":
                                column.Visible = isEquipment || isDataWarehouse;
                                break;
                            case "Program Eligible":
                                column.Visible = isDataWarehouse;
                                break;
                            case "Month":
                                column.Visible = !isEquipment && !(fileType.IsOutlook || fileType.Is13Month);
                                break;
                            case "Year":
                                column.Visible = !isEquipment;
                                break;
                            case "Branch":
                            case "Connection Type":
                            case "Owning Geography":
                            case "Owning Manager":
                            case "Segment":
                            case "Version":
                            case "Vertical":
                            case "Previous Type":
                                column.Visible = isDataWarehouse;
                                break;
                            case "Beg Bal":
                            case "Jan":
                            case "Feb":
                            case "Mar":
                            case "Apr":
                            case "May":
                            case "Jun":
                            case "Jul":
                            case "Aug":
                            case "Sep":
                            case "Oct":
                            case "Nov":
                            case "Dec":
                                column.Visible = (fileType.IsOutlook || fileType.Is13Month) && !showErrorColumn;
                                break;
                            case "Fact":
                                column.Visible = !(fileType.IsOutlook || fileType.Is13Month) && !showErrorColumn;  // fact
                                break;
                            case "Organization":
                            case "Org Chart":
                            case "Account Size":
                            case "HRHV":
                            case "Ethnicity":
                            case "Run Status Id":
                            case "Amount":
                                column.Visible = false;
                                break;
                            case "GL Account":
                            case "Region":
                            case "External Segment":
                            case "Business Segment":
                            case "Line of Business":
                            case "Planned Entity":
                            case "Fiscal Period":
                            case "Aging":
                            case "Entities":
                            case "Customer Tenure":
                            case "Credit Risk Type":
                            case "Loan Tenure":
                            case "Loan Vintage":
                            case "Collection Status":
                            case "FICO":
                            case "Upg Elig":
                            case "Tranche":
                            case "Original Loan Equipment":
                            case "First Payment Made":
                            case "WriteOff Reason":
                            case "Deact Change Reason":
                            case "Bill System Customer Type":
                            case "Loan Status":
                            case "Treasury Tenure":
                                column.Visible = false;
                                break;
                            default:
                                column.Visible = true;
                                break;
                        }
                    }
                    break;
            }
                        
            
            gvResults.Columns[0].Visible = showErrorColumn;
            gvResults.Columns[1].Visible = showLineNumber;

            // bind grid to array 
            gvResults.DataSource = a;
            gvResults.DataBind();

            // there is currently no pagination
            c = a == null ? 0 : a.Count;
            // buildPageCount(c);

            // if we skipped any lines from being displayed, display a line with a count of how many items were skipped.
            if (skippedLines > 0) {
                litSkippedRows.Visible = true;
                litSkippedRows.Text = string.Format("{0} rows were skipped.", skippedLines);
            } else {
                litSkippedRows.Visible = false;
            }
        } catch (Exception ex) {
            Utils.LogEvent(Master.curUser.EmployeeID, "FillGrid", "", ex, UserToolLogLevel.Error);
            Master.Message = HypMDUA.ERROR_MESSAGE;
        }
        return c;
    }

    /*
    private int ShowLoadedRecords(ArrayList a, HypFileType hft, int Month, string Year, DateTime dtNow, string Scenario, int SkippedRows)
    {
        try
        {
            pnlGridHead.Visible = true;

            // cell index is zero based, so subtract one to point to cells correctly
            int Cnt = gvResults.Columns.Count - 1;
            //            for (int i = 0; i <= Cnt; i++)
            //           {
            //              tblErrs.Rows[0].Cells[i].Visible = true;
            //         }

            int iStart = 0, iStop = 0;
            if (hft.is13Month == false)
            {
                 // hide outlook columns
                iStart = Cnt - 14;
                iStop = Cnt - 2;
            }
            else
            {
                // hide regular fact columns 
                iStart = Cnt - 1;
                iStop = Cnt;
            }
            // hide selected columns 
            for (int i = iStart; i <= iStop; i++)
            {
                gvResults.Columns[i].Visible = false;

            }

            // hide line number 
            gvResults.Columns[1].Visible = false;
            // hide error message
            gvResults.Columns[0].Visible = false;
            //   tblErrs.Visible = true;

            // jevans 8/1/2011 - 24524 - added map on location code
            HypFileType hft = Utils.GetInputFile(ddlFileType.SelectedValue, Master.curUser.EmployeeID);
            if (hft.DestTable.Equals("LOCATION_USER_FACT"))
            {
                gvResults.Columns[13].Visible = false; // company 
            }
            else
            {
                gvResults.Columns[16].Visible = false; // status 
                gvResults.Columns[17].Visible = false; // design 
                gvResults.Columns[18].Visible = false; // type
                gvResults.Columns[19].Visible = false; // subtype
                gvResults.Columns[20].Visible = false; // tier
            }
            DateTime dtNowCmp = dtNow.AddSeconds(-5);

            gvResults.DataSource = a;
            gvResults.DataBind();

            /*
                if (f.Outlook == null)
                {
                    tc = new TableCell();
                    tc.Text = f.Month;
                    tr.Cells.Add(tc);
                    tc = new TableCell();
                    tc.Text =  f.Fact.ToString();
                    tc.HorizontalAlign = HorizontalAlign.Right;
                    tr.Cells.Add(tc);
                }
                else // if out look columns 
                {
                    tc = new TableCell();
                    tc.Text +=  f.Outlook.Fact_BegBal.ToString();
                    tc.HorizontalAlign = HorizontalAlign.Right;
                    tr.Cells.Add(tc);
                    tc = new TableCell();
                    tc.Text = f.Outlook.Fact_Jan.ToString();
                    tc.HorizontalAlign = HorizontalAlign.Right;
                    tr.Cells.Add(tc);
                    tc = new TableCell();
                    tc.Text = f.Outlook.Fact_Feb.ToString();
                    tc.HorizontalAlign = HorizontalAlign.Right;
                    tr.Cells.Add(tc);
                    tc = new TableCell();
                    tc.Text = f.Outlook.Fact_Mar.ToString();
                    tc.HorizontalAlign = HorizontalAlign.Right;
                    tr.Cells.Add(tc);
                    tc = new TableCell();
                    tc.Text = f.Outlook.Fact_Apr.ToString();
                    tc.HorizontalAlign = HorizontalAlign.Right;
                    tr.Cells.Add(tc);
                    tc = new TableCell();
                    tc.Text = f.Outlook.Fact_May.ToString();
                    tc.HorizontalAlign = HorizontalAlign.Right;
                    tr.Cells.Add(tc);
                    tc = new TableCell();
                    tc.Text = f.Outlook.Fact_Jun.ToString();
                    tc.HorizontalAlign = HorizontalAlign.Right;
                    tr.Cells.Add(tc);
                    tc = new TableCell();
                    tc.Text = f.Outlook.Fact_Jul.ToString();
                    tc.HorizontalAlign = HorizontalAlign.Right;
                    tr.Cells.Add(tc);
                    tc = new TableCell();
                    tc.Text = f.Outlook.Fact_Aug.ToString();
                    tc.HorizontalAlign = HorizontalAlign.Right;
                    tr.Cells.Add(tc);
                    tc = new TableCell();
                    tc.Text = f.Outlook.Fact_Sep.ToString();
                    tc.HorizontalAlign = HorizontalAlign.Right;
                    tr.Cells.Add(tc);
                    tc = new TableCell();
                    tc.Text = f.Outlook.Fact_Oct.ToString();
                    tc.HorizontalAlign = HorizontalAlign.Right;
                    tr.Cells.Add(tc);
                    tc = new TableCell();
                    tc.Text = f.Outlook.Fact_Nov.ToString();
                    tc.HorizontalAlign = HorizontalAlign.Right;
                    tr.Cells.Add(tc);
                    tc = new TableCell();
                    tc.Text = f.Outlook.Fact_Dec.ToString();
                    tc.HorizontalAlign = HorizontalAlign.Right;
                    tr.Cells.Add(tc);
                } //End of if outlook
      
            //  If we skipped any lines from being displayed, display a line with a count of how many items were skipped.
            if (SkippedRows > 0)
            {
                litSkippedRows.Visible = true;
                litSkippedRows.Text = string.Format("{0} rows were skipped.", SkippedRows);
            }
            else
                litSkippedRows.Visible = false;

            return a.Count;
        }
        catch (Exception ex)
        {
            Utils.LogEvent(Master.curUser.EmployeeID, "UserInputUpload.aspx", "ShowLoadedRecords", ex, LogLevel.Error);
            return -1;
        }
    }
    */

    private void DisplayPopUpMessage(string Message)
    {
        litPopupMsg.Text = string.Format(@"<script language=""javascript"" type=""text/javascript"">setTimeout(""alert('{0}');"", 500);</script>", Message);
    }

    private void ShowContinueItems(bool bShow)
    {
        ShowContinueItems(bShow, "");
    }

    private void ShowContinueItems(bool bShow, string Message)
    {
        lblAddKeys.Visible = bShow;
        btnContinue.Visible = bShow;
        btnCancel.Visible = bShow;
        ddlFileType.Enabled = !bShow;
        fuUserFile.Enabled = !bShow;
        btnUpload.Visible = !bShow;
        ddlMonths.Enabled = !bShow;
        ddlYears.Enabled = !bShow;

        if (bShow == false)
        {
            Master.Message = Message;
            //litPopupMsg.Text = "";
        }
        // jevans 7/20/2011 - do not show popup msg 
        litPopupMsg.Text = "";
    }

    /* jevans 7/14/2011 there is no pagination 
    private void buildPageCount(int RecCount)
    {
        try
        {
            string sPageNum = (gvResults.PageIndex + 1).ToString();
            string sPageCount = gvResults.PageCount.ToString();
            sPageNum = gvResults.PageIndex + 1 > gvResults.PageCount ? sPageCount : sPageNum;

            int iStartRec = (gvResults.PageIndex * gvResults.PageSize);
            int iEndRec = iStartRec + gvResults.PageSize;
            iEndRec = iEndRec > RecCount ? RecCount : iEndRec;

            string sStartRec = (iStartRec + 1).ToString();
            string sEndRec = iEndRec.ToString();
            lbPageSelect.Items.Clear();
            for (int i = 1; i <= gvResults.PageCount; i++)
                lbPageSelect.Items.Add(new ListItem(i.ToString(), (i - 1).ToString()));
            lblPageCount.Text = sPageCount;
            lbPageSelect.SelectedValue = gvResults.PageIndex.ToString();
            lblPageCount.Text = string.Format("Page {0} of {1}", sPageNum, sPageCount); ;
            lblRowCount.Text = string.Format("Rows {2} thru {3} of {4}", sPageNum, sPageCount, sStartRec, sEndRec, RecCount.ToString());
        }
        catch (Exception ex)
        {
            Utils.LogEvent(Master.curUser.EmployeeID, "UserInputUpload.aspx", "buildPageCount", ex, LogLevel.Error);
        }
    }
    */

    /* jevans 7/14/2011 there is no pagination 
    private void buildPageHead()
   {
       try
       {
           if (tcPageCount == null)
           {
               tcPageCount = new TableCell();
               tcPageCount.ID = "tcPageCount";
               lblPageCount = new Label();
               lblPageCount.ID = "lblPageCount";
               tcPageCount.Controls.Add(lblPageCount);
               tcPageCount.Wrap = false;

               tcRowCount = new TableCell();
               tcRowCount.ID = "tcRowCount";
               lblRowCount = new Label();
               lblRowCount.ID = "lblRowCount";
               tcRowCount.Controls.Add(lblRowCount);
               tcRowCount.HorizontalAlign = HorizontalAlign.Center;
               tcRowCount.Width = Unit.Percentage(90);

           }
       }
       catch (Exception ex)
       {
           Utils.LogEvent(Master.curUser.EmployeeID, "UserInputUpload.aspx", "buildPageHead", ex, LogLevel.Error);

       }
   }
   */
    #endregion

}
