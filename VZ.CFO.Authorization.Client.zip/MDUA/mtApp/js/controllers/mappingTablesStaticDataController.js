﻿(function ($) {
	 angular.module('vmApp').controller('mappingTablesStaticDataController', ['$scope', 'uiGridConstants', 'uiGridExporterConstants', mappingTablesController]);
	 
	 function mappingTablesController ($scope, uiGridConstants, uiGridExporterConstants) {

        var self = this;
        self.uiGridConstants = uiGridConstants;
        self.DataTableVM = new DataTableViewModel(uiGridConstants);
        self.DataTableVM.MockData();
        self.DataTableVM.PivotData();
        self.Title = "This is Title";

        self.searchFor = "";
        self.replaceWith = "";
        self.searchComplete = "";
        self.replace = function () {
            if (self.searchFor != "") {
                for (var i = 0; i < self.DataTableVM.Rows.length; i++) {
                    var r = self.DataTableVM.Rows[i];
                    for (var j = 0; j < r.Data.length; j++) {
                        if (r.Data[j] === self.searchFor) {
                            r.Data[j] = self.replaceWith;
                        }
                    }
                }
            }
        };

        self.ChangeTitle = function () {
            self.Title = "TItle is changed.";
        };

        self.SelectedMappingTable = "";
        self.AvailableMappingTables = ["PMR Mapping Table", "Planning Mapping Table", "Mapping Table 3"];
        self.gridOptions = {
            //enableGridMenu: true,
            enableSelectAll: true,
            enableRowSelection: true,
            exporterCsvFilename: 'myFile.csv',
            enableFiltering: false,
            enableSorting: true,
            columnDefs: self.DataTableVM.GridColumnDefs,
            data: self.DataTableVM.Rows,
            showGridFooter: true,
            exporterPdfDefaultStyle: { fontSize: 9 },
            exporterPdfTableStyle: { margin: [30, 30, 30, 30] },
            exporterPdfTableHeaderStyle: { fontSize: 10, bold: true, italics: true, color: 'red' },
            exporterPdfHeader: { text: "My Header", style: 'headerStyle' },
            exporterPdfFooter: function (currentPage, pageCount) {
                return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
            },
            exporterPdfCustomFormatter: function (docDefinition) {
                docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
                docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
                return docDefinition;
            },
            exporterPdfOrientation: 'portrait',
            exporterPdfPageSize: 'LETTER',
            exporterPdfMaxGridWidth: 500,
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location"))
        };

        self.showFilter = function () {
            self.gridOptions.enableFiltering = !self.gridOptions.enableFiltering;
            self.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
        };

        self.gridOptions.onRegisterApi = function (gridApi) {
            //set gridApi on scope
            self.gridApi = gridApi;
            gridApi.selection.on.rowSelectionChanged($scope, function (row) {
                //var msg = 'row selected ' + row.isSelected;
                self.DataTableVM.SelectedRowsRef.push(row.uid);
                row.entity.IsSelected = true;
            });

            gridApi.selection.on.rowSelectionChangedBatch($scope, function (rows) {
                //var msg = 'rows changed ' + rows.length;
                for (var rowIndex = 0; rowIndex < rows.length; rowIndex++) {
                    self.DataTableVM.SelectedRowsRef.push(rows[rowIndex].uid);
                    rows[rowIndex].entity.IsSelected = true;
                }
            });
        };

        self.ExportToCSV = function () {
            var myElement = angular.element(document.querySelectorAll(".custom-csv-link-location"));
            self.gridApi.exporter.csvExport(uiGridExporterConstants.ALL, uiGridExporterConstants.VISIBLE, myElement);
        };

        //self.ToggleGridHeight = function () {
        //    var newHeight = "500";
        //    if (self.DataTableVM.isFullScreenMode == true) {
        //        newHeight = "750";
        //    }
        //    angular.element(document.getElementsByClassName('grid1')[0]).css('height', newHeight + 'px');
        //};

        self.maxRowToShow = 25;

        self.randomSize = function () {
            //var newHeight = Math.floor(Math.random() * (300 - 100 + 1) + 300);
            //var newWidth = Math.floor(Math.random() * (600 - 200 + 1) + 200);

            angular.element(document.getElementsByClassName('grid')[0]).css('height', newHeight + 'px');
            //angular.element(document.getElementsByClassName('grid')[0]).css('width', newWidth + 'px');
        };

        self.setMinRowsToShow = function () {
            //if data length is smaller, we shrink. otherwise we can do pagination.
            self.gridOptions.minRowsToShow = Math.min(self.gridOptions.data.length, self.maxRowToShow);
            self.gridOptions.virtualizationThreshold = self.gridOptions.minRowsToShow;
        }

        self.ddlHandler = function() {
            //removes selected globally and applies selected on list item click
            jQuery(this).parent().find(jQuery('li')).removeClass('selected');
            jQuery(this).addClass('selected');
            //getting span
            var cache = jQuery(this).parent().prev().children('span');
            //displays value on button
            jQuery(this).parent().prev().text(jQuery(this).text()).append(cache);
            //updates value on input field
            jQuery(this).parent().prev().prev('input[type="hidden"]').val(jQuery(this).text());
        }

        self.ToggleScreenMode = function () {
            var newHeight = "500px";
            self.DataTableVM.isFullScreenMode = !self.DataTableVM.isFullScreenMode;
            if (self.DataTableVM.isFullScreenMode === true) {
                self.DataTableVM.fullScreenButtonText = "Exit Full Screen";
                newHeight = "750px";
            }
            else {
                self.DataTableVM.fullScreenButtonText = "View Full Screen";
                //self.gridHeightInPx = self.getTableHeight();
                newHeight = "500px";
            }
            angular.element(document.getElementsByClassName('grid')[0]).css('height', newHeight);
        };

    }
    //end of controller function


    function DataTableViewModel(uiGridConstants) {
    var self = this;
    self.isFullScreenMode = false;
    self.fullScreenButtonText = "View Full Screen";
    self.gridClass = "grid";
    self.uiGridConstants = uiGridConstants;
    self.Title = "This is Title";
    self.Columns = []; //["Column 1", "Column 2", "Column 3", "Column 4", "Validation Comments"];
    self.Data = [];//[[100, 110, 120, 130], [200, 220, 250, 260], [300, 310, 350, 360], [400, 410, 450, 460], ["", "Invalid member name", ""]];
    self.Rows = [];
    self.GridColumnDefs = [];
    self.GridColumnFilterValues = [];
    self.MockData = function () {
        var maxRows = 100000;
        var maxColumns = 3;

        for (var colIndex = 0; colIndex < maxColumns; colIndex++) {
            var col = [];
            self.Columns.push("Column " +colIndex);
            for (var rowIndex = 0; rowIndex < maxRows; rowIndex++) {
                col.push((colIndex * 10) +rowIndex);
        }
            self.Data.push(col);
    }
    };
    self.PivotData = function () {
        self.Rows = [];
        self.GridColumnDefs = [];
        self.Columns.unshift("Validation Comments");

        for (var colIndex = 0; colIndex < self.Columns.length; colIndex++) {
            var colDef = new GridColumnDefViewModel(self.Columns[colIndex], 'Data[' + colIndex + ']', true);
            if (colIndex == 0) {
                colDef.visible = false;
            }

            

            self.GridColumnDefs.push(colDef);
        }

        for (var rowIndex = 0; rowIndex < self.Data[0].length; rowIndex++) {
            var trvm = new TableRowViewModel();
            //trvm.RowId = rowIndex;

            //push empty data for validation
            trvm.Data.push("");
            for (var colIndex = 0; colIndex < self.Data.length; colIndex++) {
                trvm.Data.push(self.Data[colIndex][rowIndex]);               
            }
            self.Rows.push(trvm);
            
    }
    };
    self.AddColumn = function () {
        var newColumnLength = self.Columns.length +1;
        var newColumnData = self.Data[self.Data.length -1];
        for (var rowIndex = 0; rowIndex < newColumnData.length; rowIndex++) {
            newColumnData[rowIndex] = newColumnData[rowIndex] +100;
    }
        self.Columns.push("Column " +newColumnLength);
        self.Data.push(newColumnData);
        self.PivotData();
    };
    self.SelectedRowsRef = [];
    self.DeletedRows = [];
    self.ValidateData = function (gridApi) {
        var col = [];

        self.ErrorMessageCollection.push("15 of 125 rows failed validation. Refer to 'Validation Message' column to correct errors.");

        for (var rowIndex = 0; rowIndex < self.Rows.length; rowIndex++) {
            if (rowIndex % 40 == 0) {
                var r = self.Rows[rowIndex];
                r.Data[0] = "Invalid Member name";
                r.ValidationType = 1;
                //col.push("Invalid Member name");
        }
    }

        self.GridColumnDefs[0].visible = true;
        gridApi.core.notifyDataChange(self.uiGridConstants.dataChange.COLUMN);
    };
    self.AddNewRow = function () {
        var trvm = new TableRowViewModel();
        for (var colIndex = 0; colIndex < self.Columns.length; colIndex++) {
            trvm.Data.push('');
    }
        self.Rows.unshift(trvm);
    };
    self.ErrorMessageCollection = [];
    self.SuccessMessageCollection = [];
    self.clearErrorMessages = function () {
        self.ErrorMessageCollection = [];
    };
    self.clearSuccessMessages = function () {
        self.SuccessMessageCollection = [];
    };
    self.DeleteSelectedRows = function () {
        for (var rowIndex = 0; rowIndex < self.Rows.length; rowIndex++) {
            if (self.Rows[rowIndex].IsSelected === true) {
                self.Rows.splice(rowIndex, 1);
        }
    }
    };
    self.gridHeightInPx = "auto"

    self.getTableHeight = function () {
        if (self.isFullScreenMode === true) {
            return {
                    height: "750px"
        };
        }
        else {
            return {
                    height: "auto"
        };
    }
        //var rowHeight = 30; // your row height
        //var headerHeight = 30; // your header height
        //return {
        //    height: ($scope.gridData.data.length * rowHeight + headerHeight) + "px"
        //};
    };
    self.EnableFilters = function () {
        for (var gridColDefIndex = 1; gridColDefIndex < self.GridColumnDefs.length; gridColDefIndex++) {
            self.GridColumnDefs[gridColDefIndex].filter = new ColumnFilterViewModel(uiGridConstants.filter.SELECT, self.Data[gridColDefIndex].unique());
        }
    }

    vzbsDropdown();
}

    function TableRowViewModel() {
    var self = this;
    self.ValidationType = "0";
    self.Data = [];
    self.IsSelected = false;
    }

    function ColumnFilterSelectOption(value, label) {
        var self = this;
        self.value = value;
        self.label = label;
    }
    function ColumnFilterViewModel(type, selectOptions ) {
            var self = this;
            self.type = type;
            self.selectOptions = selectOptions;
        }

    function GridColumnDefViewModel(name, field, isVisible) {
            var self = this;
            self.name = name;
            self.field = field;
            self.enableCellEdit = true;
            self.visible = isVisible;
            self.cellClass = function (grid, row, col, rowRenderIndex, colRenderIndex) {
                if (row.entity.ValidationType == "1") {
                    return "red";
                }
            };
        }

})(window.jQuery);