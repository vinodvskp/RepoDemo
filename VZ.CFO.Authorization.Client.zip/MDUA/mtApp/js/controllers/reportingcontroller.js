﻿(function(){
    angular.module('vmApp').controller('reportingController', ['constantService', '$state', '$templateCache', '$timeout', '$uibModal', '$scope', 'uiGridConstants', 'uiGridExporterConstants', '$http', 'spinnerService', 'reportingService', 'errorHandlerService', '$q', reportingController])

    function rotate(lists) {
        if (!lists || lists.length == 0) return lists;

        let ret = [];
        for(let j = 0; j < lists[0].length; j++) {
            let row = [];
            for(let i = 0; i < lists.length; i++) 
                row.push(lists[i][j])
            ret.push(row);
        }
        return ret;
    }

    function paging() {
        const DEFAULT_DISPLAY = 5; //default 5 pages to display
        let displays = [];
        let total;
        let cur;
        return {
            init: function (totalpages, numtodisplay) {
                numtodisplay = numtodisplay || DEFAULT_DISPLAY; 
                if (numtodisplay > totalpages)
                    numtodisplay = totalpages;

                displays.length = 0;
                for (let i = 0; i < numtodisplay; i++) {
                    displays.push(i + 1);
                }
                cur = 1;
                total = totalpages;
                return this;
            },
            reset: function() {
                displays.length = 0;
                return this;
            },
            next: function () {
                if (this.disablenext) return false;
                cur += 1;
                if (cur > displays[displays.length - 1]) {
                    displays.shift();
                    displays.push(cur);
                }
                return cur;
            },
            prev: function () {
                if (this.disableprev) return false;
                cur -= 1;
                if (cur < displays[0]) {
                    displays.pop();
                    displays.unshift(cur);
                }
                return cur;
            },
            first: function () {
                if (this.disablefirst) return false;
                this.init(total, displays.length);
                return cur;
            },
            last: function () {
                if (this.disablelast) return false;
                for (let i = 0; i < displays.length; i++) {
                    displays[i] = total - (displays.length - (i + 1));
                }
                cur = total;
                return cur;
            },
            disabled: function (page) {
                return page > total
            },
            get alldisplay() {
                return displays;
            },
            get current() {
                return cur;
            },
            set current(ncur) {
                if (!this.disabled(ncur)) {
                    cur = ncur;
                }
                return this;
            },
            get disablefirst(){
                return cur == 1;
            },
            get disablelast(){
                return cur == total;
            },
            get disableprev() {
                return cur == 1;
            },
            get disablenext() {
                return cur == total
            },
            get haspages() {
                return displays.length > 1;
            },
            get total() {
                return total;
            }
        };
    }
    function reportingController(constantService, $state, $templateCache, $timeout, $uibModal, $scope, uiGridConstants, uiGridExporterConstants, $http, spinnerService, reportingService, errorHandlerService, $q) {
		
	    var self = this;

        self.isFullScreenMode = false;
        self.fullScreenButtonText = "View Full Screen";
        self.filterButtonText ="Show Filter";
        self.uiGridConstants = uiGridConstants;
        self.totalPages;
        self.loadedPages = 0;
        self.showtable = false;
        self.showprogressbar = false;
        self.showmorespinner = false;
        self.validationSummary = [];
        self.exportUrl = "";
        self.searchvalue = "";
 		self.closeValidationSummary = function(index) {
 			self.validationSummary.splice(index, 1);
 		};
 		
        self.groups = {
    		'items': [],
    		'selectedItem':null,
    		'loading': false
        };

        this.selectedReport = null;
        this.groups.loading = true;
        this.showinfo = false;
        this.paging = paging();

        $scope.$watch('rpt.selectedReport', function () {
            this.messages = this.infos();
        }.bind(this));

        reportingService.getReports()
            .then(function (response) {
                this.groups.items = response.data
            }.bind(this)).catch(function (err) {
                errorHandler(err)
            }).finally(function () {
                this.groups.loading = false;
                spinnerService.hide("overlaySpinner");
            }.bind(this));

        //Note: backup ui-grid/uiGridViewport template 
        $templateCache.put("ui-grid/uiGridViewport_original", $templateCache.get("ui-grid/uiGridViewport"));
        $templateCache.put('ui-grid/uiGridViewport',
        	    "<div class=\"ui-grid-viewport\" ng-style=\"colContainer.getViewportStyle()\"><div class=\"ui-grid-canvas\"><div ng-repeat=\"(rowRenderIndex, row) in rowContainer.renderedRows track by $index\" ng-if=\"!row.entity.deleted || row.entity.deleted==false\" class=\"ui-grid-row\" ng-style=\"Viewport.rowStyle(rowRenderIndex)\"><div ui-grid-row=\"row\" row-render-index=\"rowRenderIndex\"></div></div></div></div>"
        	  );

        self.gridOptions = {
                enableColumnMenus:false,
                rowEditWaitInterval: -1,
                exporterCsvFilename: 'myFile.csv',
                enableFiltering: false,
                enableSorting: false,           
                showGridFooter: true,
                importerDataAddCallback: function (grid, newObjects) {},
                gridFooterTemplate: "<div class=\"ui-grid-footer-info ui-grid-grid-footer\"><span>{{'search.totalItems' | t}} {{grid.rows.length - grid.appScope.deletedRows}}</span><span ng-if=\"grid.selection.selectedCount !== 0 && grid.options.enableFooterTotalSelected\"> ({{\"search.selectedItems\" | t}} {{grid.appScope.selectedRows}})</span> <span ng-if=\"grid.renderContainers.body.visibleRowCache.length !== grid.rows.length\" class=\"ngLabel\">({{\"search.showingItems\" | t}} {{grid.renderContainers.body.visibleRowCache.length}})</span></div>",
        };
          
        self.gridOptions.onRegisterApi = function (gridApi) {
            self.gridApi = gridApi;       
        };	

        this.supported = function () {
            return this.selectedReport == null || this.selectedReport.ReportType == 1;
        };

        this.selectgroup = function (group) {
            this.groups.selectedItem = group;
            this.selectedReport = null;
            this.reset();
        };

        this.reset = function () {
            this.showprogressbar = false;
            this.showmorespinner = false;
            this.showtable = false;
            this.showinfo = false;
            this.searchvalue = "";
            this.paging.reset();
        };

        this.selectreport = function (report) {
            var gridwidth = document.querySelector('#gridContainer').offsetWidth;
            this.selectedReport = report;
            this.reset();
            if (!this.supported()) return;
            var totallength = report.Columns.reduce(function (acc, c) { return acc + c.DisplayName.length; }, 0) * 15;
            this.gridOptions.columnDefs = report.Columns.map(function (v, idx) {
                return {
                    name: v.DisplayName,
                    displayName: v.DisplayName,
                    field: idx.toString(),
                    visible: true,
                    width: totallength > gridwidth ? v.DisplayName.length * 15 : "*",
                    filter: {
                        condition: function (term, cell) {
                            let or = term.split(/\s*,\s*/).join('|');
                            var matcher = new RegExp(or, 'i');
                            return cell.match(matcher);
                        }
                    }
                };
            });
            loadreport.call(this, report);
            self.gridApi.grid.registerRowsProcessor(self.setsearchfilter, 200)
        };

        this.first = function () {
            let page = this.paging.first();
            if (page) {
                dopage.call(this, page);
            }
        };

        this.last = function () {
            let page = this.paging.last();
            if (page) {
                dopage.call(this, page);
            }
        };

        this.next = function () {
            let page = this.paging.next();
            if (page) {
                dopage.call(this, page);
            }
        };

        this.prev = function () {
            let page = this.paging.prev();
            if (page) {
                dopage.call(this, page);
            }
        };

        this.setpage = function (npage) {
            if (npage == this.paging.current) return;

            this.paging.current = npage;
            let page = this.paging.current;
            if (page) {
                dopage.call(this, page);
            }
        };

        function loadreport(report) {
            this.showmorespinner = true;
            reportingService.getInitialLoad(report.Id).then(function (response) {
                let reportingdata = response.data.ReportingData;
                if (!reportingdata.Data || reportingdata.Data.length == 0) {
                    this.showinfo = true;
                    return;
                }

                if (report.PagingType === 2) {
                    doallreport.call(this, reportingdata);
                } else {
                    dofirstpage.call(this, reportingdata);
                }             
            }.bind(this)).catch(function (err) {
                errorHandler(err);
            }).finally(function () {
                this.showmorespinner = false;
            }.bind(this));
        }

        this.infos = function () {
            if (!this.selectedReport)
                return [];

            let messages = this.selectedReport.CustomMessages || [];
            let ms = messages.filter(function (m) { return m.Event == "NO_DATA"; });
            return [].concat(ms.map(function (m) { return m.Message; }));
        };

       
        function doallreport(reportingdata) {
            let lists = unwrap(reportingdata)
            this.gridOptions.data = rotate(lists);
            this.totalPages = reportingdata.TotalPages;
            this.loadedPages = reportingdata.PageNumber;

            this.showprogressbar = this.totalPages > 2

            let promises = reportingService.getRemainingLoad(this.selectedReport.Id, reportingdata.TotalPages, reportingdata.PageNumber + 1, reportingdata.RowsPerPage, reportingdata.TotalRows);
            promises = promises.map(function (p) {
                return p.then(function (data) {
                    self.loadedPages += 1;
                    return data;
                });
            });
            $q.all(promises).then(function (response) {
                var datas = response.map(function (e) {
                    let lists = unwrap(e.data.ReportingData);
                    let r = rotate(lists);
                    return r;
                });
                var acc = self.gridOptions.data;
                self.gridOptions.data = datas.reduce(function (acc, e) { return acc.concat(e); }, acc);
            });

            this.showtable = true;
        }

        function dofirstpage(reportingdata) {
            var lists = unwrap(reportingdata)
            this.gridOptions.data = rotate(lists);
            this.totalPages = reportingdata.TotalPages;
            this.loadedPages = reportingdata.PageNumber;
            this.rowsperpage = reportingdata.RowsPerPage;
            this.totalrows = reportingdata.TotalRows;
            this.paging.init(reportingdata.TotalPages);
            this.showtable = true;
        }

        function dopage(pagenumber) {
            this.showmorespinner = true;
            reportingService.getPageData(this.selectedReport.Id, pagenumber, this.totalrows, this.rowsperpage).then(function (response) {
                let reportingdata = response.data.ReportingData;
                var lists = unwrap(reportingdata)
                this.gridOptions.data = rotate(lists);
                this.showtable = true;
            }.bind(this)).catch(function (err) {
                errorHandler(err);
            }).finally(function () {
                this.showmorespinner = false;
            }.bind(this))
        }

        function unwrap(reportingdata) {
            return reportingdata.Data.map(function (x) { return x.Values;})
        }
      
        self.showFilter = function () {
        	self.filterButtonText = self.gridOptions.enableFiltering ? "Hide Filter" : "Show Filter";
        	self.gridApi.core.clearAllFilters();
        	self.gridOptions.enableFiltering = !self.gridOptions.enableFiltering;
            self.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);

        };
        
        self.search = function() {
        	self.gridApi.grid.refresh();
        }
        
        self.setsearchfilter = function (rows) {
            let or = self.searchvalue.split(/\s*,\s*/).join('|');
            var matcher = new RegExp(or, 'i');
            rows.forEach(function (row) {
                // for visible = false row, just return it because it is controlled by other filters
                // only run for these visible rows.
                row.visible = row.visible ? row.entity.some(function (cvalue) { return cvalue.match(matcher); }) : false;
            });
            return rows;
        };
                  
        self.togglescreen = function (header, footer) {
            let eh = document.querySelector(header);
            let ef = document.querySelector(footer);
            let grid = document.querySelector('#gridContainer');

            self.isFullScreenMode = !self.isFullScreenMode;
            if (self.isFullScreenMode) {
                self.fullScreenButtonText = "Exit Full Screen";
                var gridheight = 500 + eh.offsetHeight * 2;
                eh.classList.add("ng-hide");
                ef.classList.add("ng-hide");
                grid.style['height'] = gridheight + 'px';
            }
            else {
                self.fullScreenButtonText = "View Full Screen";
                eh.classList.remove('ng-hide');
                ef.classList.remove('ng-hide');
                grid.style['height'] = "500px";
            }       
        };
           
        this.exportfile = function () {       	
            reportingService.getSignedKey({reportid: this.selectedReport.Id}, getSignedKeyCallback.bind(this), errorCallback.bind(this));      	
        }
        
        function getSignedKeyCallback(response) {
            window.open(reportingService.exporturl(this.selectedReport.Id, response.data));
        }
              
       function errorCallback(data) {
    	    this.reports.loading = false;
    		spinnerService.hide("overlaySpinner");
       }	
       
       function errorHandler(data) {
   		if (data.status =="401") {
   			errorHandlerService.addError(data.message.text);
   			$state.go("error");
   		} 		
   	  }     
 };
})();


