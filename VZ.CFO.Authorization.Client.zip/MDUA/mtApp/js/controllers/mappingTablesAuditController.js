(function (module) {
    module.controller('mappingTablesAuditController', ['spinnerService', 'mappingTablesService', 'mappingTablesAuditService', 'uiGridConstants', mappingTablesAuditController]);
    function mappingTablesAuditController(spinnerService, mappingTablesService, mappingTablesAuditService, uiGridConstants) {

        var _oldValueGridColInd = 3;
        var _newValueGridColInd = 4;
        var _isDataValidatedGridColInd = 7;
        var _isValidOverriddenGridColInd = 8;

        var self = this;
        self.searchValue ="";
        self.showGrid = false;
        self.AvailableMappingTables = {
    			'buttonLabel':'Select Mapping Table',
    			'items': [],
    			'selectedItem':null,
    			'status': { 'isopen':false},
    			'required': null
    	};
        
        self.pageSizes = {
        		'items':[20,30,40,50],
        		'selectedItem':20
        };

        //set auditType to data (1) by default
        self.auditType = "1";
        
        self.auditPageData =[];
        self.searchAuditPageData =[];
        
        mappingTablesService.getAllMappingTables({},allMappingTablesCallback, errorCallback);
        
        self.gridOptions = {
        		enableColumnMenus:false,
        		columnDefs:  [{name:"Id",field:"Id",visible:false},
        		              {name:"MappingTableId",field:"MappingTableId",visible:false},
        		              {name:"Action",field:"Action"},
			                  {name:"OldValue",field:"OldValue"},
			                  {name:"NewValue",field:"NewValue"},
			                  {name:"ActionBy",field:"ActionBy"},
			                  {name:"ActionOn", field: "ActionOn", type: "date", cellFilter: "date:'MM/dd/yyyy, HH:mm'" },
                              {name:"IsDataValidated",field:"IsDataValidated"},
                              {name:"IsValidationOverridden", field: "IsValidationOverridden" }],
        	minRowsToShow: 14,
            enableFiltering: false,
            enableSorting: false,
            showGridFooter: true
        };
        
        self.gridOptions.onRegisterApi = function (gridApi) {
            self.gridApi = gridApi;
  
        };
       
       self.selectMappingTable = function(selectedTable) {
    	    self.showGrid = false;
        	self.AvailableMappingTables.selectedItem = selectedTable;
        	self.AvailableMappingTables.buttonLabel = selectedTable.Name;
            self.itemsPerPage = self.pageSizes.selectedItem;
            self.currentPage = 1;
        	mappingTablesAuditService.setTableId(selectedTable.Id);
        	mappingTablesAuditService.setRowsPerPage( self.itemsPerPage );
        	spinnerService.show("overlaySpinner");
        	mappingTablesAuditService.setAuditType(self.auditType);
        	mappingTablesAuditService.getFirstPageData({},getFirstAuditPageCallback, errorCallback);
        	
        };
        
       self.clearSearch = function() {
        	if(self.searchValue=="" || self.searchValue==null){
        		self.pageChanged();
        	}
       }

       self.changeView = function () {
    	   self.searchValue ="";
           mappingTablesAuditService.setAuditType(self.auditType);
           self.currentPage = 1;
           self.pageChanged();
       }
        
        self.search = function() {
        	//mappingTablesAuditService.setSearchKey(self.searchValue);
            //mappingTablesAuditService.getSearchPageData({pageNumber:self.currentPage},getSearchAuditPageCallback, errorCallback);
            mappingTablesAuditService.setAuditType(self.auditType);
        	mappingTablesAuditService.getFirstPageData({"searchKey":self.searchValue},getFirstAuditPageCallback, errorCallback);
        }
    
        self.pageChanged = function () {
            //self.gridApi.pagination.seek(self.currentPage);
            mappingTablesAuditService.setAuditType(self.auditType);
        	if(self.currentPage ===1){
        		mappingTablesAuditService.getFirstPageData({"searchKey":self.searchValue},getFirstAuditPageCallback, errorCallback);
        	}
        	else {
        		mappingTablesAuditService.getPageData({"searchKey":self.searchValue, pageNumber:self.currentPage},getAuditPageCallback, errorCallback);
        	}
        	
        };
        
        self.selectPageSize = function(pageSize) {
        	//self.gridOptions.paginationPageSize = pageSize;
        	self.pageSizes.selectedItem = pageSize;
            self.itemsPerPage = self.pageSizes.selectedItem;
            self.currentPage = 1;
            mappingTablesAuditService.setRowsPerPage(self.itemsPerPage);
            mappingTablesAuditService.setAuditType(self.auditType);
        	spinnerService.show("overlaySpinner");
        	mappingTablesAuditService.getFirstPageData({"searchKey":self.searchValue},getFirstAuditPageCallback, errorCallback);
        	
        }
        
        function allMappingTablesCallback(response) {
        	var resp = response;
        	self.AvailableMappingTables.items = mappingTablesService.getSelectableTables();
        }
        
        function getFirstAuditPageCallback(response) {
        	var result = response;
        	self.showGrid = true;
        	self.auditPageData = result;
        	self.totalItems = mappingTablesAuditService.totalRecords;

            //set the grid data to empty array in case auditPageData is null; without this, data is not cleared in grid
        	if (self.auditPageData === null) {
        	    self.gridOptions.data = [];
        	}
        	else {
        	    self.gridOptions.data = self.auditPageData;
        	}
        	

        	toggleColumnsForAuditType();
        	spinnerService.hide("overlaySpinner");
        }
        
        function getAuditPageCallback(response) {
        	var result = response;
        	self.auditPageData = result;
        	self.gridOptions.data = self.auditPageData;

        	toggleColumnsForAuditType();
        	spinnerService.hide("overlaySpinner");
        }
        
        function getSearchAuditPageCallback(response) {
        	var result = response;
        	self.searchAuditPageData = result;
        	self.gridOptions.data = self.searchAuditPageData;

        	toggleColumnsForAuditType();
        	spinnerService.hide("overlaySpinner");
        }
        
        function errorCallback(data) {
    		console.log(data);
    		spinnerService.hide("overlaySpinner");
        }

        function toggleColumnsForAuditType() {
            if (self.auditType === "1") {
                self.gridOptions.columnDefs[_oldValueGridColInd].visible = true;
                self.gridOptions.columnDefs[_newValueGridColInd].visible = true;
                self.gridOptions.columnDefs[_isDataValidatedGridColInd].visible = true;
                self.gridOptions.columnDefs[8].visible = false;
                self.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
            }
            else {
                self.gridOptions.columnDefs[_oldValueGridColInd].visible = false;
                self.gridOptions.columnDefs[_newValueGridColInd].visible = false;
                self.gridOptions.columnDefs[_isDataValidatedGridColInd].visible = false;
                self.gridOptions.columnDefs[_isValidOverriddenGridColInd].visible = true;
                self.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
            }
        }
       
        
    };

}(angular.module("vmApp")));