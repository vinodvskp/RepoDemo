﻿(function ($) {
	 angular.module('vmApp').controller('mappingTablesController', ['constantService','$state','$templateCache','$timeout','$uibModal','$scope', 'uiGridConstants', 'uiGridExporterConstants','$http','spinnerService','mappingTablesService', 'errorHandlerService',mappingTablesController])
	 .controller('fileModalInstanceController', ['$window','$scope','modalColumnDefs','mappingTablesService','$uibModalInstance',function ($window, $scope,modalColumnDefs,mappingTablesService,$uibModalInstance){
		 var self = this;
		  self.columns = modalColumnDefs;
		  self.addedRows =[];
		  self.noRowLoaded = false;
		  self.noRowSelected = false;
		  self.errorMsg = "";
		  //note: override CSV.resove_type method to avoid converting a numeric string to a number.
		  CSV.resolve_type = function (token) {
		        if( token.match(/^\d+(\.\d+)?$/) ){
		            //token = parseFloat(token);
		        }
		        else if( token.match(/^(true|false)$/i) ){
		            token = Boolean( token.match(/true/i) );
		        }
		        else if(token === "undefined" ){
		            token = undefined;
		        }
		        else if(token === "null" ){
		            token = null;
		        }
		        return token;
		  };
		  CSV.error = function (err){
		        var msg = CSV.dump(err);
		        CSV.reset();
		        $scope.$apply( 
		        		function() { 
		        			self.noRowLoaded = true;
		        			self.errorMsg = "Error occurred while parsing the file. The file could be ill-formatted, corrupted or non-csv file.";
		        });
		        console.log(msg);
		    };
          $window.onerror = function(msg) {
        	  $scope.$apply( 
		        		function() { 
		        			self.noRowLoaded = true;
		        			self.errorMsg = "Error occurred while parsing the file. The file could be ill-formatted, corrupted or non-csv file.";
		        });
        	  console.log(msg);
          }
		  self.gridOptions = {
	                //enableGridMenu: true,
	                enableColumnMenus:false,
	                rowEditWaitInterval: -1,
	            	minRowsToShow: 14,
	            	data:[],
	                enableSelectAll: true,
	                enableRowSelection: true,
	                exporterCsvFilename: 'myFile.csv',
	                enableFiltering: false,
	                enableSorting: false,
	                columnDefs: createColumnDefs(modalColumnDefs),
	                showGridFooter: true,
	                importerDataAddCallback: function (grid, newObjects) {
	                    //console.log(newObjects);
	                    self.errorMsg = "";
	                    if(newObjects) {
	                    	self.noRowLoaded = false;
	                    }
	                    else {
	                    	self.noRowLoaded = true;
	                    }
	                    //error checking before loaded into the popup grid.
	                    if(!newObjects || newObjects.length ==0) {
	                    	self.errorMsg = "No data loaded from the file. Please make sure you select the right file with right columns."
	                    }
	                    else {
	                       var firstRowData = newObjects[0];
	                       var columnsNotFound = "";
	                       for(var i = 0; i < self.columns.length; i++)	 {
	                    	   var columnName = self.columns[i].displayName;
	                    	   if (columnName != "urowid" && columnName != "Validation Message") {
		                    	   if ((columnName in firstRowData) == false){
		                    		   columnsNotFound = columnsNotFound + columnName + ",";
		                    	   }
	                    	   }
	                       }
	                       if(columnsNotFound) {
	                    	   self.errorMsg = "Column(s) " + columnsNotFound.replace(/,$/,"") + " are not found in the file. Make sure your file is correct and well-formatted csv file and column names are exactly matched.";
	                       }
	                    }
	                    if(self.errorMsg) {
	                    	self.gridOptions.data = [];
	                    	self.noRowLoaded = true;
	                    }
	                    else {
	                    	self.gridOptions.data =newObjects;
	                    }
	               
	                },
	                importerErrorCallback: function(grid, errorKey, consoleMessage, context) {
	                	self.noRowLoaded = true;
	                	$scope.$apply( function () {
	                		switch(errorKey){
	                		case "importer.noHeaders":
	                			self.errorMsg = "No matched columns in the file."
	                		    break;
	                		case "importer.noObjects":
	                			self.errorMsg = "No rows created from the file -invalid or empty file content.";
	                			break;
	                		case "importer.invalidCsv":
	                			self.errorMsg = "Invalid csv file.";
	                			break;
	                		}
	                   
	                		});
	                	//console.log(self.errorMsg);
	                }
		  
	      };
		  self.gridOptions.onRegisterApi = function (gridApi) {
	            //set gridApi on scope
	            self.gridApi = gridApi;
	            $scope.gridApi = gridApi;//do this to pass to the file upload modal
	            gridApi.selection.on.rowSelectionChanged($scope, function (row) {        
	             //    row.entity.IsSelected = true;
	             //    self.addedRows.push(row);
	            });

	            gridApi.selection.on.rowSelectionChangedBatch($scope, function (rows) {
	               // for (var rowIndex = 0; rowIndex < rows.length; rowIndex++) {   
	              //      rows[rowIndex].entity.IsSelected = true;
	              //  }
	            });
	            
	        };
		  
		  self.add = function() {
			  var selectedGridRows = self.gridApi.selection.getSelectedRows()
			  for(var i=0; i <selectedGridRows.length; i++) {
				  var addedRow = mappingTablesService.createBlankRow();
				  addedRow.Data.push("");// add blank rowid to Data[0] for new record.
				  //note: the first two columns, validationMsg, dataKey are skipped
				  var selectedRow = selectedGridRows[i];
				  for(var j= 2; j <self.columns.length; j++) {
					  var colName = self.columns[j].displayName;
					  var colVal = selectedRow[colName];
					  if(j==2) {
						  colVal = colVal.toString();//if not convert number to string, it causes search feature failure.
					  }
					  addedRow.Data.push(colVal);
				  }
				  self.addedRows.push(addedRow);
			  }
			  if(self.addedRows.length > 0) {
				  $uibModalInstance.close(self.addedRows);
			  }
			  else {
				  if(self.noRowLoaded != true) {
					  self.noRowSelected = true;
				  }
				  else {
					  self.noRowSelected = false;
				  }
			  }
		  }

		  self.cancel = function () {
			$uibModalInstance.dismiss('cancel');
		  };
		  
		  function createColumnDefs(columns) {
			  var columnDefs =[];
			  for(var i =0; i <columns.length; i++) {
			      if (columns[i].displayName == "Validation Message" || columns[i].displayName == "urowid") {
				      columnDefs.push({ "name": columns[i].displayName, "displayName": columns[i].displayName, visible: false });
				  }
				  else {
				      columnDefs.push({ "name": columns[i].displayName, "displayName": columns[i].displayName, visible: true });
				  }
			  }
			  return columnDefs;
		  }
	
	 	}])
	 .controller('removeModalInstanceController', ['$uibModalInstance',function ($uibModalInstance){
		 var self = this;
		  self.ok = function ($event) {
		       $uibModalInstance.close("OK");
		  }
		  self.cancel = function () {
			$uibModalInstance.dismiss('cancel');
		  };
	
	 	}])
	 .controller('saveModalInstanceController', ['$uibModalInstance', 'canSkipValidation', 'IsValidationAssociated', function ($uibModalInstance, canSkipValidation, IsValidationAssociated) {
		 var self = this;
		  self.noSaveWithFailedValidation = true;
		  self.canSkipValidation = canSkipValidation;
		  self.isValidationAssociated = IsValidationAssociated;

		  if (!self.isValidationAssociated) {
		      self.noSaveWithFailedValidation = false;
		  }
		  //if(!canSkipValidation) {
			  
		  //    self.noSaveWithFailedValidation = true;
		  //}
		  self.ok = function ($event) {
		      $uibModalInstance.close(self.noSaveWithFailedValidation);
		   }

		  self.cancel = function () {
			$uibModalInstance.dismiss('cancel');
		  };
	
	 	}])	 
 	 .controller('findReplaceModalInstanceController', ['modalColumnDefs','$uibModalInstance',function (modalColumnDefs,$uibModalInstance){
		 var self = this;
		  self.find = {term:"", required: null};
		  self.replace = {term:"", required: null};
		  self.columns = {
		          items: createColumnDefs(modalColumnDefs),
				  selectedItem: null,
				  buttonLabel:"Select column",
				  required:null
		  };
		  
		  self.selectColumn = function(selectedItem) {
			  self.columns.buttonLabel = selectedItem.name;
			  self.columns.selectedItem = selectedItem;
			  self.columns.required = null;
		  }
		  
		  self.ok = function ($event) {
		      if (validateInput()) {

		          var selItem = $.grep(modalColumnDefs, function (m) { return m.displayName == self.columns.selectedItem.displayName; });

		          if (selItem.length > 0) {
		              $uibModalInstance.close({ findText: self.find.term, replaceText: self.replace.term, column: selItem[0] });
		          }

				  
			  }
		   }
	
		  self.cancel = function () {
			$uibModalInstance.dismiss('cancel');
		  };
		  
		  self.findKeyup = function () {
			  if(self.find.term !="") {
				    self.find.required = null;
			  }
		  }
		  self.replaceKeyup = function () {
			  if(self.replace.term !="") {
				    self.replace.required = null;
			  }
		  }
		  
		  function validateInput() {
			  var isValid = true;
			  if(!self.columns.selectedItem) {
	    			self.columns.required = true;
	    			isValid = false;
	    	  }
			  if(self.find.term =="") {
				    self.find.required = true;
				    isValid = false;
			  }
			  if(self.replace.term ==""){
				  self.replace.required = true;
				  isValid = false;
			  }
			  return isValid;
		  }

		  function createColumnDefs(columns) {
		      var columnDefs = [];
		      for (var i = 0; i < columns.length; i++) {

		          if (columns[i].displayName == "Validation Message" || columns[i].displayName == "urowid") {
		              //columnDefs.push({ "name": columns[i].displayName, "displayName": columns[i].displayName, visible: false });
		          }
		          else {
		              columnDefs.push({ "name": columns[i].displayName, "displayName": columns[i].displayName, visible: true });
		          }
		      }
		      return columnDefs;
		  }

 	}])
	 .controller('migrateModalInstanceController', ['$uibModalInstance', 'canSkipValidation', 'IsValidationAssociated', function ($uibModalInstance, canSkipValidation, IsValidationAssociated) {
		 var self = this;
		  self.noMigrateWithFailedValidation = true;
		  self.canSkipValidation = canSkipValidation;
		  self.isValidationAssociated = IsValidationAssociated;
		  //if(!canSkipValidation) {
			  
		  //    self.noMigrateWithFailedValidation = true;
	     //}
		  if (!self.isValidationAssociated) {
		      self.noMigrateWithFailedValidation = false;
		  }
		  self.ok = function ($event) {
		      $uibModalInstance.close(self.noMigrateWithFailedValidation);
		   }

		  self.cancel = function () {
			$uibModalInstance.dismiss('cancel');
		  };
	
	 	}])
	 .controller('dataEnvironmentModalInstanceController', ['$uibModalInstance','modalMessage',function ($uibModalInstance, modalMessage){
		 var self = this;
		  self.message = modalMessage;
		  self.ok = function ($event) {
		       $uibModalInstance.close("OK");
		  }
		  self.cancel = function () {
			$uibModalInstance.dismiss('cancel');
		  };
	
	 	}]);
 	
	
	 function mappingTablesController (constantService, $state,$templateCache,$timeout,$uibModal,$scope, uiGridConstants, uiGridExporterConstants,$http,spinnerService,mappingTablesService, errorHandlerService) {
		
	     var self = this;

	     self.getGridWidth = function () {
	         return $('#gridContainer').width();
	     };

        self.pageName ="Mapping Table Manage";
        self.isFullScreenMode = false;
        self.showTable = false;
        self.isFilterVisible = false;
        self.fullScreenButtonText = "View Full Screen";
        self.filterButtonText ="Show Filter";
        self.uiGridConstants = uiGridConstants;
        self.Title = "This is Title";
        self.totalPages;
        self.loadedPages;
        self.showProgressBar = false;
        self.validationSummary = [];
        self.dataEnvironment ="CURRENT";
 		self.closeValidationSummary = function(index) {
 			self.validationSummary.splice(index, 1);
 		};
 		
        self.AvailableMappingTables = {
    			'buttonLabel':'Select Mapping Table',
    			'items': [],
    			'selectedItem':null,
    			'status': { 'isopen':false},
    			'required': null,
    			'loading': false
    	};
        self.allowedActions = {};
        self.exportUrl ="";
        self.searchValue ="";
        self.AvailableMappingTables.loading = true;
        mappingTablesService.getAllMappingTables({ "gridWidth": self.getGridWidth() }, allMappingTablesCallback, errorCallback);
        //Note: backup ui-grid/uiGridViewport template 
        $templateCache.put("ui-grid/uiGridViewport_original", $templateCache.get("ui-grid/uiGridViewport"));
        $templateCache.put('ui-grid/uiGridViewport',
        	    "<div class=\"ui-grid-viewport\" ng-style=\"colContainer.getViewportStyle()\"><div class=\"ui-grid-canvas\"><div ng-repeat=\"(rowRenderIndex, row) in rowContainer.renderedRows track by $index\" ng-if=\"!row.entity.deleted || row.entity.deleted==false\" class=\"ui-grid-row\" ng-style=\"Viewport.rowStyle(rowRenderIndex)\"><div ui-grid-row=\"row\" row-render-index=\"rowRenderIndex\"></div></div></div></div>"
        	  );
        self.gridOptions = {
                //enableGridMenu: true,
        		rowTemplate:
        		'<div ng-class="{ \'row-validation\':grid.appScope.rowFormatter( row ) }">' +
                '  <div ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.colDef.name" class="ui-grid-cell" ng-class="{ \'ui-grid-row-header-cell\': col.isRowHeader }"  ui-grid-cell></div>' +
                '</div>',
                enableColumnMenus:false,
                rowEditWaitInterval: -1,
                enableSelectAll: true,
                enableRowSelection: true,
                exporterCsvFilename: 'myFile.csv',
                enableFiltering: false,
                enableSorting: false,
              
                showGridFooter: true,
                importerDataAddCallback: function (grid, newObjects) {
                    console.log(newObjects);
                    //$scope.data = $scope.data.concat( newObjects );
               
                },
                gridFooterTemplate: "<div class=\"ui-grid-footer-info ui-grid-grid-footer\"><span>{{'search.totalItems' | t}} {{grid.rows.length - grid.appScope.deletedRows}}</span><span ng-if=\"grid.selection.selectedCount !== 0 && grid.options.enableFooterTotalSelected\"> ({{\"search.selectedItems\" | t}} {{grid.appScope.selectedRows}})</span> <span ng-if=\"grid.renderContainers.body.visibleRowCache.length !== grid.rows.length\" class=\"ngLabel\">({{\"search.showingItems\" | t}} {{grid.renderContainers.body.visibleRowCache.length}})</span></div>",
        };
        
     
        self.gridOptions.onRegisterApi = function (gridApi) {
            self.gridApi = gridApi;
            gridApi.grid.appScope.deletedRows = 0;
            gridApi.grid.appScope.rowFormatter = function( row ) {
                return row.entity.validationMsg !=""; 
            };
            
            gridApi.grid.appScope.showRow = function(row) {
            	var shown = true;
            	if(row.entity.deleted && row.entity.deleted ==true) {
            		shown = false;
            	}
            	return shown;
            }
            
            gridApi.selection.on.rowSelectionChanged($scope, function (row) {
                row.entity.IsSelected = true;
                gridApi.grid.appScope.selectedRows =  gridApi.grid.selection.selectedCount;
                if(gridApi.grid.selection.selectedCount == self.gridOptions.data.length) {
                	gridApi.grid.appScope.selectedRows = gridApi.grid.appScope.selectedRows - gridApi.grid.appScope.deletedRows;
                }
                
            });

            gridApi.selection.on.rowSelectionChangedBatch($scope, function (rows) {
                for (var rowIndex = 0; rowIndex < rows.length; rowIndex++) {
                   
                    rows[rowIndex].entity.IsSelected = true;
                }
                gridApi.grid.appScope.selectedRows =  gridApi.grid.selection.selectedCount;
              
                if(gridApi.grid.selection.selectedCount == self.gridOptions.data.length) {
                	gridApi.grid.appScope.selectedRows = gridApi.grid.appScope.selectedRows - gridApi.grid.appScope.deletedRows;
                }
            });
            
        };
        
        self.createNewRow = function () {
            mappingTablesService.createNewRow();
            if(self.gridApi.grid.rows[0]) {
            	self.gridApi.core.scrollTo(self.gridApi.grid.rows[0].entity, self.gridOptions.columnDefs[2]);
            }
        };
        
        self.addMultiple = function () {
			var modalInstance = $uibModal.open({
			  templateUrl: 'importFileModal.html', //refers to modal content
			  controller: 'fileModalInstanceController as fmc', //inner controller
			  ariaLabelledBy: 'modal-title',
			  ariaDescribedBy: 'modal-body',
			  resolve: {
  	  		      modalColumnDefs: function () {
  	  		        return self.gridOptions.columnDefs;
  	  		      }
  	  		 }
			});
			modalInstance.result.then(function (fileObject) {
			      var index = fileObject.length - 1;
			      for(var i = 0; i < fileObject.length; i++) {
			    	  mappingTablesService.addRowToTop(fileObject[index--]);
			      }
			      $timeout( function() {
			    	  self.gridApi.rowEdit.setRowsDirty(fileObject);
			      });
			      if(self.gridApi.grid.rows[0]) {
			    	  self.gridApi.core.scrollTo(self.gridApi.grid.rows[0].entity, self.gridOptions.columnDefs[2]);
			      }
			      self.validationSummary = [{ type: "info", msg: fileObject.length + ' row(s) added.'}];
			    }, function () {
			        console.log('Modal dismissed at: ' + new Date());
			});

		};
		
        self.replace = function () {
        	var modalInstance = $uibModal.open({
    			  templateUrl: 'replaceModalContent.html', //refers to modal content
    			  controller: 'findReplaceModalInstanceController as frmc', //inner controller
    			  scope: $scope, //scope elements
    			  ariaLabelledBy: 'modal-title',
    			  ariaDescribedBy: 'modal-body',
  	  		  resolve: {
  	  		      modalColumnDefs: function () {
  	  		    	var availableFindColumns = [];
  	  		    	angular.forEach(self.gridOptions.columnDefs, function (gridColumnDefViewModel, index) {
  	  		    	    if (gridColumnDefViewModel.displayName != "validationMsg" && gridColumnDefViewModel.field != "Data[0]") {
	  	        			availableFindColumns.push(gridColumnDefViewModel);
	  	        		}
  	                });
  	  		        return availableFindColumns;
  	  		      }
  	  		  }
    		});
    		modalInstance.result.then(function (response) {
    			    console.log(response);
    			    var colIndex = response.column.field.match(/\d+/); // field looks like, for example  Data[1].
    			    var rowsAffected = [];
    				var dataTableVM = mappingTablesService.getDataTableVM();
    	            if (response.findText!= "") {
    	                for (var i = 0; i < dataTableVM.Rows.length; i++) {
    	                    var row = dataTableVM.Rows[i];     
    	                    if (row.Data[colIndex] === response.findText) {
    	                         row.Data[colIndex] = response.replaceText;
    	                         rowsAffected.push(row);
    	                    } 
    	                    //console.log("find & replace");
    	                    //console.log(row);
    	                }
    	               if(rowsAffected.length > 0) {
	    	               $timeout( function() {
	  	  			    	  self.gridApi.rowEdit.setRowsDirty(rowsAffected);
	  	  			       });
    	               }
    	               else {
    	            	   self.validationSummary = [{ type: 'info', msg: '"' + response.findText + '" not found'}];
    	               }
    	            }
    	            
    			}, function () {
    			      console.log('Modal dismissed at: ' + new Date());
    			});    
            
        };

        self.ChangeTitle = function () {
            self.Title = "TItle is changed.";
        };

       
        self.selectMappingTable = function(selectedTable) {
        	
        	self.AvailableMappingTables.selectedItem = selectedTable;
        	self.AvailableMappingTables.buttonLabel = selectedTable.Name;
        	self.allowedActions = mappingTablesService.getAllowedActions(self.AvailableMappingTables.selectedItem.Id);
            
            //if selectedTable doesn't have validation registered, do not show validation button
        	if (self.allowedActions.validate === true && selectedTable.IsValidationAssociated === false)
        	{
        	    self.allowedActions.validate = false;
        	}
        	
        	if(self.allowedActions.migrate) {
        		self.dataEnvironment ="LOWER";
        	}
        	if(self.allowedActions.migrate && self.dataEnvironment =="LOWER") {
        		mappingTablesService.setTableId_lwr(selectedTable.Id);
        	}
        	else {
        		mappingTablesService.setTableId(selectedTable.Id);
            }
        	
        	self.exportUrl = mappingTablesService.getExportUrl();
        	mappingTablesService.setRowsPerPage(constantService.MAPPING_TABLE_ROWS_PER_PAGE);
        	mappingTablesService.loadFirstPage({}, getFirstPageCallback, errorCallback);
        	self.gridApi.grid.registerRowsProcessor( self.searchFilter, 200 );
        };
        
        self.showFilter = function () {
        	self.isFilterVisible = !self.isFilterVisible;
        	if(self.isFilterVisible === true) {
        		 self.filterButtonText = "Hide Filter";
        		 self.gridApi.core.clearAllFilters();
        	}
        	else {
        		self.filterButtonText = "Show Filter";
        	}
            self.gridOptions.enableFiltering = !self.gridOptions.enableFiltering;
            self.gridApi.core.notifyDataChange(uiGridConstants.dataChange.COLUMN);
        };
        
        self.search = function() {
        	self.gridApi.grid.refresh();
        }
        
        self.searchFilter = function( renderableRows ){
            var matcher = new RegExp(self.searchValue);
            var searchFields = mappingTablesService.getSearchFields(self.AvailableMappingTables.selectedItem.Id);
            renderableRows.forEach( function( row ) {
              var match = false;
             searchFields.forEach(function( field ){
                if ( row.entity.Data[field].match(matcher) ){
                 match = true;
                }
              });
              if ( !match ){
                row.visible = false;
              }
            });
            return renderableRows;
        };
        
    
        self.save = function() {
        	var modalInstance = $uibModal.open({
			  templateUrl: 'saveModalContent.html', //refers to modal content
			  controller: 'saveModalInstanceController as smc', //inner controller
			  scope: $scope, //scope elements
			  ariaLabelledBy: 'modal-title',
			  ariaDescribedBy: 'modal-body',
			  resolve: { canSkipValidation: function () { 
				  						return  self.AvailableMappingTables.selectedItem.CanSkipValidation;
			                            },
			            IsValidationAssociated: function () {
			                            return self.AvailableMappingTables.selectedItem.IsValidationAssociated;
			                            }
        	           }
			});
			modalInstance.result.then(function (noSaveWithFailedValidation) {
				var payload = getRequestPayload();
				payload.IsForceSave = !noSaveWithFailedValidation;
				spinnerService.show("overlaySpinner");
	        	mappingTablesService.save(payload, saveCallback,saveErrorCallback);
	        	//console.log(payload);
			    }, function () {
			      console.log('Modal dismissed at: ' + new Date());
			});
		
        };
        
        self.migrate = function() {
        	if(self.dataEnvironment == "CURRENT") {
        		switchToChangeControlDataEnvironment("You need to switch to Change Control data view to migrate. would you like to switch to change Control data view?");
        	    return;
        	}
        	var modalInstance = $uibModal.open({
			  templateUrl: 'migrateModalContent.html', //refers to modal content
			  controller: 'migrateModalInstanceController as mmc', //inner controller
			  scope: $scope, //scope elements
			  ariaLabelledBy: 'modal-title',
			  ariaDescribedBy: 'modal-body',
			  resolve: { canSkipValidation: function () { 
											return self.AvailableMappingTables.selectedItem.CanSkipValidation;
			                                },
			            IsValidationAssociated: function () {
			                                return self.AvailableMappingTables.selectedItem.IsValidationAssociated;
			                                }
			  			}
			});
			modalInstance.result.then(function (noMigrateWithFailedValidation) {
				var payload = {"MappingTableId":self.AvailableMappingTables.selectedItem.Id} ; // to do: what is the payload for migrate?
				payload.IsForceSave = !noMigrateWithFailedValidation;
				payload.TotalRows = self.gridOptions.data.length;
				spinnerService.show("overlaySpinner");
	        	mappingTablesService.migrate(payload, migrateCallback,migrateErrorCallback);
	        	//console.log(payload);
			    }, function () {
			      console.log('Modal dismissed at: ' + new Date());
			});
		
        };

        self.remove = function () {
        	if(self.gridApi.selection.getSelectedRows().length < 1)
        	{
        		self.validationSummary = [{ type: 'info', msg: 'No rows selected for Remove.'}];
        		return;
        	}
        	
        	var modalInstance = $uibModal.open({
  			  templateUrl: 'removeModalContent.html', //refers to modal content
  			  controller: 'removeModalInstanceController as rmc', //inner controller
  			  scope: $scope, //scope elements
  			  ariaLabelledBy: 'modal-title',
  			  ariaDescribedBy: 'modal-body',
  			});
  			modalInstance.result.then(function (confirm) {
  				var dataTableVM = mappingTablesService.getDataTableVM();
  				var selectedRows = self.gridApi.selection.getSelectedRows();
  	            angular.forEach(selectedRows, function (entity, index) {
  	            	dataTableVM.DeletedRows.push(entity);
  	            	console.log(self.gridOptions.data.indexOf(entity));
  	                //self.gridOptions.data.splice(self.gridOptions.data.indexOf(entity), 1);
  	            	entity.deleted = true;
  	            	self.gridApi.grid.appScope.deletedRows++;
  	            });
  	           
			    self.gridApi.rowEdit.setRowsClean(selectedRows);
			    self.gridApi.selection.clearSelectedRows();
			    self.validationSummary = [{ type: 'info', msg: selectedRows.length + " row(s) removed from the data grid."}];
  			    }, function () {
  			      console.log('Modal dismissed at: ' + new Date());
  			});
        	 
        };
        
        self.ExportToCSV = function () {
            var myElement = angular.element(document.querySelectorAll(".custom-csv-link-location"));
            self.gridApi.exporter.csvExport(uiGridExporterConstants.ALL, uiGridExporterConstants.VISIBLE, myElement);
        };


        self.ToggleScreenMode = function (header, footer) {
            self.isFullScreenMode = !self.isFullScreenMode;
            if (self.isFullScreenMode === true) {
                self.fullScreenButtonText = "Exit Full Screen";
                var gridContainerHeight = 500 + jQuery(header).height() + jQuery(header).height();
                jQuery(header).addClass("ng-hide");
                jQuery(footer).addClass("ng-hide");
                jQuery('#gridContainer').css("height", gridContainerHeight + "px");
            }
            else {
                self.fullScreenButtonText = "View Full Screen";
                jQuery(header).removeClass("ng-hide");
                jQuery(footer).removeClass("ng-hide");
                jQuery('#gridContainer').css("height","500px");
            }
            
        };

        self.validate = function(){
        	if(self.dataEnvironment == "CURRENT" && self.allowedActions.migrate) {
        		switchToChangeControlDataEnvironment("You need to switch to Change Control data view to validate. would you like to switch to Change Control data view?");
        	}
        	var payload = getRequestPayload();
        	//console.log(payload);
        	spinnerService.show("overlaySpinner");
        	mappingTablesService.validate(payload, validateCallback,validateErrorCallback);
        }
        
        self.changeDataEnvironment = function () {
        	if(self.allowedActions.migrate && self.dataEnvironment =="LOWER") {
        		mappingTablesService.setTableId_lwr(self.AvailableMappingTables.selectedItem.Id);
        	}
        	else { // load current environment data
        		mappingTablesService.setTableId(self.AvailableMappingTables.selectedItem.Id);
        		self.gridOptions.columnDefs[0].visible = false;
        		
            }
        	
        	self.exportUrl = mappingTablesService.getExportUrl();
        	mappingTablesService.setRowsPerPage(constantService.MAPPING_TABLE_ROWS_PER_PAGE);
        	mappingTablesService.loadFirstPage({}, getFirstPageCallback, errorCallback);
        }
        
        
        self.exportFile = function () {
        	
        	mappingTablesService.getSignedKey({},getSignedKeyCallback,errorCallback);
        	
        }
        
        self.clearValidateResults = function() {
        	mappingTablesService.clearValidateResults();
        	self.gridOptions.columnDefs[0].visible = false;
        	self.gridApi.grid.refresh();
        }
        
        function switchToChangeControlDataEnvironment(message) {
        	
    		var modalInstance = $uibModal.open({
    			  templateUrl: 'dataEnvironmentModalContent.html', //refers to modal content
    			  controller: 'dataEnvironmentModalInstanceController as dec', //inner controller
    			  scope: $scope, //scope elements
    			  ariaLabelledBy: 'modal-title',
    			  ariaDescribedBy: 'modal-body',
    			  resolve: {modalMessage: function() {
    				  return message; }
    			  }
    			});
    			modalInstance.result.then(function (confirm) {
    				 self.dataEnvironment ="LOWER"
    			     self.changeDataEnvironment();
    			    }, function () {
    			      console.log('Modal dismissed at: ' + new Date());
    			});
        }
        
        function getRequestPayload() {
        	//get changed rows, it contains updated rows, newly added rows
        	var gridRows = self.gridApi.rowEdit.getDirtyRows();
        	var dataTableVM = mappingTablesService.getDataTableVM();
        	dataTableVM.ChangedRows  =[];
        	 angular.forEach(gridRows, function (gridRow, index) {
        		 dataTableVM.ChangedRows.push(gridRow.entity);
            });
        	//console.log("changed rows: " + dataTableVM.ChangedRows.length);
        	//console.log(dataTableVM.ChangedRows); 
        	var payload = mappingTablesService.buildRequestLoad();
        	return payload;
        }
        
        function allMappingTablesCallback(response) {
        	var resp = response;
            self.AvailableMappingTables.loading = false;
        	spinnerService.hide("overlaySpinner");
        	self.AvailableMappingTables.items = mappingTablesService.getSelectableTables();
       }
        
        function getFirstPageCallback(response) {
        	var mappingTableVM = mappingTablesService.getDataTableVM();
        	self.gridOptions.columnDefs = mappingTablesService.getGridColumnDefs(self.AvailableMappingTables.selectedItem.Id);
        	if(self.allowedActions.add == false) {
        		setReadonlyView ();
        	}
        	else {
        		setEditView ();
        	}
        	self.gridOptions.data = mappingTableVM.Rows;
        	self.totalPages = mappingTableVM.TotalPages;
        	self.loadedPages = 1;
        	if(mappingTableVM.Rows.length > 0) {
        		self.showProgressBar = true; 
        	}
        	if(self.totalPages < 2) {
        		self.showProgressBar = false;
        	}
        	
        	self.showTable = true;

        	mappingTablesService.loadMorePages({},getMorePagesCallback,errorCallback);
        }
        
        function getMorePagesCallback(response) {
        	var mappingTableVM = mappingTablesService.getDataTableVM();
        	self.loadedPages = mappingTableVM.PagesLoaded.length;
        	if(mappingTableVM.PagesLoaded.length === mappingTableVM.TotalPages){
        		self.showProgressBar = false;
            }	
        }

        function validateCallback(response){
        	var resp = response;
        	self.validationSummary = [{ type: response.message.type, msg: response.message.text}];
        	if(self.gridOptions.columnDefs[0].visible) {
	        	self.gridOptions.columnDefs[0].visible = false;
	        	self.gridApi.grid.refresh();
        	}    
        	spinnerService.hide("overlaySpinner");
        }
        
        function saveCallback(response){
        	var resp = response;
        	
        	self.gridApi.selection.clearSelectedRows();
        	var gridRows = self.gridApi.rowEdit.getDirtyRows();
        	var dataRows = gridRows.map(function (gridRow) { return gridRow.entity; });
        	self.gridApi.rowEdit.setRowsClean(dataRows);
        	
        	self.validationSummary = [{ type: response.message.type, msg: response.message.text}];
        	//reload the pages from server if no validation or passed validation
        	if(self.gridOptions.columnDefs[0].visible) {
	        	self.gridOptions.columnDefs[0].visible = false;
        	}   
        	self.gridApi.grid.refresh();
        	mappingTablesService.setTableId(self.AvailableMappingTables.selectedItem.Id);
        	self.gridApi.grid.appScope.deletedRows = 0;
        	mappingTablesService.setRowsPerPage(constantService.MAPPING_TABLE_ROWS_PER_PAGE);
        	mappingTablesService.loadFirstPage({}, getFirstPageCallback, errorCallback);
        	spinnerService.hide("overlaySpinner");
        	
        	
        	console.log(gridRows);
        }
        function saveErrorCallback(data) {
    		//console.log(data);
    		if(data.validationResults)
    		{
    			self.gridApi.grid.appScope.deletedRows = self.gridApi.grid.appScope.deletedRows - data.undeletedRows;
    			self.validationSummary = [{ type: 'danger', msg: data.validationResults[0].Data.length + ' of ' + self.gridApi.grid.rows.length + ' rows failed validation. Refer to "Validation Message" column to correct errors.'}];
    			self.gridOptions.columnDefs[0].visible = true;
    		}
    		else if(data.message) {
    			self.validationSummary = [{ type: data.message.type, msg: data.message.text}];
    			errorHandler(data);
    		}
    		
    		spinnerService.hide("overlaySpinner");
    		self.gridApi.grid.refresh();
       }
        
        function migrateCallback(response){
        	var resp = response;
        	self.validationSummary = [{ type: response.message.type, msg: response.message.text}];
        	if(self.gridOptions.columnDefs[0].visible) {
	        	self.gridOptions.columnDefs[0].visible = false;
	        	self.gridApi.grid.refresh();
        	}    
            //after migrate successfully, load data of current version
        	mappingTablesService.setTableId(self.AvailableMappingTables.selectedItem .Id);
        	mappingTablesService.setRowsPerPage(constantService.MAPPING_TABLE_ROWS_PER_PAGE);
        	mappingTablesService.loadFirstPage({}, getFirstPageCallback, errorCallback);
        	spinnerService.hide("overlaySpinner");
        }
        
        function getSignedKeyCallback(response) {
        	var resp = response;
        	window.open(self.exportUrl + '&signedUrl=' + response.data);
        	
        }
        
        function setReadonlyView () {
        	self.gridOptions.enableRowSelection = false;
        	self.gridOptions.enableSelectAll= false;
        	self.gridOptions.isRowSelectable = function() { return false; };
        	for(var i=0; i < self.gridOptions.columnDefs.length; i++) {
        		self.gridOptions.columnDefs[i].cellEditableCondition = false;
        	}
        	self.gridApi.core.notifyDataChange(uiGridConstants.dataChange.ALL);
        }
        
        function setEditView () {
        	self.gridOptions.enableRowSelection = true;
        	self.gridOptions.enableSelectAll= true;
        	self.gridOptions.isRowSelectable = function(row) { return true };;
        	for(var i=0; i < self.gridOptions.columnDefs.length; i++) {
        		if(self.gridOptions.columnDefs[i].field =='validationMsg') {
        			self.gridOptions.columnDefs[i].cellEditableCondition = false;
        			self.gridOptions.columnDefs[i].displayName ="Validation Message";
        		}
        		else {
        			self.gridOptions.columnDefs[i].cellEditableCondition = true
        		}	
        	}
        	self.gridApi.core.notifyDataChange(uiGridConstants.dataChange.ALL);
        }
        function migrateErrorCallback(data) {
        	validateErrorCallback(data);
        	errorHandler(data);
        	spinnerService.hide("overlaySpinner");
       }
        
        function validateErrorCallback(data) {
    		//console.log(data);
    		spinnerService.hide("overlaySpinner");
    		 if(data.validationResults)
     		{
    			self.gridApi.grid.appScope.deletedRows = self.gridApi.grid.appScope.deletedRows - data.undeletedRows;
     			self.validationSummary = [{ type: 'danger', msg: data.validationResults[0].Data.length + ' of ' + self.gridApi.grid.rows.length + ' rows failed validation. Refer to "Validation Message" column to correct errors.'}];
     			self.gridOptions.columnDefs[0].visible = true; //validationMsg column
     		}
     		else if(data.message) {
     			self.validationSummary = [{ type: data.message.type, msg: data.message.text}];
     			self.gridOptions.columnDefs[0].visible = false; //validationMsg column
     			errorHandler(data);
     		}
    		
    		self.gridApi.grid.refresh();
       }
        
       function errorCallback(data) {
    	    self.AvailableMappingTables.loading = false;
    		console.log(data);
    		spinnerService.hide("overlaySpinner");
       }	
       
       function errorHandler(data) {
   		if (data.status =="401") {
   			errorHandlerService.addError(data.message.text);
   			$state.go("error");
   		}
   		
   	}
       
    };
    

})(window.jQuery);


