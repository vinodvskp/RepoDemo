(function () {
  angular.module('vmApp').service('mappingTablesService', ['$q', '$http','authenticationService','serverVariableService',mappingTablesService]);

  //service class
  function mappingTablesService($q, $http, authenticationService,serverVariableService) {
	    var self = this;
        var _DataTableVM = null;
        var _allMappingTables = [];
        var _selectableTables  = [];
        var _allColumnDefs =[];
        var _userRoleTypesForTables = [];
        var _userAllowedActionsForTables =[];
        var _previousValidateResults = null;
        var _firstPageOperation ="";
        var _morePagesOperation =""
        self.setRowsPerPage = function(rowsPerPage) {
        	_DataTableVM.RowsPerPage =rowsPerPage;
        }
        
        self.getRowsPerPage = function(){
        	return _DataTableVM.RowsPerPage;
        }
        
        self.setTableId = function(tableId) {
        	_firstPageOperation ="GetMappingTableFirstPageData";
        	_morePagesOperation ="GetMappingTablePageData";
        	_DataTableVM = new DataTableViewModel();
            //_DataTableVM.ExportUrl = serverVariableService.MT_ENDPOINT() + '/ExportMappingTable/' + tableId;
        	_DataTableVM.ExportUrl = serverVariableService.MT_ENDPOINT() + '/ExportMappingTable?mappingTableId=' + tableId;
        	_DataTableVM.tableId = tableId;
        	_DataTableVM.Columns = self.getColumns(tableId);
        	_previousValidateResults = null;
        	
        }
        
        self.setTableId_lwr = function(tableId) {
        	_firstPageOperation ="GetMappingTableFirstPageDataFromLowerEnv";
        	_morePagesOperation ="GetMappingTablePageDataFromLowerEnv";
        	_DataTableVM = new DataTableViewModel();
        	_DataTableVM.ExportUrl = serverVariableService.MT_ENDPOINT() + '/ExportMappingTable/' + tableId;
        	_DataTableVM.tableId = tableId;
        	_DataTableVM.Columns = self.getColumns(tableId);
        	_previousValidateResults = null;
        	
        }
        self.getExportUrl = function() {
        	return _DataTableVM.ExportUrl;
        }
        self.getTableId = function(){
        	return _DataTableVM.tableId;
        }
        
        
        self.getGridColumnDefs = function(tableId) {
        	var columnDefs = {};
        	for(var i =0; i< _allColumnDefs.length; i++) {
        		if(_allColumnDefs[i].tableId == tableId) {
        			columnDefs = _allColumnDefs[i].ColumnDefs;
        			break;
        		}
        	}
        	return columnDefs;
        }
        
        self.getSearchFields = function(tableId){
        	var searchFields =[];
        	var columnDefs = self.getGridColumnDefs(tableId);
        	var colIndex=1; 
        	angular.forEach(columnDefs, function (gridColumnDefViewModel, index) {
        		// important assumption: the datakey and validateMsg are the first two column defs.
        		if(gridColumnDefViewModel.field !="validationMsg" && gridColumnDefViewModel.field !="Data[0]") {
        			searchFields.push(colIndex++);
        		}
               });
        	return searchFields;  	
        }
        
        self.getColumns = function(tableId) {
        	var columns = {};
        	for(var i =0; i < _allColumnDefs.length; i++) {
	        	if(_allColumnDefs[i].tableId == tableId) {
	        		columns = _allColumnDefs[i].Columns;
	    			break;
	    		}
        	}
        	return columns;
        }
        
        self.getAllowedActions = function(tableId) {
        	var allowdActions = {};
        	for (var i = 0; i <_userAllowedActionsForTables.length; i++) {
        		if(_userAllowedActionsForTables[i].tableId ==tableId)
        			{
        				allowdActions=  _userAllowedActionsForTables[i];
        				break;
        			}
        	}
        	return allowdActions;
        }
        
        self.getSelectableTables = function (){
        	return _selectableTables;
        }
        
        self.getDataTableVM = function(){
        	return _DataTableVM;
        }
        
        self.getAllMappingTables = function (payload,successCallback,errorCallback) {
        	
        	authenticationService.serviceCallDispatcher(payload,getAllMappingTablesWorker,successCallback,errorCallback);
        	
        }
        
	    self.loadFirstPage = function(payload,successCallback,errorCallback) {
	    	payload.pageNumber = 1;
	    	authenticationService.serviceCallDispatcher(payload,getMappingTableFirstPageWorker,successCallback,errorCallback);
	    }
	    
	    self.loadMorePages = function(payload,successCallback,errorCallback) {
	    	 for (var pageIndex = 2; pageIndex <= _DataTableVM.TotalPages; pageIndex++) {
	    		 authenticationService.serviceCallDispatcher({pageNumber:pageIndex},getMappingTablePageWorker,successCallback,errorCallback);
	         }
	    	
	    }
	    
	    self.validate = function(payload,successCallback,errorCallback) {
	    	authenticationService.serviceCallDispatcher(payload,validateMappingWorker,successCallback,errorCallback);
	    	
	    }
	    
	    self.save = function(payload,successCallback,errorCallback) {
	    	authenticationService.serviceCallDispatcher(payload,saveMappingWorker,successCallback,errorCallback);
	    	
	    }
	    
	    self.migrate= function(payload,successCallback,errorCallback) {
	    	authenticationService.serviceCallDispatcher(payload,migrateMappingWorker,successCallback,errorCallback);
	    	
	    }
	    	    
	    self.getAllRoles = function () {
	        return [{ Id: 1, Name: "READ" }, { Id: 2, Name: "EDIT" }, { Id: 3, Name: "MIGRATE" }];
	    };
	    	
	    self.createNewRow = function() {
	    	return _DataTableVM.CreateNewRow();
	    }
	    
	    self.createBlankRow = function() {
	    	return new TableRowViewModel();
	    }
	    
	    self.addRowToTop = function(tableRowViewModel) {
	    	_DataTableVM.AddRowToTop(tableRowViewModel);	
	    }
	    
	    self.getDeletedRecordIds = function() {
	    	return _DataTableVM.getDeletedRecordIds();
	    }
	    self.getAddedRecords = function() {
	    	return _DataTableVM.getAddedRecords();
	    }
	    
	    self.getModififedRecords = function() {
	    	return _DataTableVM.getModififedRecords();
	    }
	    
	    self.buildRequestLoad = function() {
	    	var deletedRecordIds = self.getDeletedRecordIds();
        	var addedRecords = self.getAddedRecords();
        	var modifiedRecords = self.getModififedRecords();
        	var editOrMigrate = 1;
        	var allowedActions = self.getAllowedActions(self.getTableId());
        	if(allowedActions.migrate) {
        		editOrMigrate = 2;
        	}
        	var payload = {"AddRecords":addedRecords,
        			"DeletedRecords":deletedRecordIds,
        			"IsForceSave":false,
        			"MappingTableId":self.getTableId(),
        			"ModifiedRecords":modifiedRecords,
        			"RequestType":editOrMigrate
        			};
        	return payload;
	    }
	    
	    self.getSignedKey = function(payload,successCallback,errorCallback) {
	    	authenticationService.serviceCallDispatcher(payload,getSignedKeyWorker,successCallback,errorCallback);
	    }
	    
	    self.clearValidateResults = function () {
	    	 clearPreviousValidateResults();
	    }
	  function buildColumnDefs(allMappingTables, gridWidth){
		  var allColumnDefs =[];
			angular.forEach(allMappingTables, function (tableInfo, index) {
			   var columnDefs = { "tableId": tableInfo.Id, "Columns": tableInfo.Columns, "ColumnDefs": [] };
			   var colListVM = isColumnWidthComputationNeeded(tableInfo.Columns, gridWidth);
			   var validationColDef = new GridColumnDefViewModel("validationMsg", 'validationMsg', false, colListVM);
			   validationColDef.enableCellEditOnFocus = false;
			   columnDefs.ColumnDefs.push(validationColDef);
			   for (var colIndex = 0; colIndex < tableInfo.Columns.length; colIndex++) {
				   var isVisible = (colIndex ==0? false:true);
				   var colDef = new GridColumnDefViewModel(tableInfo.Columns[colIndex], 'Data[' + colIndex + ']', isVisible, colListVM);
	                columnDefs.ColumnDefs.push(colDef);
	            }
				allColumnDefs.push(columnDefs);
             });
		  return allColumnDefs;
	  }

	  function calculateTotalColumnWidth(colList) {
	      var totalColWidth = 0;
	      var colListVM = { "totalColWidth": totalColWidth, "colWidthList": [] };
	      for (var colInd = 0; colInd < colList.length; colInd++) {
	          var colWidth = calculateColWidth(colList[colInd]);
	          colListVM.totalColWidth = colListVM.totalColWidth + colWidth;
	          colListVM.colWidthList.push(colWidth);
	      }
	      return colListVM;
	  }

	  function isColumnWidthComputationNeeded(colList, gridWidth) {
	      var colListVM = calculateTotalColumnWidth(colList);
	      var isNeeded = false;
	      if (colListVM.totalColWidth > gridWidth) {
	          isNeeded = true;
	      }
	      $.extend(colListVM, {"isColWidthComputeNeeded": isNeeded});
	      return colListVM;
	  }
	  
	  function buildSelectableTables (allMappingTables) {
		  var selectableTables =[];
			angular.forEach(allMappingTables, function (tableInfo, index) {
			    var tableItem = { "Id": tableInfo.Id, "Name": tableInfo.Name, "CanSkipValidation": tableInfo.CanSkipValidation, "IsValidationAssociated": (tableInfo.Validation === null || tableInfo.Validation.length === 0 ? false : true) };
			   selectableTables.push(tableItem);
           });
		  return selectableTables;
	  }
	  
    
	  function buildAllowedActions (allUserRoleTypes) {
		  var allowedActions =[];
			angular.forEach(allUserRoleTypes, function (roleTypes, index) {
		    //note: assume one role type per table
			var actionList = {};
			switch (roleTypes.UserRoleType[0]) {
	    	  case UserRoleTypeEnum.READ:
	    	      actionList = $.extend(true, {}, ReadonlyActions);
	    		  break;
	    	  case UserRoleTypeEnum.EDIT:
	    	      actionList = $.extend(true, {}, EditActions);
	    		  break;
	    	  case UserRoleTypeEnum.MIGRATE:
	    	      actionList = $.extend(true, {}, MigrateActions);
	    		  break;
			}
			actionList.tableId = roleTypes.Id;
			allowedActions.push(actionList);
           });
		  return allowedActions;
	  }
	  
	  function getUserRoleTypes (allMappingTables) {
		  var userRoleTypes =[];
			angular.forEach(allMappingTables, function (tableInfo, index) {
			   var tableItem = {"Id":tableInfo.Id,"UserRoleType":tableInfo.UserRoleType};
			   userRoleTypes.push(tableItem);
           });
		  return userRoleTypes;
	  }
	    
	  function getAllMappingTablesWorker (authToken, payload) {
		  	return $http({
	             method: 'get',
	             headers: {'Authorization': authToken },
	             url: serverVariableService.MT_ENDPOINT() + '/GetAllMappingTables',
	             data: payload
	         })
	         .then(function(response) {
	        	 if(response.status == 200) {
	        		 
	        		 // this callback will be called asynchronously
	                 // when the response is available
	        		 _allMappingTables = [];
	        		 _allMappingTables.push.apply(_allMappingTables, response.data);
	        		 _userRoleTypesForTables = getUserRoleTypes(_allMappingTables);
	        		 _userAllowedActionsForTables = buildAllowedActions(_userRoleTypesForTables);
	        		 _allColumnDefs = buildColumnDefs(_allMappingTables, payload.gridWidth);
	        		 _selectableTables = buildSelectableTables(_allMappingTables);
	        		 return $q.when("successfully get all mapping table data");
	        	 }
	       		 else {
	       			 return $q.reject("request call does not return all mapping tables data");
	       		  }
	          }, function(response){
	          	var resp = response;
	          	//console.log("getRequestTypes service call failed");
	          	return $q.reject(resp);
	          });
	  	}
	  
	   function getMappingTableFirstPageWorker(authToken, payload) {
           return $http({
               method: 'GET',
               headers: {'Authorization': authToken },
               url: serverVariableService.MT_ENDPOINT()+ '/' + _firstPageOperation + '/' +  _DataTableVM.tableId + '/'+ _DataTableVM.RowsPerPage,
           }).then(function(r) {
               if(r.status==200 && r.data) {
	               var d = r.data.PagingInfo.Result;
	               _DataTableVM.Columns = self.getColumns(self.getTableId());
	               if (r.data.PagingInfo.PageNumber === 1) {
	            	   _DataTableVM.TotalResults = r.data.PagingInfo.TotalResults;
	            	   _DataTableVM.TotalPages = r.data.PagingInfo.TotalPages;
	            	   _DataTableVM.Data = [];
	                   var pageVM = new DataPageViewModel(1);
	                   for (var colIndex = 0; colIndex < d.length; colIndex++) {
	                       pageVM.Data.push(d[colIndex].Data);
	                   }
	                   _DataTableVM.PageData[0]=pageVM;
	                   _DataTableVM.PagesLoaded.push(r.data.PagingInfo.PageNumber);
	               }
	               _DataTableVM.PivotData2();
	               _DataTableVM.isDataLoaded = true;
	               //self.LoadMoreData2();
	               return $q.when("succussfully get the first page data");
               }
               else {
            	   
            	   return $q.reject(response);
               }

           }, function(response) {
               // called asynchronously if an error occurs
               // or server returns response with an error status.
        	   return $q.reject(response);
           });

	   }

	   function getMappingTablePageWorker(authToken, payload) {
		       var pageNumber = payload.pageNumber;
               return $http({
               method: 'GET',
               headers: {'Authorization': authToken },
               url: serverVariableService.MT_ENDPOINT() + '/' + _morePagesOperation + '/' +  _DataTableVM.tableId + '/' + payload.pageNumber + '/' + _DataTableVM.RowsPerPage +'/' + _DataTableVM.TotalResults,
               //url: "http://localhost:8080/VersionManagment/mtApp/testData/morePageData.json"
           }).then(function(r) {
               if(r.status == 200 && r.data) {
            	   var d = r.data.Result;
	               if (r.data.PageNumber > 1) {
	
	                   var pageVM = new DataPageViewModel(r.data.PageNumber);
	                   for (var colIndex = 0; colIndex < d.length; colIndex++) {
	                    
	                       pageVM.Data.push(d[colIndex].Data);
	                   }
	                   
	                   _DataTableVM.PageData[r.data.PageNumber -1] = pageVM;  
	                   _DataTableVM.PagesLoaded.push(r.data.PageNumber);
	                   
	                   if (_DataTableVM.PagesLoaded.length === _DataTableVM.TotalPages) {
	                       _DataTableVM.PivotMoreData2();
	                   }
	
	               }
	               return $q.when("succussfully get " + payload.pageNumber + " page data");
               }
               else {
            	   return $q.reject(r);
               }

           }, function (response) {
               // called asynchronously if an error occurs
               // or server returns response with an error status.
        	   return $q.reject(response);
           });
       }   
	   
	   function clearPreviousValidateResults() {
			if(_previousValidateResults) {
			    for (var i = 0; i < _previousValidateResults[0].Data.length; i++) {
			        //if (_DataTableVM.HashRows[_previousValidateResults[0].Data[i]] != null) {
			            _DataTableVM.HashRows[_previousValidateResults[0].Data[i]].validationMsg = "";
			        //}
	    		}  
			}
	   }
	   
	   function validateMappingWorker (authToken, payload) {
		   clearPreviousValidateResults();
		   var rowCount = getRequestPayloadRowCount(payload);
		   console.log(angular.toJson(payload));
		  	return $http({
	             method: 'POST',
	             headers: {'Authorization': authToken, "Content-Type":"application/json"},
	             url: serverVariableService.MT_ENDPOINT() + '/ValidateMappingTableData', // to do: need validation service
	             data: payload
	         })
	         .then(function(response) {
	        	 
	        	 if(response.status == 200) {
	        		 var validationResults = response.data.ValidationResults;
	        		//var validationResults = [{Data : ["AAEHJLABGAACZnzAAA","AAEHJLABGAACZnzAAB","AAEHJLABGAACZnzAAC"]},
	        		//                {Data:["validate msg 1","validate msg 2", "validate msg 3"]}];
	        		if(validationResults) {
	        			//mimic deleted records validation failure
	        			//validationResults[0].Data.push("AAEHJLABGAACZnzAAC");
	        			//validationResults[0].Data.push("AAEHJLABGAACZnzAAE");
	        			//validationResults[1].Data.push("foreign key violation");
	        			//validationResults[1].Data.push("cannot delete it");
	        			var undeletedRows = 0;
	        			_previousValidateResults = validationResults;
		        		for(var i=0; i <validationResults[0].Data.length; i++) {
		        			_DataTableVM.HashRows[validationResults[0].Data[i]].validationMsg = validationResults[1].Data[i];
		        			if(_DataTableVM.HashRows[validationResults[0].Data[i]].deleted && _DataTableVM.HashRows[validationResults[0].Data[i]].deleted ==true) {
		        				_DataTableVM.HashRows[validationResults[0].Data[i]].deleted = false;
		        				undeletedRows++;
		        			}
		        		}                  
		        		 
		        		return $q.reject({"submitRowCount": rowCount,"validationResults": validationResults,"undeletedRows":undeletedRows});
	        		}
	        		else {
	        			 return $q.when({"submitRowCount": rowCount, message:{type:"info", text:"Validated successfully."}});
	        		}
	        	 }
	       		 else {
	       			return $q.reject({"submitRowCount": rowCount, message:{type:"info", text:"Validation call failed."}});
	       		  }
	          }, function(response){
	          	var resp = response;
	          	//console.log("getRequestTypes service call failed");
	        	return $q.reject({"submitRowCount": rowCount, message: {type:"danger", text:response.data}, status:response.status});
	          });
	  	}
	  
	   function saveMappingWorker (authToken, payload) {
		   clearPreviousValidateResults();
		   var rowCount = getRequestPayloadRowCount(payload);
		  	return $http({
	             method: 'POST',
	             headers: {'Authorization': authToken,"Content-Type":"application/json"},
	             url: serverVariableService.MT_ENDPOINT() + '/SaveMappingTableData',
	             data: payload
	         })
	         .then(function(response) {
	        	 if(response.status == 200) {
	        		 var validationResults = response.data.ValidationResults;
	        		 //validationResults = [{Data : ["AAEHJLABGAACZnzAAA","AAEHJLABGAACZnzAAB","AAEHJLABGAACZnzAAC"]},
		        	 //                   {Data:["validate msg 1","validate msg 2", "validate msg 3"]}];	        		 

	        		 if (response.data.MessageType == 1) {
	        		     return $q.reject({ "submitRowCount": rowCount, message: { type: "danger", text: "Error occured while saving. (" + response.data.Message + ")" } });
	        		 }

	        		 if (validationResults) {
	        				var undeletedRows = 0;
		        			_previousValidateResults = validationResults;
			        		for(var i=0; i <validationResults[0].Data.length; i++) {
			        			_DataTableVM.HashRows[validationResults[0].Data[i]].validationMsg = validationResults[1].Data[i];
			        			if(_DataTableVM.HashRows[validationResults[0].Data[i]].deleted && _DataTableVM.HashRows[validationResults[0].Data[i]].deleted ==true) {
			        				_DataTableVM.HashRows[validationResults[0].Data[i]].deleted = false;
			        				undeletedRows++;
			        			}
			        		}                  
			        		 
		        		return $q.reject({"submitRowCount": rowCount,"validationResults": validationResults,"undeletedRows":undeletedRows});
	        		 }
	        		 else {
	        			 return $q.when({"submitRowCount": rowCount, message:{type:"info", text:"Saved successfully."}});
	        		 }
	        	 }
	       		 else {
	       			 return $q.reject({"submitRowCount": rowCount, message:{type:"danger", text:"Save failed."}});
	       		  }
	          }, function(response){
	          	//var resp = response;
	          	//console.log(response);
	          	return $q.reject({"submitRowCount": rowCount, message: {type:"danger", text:response.data}, status:response.status});
	          });
	  	}
	   
	   function migrateMappingWorker (authToken, payload) {
		   clearPreviousValidateResults();
		   var rowCount = payload.TotalRows;
		   var migratePayload = {"MappingTableId": payload.MappingTableId,"IsForceSave":payload.IsForceSave};
		   console.log(JSON.stringify(migratePayload));
		  	return $http({
	             method: 'POST',
	             headers: {'Authorization': authToken,"Content-Type":"application/json"},
	             url: serverVariableService.MT_ENDPOINT() + '/MigrateMappingValues',
	             data: migratePayload
	         })
	         .then(function(response) {
	        	 if(response.status == 200) {
	        		 var validationResults = response.data.ValidationResults;
	        		 //validationResults = [{Data : ["AAEHJLABGAACZnzAAA","AAEHJLABGAACZnzAAB","AAEHJLABGAACZnzAAC"]},
		        	 //                   {Data:["validate msg 1","validate msg 2", "validate msg 3"]}];
	        		 if(validationResults) {
	        				var undeletedRows = 0;
		        			_previousValidateResults = validationResults;
			        		for(var i=0; i <validationResults[0].Data.length; i++) {
			        			_DataTableVM.HashRows[validationResults[0].Data[i]].validationMsg = validationResults[1].Data[i];
			        			if(_DataTableVM.HashRows[validationResults[0].Data[i]].deleted && _DataTableVM.HashRows[validationResults[0].Data[i]].deleted ==true) {
			        				_DataTableVM.HashRows[validationResults[0].Data[i]].deleted = false;
			        				undeletedRows++;
			        			}
			        		}                  
			        		 
		        		return $q.reject({"submitRowCount": rowCount,"validationResults": validationResults,"undeletedRows":undeletedRows});
	        		 }
	        		 else if (response.data && response.data.MessageType == 1) {
	        			 return $q.when({"submitRowCount": rowCount, message:{type:"danger", text:response.data.Message}}); 
	        		 }
	        		 else{
	        			 
	        			 return $q.when({"submitRowCount": rowCount, message:{type:"info", text:"Migrated successfully."}});
	        		 }
	        	 }
	       		 else {
	       			 return $q.reject({"submitRowCount": rowCount, message:{type:"danger", text:"Migrate failed."}});
	       		  }
	          }, function(response){
	          	var resp = response;
	          	//console.log("getRequestTypes service call failed");
	          	return $q.reject({"submitRowCount": rowCount, message: {type:"danger", text:response.data}, status:response.status});
	          });
	  	}
	   
	   function getSignedKeyWorker (authToken, payload) {
		  	return $http({
	             method: 'get',
	             headers: {'Authorization': authToken },
	             url: serverVariableService.MT_ENDPOINT() + '/GetSignedUrlForExportMappingTable/' + _DataTableVM.tableId,
	             data: payload
	         })
	         .then(function(response) {
	        	 if(response.status == 200) {
	        		 	
	        		 return $q.when(response);
	        	 }
	       		 else {
	       			 return $q.reject({message: {type:"danger", text:"error occured retrieving signed key"}});
	       		  }
	          }, function(response){
	          	var resp = response;
	          	//console.log("getRequestTypes service call failed");
	          	return $q.reject({message: {type:"danger", text:"error occured retrieving signed key"}});
	          });
	  	}
	   
	   function getRequestPayloadRowCount(payload) {
		   var count = 0;
		   if(payload.AddRecords.length > 0) {
			   count = count + payload.AddRecords[0].Data.length;
		   }
		   if(payload.ModifiedRecords.length > 0) {
			   count = count + payload.ModifiedRecords[0].Data.length;
		   }
		   count  = count + payload.DeletedRecords.length;
		   return count;
	   }
	   
	   
   
    } // end of service class
  
	  //view model classes
	  function DataTableViewModel() {
	      var self = this;
	      self.tableId = -1;
	      self.TotalPages = 0;
	      self.TotalResults = 0;
	      self.CurrentPage = 0;
	      self.isDataLoaded = false;
	      self.isDataLoadComplete = false;
	      self.RowsPerPage = 2500;
	
	      self.Title = "This is Title";
	      self.Columns = []; //["Column 1", "Column 2", "Column 3", "Column 4", "Validation Comments"];
	      self.Data = [];//[[100, 110, 120, 130], [200, 220, 250, 260], [300, 310, 350, 360], [400, 410, 450, 460], ["", "Invalid member name", ""]];
	      self.PageData = [];
	      self.PagesLoaded = [];
	      self.Rows = [];
	      self.HashRows = {};
	      self.GridColumnDefs = []; //["Validation Comments", "Column 1", "Column 2", "Column 3", "Column 4", "Column 5", "Column 6"];
	      
	      self.SelectedRowsRef = [];
	      self.DeletedRows = [];
	      self.ChangedRows = [];
	      self.ExportUrl = "";
	      self.ErrorMessageCollection = [];
	      self.SuccessMessageCollection = [];
	      
	      self.PivotData2 = function () {
	          self.Rows = [];
	
	          var pagedData = self.PageData[0];
	
	          for (var rowIndex = 0; rowIndex < pagedData.Data[0].length; rowIndex++) {
	              var trvm = new TableRowViewModel();
	              for (var colIndex = 0; colIndex < pagedData.Data.length; colIndex++) {
	                  trvm.Data.push(pagedData.Data[colIndex][rowIndex]);
	              }
	              self.HashRows[pagedData.Data[0][rowIndex]]= trvm ;// to do: need to change to the real key field later
	              self.Rows.push(trvm);
	          }
	
	      };
	
	      self.PivotMoreData2 = function () {
	
	          for (var pageIndex = 1; pageIndex < self.PageData.length; pageIndex++) {
	              var pagedData = self.PageData[pageIndex];
	              if (pagedData.Data.length > 0) {
	
	                  for (var rowIndex = 0; rowIndex < pagedData.Data[0].length; rowIndex++) {
	                      var trvm = new TableRowViewModel();
	                      for (var colIndex = 0; colIndex < pagedData.Data.length; colIndex++) {
	                          trvm.Data.push(pagedData.Data[colIndex][rowIndex]);
	                      }
	                      self.HashRows[pagedData.Data[0][rowIndex]]= trvm ;// to do: need to change to the real key field later
	                      self.Rows.push(trvm);
	                  }
	              }
	          }
	      };
	      
	      self.getAddedRecords = function() {
		    	 var addedRecords =[];
		    	 angular.forEach(self.ChangedRows, function (row, index) { 
		    		 if((row.Data[0] == "" || row.Data[0].match(/uiGrid-/)) && row.deleted != true) {
		    			 // assume the first field is datakey data
		    			 row.Data[0] = row.$$hashKey;
		    			 self.HashRows[row.Data[0]] = row; // for validation tracking purpose.
		    			 addedRecords.push(row);
		    		 }
		         });
		    	 //get $$hashKey as dataKey since newly added records dont have dataKey
		    	 //since we need dataKey to track validation message
		    	 console.log(addedRecords);
		    	 var unPivotedRecords = self.unPivotRecords(addedRecords);
		    	 return unPivotedRecords;
		  };
		  
		  self.getDeletedRecordIds = function() {
		    	 var deletedRowIds =[];
		    	 var patt = new RegExp("uiGrid");
		    	 angular.forEach(self.DeletedRows, function (row, index) {
	            	if(row.Data[0] !=="" && !patt.test(row.Data[0]) && row.deleted == true) { // no need to send deleted rows that is not on server yet
	            		deletedRowIds.push(row.Data[0]);
	            	}
		         });
		    	 return deletedRowIds;
		   };
		   
		   self.getModififedRecords = function() {
		    	 var modifiedRecords =[];
		    	 var patt = new RegExp("uiGrid");
		    	 angular.forEach(self.ChangedRows, function (row, index) {
		    		 if(row.Data[0] != "" && !patt.test(row.Data[0]) && row.deleted != true) {
		    			 modifiedRecords.push(row);
		    		 }
		         });
		    	 var unPivotedRecords =self.unPivotRecords(modifiedRecords);
		    	 return unPivotedRecords;
		   };
		    
		   self.unPivotRecords = function(entityRows) {
			   var unPivotedData = [];
			   var colCount = 0;
			   if(entityRows.length > 0)  {
				   colCount = entityRows[0].Data.length;
				   for(var i=0; i <colCount; i++) {
					   unPivotedData.push({Data:[]});
				   }
				   
				   for(var j=0; j < entityRows.length; j++) {
					   for(var k=0; k <colCount; k++) {
						   unPivotedData[k].Data.push(entityRows[j].Data[k]);
					   }
				   }
			   }
			   return unPivotedData;
		   }
		   
	      self.CreateNewRow = function () {
	          var trvm = new TableRowViewModel();
	          for (var colIndex = 0; colIndex < self.Columns.length; colIndex++) {
	              trvm.Data.push('');
	          }
	          self.Rows.unshift(trvm);
	          return trvm;
	      };
	      
	      self.AddRowToTop = function(tableViewModel) {
	    	  self.Rows.unshift(tableViewModel);
	    	  
	      }
	      
	      self.clearErrorMessages = function () {
	          self.ErrorMessageCollection = [];
	      };
	      self.clearSuccessMessages = function () {
	          self.SuccessMessageCollection = [];
	      };
	     
	  }
	
	  function TableRowViewModel() {
	      var self = this;
	      self.ValidationType = "0";
	      self.validationMsg = "";
	      self.Data = [];
	      self.IsSelected = false;
	  }
	
	  function GridColumnDefViewModel(name, field, isVisible, colListVM) {
	      var self = this;
	      //self.name = name;
	      self.field = field;
	      self.enableCellEditOnFocus = true;
	      self.visible = isVisible;
	      self.displayName = name;
	      self.cellEditableCondition = true;
	      self.cellTooltip = true;

	      if (colListVM.isColWidthComputeNeeded) {
	          self.width = calculateColWidth(name);
	      }
	      //self.cellClass = function (grid, row, col, rowRenderIndex, colRenderIndex) {
	      //    if (row.entity.ValidationType == "1") {
	      //        return "red";
	      //    }
	      //};
	  }

	  function calculateColWidth(columnText) {
	      var coltextLength = columnText.length;
	      return (coltextLength * 15);
	  }
	
	  function DataPageViewModel(pageNumber) {
	      var self = this;
	      self.PageNumber = pageNumber;
	      self.Data = [];
	  }
	  
	  var UserRoleTypeEnum = {READ: 1, EDIT: 2, MIGRATE:3};
	  var ReadonlyActions = { tableId: '', "filter": true, "export": true, "viewFullScreen": true, "add": false, "remove": false, "validate": false, "replace": false, "import": false, "save": false, "migrate": false };
	  var EditActions = { tableId: '', "filter": true, "export": true, "viewFullScreen": true, "add": true, "remove": true, "validate": true, "replace": true, "import": true, "save": true, "migrate": false };
	  var MigrateActions = { tableId: '', "filter": true, "export": true, "viewFullScreen": true, "add": false, "remove": false, "validate": true, "replace": false, "import": false, "save": false, "migrate": true };
// end of view model classes
  
}());