(function () {
  angular.module('vmApp').service('reportingService', ['$q', '$http','authenticationService','serverVariableService', reportingService]);

  //service class
  function reportingService($q, $http, authenticationService, serverVariableService) {
      var _DataTableVM = null;
      var DEFAULT_ROWS_PER_PAGE = 2500;

      this.getReports = function () {
          return authenticationService.simpleServiceDispatcher({}, function (token) {
              return $http({
                  method: 'get',
                  headers: { 'Authorization': token },
                  url: serverVariableService.HOST_URL() + '/api/reporting/getreports',
              });
          });
      }

      //GetReport/{reportId}
      this.getReport = function (reportId) {
          return authenticationService.simpleServiceDispatcher({}, function (token) {
              return $http({
                  method: 'get',
                  headers: { 'Authorization': token },
                  url: serverVariableService.HOST_URL() + '/api/reporting/getreport/' + reportId,
              });
          });
      }

      //GetReportDataPage/{reportId}/{pageNumber}/{rowsPerPage}/{totalRecords}
      function getReportData(reportId, pageNumber, totalRecords, rowsPerPage) {
          totalRecords = totalRecords || 0;
          rowsPerPage = rowsPerPage || DEFAULT_ROWS_PER_PAGE;
          pageNumber = pageNumber || 1;

          var url = [serverVariableService.HOST_URL() + '/api/reporting/GetReportDataPage', reportId, pageNumber, rowsPerPage, totalRecords].join('/');
          return authenticationService.simpleServiceDispatcher({}, function (token) {
              return $http({
                  method: 'get',
                  headers: { 'Authorization': token },
                  url: url
              });
          });
      }

      this.getPageData = function(reportId, pageNumber, totalRecords, rowsPerPage) {
          return getReportData(reportId, pageNumber, totalRecords, rowsPerPage);
      };

      this.getInitialLoad = function (reportId) {
          return getReportData(reportId, 1);
      };

      this.getRemainingLoad = function (reportId, totalPages, start, rowsPerPage, totalRecords) {

          start = start || 2;
          rowsPerPage = rowsPerPage || DEFAULT_ROWS_PER_PAGE;

          var promises = []
          for (var i = start; i <= totalPages; i++) {
              promises.push(getReportData(reportId, i, totalRecords, rowsPerPage));
          }
          return promises;
      };
	    
      this.getSignedKey = function (payload, successCallback, errorCallback) {
          authenticationService.serviceCallDispatcher(payload, getSignedKeyWorker, successCallback, errorCallback);
      };

      this.exporturl = function (id, signedurl) {
          return serverVariableService.HOST_URL() + '/api/reporting/ExportReport?reportId=' + id + '&signedUrl=' + signedurl;
      };
	   
	   function getSignedKeyWorker (authToken, payload) {
		  	return $http({
	             method: 'get',
	             headers: {'Authorization': authToken },
	             url: serverVariableService.HOST_URL() + '/api/reporting/GetSignedUrlForExportReport/' + payload.reportid
	         })
	         .then(function(response) {
	        	 if(response.status == 200) {        		 	
	        		 return $q.when(response);
	        	 }
	       		 else {
	       			 return $q.reject({message: {type:"danger", text:"error occured retrieving signed key"}});
	       		  }
	         })
		  	.catch(function(response){
	          	return $q.reject({message: {type:"danger", text:"error occured retrieving signed key"}});
	         });
	  	}
	    
    } // end of service class
  
}());