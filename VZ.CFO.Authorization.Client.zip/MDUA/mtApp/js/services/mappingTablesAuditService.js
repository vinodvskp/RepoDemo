(function () {

	  angular.module('vmApp')
  	.service('mappingTablesAuditService', ['$q', '$http', 'constantService','authenticationService','serverVariableService',mappingTablesAuditService]);

  function mappingTablesAuditService($q, $http, constantService,authenticationService,serverVariableService) {
	var self = this;
	var _rowsPerPage;
	var _tableId = 1;
	var _searchKey = "";
	var _auditType = "1";
	self.totalRecords = 0;
	self.totalPages = 0;
	
	self.setSearchKey = function(searchKey){
		_searchKey = searchKey;
	}
	
	self.setTableId = function(tableId){
		_tableId = tableId;
	}
	
	self.setRowsPerPage = function(rowsPerPage){
		_rowsPerPage = rowsPerPage;
	}

	self.setAuditType = function (auditType) {
	    _auditType = auditType;
	}
	
    self.getFirstPageData = function(payload, successCallback, errorCallback) { 
    	authenticationService.serviceCallDispatcher(payload,getFirstPageDataWorker,successCallback,errorCallback);
    }
    
    self.getPageData = function(payload, successCallback, errorCallback) { 
    	authenticationService.serviceCallDispatcher(payload,getPageDataWorker,successCallback,errorCallback);
    }
    
 
    function getFirstPageDataWorker(authToken, payload) {
    	var url = serverVariableService.MT_ENDPOINT() + '/GetAuditLogFirstPageData/' + _tableId + '/' + _auditType + '/' + _rowsPerPage
    	if(payload.searchKey) {
    		url = serverVariableService.MT_ENDPOINT() + '/GetAuditLogSearchFirstPageData/' + _tableId + '/' + _auditType + '/' + _rowsPerPage +'/'+ payload.searchKey
    	}
    
    	return $http({
             method: 'get',
             headers: {'Authorization': authToken },
             url: url
         })
         .then(function(response) {
        	 if(response.status == 200) {
        		 self.totalRecords = response.data.TotalResults;
        		 self.totalPages = response.data.TotalPages;
        		 return $q.when(response.data.Result);
        	 }
       		 else {
       			 return $q.reject("request call does not return valid audit data");
       		  }
          }, function(response){
          	var resp = response;
          	//console.log("getRequestTypes service call failed");
          	return $q.reject(resp);
          });
    }
    
    function getPageDataWorker(authToken, payload) {
    	var url = serverVariableService.MT_ENDPOINT() + '/GetAuditLogPageData/' + _tableId + '/' + _auditType + '/' + payload.pageNumber + '/' + _rowsPerPage + '/' + self.totalRecords
    	if(payload.searchKey) {
    		url = serverVariableService.MT_ENDPOINT() + '/GetAuditLogSearchPageData/' + _tableId + '/' + _auditType + '/' + payload.pageNumber + '/' + _rowsPerPage + '/' + self.totalRecords + '/' + payload.searchKey
    	}
    	return $http({
             method: 'get',
             headers: {'Authorization': authToken },
             url: url
         })
         .then(function(response) {
        	 if(response.status == 200) {
        		 
        		 return $q.when(response.data.Result);
        	 }
       		 else {
       			 return $q.reject("request call does not return valid audit data");
       		  }
          }, function(response){
          	var resp = response;
          	//console.log("getRequestTypes service call failed");
          	return $q.reject(resp);
          });
    }
    
    
  }
}());