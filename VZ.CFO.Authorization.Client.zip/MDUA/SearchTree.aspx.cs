﻿using System;
using System.Web.UI.HtmlControls;
using MDUA.DataAccess;
using MDUA.BusinessLogic;
using System.Web.UI.WebControls;
using MDUA.DTO;


public partial class SearchTree : System.Web.UI.Page
{
    private int NodeNbr;
    private string curVal = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        // jevans 8/17/2011 - 24524 - added table name as well as dim name for location  
        if (IsPostBack == false)
        {
            hfFormName.Value = Request.QueryString["FormName"];
            hfCtrlName.Value = Request.QueryString["CtrlName"];
            hfTable.Value = Request.QueryString["Tbl"];
            hfDimName.Value = Request.QueryString["Dim"];
            curVal = Request.QueryString["VAL"];

        }
        if (hfDimName.Value != string.Empty && hfTable.Value != string.Empty)
            FillTree(hfDimName.Value, hfTable.Value);
    }
 
    private void FillTree(string DimensionName, string TableName)
    {
        UserInfo curUser = Utils.GetCurUser(Session, Request);
        Dimension root = Utils.BuildDimTree(DimensionName, TableName, curUser.EmployeeID);
        NodeNbr = 0;
        if (root != null)
            FillNode(root, tblTree);
    }

    private void FillNode(Dimension node, Table tbl)
    {
        NodeNbr++;
        TableRow tr = new TableRow();
        tbl.Rows.Add(tr);

        //  Display the Expand / Collapse Icon if needed
        TableCell tc = new TableCell();
        tc.Width = new Unit("20px");
        tc.VerticalAlign = VerticalAlign.Top;
        System.Web.UI.WebControls.Image img = null;
        if (node.arrChildren != null)
        {
            img = new System.Web.UI.WebControls.Image();
            if (node.Parent.Length == 0)
                img.ImageUrl = "~/Images/Collapse.gif";
            else
                img.ImageUrl = "~/Images/Expand.gif";
            tc.Controls.Add(img);
        }
        tr.Cells.Add(tc);

        //  Display a hyper link to the item to edit it.
        tc = new TableCell();
        tc.VerticalAlign = VerticalAlign.Top;
        tc.HorizontalAlign = HorizontalAlign.Left;

        LinkButton lb = new LinkButton();
        lb.ID = string.Format("LB{0}", NodeNbr);
        lb.CommandArgument = node.MemberName;
        lb.OnClientClick = "window.opener.document.forms[\"" + hfFormName.Value + "\"].elements[\"" + hfCtrlName.Value + "\"].value = \"" + node.MemberName + "\"; window.close();";
        lb.Text = node.MemberName;
        if (node.Alias.Length > 0)
            lb.Text += " - " + node.Alias;
        if (node.MemberName.Equals(curVal) == true)
        {
            lb.Font.Bold = true;
            HtmlGenericControl parDiv = (HtmlGenericControl)tbl.Parent;
            while (parDiv != divTree)
            {
                parDiv.Style.Remove("display");
                parDiv.Style.Add("display", "block");

                TableCell parCell = (TableCell)parDiv.Parent;
                TableRow parRow = (TableRow)parCell.Parent;
                ((System.Web.UI.WebControls.Image)parRow.Cells[0].Controls[0]).ImageUrl = "~/Images/Collapse.gif";
                Table parTbl = (Table)parRow.Parent;
                parDiv = (HtmlGenericControl)parTbl.Parent;
            }
        }
        tc.Controls.Add(lb);
        tr.Cells.Add(tc);

        if (node.arrChildren != null)
        {
            HtmlGenericControl myDiv = new HtmlGenericControl();
            myDiv.TagName = "div";
            myDiv.ID = string.Format("div_{0}", NodeNbr);
            myDiv.Attributes.Add("width", "100%");
            if (node.Parent.Length > 0)
                myDiv.Style.Add("display", "none");

            tc.Controls.Add(myDiv);

            Table myTbl = new Table();
            myTbl.Width = new Unit("100%");
            myDiv.Controls.Add(myTbl);

            img.Attributes["onclick"] = string.Format("javascript:FlipNugget('{0}', '{1}')",
                img.ClientID, myDiv.ClientID);
            foreach (Dimension hd in node.arrChildren)
                FillNode(hd, myTbl);
        }
    }
}
