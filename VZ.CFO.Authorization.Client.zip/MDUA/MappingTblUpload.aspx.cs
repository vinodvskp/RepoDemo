﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using System.IO;

public partial class MappingTblUpload : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Master.PageTitle = "Mapping Table Upload";
        Master.NavInstructionsVisible = true;
        if (IsPostBack == false)
        {
            ArrayList arrTypes = Utils.GetMappingFileTypes(Master.curUser.EmployeeID);

            //  If this user doesn't have any file types that they can upload,
            //  Go back to the default page.
            if (arrTypes == null || arrTypes.Count == 0)
            {
                Master.PendingMessage = "You don't have access to upload mapping files";
                Server.Transfer("~/Default.aspx");
                return;
            }

            foreach (HypMappingFileType mft in arrTypes)
            {
                ListItem li = new ListItem();
                li.Text = string.Format("{0} ({1})", mft.Description, mft.MappingCode);
                li.Value = string.Format("{0}", mft.MappingCode);
                ddlFileType.Items.Add(li);
            }

            //  If there are items, put in a default item so that they don't accidentally
            //  upload to the first file type because they forgot to change the file type.
            ListItem sel = new ListItem();
            sel.Value = "";
            sel.Text = "Select Mapping File Type...";
            ddlFileType.Items.Insert(0, sel);
        }
    }
    protected void btnUpload_Click(object sender, EventArgs e)
    {
        Master.Message = "";

        //  Make sure that they picked a file type and selected a file.
        if (ddlFileType.SelectedValue == "")
        {
            Master.Message = "You must select a Mapping File Type first";
            return;
        }

        if (fuUserFile.HasFile == false)
        {
            Master.Message = "You must select a File to upload.";
            return;
        }


        //  Check to see if someone else is running a process that we should be waiting for.
        HypMappingFileType mft = Utils.GetMappingFileType(ddlFileType.SelectedValue,
            Master.curUser.EmployeeID);
        ArrayList arrFlds = Utils.GetTableFields(mft.MappingTable, Master.curUser.EmployeeID);

        string Filename = "";
        try
        {
            //  Upload the file and load the data based on the extension of the file.
            Filename = string.Format("Archive/{1}_{2}_{0}{3}",
                DateTime.Now.ToString("yyyyMMdd_HHmmss"),
                Master.curUser.UserId, mft.MappingCode,
                Path.GetExtension(fuUserFile.FileName));
            Filename = Server.MapPath(Filename);
            fuUserFile.SaveAs(Filename);
        }
        catch (Exception ex)
        {
            Master.Message = "We're sorry, but an error occurred while trying to save the file. An email has been sent to the development team.";
            DbAccess.LogEvent(Master.curUser.EmployeeID, "MappingTblUpload.aspx", "btnUpload_Click", ex, LogLevel.Error);
            
            DisplayPopUpMessage("The file must be resubmitted.");
        }
        Utils.DeleteFile(Filename, Master.curUser.EmployeeID);
    }


    private void DisplayPopUpMessage(string Message)
    {
        litPopupMsg.Text = string.Format(@"<script language=""javascript"" type=""text/javascript"">
    setTimeout(""alert('{0}');"", 500);</script>", Message);
    }

    public static int LoadDataFileIntoTable(string Filename, HypMappingFileType mft, ArrayList arrFlds)
    {
        /*
        int TotRecsAdded = -1;
        BasicOraCommand Wrtr = new BasicOraCommand(DbAccess.GetOracleConnStr());

        //Create the Connection String
        string ConnString = string.Format(@"Provider=Microsoft.Jet.OLEDB.4.0;
            Data Source={0};Extended Properties=""Excel 8.0;IMEX=1;""",
            Filename);

        //Create the connection
        System.Data.OleDb.OleDbConnection ExcelConnection =
            new System.Data.OleDb.OleDbConnection(ConnString);

        //  We want to select all the UserInput fields from the Excel file.
        string SelCmd = "";
        string AllFldNames = "";
        foreach (HypTableColumnInfo ci in arrFlds)
        {
            if (AllFldNames.Length > 0)
                AllFldNames += ",";
            AllFldNames += ci.Name;
        }
        SelCmd += string.Format("Select {0} from [{1}$]", AllFldNames, mft.MappingTable);

        System.Data.OleDb.OleDbCommand ExcelCommand = new System.Data.OleDb.OleDbCommand(SelCmd, ExcelConnection);

        try
        {
            //Open the connection
            ExcelConnection.Open();

            //Create a reader
            System.Data.OleDb.OleDbDataReader ExcelReader;
            try
            {
                ExcelReader = ExcelCommand.ExecuteReader();
            }
            catch (Exception exOpn)
            {
                throw new Exception(string.Format("There was an error opening the Excel file.  Make sure that a Worksheet named '{0}' exists and each of these columns are defined: {1}.",
                    mft.MappingCode, AllFldNames));
            }

            //  Now that we know the file will load, lets delete the current stuff.
            string InsFlds = "";
            string DelCmd = "delete from " + mft.MappingTable;
            if (mft.arrFlds.Count > 0)
            {
                string Where = "";
                foreach (HypMappingFileTypeFlds ftf in mft.arrFlds)
                {
                    if (Where.Length > 0)
                    {
                        Where += " and ";
                        InsFlds += ", ";
                    }
                    Where += ftf.ConstFld + ftf.Value;
                    InsFlds += ftf.ConstFld + ftf.Value;
                }

                DelCmd += " where " + Where;
            }
            //  Determine the table to insert into along with the fields that should be in the file.
            string[] UploadFlds = DbAccess.UserInputFldNames;
            string UploadFldTypes = DbAccess.UserInputFldTypes;
            string TableName = ConfigurationManager.AppSettings["UserInputTempTbl"];
            if (hft.isOutlook == true)
            {
                UploadFlds = DbAccess.OutlookFldNames;
                UploadFldTypes = DbAccess.OutlookFldTypes;
                TableName = ConfigurationManager.AppSettings["UserInputOutlookTbl"];
            }
            UploadFldTypes = UploadFldTypes.Replace('S', '\'').Replace('N', ' ');
            int[] FldIdxes = new int[UploadFlds.Length];
            string FldList = string.Format("insert into {0} (PRP_RPT_SOURCE, PRP_RPT_OWNER, PRP_RPT_CREATEMODIFYDATE,LineNbr",
                TableName);

            //  Check each field that should be in the file and make sure it is there.
            for (int i = 0; i < UploadFlds.Length; i++)
            {
                bool bFound = false;
                for (int j = 0; j < ExcelReader.VisibleFieldCount; j++)
                {
                    if (UploadFlds[i].Equals(ExcelReader.GetName(j).ToUpper()) == true)
                    {
                        FldIdxes[i] = j;
                        bFound = true;

                        //  If it was found, add it to the field list
                        FldList += "," + UploadFlds[i];
                        break;
                    }
                }

                //  If the field wasn't found, throw an exception.
                if (bFound == false)
                {
                    throw new Exception("The following field was not defined in the file: " + UploadFlds[i]);
                }
            }

            FldList += string.Format(") values ('{0}', '{1}', to_date('{2}', 'yyyy/mm/dd HH24.MI.SS'),",
                hft.Code, Owner, dtNow.ToString("yyyy/MM/dd HH:mm:ss"));

            //  Clear out any previous attempt to load the file.
            Cmd = string.Format("delete from {0} where PRP_RPT_SOURCE='{1}'",
                TableName, hft.Code);
            Wrtr.Open();
            Wrtr.ExecOpened(Cmd);

            //  For each row of data, write out all the data separated by tabs.
            TotRecsAdded = 0;
            while (ExcelReader.Read())
            {
                int NbrNullFlds = 0;

                TotRecsAdded++;
                string Vals = "";
                for (int i = 0; i < UploadFlds.Length; i++)
                {
                    if (ExcelReader.IsDBNull(FldIdxes[i]) == true)
                    {
                        Vals += ",NULL";
                        NbrNullFlds++;
                    }
                    else
                        Vals += string.Format(",{0}{1}{0}", UploadFldTypes[i], ExcelReader.GetValue(FldIdxes[i]));
                }

                //  If all the fields were null, just skip the line
                if (NbrNullFlds == UploadFlds.Length)
                    continue;

                //  Add the record to the table.
                Cmd = FldList + TotRecsAdded.ToString() + Vals.ToUpper() + ")";
                if (Wrtr.ExecOpened(Cmd) != 1)
                    throw new Exception(Wrtr.LastErrorMessage);
            }

            if (hft.isOutlook)
            {
                int Pos = Cmd.IndexOf("SC.O.");
                if (Pos > 0)
                {
                    Scenario = Cmd.Substring(Pos + 5, 3);
                }
            }
        }
        catch (Exception ex)
        {
            DbAccess.LogEvent("", "LoadDataFileIntoTable", Cmd, ex, LogLevel.Error);
            Msg = "An error occurred trying to read the excel file.  " + ex.Message;
            TotRecsAdded = -1;
        }

        //  We are done, clean up.
        ExcelConnection.Close();
        Wrtr.Dispose();

        return TotRecsAdded;
         * */
        return 0;
    }

    protected void btnDownload_Click(object sender, EventArgs e)
    {

    }
}
