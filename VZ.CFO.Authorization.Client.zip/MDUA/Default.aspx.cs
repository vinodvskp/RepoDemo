﻿using System;
using System.Web.UI.WebControls;
using MDUA.DataAccess;
using MDUA.BusinessLogic;
using MDUA.DTO;


public partial class Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Master.PageTitle = "System Status";

        if (IsPostBack == false)
        {
            if (Master.curUser == null)
                Master.PendingMessage = "user is null" ;
            else
            {
                WebSettings ws = Utils.LoadWebSetting(Master.curUser.EmployeeID);
                // jevans 5/23/2012 - if web settings is null, database is not available.
                if (ws == null)
                {
                    Master.Message = "MDUA could not load web settings from the database, and cannot continue.  <P>" + HypMDUA.ERROR_MESSAGE;
                    return;
                }
                //lblLastProcessed.Text = ws.LastProcessed.ToString();
                //if (ws.LockedBy.Length > 0)
                //{
                //    UserInfo ui = DbAccess.getUserData(ws.LockedBy);
                //    if (ui != null)
                //        lblLock.Text = "Locked by " + ui.FullName;
                //    else
                //        lblLock.Text = string.Format("Lock by User {0}", ws.LockedBy);
                //}

                //            ArrayList arrData = DbAccess.LoadLookupType("DIM_TYPE", Master.curUser.EmployeeID);
                //            int Total = 0;
                //            BasicOraReader Rdr = new BasicOraReader(DbAccess.GetOracleConnStr());
                //            foreach (HypWebLookup wl in arrData)
                //            {
                //                if (wl.Extra == null || wl.Extra.Length == 0)
                //                    continue;

                //                string Cmd = string.Format(@"SELECT count(member_name) FROM {0} a
                //                        where  TO_char(a.Last_Updated, 'yyyymmdd') >= '{1}'",
                //                        wl.Extra, ws.LastProcessed.ToString("yyyyMMdd"));
                //                if (Rdr.Open(Cmd) == true && Rdr.oraRdr.Read() == true)
                //                {
                //                    Total += (int)(decimal)Rdr.oraRdr[0];
                //                    Rdr.Close();
                //                }
                //            }

                //lblPending.Text = Total.ToString();
                lblUplSet.Text = (ws.UserFeedEnabled ?
                    "User Feeds Enabled" : "User Feeds Disabled") + ", " +
                    (ws.CoaCorEnabled ?
                    "COA / COR Accounts are Enabled" : "COA / COR Accounts are Disabled");

                lblBroadcast.Text = ws.BroadcastMessage;
                lblBroadcast.Text = lblBroadcast.Text.Replace("\r\n", "<br/>");
                BasicOraReader Rdr = new BasicOraReader(DbAccess.GetOracleConnectionString());

                if (Rdr.Open(@"select s.seqnbr, p.starttime, p.endtime, p.status, p.message, p.asRelatesTo 
                from rpt_process_step_tbl s
                    left outer join rpt_process_status_tbl p on ProcessId in (SELECT max(a.processid)
                    FROM rpt_process_status_tbl a
                where processcode = 'BUILDCUBE'
                group by a.processcode, a.asrelatesto) and 
                    p.ProcessCode=s.processcode and
                    p.AsRelatesTo=s.asrelatesto and 
                    p.Step = s.step
                where s.processCode='BUILDCUBE'
                order by p.AsRelatesTo, s.seqnbr") == true)
                {
                    string LstAsRelatesTo = "";
                    TableRow tr = null;
                    TableCell tc = null;
                    DateTime StrtTime = DateTime.Now;
                    DateTime EndTime = DateTime.MinValue;
                    TimeSpan tsElapsed;
                    string LastStatus = "";
                    while (Rdr.oraRdr.Read())
                    {
                        if (Rdr.oraRdr.IsDBNull(5) == true)
                            break;

                        if (LstAsRelatesTo.Equals(Rdr.oraRdr.GetString(5)) == false)
                        {
                            //  If the AsRelatesTo is changing and there is a previous value,
                            //  then calculate the Elapsed time.
                            if (LstAsRelatesTo.Length > 0)
                            {
                                tc = new TableCell();
                                tc.Text = LastStatus;
                                tr.Cells.Add(tc);
                                if (EndTime != DateTime.MinValue)
                                {
                                    tsElapsed = EndTime.Subtract(StrtTime);
                                    tc = new TableCell();
                                    tc.Text = string.Format("{0}h {1}m {2}s elapsed time.",
                                        tsElapsed.Hours, tsElapsed.Minutes, tsElapsed.Seconds);
                                    tr.Cells.Add(tc);
                                }
                            }

                            //  Setup the next item
                            LstAsRelatesTo = Rdr.oraRdr.GetString(5);
                            tr = new TableRow();
                            tblBuilds.Rows.Add(tr);
                            tc = new TableCell();
                            tr.Cells.Add(tc);
                            tc.Text = LstAsRelatesTo;
                            if (Rdr.oraRdr.IsDBNull(1) == false)
                                StrtTime = Rdr.oraRdr.GetDateTime(1);
                            else
                                StrtTime = DateTime.MinValue;
                            EndTime = DateTime.MinValue;
                            LastStatus = "";
                        }

                        if (Rdr.oraRdr.IsDBNull(2) == false)
                            EndTime = Rdr.oraRdr.GetDateTime(2);
                        else
                            EndTime = DateTime.MinValue;

                        if (Rdr.oraRdr.IsDBNull(3) == false)
                        {
                            string St = Rdr.oraRdr.GetString(3);
                            switch (St)
                            {
                                case "S": LastStatus = "Built"; break;
                                case "P": LastStatus = "Still Building"; break;
                                case "R": LastStatus = "Still Building"; break;
                                case "E": LastStatus = "Errored out"; break;
                                case "C": LastStatus = "Was Canceled"; break;
                                default: LastStatus = "No Status"; break;
                            }
                            if (EndTime != DateTime.MinValue)
                                LastStatus += " as of " + EndTime.ToString() + ".";
                            else
                                LastStatus += ".";
                        }
                    }
                    Rdr.Close();

                    //  If there was at least one cube build item.
                    if (tr != null)
                    {
                        tc = new TableCell();
                        tc.Text = LastStatus;
                        tr.Cells.Add(tc);
                        if (EndTime != DateTime.MinValue)
                        {
                            tsElapsed = EndTime.Subtract(StrtTime);
                            tc = new TableCell();
                            tc.Text = string.Format("{0}h {1}m {2}s elapsed time.",
                                tsElapsed.Hours, tsElapsed.Minutes, tsElapsed.Seconds);
                            tr.Cells.Add(tc);
                        }
                    }
                }
            
            
                lblCurrentPeriod.Text = ws.CurrentMonthString + " " + ws.CurrentYear;
            
            Rdr.Dispose();
            Rdr = null;
            }
        } 
    }
}
