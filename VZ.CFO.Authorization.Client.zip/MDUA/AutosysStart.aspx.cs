﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using MDUA.DTO;
using MDUA.DataAccess; 
using Oracle.DataAccess.Client;
using Oracle.DataAccess; 
using System.Threading;
using MDUA.BusinessLogic;

public partial class StartAutosys : System.Web.UI.Page
{
    #region User Messages
    private static readonly string successMessage = "The {0} Command for Job {1} was successfully executed.";
    private static readonly string processCantStartMsg = "The process can not be started because the status is: {0}";
    private static readonly string triggerErrorMessage = "An error occurred while trying to trigger the job. Try again or contact IT Team.";
    private static readonly string refreshErrorMessage = "Error while refreshing job status. Try again. If this still persists contact IT Team";
    #endregion
    #region field values
    private static readonly string statusTitleLastRun = "Last Run";
    private static readonly string statusTitleRunning = "Running Currently";
    private static readonly string statusFieldLabel = "Status: {0}";
    private static readonly string startedFieldLabel = "Started: {0}";
    private static readonly string endedFieldLabel = "Ended: {0}";
    private static readonly string elapsedFieldLabel = "Elapsed: {0}";
    private static readonly string notApplicableLabel = "N/A";
    #endregion
    protected void Page_Load(object sender, EventArgs e)
    {
        Master.PageTitle = "Initiate On Demand Job";

        if (IsPostBack == false)
        {
            BasicOraReader Rdr = new BasicOraReader(GeneralDatabaseAccess.GetOracleConnectionString());

            ddlAutosysOD.Items.Clear();
            ddlAutosysOD.Items.Add(new ListItem("Select an On Demand job...", " "));

            string Cmd = string.Format(@"SELECT a.job_Id, a.job_name, a.button_text, a.event
  FROM ops_on_demand_jobs a
  join ops_on_demand_job_access d on
    a.job_id = d.job_id and d.employee_id='{0}'
  order by d.display_order",
                Master.curUser.EmployeeID);
            if (Rdr.Open(Cmd) == true)
            {
                int jobIdColumn = Rdr.oraRdr.GetOrdinal("job_Id");
                int jobNameColumn = Rdr.oraRdr.GetOrdinal("job_name");
                int buttonTextColumn = Rdr.oraRdr.GetOrdinal("button_text");
                int eventColumn = Rdr.oraRdr.GetOrdinal("event");
                
                while (Rdr.oraRdr.Read())
                {
                    ListItem li = new ListItem();
                    li.Text = Rdr.oraRdr.GetString(buttonTextColumn); 
                    li.Value = Convert.ToString(Rdr.oraRdr.GetInt32(jobIdColumn));
                    ddlAutosysOD.Items.Add(li);
                }
                Rdr.Close();
            }

            if (ddlAutosysOD.Items.Count <= 1)
            {
                Master.PendingMessage = "You do not have access to Initiate On Demand job or you have none assigned to you.";
                Server.Transfer("~/Default.aspx");
                return;
            }
        }
    }
    protected void btnRefresh_Click(object sender, EventArgs e)
    {
        //  Default to not showing the start job button.
        Master.Message = "";
        divAutosysOD.Style["display"] = "none";
        if (ddlAutosysOD.SelectedIndex == 0)
        {
            Master.Message = "Please select an OD process to refresh.";
            return;
        }

        RefreshJobStatus();
    }

    protected void ddlAutosysOD_SelectedIndexChanged(object sender, EventArgs e)
    {
        Master.Message = "";

        if (ddlAutosysOD.SelectedIndex > 0)
        {
            
            int selectedJobId = Convert.ToInt32(ddlAutosysOD.SelectedValue);
            
            OnDemandJobInfo hai = GeneralDatabaseAccess.GetOnDemandJob(selectedJobId, Master.curUser.UserId);
            hfAutosysEvent.Value = hai.Event;
            hfAutosysJobname.Value = hai.JobName;
            hfAutosysJobDesc.Value = hai.Description;
            hfODJobId.Value = Convert.ToString(hai.JobId);
            hfODSubApplName.Value = (string.IsNullOrEmpty(hai.SubApplName) ? string.Empty : hai.SubApplName);
            btnStart.Text = hai.ButtonText;
        }
        RefreshJobStatus();
    }

    /// <summary>
    /// Handler for Start button click event
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void btnStart_Click(object sender, EventArgs e)
    {
        EspManager espManager = new EspManager();
        string subAppName = string.Empty;
        if (hfAutosysEvent.Value.ToUpper() == "TRIGGER")
        {
            string friendlyJobName = (string.IsNullOrEmpty(btnStart.Text.Trim()) ? string.Empty : "(" + btnStart.Text.Trim() + ")");

            try
            {
                //Get job status
                //Uncommenting the job status since it is done in BL before trigger
                //EspJobStatus jobStatus = espManager.GetJobStatus(hfAutosysJobname.Value, string.Empty, Master.curUser.EmployeeID);
                bool bSuccess = false;

                //if (jobStatus == null)
                //{
                //    GeneralDatabaseAccess.LogEvent(Master.curUser.EmployeeID, "AutosysStart.aspx", "btnStart_Click", "GetJobStatus returned null", UserToolLogLevel.Error);
                //    Master.Message = triggerErrorMessage;
                //}
                //else if (jobStatus.Status == EspJobStatusState.AppNotDefined || jobStatus.Status == EspJobStatusState.NoMatchingAppOrUnAuthorized || jobStatus.Status == EspJobStatusState.Completed)
                //{
                    
                    subAppName = (string.IsNullOrEmpty(hfODSubApplName.Value.Trim()) ? string.Empty : hfODSubApplName.Value.Trim());
                    EspMessage triggerResponse = espManager.TriggerJob(hfAutosysJobname.Value, subAppName, Master.curUser.EmployeeID);
                    if (triggerResponse != null)
                    {
                        if (triggerResponse.Info != null & triggerResponse.Info.Status == EspKnownValues.EspInfoStatus.Success)
                        {
                            bSuccess = true;
                            Master.Message = string.Format(successMessage, hfAutosysEvent.Value, hfAutosysJobname.Value);
                        }
                        else
                        {
                            GeneralDatabaseAccess.LogEvent(Master.curUser.EmployeeID, "AutosysStart.aspx", string.Format("Job: {0}; Event: {1}", hfAutosysJobname.Value + subAppName, hfAutosysEvent.Value),
                                string.Format("Info.Status: {0}; {1}", triggerResponse.Info.Status, triggerResponse.Data.Message), UserToolLogLevel.FatalError);
                        }

                        GeneralDatabaseAccess.LogEvent(Master.curUser.EmployeeID, "AutosysStart.aspx", hfAutosysEvent.Value + " OD: " + hfAutosysJobname.Value + friendlyJobName,
                        string.Format("Response: {0}", (bSuccess ? "Success" : "Failed")), UserToolLogLevel.Audit);
                    }
                    else
                    {
                        GeneralDatabaseAccess.LogEvent(Master.curUser.EmployeeID, "AutosysStart.aspx", string.Format("Job: {0}; Event: {1}", hfAutosysJobname.Value + subAppName + friendlyJobName, hfAutosysEvent.Value), "GetJobStatus() returned null.", UserToolLogLevel.FatalError);
                        Master.Message = triggerErrorMessage;
                    }
                //}
                //else
                //{
                //    Master.Message = string.Format(processCantStartMsg, jobStatus.Status.ToString());
                //}
            }
            catch (ArgumentException ae)
            {
                GeneralDatabaseAccess.LogEvent(Master.curUser.EmployeeID, "AutosysStart.aspx", string.Format("Job: {0}; Event: {1}", hfAutosysJobname.Value + subAppName + friendlyJobName, hfAutosysEvent.Value), ae, UserToolLogLevel.Error);
                Master.Message = triggerErrorMessage;
            }
            catch (ApplicationException ae)
            {
                //if (ae.Message == "Could not Trigger job because is active.")
                if (ae.Message.StartsWith("MDUA-ESP-001"))
                {
                    Master.Message = "The process can not be started because the status has changed before issuing Trigger command. Click on Refresh and try again.";
                }
                else
                {
                    Master.Message = triggerErrorMessage;
                }
                GeneralDatabaseAccess.LogEvent(Master.curUser.EmployeeID, "AutosysStart.aspx", string.Format("Job: {0}; Event: {1}", hfAutosysJobname.Value + subAppName + friendlyJobName, hfAutosysEvent.Value), ae, UserToolLogLevel.Error);
            }
            catch (Exception ex)
            {
                GeneralDatabaseAccess.LogEvent(Master.curUser.EmployeeID, "AutosysStart.aspx", string.Format("Job: {0}; Event: {1}", hfAutosysJobname.Value + subAppName + friendlyJobName, hfAutosysEvent.Value), ex, UserToolLogLevel.Error);
                Master.Message = triggerErrorMessage;
            }
        }
        //  Refresh the screen to show that it is running.
        RefreshJobStatus();
    }

    /// <summary>
    /// Refreshes job status
    /// </summary>
    private void RefreshJobStatus()
    {
        
        if (ddlAutosysOD.SelectedIndex == 0)
        {
            divAutosysOD.Style["display"] = "none";
            return;
        }

        string EspTimezone = EspDataAccess.EspTimezone;
        string subApplName = string.Empty;
        try
        {
            EspManager espManager = new EspManager();
            subApplName = (string.IsNullOrEmpty(hfODSubApplName.Value)) ? string.Empty : hfODSubApplName.Value.Trim();

            EspJobStatus jobStatus = espManager.GetJobStatus(hfAutosysJobname.Value, subApplName, Master.curUser.EmployeeID, 0);
            if (jobStatus != null)
            {
                divAutosysOD.Style["display"] = "block";
                lblAutosysODDesc.Text = hfAutosysJobDesc.Value;

                switch (jobStatus.Status)
                {
                    case EspJobStatusState.AppNotDefined:
                    case EspJobStatusState.NoMatchingAppOrUnAuthorized:                    
                        lblJobStatusHeader.Text = statusTitleLastRun;
                        lblJobStatusHeader.CssClass = string.Empty;
                        lblStatus.Text = string.Format(statusFieldLabel, notApplicableLabel);
                        lblStarted.Text = string.Format(startedFieldLabel, notApplicableLabel);
                        lblEnded.Text = string.Format(endedFieldLabel, notApplicableLabel);
                        lblStartedBy.Text = string.Format(elapsedFieldLabel, notApplicableLabel);
                        EnableStartButton();
                        break;
                    case EspJobStatusState.IsInvalidAppSpec:
                        lblJobStatusHeader.Text = statusTitleLastRun;
                        lblJobStatusHeader.CssClass = string.Empty;
                        lblStatus.Text = string.Format(statusFieldLabel, "Job not found");
                        lblStarted.Text = string.Format(startedFieldLabel, notApplicableLabel);
                        lblEnded.Text = string.Format(endedFieldLabel, notApplicableLabel);
                        lblStartedBy.Text = string.Format(elapsedFieldLabel, notApplicableLabel);
                        DisableStartButton();
                        break;
                    case EspJobStatusState.Completed:
                        lblJobStatusHeader.Text = statusTitleLastRun;
                        lblJobStatusHeader.CssClass = string.Empty;
                        lblStatus.Text = string.Format(statusFieldLabel, "Completed");
                        lblStarted.Text = string.Format(startedFieldLabel, jobStatus.StartedOn.ToString() + " " + EspTimezone);
                        lblEnded.Text = string.Format(endedFieldLabel, (jobStatus.EndedOn.HasValue == true ? jobStatus.EndedOn.ToString() + " " + EspTimezone : notApplicableLabel));
                        lblStartedBy.Text = string.Format(elapsedFieldLabel, notApplicableLabel);
                        EnableStartButton();
                        break;
                    case EspJobStatusState.InCompleteDependentJobs:
                        lblJobStatusHeader.Text = statusTitleRunning;
                        lblJobStatusHeader.CssClass = "ODJobStatusHeader-Running";
                        string dependentStatus = "Dependent processes are running or on hold." + (string.IsNullOrEmpty(jobStatus.InCompleteJobs)? string.Empty : " (" + jobStatus.InCompleteJobs + ")");
                        lblStatus.Text = string.Format(statusFieldLabel, dependentStatus);
                        lblStarted.Text = string.Format(startedFieldLabel, jobStatus.StartedOn.ToString() + " " + EspTimezone);
                        lblEnded.Text = string.Format(endedFieldLabel, notApplicableLabel);
                        if (jobStatus.StartedOn == null)
                        {
                            lblStartedBy.Text = string.Format(elapsedFieldLabel, notApplicableLabel);
                        }
                        else
                        {
                            TimeSpan elapsedTime = CalculateElapsedTime((DateTime)jobStatus.StartedOn);
                            lblStartedBy.Text = string.Format(elapsedFieldLabel, elapsedTime.ToString("c"));
                        }
                        DisableStartButton();
                        break;
                    case EspJobStatusState.Unknown:
                        lblJobStatusHeader.Text = statusTitleLastRun;
                        lblJobStatusHeader.CssClass = string.Empty;
                        lblStatus.Text = string.Format(statusFieldLabel, EspJobStatusState.Unknown.ToString());
                        lblStarted.Text = string.Format(startedFieldLabel, (jobStatus.StartedOn.HasValue == true ? jobStatus.StartedOn.ToString() + " " + EspTimezone : notApplicableLabel));
                        lblEnded.Text = string.Format(endedFieldLabel, (jobStatus.EndedOn.HasValue == true ? jobStatus.EndedOn.ToString() + " " + EspTimezone : notApplicableLabel));
                        lblStartedBy.Text = string.Format(elapsedFieldLabel, notApplicableLabel);
                        DisableStartButton();
                        break;
                }
            }
            else
            {
                GeneralDatabaseAccess.LogEvent(Master.curUser.EmployeeID, "AutosysStart.aspx.cs", string.Format("Job: {0}; Event: Refresh", hfAutosysJobname.Value + subApplName), "GetJobStatus() returned null in RefreshJobStatus method.", UserToolLogLevel.Error);
                Master.Message = refreshErrorMessage;
            }
        }
        catch (ArgumentException ae)
        {
            GeneralDatabaseAccess.LogEvent(Master.curUser.EmployeeID, "AutosysStart.aspx.cs", string.Format("Job: {0}; Event: Refresh", hfAutosysJobname.Value + subApplName), ae, UserToolLogLevel.Error);
            Master.Message = refreshErrorMessage;
        }
        catch (ApplicationException ae)
        {
            GeneralDatabaseAccess.LogEvent(Master.curUser.EmployeeID, "AutosysStart.aspx.cs", string.Format("Job: {0}; Event: Refresh", hfAutosysJobname.Value + subApplName), ae, UserToolLogLevel.Error);
            Master.Message = refreshErrorMessage;
        }
        catch (Exception ex)
        {
            GeneralDatabaseAccess.LogEvent(Master.curUser.EmployeeID, "AutosysStart.aspx.cs", string.Format("Job: {0}; Event: Refresh", hfAutosysJobname.Value + subApplName), ex, UserToolLogLevel.Error);
            Master.Message = refreshErrorMessage;
        }
    }

    /// <summary>
    /// Calculates Elapsed time from start time
    /// </summary>
    /// <param name="startTime"></param>
    /// <returns></returns>
    private static TimeSpan CalculateElapsedTime(DateTime startTime)
    {
        string destTimezone = TimeZone.CurrentTimeZone.StandardName;
        DateTime convertedTime = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(startTime, EspDataAccess.EspTimezone, destTimezone);
        return DateTime.Now - convertedTime;
    }

    /// <summary>
    /// Disables the start button
    /// </summary>
    private void DisableStartButton()
    {
        btnStart.ForeColor = System.Drawing.Color.Gray;
        btnStart.Enabled = false;
    }

    /// <summary>
    /// Enables the start button
    /// </summary>
    private void EnableStartButton()
    {
        btnStart.ForeColor = System.Drawing.Color.Black;
        btnStart.Enabled = true;
    }

    #region autosys logic
//    protected void btnStart_Click(object sender, EventArgs e)
//    {
//        BasicOraReader Rdr = new BasicOraReader(DbAccess.AutosysCS);

//        //  Select statement to find status that would keep the job from running.  The
//        //  query will return the text of the bad status so we can report why we can't
//        //  send the event right now.
//        string Cmd = string.Format(@"select b.status, c.text
//from {0}.{1}job a, {0}.{1}job_status b
//join {0}.{1}intcodes c on b.status=c.code
//where a.job_name='{2}'
//  and a.joid= b.joid",
//             DbAccess.AutosysSchema, DbAccess.AutosysTablePrefix,
//             hfAutosysJobname.Value);

//        switch (hfAutosysEvent.Value)
//        {
//            case "FORCE_STARTJOB":
//            case "STARTJOB":
//                Cmd += " and b.status in (1,3,7,11)";
//                break;

//            case "KILLJOB":
//                Cmd += " and b.status not in (1,3)";
//                break;

//            case "JOB_OFF_ICE":
//                Cmd += " and b.status != 7";
//                break;

//            case "JOB_ON_ICE":
//                Cmd += " and b.status = 7";
//                break;

//            case "JOB_OFF_HOLD":
//                Cmd += " and b.status != 11";
//                break;

//            case "JOB_ON_HOLD":
//                Cmd += " and b.status = 11";
//                break;

//            default:
//                //  For the default, add something that will never be true so that the command
//                //  just runs.
//                Cmd += " and b.status is null";
//                break;
//        }

//        if (Rdr.Open(Cmd) == true)
//        {
//            //  If it finds a record, it means that we can't start it because it is already
//            //  running or some other reason why we shouldn't start it.
//            if (Rdr.oraRdr.Read() == false)
//            {
//                BasicOraCommand CallSP = new BasicOraCommand(DbAccess.AutosysCS);
//                OracleParameter pEventText = new OracleParameter("i_eventtxt", hfAutosysEvent.Value); //"FORCE_STARTJOB");
//                OracleParameter pJobName = new OracleParameter("i_job_name", hfAutosysJobname.Value);
//                OracleParameter pStatusTxt = new OracleParameter("i_statustxt", "");
//                OracleParameter pAlarmTxt = new OracleParameter("i_alarmtxt", "");
//                OracleParameter pEvtTime = new OracleParameter("i_event_time_txt", "");
//                OracleParameter pTxt = new OracleParameter("i_txt", "");
//                OracleParameter pRC = new OracleParameter("Return_Value", OracleDbType.Int32, ParameterDirection.ReturnValue);

//                string ExecCmd = string.Format("{0}.{1}SENDEVENT", DbAccess.AutosysSchema, DbAccess.AutosysTablePrefix);
//                int Ret = CallSP.Exec(ExecCmd, CommandType.StoredProcedure, pRC, pEventText, pJobName,
//                    pStatusTxt, pAlarmTxt, pEvtTime, pTxt);

//                //if (r.Success)
//                bool bSuccess = pRC.Value.ToString().Equals("1");
//                if (bSuccess)
//                {
//                    Master.Message = string.Format("The {0} Command for Job {1} was successfully executed.",
//                     hfAutosysEvent.Value, hfAutosysJobname.Value);
//                    Thread.Sleep(2000);
//                }
//                else
//                    Master.Message = "The start return code is: " + Ret.ToString() + "   " + CallSP.LastErrorMessage + "   " + pRC.Value.ToString();


//                //  Log it.
//                GeneralDatabaseAccess.LogEvent(Master.curUser.EmployeeID, "AutosysStart.aspx", hfAutosysEvent.Value + " AUTOSYS OD: " + hfAutosysJobname.Value,
//                    string.Format("Response: {0} {1}", pRC.Value, (bSuccess ? "Success" : "Failed")), UserToolLogLevel.Audit);
//            }
//            else
//                Master.Message = "The process can not be started because the status is: " +
//                    Rdr.oraRdr.GetString(1);
//        }
//        Rdr.Dispose();

//        //  Refresh the screen to show that it is running.
//        RefreshJobStatus();
//    }
//    private void RefreshJobStatus()
//    {
//        if (ddlAutosysOD.SelectedIndex == 0)
//        {
//            divAutosysOD.Style["display"] = "none";
//            return;
//        }

//        BasicOraReader Rdr = new BasicOraReader(DbAccess.AutosysCS);
//        string Cmd = string.Format(@"SELECT a.job_name,{0}.utc.conv (b.last_start),
//      {0}.utc.conv (b.last_end), b.status, c.Text,
//      {0}.f_num_to_time ( {0}.utc.conv (b.last_end) - {0}.utc.conv (b.last_start) ) Elapsed,
//      decode(b.last_start, 999999999, 'N', 'Y') validStart,
//      decode(b.last_end, 999999999, 'N', 'Y') validEnd,
//      a.description
//  FROM {0}.{1}job a, {0}.{1}job_status b
//  join {0}.{1}intcodes c on b.status=c.code
// WHERE   a.joid = b.joid and a.job_name LIKE '{2}' 
//  and a.is_active = 1 and a.is_currver = 1
//ORDER BY   last_start DESC",
//                           DbAccess.AutosysSchema, DbAccess.AutosysTablePrefix, hfAutosysJobname.Value);
//        ReturnCodeDTO rc = Rdr.OpenReturn(Cmd);

//        if (rc.Success)
//        {
//            if (Rdr.oraRdr.Read() == true)
//            {
//                bool ValStart = Rdr.oraRdr.GetString(6).Equals("Y");
//                bool ValEnd = Rdr.oraRdr.GetString(7).Equals("Y");

//                divAutosysOD.Style["display"] = "block";
//                lblAutosysODDesc.Text = Rdr.oraRdr.GetString(8);// ddlAutosysOD.SelectedItem.Text;
//                lblStatus.Text = "Status: " + Rdr.oraRdr.GetString(4);
//                if (ValStart)
//                    lblStarted.Text = "Started: " + Rdr.oraRdr.GetDateTime(1).ToString();
//                else
//                    lblStarted.Text = "Started: N/A";

//                if (ValEnd)

//                    lblEnded.Text = "Ended: " + Rdr.oraRdr.GetDateTime(2).ToString();
//                else
//                    lblEnded.Text = "Ended: N/A";

//                if (ValStart && ValEnd)
//                    lblStartedBy.Text = "Elapsed: " + Rdr.oraRdr.GetString(5);
//                else
//                    lblStartedBy.Text = "Elapsed: N/A";
//            }
//            else
//            {
//                Master.Message = "The job is no longer defined in autosys";
//            }
//        }
//        else
//            Master.Message = "Open connection returned the following: <br>" + rc.Message;

//        Rdr.Dispose();
//    }
    #endregion
}

