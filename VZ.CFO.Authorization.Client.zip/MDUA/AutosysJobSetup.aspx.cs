﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using MDUA.DataAccess;
using MDUA.BusinessLogic;

using System.Text;
using System.Drawing;
using MDUA.DTO;

public partial class AutosysJobSetup : System.Web.UI.Page
{
    private DropDownList ddlJobNames = null;

    private DropDownList ddlGroupNames = null;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Master.curUser.Role != UserRole.Admin)
        {
            Master.PendingMessage = "You don't have access to define On Demand Jobs";
            Response.Redirect("~/Default.aspx", true);
            return;
        }

        Master.PageTitle = "OD Job Setup";
        /*if (ddlJobType.Items.Count == 0) {
            if (DbAccess.AutosysSchema.ToUpper() == "MDBADMIN") {
                ddlJobType.Items.Add(new ListItem("Box Jobs", "b"));
                ddlJobType.Items.Add(new ListItem("Commands", "c"));
                ddlJobType.Items.Add(new ListItem("File Watcher", "f"));
            } else {
                ddlJobType.Items.Add(new ListItem("Box Jobs", "98"));
                ddlJobType.Items.Add(new ListItem("Commands", "99"));
                ddlJobType.Items.Add(new ListItem("File Watcher", "102"));
            }
            ddlJobType.Items[0].Selected = true;            
        }*/

        FillAutosysTable(hfEdtEvent.Value, hfEdtJob.Value);
    }

    private void FillAutosysTable(string AsysEvent, string AsysJobID)
    {
        //hfEdtJob.Value = AsysJobName;
        hfEdtJob.Value = AsysJobID;
        hfEdtEvent.Value = AsysEvent;

        //Color AltBgnd = Color.FromArgb(231, 242, 254); //#E7F2FE
        //Color RegBgnd = Color.White;
        int MainRowCnt = 0;
        // jevans 1215/2010 this string is never used? 
        //StringBuilder sbNames = new StringBuilder();

        while (tblAsysJobs.Rows.Count > 1)
            tblAsysJobs.Rows.RemoveAt(1);

        //  Fill Autosys Names DropDownList.
        FillAutosysDDL();

        //  Read the current Autosys Jobs to display.
        BasicOraReader Rdr = new BasicOraReader(GeneralDatabaseAccess.GetOracleConnectionString());
        string Cmd = @"select a.event, G.Group_Name, a.job_name, a.description, a.button_text, a.job_id, a.esp_job_id, count(u.employee_id)
FROM ops_on_demand_jobs a
join ops_on_demand_job_group g on a.job_group_id = g.group_id
left outer join ops_on_demand_job_access u on a.job_id=u.job_id
group by a.event, G.Group_Name, a.job_name, a.description, a.button_text, a.job_id, a.esp_job_id
order by a.job_name";
        if (Rdr.Open(Cmd) == false || Rdr.LastErrorMessage.Length > 0)
        {
            Master.Message = "An error occurred trying to read the On Demand information: " +
                Rdr.LastErrorMessage;
            return;
        }

        //  If we aren't editing an existing ESP Job, put in a spot to add a new one.
        TableRow trNew = null;
        if (AsysJobID == null || AsysJobID.Length == 0 || Rdr.oraRdr.HasRows == false)
        {
            MainRowCnt++;
            trNew = new TableRow();
            //trNew.BackColor = (((MainRowCnt & 1) == 1) ? RegBgnd : AltBgnd);
            if (AddEditRow(trNew, null) == true)
                tblAsysJobs.Rows.Add(trNew);
        }

        while (Rdr.oraRdr.Read())
        {

            int oEvent = Rdr.oraRdr.GetOrdinal("EVENT");
            int oJobID = Rdr.oraRdr.GetOrdinal("JOB_ID");
            int oESPJobID = Rdr.oraRdr.GetOrdinal("ESP_JOB_ID");
            int oDescription = Rdr.oraRdr.GetOrdinal("DESCRIPTION");
            int oJobName = Rdr.oraRdr.GetOrdinal("JOB_NAME");
            int oGroupName = Rdr.oraRdr.GetOrdinal("Group_Name");

            ++MainRowCnt;

            //  Create a row for the budget group.
            TableRow tr = new TableRow();
            tr.HorizontalAlign = HorizontalAlign.Left;
            //tr.BackColor = (((MainRowCnt & 1) == 1) ? RegBgnd : AltBgnd);
            tblAsysJobs.Rows.Add(tr);

            //  If this is the job that they want to edit, put it in edit boxes.
            if (AsysJobID.Length > 0 &&
                //AsysJobName.Equals(Rdr.oraRdr.GetString(1)) &&
                //AsysEvent.Equals(Rdr.oraRdr.GetString(0)))
                AsysJobID.Equals(Convert.ToString(Rdr.oraRdr.GetInt32(oESPJobID))))

            {
                if (AddEditRow(tr, Rdr) == false)
                    tblAsysJobs.Rows.Remove(tr);
                continue;
            }

            TableCell tc;

            //  Add the icons to edit and delete this item.
            tc = new TableCell();
            tc.HorizontalAlign = HorizontalAlign.Center;

            ImageButton imgbtn = null;

            imgbtn = new ImageButton();
            imgbtn.ImageUrl = "~/Images/TextFile.gif";

            //imgbtn.CommandArgument = Rdr.oraRdr.GetString(0) + "|" + Rdr.oraRdr.GetString(1);
            imgbtn.CommandArgument = Rdr.oraRdr.GetString(oEvent) + "|" + Rdr.oraRdr.GetInt32(oESPJobID) + "|" + Rdr.oraRdr.GetString(oJobName) + "|" + Rdr.oraRdr.GetString(oDescription) + "|" + Rdr.oraRdr.GetInt32(oJobID);
            imgbtn.Click += btnEdit_Click;
            imgbtn.ID = string.Format("btnEdt{0}", MainRowCnt);
            imgbtn.AlternateText = "Edit Job";
            imgbtn.Attributes["onmouseover"] = "this.src='Images/TextFileHilite.gif'";
            imgbtn.Attributes["onmouseout"] = "this.src='Images/TextFile.gif'";
            tc.Controls.Add(imgbtn);
            tr.Cells.Add(tc);

            Literal lit = new Literal();
            lit.Text = "&nbsp;";
            tc.Controls.Add(lit);

            imgbtn = new ImageButton();
            imgbtn.ImageUrl = "~/Images/Delete.gif";
            //imgbtn.CommandArgument = Rdr.oraRdr.GetString(0) + "|" + Rdr.oraRdr.GetString(1);
            imgbtn.CommandArgument = Rdr.oraRdr.GetString(oEvent) + "|" + Rdr.oraRdr.GetInt32(oESPJobID) + "|" + Rdr.oraRdr.GetString(oJobName) + "|" + Rdr.oraRdr.GetString(oDescription) + "|" + Rdr.oraRdr.GetInt32(oJobID);
            imgbtn.Click += btnDelete_Click;
            imgbtn.ID = string.Format("btnDel{0}", MainRowCnt);
            imgbtn.AlternateText = "Del Job";
            imgbtn.Attributes["onmouseover"] = "this.src='Images/DeleteHilite.gif'";
            imgbtn.Attributes["onmouseout"] = "this.src='Images/Delete.gif'";

            HtmlGenericControl spn = new HtmlGenericControl();
            spn.TagName = "span";
            spn.Attributes["onclick"] = string.Format("return confirm('Are you sure that you want to delete this Job?  There are {0} users with this job assigned to them.  They will not be allowed to run this job if you delete the definition.  Click OK to delete.')",
                Rdr.oraRdr.GetDecimal(7));
            spn.Controls.Add(imgbtn);
            tc.Controls.Add(spn);

            //  Get the Autosys Event, Job Name, Description, Button Text
            for (int c = 0; c < 8; c++)
            {
                //if (c != 4 && c != 5) //Excluding job id and esp job id which need not be added to the grid
                if (c != 5 && c != 6) //Excluding job id and esp job id which need not be added to the grid
                {
                    tc = new TableCell();
                    if (Rdr.oraRdr.IsDBNull(c) == false)

                        tc.Text = string.Format("{0}", Rdr.oraRdr.GetValue(c));
                    tr.Cells.Add(tc);
                }
            }
            tr.Cells.Add(tc);
        }

        //  If there are no Autosys Jobs left to be added, remove the empty add row.
        if (ddlJobNames.Items.Count == 0 && trNew != null)
            tblAsysJobs.Rows.Remove(trNew);
    }

    private bool FillAutosysDDL()
    {
        ddlGroupNames = new DropDownList();
        ddlGroupNames.ID = "ddlGroupNames";
        BasicOraReader groupRdr = new BasicOraReader(GeneralDatabaseAccess.GetOracleConnectionString());
        string groupQuery = "SELECT GROUP_ID, GROUP_NAME FROM OPS_ON_DEMAND_JOB_GROUP ORDER BY GROUP_NAME";
        if (!groupRdr.Open(groupQuery))
        {
            Master.Message = "An error occurred trying to read groups: " +
                groupRdr.LastErrorMessage;
            return false;
        }

        int ordGroupId = groupRdr.oraRdr.GetOrdinal("GROUP_ID");
        int ordGroupName = groupRdr.oraRdr.GetOrdinal("GROUP_NAME");

        while (groupRdr.oraRdr.Read())
        {
            ddlGroupNames.Items.Add(new ListItem(groupRdr.oraRdr.GetString(ordGroupName), Convert.ToString(groupRdr.oraRdr.GetInt64(ordGroupId))));
        }
        groupRdr.Dispose();

        ddlJobNames = new DropDownList();
        ddlJobNames.ID = "ddlJobNames";
        BasicOraReader AsysRdr = new BasicOraReader(GeneralDatabaseAccess.GetOracleConnectionString());
        //string SelCmd = string.Format("select JOB_NAME, Description from {0}.{1}job where job_type='{2}'",
        //    DbAccess.AutosysSchema, DbAccess.AutosysTablePrefix,
        //    ddlJobType.SelectedValue);

        //string SelCmd = string.Format("select a.JOB_NAME, a.Description from USER_TOOL.OPS_ON_DEMAND_ESPJOBS a left outer join user_tool.ops_on_demand_jobs u on a.JOB_NAME = u.JOB_NAME and a.Description = u.Description where u.job_name is null",
            //ddlJobType.SelectedValue);

        string SelCmd = "select a.JOB_NAME, a.Description, a.ESP_JOB_ID from OPS_ON_DEMAND_ESPJOBS a left join ops_on_demand_jobs u on a.esp_job_id= u.esp_job_id and a.JOB_NAME = u.job_name and a.Description = u.Description WHERE U.JOB_NAME IS NULL";

        //if (chkOnDemand.Checked)
            //SelCmd += "  and job_name like '%_OD'";
        SelCmd += " order by a.JOB_NAME";
        if (!AsysRdr.Open(SelCmd))
        {
            Master.Message = "An error occurred trying to read Jobs: " +
                AsysRdr.LastErrorMessage;
            return false;
        }

        while (AsysRdr.oraRdr.Read())
        {
            string Desc = "<No Description>";
            int ordDescription = AsysRdr.oraRdr.GetOrdinal("DESCRIPTION");
            int ordJobName = AsysRdr.oraRdr.GetOrdinal("JOB_NAME");
            int ordESPJobID = AsysRdr.oraRdr.GetOrdinal("ESP_JOB_ID");
            //if (AsysRdr.oraRdr.IsDBNull(1) == false)
                if (AsysRdr.oraRdr.IsDBNull(ordDescription) == false)
                //Desc = AsysRdr.oraRdr.GetString(1);
                    Desc = AsysRdr.oraRdr.GetString(ordDescription);
            //ddlJobNames.Items.Add(new ListItem(AsysRdr.oraRdr.GetString(0) + " - " +
                //Desc, AsysRdr.oraRdr.GetString(0)));
            ddlJobNames.Items.Add(new ListItem(AsysRdr.oraRdr.GetString(ordJobName) + " - " + 
                Desc, Convert.ToString(AsysRdr.oraRdr.GetInt32(ordESPJobID))));
        }
        AsysRdr.Dispose();
        return true;
    }

    private bool AddEditRow(TableRow tr, BasicOraReader Rdr)
    {
        
        TableCell tc;

        //  Add the icons to Save or Cancel this item.
        tc = new TableCell();
        tc.HorizontalAlign = HorizontalAlign.Center;

        ImageButton imgbtn = null;

        imgbtn = new ImageButton();
        imgbtn.ImageUrl = "~/Images/Save.gif";
        imgbtn.Click += btnSave_Click;
        imgbtn.ID = "btnSave";
        imgbtn.AlternateText = "Save Job";
        imgbtn.Attributes["onmouseover"] = "this.src='Images/SaveHilite.gif'";
        imgbtn.Attributes["onmouseout"] = "this.src='Images/Save.gif'";
        tc.Controls.Add(imgbtn);

        if (Rdr != null)
        {
            Literal lit = new Literal();
            lit.Text = "&nbsp;";
            tc.Controls.Add(lit);

            imgbtn = new ImageButton();
            imgbtn.ImageUrl = "~/Images/Cancel.gif";
            imgbtn.Click += btnCancel_Click;
            imgbtn.ID = "btnCancel";
            imgbtn.AlternateText = "Cancel Job";
            imgbtn.Attributes["onmouseover"] = "this.src='Images/CancelHilite.gif'";
            imgbtn.Attributes["onmouseout"] = "this.src='Images/Cancel.gif'";
            tc.Controls.Add(imgbtn);
        }
        tr.Cells.Add(tc);

        //  If we don't have a Rdr control, then this is a new item.  So give them a 
        //  drop down list to pick the Autosys Job Names; otherwise, just display the
        //  JOB Name, since they can't edit it.
        tc = new TableCell();
        if (Rdr != null)
        {
            int orJobName = Rdr.oraRdr.GetOrdinal("JOB_NAME");
            int orEvent = Rdr.oraRdr.GetOrdinal("EVENT");
            int orDescription = Rdr.oraRdr.GetOrdinal("DESCRIPTION");

            //tc.Text = Rdr.oraRdr.GetString(0);
            tc.Text = Convert.ToString(Rdr.oraRdr[orEvent]);
            tr.Cells.Add(tc);

            //group
            tc = new TableCell();
            tc.Controls.Add(ddlGroupNames);
            tr.Cells.Add(tc);

            tc = new TableCell();
            //tc.Text = Rdr.oraRdr.GetString(1);
            tc.Text = Convert.ToString(Rdr.oraRdr[orJobName]);
            tr.Cells.Add(tc);

            //  Display the description if one exists.
            tc = new TableCell();
            //tc.Text = Rdr.oraRdr.GetString(2);
            tc.Text = Convert.ToString(Rdr.oraRdr[orDescription]);
            tr.Cells.Add(tc);
        }
        else
        {
            string[] asysEvts = ConfigurationManager.AppSettings["AutosysEvents"].Split('|');
            DropDownList ddlEvents = new DropDownList();
            ddlEvents.ID = "ddlEvents";
            foreach (string evt in asysEvts)
                ddlEvents.Items.Add(evt);
            tc.Controls.Add(ddlEvents);
            tr.Cells.Add(tc);

            //group
            tc = new TableCell();
            tc.Controls.Add(ddlGroupNames);
            tr.Cells.Add(tc);

            tc = new TableCell();
            tc.ColumnSpan = 2;
            tc.Controls.Add(ddlJobNames);
            tr.Cells.Add(tc);
        }


        //  Create an edit box for the button text.
        TextBox tbBtnTxt = new TextBox();
        tbBtnTxt.ID = "tbBtnTxt";
        if (Rdr != null)
        //tbBtnTxt.Text = Rdr.oraRdr.GetString(3);
        {
            int orButtonText = Rdr.oraRdr.GetOrdinal("BUTTON_TEXT");
            tbBtnTxt.Text = Convert.ToString(Rdr.oraRdr[orButtonText]);
        }
        tbBtnTxt.MaxLength = 30;
        tc = new TableCell();
        tc.ColumnSpan = 2;
        tc.Controls.Add(tbBtnTxt);
        tr.Cells.Add(tc);
        return true;
    }

    protected void btnEdit_Click(object sender, EventArgs e)
    {
        ImageButton ib = (ImageButton)sender;
        string[] sInfo = ib.CommandArgument.Split('|');
        FillAutosysTable(sInfo[0], sInfo[1]);
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {
        ImageButton ib = (ImageButton)sender;
        string[] sInfo = ib.CommandArgument.Split('|');
        BasicOraCommand Wrtr = new BasicOraCommand(GeneralDatabaseAccess.GetOracleConnectionString());
        //string Cmd = string.Format("delete from ops_on_demand_jobs where job_name='{1}' and event='{0}'",
            //sInfo[0], sInfo[1]);
    //    string Cmd = string.Format("delete from ops_on_demand_job_access where job_ID='{0}'",
    //sInfo[4]);

        string Cmd = string.Format("delete from ops_on_demand_job_access where job_ID in (select job_id from ops_on_demand_jobs where esp_job_id='{0}')",
    sInfo[1]);

        Wrtr.ExecOpened(Cmd);
        Master.Message = string.Format("'{1}-{2}'with event '{0}' was successfully deleted.", sInfo[0], sInfo[2], sInfo[3]);

        //Cmd = string.Format("delete from ops_on_demand_job_access where job_ID='{1}' and event='{0}'",
            //sInfo[0], sInfo[1]);
        Cmd = string.Format("delete from ops_on_demand_jobs where esp_job_id='{0}'",
    sInfo[1]);

        if (Wrtr.Exec(Cmd) < 1)
        {
            Master.Message = string.Format("{0} {1} could not be deleted due to the following error: {2}",
                sInfo[2], sInfo[3], Wrtr.LastErrorMessage);
            FillAutosysTable("", "");
            return;
        }

        FillAutosysTable("", "");
    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        DropDownList ddlGroupNames = (DropDownList)tblAsysJobs.FindControl("ddlGroupNames");
        DropDownList ddlJobNames = (DropDownList)tblAsysJobs.FindControl("ddlJobNames");
        DropDownList ddlEvents = (DropDownList)tblAsysJobs.FindControl("ddlEvents");
        TextBox tbBtnTxt = (TextBox)tblAsysJobs.FindControl("tbBtnTxt");
         
        if (tbBtnTxt == null)
        {
            Master.Message = "Could not find all the controls to save the data";
            return;
        }

        tbBtnTxt.Text = tbBtnTxt.Text.Trim();
        if (tbBtnTxt.Text.Length == 0)
        {
            Master.Message = "The Button Text must be filled in.";
            return;
        }

        BasicOraCommand Wrtr = new BasicOraCommand(GeneralDatabaseAccess.GetOracleConnectionString());
        string Cmd = "";
        string AuditText = "";
        if (hfEdtJob.Value == null || hfEdtJob.Value.Length == 0)
        {
            //  It is a new item, try and add it.
//            Cmd = string.Format(@"insert into ops_on_demand_jobs (job_name, description, 
//button_text, event, date_created, date_modified) values ('{0}', '{1}','{2}','{3}',
//sysdate,sysdate)",
//                   ddlJobNames.SelectedValue,
//                   ddlJobNames.SelectedItem.Text.Substring(ddlJobNames.SelectedValue.Length + 3),
//                   tbBtnTxt.Text, ddlEvents.SelectedValue);

            Cmd = string.Format(@"insert into ops_on_demand_jobs (job_name, description, 
            sub_appl_name, job_id, esp_job_id,  event, button_text, date_created, date_modified, job_group_id)
                (SELECT job_name, description, sub_appl_name, mdua_jobid_seq.nextval, esp_job_id, '{1}', '{2}', sysdate, sysdate, '{3}' from 
                    USER_TOOL.OPS_ON_DEMAND_ESPJOBS where esp_job_id = '{0}')", ddlJobNames.SelectedValue, ddlEvents.SelectedValue, tbBtnTxt.Text, ddlGroupNames.SelectedValue);

            AuditText = string.Format("Added New On Demand Job: {0} of {1} in group {2}",
                ddlEvents.SelectedValue, ddlJobNames.SelectedItem.Text, ddlGroupNames.SelectedItem.Text);
        }
        else
        {
//            Cmd = string.Format(@"update ops_on_demand_jobs set button_text='{0}',date_modified=sysdate 
// where job_name='{1}' and event='{2}'",
//                   tbBtnTxt.Text,
//                   hfEdtJob.Value, hfEdtEvent.Value);

            Cmd = string.Format(@"update ops_on_demand_jobs set button_text='{0}',date_modified=sysdate, job_group_id = '{2}'
             where esp_job_id = '{1}'", tbBtnTxt.Text, hfEdtJob.Value, ddlGroupNames.SelectedItem.Value);

            AuditText = "Updated Button Text for " + hfEdtEvent.Value + " of On Demand Job (" + hfEdtJob.Value +
                ") to (" + tbBtnTxt.Text + ")";
        }

        if (Wrtr.Exec(Cmd) != 1)
        {
            if (Wrtr.LastErrorMessage.ToLower().Contains("constraint") &&
                ddlEvents != null)
                Master.Message = string.Format("On Demand Event '{0}' for Job '{1}' is already defined.",
                    ddlEvents.SelectedValue, ddlJobNames.SelectedValue);
            else
                Master.Message = "There was an error trying to save the data: " +
                    Wrtr.LastErrorMessage;
            return;
        }

        Master.Message = "The On Demand Job was successfully saved.";
        GeneralDatabaseAccess.LogEvent(Master.curUser.EmployeeID, "AutosysJobSetup", AuditText, "Success", UserToolLogLevel.Audit);
        FillAutosysTable("", "");
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        FillAutosysTable("", "");
    }
    protected void btnRefresh_Click(object sender, EventArgs e)
    {
        FillAutosysTable("", "");
    }
}
