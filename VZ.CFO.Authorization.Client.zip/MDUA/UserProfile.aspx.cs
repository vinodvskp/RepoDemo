﻿using System;
using System.Web.UI.WebControls;
using MDUA.DataAccess;
using MDUA.BusinessLogic;
using System.Collections.Generic;
using MDUA.DTO;

public partial class UserProfile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Master.PageTitle = "User Profile";
        if (Master.curUser.Role != UserRole.Admin) {
            if (!Master.curUser.CanAssignUserFileType && !Master.curUser.CanAssignAutosysOD) {
                Master.PendingMessage = "You don't have access to edit user profiles.";
                Server.Transfer("~/Default.aspx");
                return;
            }
        }

        Master.NavInstructionsVisible = true;

        if (!IsPostBack)
        {
            if (Master.curUser.Role != UserRole.Admin)
            {
                ddlRoles.Enabled = false;

                //  Set if they can assign Autosys OD Jobs
                lbAutosysOD.Enabled = Master.curUser.CanAssignAutosysOD;
                btnASODDown.Enabled = Master.curUser.CanAssignAutosysOD;
                btnASODUp.Enabled = Master.curUser.CanAssignAutosysOD;

                //  Can they assign User File Types.
                 lbInputFiles.Enabled = Master.curUser.CanAssignUserFileType;

            }

            List<UserToolRole> roles = GeneralDatabaseAccess.GetRoles();

            ddlRoles.Items.Clear(); 
            foreach (UserToolRole role in roles) {
                ddlRoles.Items.Add(new ListItem(role.Description, role.Role));
            }

            string uId = Request.QueryString["ID"];
            UserInfo ui = GeneralDatabaseAccess.GetUserData(uId);
            if (ui == null) {
                Server.Transfer("~/Users.aspx");
                return;
            }

            lblEmployeeID.Text = uId;
            lblFirstName.Text = ui.FirstName;
            lblLastName.Text = ui.LastName;
            lblEmail.Text = ui.EMail;
            lblUserId.Text = ui.UserId;
            lblActive.Text = ui.Active ? "Yes" : "No";
            hfLastRole.Value = ((int)ui.Role).ToString();
            ddlRoles.SelectedValue = ((int)ui.Role).ToString();
            chkAdjPostNow.Checked = ui.CanPostAdjImmediately;
            chkAdjAnyPeriod.Checked = ui.CanPostAdjToAnyPeriod;
            chkCanAddKeys.Checked = ui.CanAddUserInputKeys;
            chkAddFileTypes.Checked = ui.CanAddNewFileType;

            chkAssignUserFileTypes.Checked = ui.CanAssignUserFileType;
            chkAutosysOD.Checked = ui.CanAssignAutosysOD;
            chkOutline.Checked = ui.CanModifyOutline;
            chkCPGA.Checked = ui.CanProcessCpga;
            chkCanPostPrev.Checked = ui.CanPostToAnyPeriod;


            List<UserFileTypeDescription> userFileTypeDescriptions = GeneralDatabaseAccess.GetUserFileTypeDescriptions(uId);

            lbInputFiles.Items.Clear();
            ListItem item;
            foreach (UserFileTypeDescription userFileTypeDescription in userFileTypeDescriptions) {
                item = new ListItem(
                    string.Format("{0}: {1} - {2}", userFileTypeDescription.FactTableDescription
                        , userFileTypeDescription.Description
                        , userFileTypeDescription.FileTypeCode)
                    , userFileTypeDescription.FileTypeCode);
                item.Selected = !string.IsNullOrEmpty(userFileTypeDescription.EmployeeId);
                lbInputFiles.Items.Add(item);
            }

            List<UserOnDemandDescription> userOnDemandDescriptions = GeneralDatabaseAccess.GetUserOnDemandDescriptions(uId);

            lbAutosysOD.Items.Clear();
            
            foreach (UserOnDemandDescription userOnDemandDescription in userOnDemandDescriptions) {
                item = new ListItem(
                    string.Format("{0} - {1}", userOnDemandDescription.ButtonText, userOnDemandDescription.AutomationToolJobName)
                    , Convert.ToString(userOnDemandDescription.JobId));
                    
                item.Selected = userOnDemandDescription.SequenceId.HasValue;
                lbAutosysOD.Items.Add(item);
            }
        }
    }
    protected void btnReturn_Click(object sender, EventArgs e)
    {
        Server.Transfer("~/Users.aspx");
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        UserInfo ui = new UserInfo();
        ui.EmployeeID = lblEmployeeID.Text;
        ui.Role = (UserRole)int.Parse(ddlRoles.SelectedValue);
        ui.CanAddUserInputKeys = chkCanAddKeys.Checked;
        ui.CanPostAdjImmediately = chkAdjPostNow.Checked;
        ui.CanPostAdjToAnyPeriod = chkAdjAnyPeriod.Checked;
        ui.CanAssignUserFileType = chkAssignUserFileTypes.Checked;
        ui.CanAssignAutosysOD = chkAutosysOD.Checked;
        ui.CanAddNewFileType = chkAddFileTypes.Checked;
        ui.CanModifyOutline = chkOutline.Checked;
        ui.CanProcessCpga = chkCPGA.Checked;
        ui.CanPostToAnyPeriod = chkCanPostPrev.Checked;

        List<string> listInputFiles = new List<string>();
        List<int> listOnDemandJobs = new List<int>();
        
        foreach (ListItem item in lbInputFiles.Items) {
            if (item.Selected) { listInputFiles.Add(item.Value); }
        }

        foreach (ListItem item in lbAutosysOD.Items) {
            if (item.Selected) { listOnDemandJobs.Add(Convert.ToInt32(item.Value)); }

        }

        if (!GeneralDatabaseAccess.UpdateUserInfo(ui, Master.curUser.EmployeeID, listInputFiles, listOnDemandJobs)) {
            Master.Message = string.Format("An error occurred trying to update {0} {1} ({2}) to be a {3}",
                lblFirstName.Text, lblLastName.Text, lblEmployeeID.Text, ddlRoles.SelectedItem);
            return;
        } else {
            // jevans 8/8/2012 - only log event if the user role changed because 
            //  currently user update routinely adds this event even if role did not change
            if (!hfLastRole.Value.Equals(ddlRoles.SelectedValue)) {
                GeneralDatabaseAccess.LogEvent(Master.curUser.EmployeeID, "User Profile",
                    string.Format("Changed Role from {0} to {1} for user {2}", hfLastRole.Value,
                        ddlRoles.SelectedValue, lblEmployeeID.Text), "Success", UserToolLogLevel.Audit);
            }
        }

        Master.PendingMessage = "The user was successfully updated.";

        Server.Transfer("~/Users.aspx");
    }

    protected void btnMoveUp_Click(object sender, EventArgs e) {
        int[] indices = lbAutosysOD.GetSelectedIndices();

        if (indices == null || indices.Length > 1)
        {
            Master.Message = "You must select one item from the AutoSys OD list box before trying to move them within the list.";
            return;
        }
    }

    protected void btnASODUp_Click(object sender, EventArgs e)
    {
        if (lbAutosysOD.SelectedIndex == -1) {
            Master.Message = "You must select an item to move.";
            return;
        }

        if (lbAutosysOD.SelectedIndex == 0)
            return;

        int idx = lbAutosysOD.SelectedIndex;
        ListItem li = lbAutosysOD.SelectedItem;
        lbAutosysOD.Items.RemoveAt(idx);
        lbAutosysOD.Items.Insert(idx - 1, li);
    }

    protected void btnASODDown_Click(object sender, EventArgs e)
    {
        if (lbAutosysOD.SelectedIndex == -1) {
            Master.Message = "You must select an item to move.";
            return;
        }

        if (lbAutosysOD.SelectedIndex == lbAutosysOD.Items.Count - 1)
            return;

        int idx = lbAutosysOD.SelectedIndex;
        ListItem li = lbAutosysOD.SelectedItem;
        lbAutosysOD.Items.RemoveAt(idx);
        lbAutosysOD.Items.Insert(idx + 1, li);
    }
}
