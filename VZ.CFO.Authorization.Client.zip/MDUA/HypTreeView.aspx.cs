﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using MDUA.DataAccess;
using MDUA.BusinessLogic;

public partial class HypTreeView : System.Web.UI.Page
{
    private int NodeNbr = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        Master.PageTitle = "Dimension Information";
        Master.NavInstructionsVisible = true;

        if (IsPostBack == false)
        {
            string SelVal = Request.QueryString["SEL"];
            if (SelVal == null || SelVal.Length == 0)
                SelVal = DbAccess.FunctionTblName;

            string Del = Request.QueryString["DEL"];
            if (Del != null && Del.Trim().Length > 0)
            {
                if (DbAccess.DeleteDimension(Del, SelVal, Master.curUser.EmployeeID))
                    Master.Message = "The dimension was successfully deleted";
            }

            ArrayList arrDimType = DbAccess.LoadLookupType("DIM_TYPE", Master.curUser.EmployeeID);
            foreach (HypWebLookup wl in arrDimType)
            {
                ListItem li = new ListItem(wl.Description, wl.Value);
                if (wl.Value.Equals(SelVal) == true)
                    li.Selected = true;
                ddlDimType.Items.Add(li);
            }
            FillTree();
        }
    }

    private void FillTree()
    {
        //while (tblTree.Rows.Count > 1)
        //    tblTree.Rows.RemoveAt(1);

        lblDesc.Text = ddlDimType.SelectedItem + " Data";
        HypWebSettings cfg = DbAccess.LoadWebSetting(Master.curUser.EmployeeID);
        HypDimension root = Utils.BuildDimTree(ddlDimType.SelectedValue, Master.curUser.EmployeeID);
        NodeNbr = 0;
        FillNode(root, tblTree);
    }

    private void FillNode(HypDimension node, HtmlTable tbl)
    {
        NodeNbr++;
        HtmlTableRow tr = new HtmlTableRow();
        tbl.Controls.Add(tr);

        //  Display the Expand / Collapse Icon if needed
        HtmlTableCell tc = new HtmlTableCell();
        tc.Width = "20px";
        tc.VAlign = "top";
        Image img = null;
        if (node.arrChildren != null)
        {
            img = new Image();
            if (node.Parent.Length == 0)
                img.ImageUrl = "~/Images/Collapse.gif";
            else
                img.ImageUrl = "~/Images/Expand.gif";
            tc.Controls.Add(img);
        }
        tr.Controls.Add(tc);

        //  Display a hyper link to the item to edit it.
        tc = new HtmlTableCell();
        tc.VAlign = "top";
        tc.Align = "left";

        if (Master.curUser.Role == UserRole.ReadOnly)
        {
            Label lbl = new Label();
            lbl.Text = node.MemberName;
            if (node.Alias.Length > 0)
                lbl.Text += " - " + node.Alias;
            tc.Controls.Add(lbl);
        }
        else
        {
            HyperLink lnk = new HyperLink();
            lnk.NavigateUrl = string.Format("~/EditDimension.aspx?MN={0}&PAR={1}&SEL={2}",
                Server.UrlEncode(node.MemberName), Server.UrlEncode(node.Parent), ddlDimType.SelectedValue);
            lnk.Text = node.MemberName;
            if (node.Alias.Length > 0)
                lnk.Text += " - " + node.Alias;
            tc.Controls.Add(lnk);

            //  Don't add the insert buttons for the root node.
            if (NodeNbr > 1 && Master.curUser.CanModifyOutline)
            {
                Literal lit = new Literal();
                lit.Text = "&nbsp;";
                tc.Controls.Add(lit);

                //  Add the button to add a new item above this item.
                lnk = new HyperLink();
                lnk.NavigateUrl = string.Format("~/EditDimension.aspx?AF={0}&PAR={1}&SEL={2}",
                    node.MemberName, node.Parent, ddlDimType.SelectedValue);
                tc.Controls.Add(lnk);

                Image btnImg = new Image();
                btnImg.ImageUrl = "~/Images/AddAbove.bmp";
                btnImg.Attributes["onmouseover"] = "this.src='Images/AddAboveHilite.bmp'";
                btnImg.Attributes["onmouseout"] = "this.src='Images/AddAbove.bmp'";
                btnImg.AlternateText = "Add a new member before this member";
                lnk.Controls.Add(btnImg);

                //ImageButton ib = new ImageButton();
                //ib.ID = string.Format("btnAA{0}", NodeNbr);
                //ib.ImageUrl = "~/Images/AddAbove.bmp";
                //ib.Attributes["onmouseover"] = "this.src='Images/AddAboveHilite.bmp'";
                //ib.Attributes["onmouseout"] = "this.src='Images/AddAbove.bmp'";
                //ib.PostBackUrl = string.Format("~/EditDimension.aspx?AF={0}&PAR={1}&SEL={2}",
                //    node.MemberName, node.Parent, ddlDimType.SelectedValue);
                //ib.AlternateText = "Add a new dimension above this dimension";
                //ib.EnableViewState = false;
                //tc.Controls.Add(ib);

                lit = new Literal();
                lit.Text = "&nbsp;";
                tc.Controls.Add(lit);

                //  Add the button to add a new item below this item.
                //ib = new ImageButton();
                //ib.ID = string.Format("btnAB{0}", NodeNbr);
                //ib.ImageUrl = "~/Images/AddBelow.bmp";
                //ib.Attributes["onmouseover"] = "this.src='Images/AddBelowHilite.bmp'";
                //ib.Attributes["onmouseout"] = "this.src='Images/AddBelow.bmp'";
                //ib.PostBackUrl = string.Format("~/EditDimension.aspx?BE={0}&PAR={1}&SEL={2}",
                //    node.MemberName, node.Parent, ddlDimType.SelectedValue);
                //ib.AlternateText = "Add a new dimension below this dimension";
                //tc.Controls.Add(ib);
                lnk = new HyperLink();
                lnk.NavigateUrl = string.Format("~/EditDimension.aspx?BE={0}&PAR={1}&SEL={2}",
                    node.MemberName, node.Parent, ddlDimType.SelectedValue);
                tc.Controls.Add(lnk);

                btnImg = new Image();
                btnImg.ImageUrl = "~/Images/AddBelow.bmp";
                btnImg.Attributes["onmouseover"] = "this.src='Images/AddBelowHilite.bmp'";
                btnImg.Attributes["onmouseout"] = "this.src='Images/AddBelow.bmp'";
                btnImg.AlternateText = "Add a new member after this member";
                lnk.Controls.Add(btnImg);
            }
        }

        if (Master.curUser.Role == UserRole.Admin &&
            (node.arrChildren == null || node.arrChildren.Count == 0) &&
            Master.curUser.CanModifyOutline == true)
        {
            Literal lit = new Literal();
            lit.Text = "&nbsp;";
            tc.Controls.Add(lit);

            //  Add the button to add a new item below this item.
            //ImageButton ib = new ImageButton();
            //ib.ID = string.Format("btnDel{0}", NodeNbr);
            //ib.ImageUrl = "~/Images/Delete.gif";
            //ib.Attributes["onmouseover"] = "this.src='Images/DeleteHilite.gif'";
            //ib.Attributes["onmouseout"] = "this.src='Images/Delete.gif'";
            //ib.PostBackUrl = string.Format("~/HypTreeView.aspx?SEL={0}&DEL={1}",
            //    ddlDimType.SelectedValue, node.MemberName);
            //ib.AlternateText = "Delete this dimension";
            HyperLink lnk = new HyperLink();
            lnk.NavigateUrl = string.Format("~/HypTreeView.aspx?SEL={0}&DEL={1}",
                ddlDimType.SelectedValue, node.MemberName);
            tc.Controls.Add(lnk);

            Image btnImg = new Image();
            btnImg.ImageUrl = "~/Images/Delete.bmp";
            btnImg.Attributes["onmouseover"] = "this.src='Images/DeleteHilite.bmp'";
            btnImg.Attributes["onmouseout"] = "this.src='Images/Delete.bmp'";
            btnImg.AlternateText = "Delete this dimension";
            lnk.Controls.Add(btnImg);

            HtmlGenericControl spn = new HtmlGenericControl();
            spn.TagName = "span";
            spn.Attributes["onclick"] = string.Format("return confirm('Do you really want to delete the {0} Dimension?')",
                node.MemberName);
            spn.Controls.Add(lnk);
            tc.Controls.Add(spn);
        }

        tr.Controls.Add(tc);

        if (node.arrChildren != null)
        {
            HtmlGenericControl myDiv = new HtmlGenericControl();
            myDiv.TagName = "div";
            myDiv.ID = string.Format("div_{0}", NodeNbr);
            myDiv.Attributes.Add("width", "100%");
            if (node.Parent.Length > 0)
                myDiv.Style.Add("display", "none");

            tc.Controls.Add(myDiv);

            HtmlTable myTbl = new HtmlTable();
            myTbl.Width = "100%";
            myDiv.Controls.Add(myTbl);

            img.Attributes["onclick"] = string.Format("javascript:FlipNugget('{0}', '{1}')",
                img.ClientID, myDiv.ClientID);
            foreach (HypDimension hd in node.arrChildren)
                FillNode(hd, myTbl);
        }
    }
    protected void ddlDimType_SelectedIndexChanged(object sender, EventArgs e)
    {
        FillTree();
    }
    protected void btnDeleteFile_Click(object sender, ImageClickEventArgs e)
    {
        ImageButton ib = (ImageButton)sender;
        if (DbAccess.DeleteDimension(ib.CommandArgument, ddlDimType.SelectedValue, Master.curUser.EmployeeID))
            Master.Message = "The Dimension was successfully deleted.";
        else
            Master.Message = HypMDUA.ERROR_MESSAGE;
        FillTree();
    }
}
