﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Web.Configuration;
using MDUA.DataAccess;
using MDUA.BusinessLogic;

public partial class ProtectConfig : System.Web.UI.Page
{
    private string PagePswd = "Mdua@2008";
    protected void Page_Load(object sender, EventArgs e)
    {
        Master.PageTitle = "Configuration Protection";
        if (Master.SignedIn(UserRole.Admin) == false)
            return;
    }
    protected void btnProtect_Click(object sender, EventArgs e)
    {
        TextBox txtPassword = (TextBox)Page.FindControl("txtPassword");
        Label lblStatus = (Label)Page.FindControl("lblStatus");
        if (txtPassword.Text.Equals(PagePswd) == false)
        {
            lblStatus.Text = "An invalid password was provided.";
            return;
        }

        try
        {
            ProtectSection("appSettings", "DataProtectionConfigurationProvider");
            ProtectSection("connectionStrings", "DataProtectionConfigurationProvider");
            lblStatus.Text = "Configuration is protected";
        }
        catch (Exception ex)
        {
            DbAccess.LogEvent(Master.curUser.EmployeeID, "ProtectConfig.aspx", "btnProtect_Click", ex, LogLevel.Error);
            Master.Message = HypMDUA.ERROR_MESSAGE;
        }
    }
    protected void btnUnProtect_Click(object sender, EventArgs e)
    {
        if (txtPassword.Text.Equals(PagePswd) == false)
        {
            lblStatus.Text = "An invalid password was provided.";
            return;
        }

        try
        {
            UnProtectSection("appSettings");
            UnProtectSection("connectionStrings");
            lblStatus.Text = "Configuration is unprotected";
        }
        catch (Exception ex)
        {
            DbAccess.LogEvent(Master.curUser.EmployeeID, "ProtectConfig.aspx", "btnUnProtect_Click", ex, LogLevel.Error);
<<<<<<< .mine
            Master.Message = HypMDUA.ERROR_MESSAGE;
                
=======
            Master.Message = HypMDUA.ERROR_MESSAGE;
 
>>>>>>> .r4841
        }
    }

    private void ProtectSection(string sectionName, string provider)
    {
        Configuration config = WebConfigurationManager.OpenWebConfiguration(Request.ApplicationPath);

        ConfigurationSection section = config.GetSection(sectionName);

        if (section != null && !section.SectionInformation.IsProtected)
        {
            section.SectionInformation.ProtectSection(provider);
            config.Save();
        }
    }

    private void UnProtectSection(string sectionName)
    {
        Configuration config =
            WebConfigurationManager.OpenWebConfiguration(Request.ApplicationPath);

        ConfigurationSection section = config.GetSection(sectionName);

        if (section != null && section.SectionInformation.IsProtected)
        {
            section.SectionInformation.UnprotectSection();
            config.Save();
        }
    }
}
