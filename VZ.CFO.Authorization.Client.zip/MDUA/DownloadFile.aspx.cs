using System;
using System.IO;
using System.Threading;
using MDUA.DataAccess;
using MDUA.BusinessLogic;

public partial class DownloadFile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string DocName = Request.QueryString["DocName"];
        string DelIt = Request.QueryString["Del"];

        if (DocName != null && DocName.Length > 0 && File.Exists(DocName))
        {
            string CntType = Path.GetExtension(DocName);
            byte[] FileContents = null;
            int RetryCnt = 0;
            bool Failed = true;

            while (Failed == true && RetryCnt < 10)
            {
                try
                {
                    Failed = false;
                    RetryCnt++;
                    FileStream fs = new FileStream(DocName, FileMode.Open, FileAccess.Read);
                    BinaryReader br = new BinaryReader(fs);

                    FileContents = br.ReadBytes((int)fs.Length);

                    br.Close();
                    fs.Close();

                    if (DelIt != null && DelIt == "Y")
                        Utils.DeleteFile(DocName, "");
                }                
                catch (Exception ex)
                {
                    Failed = true;
                    Response.Write(ex.Message);
                    Thread.Sleep(200);
                }
            }

            if (FileContents != null)
            {
                Response.Clear();
                Response.ContentType = CntType;
                Response.AddHeader("Content-Disposition", "attachment;filename=" + Path.GetFileName(DocName));
                Response.AddHeader("Content-Length", FileContents.Length.ToString());
                Response.Charset = "UTF-8";
                Response.BinaryWrite(FileContents);
                Response.Flush();
                Response.End();
                return;
            }
        }

        Response.Write("No Document specified!");
    }
}
