﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using MDUA.DataAccess;
using MDUA.BusinessLogic;

public partial class SysLock : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Master.PageTitle = "System Lock";
        if (Master.SignedIn(UserRole.Admin) == false)
            return;

        Master.NavInstructionsVisible = true;

        if (IsPostBack == false)
            UpdateDisplay();
    }
    protected void btnLock_Click(object sender, EventArgs e)
    {
        string LockedBy = " ";
        if (btnLock.Text.Equals("Lock Dimensions"))
            LockedBy = Master.curUser.EmployeeID;
        if (DbAccess.LockApplication(LockedBy, Master.curUser.EmployeeID) == true)
        {
            Master.Message = "Locked setting was successfully changed";
            UpdateDisplay();
        }
        else
            Master.Message = "An error occurred trying to change the lock setting";
    }

    private void UpdateDisplay()
    {
        HypWebSettings ws = DbAccess.LoadWebSetting(Master.curUser.EmployeeID);
        if (ws != null && ws.LockedBy.Trim().Length > 0)
        {
            UserInfo ui = DbAccess.getUserData(ws.LockedBy);
            lblDesc.Text = string.Format("The system is currently locked by {0}",
                (ui == null) ? ("User " + ws.LockedBy) : ui.FullName);
            btnLock.Text = "Unlock Dimensions";
        }
        else
        {
            lblDesc.Text = "The system is currently available for updating";
            btnLock.Text = "Lock Dimensions";
        }
    }
}
