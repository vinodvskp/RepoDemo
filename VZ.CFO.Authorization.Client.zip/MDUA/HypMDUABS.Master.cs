﻿using MDUA.BusinessLogic;
using MDUA.DataAccess;
using MDUA.DTO;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace MDUA
{
    public partial class HypMDUABS : System.Web.UI.MasterPage
    {
        public const string ERROR_MESSAGE = "An unidentified error has occurred.  Please contact the Financial Application Support Team immediately for resolution.";

        public static FbitConfigData fbitConfigData = null;

        public String PageTitle
        {
            set
            {
                lblPageTitle.Text = value;
                Page.Title = "VzW Hyperion MDUA - " + value;
            }
            get { return lblPageTitle.Text; }
        }

        public string Message
        {
            set {
                lblMsg.Text = value;
                if (lblMsg.Text.Trim().Equals(string.Empty))
                {
                    HideMessageContainer();
                }
                else
                {
                    ShowMessageContainer();
                }
            }
            get { return lblMsg.Text; }
        }

        private void ShowMessageContainer() 
        {
            masterMessageContainer.Visible = true;
        }

        private void HideMessageContainer()
        {
            masterMessageContainer.Visible = false;
        }

        public string PendingMessage
        {
            set { Session["Message"] = value; }
            get { return (string)Session["Message"]; }
        }

        private string AssemblyVersion
        {
            get
            {
                Assembly myAssembly = Assembly.GetExecutingAssembly();
                AssemblyName myAssemblyName = myAssembly.GetName();
                return myAssemblyName.Version.ToString();
            }
            set { }
        }

        // jevans 11/20/2010 - create local user to avoid calling the util GetCurUser  
        private UserInfo _user;

        public UserInfo curUser
        {
            get
            {
                /*  UserInfo ui = new UserInfo();
                  ui.FirstName = "Test";
                  ui.LastName = Request.Headers["employeeID"];
                  if (ui.LastName == null || ui.LastName.Length == 0)
                      ui.LastName = "User";
                  ui.Role = UserRole.Admin;
             
                 ui.Active = true;
                  return ui;
                 */
                // jevans 11/20/2010 - to avoid GetCurUser more than once per page load, use session variable

                if (_user == null)
                    _user = Utils.GetCurUser(Session, Request);

                return _user; // Utils.GetCurUser(Session, Request); 
            }
        }

        public HtmlForm MasterForm
        {
            get { return this.form1; }
        }

        public HtmlGenericControl MasterBody
        {
            get { return bodytag; }
        }

        public bool SignedIn(UserRole ur)
        {
            UserInfo ui = curUser;
            if (ui == null ||
                ui.Active == false)
            {
                Server.Transfer("~/Unauthorized.aspx");
                return false;
            }

            if ((int)ui.Role < (int)ur)
            {
                PendingMessage = string.Format("You don't have sufficent Access to access the {0} page.", PageTitle);
                Server.Transfer("~/Default.aspx");
                return false;
            }

            return true;
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (PendingMessage != null)
                {
                    Message = (string)PendingMessage;
                    Session.Remove("Message");
                }

                UserInfo u = curUser;
                if (u == null)
                    return;

                if (fbitConfigData == null)
                {
                    fbitConfigData = new FbitConfigData();
                    fbitConfigData.LDAPServer = ConfigurationManager.AppSettings["ldap_server"];
                    fbitConfigData.LoginEID = ConfigurationManager.AppSettings["login_eid"];
                    fbitConfigData.MTServer = ConfigurationManager.AppSettings["mt_server"];
                    fbitConfigData.OAuthHost = ConfigurationManager.AppSettings["oauth_host"];
                    fbitConfigData.SiteSubfolder = ConfigurationManager.AppSettings["site_subfolder"];
                    fbitConfigData.SkipSSO = ConfigurationManager.AppSettings["skip_sso"];
                    fbitConfigData.VMServer = ConfigurationManager.AppSettings["vm_server"];
                    fbitConfigData.NotificationType = ConfigurationManager.AppSettings["notification_type"];
                    fbitConfigData.DatascoopServer = ConfigurationManager.AppSettings["datascoop_server"];
                }

                ldap_server.Value = fbitConfigData.LDAPServer;
                login_eid.Value = fbitConfigData.LoginEID;
                mt_server.Value = fbitConfigData.MTServer;
                vm_server.Value = fbitConfigData.VMServer;
                oauth_host.Value = fbitConfigData.OAuthHost;
                site_subfolder.Value = fbitConfigData.SiteSubfolder;
                datascoop_server.Value = fbitConfigData.DatascoopServer;


                //lblUser.Text = u.FullName;

                //  Environment Setting
                string connectString = DbAccess.GetOracleConnectionString();
                string databaseInstanceDescription = ConfigurationManager.AppSettings["DatabaseInstanceDescription"];
                //lblEnvironment.Text = databaseInstanceDescription != null ? string.Format("{0}-{1}", databaseInstanceDescription, Regex.Match(connectString, @"SERVICE_NAME {0,}= {0,}([^)]*)").Groups[1].Value) : Regex.Match(connectString, @"SERVICE_NAME {0,}= {0,}([^)]*)").Groups[1].Value;
                //lblVersion.Text = string.Format("{0}", AssemblyVersion);

                //  Navigation Bar Access
                /*NavBarGroup grp = nbMDUA.Groups.FindByName("ngMonthEndAutomation");
                // jevans 11/8/2010 - hide group  
                grp.Visible = false;// (lblEnvironment.Text == "APPDEV");
                grp.Items.FindByName("nvLockChanges").Visible = (u.Role == UserRole.Admin);
                grp.Items.FindByName("nvCreateExtract").Visible = (u.Role == UserRole.Admin);

                // jevans 11/8/2010 - hide group  
                grp = nbMDUA.Groups.FindByName("ngMonthEndCalendar");
                grp.Visible = false;
                grp.Items.FindByName("nvEditCalInv").Visible = (u.Role == UserRole.Admin);
                grp.Items.FindByName("nvCreateCal").Visible = (u.Role == UserRole.Admin);

                grp = nbMDUA.Groups.FindByName("ngUserInputUploads");
                //grp.Items.FindByName("nvUserInputNewKey").Visible = u.CanAddUserInputKeys;
                grp.Items.FindByName("nvMoveKeyCombos").Visible = u.CanAddUserInputKeys;
                grp.Items.FindByName("nvUserInputNewType").Visible = u.CanAddNewFileType;

                grp = nbMDUA.Groups.FindByName("ngSelfServe");
                //grp.Visible = (u.Role == UserRole.Admin || u.CanPostAdjImmediately || u.CanProcessCpga);
                grp.Items.FindByName("nvCPGAInfo").Visible = (u.Role == UserRole.Admin || u.CanProcessCpga);

                grp = nbMDUA.Groups.FindByName("ngAdmin");
                grp.Visible = (u.Role == UserRole.Admin || u.CanAssignUserFileType || u.CanAssignAutosysOD);
                //grp.Items.FindByName("nvViewLog").Visible = (u.Role == UserRole.Admin);
                grp.Items.FindByName("nvLoadData").Visible = false; // (u.Role == UserRole.Admin);
                // jevans 12/5/2010 - not currently enabled 
                grp.Items.FindByName("nvChartfield").Visible = false; // (u.Role == UserRole.Admin);
                grp.Items.FindByName("navAutosysSetup").Visible = (u.Role == UserRole.Admin);
                grp.Items.FindByName("navSysSettings").Visible = (u.Role == UserRole.Admin);*/
            }
            catch (Exception ex)
            {
                Utils.LogEvent("", "HypMDAU.Master", "PAGE_LOAD", ex, UserToolLogLevel.Error);
                Message = ERROR_MESSAGE;
            }
        }
    }
}