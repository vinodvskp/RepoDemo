﻿using System;
using System.Collections;
using System.Configuration;
using System.IO;
using System.Web.UI.WebControls;
using MDUA.BusinessLogic;
using MDUA.DataAccess;
using MDUA.DTO;
using System.Text;
using System.Collections.Generic;
using System.Reflection;

public partial class UserInputnewKey : System.Web.UI.Page {
    public delegate string DetermineMsgText(FileType hft, FactValidDTO f);

    #region events
    protected void Page_Load(object sender, EventArgs e) {
        try {
            Master.PageTitle = "User Input Keys";
            Master.Message = string.Empty;
            //Master.NavInstructionsVisible = true;
          
            btnAdd.Visible = Master.curUser.CanAddUserInputKeys;
            fuNewKey.Enabled = Master.curUser.CanAddUserInputKeys;
            if (!IsPostBack) {
                List<FileType> fileTypes = Utils.GetFileTypes(Master.curUser.EmployeeID);

                if (fileTypes == null) {
                    Master.Message = HypMDUA.ERROR_MESSAGE;
                    return;
                }

                //  If this user doesn't have any file types that they can upload,
                //  Go back to the default page.
                if (fileTypes.Count == 0) {
                    Master.PendingMessage = "You don't have access to Add New Keys";
                    Response.Redirect("Default.aspx");
                }

                foreach (FileType fileType in fileTypes) {
                    if (fileType.UsesValidKeyCombos) {
                        ddlFileType.Items.Add(new ListItem(string.Format("{0} ({1})", fileType.Description, fileType.FileTypeCode), fileType.FileTypeCode));
                    }
                }

                ddlFileType.Items.Insert(0, new ListItem("Select File Type...", string.Empty));
            } else  {
                litJavaScript.Text = "";
            }

        } catch (System.Threading.ThreadAbortException) {
            // thread was aborted ... do nothing
        } catch (Exception ex) {
            //  Log the error to a table.
            Utils.LogEvent(Master.curUser.EmployeeID, "UserInputNewKey.aspx", "Page_load", ex, UserToolLogLevel.Error);
            Master.Message = HypMDUA.ERROR_MESSAGE;
        }
    }

    protected void btnAdd_Click(object sender, EventArgs e) {
        pnlDeleteAll.Visible = false;
        gvResults.Visible = false;

        //  Make sure that they picked a file type and selected a file.
        if (ddlFileType.SelectedValue == "") {
            Master.Message = "You must select a File Type first";
            return;
        }

        if (!fuNewKey.HasFile) {
            Master.Message = "You must select a File to upload.";
            return;
        }

        //  Upload the file and load the data based on the extension of the file.
        string filename = string.Format("Archive/{1}_{2}_{0}{3}", DateTime.Now.ToString("yyyyMMdd_HHmmss")
            , Master.curUser.UserId, ddlFileType.SelectedValue, Path.GetExtension(fuNewKey.FileName));
        filename = Server.MapPath(filename);
        fuNewKey.SaveAs(filename);

        DateTime dtNow = DateTime.Now;
        try {
            // jevans - 24735 - automap now requires current period
            WebSettings settings = Utils.LoadWebSetting(Master.curUser.EmployeeID);
            // jevans 5/23/2012 - if web settings is null, database is not available.
            if (settings == null) {
                Master.Message = "MDUA could not load web settings from the database, and cannot continue.  <P>" + HypMDUA.ERROR_MESSAGE;
                return;
            }
            string fiscal_period = string.Format(settings.CurrentMonthInt.ToString().Length == 1 ? "{0}0{1}" : "{0}{1}", settings.CurrentYear, settings.CurrentMonthInt.ToString());
            
            string message = "";
            int recordsAdded = 0;
            FileType fileType = Utils.GetFileType(ddlFileType.SelectedValue, Master.curUser.EmployeeID);

            if (fileType.FactTable == FactTable.ProductOfferUser 
                || fileType.FactTable == FactTable.EquipmentUser
                || fileType.FactTable == FactTable.PlanningActuals
                || fileType.FactTable == FactTable.DevicePaymentLoan) {
                ProcessExcelFile(filename, fileType, fiscal_period);
            } else {

                // jevans 11/22/2010 - add 2007 extension 
                string path = Path.GetExtension(filename).ToLower();
                if (path.Equals(".xls") || path.Equals(".xlsx"))
                    // jevans 11/24/2010 - changed curUser.EmployeeID to curUser.Userid to match all other calls to load data  
                    // jevans - 24735 - pass a 'checkdate' of false for equipment key-combos
                    recordsAdded = Utils.LoadExcelToStage(filename, fileType, dtNow, Master.curUser.UserId, false, out message);
                Utils.DeleteFile(filename, Master.curUser.EmployeeID);

                //  If null was returned from the Load data routine, there was an error and the routine
                //  would have written out the error message.
                switch (recordsAdded) {
                    case -1: Master.Message = message; return;
                    case -2: Master.Message = HypMDUA.ERROR_MESSAGE; return;
                }

                //  Process the Forced Value fields for this file type.
                message = Utils.ProcessForcedValues(fileType);
                if (message.Length > 0) {
                    Master.Message = "The following Error occurred when trying to load the file: " + message;
                    return;
                }

                int skippedRows = 0;
                ArrayList aKeys;
                gvResults.Columns[0].Visible = false;


                //  Process the Automapped fields for this file type.

                aKeys = Utils.ProcessAutomappedData(fileType, 0, fiscal_period, out message, out skippedRows);
                if (aKeys == null) {
                    Master.Message = HypMDUA.ERROR_MESSAGE;
                    return;
                }
                if (aKeys.Count > 0) {
                    gvResults.Visible = true;
                    gvResults.Columns[0].Visible = true;
                    if (FillGrid(fileType, aKeys, DisplayInvalidKeyCombo, "Failed to automap the following lines.", true, skippedRows) > 0) {
                        Master.Message = "Failed to automap the following lines.";
                        return;
                    }
                }

                //  Call the routine that maps the company field.
                if (Utils.CallCompanyLookup(fileType, Master.curUser.EmployeeID) == -1) {
                    Master.Message = "The Company Field could not be mapped successfully.  Check the file's Entity values";
                    return;
                }

                //  Validate the records in the temporary table to make sure the combinations 
                //  exist in the cross reference table.  Write out any items to the error table
                //  and make it visible if there were errors.
                // jevans 5/10/2011 -- restrict rows displayed 
                aKeys = Utils.ValidateKeyCombinations(fileType, dtNow, out skippedRows);
                if (aKeys == null) {
                    Master.Message = HypMDUA.ERROR_MESSAGE;
                    return;
                }
                gvResults.Columns[0].Visible = false;
                if (aKeys.Count > 0) {
                    gvResults.Visible = true;
                    gvResults.Columns[0].Visible = true;
                    if (FillGrid(fileType, aKeys, DisplayInvalidKeyCombo, null, true, skippedRows) > 0)
                        Master.Message = "The following key combinations are invalid.  Check individual lines for more information.";
                    return;
                }

                // jevans 5/17/2012 - there are two validate scenario methods... combining them for both keys and uploads
                //aKeys = Utils.ValidateScenario(hft, Scenario, dtNow);
                aKeys = Utils.ValidateAdjustmentScenarios(fileType, 0, out skippedRows);
                if (aKeys == null) {
                    Master.Message = HypMDUA.ERROR_MESSAGE;
                    return;
                }
                if (aKeys.Count > 0) {
                    gvResults.Visible = true;
                    gvResults.Columns[0].Visible = true;
                    string ValidAdjScenarios = ConfigurationManager.AppSettings["ValidAdjScenarios"];
                    if (FillGrid(fileType, aKeys, null, string.Format("The Scenario must {0}contain {1}",
                        (fileType.IsAdjustment ? "" : "not "), ValidAdjScenarios), true, skippedRows) > 0)
                        Master.Message = string.Format("The file has Scenarios that {0}contain {1}.",
                            (fileType.IsAdjustment ? "do not " : ""), ValidAdjScenarios);
                    return;
                }
                aKeys = Utils.ValidateDuplicateRows(fileType, 0, false, out skippedRows);
                if (aKeys == null) {
                    Master.Message = HypMDUA.ERROR_MESSAGE;
                    return;
                }
                if (aKeys.Count > 0) {
                    gvResults.Visible = true;
                    gvResults.Columns[0].Visible = true;
                    Master.Message = "There are duplicate rows in the uploaded file. ";
                    FillGrid(fileType, aKeys, null, "This key combination is duplicated", true, skippedRows);
                } else
                    DisplayRecsToBeAdded(fileType, dtNow);
            }
        }
        catch (Exception ex)
        {
            //  Log the error to a table.
            Utils.LogEvent("", "UserInputNewKey", "btnAdd_Click", ex, UserToolLogLevel.Error);
            Master.Message = HypMDUA.ERROR_MESSAGE;
        }
        // jevans 7/20/2011 - save date and delete destination! 
        Session.Add("DateAdded", dtNow.ToString("yyyy/MM/dd HH:mm:ss"));
        //Utils.DelUserInputFile(dtNow, Master.curUser.EmployeeID);
    }

    /// <summary>
    /// New Routine for ProdOffer
    /// </summary>
    /// <param name="filename"></param>
    protected void ProcessExcelFile(string filename, FileType fileType, string fiscalPeriod) {
        string errorMessage = string.Empty;
        int runStatusId;
        int totalRecordsAdded = 0;
        ArrayList results;
        int rows;
        int rowsSkipped;
        string message;
        StageProcessingStatus status;
                    
        try {
            switch (Path.GetExtension(filename).ToLower()) {
                case ".xls":
                case ".xlsx":
                    switch (fileType.FactTable) {
                        case FactTable.ProductOfferUser:
                            totalRecordsAdded = ProductOfferDatabaseAccess.LoadProductOfferExcelToStage(filename, fileType, Master.curUser.UserId, false, out message, out runStatusId);
                            break;
                        case FactTable.EquipmentUser:
                            totalRecordsAdded = EquipmentDatabaseAccess.LoadExcelToStage(filename, fileType, Master.curUser.UserId, false, out message, out runStatusId);                        
                            break;
                        case FactTable.PlanningActuals:
                            totalRecordsAdded = PlanningActualsDatabaseAccess.LoadExcelToStage(filename, fileType, Master.curUser.UserId, false, out message, out runStatusId);                        
                            break;
                        case FactTable.DevicePaymentLoan:
                            totalRecordsAdded = DevicePaymentLoanDatabaseAccess.LoadDPLoanExcelToStage(filename, fileType, Master.curUser.UserId, false, out message, out runStatusId);                                
                            break;
                        default:
                            message = string.Empty;
                            runStatusId = -1;
                            break;
                    }
                    
                    switch (totalRecordsAdded) {
                        case -2: Master.Message = HypMDUA.ERROR_MESSAGE; break; // Exception occurred
                        case -1: Master.Message = message; break; // Error occured during routine
                        case 0: Master.Message = "There were no rows found in the uploaded spreadsheet"; break;
                        default:
                            Session.Add("runStatusId", runStatusId);

                            switch (fileType.FactTable) {
                                case FactTable.ProductOfferUser:
                                    results = ProductOfferDatabaseAccess.ProcessStagedKeyData(runStatusId, fiscalPeriod, fileType, Master.curUser.EmployeeID, out status, out message, out rows, out rowsSkipped);
                                    break;
                                case FactTable.EquipmentUser:
                                    results = EquipmentDatabaseAccess.ProcessStagedKeyData(runStatusId, fiscalPeriod, fileType, Master.curUser.EmployeeID, out status, out message, out rows, out rowsSkipped);
                                    break;
                                case FactTable.PlanningActuals:
                                    results = PlanningActualsDatabaseAccess.ProcessStagedKeyData(runStatusId, fiscalPeriod, fileType, Master.curUser.EmployeeID, out status, out message, out rows, out rowsSkipped);
                                    break;
                                case FactTable.DevicePaymentLoan:
                                    results = DevicePaymentLoanDatabaseAccess.ProcessStagedKeyData(runStatusId, fiscalPeriod, fileType, Master.curUser.EmployeeID, out status, out message, out rows, out rowsSkipped);
                                    break;
                                default:
                                    status = StageProcessingStatus.None;
                                    results = null;
                                    rows = 0;
                                    rowsSkipped = 0;
                                    break;
                            }
                            
                            switch (status) {
                                case StageProcessingStatus.CriticalValidationsFailed:
                                case StageProcessingStatus.AdditionOfKeysRequired:
                                    Master.Message = "Issues detected with input file, please refer to the messages in the grid for additional details";
                                    FillGrid(fileType, results, null, "", true, rowsSkipped);
                                    btnContinue.Visible = false;
                                    btnCancel.Visible = false;
                                    btnAdd.Visible = true;
                                    ddlFileType.Enabled = true;
                                    pnlDeleteAll.Visible = false;                    
                                    btnDownload.Visible = true;
                                    break;
                                default:
                                    if (rows == 0) {
                                        Master.Message = "All key combinations from file already exist in the validation table";
                                        btnContinue.Visible = false;
                                        btnCancel.Visible = false;
                                        btnAdd.Visible = true;
                                        gvResults.Visible = false;
                                        litSkippedRows.Visible = false;
                                    } else {
                                        Master.Message = string.Format("The following {0} key combination(s) will be added to the validation table.  Click Continue to proceed. ", rows);
                                        FillGrid(fileType, results, null, "", false, rowsSkipped);
                                        btnContinue.Visible = true;
                                        btnCancel.Visible = true;
                                        btnAdd.Visible = false;
                                        ddlFileType.Enabled = false;
                                        pnlDeleteAll.Visible = false;                    
                                        btnDownload.Visible = true;
                                    }
                                    break;
                            }
                            break;
                    }
                    break;
                default:
                    Master.Message = "Invalid file format.  The upload file must end in .XLS or .XLSX";
                    break;
            }
        } catch (Exception ex) {
            Utils.LogEvent("", "UserInputNewKey", MethodBase.GetCurrentMethod().Name, ex, UserToolLogLevel.Error);
            Master.Message = HypMDUA.ERROR_MESSAGE;
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e) {
        try {
            Response.Redirect("UserInputNewKey.aspx");
        } catch (System.Threading.ThreadAbortException) {
            // thread was aborted ... do nothing
        }
    }

    protected void btnContinue_Click(object sender, EventArgs e) {
        btnContinue.Visible = false;
        int runStatusId;
        int totalKeysAdded = 0;
        bool addWasSuccessful = false;

        FileType fileType = Utils.GetFileType(ddlFileType.SelectedValue, Master.curUser.EmployeeID);
        if (fileType.FactTable == FactTable.ProductOfferUser 
            || fileType.FactTable == FactTable.EquipmentUser
            || fileType.FactTable == FactTable.PlanningActuals
            || fileType.FactTable == FactTable.DevicePaymentLoan) {
            int.TryParse(Session["runStatusId"].ToString(), out runStatusId);

            switch (fileType.FactTable) {
                case FactTable.ProductOfferUser:
                    ProductOfferDatabaseAccess.AddKeysFromStagedData(fileType, runStatusId, out addWasSuccessful, out totalKeysAdded);
                    break;
                case FactTable.EquipmentUser:
                    EquipmentDatabaseAccess.AddKeysFromStagedData(fileType, runStatusId, out addWasSuccessful, out totalKeysAdded);
                    break;
                case FactTable.PlanningActuals:
                    PlanningActualsDatabaseAccess.AddKeysFromStagedData(fileType, runStatusId, out addWasSuccessful, out totalKeysAdded);
                    break;
                case FactTable.DevicePaymentLoan:
                    DevicePaymentLoanDatabaseAccess.AddKeysFromStagedData(fileType, runStatusId, out addWasSuccessful, out totalKeysAdded);                    
                    break;
            }

            if (addWasSuccessful) {
                Master.PendingMessage = String.Format("Successfully added {0} key combinations", totalKeysAdded);
                Utils.LogEvent(Master.curUser.EmployeeID, "UserInputNewKey", "Add User Input Key Combinations"
                    , string.Format("Added {0} Key combinations to the {1} File Type", totalKeysAdded, ddlFileType.SelectedValue), UserToolLogLevel.Audit);
            } else {
                Master.PendingMessage = HypMDUA.ERROR_MESSAGE;
            }
        } else {
            string dAdded = Session["DateAdded"].ToString();
            if (Utils.AddUserInputKeys(fileType, Master.curUser.UserId, dAdded, Master.curUser.EmployeeID, out totalKeysAdded)) {
                Master.PendingMessage = String.Format("Successfully added {0} Keys.", totalKeysAdded);
                Utils.LogEvent(Master.curUser.EmployeeID, "UserInputNewKey", "Add User Input Key Combinations"
                    , string.Format("Added {0} Key combinations to the {1} File Type", totalKeysAdded, ddlFileType.SelectedValue), UserToolLogLevel.Audit);
            } else {
                Master.PendingMessage = HypMDUA.ERROR_MESSAGE;
            }
        }
        try {
            Response.Redirect("UserInputNewKey.aspx");
        } catch (System.Threading.ThreadAbortException) {
            // thread was aborted ... do nothing
        }
    }

    protected void btnDisplay_Click(object sender, EventArgs e) {
        if (ddlFileType.SelectedValue == "") {
            gvResults.Visible = false;
            Master.Message = "You must select a File Type to display";
            return;
        }

        Master.Message = "";
        int SkippedRows = 0;
        FileType fileType = Utils.GetFileType(ddlFileType.SelectedValue, Master.curUser.EmployeeID);
        ArrayList a = Utils.GetCurrentKeys(fileType, out SkippedRows);

        FillGrid(fileType, a, null, "", false, SkippedRows);
    }

    protected void btnDeleteAll_Click(object sender, EventArgs e) {
        try {
            int recordsDeleted = 0;
            FileType fileType = Utils.GetFileType(ddlFileType.SelectedValue, Master.curUser.EmployeeID);

            if (fileType.FactTable == FactTable.ProductOfferUser) {
                recordsDeleted = ProductOfferDatabaseAccess.DeleteKeys(fileType, null, true);
            } else if (fileType.FactTable == FactTable.EquipmentUser) {
                recordsDeleted = EquipmentDatabaseAccess.DeleteKeys(fileType, null, true);
            } else if (fileType.FactTable == FactTable.PlanningActuals) {
                recordsDeleted = PlanningActualsDatabaseAccess.DeleteKeys(fileType, null, true);
            } else if (fileType.FactTable == FactTable.DevicePaymentLoan)
            {
                recordsDeleted = DevicePaymentLoanDatabaseAccess.DeleteKeys(fileType, null, true);
            } 
            else {
                if (!Utils.DelUserInputKey(ddlFileType.SelectedValue, Master.curUser.EmployeeID, out recordsDeleted)) {
                    Master.Message = HypMDUA.ERROR_MESSAGE;
                    return;
                }
            }
            Master.Message = string.Format("All {0} items were deleted", recordsDeleted.ToString());
            pnlDeleteAll.Visible = false;
            gvResults.Visible = false;
        }
        catch (Exception ex)
        {
            Utils.LogEvent(Master.curUser.EmployeeID, "UserInputNewKey.aspx", "btnDeleteAll_Click", ex, UserToolLogLevel.Error);
            Master.Message = HypMDUA.ERROR_MESSAGE;
        }
    }

    protected void btnDelete_Click(object sender, EventArgs e) {
        int rowsDeleted = 0;
        try {
            if (gvResults.GetSelectedIndices() == null || gvResults.GetSelectedIndices().Length == 0) {
                Master.Message = "No record(s) were selected to delete.";
                return;
            }

            FileType fileType = Utils.GetFileType(ddlFileType.SelectedValue, Master.curUser.EmployeeID);

            if (fileType.FactTable == FactTable.ProductOfferUser 
                || fileType.FactTable == FactTable.EquipmentUser
                || fileType.FactTable == FactTable.PlanningActuals
                || fileType.FactTable == FactTable.DevicePaymentLoan) {
                List<string> rowids = new List<string>();
                foreach (int index in gvResults.GetSelectedIndices()) {
                    rowids.Add((string)gvResults.DataKeys[index].Value);
                }
                switch (fileType.FactTable) {
                    case FactTable.ProductOfferUser:
                        rowsDeleted = ProductOfferDatabaseAccess.DeleteKeys(fileType, rowids, false);
                        break;
                    case FactTable.EquipmentUser:
                        rowsDeleted = EquipmentDatabaseAccess.DeleteKeys(fileType, rowids, false);
                        break;
                    case FactTable.PlanningActuals:
                        rowsDeleted = PlanningActualsDatabaseAccess.DeleteKeys(fileType, rowids, false);
                        break;
                    case FactTable.DevicePaymentLoan:
                        rowsDeleted = DevicePaymentLoanDatabaseAccess.DeleteKeys(fileType, rowids, false);
                        break;
                }

            } else {
                // move selected keys into an array list for delete method
                ArrayList keysToDelete = new ArrayList();
                foreach (int index in gvResults.GetSelectedIndices()) {
                    keysToDelete.Add((string)gvResults.DataKeys[index].Value);
                }

                if (!Utils.DelUserInputKey(ddlFileType.SelectedValue, keysToDelete, Master.curUser.EmployeeID, out rowsDeleted)) {
                    Master.Message = HypMDUA.ERROR_MESSAGE;
                    return;
                }

            }

            Master.Message = string.Format("{0} item(s) were deleted", rowsDeleted);
            Utils.LogEvent(Master.curUser.EmployeeID, "UserInputNewKey.aspx", "Delete Keys"
                , string.Format("Deleted {0} keys from type {1}", rowsDeleted, ddlFileType.SelectedValue)
                , UserToolLogLevel.Audit);

            int SkippedRows = 0;
            ArrayList a = Utils.GetCurrentKeys(fileType, out SkippedRows);
            FillGrid(fileType, a, null, string.Empty, false, SkippedRows);
        } catch (Exception ex) {
            Utils.LogEvent(Master.curUser.EmployeeID, "UserInputNewKey.aspx", "btnDelete_Click", ex, UserToolLogLevel.Error);
            Master.Message = HypMDUA.ERROR_MESSAGE;
        }
    }

    protected void btnDownload_Click(object sender, EventArgs e) {
        if (ddlFileType.SelectedValue == "") {
            gvResults.Visible = false;
            Master.Message = "You must select a File Type to download";
            return;
        }

        string Filename = string.Format("Downloads/{1}_{2}_{0}.csv",
            DateTime.Now.ToString("yyyyMMdd_HHmmss"),
            Master.curUser.UserId, ddlFileType.SelectedValue);
        Filename = Server.MapPath(Filename);

        FileType fileType = Utils.GetFileType(ddlFileType.SelectedValue, Master.curUser.EmployeeID);
        switch (Utils.WriteValidationDataToCSV(fileType, Master.curUser.EmployeeID, Filename)) {
            case 0:
                Master.Message = "There was no data found for the selected type. ";
                break;
            case -1:
                Master.Message = HypMDUA.ERROR_MESSAGE;
                break;
            default:
                try
                {
                    Response.Redirect(string.Format("DownloadFile.aspx?DocName={0}&Del=Y", Filename));
                }
                catch (System.Threading.ThreadAbortException)
                { /* thread was aborted ... do nothing */}
                break;
        }
    }

    protected void gvResults_Sorting(object sender, GridViewSortEventArgs e)
    {

        //Retrieve the table from the session object.
        ArrayList a = Session["ArrayList"] as ArrayList;

        if (a != null)
        {

            IComparer f = (IComparer)new FactComparer(e.SortExpression, SortOrderAlternate(e.SortExpression));
            a.Sort(f);
            //            gvResults.PageSize = int.Parse(lbPageSize.SelectedValue);
            // go to first page
            gvResults.DataSource = a;
            gvResults.DataBind();
            gvResults.PageIndex = 0;

        }
    }

    public bool SortOrderAlternate(String currentSortExpression)
    {
        String previousSortExpression = (String)Session["SortExpression"];
        bool bReturn = false;
        if (previousSortExpression == null)
        {
            //first sort, set to default ASC
            currentSortExpression += " ASC";
        }
        else
        {

            if (previousSortExpression.StartsWith(currentSortExpression))
            {
                //same column re-sort, set to opposite order
                if (previousSortExpression.EndsWith("ASC"))
                {
                    currentSortExpression += " desc";
                    bReturn = true;
                }
                else
                    currentSortExpression += " ASC";
            }
            else
            {
                //new column sort, set to default ASC
                currentSortExpression += " ASC";
            }
        }

        Session.Remove("SortExpression");
        Session.Add("SortExpression", currentSortExpression);

        return bReturn;
    }
    #endregion

    #region formatting
    private string DisplayInvalidKeyCombo(FileType hft, FactValidDTO f) {
        string errorText = string.Empty;
        string fieldsFailedAutomap = string.Empty;
        bool isLocation = hft.FactTableId == (int)FactTable.LocationUser;
        bool isEquipment = hft.FactTableId == (int)FactTable.EquipmentUser;
        bool isDataWarehouse = hft.FactTableId == (int)FactTable.DataWarehouseUser;
        try {
            //  first check for fields that didn't auto map correctly.
            if (isLocation) {
                if (f.ReportingLine == string.Empty) fieldsFailedAutomap += "Reporting line, ";
                if (f.Account == string.Empty) fieldsFailedAutomap += "Account, ";
                if (f.KPI == string.Empty) fieldsFailedAutomap += "KPI, ";
                if (f.View == string.Empty) fieldsFailedAutomap += "View, ";
                if (f.Scenario == string.Empty) fieldsFailedAutomap += "Scenario, ";
                if (f.Product == string.Empty) fieldsFailedAutomap += "Product, ";
                if (f.SubAccount == string.Empty) fieldsFailedAutomap += "Sub Account, ";
                if (f.ServiceType == string.Empty) fieldsFailedAutomap += "Service Type, ";
                if (f.Function == string.Empty) fieldsFailedAutomap += "Function, ";
                if (f.CostCenter == string.Empty) fieldsFailedAutomap += "Cost Center, ";
                if (f.Entity == string.Empty) fieldsFailedAutomap += "Entity, ";
                if (f.Equipment == string.Empty) fieldsFailedAutomap += "Equipment, ";
                if (f.TechType == string.Empty) fieldsFailedAutomap += "Tech Type, ";
                if (f.StoreStatus == string.Empty) fieldsFailedAutomap += "Store Status, ";
                if (f.DesignType == string.Empty) fieldsFailedAutomap += "Design Type, ";
                if (f.LocationType == string.Empty) fieldsFailedAutomap += "Location Type, ";
                if (f.LocationSubtype == string.Empty) fieldsFailedAutomap += "Location Subype, ";
                if (f.LocationTierCode == string.Empty) fieldsFailedAutomap += "Loc Tier Code, ";
            } else if (isDataWarehouse) {
                if (f.ReportingLine == string.Empty) fieldsFailedAutomap += "Reporting line, ";
                if (f.Account == string.Empty) fieldsFailedAutomap += "Cust Account, ";
                if (f.KPI == string.Empty) fieldsFailedAutomap += "KPI, ";
                if (f.View == string.Empty) fieldsFailedAutomap += "View, ";
                if (f.Scenario == string.Empty) fieldsFailedAutomap += "Scenario, ";
                if (f.Product == string.Empty) fieldsFailedAutomap += "Product, ";
                if (f.SubAccount == string.Empty) fieldsFailedAutomap += "Sub Account, ";
                if (f.ServiceType == string.Empty) fieldsFailedAutomap += "Service Type, ";
                if (f.Function == string.Empty) fieldsFailedAutomap += "Function, ";
                if (f.Entity == string.Empty) fieldsFailedAutomap += "Entity, ";
                if (f.Equipment == string.Empty) fieldsFailedAutomap += "Equipment, ";
                if (f.TechType == string.Empty) fieldsFailedAutomap += "Tech Type, ";
                if (f.Branch == string.Empty) fieldsFailedAutomap += "Branch, ";
                if (f.OwningGeo == string.Empty) fieldsFailedAutomap += "Owning Geography, ";
                if (f.OwningMgr == string.Empty) fieldsFailedAutomap += "Owning Manager, ";
                if (f.Vertical == string.Empty) fieldsFailedAutomap += "Vertical, ";
            } else {
                if (f.ReportingLine == string.Empty) fieldsFailedAutomap += "Reporting line, ";
                if (f.Account == string.Empty) fieldsFailedAutomap += "Account, ";
                if (f.KPI == string.Empty) fieldsFailedAutomap += "KPI, ";
                if (f.View == string.Empty) fieldsFailedAutomap += "View, ";
                if (f.Scenario == string.Empty) fieldsFailedAutomap += "Scenario, ";
                if (f.Product == string.Empty) fieldsFailedAutomap += "Product, ";
                if (f.SubAccount == string.Empty) fieldsFailedAutomap += "Sub Account, ";
                if (f.ServiceType == string.Empty) fieldsFailedAutomap += "Service Type, ";
                if (f.Function == string.Empty) fieldsFailedAutomap += "Function, ";
                if (f.CostCenter == string.Empty) fieldsFailedAutomap += "Cost Center, ";
                if (f.Entity == string.Empty) fieldsFailedAutomap += "Entity, ";
                if (f.Company == string.Empty) fieldsFailedAutomap += "Company, ";
                if (f.Equipment == string.Empty) fieldsFailedAutomap += "Equipment, ";
                if (f.TechType == string.Empty) fieldsFailedAutomap += "Tech Type, ";
            }
                        
            if (fieldsFailedAutomap.Length > 0) {
                fieldsFailedAutomap = fieldsFailedAutomap.Substring(0, fieldsFailedAutomap.Length - 2);
                if (fieldsFailedAutomap.Length > 0) {
                    errorText += string.Format(" The following fields did not automap correctly: {0}. ", fieldsFailedAutomap);
                }
            }
            if (!string.IsNullOrEmpty(f.SourceValid) && !f.SourceValid.Equals(f.Source)) {
                errorText += string.Format("This record already exists in the fact table under the '{0}' File Type", f.SourceValid);
            }
            if (errorText.Length > 0) {
                return errorText;
            }
                        
            // NOW check for invalid dim values
            if (isLocation) {
                if (f.ReportLineValid == string.Empty) errorText += "Reporting Line, ";
                if (f.AccountValid == string.Empty) errorText += "Account, ";
                if (f.KPIValid == string.Empty) errorText += "KPI, ";
                if (f.ViewValid == string.Empty) errorText += "View, ";
                if (f.ScenarioValid == string.Empty) errorText += "Scenario, ";
                if (f.ProductValid == string.Empty) errorText += "Product, ";
                if (f.SubAcctValid == string.Empty) errorText += "Subaccount, ";
                if (f.ServiceValid == string.Empty) errorText += "Service Type, ";
                if (f.FunctionValid == string.Empty) errorText += "Function, ";
                if (f.CostCenterValid == string.Empty) errorText += "Cost Center, ";
                if (f.EntityValid == string.Empty) errorText += "Entity, ";
                if (f.EquipmentValid == string.Empty) errorText += "Equipment, ";
                if (f.TechTypeValid == string.Empty) errorText += "Tech Type, ";
                if (f.StoreStatusValid == string.Empty) errorText += "Store Status, ";
                if (f.DesignTypeValid == string.Empty) errorText += "Design Type, ";
                if (f.LocationTypeValid == string.Empty) errorText += "Location Type, ";
                if (f.LocationSubtypeValid == string.Empty) errorText += "Location Subype, ";
                if (f.LocationTierCodeValid == string.Empty) errorText += "Loc Tier Code, ";  
            } else if (isDataWarehouse) {
                if (f.ReportLineValid == string.Empty) errorText += "Reporting Line, ";
                if (f.AccountValid == string.Empty) errorText += "Cust Account, ";
                if (f.KPIValid == string.Empty) errorText += "KPI, ";
                if (f.ViewValid == string.Empty) errorText += "View, ";
                if (f.ScenarioValid == string.Empty) errorText += "Scenario, ";
                if (f.ProductValid == string.Empty) errorText += "Product, ";
                if (f.SubAcctValid == string.Empty) errorText += "Subaccount, ";
                if (f.ServiceValid == string.Empty) errorText += "Service Type, ";
                if (f.FunctionValid == string.Empty) errorText += "Function, ";
                if (f.EntityValid == string.Empty) errorText += "Entity, ";
                if (f.EquipmentValid == string.Empty) errorText += "Equipment, ";
                if (f.TechTypeValid == string.Empty) errorText += "Tech Type, ";
                if (f.BranchValid == string.Empty) errorText += "Branch, ";
                if (f.ConnTypeValid == string.Empty) errorText += "Connection Type, ";
                if (f.SegmentValid == string.Empty) errorText += "Segment, ";
                if (f.OwningGeoValid == string.Empty) errorText += "Owning Geography, ";
                if (f.OwningMgrValid == string.Empty) errorText += "Owning Manager, ";
                if (f.VersionValid == string.Empty) errorText += "Version, ";
                if (f.VerticalValid == string.Empty) errorText += "Vertical, ";
                if (f.PreviousTypeValid == string.Empty) errorText += "Previous Type, ";
                if (f.ContractTermValid == string.Empty) errorText += "Contract Term, ";
                if (f.ProgramEligible == string.Empty) errorText += "Program Eligible, ";
            } else {
                if (f.ReportLineValid == string.Empty) errorText += "Reporting Line, ";
                if (f.AccountValid == string.Empty) errorText += "Account, ";
                if (f.KPIValid == string.Empty) errorText += "KPI, ";
                if (f.ViewValid == string.Empty) errorText += "View, ";
                if (f.ScenarioValid == string.Empty) errorText += "Scenario, ";
                if (f.ProductValid == string.Empty) errorText += "Product, ";
                if (f.SubAcctValid == string.Empty) errorText += "Subaccount, ";
                if (f.ServiceValid == string.Empty) errorText += "Service Type, ";
                if (f.FunctionValid == string.Empty) errorText += "Function, ";
                if (f.CostCenterValid == string.Empty) errorText += "Cost Center, ";
                if (f.EntityValid == string.Empty) errorText += "Entity, ";
                if (f.CompanyValid == string.Empty) errorText += "Company, ";
                if (f.EquipmentValid == string.Empty) errorText += "Equipment, ";
                if (f.TechTypeValid == string.Empty) errorText += "Tech Type, ";
            }

            if (errorText.Length > 0) {
                errorText = errorText.Substring(0, errorText.Length - 2);
                errorText = "The following fields are not valid: " + errorText + ".  ";
            }

        } catch (Exception ex) {
            //  Log the error to a table.
            Utils.LogEvent(Master.curUser.EmployeeID, "UserInputNewKey.aspx", "DisplayInvalidKeyCombo", ex, UserToolLogLevel.Error);
            Master.Message = HypMDUA.ERROR_MESSAGE;
            errorText = null;
        }
        return errorText;
    }

    public int DisplayRecsToBeAdded(FileType fileType, DateTime now) {
        int rowsSkipped = 0;
        int numberToAdd = 0;

        // jevans 5/10/2011 -- restrict rows displayed 
        ArrayList a = Utils.GetKeysToBeAdded(fileType, now, out rowsSkipped);
        if (a == null) {
            Master.Message = HypMDUA.ERROR_MESSAGE;
            return 0;
        }
        
        try {
            gvResults.Columns[0].Visible = false;
            gvResults.Columns[1].Visible = false;

            if (a != null && a.Count > 0) {
                gvResults.Visible = true;
                gvResults.Columns[0].Visible = false;

                numberToAdd = FillGrid(fileType, a, null, null, false, rowsSkipped);

                // an error occured, stop processing
                if (numberToAdd < 0) return -1;

                if (numberToAdd > 0) {
                    Master.Message = rowsSkipped > 0 ? string.Format("Partial results displayed: {0} rows not displayed, {1} key combinations will be added to the validation table.  For a complete list of loaded keys, select the Download button after processing.  Do you want to continue? ", rowsSkipped, (a.Count + rowsSkipped).ToString())
                                                     : string.Format("The following {1} key combinations will be added to the validation table.  Do you want to continue? ", rowsSkipped, (a.Count + rowsSkipped).ToString());
                    btnContinue.Visible = true;
                    btnCancel.Visible = true;
                    btnAdd.Visible = false;
                    ddlFileType.Enabled = false;
                    pnlDeleteAll.Visible = false;
                }
            }

            if (numberToAdd == 0) {
                Master.Message = "There are no items that don't already exist in the validation table.";
                btnContinue.Visible = false;
                btnCancel.Visible = false;
                btnAdd.Visible = true;
                gvResults.Visible = false;
            }
        } catch (Exception ex) {
            //  Log the error to a table.
            Utils.LogEvent(Master.curUser.EmployeeID, "UserInputNewKey.aspx", "DisplayRecsToBeAdded", ex, UserToolLogLevel.Error);
            Master.Message = HypMDUA.ERROR_MESSAGE;
        }

        return numberToAdd;
    }

    private int FillGrid(FileType fileType, ArrayList results, DetermineMsgText GetMsg, string defaultMessage, bool displayMessage, int skippedRows) {
        int returnCode = -1;
        if (results == null)
            return returnCode;
        // save array in session for page/sort 
        Session["ArrayList"] = results;

        gvResults.Visible = true;
        
        pnlDeleteAll.Visible = Master.curUser.CanAddUserInputKeys;

        // cell index is zero based, so subtract one to count columns  
        int columnCount = gvResults.Columns.Count - 1;

        try {
            switch ((FactTable)fileType.FactTableId) {
                case FactTable.PlanningActuals:
                    foreach (DataControlField column in gvResults.Columns) {
                        switch (column.HeaderText) {
                            case "Account":
                            case "Cust Account":
                                column.Visible = true;
                                column.HeaderText = "Account";
                                break;
                            case "GL Account":
                            case "Product":
                            case "Contract Term":
                            case "Tech Type":
                            case "TechType":
                            case "Region":
                            case "ServiceType":
                            case "Scenario":
                            case "Function":
                            case "External Segment":
                            case "Business Segment":
                            case "Line of Business":
                            case "Planned Entity":
                            case "Run Status Id":
                                column.Visible = true;
                                break;
                            default:
                                column.Visible = false;
                                break;
                        }
                    }
                    gvResults.Columns[0].Visible = displayMessage;
                    break;
                case FactTable.ProductOfferUser:
                    foreach (DataControlField column in gvResults.Columns) {
                        switch (column.HeaderText) {
                            case "Account":
                            case "Cust Account":
                                column.Visible = true;
                                column.HeaderText = "Account";
                                break;
                            case "Entity":
                            case "Location":
                                column.HeaderText = "Entity";
                                break;
                            case "Product":
                            case "Cost Cntr":
                            case "Cost Center":
                            case "Contract Term":
                            case "Connection Type":
                            case "Segment":
                            case "ReportingLine":
                            case "Rptng Line":
                            case "Equipment":
                            case "ServiceType":
                            case "Srv Type":
                            case "Scenario":
                            case "Function":
                            case "Organization":
                            case "Org Chart":
                            case "Account Size":
                            case "HRHV":
                            case "Ethnicity":
                            case "Run Status Id":
                                column.Visible = true;
                                break;
                            default:
                                column.Visible = false;
                                break;
                        }
                    }
                    gvResults.Columns[0].Visible = displayMessage;
                    break;
                case FactTable.EquipmentUser:
                    foreach (DataControlField column in gvResults.Columns) {
                        switch (column.HeaderText) {
                            case "Account":
                            case "Cust Account":
                                column.Visible = false;
                                break;
                            case "Entity":
                            case "Location":
                                column.HeaderText = "Entity";
                                column.Visible = true;
                                break;
                            case "ReportingLine":
                            case "Rptng Line":
                            case "Cost Center":
                            case "Cost Cntr":
                            case "Method Type":
                            case "Methodology Type":
                            case "Sale Type":
                            case "Discount Type":
                            case "Contract Term":
                            case "KPI":
                            case "View":
                            case "Equipment":
                            case "ServiceType":
                            case "Service Type":
                            case "Srv Type":
                            case "Scenario":
                            case "Function":
                            case "Tech Type":
                            case "Run Status Id":
                                column.Visible = true;
                                break;
                            default:
                                column.Visible = false;
                                break;
                        }
                    }
                    gvResults.Columns[0].Visible = displayMessage;
                    break;
                case FactTable.DevicePaymentLoan:
                    foreach (DataControlField column in gvResults.Columns)
                    {
                        switch (column.HeaderText)
                        {

                            case "Aging":
                            case "Collection Status":
                            case "Contract Term":
                            case "Credit Risk Type":
                            case "Entities":
                            case "Equipment":
                            case "Customer Tenure":
                            case "Deact Change Reason":
                            case "FICO":
                            case "Function":
                            case "Loan Tenure":
                            case "Loan Vintage":
                            case "First Payment Made":
                            case "Original Loan Equipment":
                            case "Reporting Line":
                            case "Rptng Line":
                            case "Scenario":
                            case "ServiceType":
                            case "Service Type":
                            case "Srv Type":
                            case "Tranche":
                            case "Upg Elig":
                            case "WriteOff Reason":
                            case "Bill System Customer Type":
                            case "Loan Status":
                            case "Treasury Tenure":
                            case "Run Status Id":
                            column.Visible = true;
                            break;
                            default:
                                column.Visible = false;
                                break;
                        }
                    }
                    gvResults.Columns[0].Visible = displayMessage;
                    break;
                default:
                    bool isLocation = fileType.FactTableId == (int)FactTable.LocationUser;
                    bool isEquipment = fileType.FactTableId == (int)FactTable.EquipmentUser;
                    bool isDataWarehouse = fileType.FactTableId == (int)FactTable.DataWarehouseUser;

                    foreach (DataControlField column in gvResults.Columns) {
                        switch (column.HeaderText) {
                            case "Account":
                            case "Cust Account":
                                column.Visible = !isEquipment;
                                column.HeaderText = isDataWarehouse ? "Cust Account" : "Account";
                                break;
                            case "Entity":
                            case "Location":
                                column.HeaderText = isLocation ? "Location" : "Entity";
                                break;
                            case "Product":
                            case "Sub Acct":
                                column.Visible = !isEquipment;
                                break;
                            case "Cost Cntr":
                                column.Visible = !isDataWarehouse;
                                break;
                            case "Company":
                                column.Visible = !isEquipment && !isDataWarehouse && !isLocation;
                                break;
                            case "Store Status":
                            case "Design Type":
                            case "Loc Type":
                            case "Loc Subtype":
                            case "Loc Tier Code":
                                column.Visible = isLocation;
                                break;
                            case "Method Type":
                            case "Methodology Type":
                            case "Sale Type":
                            case "Discount Type":
                                column.Visible = isEquipment;
                                break;
                            case "Contract Term":
                                column.Visible = isEquipment || isDataWarehouse; ;
                                break;
                            case "Program Eligible":
                                column.Visible = isDataWarehouse;
                                break;
                            case "Branch":
                            case "Connection Type":
                            case "Owning Geography":
                            case "Owning Manager":
                            case "Segment":
                            case "Version":
                            case "Vertical":
                            case "Previous Type":
                                column.Visible = isDataWarehouse;
                                break;
                            case "Organization":
                            case "Org Chart":
                            case "Account Size":
                            case "HRHV":
                            case "Ethnicity":
                            case "Run Status Id":
                                column.Visible = false;
                                break;
                            case "GL Account":
                            case "Region":
                            case "External Segment":
                            case "Business Segment":
                            case "Line of Business":
                            case "Planned Entity":
                            case "Fiscal Period":
                            case "Aging":
                            case "Entities":
                            case "Customer Tenure":
                            case "Credit Risk Type":
                            case "Loan Tenure":
                            case "Loan Vintage":
                            case "Collection Status":
                            case "FICO":
                            case "Upg Elig":
                            case "Tranche":
                            case "Original Loan Equipment":
                            case "First Payment Made":
                            case "WriteOff Reason":
                            case "Deact Change Reason":
                            case "Bill System Customer Type":
                            case "Loan Status":
                            case "Treasury Tenure":
                                column.Visible = false;
                                break;
                            default:
                                column.Visible = true;
                                break;
                        }
                    }
                    gvResults.Columns[0].Visible = displayMessage;

                    // fill table with error results 
                    foreach (FactValidDTO f in results) {
                        string ErrMsg = string.Empty;
                        if (GetMsg != null)
                            ErrMsg = GetMsg(fileType, f);
                        else
                            if (defaultMessage != null && defaultMessage.Length > 0)
                                ErrMsg = defaultMessage;
                        if (ErrMsg.Length > 0) {
                            f.Message = ErrMsg;
                            btnContinue.Visible = false;
                            btnAdd.Visible = true;
                            pnlDeleteAll.Visible = false;
                        }
                    } // end for each fact error message 
                    break;
            }
            
            

            // jevans 5/10/2011 -- check for skipped rows in error results
            if (skippedRows > 0)
            {
                litSkippedRows.Visible = true;
                litSkippedRows.Text = string.Format("{0} rows were skipped.", skippedRows);
                Master.Message += string.Format("<p>The first {0} rows are displayed, {1} rows were skipped. For a complete list of loaded keys, select the Download button.", results.Count, skippedRows);
            }
            else
                litSkippedRows.Visible = false;

            // bind grid to array 
            gvResults.DataSource = results;
            gvResults.DataBind();

            returnCode = results.Count;
        }
        catch (Exception ex)
        {
            //  Log the error to a table.
            Utils.LogEvent(Master.curUser.EmployeeID, "UserInputNewKey.aspx", "FillTable", ex, UserToolLogLevel.Error);
            Master.Message = HypMDUA.ERROR_MESSAGE;
        }

        return returnCode;
    }
    #endregion
} // end of class
