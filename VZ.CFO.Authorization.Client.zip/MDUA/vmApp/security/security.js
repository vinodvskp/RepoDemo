﻿(function () {
    var app = angular.module("security", ["common"]);
}());
