﻿(function (module) {
    var loginController = function (oauth, currentUser, alerting, loginRedirect) {
        var vm = this;
        vm.username = "";
        vm.password = "";
        vm.user = currentUser.profile;
        vm.login = function (form) {
            if (form.$valid) {
                oauth.login(vm.username, vm.password)
                     .then(function () {
                         loginRedirect.redirectPostLogin();
                     })
                     .catch(alerting.errorHandler("Could not login"));
                vm.password = vm.username = "";
                form.$setUntouched();
            }
        }
    };
    module.controller("loginController", loginController);
}(angular.module("security")));
