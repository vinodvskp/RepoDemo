angular.module('vmApp').factory('storeService', function () {
        var storedObject;
        return {
            set: function (o) {
                this.storedObject = o.toString();
            },
            get: function () {
                return this.storedObject;
            }
        };
});