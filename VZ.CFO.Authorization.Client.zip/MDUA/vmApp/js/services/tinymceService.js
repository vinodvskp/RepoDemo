﻿
angular.module('vmApp').factory('tinymceService', ['$http', '$q', 'authenticationService', 'serverVariableService', function ($http, $q, authenticationService, serverVariableService) {
    const plugins = [
             'advlist autolink lists link charmap hr anchor pagebreak',
             'searchreplace wordcount visualblocks visualchars code fullscreen',
             'insertdatetime nonbreaking save table contextmenu directionality',
             'emoticons template paste textcolor colorpicker textpattern imagetools toc help'
    ];
    const toolbar1 = 'undo redo | insert | styleselect | bold italic fontselect fontsizeselect | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link';
    const toolbar2 = 'forecolor backcolor emoticons | help';

    let content_id = undefined;
    let content_type = 0;
    let readonly = 0;

    function getContentFromSvc(token, payload) {
        return $http({
            method: 'GET',
            headers: { 'Authorization': token },
            url: serverVariableService.MDUA_USERS_ENDPOINT() + '/GetHomepageContent/' + payload.eid
        }).then(function (response) {
            content_id = !response.data.Id ? undefined : response.data.Id;
            content_type = response.data.Type;
            return response;
        });
    }

    function postContentFromSvc(token, payload) {
        return $http({
            method: 'POST',
            headers: { 'Authorization': token },
            url: serverVariableService.MDUA_USERS_ENDPOINT() + '/PostHomepageContent/' + payload.eid,
            data: payload.data
        })
    }

    //public interface
    return {
        getContent: function (payload) {        
            return authenticationService.simpleServiceDispatcher(payload, getContentFromSvc);
        },

        getAdminControl: function (is_admin) {
            return {
                inline: !is_admin,
                plugins: is_admin ? plugins : [],
                toolbar1: is_admin ? toolbar1 : false,
                toolbar2: is_admin ? toolbar2 : false,
                readonly: is_admin ? readonly : 1
            }
        },

        saveContent: function (eid, content) {
            let payload = {
                eid: eid,
                data: {
                    Id: content_id,
                    Content: content,
                    type: content_type
                }
            }
            return authenticationService.simpleServiceDispatcher(payload, postContentFromSvc);
        }
    };
}]);
