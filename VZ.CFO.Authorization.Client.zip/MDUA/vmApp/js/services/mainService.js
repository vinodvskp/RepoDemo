(function () {

    angular.module('vmApp')
        .factory('mainService', ['$http', '$q', 'serverVariableService', 'authenticationService', mainService]);

    function mainService($http, $q, serverVariableService, authenticationService) {

        return {
        	getLdapService: getLdapService,
        	getMenuService:getMenuService,
            eidService: eidService,
            singoutService: singoutService,            
            getHomeMenuItemServic: getHomeMenuItemServic,
            getFactTableSettings: getFactTableSettings,
            auditUser: auditUser,
            AuditUserViewModel: AuditUserViewModel
        };
        
        function eidService() {
        	return serverVariableService.USER_EID()
        }
     
        function getLdapService(payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getLdapUserWorker, successCallback, errorCallback);
        }
        
        function getMenuService(payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getMenuWorker, successCallback, errorCallback);
        }


        function getFactTableSettings(payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getFactTableSettingsWorker, successCallback, errorCallback);
        }
        
        function getHomeMenuItemServic(payload, success, error) {
            authenticationService.serviceCallDispatcher(payload, getHomeMenuItems, success, error);
        }
        
        function auditUser (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, auditUserWorker, successCallback, errorCallback);
        }

        function AuditUserViewModel(employeeId, location, action, status, logLevel) {
            var self = this;
            self.EmployeeId = employeeId;
            self.Location = location;
            self.Action = action;
            self.Status = status;
            self.LogLevel = logLevel;
        }

        function singoutService() {
            return $http({
                method: 'GET',               
                url: serverVariableService.LOGOUT_URL()
            })
            .then(function (response) {
                return response;
            },function (response) {
                return $q.reject(response);
            });
        }

        function getMenuWorker(authToken, payload) {
            return $http({
                method: 'get',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MENU_URL()                
            })
	         .then(function (response) {
	             if (response.status == 200) {
	                 return $q.when(response);
	             }
	             else {
	                 return $q.reject("Get Menu request failed");
	             }
	         }, function (response) {
	             var resp = response;
	             //console.log("getRequestTypes service call failed");
	             return $q.reject(resp);
	         });
        }

        function getHomeMenuItems(authToken, payload) {
            return $http({
                method: 'GET',
                headers: { 'Authorization': authToken },
                url: serverVariableService.HOME_MENU_URL()
            })
	         .then(function (response) {
	             if (response.status == 200) {
	                 return $q.when(response);
	             }
	             else {
	                 return $q.reject("Get home menu items request failed");
	             }
	         }, function (response) {
	             var resp = response;
	             return $q.reject(resp);
	         });
        }

        function getLdapUserWorker(authToken, payload) {

            return $http({
                method: 'get',
                headers: { 'Authorization': authToken },
                url: serverVariableService.LDAP_URL()
            })
	         .then(function (response) {
	             if (response.status == 200) {
	                 return $q.when(response);
	             }
	             else {
	                 return $q.reject("Get user request failed");
	             }
	         }, function (response) {
	             var resp = response;
	             //console.log("getRequestTypes service call failed");
	             return $q.reject(resp);
	         });

        }

        function auditUserWorker(authToken, payload) {
            return $http({
                method: 'post',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_USERS_ENDPOINT() + '/AuditUser',
                data: payload.data
            })
         .then(function (response) {
             if (response.status == 200) {
                 return $q.when(response);
             }
             else {
                 return $q.reject("request call does not return future versions data");
             }
         }, function (response) {
             var resp = response;
             //console.log("getRequestTypes service call failed");
             return $q.reject(resp);
         });
        }


        function getFactTableSettingsWorker(authToken, payload) {

            return $http({
                method: 'get',
                headers: { 'Authorization': authToken },
                url: serverVariableService.MDUA_NOTIFICATION_ENDPOINT() + '/api/mdua/facttable/GetFactTableSetting'
            })
	         .then(function (response) {
	             if (response.status == 200) {
	                 return $q.when(response.data);
	             }
	             else {
	                 return $q.reject("Get Fact Table Settings failed");
	             }
	         }, function (response) {
	             var resp = response;
	             //console.log("getRequestTypes service call failed");
	             return $q.reject(resp);
	         });

        }
    }
}());