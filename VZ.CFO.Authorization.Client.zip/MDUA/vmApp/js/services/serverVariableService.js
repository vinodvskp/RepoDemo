(function () {

    angular.module('vmApp').factory('serverVariableService', [serverVariableService]);

    function serverVariableService() {

        return {
            
        	USER_EID: USER_EID,
        	LDAP_URL:LDAP_URL,
        	MENU_URL:MENU_URL,
        	MDUA_NOTIFICATION_ENDPOINT: MDUA_NOTIFICATION_ENDPOINT,
        	MT_ENDPOINT: MT_ENDPOINT,
        	MDUA_USERS_ENDPOINT: MDUA_USERS_ENDPOINT,
        	VM_ENDPOINT: VM_ENDPOINT,
        	VM_ENDPOINT_SIGNED: VM_ENDPOINT_SIGNED,
        	VM_DISPLAY_MAXROWCOUNT:VM_DISPLAY_MAXROWCOUNT,
        	ODJOBS_ENDPOINT: ODJOBS_ENDPOINT,
        	LOGOUT_URL:LOGOUT_URL,
        	SITE_SUBFOLDER:SITE_SUBFOLDER,
        	OAUTH_HOST: OAUTH_HOST,
        	NOTIFICATION_TYPE: NOTIFICATION_TYPE,
        	DRM_LINK: DRM_LINK,
        	MENU_MODE: MENU_MODE,
        	DATASCOOP_ENDPOINT: DATASCOOP_ENDPOINT,
        	HOME_MENU_URL: HOME_MENU_URL,
        	HOST_URL: HOST_URL
          
        };
        
        function USER_EID() {   
            return document.getElementById("login_eid") ? document.getElementById("login_eid").value : document.getElementById("ctl00_login_eid").value;
        }
        
        function LDAP_URL() {
            return (document.getElementById("ldap_server") ? document.getElementById("ldap_server").value : document.getElementById("ctl00_ldap_server").value) + '/api/mdua/useraccess/GetAllUsers/' + USER_EID() + '';
        }
        
        function MENU_URL() {
            return (document.getElementById("mt_server") ? document.getElementById("mt_server").value : document.getElementById("ctl00_mt_server").value) + '/api/mdua/useraccess/GetMenuForUser';
        }

        function HOME_MENU_URL() {
            return (document.getElementById("mt_server") ? document.getElementById("mt_server").value : document.getElementById("ctl00_mt_server").value) + '/api/mdua/useraccess/GetHomeMenuItem';
        }
        
        function MDUA_NOTIFICATION_ENDPOINT() {
            return document.getElementById("mt_server") ? document.getElementById("mt_server").value : document.getElementById("ctl00_mt_server").value;
        }
        
        function MT_ENDPOINT() {   
            return (document.getElementById("mt_server") ? document.getElementById("mt_server").value : document.getElementById("ctl00_mt_server").value) + '/api/MappingTableMgmt';
        }

        function MDUA_USERS_ENDPOINT() { 
            return (document.getElementById("mt_server") ? document.getElementById("mt_server").value : document.getElementById("ctl00_mt_server").value) + '/api/mdua/useraccess';
        }
        
        function VM_ENDPOINT() {   
            return (document.getElementById("vm_server") ? document.getElementById("vm_server").value : document.getElementById("ctl00_vm_server").value) + '/protected/vmservice';
        }
        
        function VM_ENDPOINT_SIGNED() {
            return (document.getElementById("vm_server") ? document.getElementById("vm_server").value : document.getElementById("ctl00_vm_server").value) + '/vmservice';
        }

        function VM_DISPLAY_MAXROWCOUNT() {
            return (document.getElementById("vm_display_maxrowcount") ? document.getElementById("vm_display_maxrowcount").value : "1000");
        }

        function LOGOUT_URL()
        {
            return (document.getElementById("ldap_server") ? document.getElementById("ldap_server").value : document.getElementById("ctl00_ldap_server").value) + '/logout';
        }

        function ODJOBS_ENDPOINT() {
            return (document.getElementById("mt_server") ? document.getElementById("mt_server").value : document.getElementById("ctl00_mt_server").value) + '/api/mdua/odjobs';
        };
        
        function SITE_SUBFOLDER() {
            return document.getElementById("site_subfolder") ? document.getElementById("site_subfolder").value : document.getElementById("ctl00_site_subfolder").value;
        };
        function OAUTH_HOST() {
            return document.getElementById("oauth_host") ? document.getElementById("oauth_host").value : document.getElementById("ctl00_oauth_host").value;
        };
        function NOTIFICATION_TYPE() {
            return document.getElementById("notification_type") ? document.getElementById("notification_type").value : document.getElementById("ctl00_notification_type").value;
        };
        function DRM_LINK() {
            return document.getElementById("drm_link") ? document.getElementById("drm_link").value : document.getElementById("ctl00_drm_link").value;
        };
        function MENU_MODE() {
            return document.getElementById("menu_mode") ? document.getElementById("menu_mode").value : document.getElementById("ctl00_menu_mode").value;
        };
        function DATASCOOP_ENDPOINT() {
            return document.getElementById("datascoop_server") ? document.getElementById("datascoop_server").value : document.getElementById("ctl00_datascoop_server").value;
        };
        function HOST_URL() {
            return document.getElementById("mt_server") ? document.getElementById("mt_server").value : document.getElementById("ctl00_mt_server").value;
        }
        
    }
}());
