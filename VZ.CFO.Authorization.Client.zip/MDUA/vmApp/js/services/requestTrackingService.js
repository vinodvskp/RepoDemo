﻿(function () {

    angular.module('vmApp')
        .service('requestTrackingService', ['$q', '$http', 'constantService','serverVariableService','authenticationService',requestTrackingService]);

    function requestTrackingService($q, $http, constantService,serverVariableService,authenticationService) {
		
        var self = this;
		var _rowsPerPage;
		var _tableId = 1;
		self.totalRecords = 0;
		self.totalPages = 0;

		self.setTableId = function(tableId) {
			_tableId = tableId;
		}

		self.setRowsPerPage = function(rowsPerPage) {
			_rowsPerPage = rowsPerPage;
		}
         
         
         
    	 self.getRecentActivity = function(payload, successCallback, errorCallback) {
    	    	authenticationService.serviceCallDispatcher(payload, getRecentActivityWorker,successCallback,errorCallback);
    	 }
    	 
    	 self.getRequestTypes = function(payload, successCallback, errorCallback) {
    	    	authenticationService.serviceCallDispatcher(payload,getRequestTypesWorker,successCallback,errorCallback);
    	    }
    	 
    	 self.getRequests = function(payload, successCallback, errorCallback) {
 	    	authenticationService.serviceCallDispatcher(payload,getRequestsWorker,successCallback,errorCallback);
 	    }
    	 
    	 self.retryRequest = function(payload, successCallback, errorCallback) {
  	    	authenticationService.serviceCallDispatcher(payload,retryRequestWorker,successCallback,errorCallback);
  	    }
     	 
    	 self.completeRequest = function(payload, successCallback, errorCallback) {
   	    	authenticationService.serviceCallDispatcher(payload,completeRequestWorker,successCallback,errorCallback);
   	    }
      	 
    	 self.cancelRequest = function(payload, successCallback, errorCallback) {
    	    	authenticationService.serviceCallDispatcher(payload,cancelRequestWorker,successCallback,errorCallback);
    	 }
    	    
    	 function getRecentActivityWorker(authToken, payload) {
    	    	return $http({
    	             method: 'post',
    	             headers: {'Authorization': authToken },
    	             url: serverVariableService.VM_ENDPOINT() +'/dashboard/recentActivity',
    	             data: payload
    	         })
    	         .then(function(response) {
    	        	 if(response.status == 200) {
    	        		 return $q.when(response);
    	        	 }
    	       		 else {
    	       			 return $q.reject("request call does not return recent activity data");
    	       		  }
    	          }, function(response){
    	          	var resp = response;
    	          	//console.log("getRequestTypes service call failed");
    	          	return $q.reject(resp);
    	          });
    	    }
    	 function getRequestTypesWorker(authToken, payload) {
    	    	return $http({
    	             method: 'post',
    	             headers: {'Authorization': authToken },
    	             url: serverVariableService.VM_ENDPOINT() +'/newRequest/getRequestTypes',
    	             data: payload
    	         })
    	         .then(function(response) {
    	        	 if(response.status == 200) {
    	        		 return $q.when(response);
    	        	 }
    	       		 else {
    	       			 return $q.reject("request call does not return request types data");
    	       		  }
    	          }, function(response){
    	          	var resp = response;
    	          	//console.log("getRequestTypes service call failed");
    	          	return $q.reject(resp);
    	          });
    	    }
    	 
    	 function getRequestsWorker(authToken, payload) {
 	    	return $http({
 	             method: 'post',
 	             headers: {'Authorization': authToken },
 	             url: serverVariableService.VM_ENDPOINT() +'/requestTracking/getRequests',
 	             data: payload
 	         })
 	         .then(function(response) {
 	        	 if(response.status == 200) {
 	        		 return $q.when(response);
 	        	 }
 	       		 else {
 	       			 return $q.reject("request call does not return requests data");
 	       		  }
 	          }, function(response){
 	          	var resp = response;
 	          	//console.log("getRequestTypes service call failed");
 	          	return $q.reject(resp);
 	          });
 	    }
    	 
    	 function retryRequestWorker(authToken, payload) {
  	    	return $http({
  	             method: 'post',
  	             headers: {'Authorization': authToken },
  	             url: serverVariableService.VM_ENDPOINT() +'/requestTracking/retryRequest',
  	             data: payload
  	         })
  	         .then(function(response) {
  	        	 if(response.status == 200) {
  	        		 return $q.when(response);
  	        	 }
  	       		 else {
  	       			 return $q.reject(response);
  	       		  }
  	          }, function(response){
  	          	var resp = response;
  	          	//console.log("getRequestTypes service call failed");
  	          	return $q.reject(resp);
  	          });
  	    }

       	 function completeRequestWorker(authToken, payload) {
   	    	return $http({
   	             method: 'post',
   	             headers: {'Authorization': authToken },
   	             url: serverVariableService.VM_ENDPOINT() +'/requestDetails/markRequestAsComplete',
   	             data: payload
   	         })
   	         .then(function(response) {
   	        	 if(response.status == 200) {
   	        		 return $q.when(response);
   	        	 }
   	       		 else {
   	       			 return $q.reject(response);
   	       		  }
   	          }, function(response){
   	          	var resp = response;
   	          	//console.log("getRequestTypes service call failed");
   	          	return $q.reject(resp);
   	          });
   	    }
       	 
       	 function cancelRequestWorker(authToken, payload) {
   	    	return $http({
   	             method: 'post',
   	             headers: {'Authorization': authToken },
   	             url: serverVariableService.VM_ENDPOINT() +'/requestTracking/cancelRequest',
   	             data: payload
   	         })
   	         .then(function(response) {
   	        	 if(response.status == 200) {
   	        		 return $q.when(response);
   	        	 }
   	       		 else {
   	       			 return $q.reject(response);
   	       		  }
   	          }, function(response){
   	          	var resp = response;
   	          	//console.log("getRequestTypes service call failed");
   	          	return $q.reject(resp);
   	          });
   	    }

    }

}());