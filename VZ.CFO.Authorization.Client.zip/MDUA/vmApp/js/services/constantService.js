
(function () {
    angular.module('vmApp')
        .constant('constantService',
        {
        	APP_TITLE: 'MDM/PMR',
            APP_DESCRIPTION: 'Finance Data Management',
            APP_AUTH_TYPE: 'Bearer ',
            MAPPING_TABLE_ROWS_PER_PAGE: 2500
        });
}());