﻿(function () {

    angular.module('vmApp')
  .service('createRequestService', ['$interval','$q', '$http', 'constantService', 'authenticationService', 'serverVariableService', createRequestService]);

    function createRequestService($interval,$q, $http, constantService, authenticationService, serverVariableService) {
        var self = this;
        self.pollInterval = undefined;
        self.calculateTransDelta = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, calculateTransDeltaWorker, successCallback, errorCallback);
        }

        self.getRequestTypes = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getRequestTypesWorker, successCallback, errorCallback);
        }

        self.getProfile = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getProfileWorker, successCallback, errorCallback);
        }

        self.getFutureVersions = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getFutureVersionsWorker, successCallback, errorCallback);
        }

        self.getHierarchiesByVersion = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getHierarchiesByVersionWorker, successCallback, errorCallback);
        }

        self.submitRequest = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, submitRequestWorker, successCallback, errorCallback);
        }

        self.processRequest = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, processRequestWorker, successCallback, errorCallback);
        }

        self.isDeltaStale = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, isDeltaStaleWorker, successCallback, errorCallback);
        }

        self.submitGenDeltaRequest = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, submitGenDeltaRequestWorker, successCallback, errorCallback);
        }

        self.processGenDeltaRequest = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, processGenDeltaRequestWorker, successCallback, errorCallback);
        }
    
        self.genDeltaStatus = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, genDeltaStatusWorker, successCallback, errorCallback);
        }

        self.startDeltaStatusPolling = function (callback) {
            self.pollInterval = $interval(callback, 5000);
        }

        self.stopDeltaStatusPolling = function () {
            if (angular.isDefined(self.pollInterval)) {
                $interval.cancel(self.pollInterval);
                self.pollInterval = undefined;
            }
        }

        self.getGenDeltaTxns = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getGenDeltaTxnsWorker, successCallback, errorCallback);
        }

        self.downloadDeltaSignedKey = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, downloadDeltaSignedKeyWorker, successCallback, errorCallback);
        }

        function getRequestTypesWorker(authToken, payload) {
            return $http({
                method: 'post',
                headers: { 'Authorization': authToken },
                url: serverVariableService.VM_ENDPOINT() + '/newRequest/getRequestTypes',
                data: payload
            })
             .then(function (response) {
                 if (response.status == 200) {
                     return $q.when(response);
                 }
                 else {
                     return $q.reject("request call does not return valid data");
                 }
             }, function (response) {
                 var resp = response;
                 //console.log("getRequestTypes service call failed");
                 return $q.reject(resp);
             });
        }

        function getProfileWorker(authToken, payload) {
            return $http({
                method: 'post',
                headers: { 'Authorization': authToken },
                url: serverVariableService.VM_ENDPOINT() + '/dashboard/profile',
                data: payload
            })
             .then(function (response) {
                 if (response.status == 200) {
                     return $q.when(response);
                 }
                 else {
                     return $q.reject("request call does not return valid profile data");
                 }
             }, function (response) {
                 var resp = response;
                 //console.log("getRequestTypes service call failed");
                 return $q.reject(resp);
             });
        }

        function getFutureVersionsWorker(authToken, payload) {
            return $http({
                method: 'post',
                headers: { 'Authorization': authToken },
                url: serverVariableService.VM_ENDPOINT() + '/newRequest/getFutureVersions',
                data: payload
            })
             .then(function (response) {
                 if (response.status == 200) {
                     return $q.when(response);
                 }
                 else {
                     return $q.reject("request call does not return future versions data");
                 }
             }, function (response) {
                 var resp = response;
                 //console.log("getRequestTypes service call failed");
                 return $q.reject(resp);
             });
        }

        function getHierarchiesByVersionWorker(authToken, payload) {
            return $http({
                method: 'post',
                headers: { 'Authorization': authToken },
                url: serverVariableService.VM_ENDPOINT() + '/newRequest/getHierarchiesByVersionType',
                data: payload
            })
             .then(function (response) {
                 if (response.status == 200) {
                     return $q.when(response);
                 }
                 else {
                     return $q.reject("request call does not return HierarchiesByVersionType data");
                 }
             }, function (response) {
                 var resp = response;
                 //console.log("getRequestTypes service call failed");
                 return $q.reject(resp);
             });
        }

        function calculateTransDeltaWorker(authToken, payload) {
            return $http({
                method: 'post',
                headers: { 'Authorization': authToken },
                url: serverVariableService.VM_ENDPOINT() + '/newRequest/identifyDelta',
                data: payload
            })
            .then(function (response) {
                if (response.status == 200) {
                    return $q.when(response);
                }
                else {
                    return $q.reject("request call does not return trans delta data");
                }
            }, function (response) {
                var resp = response;
                //console.log("getRequestTypes service call failed");
                return $q.reject(resp);
            });
        }

        function submitRequestWorker(authToken, payload) {
            return $http({
                method: 'post',
                headers: { 'Authorization': authToken },
                url: serverVariableService.VM_ENDPOINT() + '/newRequest/submitRequest',
                data: payload
            })
            .then(function (response) {
                if (response.status == 200) {
                    return $q.when(response);
                } else {
                    return $q.reject("submit request service failed.");
                }
            }, function (response) {
                var resp = response;
                //console.log("getRequestTypes service call failed");
                return $q.reject(resp);
            });
        }

        function isDeltaStaleWorker(authToken, payload) {
            return $http({
                method: 'post',
                headers: { 'Authorization': authToken },
                url: serverVariableService.VM_ENDPOINT() + '/newRequest/isStaleDelta',
                data: payload
            })
            .then(function (response) {
                if (response.status == 200) {
                    return $q.when(response);
                } else {
                    return $q.reject("isDeltaStale service failed.");
                }
            }, function (response) {
                var resp = response;
                //console.log("getRequestTypes service call failed");
                return $q.reject(resp);
            });
        }

        function processRequestWorker(authToken, payload) {
            return $http({
                method: 'post',
                headers: { 'Authorization': authToken },
                url: serverVariableService.VM_ENDPOINT() + '/newRequest/processRequest',
                data: payload
            })
            .then(function (response) {
                if (response.status == 200) {
                    return $q.when(response);
                } else {
                    return $q.reject("process request service failed.");
                }
            }, function (response) {
                var resp = response;
                console.log("getProcessRequest service call failed");
                return $q.reject(resp);
            });
        }


        function submitGenDeltaRequestWorker(authToken, payload) {
            return $http({
                method: 'post',
                headers: { 'Authorization': authToken },
                url: serverVariableService.VM_ENDPOINT() + "/newRequest/submitGenDeltaRequest",
                data: payload
            })
             .then(function (response) {
                 if (response.status == 200) {
                     return $q.when(response);
                 }
                 else {
                     return $q.reject("Error occurred while calling submitGenDeltaRequest");
                 }
             }, function (response) {
                 var resp = response;
                 //console.log("getRequestTypes service call failed");
                 return $q.reject(resp);
             });
        }

        function processGenDeltaRequestWorker(authToken, payload) {
            return $http({
                method: 'post',
                headers: { 'Authorization': authToken },
                url: serverVariableService.VM_ENDPOINT() + "/newRequest/processGenDeltaRequestAsync",
                data: payload
            })
             .then(function (response) {
                 if (response.status == 200) {
                     return $q.when(response);
                 }
                 else {
                     return $q.reject("Error occurred while calling processGenDeltaRequest");
                 }
             }, function (response) {
                 var resp = response;
                 //console.log("getRequestTypes service call failed");
                 return $q.reject(resp);
             });
        }


        function genDeltaStatusWorker(authToken, payload) {
            return $http({
                method: 'post',
                headers: { 'Authorization': authToken },
                url: serverVariableService.VM_ENDPOINT() +'/newRequest/getGenDeltaStatus',
                data: payload
            })
             .then(function (response) {
                 if (response.status == 200) {
                     return $q.when(response);
                 }
                 else {
                     return $q.reject("Error occurred while calling getGenDeltaStatus");
                 }
             }, function (response) {
                 var resp = response;
                 //console.log("getRequestTypes service call failed");
                 return $q.reject(resp);
             });
        }



        function getGenDeltaTxnsWorker(authToken, payload) {
            return $http({
                method: 'post',
                headers: { 'Authorization': authToken },
                url: serverVariableService.VM_ENDPOINT() + '/newRequest/getGenDeltaTxns',
                data: payload
            })
             .then(function (response) {
                 if (response.status == 200) {
                     return $q.when(response);
                 }
                 else {
                     return $q.reject("Error occurred while calling getGenDeltaTxns");
                 }
             }, function (response) {
                 var resp = response;
                 //console.log("getRequestTypes service call failed");
                 return $q.reject(resp);
             });
        }
        
        function downloadDeltaSignedKeyWorker(authToken, payload) {
            return $http({
                method: 'POST',
                headers: { 'Authorization': authToken },
                url: serverVariableService.VM_ENDPOINT() + '/newRequest/downloadDeltaTxns/getTempDeltaSignedKey',
                data: payload
            })
             .then(function (response) {
                 if (response.status == 200) {

                     return $q.when(response);
                 }
                 else {
                     return $q.reject({ message: { type: "danger", text: "error occured downloading delta" } });
                 }
             }, function (response) {
                 var resp = response;
                 //console.log("getRequestTypes service call failed");
                 return $q.reject({ message: { type: "danger", text: "error occured downloading delta" } });
             });
        }

    }
}());