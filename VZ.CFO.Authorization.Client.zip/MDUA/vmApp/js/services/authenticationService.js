(function () {

    angular.module('vmApp')
        .service('authenticationService', ['$timeout','$http', '$q', 'serverVariableService', authenticationService]);

    function authenticationService($timeout,$http, $q, serverVariableService) {
    	var self = this;
    	self.tokenInfo = {};
    	self.tokenInfo.token_type ='';
    	self.tokenInfo.access_token ='';
    	self.tokenInfo.tokenExpired = true;
    	self.tokenInfo.error ='';
    	self.tokenInfo.error_description ='';
    	self.tokenInfo.message = {};
    	self.serviceCallDispatcher = function (payload, serviceToCall, successCallback, errorCallback) {
    	    var authPromise = getAccessToken();
    	    authPromise.then(
                    //success
                    function (response) {
                        //	var auth = response;
                        var authToken = response.token_type + " " + response.access_token;
                        //console.log(authToken);
                        return $q.when(authToken);
                    },
                    //fail
                    function (response) {
                        return $q.reject(response);
                    }).
                then(function (authToken) {
                    return serviceToCall(authToken, payload);
                },

                    function (response) {
                        var resp = response;
                        return $q.reject(response);
                    }).
                then(successCallback, errorCallback);

    	};
    	self.simpleServiceDispatcher = function (payload, serviceToCall) {
    	    var authPromise = getAccessToken();
    	    return authPromise.then(
                    function (response) {
                        var authToken = response.token_type + " " + response.access_token;
                        return $q.when(authToken);
                    },
                    function (response) {
                        return $q.reject(response);
                    }).
                then(function (authToken) {
                        return serviceToCall(authToken, payload);
                    },
                    function (response) {
                        var resp = response;
                        return $q.reject(response);
                    });
    	};
    	function getAccessToken(payload) {
    		
	        if(self.tokenInfo.tokenExpired===false) {
	        	
	        	return $q.when(self.tokenInfo);     	
	        }
	        else {
	            return $http({
	                method: 'GET',
	               // headers: { 'EID': '6848458798' },
	                url: serverVariableService.OAUTH_HOST() + '/api/token/1/false'
	            })
	            .then(function (response) {
	            	if(response.data) {
		            		self.tokenInfo.token_type ="Bearer";
		                	self.tokenInfo.access_token = response.data;//response.data.access_token;
		                	self.tokenInfo.tokenExpired = false;
		                	self.tokenInfo.error ='';
		                	self.tokenInfo.error_description ='';
		            		$timeout(function(){ self.tokenInfo.tokenExpired = true;},2000*60);
		            		return $q.when(self.tokenInfo); 
	            	}
	            	else {
	            		self.tokenInfo.token_type ='';
	                	self.tokenInfo.access_token ='';
	                	self.tokenInfo.tokenExpired = true;
	                	self.tokenInfo.error ='No access token returned.';
	                	self.tokenInfo.error_description ='No access token returned.';
	                	self.tokenIfno.message = { type:"danger",text:"No access token returned."};
	            		return $q.reject(self.tokenInfo); 
	            	}    		
	            },
	            function(response) {
            	
            		console.log("status",response.status);
            		self.tokenInfo.token_type ='';
                	self.tokenInfo.access_token ='';
                	self.tokenInfo.tokenExpired = true;
                	self.tokenInfo.error = response.status;
                	self.tokenInfo.error_description = " Auth call failed"
                	self.tokenInfo.message = { type:"danger",text:"Auth call failed"};
            		return $q.reject(self.tokenInfo);
		            	
	            });
	            
	        }
        }
    }
}());