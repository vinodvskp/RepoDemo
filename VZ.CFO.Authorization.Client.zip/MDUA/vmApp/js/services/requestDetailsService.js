(function () {

    angular.module('vmApp')
        .service('requestDetailsService', ['$q', '$http', 'constantService','serverVariableService','authenticationService',requestDetailsService]);

    function requestDetailsService($q, $http, constantService,serverVariableService,authenticationService) {
         var self = this;
    	 
         self.getRequestDetails = function(payload, successCallback, errorCallback) {
  	    	authenticationService.serviceCallDispatcher(payload,getRequestDetailsWorker,successCallback,errorCallback);
  	    }
         
         self.getDeltaList = function(payload, successCallback, errorCallback) {
   	    	authenticationService.serviceCallDispatcher(payload,getDeltaListWorker,successCallback,errorCallback);
   	    }
      	  
         self.getRequestLogs = function(payload, successCallback, errorCallback) {
    	    	authenticationService.serviceCallDispatcher(payload,getRequestLogsWorker,successCallback,errorCallback);
    	    }
      	
         self.downloadRequestLogs = function(payload, successCallback, errorCallback) {
 	    	authenticationService.serviceCallDispatcher(payload,downloadRequestLogsWorker,successCallback,errorCallback);
 	    }
   	     
         self.downloadDeltaSignedKey = function (payload, successCallback, errorCallback) {
             authenticationService.serviceCallDispatcher(payload, downloadDeltaSignedKeyWorker, successCallback, errorCallback);
         }
     	    
     	 function getRequestDetailsWorker(authToken, payload) {
     	    	return $http({
     	             method: 'post',
     	             headers: {'Authorization': authToken },
     	             url: serverVariableService.VM_ENDPOINT() +'/requestDetails/getRequestDetails',
     	             data: payload
     	         })
     	         .then(function(response) {
     	        	 if(response.status == 200) {
     	        		 return $q.when(response);
     	        	 }
     	       		 else {
     	       			 return $q.reject("request call does not return request details data");
     	       		  }
     	          }, function(response){
     	          	var resp = response;
     	          	//console.log("getRequestTypes service call failed");
     	          	return $q.reject(resp);
     	          });
     	    }
         
     	 function getDeltaListWorker(authToken, payload) {
   	    	return $http({
   	             method: 'post',
   	             headers: {'Authorization': authToken },
   	    	    //url: serverVariableService.VM_ENDPOINT() +'/requestTracking/getDeltaList',
   	             url: serverVariableService.VM_ENDPOINT() + '/requestTracking/getDeltaListLimit',
   	             data: payload
   	         })
   	         .then(function(response) {
   	        	 if(response.status == 200) {
   	        		 return $q.when(response);
   	        	 }
   	       		 else {
   	       			 return $q.reject("request call does not return delta list details");
   	       		  }
   	          }, function(response){
   	          	var resp = response;
   	          	//console.log("getRequestTypes service call failed");
   	          	return $q.reject(resp);
   	          });
   	    }
     	 function getRequestLogsWorker(authToken, payload) {
    	    	return $http({
    	             method: 'post',
    	             headers: {'Authorization': authToken },
    	             url: serverVariableService.VM_ENDPOINT() +'/requestDetails/getRequestLogs',
    	             data: payload
    	         })
    	         .then(function(response) {
    	        	 if(response.status == 200) {
    	        		 return $q.when(response);
    	        	 }
    	       		 else {
    	       			 return $q.reject("request call does not return request logs");
    	       		  }
    	          }, function(response){
    	          	var resp = response;
    	          	//console.log("getRequestTypes service call failed");
    	          	return $q.reject(resp);
    	          });
    	} 
     	 
     	 function downloadRequestLogsWorker(authToken, payload) {
 	    	return $http({
 	             method: 'post',
 	             headers: {'Authorization': authToken },
 	             url: serverVariableService.VM_ENDPOINT() + '/requestDetails/downloadVMActionScripts',
 	             data: payload,
 	             contentType: "application/json",
 	         })
 	         .then(function(response) {
 	        	 if(response.status == 200) {
 	        		 return $q.when(response.data);
 	        	 }
 	       		 else {
 	       			 return $q.reject("request call does not return request logs");
 	       		  }
 	          }, function(response){
 	          	var resp = response;
 	          	//console.log("getRequestTypes service call failed");
 	          	return $q.reject(resp);
 	          });
     	 }

     	 function downloadDeltaSignedKeyWorker(authToken, payload) {
     	     return $http({
     	         method: 'POST',
     	         headers: { 'Authorization': authToken },
     	         url: serverVariableService.VM_ENDPOINT() + '/requestDetails/downloadVMDeltaTxns/getVMDeltaSignedKey',
     	         data: payload
     	     })
              .then(function (response) {
                  if (response.status == 200) {

                      return $q.when(response);
                  }
                  else {
                      return $q.reject({ message: { type: "danger", text: "error occured downloading delta" } });
                  }
              }, function (response) {
                  var resp = response;
                  //console.log("getRequestTypes service call failed");
                  return $q.reject({ message: { type: "danger", text: "error occured downloading delta" } });
              });
     	 }

     	 
    }

}());