
(function () {
    'use strict';

    angular.module('vmApp')
      .directive('fileUpload', ['$parse',function($parse) {
    	    return {
    	        require:"ngModel",
    	        restrict: 'A',
    	        link: function($scope, el, attrs, ngModel){
    	            el.bind('change', function(event){
    	                var files = event.target.files;
    	                var file = files[0];
    	                ngModel.$setViewValue(file.name);
    	                //console.log(file.name);
    	                //console.log("ngModel");
                        $scope.gridApi.importer.importFile(file);
    	                $scope.$apply();
    	            });
    	        }
    	    };
    	}]);
      
})();
