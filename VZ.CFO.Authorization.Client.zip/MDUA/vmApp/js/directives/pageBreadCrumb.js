(function () {
    'use strict';
    angular.module('vmApp').directive('pageBreadCrumb',function () {
        return {
            restrict: 'A',
            template: '<h1>{{bcCtrl.currentBreadCrumbItem.displayName}}</h1> ' +
                      '<ol ng-if="bcCtrl.allBreadCrumbItems.length > 1" class="breadcrumb">' +
                          '<li ng-if="bcCtrl.activeBreadCrumbItems.length > 0" ng-repeat="item in bcCtrl.activeBreadCrumbItems"><a ng-href="{{item.url}}">{{item.displayName}}</a></li>' +
                          '<li>{{bcCtrl.currentBreadCrumbItem.displayName}}</li>' +
                       '</ol>',
            controller: ['$state', function ($state) {
            	var self = this;
            	self.allBreadCrumbItems =[];
            	self.activeBreadCrumbItems =[];
            	self.currentBreadCrumbItem = {};
            	function buildStates (state) {
            		//console.log(state);
            		var bcStates = state.current.url.split('/');
            		var validBcStates = [];
            		for (var i= 0; i < bcStates.length; i ++) {
            			if(bcStates[i].length > 1) {
            				var stateItem = state.get(bcStates[i]);
            				if(stateItem) {
	            				var breadCrumbItem = {url: stateItem.url.replace(/^\//, "#"),displayName: stateItem.data.displayName};
	            				self.allBreadCrumbItems.push(breadCrumbItem);
            			    }
            			}
            		}
            		
            		for (var i = 0; i <self.allBreadCrumbItems.length - 1 ; i++ ) {
            			self.activeBreadCrumbItems.push(self.allBreadCrumbItems[i]);
            		}
            		self.currentBreadCrumbItem =self.allBreadCrumbItems[self.allBreadCrumbItems.length -1];
            	}
            	
                buildStates($state);
            }],
            controllerAs: 'bcCtrl',
            link: function(scope, element, attrs,controller) {
            }
         };
      });
})();