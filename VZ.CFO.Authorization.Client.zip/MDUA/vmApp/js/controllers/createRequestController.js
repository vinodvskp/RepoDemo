
(function () {

    angular.module('vmApp')
        .controller('createRequestController', ['notificationSubscriberService','confirmModalService', 'storeService', '$state', '$scope', '$q', '$log', 'serverVariableService', 'localStoreService', 'alertingService', 'mainService', 'orderByFilter', 'createRequestService','spinnerService', 'uiGridExporterConstants', 'errorHandlerService', createRequestController]);

    function createRequestController(notificationSubscriberService, confirmModalService, storeService, $state, $scope, $q, $log, serverVariableService, localStoreService, alertingService, mainService, orderByFilter, createRequestService, spinnerService, uiGridExporterConstants, errorHandlerService) {
        var self = this;
        self.displayDeltaRowCount = 0;
        self.totalDeltaRowCount = 0;
        self.tempDeltaProcessId ="";
        self.pageName = $state.current.data.displayName;
        self.showCalculateButton = true;
        self.showSubmitButton = false;
        self.requestIdAtDelta = "";
        self.requestStatusAtDelta = "";

        //todo: get request type data from service
        self.transactionHeaders = ["Target Version", "Transaction ID", "User Name", "Action", "Version", "Hierarchy", "Node", "Property", "From Value", "From Origin", "To Value", "To Origin"];
        self.transactionColumnNames = ["targetVersion", "TransactionID", "UserName", "Action", "Version", "Hierarchy", "Node", "Property", "FromValue", "FromOrigin", "ToValue", "ToOrigin"];
        self.showDeltaTable = false;
        self.sortByColName = self.transactionColumnNames[0];
        self.sortReverse = true;
        self.requestTypes = {
            'buttonLabel': 'Select Request Type',
            'items': [],
            'selectedItem': null,
            'status': { 'isopen': false },
            'required': null
        };

        self.futureVersions = {
            'buttonLabel': 'Select Future Version',
            'items': [],
            'selectedItem': null,
            'status': { 'isopen': false },
            'show': false,
            'required': null
        };
        self.enableSubmitButton = false;

        self.profile = [];
        /*
    	self.exclusions = {"required": null,"show":false};// hierachary
    	self.exclusions.leftList =[]; 
    	self.exclusions.rightList =[];
    	self.exclusions.fullList = []; */

        self.exclusions = {
            fullList: {
                name: "full list",
                items: []
            },
            leftList: {
                name: "left list",
                items: [],
                selectedItems: []
            },
            rightList: {
                name: "right list",
                items: [],
                selectedItems: []
            },
            show: false
        }

        self.transDelta = [];
        self.transView = [];
        self.inputCache = { "process": "", "futureVersion": "", "exclusions": [] };

        //todo: get delta transactions from service 
        createRequestService.getRequestTypes({}, requestTypesCallback, requestTypesErrorCallback);
        createRequestService.getProfile({}, profileCallback, profileErrorCallback);
        //createRequestService.getFutureVersions({},futureVersionsCallback, errorCallback);
        self.gridOptions = {
            columnDefs: [{ name: "Source Version", field: "sourceVersionType", width: "150", cellTooltip: true },
                         { name: "targetVersion", field: "targetVersionType", width: "250", cellTooltip: true },
                         { name: "TransactionId", field: "trasanctionId", width: "150", cellTooltip: true },
                         { name: "UserName", field: "userName", width: "150", cellTooltip: true },
                         { name: "Action", field: "action", width: "240", cellTooltip: true },
                         { name: "Hierarchy", field: "hirerachyAbbrev", width: "110", cellTooltip: true },
                         { name: "Node", field: "nodeAbbrev", width: "220", cellTooltip: true },
                         { name: "Property", field: "propertyAbbrev", width: "150", cellTooltip: true },
                         { name: "FromValue", field: "fromValue", width: "200", cellTooltip: true },
                         { name: "FromOrigin", field: "fromOrigin", width: "150", cellTooltip: true },
                         { name: "ToValue", field: "toValue", width: "150", cellTooltip: true },
                         { name: "ToOrigin", field: "toOrigin", width: "150", cellTooltip: true }],
            enableFiltering: false,
            enableSorting: true,
            showGridFooter: true,
            exporterCsvFilename: 'New_request_Delta.csv',
            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
            onRegisterApi: function (gridApi) {
                self.gridApi = gridApi;
            }
        };

        self.selectRequestType = function (item) {
            //self.exclusions.required = false;
            self.futureVersions.required = false;
            self.requestTypes.selectedItem = item;
            self.requestTypes.buttonLabel = item.requestType;
            self.requestTypes.required = null;
            self.gridOptions.data = [];
            self.showDeltaTable = false;
            if (self.requestTypes.selectedItem.requestTypeCode == 'SNAPSHOT') {
                self.showCalculateButton = false;
                self.showSubmitButton = true;
                self.enableSubmitButton = true;
                self.futureVersions.show = false;
                self.exclusions.show = false;
            }
            else {
                self.showCalculateButton = true;
                self.showSubmitButton = false;

                self.futureVersions.show = showFutureVersions(self.requestTypes.selectedItem.requestType);
                self.exclusions.show = showExclusions(self.requestTypes.selectedItem.requestType);
                if (self.futureVersions.show == true) {
                    createRequestService.getFutureVersions({}, futureVersionsCallback, futureVersionsErrorCallback);
                }
                if (self.exclusions.show && self.exclusions.fullList.items.length == 0) {
                    createRequestService.getHierarchiesByVersion({ 'version': item.versionType }, hierarchiesByVersionCallback, hierarchiesByVersionErrorCallback);
                }
                if (self.exclusions.show && self.exclusions.fullList.items.length > 0) {
                    self.exclusions.leftList.items = [];
                    self.exclusions.leftList.items.push.apply(self.exclusions.leftList.items, self.exclusions.fullList.items);
                    self.exclusions.rightList.items = [];
                }

            }
        };

        self.selectFutureVersion = function (item) {
            self.enableSubmitButton = false;
            self.futureVersions.selectedItem = item;
            self.futureVersions.buttonLabel = item.versionName + ' (' + item.application + ')';
            self.exclusions.show = showExclusions(self.requestTypes.selectedItem.requestType);
            self.futureVersions.required = null;
        }


        this.transactionSortBy = function (colName) {
            this.sortReverse = (colName !== null && this.sortByColName === colName)
 	            ? !this.sortReverse : false;
            this.sortByColName = colName;
            this.deltaTransactions = orderByFilter(this.deltaTransactions, this.sortByColName, this.sortReverse);

        };

        self.calculateDelta = function () {
            var payload = {};
            self.transView = [];
            self.transDelta = [];
            //1.todo: make a service call to retrieve transaction delta
            //2. show transactions in table - should we make the table display portion a child view?
            if (!self.requestTypes.selectedItem) {
                self.requestTypes.required = true;
                return;
            }
            var selectedRequestTypeCode = self.requestTypes.selectedItem.requestTypeCode;
            switch (selectedRequestTypeCode) {
                case "ER":
                    payload = { "process": selectedRequestTypeCode };
                    self.inputCache.process = selectedRequestTypeCode;
                    break;
                case "ERP":
                    payload = { "process": selectedRequestTypeCode };
                    self.inputCache.process = selectedRequestTypeCode;
                    break;
                case "OBP":
                    payload = { "process": selectedRequestTypeCode };
                    self.inputCache.process = selectedRequestTypeCode;
                    break;
                case "CBP":

                    var selectedExclusions = self.getSelectedExclusions();

                    /*if(selectedExclusions.length==0) {
                       self.exclusions.required = true;
                       return;
                    }*/
                    //alert("vmcr.exclusions.required"+selectedExclusions);
                    payload = { "process": selectedRequestTypeCode, "exclusions": selectedExclusions };
                    self.inputCache.process = selectedRequestTypeCode;
                    self.inputCache.exclusions = selectedExclusions;
                    break;
                case "PFR":
                    //self.exclusions.required = false;
                    if (!self.futureVersions.selectedItem) {
                        self.futureVersions.required = true;
                        return;
                        payload = { "process": selectedRequestTypeCode };
                        self.inputCache.process = selectedRequestTypeCode;
                        self.inputCache.futureVersion = "";
                    } else {
                        payload = { "process": selectedRequestTypeCode, "futureVersion": self.futureVersions.selectedItem.versionName };
                        self.inputCache.process = selectedRequestTypeCode;
                        self.inputCache.futureVersion = self.futureVersions.selectedItem.versionName;
                    }
                    break;
                default:
                    console.log("no request type selected");
            }
            self.futureVersions.required = null;
            spinnerService.show("overlaySpinner");

            createRequestService.submitGenDeltaRequest(payload, submitGenDeltaRequestCallback, errorCallback);

            //createRequestService.calculateTransDelta(payload, transDeltaCallback, transDeltaErrorCallback); //5/30/2017
            //self.exclusions.leftList = self.exclusions.fullList;
            //self.exclusions.rightList = [];
        }
        self.isDeltaStale = function (requestId) {
            if (self.requestTypes.selectedItem.requestTypeCode == "SNAPSHOT") {
                self.submitRequest();
            }
            else {
                createRequestService.isDeltaStale({ "requestIdAtDelta": requestId, "requestStatusAtDelta": self.requestStatusAtDelta }, isDeltaStaleRequestCallback, processRequestErrorCallback);
            }
        }
        self.submitRequest = function () {
            var payload = {};
            if (self.requestTypes.selectedItem.requestTypeCode == "SNAPSHOT") {
                self.inputCache.process = self.requestTypes.selectedItem.requestTypeCode;
                self.transDelta = [];
            }
            payload.process = self.inputCache.process;
            payload.futureVersion = self.inputCache.futureVersion;
            if (self.requestTypes.selectedItem.requestTypeCode == "CBP") {
                payload.exclusions = self.inputCache.exclusions;
            }
            //payload.delta = self.transDelta;
            if (self.requestTypes.selectedItem.requestTypeCode == "SNAPSHOT") {
                payload.futureVersion = "";
                payload.tempDeltaId = null;
            }
            else {
                payload.tempDeltaId = parseInt(self.tempDeltaProcessId);
            }
            //console.log(payload);

            var confirmModalInstance = confirmModalService.createConfirmModal("Are you sure you want to submit request?");
            if (confirmModalInstance) {
                confirmModalInstance.result.then(function (comments) {
                    spinnerService.show("overlaySpinner");
                    createRequestService.submitRequest(payload, submitRequestCallback, submitErrorCallback);
                }, function () {
                    //console.log('Modal dismissed at: ' + new Date());
                });
            }

        }

        self.processRequest = function (input) {
            var payload = {};
            payload.requestId = input.data.requestId + "";
            payload.eid = serverVariableService.USER_EID();
            //console.log("save payload:");
            //console.log(payload);
            //spinnerService.show("overlaySpinner");
            createRequestService.processRequest(payload, processRequestCallback, processRequestErrorCallback);
        }

        self.getSelectedExclusions = function () {
            /*
 	    	//this function is a hack for getting selectedExclusions - because there isn't a simple angular-way available to handle the drag-n-drop lists.
 	    	var selectedExclusions = [];
 	    	jQuery("#exclusionRightList > li").each(function() { selectedExclusions.push(jQuery(this).text());});
 	    	self.exclusions.rightList = selectedExclusions;
 	    	self.exclusions.leftList = jQuery(self.exclusions.fullList).not(selectedExclusions).get();
 	    	return selectedExclusions;
 	    	*/
            return self.exclusions.rightList.items;
        }

        self.downloadCSV = function () {
            //self.gridApi.exporter.csvExport(uiGridExporterConstants.VISIBLE, uiGridExporterConstants.ALL);
            self.downloadDelta();
        }

        self.downloadDelta = function () {
            createRequestService.downloadDeltaSignedKey({ "tempDeltaReqId": self.tempDeltaProcessId.toString() }, downloadDeltaSignedKeyCallback, errorCallback);
        }

        self.exclusions.isSelected = function (item, list) {
            var selected = false;
            for (var i = 0; i < list.selectedItems.length; i++) {
                if (item == list.selectedItems[i]) {
                    selected = true;
                    break;
                }
            }
            return selected;
        };

        self.exclusions.checkboxHandler = function (check, item, list) {
            //inserts unique values
            if (check)
                list.selectedItems.push(item);

            else
                list.selectedItems.splice(list.selectedItems.indexOf(item), 1);
        };

        self.exclusions.moveSelectedToRight = function () {
            self.enableSubmitButton = false;
            for (var i = 0; i < self.exclusions.leftList.selectedItems.length; i++) {
                self.exclusions.rightList.items.push(self.exclusions.leftList.selectedItems[i]);
                var item = self.exclusions.leftList.selectedItems[i];
                self.exclusions.leftList.items.splice(self.exclusions.leftList.items.indexOf(item), 1);
            }
            self.exclusions.rightList.items.sort();
            self.exclusions.leftList.selectedItems = [];

        };

        self.exclusions.moveAllToRight = function () {
            self.enableSubmitButton = false;
            for (var i = 0; i < self.exclusions.leftList.items.length; i++) {
                self.exclusions.rightList.items.push(self.exclusions.leftList.items[i]);
            }

            self.exclusions.rightList.items.sort();
            self.exclusions.leftList.selectedItems = [];
            self.exclusions.leftList.items = [];

        };

        self.exclusions.moveSelectedToLeft = function () {
            self.enableSubmitButton = false;
            for (var i = 0; i < self.exclusions.rightList.selectedItems.length; i++) {
                self.exclusions.leftList.items.push(self.exclusions.rightList.selectedItems[i]);
                var item = self.exclusions.rightList.selectedItems[i];
                self.exclusions.rightList.items.splice(self.exclusions.rightList.items.indexOf(item), 1);
            }
            self.exclusions.leftList.items.sort();
            self.exclusions.rightList.selectedItems = [];
        };

        self.exclusions.moveAllToLeft = function () {
            self.enableSubmitButton = false;
            for (var i = 0; i < self.exclusions.rightList.items.length; i++) {
                self.exclusions.leftList.items.push(self.exclusions.rightList.items[i]);
            }
            self.exclusions.leftList.items.sort();
            self.exclusions.rightList.selectedItems = [];
            self.exclusions.rightList.items = [];
        };

        self.processGenDeltaRequest = function (tempDeltaProcessId) {
            var payload = {"vmTempDeltaReqId":tempDeltaProcessId.toString()};
            //console.log(payload);
            //spinnerService.show("overlaySpinner");
            createRequestService.processGenDeltaRequest(payload, processGenDeltaRequestCallback, errorCallback);
        };

        function requestTypesCallback(response) {
            self.requestTypes.items = response.data;
        }

        function futureVersionsCallback(response) {
            self.futureVersions.items = response.data;
        }

        function futureVersionsErrorCallback(data) {
            console.log(data);
            errorHandler(data, "retrieve future versions");
        }

        function transDeltaCallback(response) {
            self.transDelta = [];
            self.transDelta.push.apply(self.transDelta, response.data.delta);
            self.requestIdAtDelta = response.data.requestIdAtDelta;
            self.requestStatusAtDelta = response.data.requestStatusAtDelta;
            self.transView = buildTransView(self.transDelta);

            self.gridOptions.data = self.transView;
            //console.log(self.transView);

            spinnerService.hide("overlaySpinner");

            if (self.transView.length > 0) {
                self.showDeltaTable = true;
                self.showSubmitButton = true;
                self.enableSubmitButton = true;
            } else {
                alertingService.addInformation("There is no data available for this request type.");
                self.showDeltaTable = false;
                self.showSubmitButton = false;
                self.enableSubmitButton = false;
            }
        }

        function transDeltaErrorCallback(data) {
            console.log(data);
            errorHandler(data, "generate transaction delta");
        }

        function createBigdataSet(row) {
            for (var i = 1; i < 350000; i++) {
                self.transView.push(JSON.parse(JSON.stringify(row)));
            }

        }

        function isDeltaStaleRequestCallback(response) {
            var resp = response;
            if (response.data == false) {
                self.submitRequest();
            }
            else {
                alertingService.addInformation("Delta is stale. Please generate again.");
            }

        }
        function submitRequestCallback(response) {
            console.log(response);
            spinnerService.hide("overlaySpinner");
            if (response.data && response.data.requestId) {
                alertingService.addSuccess("request submitted successfully.");
                self.processRequest(response);
                //alert("response.data.requestId"+response.data.requestId);
                storeService.set(response.data.requestId + "");
                $state.go("requestDetails", { requestId: response.data.requestId + "" });
            }
            else {
                alertingService.addInformation(response.data.errorMessage);
            }
        }

        function processRequestCallback(response) {
            console.log("processRequestCallback called successfully.");
            //spinnerService.hide("overlaySpinner");
            //alertingService.addSuccess("Process request completed.");
        }

        function processGenDeltaRequestCallback(response) {
            console.log("processGenDeltaRequestCallback called successfully.");
            //spinnerService.hide("overlaySpinner");
            //alertingService.addSuccess("Process request completed.");
        }
        

        function processRequestErrorCallback(data) {
            console.log(data);
            errorHandler(data, "process request");
        }

        function buildTransView(transDelta) {
            var tView = [];
            for (var i = 0; i < transDelta.length; i++) {
                if (transDelta[i].drmTransaction.length > 0) {
                    for (var k = 0; transDelta[i].drmTransaction[k]; k++) {
                        var transItem = mergeObjects({ "targetVersion": transDelta[i].targetVersion }, transDelta[i].drmTransaction[k]);
                        tView.push(transItem);
                    }
                }
            }
            return tView;
        }

        function mergeObjects(obj, src) {
            for (var key in src) {
                if (src.hasOwnProperty(key)) {
                    if (src[key] === null) {
                        obj[key] = "";
                    }
                    else {
                        obj[key] = src[key];
                    }
                }

            }
            return obj;
        }

        function requestTypesErrorCallback(data) {
            //console.log(data);
            errorHandler(data, "load request types");
        }

        function submitErrorCallback(data) {
            //console.log(data);
            errorMessageHandler(data, "submit request");
        }

        function profileCallback(response) {
            self.profile = response.data;
        }


        function profileErrorCallback(data) {
            //console.log(data);
            errorHandler(data, "load profile");
        }


        function errorHandler(data, operation) {
            spinnerService.hide("overlaySpinner");
            if (data.status == "401") {
                errorHandlerService.addError("Unauthorized to " + operation + " on " + self.pageName + " page");
                $state.go("error");
            }
            else {
                errorHandlerService.addError(data.statusText + " on " + self.pageName + " page");
            }

        }
        function errorMessageHandler(message, operation) {
            spinnerService.hide("overlaySpinner");
            alertingService.addDanger(message + " on " + self.pageName + " page");
        }
        function hierarchiesByVersionCallback(response) {
            /*self.exclusions.leftList =[];
    		self.exclusions.fullList =[];
    		self.exclusions.leftList.push.apply(self.exclusions.leftList,response.data);
    		self.exclusions.fullList.push.apply(self.exclusions.fullList,response.data);
    		*/
            self.exclusions.leftList.items.push.apply(self.exclusions.leftList.items, response.data);
            self.exclusions.fullList.items.push.apply(self.exclusions.fullList.items, response.data);
        }

        function hierarchiesByVersionErrorCallback(data) {
            //console.log(data);
            errorHandler(data, "retrieve hierarchies");
        }

        function downloadDeltaSignedKeyCallback(response) {
            var respData = response;
            console.log(serverVariableService.VM_ENDPOINT_SIGNED() + '/newRequest/downloadTempDeltaTxns?requestId=' + self.tempDeltaProcessId.toString() + '&signedToken=' + respData.data.responseObject);
            window.open(serverVariableService.VM_ENDPOINT_SIGNED() + '/newRequest/downloadTempDeltaTxns?requestId=' + self.tempDeltaProcessId.toString() + '&signedToken=' + respData.data.responseObject);
        }

        function submitGenDeltaRequestCallback(response) {
            console.log("submitGenDeltaRequestCallback:" + response.data);
            var tempDeltaProcessId = response.data.tempDeltaReqId;
            self.requestIdAtDelta = response.data.requestIdAtDelta;
            self.requestStatusAtDelta = response.data.requestStatusAtDelta;
            self.tempDeltaProcessId = tempDeltaProcessId;
            //spinnerService.hide("overlaySpinner");
            if (tempDeltaProcessId) {
                alertingService.addSuccess("Delta request submitted successfully.");
                self.processGenDeltaRequest(tempDeltaProcessId);
                //createRequestService.startDeltaStatusPolling(notifyDeltaStatus)
                if (notificationSubscriberService.isSubscribed("VM", "Create Request") == false) {
                    notificationSubscriberService.subscribe("VM", "Create Request", notifyDeltaStatus)
                }

            }
        }

        function notifyDeltaStatus() {
            if (self.tempDeltaProcessId) {
                createRequestService.genDeltaStatus({ "requestId": self.tempDeltaProcessId.toString() }, genDeltaStatusCallback, genDeltaStatusErrorCallback);
            }
        }

        function genDeltaStatusCallback(response) {
            console.log(response.data.tempDeltaStatus);
            
            if (response.data && response.data.tempDeltaStatus == "COMPLETED") {
                //spinnerService.hide("overlaySpinner");
                //alertingService.addSuccess("Delta request completed successfully.");
               
                //createRequestService.stopDeltaStatusPolling();
                notificationSubscriberService.disconnectSubscriber("VM_CreateRequest");
                createRequestService.getGenDeltaTxns({ "requestId": self.tempDeltaProcessId.toString(), "start": "0", "limit": serverVariableService.VM_DISPLAY_MAXROWCOUNT() }, getGenDeltaTxnsCallback, errorCallback);
            }
        }

        function genDeltaStatusErrorCallback(response) {
            //spinnerService.hide("overlaySpinner");
            //createRequestService.stopDeltaStatusPolling();
            //notificationSubscriberService.disconnectSubscriber("VM_CreateRequest");
            alertingService.addInformation("Error occurred while checket delta generation status.");
            
        }

        function getGenDeltaTxnsCallback(response) {
            self.transDelta = [];
            self.transDelta.push.apply(self.transDelta, response.data.results);
            self.totalDeltaRowCount = response.data.totalCount;
            self.displayDeltaRowCount = ( parseInt(self.totalDeltaRowCount)< 1000 ?self.totalDeltaRowCount : parseInt(serverVariableService.VM_DISPLAY_MAXROWCOUNT())  );
            //self.requestIdAtDelta = response.data.requestIdAtDelta;
            //self.requestStatusAtDelta = response.data.requestStatusAtDelta;
            self.transView = self.transDelta; //buildTransView(self.transDelta);

            self.gridOptions.data = self.transView;
            //console.log(self.transView);

            spinnerService.hide("overlaySpinner");

            if (self.transView.length > 0) {
                self.showDeltaTable = true;
                self.showSubmitButton = true;
                self.enableSubmitButton = true;
            } else {
                alertingService.addInformation("There is no data available for this request type.");
                self.showDeltaTable = false;
                self.showSubmitButton = false;
                self.enableSubmitButton = false;
            }
        }

        function errorCallback(data) {
            self.loading = true;
            console.log(data);
            spinnerService.hide("overlaySpinner");
        }

        function showFutureVersions(selectedRequestType) {
            var canShow;
            if (selectedRequestType == "Future") {
                canShow = true;
            }
            else {
                canShow = false;
            }
            return canShow;
        }


        function showExclusions(selectedRequestType) {
            var canShow;
            if (selectedRequestType == "Close Blackout Period") {
                canShow = true
            }
            else {
                canShow = false;
            }

            return canShow;
        }

    }

}());