(function () {

    angular.module('vmApp')
    .controller('mainController', ['$state', '$scope', 'constantService', 'serverVariableService', 'mainService', 'localStoreService', 'alertingService', 'userProfileService', 'userRoleService', mainController]);

    function mainController($state, $scope, constantService, serverVariableService, mainService, localStoreService, alertingService, userProfileService, userRoleService) {

        $scope.bigDeviceSiteName = constantService.APP_DESCRIPTION;
        $scope.smallDeviceSiteName = constantService.APP_TITLE;
        $scope.menuUrl = serverVariableService.SITE_SUBFOLDER() + "images/menu/";
        $scope.siteSubfolder = serverVariableService.SITE_SUBFOLDER();
        $scope.menuViewUrl = serverVariableService.SITE_SUBFOLDER() + "common/templates/menuView.html";
        $scope.userProfileMenuViewUrl = serverVariableService.SITE_SUBFOLDER() + "common/templates/userProfileMenuView.html";
        
        
        


        //callbacks
        
        function errorCallback(response) {
            alertingService.addDanger('Error loading main controller values');
        }

    }
}());