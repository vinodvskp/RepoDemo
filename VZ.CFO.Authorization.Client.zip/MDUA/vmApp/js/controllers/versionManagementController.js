﻿(function (module) {
    function versionManagementController(userRoleService, userMenuService, serverVariableService, $state, createRequestService, requestTrackingService, notificationSubscriberService, spinnerService, errorHandlerService, $interval) {
        var self = this;
        self.profile = [];
        self.recentActivity = [];
        self.pageName = "Dash Board";
        self.site_subfolder = serverVariableService.SITE_SUBFOLDER();
        self.trackingLayoutClass ={};
        self.showActions = true;
        self.showTracking = false;
        self.showCreateRequest = false;
        self.profileLayout = { "pull-right": true };

        switch(userRoleService.getUserVersionManagementRole())
        {
        	case userRoleService.VM_ROLE.EDIT:
        		self.showTracking = self.showCreateRequest = true;
        		break;
        	case userRoleService.VM_ROLE.TRACKING:
        		self.showTracking = true;
        		self.trackingLayoutClass = {"col-md-offset-6":true};
        		break;
        	case userRoleService.VM_ROLE.READ:
        		self.showTracking = self.showCreateRequest = self.showActions = false;
        		 self.profileLayout = {"pull-left":true};
        		break;
        	default:       		
        	
        }

        createRequestService.getProfile({},profileCallback, profileErrorCallback);
        requestTrackingService.getRecentActivity({},recentActivityCallback,recentActivityErrorCallback);
        
        if (notificationSubscriberService.isSubscribed("VM", "Dashboard") == false) {
        	notificationSubscriberService.subscribe("VM","Dashboard", notificationCallback)
        }

        function profileErrorCallback(data) {
        	errorHandler(data, "profile");
    	}	
    	
    	function profileCallback(response) {
    		self.profile = response.data;
    	}
    	
    	function recentActivityCallback(response) {
    	    self.recentActivity = response.data;
    	}
    	
    	function recentActivityErrorCallback(data) {
    		errorHandler(data, "recent activities");
     	}
    	
    	function notificationCallback(messages) {    	    
    	    var date = new Date();    	    
    	    var time = date.toLocaleTimeString();
    	    console.log('notification call back' + ' ' + time);
    	    requestTrackingService.getRecentActivity({},recentActivityCallback,errorCallback);
    	}	
    	
    	function errorHandler(data, operation) {
    		if (data.status =="401") {
    			errorHandlerService.addError("Unauthorized to " + operation + " on " + self.pageName + " page");
    			$state.go("error");
    		}
    		else {
    			errorHandlerService.addError(data.statusText + " on " + self.pageName + " page");
    		}
    		
    	}
    	
    	function errorCallback(response) {
    		
    	}
    };

    module.controller('versionManagementController', ['userRoleService','userMenuService','serverVariableService','$state','createRequestService','requestTrackingService', 'notificationSubscriberService','spinnerService','errorHandlerService', '$interval', versionManagementController]);
}(angular.module("vmApp")));
