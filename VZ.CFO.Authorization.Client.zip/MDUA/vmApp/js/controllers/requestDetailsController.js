
(function () {

    angular.module('vmApp')
        .controller('requestDetailsController', ['$filter', '$scope', '$q', '$log', 'serverVariableService', 'localStoreService', 'alertingService', 'mainService', 'orderByFilter', '$stateParams','requestDetailsService', 'spinnerService', 'storeService', 'uiGridExporterConstants', 'notificationSubscriberService', requestDetailsController]);

    function requestDetailsController($filter, $scope, $q, $log, serverVariableService, localStoreService, alertingService, mainService, orderByFilter, $stateParams, requestDetailsService, spinnerService, storeService, uiGridExporterConstants, notificationSubscriberService) {
        var self = this;
        self.displayDeltaRowCount = 0;
        self.totalDeltaRowCount = 0;
        self.loading = false;
        self.showActionScriptDownload = false;
        //todo: get request detail from service with a request id
        this.transactionHeaders = ["Transaction ID", "User Name", "Action", "Version", "Hierarchy", "Node", "Property", "From Value", "From Origin", "To Value", "To Origin"];
        this.transactionColumnNames = ["TransactionID", "UserName", "Action", "Version", "Hierarchy", "Node", "Property", "FromValue", "FromOrigin", "ToValue", "ToOrigin"];
        this.sortByColName = this.transactionColumnNames[0];
        this.sortReverse = true;
        //todo: get request detail from service with a request id
        this.requestStatusIcon = "";
        this.transactionSortBy = function (colName) {
            this.sortReverse = (colName !== null && this.sortByColName === colName)
 	            ? !this.sortReverse : false;
            this.sortByColName = colName;
            this.deltaTransactions = orderByFilter(this.deltaTransactions, this.sortByColName, this.sortReverse);

        };

        self.gridOptions = {
            columnDefs: [{ name: "TransactionId", field: "delatId", width: "150" },
			                  { name: "UserName", field: "userName", width: "130" },
			                  { name: "Action", field: "action", width: "240" },
			                  { name: "Version", field: "versionAbbrev", width: "150" },
			                  { name: "Hierarchy", field: "hirerachyAbbrev", width: "110" },
			                  { name: "Node", field: "nodeAbbrev", width: "220" },
			                  { name: "Property", field: "propertyAbbrev", width: "150" },
			                  { name: "FromValue", field: "fromValue", width: "200" },
			                  { name: "FromOrigin", field: "fromOrigin", width: "150" },
			                  { name: "ToValue", field: "toValue", width: "150" },
			                  { name: "ToOrigin", field: "toOrigin", width: "150" }],

            enableFiltering: false,
            enableSorting: false,
            showGridFooter: true,
            enableGridMenu: false,
            enableSelectAll: true,
            exporterCsvFilename: 'Request Details.csv',

            exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
            onRegisterApi: function (gridApi) {
                self.gridApi = gridApi;
            }
        };

        self.downloadCSV = function () {
           //self.gridApi.exporter.csvExport(uiGridExporterConstants.VISIBLE, uiGridExporterConstants.ALL);
            self.downloadDelta();
        }

        self.exportRequestLog = function () {
            var blob = new Blob([document.getElementById('exportable').innerHTML], {
                type: "application/vnd.ms-excel;charset=utf-8"
            });
            saveAs(blob, "Report.xls");
        }

        self.downloadRequestlog = function () {
            requestDetailsService.downloadRequestLogs({ 'requestId': requestId }, downloadLogsCallback, errorCallback);
        }

        self.downloadDelta = function () {
            requestDetailsService.downloadDeltaSignedKey({ "tempDeltaReqId": requestId}, downloadDeltaSignedKeyCallback, errorCallback);
        }

        self.requestDetails = { 'items': [] };
        self.deltaListDetails = { 'items': [] };
        self.requestLogs = { 'items': [] };
        requestId = storeService.get();
        requestDetailsService.getRequestDetails({ 'requestId': requestId }, requestDetailsCallback, errorCallback);
        requestDetailsService.getDeltaList({ 'requestId': requestId, "start": "0", "end": serverVariableService.VM_DISPLAY_MAXROWCOUNT() }, deltaListCallback, errorCallback);
        requestDetailsService.getRequestLogs({ 'requestId': requestId }, requestLogsCallback, errorCallback);

        if (notificationSubscriberService.isSubscribed("VM", "Request Details") == false) {
            notificationSubscriberService.subscribe("VM", "Request Details", notificationCallback)
        }


        function requestDetailsCallback(response) {
            self.requestDetails.items = response.data;
            self.requestStatusIcon = getRequestStatusIcon(self.requestDetails.items.requestStatus);
            self.showActionScriptDownload = showActionScript(response.data);
        }

        function getRequestStatusIcon(requestStatus) {
            var iconClasses = "";
            switch (requestStatus) {
                case 'COMPLETED':
                    iconClasses = { 'fa': true, 'fa-check': true, 'fa-lg': true, 'requestCompleted': true };
                    break;
                case 'COMPLETED WITH WARNINGS':
                    iconClasses = { 'fa': true, 'fa-exclamation-triangle': true, 'fa-lg': true, 'requestCompletedWithWarnings': true };
                    break;
                case 'FAILED':
                    iconClasses = { 'fa': true, 'fa-exclamation': true, 'fa-lg': true, 'requestFailed': true };
                    break;
                case 'CANCELLED':
                    iconClasses = { 'fa': true, 'fa-times': true, 'fa-lg': true, 'requestCancelled': true };
                    break;
                case 'PROCESSING':
                    iconClasses = { 'fa': true, 'fa-refresh': true, 'fa-spin': true, 'fa-lg': true, 'requestProcessing': true };
                    break;
                case 'REPROCESSING':
                    iconClasses = { 'fa': true, 'fa-refresh': true, 'fa-spin': true, 'fa-lg': true, 'requestProcessing': true };
                    break;
                case 'SUBMITTED':
                    iconClasses = { 'fa': true, 'fa-file-text': true, 'fa-lg': true, 'requestSubmitted': true };
                    break;
                default:
            }
            return iconClasses;
        }

        function deltaListCallback(response) {
            self.deltaListDetails.items = response.data.results;
            self.totalDeltaRowCount = response.data.totalCount;
            self.displayDeltaRowCount = (parseInt(self.totalDeltaRowCount) < 1000 ? self.totalDeltaRowCount : parseInt(serverVariableService.VM_DISPLAY_MAXROWCOUNT()) );
            self.gridOptions.data = self.deltaListDetails.items;
            if (self.requestDetails.items.requestTypeCode == 'SNAPSHOT') {
                self.dataMessage = "N/A";
            }
            else if (self.gridOptions.data.length == 0) {
                self.dataMessage = "No data"
            }
            self.loading = true;
        }
        function errorCallback(data) {
            self.loading = true;
            console.log(data);
            spinnerService.hide("overlaySpinner");
        }

        function requestLogsCallback(response) {
            self.requestLogs.items = response.data;
        }

        function notificationCallback(message) {
            if (serverVariableService.NOTIFICATION_TYPE() == 'poll') {
                var date = new Date();
                var time = date.toLocaleTimeString();
                console.log('notification call back' + ' ' + time);
                requestDetailsService.getRequestLogs({ 'requestId': requestId }, requestLogsCallback, errorCallback);
                requestDetailsService.getRequestDetails({ 'requestId': requestId }, requestDetailsCallback, errorCallback);
            }
            else {
                if (message && message.ApplicationName == "VM" && message.ApplicationModuleName == "Request Details" && message.ChangeContext == requestId) {
                    requestDetailsService.getRequestLogs({ 'requestId': requestId }, requestLogsCallback, errorCallback);
                    requestDetailsService.getRequestDetails({ 'requestId': requestId }, requestDetailsCallback, errorCallback);
                }
            }
        }

        function downloadLogsCallback(data) {
            var htmlTable = buildDownableTable(data);
            var blob = new Blob([htmlTable], {
                type: "application/vnd.ms-excel;charset=utf-8"
            });
            saveAs(blob, "actionscript_report.xls");

        }

        function buildDownableTable(data) {
            var htmlTable = "";
            htmlTable = "<table border='1'>";
            htmlTable += "<tr>";
            htmlTable += "<td style='margin-right:10px;'>action_Script</td>";
            htmlTable += "<td style='margin-right:10px;'>source_Version_Nm</td>";
            htmlTable += "<td style='margin-right:10px;'>source_Version_Type</td>";
            htmlTable += "<td style='margin-right:10px;'>target_Version_Nm</td>";
            htmlTable += "<td style='margin-right:10px;'>target_Version_Type</td>";
            htmlTable += "<td style='margin-right:10px;'>error_Log</td>";
            htmlTable += "</tr>";
            for (var i = 0; i < data.length; i++) {
                htmlTable += "<tr>";
                //htmlTable += "<td style='margin-right:10px;'>" +  $filter('date')(data[i].creationDate, "dd/MM/yyyy") + "</td>";
                htmlTable += "<td style='margin-right:10px;'>" + ((data[i].action_Script == null) ? ' ' : data[i].action_Script) + "</td>";
                htmlTable += "<td style='margin-right:10px;'>" + ((data[i].source_Version_Nm == null) ? ' ' : data[i].source_Version_Nm) + "</td>";
                htmlTable += "<td style='margin-right:10px;'>" + ((data[i].source_Version_Type == null) ? ' ' : data[i].source_Version_Type) + "</td>";
                htmlTable += "<td style='margin-right:10px;'>" + ((data[i].target_Version_Nm == null) ? ' ' : data[i].target_Version_Nm) + "</td>";
                htmlTable += "<td style='margin-right:10px;'>" + ((data[i].target_Version_Type == null) ? ' ' : data[i].target_Version_Type) + "</td>";
                htmlTable += "<td style='margin-right:10px;'>" + ((data[i].error_Log == null) ? ' ' : data[i].error_Log) + "</td>";
                htmlTable += "</tr>";
            }
            htmlTable += '</table>';
            return htmlTable;
        }

        function buildLogsTable(data) {
            var htmlTable = "";
            htmlTable = "<table>";

            for (var i = 0; i < data.length; i++) {
                htmlTable += "<tr>";
                htmlTable += "<td style='padding: 3px;'>" + ((data[i].auditLogId == null) ? ' ' : data[i].auditLogId) + "</td>";
                htmlTable += "<td style='padding: 3px;'>" + $filter('date')(data[i].creationDate, "MM/dd/yyyy") + "</td>";
                htmlTable += "<th style='padding: 3px;'>" + ((data[i].request_log == null) ? ' ' : data[i].request_log) + "</th>";
                htmlTable += "</tr>";
            }
            htmlTable += '</table>';
            return htmlTable;
        }

        function downloadDeltaSignedKeyCallback(response) {
            var respData = response;
            console.log(serverVariableService.VM_ENDPOINT_SIGNED() + '/requestDetails/downloadVMDeltaTxns?requestId=' + requestId + '&signedToken=' + respData.data.responseObject);
            window.open(serverVariableService.VM_ENDPOINT_SIGNED() + '/requestDetails/downloadVMDeltaTxns?requestId=' + requestId + '&signedToken=' + respData.data.responseObject);
        }

        function showActionScript(requestDetail) {
            var showable = false;
            if (requestDetail) {
                if ((requestDetail.requestStatus == 'COMPLETED' || requestDetail.requestStatus == 'FAILED' || requestDetail.requestStatus == 'COMPLETED WITH WARNINGS') && requestDetail.requestType != 'SNAPSHOT') {
                    showable = true;
                }
            }
            return showable;
        }

    }

    angular.module('vmApp')
    .filter('hierPartialDisplay', function () {
        return function (hiers) {
            var displayString = "";
            if (hiers) {
                var pattern = /\[|\]/g;
                var hiersRemovedBracket = hiers.replace(pattern, function replacer(match) {
                    return "";
                });
                var arrHiers = hiersRemovedBracket.split(",");
                if (arrHiers.length > 2) {
                    displayString = "[" + arrHiers[0] + "," + arrHiers[1] + ", ...]"
                }
                else {
                    displayString = hiers;
                }
            }
            return displayString;
        }
    })

}());