(function (module) {
    module.controller('homeController', ['$scope', '$sce', 'serverVariableService', 'tinymceService', 'mainService', 'alertingService', 'localStoreService', homeController]);

    const ADMIN_ID = 9;

    function homeController($scope, $sce, serverVariableService, tinymceService, mainService, alertingService, localStoreService) {
        var self = this;
        self.site_subfolder = serverVariableService.SITE_SUBFOLDER();

        let eid = localStoreService.getEmpEid();

        $scope.is_edit = false;
        tinymceService.getContent({eid: eid}).then(function (response) {
            let vm = response.data;
            $scope.tinymceContent = $sce.trustAsHtml(!vm.Content ? '' : vm.Content);
        }).then(function(response) {
            mainService.getLdapService([], function (response) {
                                                        $scope.is_admin = response.data.UserRole === ADMIN_ID;
                                                        tinymce_init(tinymceService.getAdminControl());
                                                    },
                                           function (err) { alertingService.addDanger(err); });
        })
        
        $scope.$on('$viewContentLoaded', function () {
        });

        $scope.$on('$destroy', function () {
            tinymce.remove();
        });

        $scope.save = function () {
            tinymceService.saveContent(eid, tinymce.activeEditor.getContent()).then(function (response) {
                turn_on_edit($scope, false, tinymceService.getAdminControl(false));
                alertingService.addSuccess("Home page content was successfully saved.");
            }).catch(function (err) {
                alertingService.addDanger(err);
            });
        };

        $scope.edit = function () {
            turn_on_edit($scope, true, tinymceService.getAdminControl(true));
        }
    }

    function turn_on_edit(scope, flag, control) {
        scope.is_edit = flag;
        tinymce.remove();
        tinymce_init(control);
    }

    function tinymce_init(control) {
        tinymce.init({
            selector: 'div#home-message',
            theme: 'modern',
            height: "260",
            inline: true, 
            plugins: control.plugins,
            toolbar1: control.toolbar1,
            toolbar2: control.toolbar2,
            readonly: control.readonly,
            branding: false,
            image_advtab: true,
            content_css: [
           //   '//www.tinymce.com/css/codepen.min.css'
            ]
        });
    }
}(angular.module("vmApp")));