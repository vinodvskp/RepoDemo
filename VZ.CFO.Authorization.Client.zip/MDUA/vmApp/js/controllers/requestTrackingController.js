﻿(function () {
    angular.module('vmApp')
    .controller('requestTrackingController', ['userRoleService', '$scope', '$q', '$log', 'serverVariableService', 'localStoreService', 'alertingService', 'mainService', 'orderByFilter', 'requestTrackingService', 'spinnerService', '$state', 'storeService', 'errorHandlerService', 'confirmModalService', requestTrackingController]);

    function requestTrackingController(userRoleService, $scope, $q, $log, serverVariableService, localStoreService, alertingService, mainService, orderByFilter, requestTrackingService, spinnerService, $state, storeService, errorHandlerService, confirmModalService) {
        var vm = this;


        vm.pageName = "Request Tracking";
        vm.requestTypes = {
            'buttonLabel': 'Select an option',
            'items': [],
            'selectedItem': null,
            'status': { 'isopen': false },
            'required': null
        };

        vm.requests = { 'results': [] };

        function rowTemplate() {
            return '<div ng-dblclick="grid.appScope.rowDblClick(row)" >' +
              '  <div ng-repeat="(colRenderIndex, col) in colContainer.renderedColumns track by col.colDef.name" class="ui-grid-cell" ng-class="{ \'ui-grid-row-header-cell\': col.isRowHeader }"  ui-grid-cell></div>' +
              '</div>';
        }

        $scope.rowDblClick = function (row) {
            vm.requestDetails(row.entity.requestId);
        };

        $scope.retryRequest = function (row) {
            var confirmModalInstance = confirmModalService.createConfirmModal("Are you sure you want to retry request " + row.entity.requestId.toString() + "?");
            if (confirmModalInstance) {
                confirmModalInstance.result.then(function (confirm) {
                    requestTrackingService.retryRequest({ "eid": serverVariableService.USER_EID(), "requestId": row.entity.requestId.toString() }, retryRequestCallback, errorCallback);
                    vm.requestDetails(row.entity.requestId);
                }, function () {
                    //console.log('Modal dismissed at: ' + new Date());
                });
            }
        };

        $scope.completeRequest = function (row) {
            var confirmModalInstance = confirmModalService.createConfirmModal("Are you sure you want to mark request " + row.entity.requestId.toString() + " as completed?", true);
            if (confirmModalInstance) {
                confirmModalInstance.result.then(function (comments) {
                    requestTrackingService.completeRequest({ "requestId": row.entity.requestId.toString(), "comments": comments }, retryRequestCallback, errorCallback);
                    vm.requestDetails(row.entity.requestId);
                }, function () {
                    //console.log('Modal dismissed at: ' + new Date());
                });
            }
        };

        $scope.cancelRequest = function (row) {
            var confirmModalInstance = confirmModalService.createConfirmModal("Are you sure you want to cancel request " + row.entity.requestId.toString() + "?");
            if (confirmModalInstance) {
                confirmModalInstance.result.then(function (confirm) {
                    requestTrackingService.cancelRequest({ "requestId": row.entity.requestId.toString() }, retryRequestCallback, errorCallback);
                    vm.requestDetails(row.entity.requestId);
                }, function () {
                    //console.log('Modal dismissed at: ' + new Date());
                });
            }
        };

        var gridColumnDefs = [{ name: "RequestId", field: "requestId", type: "number", enableCellEdit: false, cellTemplate: '<div class="grid-action-cell" style="padding: 10px;"><a ng-click="grid.appScope.rowDblClick(row)">{{row.entity.requestId}}</a></div>' },
             			      { name: "RequestType", field: "requestType", enableCellEdit: false, },
            			      { name: "Exclusions", field: "hierarchyExclusions", enableCellEdit: false, cellTooltip: true },
            			      { name: "RequestedBy", field: "createdBy", enableCellEdit: false },
            			      { name: "CreationDate", field: "creationDate", enableCellEdit: false, type: "date", cellFilter: "date:'MM/dd/yyyy, HH:mm'" },
            			      { name: "Status", field: "requestStatus", enableCellEdit: false, cellTemplate: '<div class="ui-grid-cell-contents" style="padding-top:4px;" title="{{row.entity.requestStatus}}"><i aria-hidden="true" ng-class="row.entity.iconClasses"></i></div>' }];
        if (userRoleService.getUserVersionManagementRole() == userRoleService.VM_ROLE.EDIT) {
            var actioncolumn = { name: "Action", field: "enableActions", enableCellEdit: false, cellTemplate: '<div ng-show="row.entity.enableActions==true" class="grid-action-cell" style="padding-top:4px;"><button  class="btn btn-success btn-circle" data-toggle="tooltip" data-placement="left" title="Retry request" style="padding:0px;height:20px;width:20px;min-height:20px;" ng-click="grid.appScope.retryRequest(row)"><i class="fa fa-repeat" aria-hidden="true"></i></button><button class="btn btn-info btn-circle" data-toggle="tooltip" data-placement="left" title="Mark as complete" style="padding:0px;height:20px;width:20px;min-height:20px;" ng-click="grid.appScope.completeRequest(row)"><i class="glyphicon glyphicon-ok" aria-hidden="true"></i></button><button class="btn btn-danger btn-circle" data-toggle="tooltip" data-placement="left" title="Cancel request" style="padding:0px;height:20px;width:20px;min-height:20px;" ng-click="grid.appScope.cancelRequest(row)"><i class="fa fa-ban" aria-hidden="true"></i></button></div>' };
            gridColumnDefs.push(actioncolumn);
        }
        gridColumnDefs.push({ name: "Comments", field: "comments", enableCellEdit: false, cellTooltip: true });

        vm.gridOptions = {
            rowTemplate: rowTemplate(),
            enableRowSelection: true,
            rowSelection: true,
            allowCellFocus: true,
            enableColumnMenus: false,
            columnDefs: gridColumnDefs,
            minRowsToShow: 14,
            enableFiltering: false,
            enableSorting: true,
            showGridFooter: true
        };

        vm.gridOptions.multiSelect = false;



        vm.gridOptions.onRegisterApi = function (gridApi) {
            vm.gridApi = gridApi;
            vm.gridApi.grid.registerRowsProcessor(vm.createStatusIcon, 200);
        }

        vm.createStatusIcon = function (renderableRows) {

            renderableRows.forEach(function (row) {
                var iconClasses = "";
                switch (row.entity.requestStatus) {
                    case 'COMPLETED':
                        iconClasses = { 'fa': true, 'fa-check': true, 'fa-lg': true, 'requestCompleted': true };
                        break;
                    case 'COMPLETED WITH WARNINGS':
                        iconClasses = { 'fa': true, 'fa-exclamation-triangle': true, 'fa-lg': true, 'requestCompletedWithWarnings': true };
                        break;
                    case 'FAILED':
                        iconClasses = { 'fa': true, 'fa-exclamation': true, 'fa-lg': true, 'requestFailed': true };
                        break;
                    case 'CANCELLED':
                        iconClasses = { 'fa': true, 'fa-times': true, 'fa-lg': true, 'requestCancelled': true };
                        break;
                    case 'PROCESSING':
                        iconClasses = { 'fa': true, 'fa-refresh': true, 'fa-spin': true, 'fa-lg': true, 'requestProcessing': true };
                        break;
                    case 'REPROCESSING':
                        iconClasses = { 'fa': true, 'fa-refresh': true, 'fa-spin': true, 'fa-lg': true, 'requestProcessing': true };
                        break;
                    case 'SUBMITTED':
                        iconClasses = { 'fa': true, 'fa-file-text': true, 'fa-lg': true, 'requestSubmitted': true };
                        break;
                    default:
                }
                row.entity.iconClasses = iconClasses;
            });
            return renderableRows;
        }

        vm.selectRequestType = function (item) {
            vm.requestTypes.selectedItem = item;
            vm.requestTypes.buttonLabel = item.requestType;
            vm.requestTypes.required = null;
            requestTrackingService.getRequests({ 'requestType': item.requestTypeCode }, requestsCallback, errorCallback);
        };

        vm.requestDetails = function (requestId) {
            storeService.set(requestId);
            $state.go("requestDetails", { requestId: requestId });
        };

        requestTrackingService.getRequestTypes({}, requestTypesCallback, errorCallback);


        function requestTypesCallback(response) {
            vm.requestTypes.items = response.data;
            vm.requestTypes.items.unshift({ requestType: "ALL", requestTypeCode: "ALL" });
            spinnerService.show("overlaySpinner");
            requestTrackingService.getRequests({ 'requestType': "ALL" }, requestsCallback, errorCallback);

        }
        function requestsCallback(response) {
            spinnerService.hide("overlaySpinner");
            vm.requests.results = response.data;

            vm.gridOptions.data = vm.requests.results;
        }

        function retryRequestCallback(response) {
            //do nothing
        }

        function errorCallback(data) {
            spinnerService.hide("overlaySpinner");
            if (data.status == "401") {
                errorHandlerService.addError("Unauthorized to run services on " + self.pageName + " page");
                $state.go("error");
            }
            else {
                errorHandlerService.addError(data.statusText + " on " + vm.pageName + " page");
            }

        }



        //We can call service from the server
        //End
    };

}());
