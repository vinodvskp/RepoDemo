﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO;
using System.Web.UI.WebControls;
using MDUA.BusinessLogic;
using MDUA.DataAccess;
using MDUA.DTO;
using System.Collections.Generic;

/* jevans: this new page was created for the HAPI project to replace UserInputUpload, and IT IS NEVER USED */ 
public partial class OpsUploadInputFile : System.Web.UI.Page
{
    public delegate string DetermineMsgText(BasicOraReader Rdr);
    private List<MasterDimension> dimensions = null;

    protected void Page_Load(object sender, EventArgs e)
    {
        Master.PageTitle = "Input File Upload";
        Master.NavInstructionsVisible = true;
        if (IsPostBack == false)
        {
            WebSettings Settings = Utils.LoadWebSetting(Master.curUser.EmployeeID);
            // jevans 5/23/2012 - if web settings is null, database is not available.
            if (Settings == null)
            {
                Master.Message = "MDUA could not load web settings from the database, and cannot continue.  <P>" + HypMDUA.ERROR_MESSAGE;
                return;
            }
            BasicOraReader Rdr = new BasicOraReader(DbAccess.GetOracleConnectionString());
            if (Rdr.Open("Select Alias from Web_dimensions_tbl where dim_type='YEARS' and not Alias is null Order by Alias"))
            {
                while (Rdr.oraRdr.Read())
                    ddlYears.Items.Add(Rdr.oraRdr.GetString(0));
                Rdr.Close();
            }
            Rdr.Dispose();

            if (Settings.UserFeedEnabled == false)
            {
                Master.PendingMessage = "User File Uploads have been Disabled.  Check with the Financial Team to find out when they will be available.";
                Server.Transfer("~/Default.aspx");
                return;
            }

            ddlMonths.SelectedValue = Settings.CurrentMonthInt.ToString();
            ddlYears.SelectedValue = Settings.CurrentYear;
            ddlMonths.Enabled = Master.curUser.CanPostToAnyPeriod || Master.curUser.Role == UserRole.Admin;
            ddlYears.Enabled = Master.curUser.CanPostToAnyPeriod;

            //  Populate the file types.  If they don't have any file types that they can upload,
            //  redirect them to the status page and tell them they don't have access.
            if (PopulateFileTypes() == false)
                return;
        }

        //  If the File Type was passed in as a parameter, process the file using the 
        //  information passed in.  The information would be passed in if the user 
        //  selected a legacy file from the new File Upload page.  The requests will come
        //  from OpsUploadInputFile.aspx.  We only need to check the query strings if this
        //  is not a post back.  If it is a post back, we should have already processed these.
        if (IsPostBack == false &&
            Request.QueryString["FILE_TYPE"] != null && Request.QueryString["FILE_TYPE"].Length > 0)
        {
            ddlFileType.SelectedValue = Request.QueryString["FILE_TYPE"];
            ddlMonths.SelectedValue = Request.QueryString["MONTH"];
            ddlYears.SelectedValue = Request.QueryString["YEAR"];
            string fn = Request.QueryString["FN"];
            ProcessUploadFile(fn);
            return;
        }
    }
  
    protected bool PopulateFileTypes() {
        //  Get a list of File types that this user can upload
        List<FileType> fileTypes = Utils.GetFileTypes(Master.curUser.EmployeeID);

        //  If this user doesn't have any file types that they can upload,
        //  Go back to the default page.
        if (fileTypes == null) {
            Master.Message = HypMDUA.ERROR_MESSAGE;
            return false;
        }

        if (fileTypes.Count == 0) {
            Master.PendingMessage = "You don't have access to upload files for this file type";
            Server.Transfer("~/Default.aspx");
            return false;
        }

        ddlFileType.Items.Clear();
        foreach (FileType fileType in fileTypes) {
            ddlFileType.Items.Add(new ListItem(string.Format("{0} ({1})", fileType.Description, fileType.FileTypeCode),fileType.FileTypeCode));
        }

        //  If there are items, put in a default item so that they don't accidentally
        //  upload to the first file type because they forgot to change the file type.
        ddlFileType.Items.Insert(0, new ListItem("Select Input File Type...", ""));
        return true;
    }

    protected void btnUpload_Click(object sender, EventArgs e) {
        btnDownload.Visible = false;
        Master.Message = "";
        litPopupMsg.Text = "";
        tblErrs.Visible = false;

        WebSettings Settings = Utils.LoadWebSetting(Master.curUser.EmployeeID);
        // jevans 5/23/2012 - if web settings is null, database is not available.
        if (Settings == null) {
            Master.Message = "MDUA could not load web settings from the database, and cannot continue.  <P>" + HypMDUA.ERROR_MESSAGE;
            return;
        }

        if (!Settings.UserFeedEnabled) {
            Master.Message = "User Input File Uploads have been Disabled.  Check with the Financial Team to find out when they will be available.";
            return;
        }

        //  Make sure that they picked a file type and selected a file.
        if (ddlFileType.SelectedValue == "") {
            Master.Message = "You must select an Input File Type first";
            return;
        }

        if (!fuUserFile.HasFile) {
            Master.Message = "You must select a File to upload.";
            return;
        }

        // jevans 11/22/2010 - add 2007 extension 
        string path = Path.GetExtension(fuUserFile.FileName).ToLower();
        if (!path.Equals(".xls") && !path.Equals(".xlsx")) {
            Master.Message = "The file must be an Excel file with a .xls or .xlsx extension";
            return;
        }

        int Cnt = tblErrs.Rows[0].Cells.Count;
        tblErrs.Rows[0].Cells[Cnt - 2].Visible = false;
        tblErrs.Rows[0].Cells[Cnt - 1].Visible = false;

        //  Now get the file type information so that we can see if this is a legacy file.
        FileType hft = Utils.GetFileType(ddlFileType.SelectedValue, Master.curUser.EmployeeID);

        //  Save the file now in case this is a Legacy Request.
        string Filename = "";
        try {
            //  Upload the file and load the data based on the extension of the file.
            string destinationDirectory = string.Format("Archive/{0}{1}", DateTime.Now.Year, DateTime.Now.Month);
            destinationDirectory = Server.MapPath(destinationDirectory);
            if (!Directory.Exists(destinationDirectory))
                Directory.CreateDirectory(destinationDirectory);

            DateTime currentTime = DateTime.Now;
            Filename = destinationDirectory + string.Format("\\{0}-{1}-{2}{3}",
                Master.curUser.UserId,
                hft.FileTypeCode,
                currentTime.ToString("yyyyMMdd_HHmmss"),
                Path.GetExtension(fuUserFile.FileName));
            fuUserFile.SaveAs(Filename);
            hfFileName.Value = Filename;
        } catch (Exception exFile) {
            if (Filename.Length > 0) {
                Utils.DeleteFile(Filename, Master.curUser.EmployeeID);
            }
            GeneralDatabaseAccess.LogEvent(Master.curUser.EmployeeID, "OpsUploadInputFile.aspx", "btnUpload_Click", exFile, UserToolLogLevel.Error);
            Master.Message = HypMDUA.ERROR_MESSAGE;
            return;
        }
        //  If this is a Legacy File Type, then send the request over to the Legacy File Upload Process.
        //  jevnas 12/15/2010 processing of the adjustmen data to the CPGA FACT TBL
        if (hft.DestinationTable.StartsWith("RPT_") 
            || hft.FactTableId == (int)FactTable.LocationUser
            || hft.FactTableId == (int)FactTable.EquipmentUser
            || hft.FactTableId == (int)FactTable.DataWarehouseUser
            ) {
            string XferCmd = string.Format("~/UserInputUpload.aspx?FILE_TYPE={0}&MONTH={1}&YEAR={2}&FN={3}",
                hft.FileTypeCode, ddlMonths.SelectedValue, ddlYears.SelectedValue, Filename);
            //XferCmd = Server.UrlEncode(XferCmd);
            Server.Transfer(XferCmd);
            return;
        }

        ProcessUploadFile(Filename);
    }

    protected void ProcessUploadFile(string filename)
    {
        //  Now get the file type information so that we can see if this is a legacy file.
        FileType fileType = Utils.GetFileType(ddlFileType.SelectedValue, Master.curUser.EmployeeID);

        string ClosePeriod = ddlYears.SelectedValue;
        if (ddlMonths.SelectedValue.Length == 1)
            ClosePeriod += "0";
        ClosePeriod += ddlMonths.SelectedValue;

        //  Check to see if someone else is running a process that we should be waiting for.
        string ErrMsg;
        int myRunId = Utils.LockFileType(fileType.FileTypeCode, ClosePeriod, Master.curUser.UserId, Master.curUser.EmployeeID, out ErrMsg);
        if (myRunId < 0)
        {
            Master.Message = ErrMsg;
            Utils.DeleteFile(filename, Master.curUser.EmployeeID);
            DisplayPopUpMessage("The file must be resubmitted.");
            return;
        }
        hfRunStatusId.Value = myRunId.ToString();

        string LogMsg = string.Format("Loading {0}: is_adjustment={1}, is_13month={2}, is_outlook={3}, is_user_feed={4}, uses_valid_keys={5}, fact_table_id={6}, dest_table={7}",
            fileType.FileTypeCode, fileType.IsAdjustment, fileType.Is13Month, fileType.IsOutlook, fileType.IsUserFeed, fileType.UsesValidKeyCombos, fileType.FactTableId, fileType.DestinationTable);
       Utils.LogMessage(LogMsg, null, null, myRunId);

        LogMsg = "";
        foreach (FileTypeField field in fileType.fields)
        {
            if (LogMsg.Length > 0)
                LogMsg += ",  ";
            LogMsg += string.Format("MemberName: {0}, Source={1}, ForcedValue={2}",
                field.FactColumnName, field.Source, field.ForcedValue);
        }
        Utils.LogMessage(LogMsg, null, null, myRunId);
        string TableName = string.Empty;
        try
        {
            string Msg = "";
            string Scenario = "";
            int TotRecsAdded = 0;

            MasterFactTable mft = Utils.GetFactTable(fileType.FactTableId.ToString(), "", Master.curUser.EmployeeID);
            if (mft == null)
            {
                Master.Message = HypMDUA.ERROR_MESSAGE;
                //Master.Message = "Could not retrieve Fact Table information.  Please contact the IT OPS group to resolve the issue.";
                return;
            }
            hfStageYear.Value = mft.StageTableYearName;
            hfStageMonth.Value = mft.StageTableMonthName;
            hfPreFactLoad.Value = mft.PreFactLoadProcedure;
            hfKeyComboTable.Value = mft.KeyComboTableName;
            hfFactValTbl.Value = mft.FactTableWithValues;

            LogMsg = string.Format("fact_table_id: {0}, fact_table_name={1}, stage_table_year_name={2}, stage_table_month_name={3}, pre_fact_load_procedure={4}, key_combo_table_name={5}, fact_table_with_outline_values={6}, allows_adjustments={7}",
                mft.FactTableId, mft.FactTableName, mft.StageTableYearName, mft.StageTableMonthName, mft.PreFactLoadProcedure, mft.KeyComboTableName, mft.FactTableWithValues, mft.AllowsAdjustments);
            Utils.LogMessage(LogMsg, null, null, myRunId);

            BasicOraReader Rdr = new BasicOraReader(DbAccess.GetOracleConnectionString());

            TableName = fileType.Is13Month ? hfStageYear.Value : hfStageMonth.Value;
            dimensions = Utils.GetFactDimensions(fileType.FactTable, fileType.Is13Month, true, true);

            TotRecsAdded = Utils.LoadDataInputFileIntoTable(filename, TableName, dimensions, fileType, Master.curUser.UserId, myRunId, out Msg, out Scenario);
            hfScenario.Value = Scenario;

            //  If null was returned from the Load data routine, there was an error and the routine
            //  would have written out the error message.
            if (TotRecsAdded <= 0)
            {
                DisplayPopUpMessage("The file must be resubmitted.");
                Master.Message += Msg;
               //  hrow new Exception(Msg);
            }

            //  Setup the table so that we can display the data as it is loaded 
            //  from the file.
            tblErrs.Rows[0].Cells.Clear();
            tblErrs.Rows[0].Cells.Add(new TableCell());
            tblErrs.Rows[0].Cells[0].Text = "Line Nbr";
            foreach (MasterDimension md in dimensions)
            {
                LogMsg = string.Format("Code={0}, Id={1}, IdColumn={2}, IsIncludedInUserFeed={3}, KeyComboValidation={4}, MasterTable={5}, Name={6}, Prefix={7}, StageTableColumnName={8}, TableAlias={9}, Type={10}, ValidationColumn={11}",
                    md.FactColumnName, md.Id, md.IdColumn, md.IsIncludedInUserFeed, md.KeyComboValidation, md.MasterTable, md.DimensionLabel, md.Prefix, md.FactColumnName, md.TableAlias, md.DimVariableType, md.ValidationColumn);
                Utils.LogMessage(LogMsg, null, null, myRunId);

                TableCell tcHdr = new TableCell();
                tcHdr.Text = md.FactColumnName;
                tblErrs.Rows[0].Cells.Add(tcHdr);
            }

            BasicOraCommand Wrtr = new BasicOraCommand(DbAccess.GetOracleConnectionString());
            Wrtr.Open();

            //  If this is an adjustment and the user can post to any month or this is an outlook
            //  where everyone is supplied, use whatever month was entered on the record; otherwise,
            //  get the current month from the Current Month table.
            int month = -1;
            int.TryParse(ddlMonths.SelectedValue, out month);
            string Years = ddlYears.SelectedValue;
            bool CheckPeriod = true;

            if (fileType.IsAdjustment && Master.curUser.CanPostAdjToAnyPeriod)
            {
                CheckPeriod = false;
                month = -1;
            }

            //  All Data Manipulation and Validation routines will throw errors if there is an 
            //  issue, so we don't need to check return codes from any of the routines.
            //  Check to see if there are any field that have forced values.
            
            Msg = Utils.ProcessInputFileForceValues(fileType,  TableName, myRunId, out Msg);
            if (Msg.Length > 0)
            {
                DisplayPopUpMessage("The file must be resubmitted.");
                Master.Message += Msg;
                // hrow new Exception(Msg);
            }

            bool status = false;
            // Validate the period, only if it isn't outlook
            status = ValidatePeriod(TableName, fileType, CheckPeriod, Rdr, month, Years, myRunId);

            if (status)
            // validate adjustments 
            status = ValidateAdjScenario(TableName, fileType, Rdr, myRunId);

            //  Make sure all the data is valid
            if (status) 
                status = ValidateDimensionFields(TableName, fileType, Rdr, myRunId);

            //  Check for any duplicate records
            if (status)
                status = ValidateDuplicateRows(TableName, fileType, Rdr, myRunId);

            //  If this file type uses valid key combinations, check them now
            //ValidateKeyCombos(TableName, hft, Rdr);

            //  Do the rest of the processing.  It is broken out in case the users can
            //  add keys and we jumped past all this the first time through.
            if (status)
                FinishProcessingData(TableName, fileType, Rdr, Scenario, month, Years);
        }
        catch (Exception exAll)
        {
            GeneralDatabaseAccess.LogEvent(Master.curUser.EmployeeID, "OpsUploadInputFile.aspx", "ProcessUploadFile", exAll, UserToolLogLevel.Error);
            Master.Message = HypMDUA.ERROR_MESSAGE;
                             
            //  We don't want to delete the file if there is no Message.  This means that the exception
            //  Is because there are some invalid keys, but the user can add them if they click ok.
            Utils.DeleteFile(filename, Master.curUser.EmployeeID);

            Utils.RunStatusComplete(int.Parse(hfRunStatusId.Value), "Error", exAll.Message, 0, TableName);
            btnDownload.Visible = true;
        }
    }

    protected void FinishProcessingData(string TableName, FileType hft, BasicOraReader Rdr, string Scenario,
        int month, string Years)
    {
        //  Call the stored procedure to process the added items.
        int NbrUpdated = 0;
        string NewCode = hft.FileTypeCode;
        string Cmd = "";
        Int32 RunId = 0;
        try
        {
            Int32.TryParse(hfRunStatusId.Value, out RunId);
            BasicOraCommand Wrtr = new BasicOraCommand(DbAccess.GetOracleConnectionString());
            if (hft.Is13Month)
            {
                //  Get a list of all the Dimension Fields
                string SelFlds = "";
                foreach (MasterDimension md in dimensions)
                {
                    if (md.IdColumn.Length == 0)
                        continue;

                    SelFlds += md.FactColumnName + ",";
                }

                //  Pivot the data into the Month stage table.
                Utils.UtilTruncateTable(hfStageMonth.Value, false);

                Cmd = string.Format(@"insert into stg_mdua_bs_month ({1} fiscal_period, business_unit, fact_amt, run_status_id, source_cd, Line_nbr, time, year, file_type) (
select {1} 
fiscal_period, null, fact_amt, run_status_id, source_cd, Line_nbr, time, year, file_type 
from (
    with data as (select (level - 1) lev from dual connect by level <= 13)
    select {1} fiscal_period, fact_amt, run_status_id, source_cd, line_nbr, time, year, file_type
    from (
        select {1} Year * 100 + lev fiscal_period, year
         -- unpivot 
         , to_char(lev) time
         , case lev 
             when 0 then FACT_begbal
             when 1 then FACT_jan
             when 2 then FACT_feb
             when 3 then FACT_mar
             when 4 then FACT_apr
             when 5 then FACT_may
             when 6 then FACT_jun
             when 7 then FACT_jul
             when 8 then FACT_aug 
             when 9 then FACT_sep
             when 10 then FACT_oct
             when 11 then FACT_nov 
             when 12 then FACT_dec
           end fact_amt
           , run_status_id, source_cd, line_nbr, file_type 
         from stg_mdua_bs_year, data 
    ) where fact_amt is not null and run_status_id={0}
))", hfRunStatusId.Value, SelFlds);
                Wrtr.Exec(Cmd);
            }
            else
            {
                string UpdCmd = string.Format("Update {0} set fiscal_period=(Year * 100) + time where run_status_id={1}",
                    hfStageMonth.Value, hfRunStatusId.Value);
                Wrtr.Exec(UpdCmd);
            }

            //  If there is cleanup work to do before calling the fact table load routine,
            //  do it now.
            if (hfPreFactLoad.Value.Length > 0)
            {
                Utils.LogMessage(string.Format("Running PreFactLoad stored procedure: {0}", hfPreFactLoad.Value), null, null, RunId);
                DataSet dsResult = GeneralDatabaseAccess.callInputFilePreFactLoad(hfPreFactLoad.Value, hfRunStatusId.Value,
                    Master.curUser.EmployeeID);

                if (dsResult != null && dsResult.Tables.Count > 0 && dsResult.Tables[0].Rows.Count > 0)
                {
                    FillPreLoadErrTable(dsResult);
                    Master.Message += "There are invalid records.";
                    // hrow new Exception("There are invalid records.");
                }
            }

            //  Call routine to insert data into the fact table.
            NbrUpdated = Utils.CopyInputFileStageToTrans(RunId, hft.FileTypeCode, hft.IsAdjustment ? "Y" : "N");
            if (NbrUpdated == -1)
            {
                DisplayPopUpMessage("The file must be resubmitted.");
                throw new Exception("There was an error in the stored procedure that processes the User Input file.  All records in the file have been rejected.");
            }

            GeneralDatabaseAccess.LogEvent(Master.curUser.EmployeeID, "UserInputUpload", "Uploaded User File " + hft.FileTypeCode,
                string.Format("{0} item(s) were added or modified.",
                NbrUpdated), UserToolLogLevel.Audit);
            Master.Message += string.Format("<br>{0} item(s) were added or modified.",
                NbrUpdated);

            ShowLoadedRecords();

            //  If the file type was an adjustment file, then we need to run the MaxL script.
            //  An audit entry is added recording the response from the MaxL client application.
            Utils.DeleteInputFileStagingData(hfStageMonth.Value, hft.FileTypeCode);
            Utils.DeleteInputFileStagingData(hfStageYear.Value, hft.FileTypeCode);

            Utils.RunStatusComplete(RunId, "Complete", string.Format("{0} item(s) were added or modified.", NbrUpdated), NbrUpdated, TableName);
        }
        catch (Exception exAll)
        {
            GeneralDatabaseAccess.LogEvent(Master.curUser.EmployeeID, "OpsUploadInputFile.aspx", "ProcessUploadFile", exAll, UserToolLogLevel.Error);
            Utils.RunStatusComplete(RunId, "Error", exAll.Message, 0, TableName);
        }
    }
    public bool ValidatePeriod(string TableName, FileType hft, bool CheckPeriod, BasicOraReader Rdr,
        int month, string Years, int RunId)
    {
        bool bReturn = false;
        string Cmd = "Select s.Line_Nbr";
        foreach (MasterDimension md in dimensions)
            Cmd += ",s." + md.FactColumnName;
        Cmd += string.Format(" from {0} s ", TableName);

        string Where = "";

        if (CheckPeriod == false)
        {
            Where = "(not s.Year in (select distinct year from dim_fiscal_period)";
            if (hft.Is13Month == false)
                Where += " or not s.Time in (select distinct fiscal_period_month from dim_fiscal_period)";
            Where += ")";
        }
        else
        {
            Where = "(s.Year != " + Years;
            if (hft.Is13Month == false)
                Where += " or s.time != " + month.ToString();
            Where += ")";
        }

        Cmd += " Where " + Where + string.Format(" and run_status_id={0}", RunId);
        Utils.LogMessage("Validating Period", Cmd, null, RunId);

        try
        {
            if (Rdr.Open(Cmd))
            {
                if (Rdr.oraRdr.HasRows)
                {
                    FillTable(Rdr, CheckCurrentPeriod, null);
                    DisplayPopUpMessage("The file must be resubmitted.");
                    Master.Message = "There was an error with the displayed items.";
                    Utils.RunStatusComplete(int.Parse(hfRunStatusId.Value), "Error", "invalid period", 0, TableName);

                    //throw new Exception("There was an error with the displayed items.");
                }
                else
                    bReturn = true;
            }
            else
            {
                GeneralDatabaseAccess.LogEvent(Master.curUser.EmployeeID, "OpsUploadInputFile.aspx", "ValidatePeriod", Rdr.LastErrorMessage, UserToolLogLevel.Error);
                Master.Message = HypMDUA.ERROR_MESSAGE;
            }
        }
        catch (Exception ex)
        {
            GeneralDatabaseAccess.LogEvent(Master.curUser.EmployeeID, "OpsUploadInputFile.aspx", "ValidatePeriod", ex, UserToolLogLevel.Error);
            Master.Message = HypMDUA.ERROR_MESSAGE;
        }
        return bReturn;

    }

    public string CheckCurrentPeriod(BasicOraReader Rdr)
    {
        //int Mnth = 0;
        //int.TryParse(Rdr.oraRdr.GetValue["time"].toString(), out Mnth);
        //if (Mnth < 0 || Mnth > 12)
        //    return "The month is not a valid month value.  It must be a value in the range of 0 to 12.";

        ////  Check the field that validates year against the outline.  If the outline year is null, 
        ////  then they have an invalid Year.
        //if (Rdr.oraRdr.FieldCount > 15 && Rdr.oraRdr.IsDBNull(15))
        //    return "The year is not a valid year.  It must be a defined year in the Years outline.";

        //return "Either the month or year is not equal to the current period.";
        return "The Time and / or Year is not valid or it is not equal to the current period.";
    }
    /*
        public void ValidateScenario(string TableName, HypFileType hft, BasicOraReader Rdr, int RunId)
        {
            string Cmd = string.Format(@"Select distinct dim_rpt_scenario from {0} where run_status_id={1}",
                TableName, RunId);
            if (Rdr.Open(Cmd) && Rdr.oraRdr.HasRows)
            {
                int NbrScn = 0;
                while (Rdr.oraRdr.Read())
                    NbrScn++;
                Rdr.Close();

                if (NbrScn > 1)
                {
                    DisplayPopUpMessage("The file must be resubmitted.");
                    throw new Exception("The Outlook File has more than one Scenario defined in the file.");
                }
            }
        }
    */
    public bool ValidateAdjScenario(string TableName, FileType hft, BasicOraReader Rdr, int RunId)
    {
        bool bReturn = false;
        string Cmd = "Select s.Line_Nbr";
        try
        {
            foreach (MasterDimension md in dimensions)
                Cmd += ",s." + md.FactColumnName;
            Cmd += string.Format(" from {0} s left outer join master_scenario m on s.scenario=m.scenario_code", TableName);
            Cmd += string.Format(" where m.is_adjustment {2}= 'Y' and run_status_id={1}",
                TableName, RunId, hft.IsAdjustment ? "!" : "");
            Utils.LogMessage("Validating Scenario", Cmd, null, RunId);
            if (Rdr.Open(Cmd))
            {
                if (Rdr.oraRdr.HasRows)
                {
                    FillTable(Rdr, null, string.Format("The Scenario must only contain {0}adjustment scenarios.",
                        (hft.IsAdjustment ? "" : "non-")));
                    DisplayPopUpMessage("The file must be resubmitted.");
                    Utils.RunStatusComplete(int.Parse(hfRunStatusId.Value), "Error", "invalid scenarios", 0, TableName);
                    //throw new Exception("The file has Scenarios that do not match the file definition.");
                }
                else
                    bReturn = true;
            }
            else
            {
                GeneralDatabaseAccess.LogEvent(Master.curUser.EmployeeID, "OpsUploadInputFile.aspx", "ValidateAdjScenario", Rdr.LastErrorMessage, UserToolLogLevel.Error);
                Master.Message = HypMDUA.ERROR_MESSAGE;
            }
        }
        catch (Exception ex)
        {
            GeneralDatabaseAccess.LogEvent(Master.curUser.EmployeeID, "OpsUploadInputFile.aspx", "ValidateAdjScenario", ex, UserToolLogLevel.Error);
            Master.Message = HypMDUA.ERROR_MESSAGE;
        }
        return bReturn; 
    }

    public bool ValidateDuplicateRows(string TableName, FileType hft, BasicOraReader Rdr, int RunId)
    {

        bool bReturn = false;
        string Cmd = "Select count(1)";
        string Flds = "";
        foreach (MasterDimension md in dimensions)
            Flds += ",s." + md.FactColumnName;
        Cmd += Flds;
        Cmd += string.Format(" from {0} s where s.run_status_id={1}", TableName, RunId);
        Cmd += " group by " + Flds.Substring(1);
        Cmd += " having count(1) > 1";

        Utils.LogMessage("Checking for Duplicate Keys", Cmd, null, RunId);
        // jevans 8/19/2011 - add error handling 
        try
        {
            if (Rdr.Open(Cmd))
            {
                if (Rdr.oraRdr.HasRows)
                {
                    FillTable(Rdr, null, "This row is duplicated in the file.  It appears as many times as indicated by the Line Nbr column.");
                    DisplayPopUpMessage("The file must be resubmitted.");
                    Utils.RunStatusComplete(int.Parse(hfRunStatusId.Value), "Error", "duplicate rows", 0, TableName);
                    //throw new Exception("There are duplicate rows in the file.  The Line Nbr column shows how many times this combination repeats.");
                }
                else
                    bReturn = true;
            }
            else
            {
                throw new Exception(Rdr.LastErrorMessage);
            }
        }
        catch (Exception ex)
        {
            GeneralDatabaseAccess.LogEvent(Master.curUser.EmployeeID, "OpsUploadInputFile.aspx", "ValidateDuplicateRows", ex, UserToolLogLevel.Error);
            Utils.RunStatusComplete(int.Parse(hfRunStatusId.Value), "Error", "duplicate rows", 0, TableName);
            Master.Message = HypMDUA.ERROR_MESSAGE;
        }
        return bReturn;
    }

    public bool ValidateDimensionFields(string TableName, FileType hft, BasicOraReader Rdr, int RunId)
    {
        bool bReturn = false;

        string AddlFlds = "";
        string Joins = "";
        string Where = "";
        string Cmd = "Select s.Line_Nbr";
        try
        {
            foreach (MasterDimension md in dimensions)
            {
                Cmd += ",s." + md.FactColumnName;
                if (md.MasterTable.Length > 0)
                {
                    AddlFlds += string.Format(",{0}.{1}", md.TableAlias,
                        md.IdColumn);
                    Joins += string.Format(" left outer join {0} {1} on s.{2}={1}.{3} ",
                        md.MasterTable, md.TableAlias, md.FactColumnName, md.ValidationColumn);
                    if (md.ExtraValidationClause.Length > 0)
                        Joins += " and " + md.ExtraValidationClause;
                    if (Where.Length > 0)
                        Where += " or ";
                    Where += string.Format(" {0}.{1} is null", md.TableAlias,
                        md.IdColumn);
                }
            }

            Cmd += AddlFlds;
            Cmd += string.Format(" from {0} s", TableName);
            Cmd += Joins;
            Cmd += string.Format(" where s.run_status_id={0} and (", RunId);
            Cmd += Where + ") order by s.Line_Nbr";

            Utils.LogMessage("Validating Fields against Master Data", Cmd, null, RunId);
            if (Rdr.Open(Cmd))
            {
                if (Rdr.oraRdr.HasRows)
                {
                    int Cnt = FillTable(Rdr, CheckNotFoundFlds, null);
                    DisplayPopUpMessage("The file must be resubmitted.");
                    Master.Message = "There are Invalid Field Values in the User Feed.  Check individual lines for more information.";
                    Utils.RunStatusComplete(int.Parse(hfRunStatusId.Value), "Error", "invalid dimensions", 0, TableName);
                    //throw new Exception("There are Invalid Field Values in the User Feed.  Check individual lines for more information.");
                }
                else
                    bReturn = true;
            }
            else
            {
                GeneralDatabaseAccess.LogEvent(Master.curUser.EmployeeID, "OpsUploadInputFile.aspx", "ValidateDimensionFields", Rdr.LastErrorMessage, UserToolLogLevel.Error);
                Master.Message = HypMDUA.ERROR_MESSAGE;
            }
        }
        catch (Exception ex)
        {
            GeneralDatabaseAccess.LogEvent(Master.curUser.EmployeeID, "OpsUploadInputFile.aspx", "ValidateDimensionFields", ex, UserToolLogLevel.Error);
            Master.Message = HypMDUA.ERROR_MESSAGE;
        }
        return bReturn;
    }

    private string CheckNotFoundFlds(BasicOraReader Rdr)
    {
        string Msg = "The following field(s) are not valid: ";
        foreach (MasterDimension md in dimensions)
        {
            if (md.MasterTable.Length > 0 && md.IdColumn.Length > 0)
            {
                int Col = Rdr.oraRdr.GetOrdinal(md.IdColumn);
                if (Col >= 0)
                    if (Rdr.oraRdr.IsDBNull(Col))
                        Msg += md.FactColumnName + "    ";
            }
        }
        //for (int i = 0; i < Rdr.oraRdr.VisibleFieldCount; i++)
        //    if (Rdr.oraRdr.IsDBNull(i))
        //        Msg += Rdr.oraRdr.GetName(i) + "  ";
        return Msg;
    }


    //  If the file type uses valid key combinations, check the key combinations table.
    public void ValidateKeyCombos(string TableName, FileType hft, BasicOraReader Rdr)
    {
        if (hft.UsesValidKeyCombos == false)
            return;

        string Cmd = "";
        string Join = string.Format("kc.fact_table_id={0} and kc.file_type={1}",
            hfMasterTableId, hft.FileTypeCode);

        //  Select any items that don't exist in the key combinations table.
        Cmd = "Select s.LineNbr, ";
        foreach (MasterDimension md in dimensions)
        {
            Cmd += ",s." + md.FactColumnName;
            if (md.KeyComboValidation.Length > 0)
                Join += " and " + md.KeyComboValidation;
            else
                Join += string.Format(" and s.{0} = kc.{0}", md.FactColumnName);
        }
        Cmd += string.Format("from {0} s left outer join {1} kc on {2} where kc.file_type is null order by LineNbr",
            TableName, hfKeyComboTable.Value, Join);

        if (Rdr.Open(Cmd) && Rdr.oraRdr.HasRows)
        {
            int Cnt = FillTable(Rdr, null, "This line does not have a valid key combination.");
            /*
            if (hft.UsesValidKeyCombos)
            {
                if (InvalidKeyFlds.Length > 1)
                    InvalidKeyFlds = InvalidKeyFlds.Substring(1);
                string[] invKeys = InvalidKeyFlds.Split(',');

                //  If there are invalid keys and all the invalid keys aren't defined in other file types, check
                //  to see if they are user definable.  If they are, ask the user if they would like to 
                //  just add the keys instead.
                if (Cnt == invKeys.Length)
                {
                    hfLineNbrs.Value = InvalidKeyFlds;
                    CheckUserDefinedFlds(hft, InvalidKeyFlds, Rdr, TableName);
                }
            }
            */
            DisplayPopUpMessage("The file must be resubmitted.");
            //throw new Exception("There are Invalid Key Combinations in the User Feed.  Check individual lines for more information.");
            Master.Message = "There are Invalid Key Combinations in the User Feed.  Check individual lines for more information.";
        }
    }

    private void CheckUserDefinedFlds(FileType hft, string LineNbrs, BasicOraReader Rdr, string TableName)
    {
        //  Start by checking to see if there are any User Defined Fields.
        string[] FldNames = new string[] {
            "DIM_RPT_REPORTNGLINE", "DIM_RPT_ACCOUNT", "DIM_RPT_KPI", "DIM_RPT_VIEW", 
            "DIM_RPT_SCENARIO", "DIM_RPT_PRODUCT", "DIM_RPT_SUBACCOUNT", 
            "DIM_RPT_SERVICETYPE", "DIM_RPT_FUNCTION", "DIM_RPT_COSTCENTER", "DIM_RPT_ENTITY", "DIM_RPT_COMPANY"            
        };

        /*Select s.LineNbr, max(v.dim_rpt_costcenter), max(cc.MemberName)
        from rpt_stage_out_Usr1_tbl s
        left outer join rpt_fact_validate_tbl v on s.dim_rpt_reportngline=v.dim_rpt_reportngline
        and s.dim_rpt_account =v.dim_rpt_account
        and s.dim_rpt_kpi =v.dim_rpt_kpi
        and s.dim_rpt_view=v.dim_rpt_view
        and s.dim_rpt_scenario=v.dim_rpt_scenario
        and s.dim_rpt_product =v.dim_rpt_product
        and s.dim_rpt_subaccount=v.dim_rpt_subaccount
        and s.dim_rpt_servicetype=v.dim_rpt_servicetype
        and s.dim_rpt_function=v.dim_rpt_function
        and s.dim_rpt_entity=v.dim_rpt_entity     
        and s.prp_rpt_source=''
        left outer join WEB_DIMENSIONS_TBL cc on s.DIM_RPT_COSTCENTER=cc.MemberName
        where s.linenbr in () 
        group by s.LineNbr
         */

        string Sel = "";
        string OuterJoins = "";
        foreach (FileTypeField ftFld in hft.fields)
        {
            if (ftFld.Source == FileTypeFieldSource.UserDefinableUserFeed)
            {
                for (int i = 0; i < FldNames.Length; i++)
                {
                    if (ftFld.FactColumnName.Equals(FldNames[i]))
                    {
                        string prefix = ftFld.FactColumnName.Substring(0, 4) ;
                        //string memNme = DbAccess.DimNameToDimType(ftFld.StageColumnName);
                        Sel += string.Format(",max(v.{0}),max({1}.Member_Name)",
                            ftFld.FactColumnName, prefix);
                        OuterJoins += string.Format(" left outer join WEB_DIMENSIONS_TBL {0} on s.{1}={0}.Member_Name and {0}.DIM_TYPE='{2}' and {0}.Dim_Storage='Store Data'",
                            prefix, ftFld.FactColumnName, ftFld.DimensionTypeName);
                        FldNames[i] = "";
                        break;
                    }
                }
            }
        }

        //  If Sel.Length is 0, there are no user definable fields.
        if (Sel.Length == 0)
        {
            DisplayPopUpMessage("The file must be resubmitted.");
            //throw new Exception("There are Invalid Key Combinations in the User Feed.  Check individual lines for more information.");
            Master.Message = "There are Invalid Key Combinations in the User Feed.  Check individual lines for more information.";
        }

        //  Create the field list that should be included in the join.  It shouldn't include
        //  any of the fields that are being selected.
        string JoinCmd = "";
        foreach (string Nme in FldNames)
        {
            if (Nme.Length == 0)
                continue;

            if (JoinCmd.Length > 0)
                JoinCmd += " and ";

            JoinCmd += string.Format("s.{0}=v.{0}", Nme);
        }

        //  Create the Select Statement.  It should show the joined fields for the user definable fields
        //  so that we can determine if a key like the one we are trying to create exists.
        string Cmd = string.Format(@"select s.LineNbr{0} 
            from {1} s 
            left outer join {2} v on {3} and s.prp_rpt_source='{4}'
            {6}
            where s.prp_rpt_source='{4}' and s.linenbr in ({5})
            group by s.LineNbr",
            Sel, 
            TableName, 
            hft.ValidationKeyTable,
            JoinCmd, 
            hft.FileTypeCode,
            LineNbrs, 
            OuterJoins);

        if (Rdr.Open(Cmd) == false)
        {
            DisplayPopUpMessage("The file must be resubmitted.");
            //throw new Exception("There are Invalid Key Combinations in the User Feed.  Check individual lines for more information.");
            Master.Message = "There are Invalid Key Combinations in the User Feed.  Check individual lines for more information.";
        }

        //  For each row that is returned, make sure all the fields exist.  If any return a null,
        //  It means that a record like the one we are trying to define doesn't exist.
        string ErrMsg = "";
        string BadLines = "";
        while (Rdr.oraRdr.Read())
        {
            for (int f = 1; f < Rdr.oraRdr.FieldCount; f++)
            {
                if (Rdr.oraRdr.IsDBNull(f))
                {
                    //  If it is the first field of the two fields per record, then it means there
                    //  is no similar row in the validation table.  If it is the 2nd of the two columns
                    //  per row checked, then the value was not found in the outline.
                    if (((f - 1) & 1) == 0)
                        ErrMsg += string.Format("Line {0} is not similar to other rows.\r\n", Rdr.oraRdr[0]);
                    else
                    {
                        string FldName = Rdr.oraRdr.GetName(f - 1);
                        FldName = FldName.Substring(14, FldName.Length - 15);
                        ErrMsg += string.Format("Line {0} {1} does not exist in the outline.\r\n", Rdr.oraRdr[0], FldName);
                    }
                    BadLines += string.Format("{0}", Rdr.oraRdr[0]);
                    break;
                }
            }
        }

        if (BadLines.Length > 0)
        {
            DisplayPopUpMessage("The file must be resubmitted.");
            //hrow new Exception(ErrMsg);
            Master.Message = ErrMsg;
        }

        //  If we get to this point, it means that the items with keys that aren't defined can be added
        //  to the validation table.
        //ShowContinueItems(true);
        //throw new Exception("");
    }

    private int FillTable(BasicOraReader Rdr, DetermineMsgText GetMsg, string DefaultMsg)
    {
        Color AltBgnd = Color.FromArgb(231, 242, 254); //#E7F2FE
        Color RegBgnd = Color.White;
        int MainRowCnt = 0;

        tblErrs.Visible = true;
        tblErrs.Rows[0].Cells[0].Visible = true;

        while (tblErrs.Rows.Count > 1)
            tblErrs.Rows.RemoveAt(1);

        while (Rdr.oraRdr.Read())
        {
            ++MainRowCnt;

            //  Create a row for the budget group.
            TableRow tr = new TableRow();
            tr.BackColor = (((MainRowCnt & 1) == 1) ? RegBgnd : AltBgnd);
            tblErrs.Rows.Add(tr);

            for (int c = 0; c < tblErrs.Rows[0].Cells.Count; c++)
            {
                TableCell tc = new TableCell();
                tc.Text = string.Format("{0}", Rdr.oraRdr[c]);
                tr.Cells.Add(tc);
            }

            if (GetMsg != null || DefaultMsg != null)
            {
                tr.ForeColor = Color.Red;

                TableRow trErr = new TableRow();
                trErr.ForeColor = Color.Red;
                trErr.BackColor = tr.BackColor;
                tblErrs.Rows.Add(trErr);

                TableCell tc = new TableCell();
                trErr.Cells.Add(tc);

                tc = new TableCell();
                tc.Text = ((GetMsg != null) ? GetMsg(Rdr) : DefaultMsg);
                tc.ColumnSpan = tr.Cells.Count - 1;
                trErr.Cells.Add(tc);
            }
        }
        Rdr.Close();
        return MainRowCnt;
    }

    private int FillPreLoadErrTable(DataSet dsResult)
    {
        Color AltBgnd = Color.FromArgb(231, 242, 254); //#E7F2FE
        Color RegBgnd = Color.White;
        int MainRowCnt = 0;

        tblErrs.Visible = true;

        //  Setup the columns
        tblErrs.Rows[0].Cells.Clear();
        for (int ci = 0; ci < dsResult.Tables[0].Columns.Count - 1; ci++)
        {
            DataColumn col = dsResult.Tables[0].Columns[ci];
            TableCell tcCol = new TableCell();
            tcCol.Text = col.Caption.Length > 0 ? col.Caption : col.ColumnName;
            tblErrs.Rows[0].Cells.Add(tcCol);
        }

        while (tblErrs.Rows.Count > 1)
            tblErrs.Rows.RemoveAt(1);

        foreach (DataRow dr in dsResult.Tables[0].Rows)
        {
            ++MainRowCnt;

            //  Create a row for the budget group.
            TableRow tr = new TableRow();
            tr.BackColor = (((MainRowCnt & 1) == 1) ? RegBgnd : AltBgnd);
            tblErrs.Rows.Add(tr);

            for (int c = 0; c < dsResult.Tables[0].Columns.Count - 1; c++)
            {
                TableCell tc = new TableCell();
                tc.Text = string.Format("{0}", dr[c]);
                tr.Cells.Add(tc);
            }

            tr.ForeColor = Color.Red;

            TableRow trErr = new TableRow();
            trErr.ForeColor = Color.Red;
            trErr.BackColor = tr.BackColor;
            tblErrs.Rows.Add(trErr);

            TableCell tcErr = new TableCell();
            trErr.Cells.Add(tcErr);

            tcErr = new TableCell();
            tcErr.Text = dr[dsResult.Tables[0].Columns.Count - 1].ToString();
            tcErr.ColumnSpan = tr.Cells.Count - 1;
            trErr.Cells.Add(tcErr);
        }
        dsResult.Dispose();
        return MainRowCnt;
    }

    private int ShowLoadedRecords()
    {
        BasicOraReader Rdr = new BasicOraReader(DbAccess.GetOracleConnectionString());
        string Cmd = string.Format("select * from {1} where run_status_id={0}",
            hfRunStatusId.Value, hfFactValTbl.Value);
        if (Rdr.Open(Cmd) == false)
            return -1;

        //  Define the table so that all the data is displayed.
        tblErrs.Visible = true;
        while (tblErrs.Rows.Count > 1)
            tblErrs.Rows.RemoveAt(1);
        tblErrs.Rows[0].Cells.Clear();
        TableRow tr = tblErrs.Rows[0];
        TableCell tc;
        for (int cl = 0; cl < Rdr.oraRdr.FieldCount; cl++)
        {
            tc = new TableCell();
            tc.Text = Rdr.oraRdr.GetName(cl);
            tr.Cells.Add(tc);
        }

        Color AltBgnd = Color.FromArgb(231, 242, 254); //#E7F2FE
        Color RegBgnd = Color.White;
        int MainRowCnt = 0;

        int MaxLinesToDisplay = 1000;
        int.TryParse(ConfigurationManager.AppSettings["UploadMaxLinesDisplayed"], out MaxLinesToDisplay);

        int SkippedLines = 0;
        TableRow trSkipped = null;
        while (Rdr.oraRdr.Read())
        {
            ++MainRowCnt;

            //  There are some file types that have 20K or more rows.  Don't display all of them
            //  back to the user because the browser will time out and the user won't be able to 
            //  tell if the upload worked or not and with Adjustments being relative, we don't want
            //  an adjustment to be posted more than once.
            if (MainRowCnt > MaxLinesToDisplay)
            {
                if (SkippedLines == 0)
                {
                    trSkipped = new TableRow();
                    trSkipped.BackColor = (((MainRowCnt & 1) == 1) ? RegBgnd : AltBgnd);
                    tblErrs.Rows.Add(trSkipped);
                }

                SkippedLines++;
                continue;
            }

            //  Create a row for the budget group.
            tr = new TableRow();
            tr.BackColor = (((MainRowCnt & 1) == 1) ? RegBgnd : AltBgnd);
            tblErrs.Rows.Add(tr);

            for (int c = 0; c < Rdr.oraRdr.FieldCount; c++)
            {
                tc = new TableCell();
                tc.Text = string.Format("{0}", Rdr.oraRdr[c]);
                tr.Cells.Add(tc);
            }
        }

        //  If we skipped any lines from being displayed, display a line with a count of how many items were skipped.
        if (SkippedLines > 0)
        {
            TableCell tcSkipped = new TableCell();
            tcSkipped.ColumnSpan = tblErrs.Rows[0].Cells.Count;
            tcSkipped.Text = string.Format("{0} rows were skipped.", SkippedLines);
            trSkipped.Font.Bold = true;
            trSkipped.Cells.Add(tcSkipped);
        }

        Rdr.Close();
        return MainRowCnt;
    }

    private void DisplayPopUpMessage(string Message)
    {
        litPopupMsg.Text = string.Format(@"<script language=""javascript"" type=""text/javascript"">
    setTimeout(""alert('{0}');"", 500);
</script>", Message);
    }
  
    protected void btnDownload_Click(object sender, EventArgs e)
    {
        //  Make sure that they picked a file type and selected a file.
        litPopupMsg.Text = "";
        tblErrs.Visible = false;
        btnDownload.Visible = false;
        if (ddlFileType.SelectedValue.Trim().Length == 0)
        {
            Master.Message = "You must select a File Type first";
            return;
        }

        //  Check to see if someone else is running a process that we should be waiting for.
        FileType hft = Utils.GetFileType(ddlFileType.SelectedValue,
            Master.curUser.EmployeeID);

        string TableName = hft.Is13Month ? hfStageYear.Value : hfStageMonth.Value;

        string Cmd = string.Format("Select * from {0} where File_type='{1}'",
            TableName, hft.FileTypeCode);
       
        string Filename = string.Format("Downloads/{1}_{2}_{0}.csv",
            DateTime.Now.ToString("yyyyMMdd_HHmmss"),
            Master.curUser.UserId, hft.FileTypeCode);
        Filename = Server.MapPath(Filename);
        if (Utils.WriteDataToCSV(Master.curUser.EmployeeID, Filename, hft.FileTypeCode, Cmd) > -1)
            Response.Redirect(string.Format("~/DownloadFile.aspx?DocName={0}&Del=Y",
                Filename));
        else
            /// message says team was notified
            Master.Message = HypMDUA.ERROR_MESSAGE;
    }

    private void ShowSelectionControls(bool bShow)
    {
        lblCurPeriod.Visible = bShow;
        lblFileType.Visible = bShow;
        lblInputFile.Visible = bShow;
        ddlFileType.Visible = bShow;
        ddlMonths.Visible = bShow;
        ddlYears.Visible = bShow;
        fuUserFile.Visible = bShow;
        btnUpload.Visible = bShow;
    }

    private void LoadProcessComplete(bool RemoveDataFromStageTable, string Filename, bool Success,
        string Message, int RecCount)
    {
        /*
                //  We don't want to delete the file if there is no Message.  This means that the exception
                //  Is because there are some invalid keys, but the user can add them if they click ok.
                if (Filename != null && Filename.Length > 0)
                    Utils.DeleteFile(Filename, Master.curUser.EmployeeID);

                if (RemoveDataFromStageTable)
                {
                    Utils.DeleteInputFileStagingData(hfStageMonth.Value, ddlFileType.SelectedValue);
                    Utils.DeleteInputFileStagingData(hfStageYear.Value, ddlFileType.SelectedValue);
                }

                DbAccess.callEndProcessStep(hfProcStatId.Value, "LOAD_DATA", Success ? "S" : "E",
                    Message, Master.curUser.EmployeeID);
                DbAccess.DelProcessLog(SeqNbr, Master.curUser.EmployeeID);
                btnDownload.Visible = true;
        */
    }
}
