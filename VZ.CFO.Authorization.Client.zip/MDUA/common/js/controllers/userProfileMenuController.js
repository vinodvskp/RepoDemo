﻿(function (module) {

    module.controller('userProfileMenuController', ["$scope", "$state", "mainService", "userMenuService", "alertingService", "spinnerService", "localStoreService", "userRoleService", userProfileMenuController]);

    function userProfileMenuController($scope, $state, mainService, userMenuService, alertingService, spinnerService, localStoreService, userRoleService) {
        var self = $scope;

        $scope.environment = '';

        $scope.getUserInfo = function (userEid) {
            var userEid = { "eid": userEid };
            mainService.getLdapService([], getLdapUserSuccessCallback, loadUserRoleErrorCallback);
        };

        if (!localStoreService.getEmpEid()) {
            localStoreService.addEmpEid(mainService.eidService());
        }




        //handlers
        function onLoad() {
            $scope.getUserInfo(localStoreService.getEmpEid());
            userRoleService.loadUserRole({}, loadUserRoleCallback, loadUserRoleErrorCallback);
            mainService.getFactTableSettings({}, getFactTableSettingsCallback, geEnvErrorCallBack);
        }

        $scope.singoutFn = function () {
            /*mainService.singoutService()
              .then(function (response) {                  
                  localStoreService.addEmpEid('');
                  alertingService.addSuccess("Successfully logout.");
                  window.location.assign("Logout.html");                 
              },
              function (response) {
            	  alertingService.addDanger("Error:" + response);
              });*/
            //Note: logout is not needed, just go to home page
            $state.go("home");
        }
        //callbacks

        function getFactTableSettingsCallback(response) {
            if (response) {
                $scope.environment = response.Environment;
            }
            
        }

        function getMenuErrorCallBack(response) {
            alertingService.addDanger("getMenu call -Error:" + response);
        }

        function geEnvErrorCallBack(response) {
            alertingService.addDanger("Error fetching environment details");
        }

        function loadUserRoleCallback(response) {
            console.log(userRoleService.getUserVersionManagementRole());
        }
        function loadUserRoleErrorCallback(response) {
            alertingService.addDanger(response);
        }

        function getLdapUserSuccessCallback(response) {

            $scope.user = response.data;
            if ($scope.user) {
                $scope.user.photo = 'https://ssoutils.verizon.com/directoryservice/getimage.axd?eid=' + $scope.user.EmployeeId;
            }

        }

        //Onload
        onLoad();
    }

    //view model


})(angular.module('vmApp'));