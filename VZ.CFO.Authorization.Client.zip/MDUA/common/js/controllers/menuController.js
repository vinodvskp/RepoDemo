﻿(function (module) {

    module.controller('menuController', ["$scope", "mainService", "userMenuService", "alertingService", "serverVariableService", menuController]);

    function menuController($scope, mainService, userMenuService, alertingService, serverVariableService) {
        var self = $scope;

        $scope.menus = [];

        self.menuMode = serverVariableService.MENU_MODE();
        self.menuPrefix = "";

        self.setMenuPrefix = function () {
            if (self.menuMode == "legacy") {
                self.menuPrefix = serverVariableService.SITE_SUBFOLDER() + "MDMFramework/Home#/"
            }
            else {
                self.menuPrefix = "#/"
            }
        }

        self.getMenu = function () {
            mainService.getMenuService([], getMenuSuccessCallBack, getMenuErrorCallBack);
        };

        self.getHomeMenuItem = function () {
            mainService.getHomeMenuItemServic([], function (response) {
                $scope.menuitems = response.data;
            }, function (error) {
                alertingService.addDanger("getHomeMenuItem call -Error:" + error);
            })
        }
        self.auditUser = function () {
            var auditUserViewModel = new mainService.AuditUserViewModel(serverVariableService.USER_EID(), 'Home', 'Login for ' + serverVariableService.USER_EID(), 'Success', 7);
            mainService.auditUser({ "data": auditUserViewModel }, auditUserSuccessCallback, auditUserErrorCallback);
        }

        //handlers
        function onLoad() {
            self.getMenu();
            self.getHomeMenuItem();
            self.auditUser();
        }

        //callbacks

        function getMenuSuccessCallBack(response) {
            $scope.menus = response.data;
            self.setMenuPrefix();
            userMenuService.storeUserMenu(response.data);
        }

        function getMenuErrorCallBack(response) {
            alertingService.addDanger("getMenu call -Error:" + response);
        }

        function auditUserSuccessCallback(response) {
            console.log('audit user success');
        }

        function auditUserErrorCallback(response) {
            console.log('audit user failed');
        }

        //Onload
        onLoad();
    }

    //view model



})(angular.module('vmApp'));