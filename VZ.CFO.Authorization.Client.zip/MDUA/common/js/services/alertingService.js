﻿(function () {

    angular.module('common').factory('alertingService', ['$timeout','$rootScope',alertingService]);

    function alertingService($timeout,$rootScope) {
    	var currentAlerts = [];
    	
        var addDanger = function (message) {
            var alert = { type: "alert-danger", message: message };
            addAlert(alert);
        };
        
        var addWarning = function (message) {
            var alert = { type: "alert-warning", message: message };
            addAlert(alert);
        };


        var addInformation = function (message) {
            var alert = { type: "alert-info", message: message };
            addAlert(alert);
        };

        var addSuccess = function (message) {
            var alert = { type: "alert-success ", message: message };
            addAlert(alert);
        };
        

        var addAlert = function (alert) {
            currentAlerts.push(alert);
            $timeout(function () {
                for (var i = 0; i < currentAlerts.length; i++) {
                    if (currentAlerts[i] == alert) {
                        currentAlerts.splice(i, 1);
                        break;
                    }
                }
            }, 10000);
        };

        var errorHandler = function (description) {
            return function () {
                addDanger(description);
            };
        };
        
        $rootScope.$on('$stateChangeSuccess',
			function(event, toState, toParams, fromState, fromParams){
			    //event.preventDefault();
			    currentAlerts.length =0;
        	
    	});
      
        return {
        	addDanger: addDanger,
        	addWarning: addWarning,
        	addInformation: addInformation,
            errorHandler: errorHandler,
            addSuccess: addSuccess,
            currentAlerts: currentAlerts
        };
    }
}());
