(function () {

    angular.module('common').factory('notificationSubscriberService', ['$rootScope','serverVariableService', '$interval',notificationSubscriberService]);

    function notificationSubscriberService($rootScope, serverVariableService, $interval) {

        var notificationType = serverVariableService.NOTIFICATION_TYPE();
        
        var subscribers = [];
    	var subscribe = function (appName, appModuleName, subscriberCallback) {

    	    if (notificationType == "push") {
    	        var compactAppModuleName = appModuleName.replace(" ", "");
    	        //if(!subscribers[appName + "_" + compactAppModuleName]) {
    	        var connection = jQuery.hubConnection(serverVariableService.MDUA_NOTIFICATION_ENDPOINT());
    	        var proxy = connection.createHubProxy('pushNotificationHub');
    	        proxy.connection.qs = "app_name=" + appName + "&app_module=" + appModuleName;
    	        proxy.on('broadcastMessage', function (message) { $rootScope.$apply(subscriberCallback(message)) });
    	        proxy.connection.start().pipe(function () {
    	            console.log("started subscriber: " + appName + " " + appModuleName + " connection Id=" + proxy.connection.id);
    	        });
    	        subscribers[appName + "_" + compactAppModuleName] = proxy;
    	        //}
    	        //else {
    	        //	reconnectSubscriber(appName, appModuleName);
    	        //}
    	    }
    	    if (notificationType == "poll") {
    	        startPolling(appName, appModuleName, subscriberCallback);
    	    }
        };
        
        var isSubscribed = function (appName, appModuleName) {
        	var compactAppModuleName = appModuleName.replace(" ", "");
            return (subscribers[appName + "_" + compactAppModuleName] == true);
 		};
       
 		var disconnectSubscriber = function(key) {
 			var proxy = subscribers[key];
 			if (proxy) {
 			    if (notificationType == "push") {
 			        if (proxy.connection && proxy.connection.state && proxy.connection.state !== 4 /* disconnected */) {
 			            proxy.connection.stop();
 			            console.log(key + ' signlar stopped.');
 			        }
 			    }

 			    if (notificationType == "poll") {
 			        if (angular.isDefined(proxy)) {
 			            $interval.cancel(proxy);
 			            proxy = undefined;
 			        }
 			    }
 			}
 		}
 		
 		var reconnectSubscriber = function(appName, appModuleName) {
 			 var compactAppModuleName = appModuleName.replace(" ", "");
        	 var proxy = subscribers[appName + "_" + compactAppModuleName];
        	 proxy.connection.start().pipe(function () {
                 console.log(" restarted subscriber: " + appName + " " + appModuleName + " connection Id=" + proxy.connection.id);
             });
 		}

 		var startPolling = function (appName, appModuleName, subscriberCallback) {
 		    var pollInterval = $interval(subscriberCallback, 10000);
 		    var compactAppModuleName = appModuleName.replace(" ", "");
 		    subscribers[appName + "_" + compactAppModuleName] = pollInterval;
 		}
 		 
        return {
        	isSubscribed: isSubscribed,
        	subscribe:subscribe,
        	disconnectSubscriber: disconnectSubscriber
        };
    }
}());
