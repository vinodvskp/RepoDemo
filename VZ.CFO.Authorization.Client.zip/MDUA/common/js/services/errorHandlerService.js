(function () {

    angular.module('common').factory('errorHandlerService', ['$rootScope',errorHandlerService]);

    function errorHandlerService($rootScope) {
    	var errors = [];

        var addError = function (errorMsg) {
        	errors.push({ type: "alert-danger", message: errorMsg });
        };

        $rootScope.$on('$stateChangeSuccess',
			function(event, toState, toParams, fromState, fromParams){
			    //event.preventDefault();
        	if(toState.name !="error") {
        		errors.length = 0;
        	}
    	});      
        return {
        	addError: addError,
            errors: errors
        };
    }
}());