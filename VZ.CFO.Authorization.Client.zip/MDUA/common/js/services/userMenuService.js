(function (module) {

    var userMenuService = function () {

        var userMenu =[];

        var storeUserMenu = function (val) {
        	userMenu =val;
        };        
	    var  getUserMenu = function (){
	         return userMenu;
	    }
      
	    function hasMenuItemAccess(menu, displayName) {
            var hasAccess = false;
            if (menu) {
                for (var i = 0; i < menu.length; i++) {
                    if (menuItem = menu[i].Name == displayName) {
                        hasAccess = true;
                        return hasAccess;
                    }
                    if(hasAccess == false) {
                    	hasAccess = hasMenuItemAccess(menu[i].SubMenus, displayName);
                    }
                }
            }
            else {
                hasAccess = false;
            }
            return hasAccess;
        }

        
        return {           
            getUserMenu:getUserMenu,
            storeUserMenu:storeUserMenu,
            hasMenuItemAccess:hasMenuItemAccess
        };
        
    };

    module.factory("userMenuService", userMenuService);

}(angular.module("common")))
