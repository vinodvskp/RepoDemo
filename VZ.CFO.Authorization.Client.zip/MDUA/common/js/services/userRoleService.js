(function (module) {

    function userRoleService($q, $http, authenticationService, serverVariableService)  {
        var self = this;
        self.userRole = {};
        self.userManagementRole ="";
        self.VM_ROLE = {READ:"READ",TRACKING:"TRACKING",EDIT:"EDIT"};
       
        self.getUserRole = function() {
        	return self.userRole;
        }
        
        self.getUserVersionManagementRole = function() {
        	return self.userManagementRole;
        }
        self.loadUserRole = function(payload, successCallback, errorCallback) { 
        	authenticationService.serviceCallDispatcher(payload, loadUserRoleWorker ,successCallback,errorCallback);
        }
        
        function identifyUserVerisonManagementRole (userRole) {
        	var vmRole ='';
        	var vmRoles = $.grep(userRole, function (c) { return c.m_type == 'MDMFramework.VM.0'; });
        	if($.grep(vmRoles, function (c) { return c.m_value == self.VM_ROLE.EDIT; }).length > 0) {
        		vmRole = self.VM_ROLE.EDIT;
        	}
        	else if ($.grep(vmRoles, function (c) { return c.m_value == self.VM_ROLE.TRACKING; }).length > 0) {
        		vmRole = self.VM_ROLE.TRACKING
        	}
        	else if($.grep(vmRoles, function (c) { return c.m_value == self.VM_ROLE.READ; }).length > 0) {
        		vmRole  = self.VM_ROLE.READ;
        	}
        	return vmRole;
        }
        
        function loadUserRoleWorker(authToken, payload) {
        	return $http({
                 method: 'GET',
                 headers: {'Authorization': authToken },
                 url: serverVariableService.MDUA_USERS_ENDPOINT() +'/GetRolesFromAuthToken'
             })
             .then(function(response) {
            	 if(response.status == 200) {
            		 self.userRole = response.data;
            		 self.userManagementRole = identifyUserVerisonManagementRole(self.userRole); 
            		 return $q.when("User role loaded");
            	 }
           		 else {
           			 return $q.reject("Failed to get user role.");
           		  }
              }, function(response){
              	var resp = response;
              	
              	return $q.reject(resp);
              });
        }   
    };

    module.service("userRoleService", ['$q','$http','authenticationService','serverVariableService', userRoleService]);

}(angular.module("common")))