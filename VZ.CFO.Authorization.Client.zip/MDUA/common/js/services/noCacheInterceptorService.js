(function () {

	    angular.module('common').factory('noCacheInterceptorService', noCacheInterceptorService);

	    function noCacheInterceptorService() {
	        var noCacheOperations = ["GetAllMappingTables",
		                             "GetMappingTableFirstPageData",
		                             "GetMappingTablePageData",
		                             "GetMappingTableFirstPageDataFromLowerEnv",
		                             "GetMappingTablePageDataFromLowerEnv"
		                             ];
		    var enableNoCache = function(url) {
		    	var enable = false;
		    	for(i=0; i< noCacheOperations.length; i++) {
		    		if(url.indexOf(noCacheOperations[i]) > -1) {
		    			enable = true;
		    			break;	
		    		}
		    	}
		    	return enable;
		    }
		    
	        return {
	            request: function (config) {
	                if(config.method.toUpperCase()=='GET' && enableNoCache(config.url)){
	                    var separator = config.url.indexOf('?') === -1 ? '?' : '&';
	                    config.url = config.url+separator+'noCache=' + new Date().getTime();
	                    //console.log(config.url);
	                }
	                return config;
	           }
	       };
	    	
	    }
}());

    