(function () {
    angular.module('common').factory('confirmModalService', ['$uibModal',confirmModalService]);

    function confirmModalService($uibModal) {
    	
       function createConfirmModal (message, showComment) {
    	   var commentHtml = "";
    	   if(showComment == true) {
    		   commentHtml =' <form class="form-horizontal">'
    			            + '<div style="margin-top:15px;">'
    			            + '    <div style="top-margin:10px;display:inline-block;vertical-align:middle;">Comment</div>'
                            + '    <div style="display:inline-block;vertical-align:middle;"><textarea rows="4" cols="30" ng-model="cc.comment"></textarea></div>'
    						+ '</div>'
    		                +' </form>';
    	   }
    	   var modalInstance = $uibModal.open({
 			  template: '<div class="modal-header">'
 					+ '<h4 class="modal-title" id="modal-title">Confirm</h4>'
 					+ '</div>'
 					+ '<div class="modal-body" id="modal-body" style="text-align:center;">'
 					+ message
 					+ commentHtml
 					+ '</div>'
 					+ '<div class="modal-footer" style="text-align:center;">'
 					+ '	<button class="btn btn-primary" type="button" ng-click="cc.ok()">OK</button>'
 					+ '	<button class="btn btn-default" type="button" ng-click="cc.cancel()">Cancel</button>'
 					+ '</div>', 
 			  controller: ['$uibModalInstance',function ($uibModalInstance){
 				 var self = this;
 				  self.comment ="";
 				  self.ok = function ($event) {
 				       $uibModalInstance.close(self.comment);
 				  }
 				  self.cancel = function () {
 					$uibModalInstance.dismiss('cancel');
 				  };
 			
 			 	}],
 			  controllerAs:'cc',
 			  ariaLabelledBy: 'modal-title',
 			  ariaDescribedBy: 'modal-body'
 			});
    	   return modalInstance;
       }
        return {
        	createConfirmModal: createConfirmModal
        };
    }
}());
