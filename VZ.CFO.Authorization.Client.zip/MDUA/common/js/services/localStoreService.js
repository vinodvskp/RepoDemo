(function (module) {

    var localStoreService = function () {

        var empEid='';

        var addEmpEid = function (val) {
              empEid=val;
        };

        function getEmpEid(){
              return empEid;
        }

        return {           
            addEmpEid:addEmpEid,
            getEmpEid: getEmpEid
        };
        
    };

    module.factory("localStoreService", localStoreService);

}(angular.module("common")))
