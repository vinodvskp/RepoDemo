﻿
(function (module) {
    var fileDrop = function () {
        return {
            restrict: "EAC",
            //transclude: true,
            scope: {
                data: "="
            },
            template: "<p class=\"cus-file-drop dropper\">Drag the excel file you want to upload into this box or <a class=\"file-upload-text\">" +
                       "<u>Click here to browse</u></a><input type=\"file\" class=\"file-upload-ctrl\" /></p>",
            link: function (scope, elm, attrs) {
                if (typeof window.FileReader === 'undefined')
                    alert('File API & FileReader not supported');

                var dropper = $(elm)[0];
                dropper.ondragover = function () { $(dropper).addClass('hover'); return false; };
                dropper.ondragend = function () { $(dropper).removeClass('hover'); return false; };
                dropper.ondrop = function (e) {
                    e.preventDefault();
                    var files = [].slice.call(e.dataTransfer.files);
                    files.forEach(function (file) {
                        var reader = new FileReader();
                        reader.onload = function (event) {
                            fileLoaded(file.name, event.target.result); 
                        };
                        reader.readAsDataURL(file);
                        $(dropper).removeClass('hover');
                    });
                    return false;
                };

                $(elm).on("change", ".file-upload-ctrl", function (e) {
                    debugger;
                    var file = $(this)[0].files[0];
                    var reader = new FileReader();
                    reader.readAsDataURL(file);
                    reader.onload = function (event) {
                        fileLoaded(file.name, event.target.result);
                    };
                    console.log(e);
                });

                function fileLoaded(filename, dataUri) {
                    var strArray = dataUri.split(",");
                    var base64Str = strArray[strArray.length - 1];
                    scope.data = {
                        name: filename,
                        fileData: base64Str
                    };

                    scope.$apply();
                }
            }
        };
    };
    module.directive("fileDrop", fileDrop);
}(angular.module("common")));
{ }