(function (module) {
    var errorHandler = function ($templateCache, errorHandlerService) {
        return {
            restrict: "AE",
            template: $templateCache.get('fdm_alerts.html'),
            link: function (scope) {
                scope.currentAlerts = errorHandlerService.errors;
            }
        };
    };
    module.directive("errorHandler", ['$templateCache','errorHandlerService',errorHandler]);
}(angular.module("common")));