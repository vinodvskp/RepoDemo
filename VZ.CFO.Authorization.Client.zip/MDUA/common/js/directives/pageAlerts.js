﻿(function (module) {
    var alerts = function ($templateCache,alerting) {
        return {
            restrict: "AE",
            template: $templateCache.get('fdm_alerts.html'),
            link: function (scope) {
                scope.currentAlerts = alerting.currentAlerts;
            }
        };
    };
    module.directive("pageAlerts", ['$templateCache','alertingService',alerts]);
}(angular.module("common")));