﻿using System;
using System.Collections;
using System.Drawing;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using MDUA.BusinessLogic;
using MDUA.DataAccess;
using MDUA.DTO;
using System.Collections.Generic;
using System.Web.UI;

public partial class OpsFileTypes : System.Web.UI.Page
{
    #region events 

    protected void Page_Load(object sender, EventArgs e) {
        Master.PageTitle = "Input File Definition";
        //Master.NavInstructionsVisible = true;
        Master.Message = "";

        if (Master.curUser.Role != UserRole.Admin) {
            if (!Master.curUser.CanAddNewFileType) {
                try {
                    Master.PendingMessage = "You don't have access to add new Input Files.";
                    Server.Transfer("~/Default.aspx");
                } catch (System.Threading.ThreadAbortException) {
                    // thread was aborted ... do nothing
                }
            }
        }

        if (IsPostBack) {
            if (ddlCube.SelectedValue.Trim().Length > 0) {
                if (hfFactId.Value.Length > 0) {
                    FillFileTypesTable();
                    SetTargetRelatedInformation((FactTable)int.Parse(hfFactId.Value));
                }
            }            
        } else {
            chkShowOnly.Checked = true;
            fillFactDropDown();
        }
    }

    protected void btnSave_Click(object sender, EventArgs e) {
        // jevans 12/23/2010 - hide file types when editing or adding 
        tblFileTypes.Visible = false;

        if (txtCode.Text.Trim().Length == 0) {            
            ddlCube_SelectedIndexChanged(sender, e);
            Master.Message = "You must supply a file type.";
            return;
        }
        
        if (txtDescription.Text.Trim().Length == 0) {            
            ddlCube_SelectedIndexChanged(sender, e);
            Master.Message = "You must supply a description for the file type.";
            return;
        }
        

        if (txtCode.Enabled) {
            txtCode.Text = txtCode.Text.ToUpper().Trim();
            FileType hftExist = Utils.GetFileType(txtCode.Text, "");
            if (hftExist != null) {                
                ddlCube_SelectedIndexChanged(sender, e);
                Master.Message = string.Format("The Input File Code already exists for {0}", hftExist.Description);
                return;
            }
        }

        if (chkUserFeed.Checked) {
            if (txtCode.Text.IndexOf("ADJ") == -1 && txtCode.Text.IndexOf("USR") == -1) {                
                ddlCube_SelectedIndexChanged(sender, e);
                Master.Message = "The File Type Code must contain either ADJ or USR for a user feed.";
                return;
            } 
        } else {
            if (txtCode.Text.IndexOf("ADJ") >= 0 || txtCode.Text.IndexOf("USR") >= 0) {                
                ddlCube_SelectedIndexChanged(sender, e);
                Master.Message = "The Input File Code cannot contain either ADJ or USR for NON user feeds.";
                return;
            }
        }

        FileType fileType = new FileType();
        fileType.FactTableId = int.Parse(hfFactId.Value);
        fileType.FileTypeCode = txtCode.Text.Trim();
        fileType.Description = txtDescription.Text.Trim();
        fileType.ScheduledLoadDate = txtScheduledDte.Text.Trim();
        fileType.IsAdjustment = chkAdjustment.Checked;
        fileType.IsOutlook = chkOutlook.Checked;
        fileType.Is13Month = chk13Month.Checked;
        fileType.IsUserFeed = chkUserFeed.Checked;
        fileType.ShowOnUploadStatus = chkShowOnUploadPage.Checked;
        fileType.UsesValidKeyCombos = chkValidKeyCombos.Checked;
        fileType.DestinationTable = hfFactName.Value;
               
        //  Validate the dimension fields.
        string[] dimensions = hfDimensions.Value.Split(';');
        foreach (string dim in dimensions) {
            if (dim.Length == 0) {
                continue;
            }

            if (!IsValidDimension(dim, ref fileType)) {
                tblFileTypes.Visible = false;
            }

        }
        // if any DIM error found, stop processing 
        if (Master.Message.Length > 0) {
            return;
        }

        // Capture Custom Attributes settings
        Control control;
        if (hfCustomAttributes.Value.Trim() !="" && hfCustomAttributes.Value.Split('|').Length > 0) { 
            foreach (string id in hfCustomAttributes.Value.Split('|')) {
                control = tblFields.FindControl(id);
                if (control.ID.StartsWith("CA_chk")) {
                    fileType.fields.Add(new FileTypeField(control.ID.Substring(6), ((CheckBox)control).Checked ? "Y" : "N", FileTypeFieldSource.CustomAttributeField));
                } else if (control.ID.StartsWith("CA_txt")) {
                    fileType.fields.Add(new FileTypeField(control.ID.Substring(6), ((TextBox)control).Text, FileTypeFieldSource.CustomAttributeField));
                } else if (control.ID.StartsWith("CA_ddl")) {
                    fileType.fields.Add(new FileTypeField(control.ID.Substring(6), ((DropDownList)control).SelectedValue, FileTypeFieldSource.CustomAttributeField));
                }
            }
        }


        if (!Utils.AddUpdateInputFile(fileType, Master.curUser.EmployeeID)) {
            Master.Message = HypMDUA.ERROR_MESSAGE;
            //tblFileTypes.Visible = false;
            return;
        } else {
            Utils.LogEvent(Master.curUser.EmployeeID, "OpsFileTypes.aspx", "Add/Update Input File",
                string.Format("Input File {0} was added/updated", txtCode.Text), UserToolLogLevel.Audit);

            Master.Message = "The Input File was successfully " + (txtCode.Enabled == true ? "Added." : "Updated.");
            
            ddlCube.SelectedIndex = -1;
            pnlDetails.Visible = false;
            tblFileTypes.Visible = false;
            btnCancel.Visible = false;
        }
     
    }

    protected void btnEdit_Click(object sender, EventArgs e) {
             
        ImageButton ib = (ImageButton)sender;
        FileType fileType = Utils.GetFileType(ib.CommandArgument, "");
        if (fileType == null)
            return;
        // jevans 12/23/2010 - hide file types when editing or adding 
        tblFileTypes.Visible = false;
         //  Select this fact table from the drop down list.
        if (!hfFactId.Value.Equals(fileType.FactTableId.ToString())) {
            foreach (ListItem item in ddlCube.Items) {
                if (item.Value.StartsWith(fileType.FactTableId.ToString() + ";")) {
                    item.Selected = true;
                    hfFactId.Value = fileType.FactTableId.ToString();
                    hfFactName.Value = item.Value.Substring(hfFactId.Value.Length + 1);
                } else {
                    item.Selected = false;
                }
            }
        }
        SetTargetRelatedInformation((FactTable)fileType.FactTableId);
        
        ClearFileTypeInfo();
        btnCancel.Visible = true;

        chkAdjustment.Checked = fileType.IsAdjustment;
        chk13Month.Checked = fileType.Is13Month;
        chkOutlook.Checked = fileType.IsOutlook;
        chkShowOnUploadPage.Checked = fileType.ShowOnUploadStatus;
        chkUserFeed.Checked = fileType.IsUserFeed;
        chkValidKeyCombos.Checked = fileType.UsesValidKeyCombos;

        txtCode.Text = fileType.FileTypeCode;
        txtDescription.Text = fileType.Description;
        txtScheduledDte.Text = fileType.ScheduledLoadDate;

        foreach (FileTypeField field in fileType.fields) {
            if (field.Source == FileTypeFieldSource.CustomAttributeField) {
                CheckBox checkBox = (CheckBox)tblFields.FindControl("CA_chk" + field.FactColumnName);
                if (checkBox != null) {
                    checkBox.Checked = field.ForcedValue.ToUpper().Trim().Equals("Y");
                } else {
                    TextBox textBox = (TextBox)tblFields.FindControl("CA_txt" + field.FactColumnName);
                    if (textBox != null) {
                        textBox.Text = field.ForcedValue;
                    } else {
                        DropDownList dropDownList = (DropDownList)tblFields.FindControl("CA_ddl" + field.FactColumnName);
                        if (dropDownList != null) {
                            dropDownList.SelectedValue = field.ForcedValue;
                        }
                    }
                }
            } else {
                TextBox tb = (TextBox)tblFields.FindControl("txt" + field.FactColumnName);
                if (tb != null) {
                    tb.Text = field.ForcedValue;
                } 
                DropDownList ddl = (DropDownList)tblFields.FindControl("ddl" + field.FactColumnName);
                if (ddl != null) {
                  ddl.SelectedValue = ((int)field.Source).ToString();
                }
            }
        }
        txtCode.Enabled = false;
        //txtDescription.Focus();
        btnSave.Text = "Update";
    }

    protected void btnDel_Click(object sender, EventArgs e)
    {
        //  Do this to fill in the values in the edit fields.
        btnEdit_Click(sender, e);
        txtCode.Enabled = true;
        btnSave.Text = "Add";
        btnCancel.Visible = false;

        ImageButton ib = (ImageButton)sender;
        if (Utils.DeleteInputFileType(ib.CommandArgument, Master.curUser.EmployeeID) == false)
        {
            Master.Message = HypMDUA.ERROR_MESSAGE;
            return;
        }

        btnSave.Text = "Add";
        FillFileTypesTable();
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        btnCancel.Visible = false;
        ClearFileTypeInfo();
        //txtCode.Focus();

        FillFileTypesTable();
    }

    protected void chkShowOnly_CheckedChanged(object sender, EventArgs e)
    {
        ddlCube_SelectedIndexChanged(sender, e);
    }

    protected void ddlCube_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlCube.SelectedValue.Trim().Length == 0)
        {
            pnlDetails.Visible = false;
            Master.Message = "Please select a fact table";
            return;
        }
        //    Master.Message = "";

        string[] FactInfo = ddlCube.SelectedValue.Split(';');
        hfFactId.Value = FactInfo[0];
        if (FactInfo.Length > 1)
            hfFactName.Value = FactInfo[1];

        pnlDetails.Visible = true;
        ClearFileTypeInfo();
        SetTargetRelatedInformation((FactTable)Convert.ToInt32(FactInfo[0]));
        //FillDimensionsTable();
        FillFileTypesTable();
        //SetFactTableSpecifics();
    }
    
    #endregion

    #region displays 

    private void fillFactDropDown() {
        List<FactTableDTO> factTables = Utils.GetFactTableNames();
        foreach (FactTableDTO f in factTables.ToArray()) {
            this.ddlCube.Items.Add(new ListItem(f.FactTableDescription, f.FactTableId));
        }
    }
   
    private void FillFileTypesTable() {

        // jevans 12/23/2010 - make sure this table is visible in case previous action was 'add' or 'edit'
        tblFileTypes.Visible = true;
        int factTableId = 0;
        // jevans 4/19/2012 - if fact isnt populated, exit 
        if (!int.TryParse(hfFactId.Value, out factTableId))
            return;
        List<FileType> fileTypes = Utils.GetFileTypes(chkShowOnly.Checked ? factTableId : 0, "");
        fileTypes.Sort();

        //Color alternatingBackgroundColor = Color.FromArgb(231, 242, 254); //#E7F2FE
        //Color backgroundColor = Color.White;
        int MainRowCnt = 0;
      
        while (tblFileTypes.Rows.Count > 1)
            tblFileTypes.Rows.RemoveAt(1);
        
        foreach (FileType fileType in fileTypes) {
            //  If this isn't an admin, don't show none user feeds.
            if (Master.curUser.Role != UserRole.Admin && !fileType.IsUserFeed)
                continue;

            ++MainRowCnt;

            //  Create a row for the budget group.
            TableRow row = new TableRow();
            row.HorizontalAlign = HorizontalAlign.Left;
            //row.BackColor = (((MainRowCnt & 1) == 1) ? backgroundColor : alternatingBackgroundColor);
            tblFileTypes.Rows.Add(row);

            TableCell cell;

            //  Add the icons to edit and delete this item.
            cell = new TableCell();
            cell.HorizontalAlign = HorizontalAlign.Center;

            ImageButton imageButton = new ImageButton();
            imageButton.ImageUrl = "~/Images/Delete.gif";
            imageButton.CommandArgument = fileType.FileTypeCode;
            imageButton.Click += btnDel_Click;
            imageButton.ID = string.Format("btnDel{0}", fileType.FileTypeCode);
            imageButton.AlternateText = "Delete Input File";
            imageButton.Attributes["onmouseover"] = "this.src='Images/DeleteHilite.gif'";
            imageButton.Attributes["onmouseout"] = "this.src='Images/Delete.gif'";

            HtmlGenericControl spn = new HtmlGenericControl();
            spn.TagName = "span";
            spn.Attributes["onclick"] = string.Format("return confirm('Do you really want to delete the {0} ({1}) Input File?')",
                fileType.Description, fileType.FileTypeCode);
            spn.Controls.Add(imageButton);
            cell.Controls.Add(spn);
            //}

            Literal lit = new Literal();
            lit.Text = "&nbsp;";
            cell.Controls.Add(lit);

            imageButton = new ImageButton();
            imageButton.ImageUrl = "~/Images/TextFile.gif";
            imageButton.CommandArgument = fileType.FileTypeCode;
            imageButton.Click += btnEdit_Click;
            imageButton.ID = string.Format("btnEdt{0}", fileType.FileTypeCode);
            imageButton.AlternateText = "Edit File Type";
            imageButton.Attributes["onmouseover"] = "this.src='Images/TextFileHilite.gif'";
            imageButton.Attributes["onmouseout"] = "this.src='Images/TextFile.gif'";
            cell.Controls.Add(imageButton);
            row.Cells.Add(cell);

            cell = new TableCell();
            cell.Text = fileType.FileTypeCode;
            row.Cells.Add(cell);

            cell = new TableCell();
            cell.Text = fileType.Description;
            row.Cells.Add(cell);

            cell = new TableCell();
            foreach (ListItem item in ddlCube.Items) {
                if (item.Value.Equals(fileType.FactTableId.ToString() + ";" + fileType.DestinationTable)) {
                    cell.Text = "Table: <b>" + item.Text + "</b><br/>";
                    break;
                }
            }

            cell.Text += "Load Date: <b>" + fileType.ScheduledLoadDate + "</b><br/>";
            cell.Text += string.Format("Is User Feed: <b>{0}</b><br/>", fileType.IsUserFeed ? "Yes" : "No");
            cell.Text += string.Format("Is an Adjustment: <b>{0}</b><br/>", fileType.IsAdjustment ? "Yes" : "No");
            cell.Text += string.Format("Has 13 Months: <b>{0}</b><br/>", fileType.Is13Month ? "Yes" : "No");
            cell.Text += string.Format("Is Outlook Data: <b>{0}</b><br/>", fileType.IsOutlook ? "Yes" : "No");
            cell.Text += string.Format("Validates Key Combos: <b>{0}</b><br/>", fileType.UsesValidKeyCombos ? "Yes" : "No");
            cell.Text += string.Format("Show on Status Page: <b>{0}</b><br/>", fileType.ShowOnUploadStatus ? "Yes" : "No");
            row.Cells.Add(cell);


            cell = new TableCell();
            cell.Text = "";
            foreach (FileTypeField fileTypeField in fileType.fields)
            {
                if (fileTypeField.Source == FileTypeFieldSource.ForcedValue) {
                    cell.Text += string.Format("{0}= {1}<br/>", fileTypeField.FactColumnName, fileTypeField.ForcedValue);
                } else if (fileTypeField.Source == FileTypeFieldSource.CustomAttributeField) { // this condition must come before next condition in order to display properly
                    cell.Text += string.Format("{0}= {1} (Custom Field)<br/>", fileTypeField.FactColumnName, fileTypeField.ForcedValue);
                } else if (fileTypeField.Source >= FileTypeFieldSource.AutomapOnAccount || fileTypeField.Source == FileTypeFieldSource.UserDefinableUserFeed) {
                    cell.Text += fileTypeField.FactColumnName + string.Format("= ({0})<br/>", fileTypeField.Source);
                } 
            }
            row.Cells.Add(cell);
        }
    }
    
    private bool IsValidDimension(string dimension, ref FileType fileType) {
        FactTable selectedFactTable = (FactTable)int.Parse(hfFactId.Value);
        TextBox tbField = (TextBox)tblFields.FindControl("txt" + dimension);
        if (tbField == null)
            return false;

        DropDownList ddl = (DropDownList)tblFields.FindControl("ddl" + dimension);
        if (ddl == null)
            return false;

        int fieldSource = int.Parse(ddl.SelectedValue);
        // jevans 1/7/2011 - if forced value, must have value
        if (fieldSource != (int)FileTypeFieldSource.ForcedValue) {
            if (tbField.Text.Length > 0) {
                Master.Message += string.Format("{0} was supplied a value, but Data Source is not set to 'Use Forced Value'<br>", dimension);
                return true;
            }
        }
        if (fieldSource == (int)FileTypeFieldSource.UserFeed)
           return true;

        /* the hidden field contains 
         *  0 Dim Table, 
         *  1 Validation Field
         *  2 dim name and 
         *  3 alias 
         *  4 extra validation
        */
        HiddenField hf = (HiddenField)tblFields.FindControl("hf" + dimension);
        string[] hiddenFields = hf.Value.Split('|');

        if (fieldSource == (int)FileTypeFieldSource.ForcedValue) {
            tbField.Text = tbField.Text.Trim();//.ToUpper();
            if (tbField.Text.Length == 0) {
                Master.Message += string.Format("{0} is set to forced value, but no value is supplied<br>", hiddenFields[2]);
                return false;
            }

            ReturnCodeDTO rc;
            //  validate the dimension forced value
            // select tablename validationfield from dimtable ALIASNAME where alias.valfield = 'fieldtext'  

            switch (selectedFactTable) {
                case FactTable.ProductOfferUser: rc = ProductOfferDatabaseAccess.ValidateDimensionValue(hiddenFields[2], tbField.Text); break;
                case FactTable.EquipmentUser: rc = EquipmentDatabaseAccess.ValidateDimensionValue(hiddenFields[2], tbField.Text); break;
                case FactTable.PlanningActuals: rc = PlanningActualsDatabaseAccess.ValidateDimensionValue(hiddenFields[2], tbField.Text); break;
                case FactTable.DevicePaymentLoan: rc = DevicePaymentLoanDatabaseAccess.ValidateDimensionValue(hiddenFields[2], tbField.Text); break;
                default: rc = Utils.ValidDimension(hiddenFields[2], hiddenFields[1], hiddenFields[0], hiddenFields[3], tbField.Text, hiddenFields[4]); break;
            }
            
            if (!rc.Success) {
                Master.Message = HypMDUA.ERROR_MESSAGE;
                return false;
            } else {
                if (rc.ReturnCode == 1) {
                    Master.Message += rc.Message + "<br>";
                    return false;
                }
            }

        } // end of if forced value 
       
        FileTypeField fileTypeField = new FileTypeField();
        fileTypeField.FactColumnName  = dimension;
        fileTypeField.Source = (FileTypeFieldSource)fieldSource;
        fileTypeField.ForcedValue = tbField.Text;

        fileType.fields.Add(fileTypeField);
        return true;
    }

    private void ClearFileTypeInfo()  {
        txtCode.Enabled = true;
        txtCode.Text = "";
        txtDescription.Text = "";
        txtScheduledDte.Text = "";
        Master.Message = "";

        string[] dimensions = hfDimensions.Value.Split(';');
        foreach (string dimension in dimensions) {
            TextBox tb = (TextBox)tblFields.FindControl("txt" + dimension);
            if (tb != null) {
                tb.Text = "";
            } 
            DropDownList ddl = (DropDownList)tblFields.FindControl("ddl" + dimension);
            if (ddl != null) {
                ddl.SelectedValue = "0";
            }            
        }

        string[] customControlNames = this.hfCustomAttributes.Value.Split('|');
        foreach (string controlName in customControlNames) {
            Control control = tblFields.FindControl(controlName);
            if (control is CheckBox) {
                ((CheckBox)control).Checked = false;
            } else if (control is DropDownList) {
                ((DropDownList)control).SelectedIndex = 0;
            } else if (control is TextBox) {
                ((TextBox)control).Text = string.Empty;                    
            }
        }

        ddlDestTbl.SelectedIndex = 0;
        chkAdjustment.Checked = false;
        chk13Month.Checked = false;
        chkOutlook.Checked = false;
        chkShowOnUploadPage.Checked = false;
        chkUserFeed.Checked = false;
        chkValidKeyCombos.Checked = false;

        btnSave.Text = "Add";
    }
    
    private void SetTargetRelatedInformation(FactTable selectedTarget) {
        MasterFactTable factTable = Utils.GetFactTable(((int)selectedTarget).ToString(), "", Master.curUser.EmployeeID);
        chkAdjustment.Enabled = factTable.AllowsAdjustments;
        chkOutlook.Enabled = factTable.AllowsOutlook;
        
        //  If the fact table has a Key Combination table supplied, it can validate key combos.
        chkValidKeyCombos.Enabled = (factTable.KeyComboTableName.Length > 0);

        List<CustomTargetAttribute> customAttributes = GeneralDatabaseAccess.GetCustomAttributes(selectedTarget);
        List<AutomapFieldInfo> automapFields = GeneralDatabaseAccess.GetAutomapFields(selectedTarget);
        List<MasterDimension> dimensions = Utils.GetFactDimensions(selectedTarget, false, false, true);
        dimensions.Sort();

        hfDimensions.Value = "";
        while (tblFields.Rows.Count > 1)
            tblFields.Rows.RemoveAt(1);

        foreach (MasterDimension dimension in dimensions) {
            hfDimensions.Value += dimension.FactColumnName + ";";

            //  Create a row for the budget group.
            TableRow row = new TableRow();
            row.HorizontalAlign = HorizontalAlign.Left;
            tblFields.Rows.Add(row);

            TableCell cell; 
            cell = new TableCell();
            cell.HorizontalAlign = HorizontalAlign.Right;
            Label label = new Label();
            label.Text = dimension.DimensionLabel + ":";
            //label.ForeColor = Color.Blue;
            cell.Controls.Add(label); //  Add the Dimension Label
            row.Cells.Add(cell);

            DropDownList ddl = new DropDownList();
            ddl.ID = "ddl" + dimension.FactColumnName;

            // add standard dimension field options
            ddl.Items.Add(new ListItem("Data from User Feed", "0"));
            ddl.Items.Add(new ListItem("User Feed / User Definable", "1"));
            ddl.Items.Add(new ListItem("Use Forced Value", "2"));

            // add automap options if configured
            foreach (AutomapFieldInfo fieldInfo in automapFields) {
                if (fieldInfo.ColumnName.ToUpper() == dimension.FactColumnName.ToUpper()) {
                    ddl.Items.Add(new ListItem(fieldInfo.Description, fieldInfo.AutomapId));
                }
            }           

            cell = new TableCell();
            cell.Controls.Add(ddl);
            row.Cells.Add(cell);

            TextBox tb = new TextBox();
            tb.ID = "txt" + dimension.FactColumnName;
            cell = new TableCell();
            cell.Controls.Add(tb);
            row.Cells.Add(cell);

            //  Hidden Field to have 
            HiddenField hf = new HiddenField();
            hf.ID = "hf" + dimension.FactColumnName;
            //  Dim Table, Validation Field, dim name and alias 
            hf.Value = string.Format("{0}|{1}|{2}|{3}|",
                dimension.MasterTable, dimension.ValidationColumn, dimension.DimensionTypeName, dimension.TableAlias);
            hf.Value += dimension.ExtraValidationClause;
            cell.Controls.Add(hf);
        }

        List<string> attributeIds = new List<string>();

        if (customAttributes.Count > 0) {
            TableRow row = new TableRow();
            row.HorizontalAlign = HorizontalAlign.Left;
            row.Font.Bold = true;
            //row.ForeColor = Color.Blue;
            tblFields.Rows.Add(row);
            row.Cells.Add(new TableCell());
            TableCell cell = new TableCell();
            cell.ColumnSpan = 2;
            cell.Text = "Custom fields:";
            row.Cells.Add(cell);
        }
        
        foreach (CustomTargetAttribute attribute in customAttributes) {
            TableRow row = new TableRow();
            row.HorizontalAlign = HorizontalAlign.Left;
            tblFields.Rows.Add(row);

            TableCell cell;
            Label label;

            switch (attribute.AttributeType) {
                case CustomAttributeType.TextBox:
                    cell = new TableCell();
                    cell.HorizontalAlign = HorizontalAlign.Right;
                    label = new Label();
                    label.Text = attribute.AttributeName + ":";
                    //label.ForeColor = Color.Blue;
                    cell.Controls.Add(label); 
                    row.Cells.Add(cell);
                   
                    TextBox textBox = new TextBox();
                    textBox.ID = "CA_txt" + attribute.ColumnName;
                    attributeIds.Add(textBox.ID);
                    cell = new TableCell();
                    cell.Controls.Add(textBox);
                    row.Cells.Add(cell);
                    break;
                case CustomAttributeType.DropDownList:
                    cell = new TableCell();
                    cell.HorizontalAlign = HorizontalAlign.Right;
                    label = new Label();
                    label.Text = attribute.AttributeName + ":";
                    //label.ForeColor = Color.Blue;
                    cell.Controls.Add(label); 
                    row.Cells.Add(cell);

                    DropDownList list = new DropDownList();
                    list.ID = "CA_ddl" + attribute.ColumnName;
                    attributeIds.Add(list.ID);
                    foreach (string dropdownItem in attribute.DropdownItems) {
                        list.Items.Add(new ListItem(dropdownItem, dropdownItem));
                    }
                    cell = new TableCell();
                    cell.Controls.Add(list);
                    row.Cells.Add(cell);
                    break;
                case CustomAttributeType.CheckBox:
                    row.Cells.Add(new TableCell());
                    cell = new TableCell();
                    cell.ColumnSpan = 2;
                    CheckBox checkBox = new CheckBox();
                    checkBox.ID = "CA_chk" + attribute.ColumnName;
                    attributeIds.Add(checkBox.ID);
                    checkBox.Text = attribute.AttributeName;
                    //checkBox.ForeColor = Color.Blue;
                    cell.Controls.Add(checkBox);
                    row.Cells.Add(cell);
                    break;
            }

        }
        hfCustomAttributes.Value = string.Join("|", attributeIds.ToArray());
    
    }

    #endregion

}

