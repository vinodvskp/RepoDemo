﻿using System;
using System.Collections;
using System.Drawing;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
//using MDUA.DataAccess;
using MDUA.BusinessLogic;

public partial class UserInputNewFileType : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Master.PageTitle = "User Input File Types";
        Master.NavInstructionsVisible = true;
        if (Master.curUser.Role != UserRole.Admin)
        {
            if (Master.curUser.CanAddNewFileType == false)
            {
                Master.PendingMessage = "You don't have access to Add New File Types.";
                Server.Transfer("~/Default.aspx");
                return;
            }
            chkUserFeed.Checked = true;
            chkUserFeed.Enabled = false;
        }

        if (IsPostBack == false)
        {
            hlReportingLine.HRef = string.Format("javascript:SearchTree('{0}','{1}')",
                txtReportingLine.ClientID, "REPORTINGLINE");
            hlAccount.HRef = string.Format("javascript:SearchTree('{0}','{1}')",
                txtAccount.ClientID, "ACCOUNT");
            hlKPI.HRef = string.Format("javascript:SearchTree('{0}','{1}')",
                txtKPI.ClientID, "KPI");
            hlView.HRef = string.Format("javascript:SearchTree('{0}','{1}')",
                txtView.ClientID, "VIEW");
            hlYears.HRef = string.Format("javascript:SearchTree('{0}','{1}')",
                txtYears.ClientID, "YEARS");
            hlScenario.HRef = string.Format("javascript:SearchTree('{0}','{1}')",
                txtScenario.ClientID, "SCENARIO");
            hlProduct.HRef = string.Format("javascript:SearchTree('{0}','{1}')",
                txtProduct.ClientID, "PRODUCT");
            hlSubAccount.HRef = string.Format("javascript:SearchTree('{0}','{1}')",
                txtSubAccount.ClientID, "SUBACCOUNT");
            hlServiceType.HRef = string.Format("javascript:SearchTree('{0}','{1}')",
                txtServiceType.ClientID, "SERVICETYPE");
            hlFunction.HRef = string.Format("javascript:SearchTree('{0}','{1}')",
                txtFunction.ClientID, "FUNCTION");
            hlCostCenter.HRef = string.Format("javascript:SearchTree('{0}','{1}')",
                txtCostCenter.ClientID, "COSTCENTER");
            hlEntity.HRef = string.Format("javascript:SearchTree('{0}','{1}')",
                txtEntity.ClientID, "ENTITY");
            hlEquipment.HRef = string.Format("javascript:SearchTree('{0}','{1}')",
                txtEquipment.ClientID, "EQUIPMENT");
            hlTechType.HRef = string.Format("javascript:SearchTree('{0}','{1}')",
                txtTechType.ClientID, "TECHTYPE");

            ArrayList arrDests = Utils.LoadLookupType("DEST_TBL", Master.curUser.EmployeeID);
            foreach (HypWebLookup wl in arrDests)
            {
                ListItem li = new ListItem(wl.Value, string.Format("{0};{1}", wl.Description, wl.Extra));
                ddlDestTbl.Items.Add(li);
            }
        }
        FillTable();
    }

    private void FillTable()
    {
        ArrayList arrFileTypes = Utils.GetInputFiles("", "");
        arrFileTypes.Sort();

        Color AltBgnd = Color.FromArgb(231, 242, 254); //#E7F2FE
        Color RegBgnd = Color.White;
        int MainRowCnt = 0;

        while (tblFileTypes.Rows.Count > 1)
            tblFileTypes.Rows.RemoveAt(1);

        foreach (HypFileType hft in arrFileTypes)
        {
            //  If this isn't an admin, don't show none user feeds.
            if (Master.curUser.Role != UserRole.Admin &&
                hft.isUserFeed == false)
                continue;

            if (hft.DestTable.ToUpper().StartsWith("RPT_") == false)
                continue;

            ++MainRowCnt;

            //  Create a row for the budget group.
            TableRow tr = new TableRow();
            tr.HorizontalAlign = HorizontalAlign.Left;
            tr.BackColor = (((MainRowCnt & 1) == 1) ? RegBgnd : AltBgnd);
            tblFileTypes.Rows.Add(tr);

            TableCell tc;

            //  Add the icons to edit and delete this item.
            tc = new TableCell();
            tc.HorizontalAlign = HorizontalAlign.Center;

            ImageButton imgbtn = null;
     
            //if (Master.curUser.Role == UserRole.Admin)
            //{
            imgbtn = new ImageButton();
            imgbtn.ImageUrl = "~/Images/Delete.bmp";
            imgbtn.CommandArgument = hft.Code;
            imgbtn.Click += btnDel_Click;
            imgbtn.ID = string.Format("btnDel{0}", hft.Code);
            imgbtn.AlternateText = "Delete File Type";
            imgbtn.Attributes["onmouseover"] = "this.src='Images/DeleteHilite.bmp'";
            imgbtn.Attributes["onmouseout"] = "this.src='Images/Delete.bmp'";

            HtmlGenericControl spn = new HtmlGenericControl();
            spn.TagName = "span";
            spn.Attributes["onclick"] = string.Format("return confirm('Do you really want to delete the {0} ({1}) File Type?')",
                hft.Description, hft.Code);
            spn.Controls.Add(imgbtn);
            tc.Controls.Add(spn);
            //}

            Literal lit = new Literal();
            lit.Text = "&nbsp;";
            tc.Controls.Add(lit);

            imgbtn = new ImageButton();
            imgbtn.ImageUrl = "~/Images/TextFile.gif";
            imgbtn.CommandArgument = hft.Code;
            imgbtn.Click += btnEdit_Click;
            imgbtn.ID = string.Format("btnEdt{0}", hft.Code);
            imgbtn.AlternateText = "Edit File Type";
            imgbtn.Attributes["onmouseover"] = "this.src='Images/TextFileHilite.gif'";
            imgbtn.Attributes["onmouseout"] = "this.src='Images/TextFile.gif'";
            tc.Controls.Add(imgbtn);
            tr.Cells.Add(tc);

            tc = new TableCell();
            tc.Text = hft.Code;
            tr.Cells.Add(tc);

            tc = new TableCell();
            tc.Text = hft.Description;
            tr.Cells.Add(tc);

            tc = new TableCell();
            tc.HorizontalAlign = HorizontalAlign.Center;
            tc.Text = (hft.isAdjustment ? "Adjustment" : "") +
                (hft.isOutlook ? " Outlook " : "");
            tr.Cells.Add(tc);

            tc = new TableCell();
            tc.Text = hft.ScheduledLoadDate;
            tr.Cells.Add(tc);

            tc = new TableCell();
            foreach (HypFileTypeFlds tFld in hft.arrFlds)
            {
                if (tFld.Source == HypFileTypeFldSource.ForcedValue)
                    tc.Text += string.Format("{0}={1}<br/>", tFld.MemberName, tFld.ForcedValue);
                else if (tFld.Source >= HypFileTypeFldSource.AutomapOnAccount ||
                    tFld.Source == HypFileTypeFldSource.UserDefinableUserFeed)
                    tc.Text += tFld.MemberName + string.Format("=({0})<br/>", tFld.Source);
            }
            tr.Cells.Add(tc);
        }
    }
    protected void btnAdd_Click(object sender, EventArgs e)
    {
        if (txtCode.Text.Trim().Length == 0)
        {
            Master.Message = "You must supply a file type.";
            return;
        }

        if (txtDescription.Text.Trim().Length == 0)
        {
            Master.Message = "You must supply a description for the file type.";
            return;
        }

        if (txtCode.Enabled == true)
        {
            ArrayList arrFileTypes = Utils.GetInputFiles("", "");
            arrFileTypes.Sort();

            int Idx = arrFileTypes.BinarySearch(txtCode.Text.Trim());
            if (Idx >= 0)
            {
                Master.Message = string.Format("The File Type Code already exists for {0}",
                    ((HypFileType)arrFileTypes[Idx]).Description);
                return;
            }
        }

        if (ddlDestTbl.SelectedValue.Trim().Length == 0)
        {
            Master.Message = "You must select a Destination Fact table.";
            return;
        }

        string[] DestTables = ddlDestTbl.SelectedValue.Split(';');
        if (chkAdjustment.Checked && (DestTables.Length < 2 || DestTables[1].Trim().Length == 0))
        {
            Master.Message = "You specified that the File Type is an adjustment, but the Destination Fact Table does not have an adjustment table defined.";
            return;
        }

        if (chkUserFeed.Checked == true)
        {
            if (txtCode.Text.IndexOf("ADJ") == -1 &&
                txtCode.Text.IndexOf("USR") == -1)
            {
                Master.Message = "The File Type Code must contain either ADJ or USR for a user feed.";
                return;
            }
            /*
            if (chkAdjustment.Checked == true && txtCode.Text.IndexOf("ADJ") == -1)
            {
                Master.Message = "The Input File Code must contain ADJ for Adjustments.";
                return;
            }

            if (chkAdjustment.Checked == false && txtCode.Text.IndexOf("USR") == -1)
            {
                Master.Message = "The Input File Code must contain USR for Non-Adjustments.";
                return;
            }
            */
        }
        else
        {
            if (txtCode.Text.IndexOf("ADJ") >= 0 &&
                txtCode.Text.IndexOf("USR") >= 0)
            {
                Master.Message = "The File Type Code can not contain either ADJ or USR for NON user feeds.";
                return;
            }
        }

        if (chkUserFeed.Checked == false && Master.curUser.Role != UserRole.Admin)
        {
            Master.Message = "Only Administrators can add or modify non user feeds.";
            return;
        }

        HypFileType hft = new HypFileType();
        hft.Code = txtCode.Text.Trim();
        hft.Description = txtDescription.Text.Trim();
        hft.ScheduledLoadDate = txtScheduledDte.Text.Trim();
        hft.isAdjustment = chkAdjustment.Checked;
        hft.isOutlook = chkOutlook.Checked;
        hft.isUserFeed = chkUserFeed.Checked;
        hft.ShowOnUploadStatus = chkShowOnUploadPage.Checked;
        hft.UsesValidKeyCombos = chkValidKeyCombos.Checked;
        hft.DestTable = (chkAdjustment.Checked ? DestTables[1] : DestTables[0]);

        string msg = string.Empty;
        if (Utils.IsValidDimension(txtReportingLine.Text, "REPORTINGLINE", "Reporting Line", false,
            "DIM_RPT_REPORTNGLINE", ddlReportingLine.SelectedValue, ref hft, out msg) == false)
            return;
        if (Utils.IsValidDimension(txtAccount.Text , "ACCOUNT", "Account", false,
            "DIM_RPT_ACCOUNT", ddlAccount.SelectedValue, ref hft, out msg) == false)
            return;
        if (Utils.IsValidDimension(txtKPI.Text, "KPI", "KPI", false,
            "DIM_RPT_KPI", ddlKPI.SelectedValue, ref hft, out msg) == false)
            return;
        if (Utils.IsValidDimension(txtView.Text, "VIEW", "View", false,
            "DIM_RPT_VIEW", ddlView.SelectedValue, ref hft, out msg) == false)
            return;
        if (Utils.IsValidDimension(txtYears.Text, "YEARS", "Years", true,
            "DIM_RPT_YEARS", ddlYears.SelectedValue, ref hft, out msg) == false)
            return;
        if (Utils.IsValidDimension(txtScenario.Text, "SCENARIO", "Scenario", false,
            "DIM_RPT_SCENARIO", ddlScenario.SelectedValue, ref hft, out msg) == false)
            return;
        if (Utils.IsValidDimension(txtProduct.Text, "PRODUCT", "Product", false,
            "DIM_RPT_PRODUCT", ddlProduct.SelectedValue, ref hft, out msg) == false)
            return;
        if (Utils.IsValidDimension(txtSubAccount.Text, "SUBACCOUNT", "SubAccount", false,
            "DIM_RPT_SUBACCOUNT", ddlSubAccount.SelectedValue, ref hft, out msg) == false)
            return;
        if (Utils.IsValidDimension(txtServiceType.Text, "SERVICETYPE", "Service Type", false,
            "DIM_RPT_SERVICETYPE", ddlServiceType.SelectedValue, ref hft, out msg) == false)
            return;
        if (Utils.IsValidDimension(txtFunction.Text, "FUNCTION", "Function", false,
            "DIM_RPT_FUNCTION", ddlFunction.SelectedValue, ref hft, out msg) == false)
            return;
        if (Utils.IsValidDimension(txtCostCenter.Text, "COSTCENTER", "Cost Center", false,
            "DIM_RPT_COSTCENTER", ddlCostCenter.SelectedValue, ref hft, out msg) == false)
            return;
        if (Utils.IsValidDimension(txtEntity.Text, "ENTITY", "Entity", false,
            "DIM_RPT_ENTITY", ddlEntity.SelectedValue, ref hft, out msg) == false)
            return;
        //* jevans 12/19/2010 - added equip and tech type
        /*
        if (Utils.IsValidDimension(txtEQUIPMENT.Text, "EQUIPMENT", "EQUIPMENT", false,
            "DIM_RPT_EQUIPMENT", ddlEQUIPMENT.SelectedValue, ref hft, out msg) == false)
            return;
        if (Utils.IsValidDimension(txtEntity.Text, "ENTITY", "Entity", false,
            "DIM_RPT_ENTITY", ddlEntity.SelectedValue, ref hft, out msg) == false)
            return;
        */

        if (ddlFunction.SelectedValue == ((int)HypFileTypeFldSource.AutomapOnCostCenter).ToString() &&
            ddlCostCenter.SelectedValue == ((int)HypFileTypeFldSource.AutomapOnFunction).ToString())
        {
            Master.Message = "Function and Cost Center can not be auto mapped to each other.";
            return;
        }

        if (Utils.AddUpdateFileType(hft, Master.curUser.EmployeeID) == false)
            Master.Message = "There was an error trying to add/update the File Type.";
        else
        {
            Utils.LogEvent(Master.curUser.EmployeeID, "UserInputNewFileType.aspx", "Add/Update File Type",
                string.Format("File Type {0} was added/updated", txtCode.Text), LogLevel.Audit);

            Master.Message = "The new File Type was successfully " + (txtCode.Enabled == true ? "Added." : "Updated.");
            ClearFileTypeInfo();
            txtCode.Enabled = true;
            txtCode.Focus();
            btnCancel.Visible = false;
        }
        FillTable();
    }

   
    protected void btnEdit_Click(object sender, EventArgs e)
    {
        ImageButton ib = (ImageButton)sender;
        HypFileType hft = Utils.GetInputFile(ib.CommandArgument, "");
        if (hft == null)
            return;

        ClearFileTypeInfo();
        btnCancel.Visible = true;

        chkAdjustment.Checked = hft.isAdjustment;
        chkOutlook.Checked = hft.isOutlook;
        chkShowOnUploadPage.Checked = hft.ShowOnUploadStatus;
        chkUserFeed.Checked = hft.isUserFeed;
        chkValidKeyCombos.Checked = hft.UsesValidKeyCombos;

        txtCode.Text = hft.Code;
        txtDescription.Text = hft.Description;
        txtScheduledDte.Text = hft.ScheduledLoadDate;

        ddlDestTbl.SelectedIndex = 0;
        string Strts = hft.DestTable + ";";
        string Ends = ";" + hft.DestTable;
        for (int i = 1; i < ddlDestTbl.Items.Count; i++)
        {
            if (ddlDestTbl.Items[i].Value.StartsWith(Strts) == true ||
                ddlDestTbl.Items[i].Value.EndsWith(Ends) == true)
            {
                ddlDestTbl.SelectedIndex = i;
                break;
            }
        }

        foreach (HypFileTypeFlds tFld in hft.arrFlds)
        {
            if (tFld.MemberName.Equals("DIM_RPT_REPORTNGLINE"))
            {
                txtReportingLine.Text = tFld.ForcedValue;
                ddlReportingLine.SelectedValue = ((int)tFld.Source).ToString();
            }
            else if (tFld.MemberName.Equals("DIM_RPT_ACCOUNT"))
            {
                txtAccount.Text = tFld.ForcedValue;
                ddlAccount.SelectedValue = ((int)tFld.Source).ToString();
            }
            else if (tFld.MemberName.Equals("DIM_RPT_KPI"))
            {
                txtKPI.Text = tFld.ForcedValue;
                ddlKPI.SelectedValue = ((int)tFld.Source).ToString();
            }
            else if (tFld.MemberName.Equals("DIM_RPT_VIEW"))
            {
                txtView.Text = tFld.ForcedValue;
                ddlView.SelectedValue = ((int)tFld.Source).ToString();
            }
            else if (tFld.MemberName.Equals("DIM_RPT_YEARS"))
            {
                txtYears.Text = tFld.ForcedValue;
                ddlYears.SelectedValue = ((int)tFld.Source).ToString();
            }
            else if (tFld.MemberName.Equals("DIM_RPT_SCENARIO"))
            {
                txtScenario.Text = tFld.ForcedValue;
                ddlScenario.SelectedValue = ((int)tFld.Source).ToString();
            }
            else if (tFld.MemberName.Equals("DIM_RPT_PRODUCT"))
            {
                txtProduct.Text = tFld.ForcedValue;
                ddlProduct.SelectedValue = ((int)tFld.Source).ToString();
            }
            else if (tFld.MemberName.Equals("DIM_RPT_SUBACCOUNT"))
            {
                txtSubAccount.Text = tFld.ForcedValue;
                ddlSubAccount.SelectedValue = ((int)tFld.Source).ToString();
            }
            else if (tFld.MemberName.Equals("DIM_RPT_SERVICETYPE"))
            {
                txtServiceType.Text = tFld.ForcedValue;
                ddlServiceType.SelectedValue = ((int)tFld.Source).ToString();
            }
            else if (tFld.MemberName.Equals("DIM_RPT_FUNCTION"))
            {
                txtFunction.Text = tFld.ForcedValue;
                ddlFunction.SelectedValue = ((int)tFld.Source).ToString();
            }
            else if (tFld.MemberName.Equals("DIM_RPT_COSTCENTER"))
            {
                txtCostCenter.Text = tFld.ForcedValue;
                ddlCostCenter.SelectedValue = ((int)tFld.Source).ToString();
            }
            else if (tFld.MemberName.Equals("DIM_RPT_ENTITY"))
            {
                txtEntity.Text = tFld.ForcedValue;
                ddlEntity.SelectedValue = ((int)tFld.Source).ToString();
            }
        }
        txtCode.Enabled = false;
        txtDescription.Focus();
        btnAdd.Text = "Update";
    }

    protected void btnDel_Click(object sender, EventArgs e)
    {
        //  Do this to fill in the values in the edit fields.
        btnEdit_Click(sender, e);
        txtCode.Enabled = true;
        btnAdd.Text = "Add";
        btnCancel.Visible = false;

        ImageButton ib = (ImageButton)sender;
        if (Utils.DeleteFileType(ib.CommandArgument, Master.curUser.EmployeeID) == false)
        {
            Master.Message = "There was an error trying to delete the new File Type.";
            return;
        }

        btnAdd.Text = "Add";
        FillTable();
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        btnCancel.Visible = false;
        ClearFileTypeInfo();
        txtCode.Focus();

        FillTable();
    }

    private void ClearFileTypeInfo()
    {
        txtCode.Enabled = true;
        txtCode.Text = "";
        txtDescription.Text = "";
        txtScheduledDte.Text = "";
        txtReportingLine.Text = "";
        txtAccount.Text = "";
        txtKPI.Text = "";
        txtView.Text = "";
        txtYears.Text = "";
        txtScenario.Text = "";
        txtProduct.Text = "";
        txtSubAccount.Text = "";
        txtServiceType.Text = "";
        txtFunction.Text = "";
        txtCostCenter.Text = "";
        txtEntity.Text = "";
        ddlReportingLine.SelectedValue = "0";
        ddlAccount.SelectedValue = "0";
        ddlKPI.SelectedValue = "0";
        ddlView.SelectedValue = "0";
        ddlYears.SelectedValue = "0";
        ddlScenario.SelectedValue = "0";
        ddlProduct.SelectedValue = "0";
        ddlSubAccount.SelectedValue = "0";
        ddlServiceType.SelectedValue = "0";
        ddlFunction.SelectedValue = "0";
        ddlCostCenter.SelectedValue = "0";
        ddlEntity.SelectedValue = "0";
        ddlDestTbl.SelectedIndex = 0;
        chkAdjustment.Checked = false;
        chkOutlook.Checked = false;
        chkShowOnUploadPage.Checked = false;
        chkUserFeed.Checked = false;
        chkValidKeyCombos.Checked = false;
        btnAdd.Text = "Add";
    }
}
