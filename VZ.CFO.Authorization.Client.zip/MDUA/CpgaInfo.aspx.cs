﻿using System;
using System.Collections;
using System.Data;
using System.Drawing;
using System.IO;
using System.Web.UI.WebControls;
using MDUA.BusinessLogic;
using MDUA.DataAccess;
using MDUA.DTO;

public partial class CpgaInfo : System.Web.UI.Page
{
    private ArrayList arrTriggers = null;
    private ArrayList arrPatterns = null;
    private ArrayList arrSplitFunc = null;
    private ArrayList arrEntities = null;
    private ArrayList arrLookup = null;
    private string BuildCPGAProcCode = "BUILDCPGA";
    private string LoadRulesProcCode = "LOADRULES";
    private string CPGAAsRelatesTo = "CPGA";
    private string TmpTriggerTblName = "CPGA_TMPTRIGGERS";
    private string TmpPatternTblName = "CPGA_TMPPATTERNS";
    private string TmpSplitFuncTblName = "cpga_tmpsplitfunction";
    private string TmpOvrrdesTblName = "CPGA_TMPENTITY_OVRRDES_TBL";
    // jevans 3/14/2011 - use new stage tables for overlap 
    private string StgTriggerTblName = "CPGA_STAGE_TRIGGERS";
    private string StgPatternTblName = "CPGA_STAGE_PATTERNS";
    private string StgLookupTblName = "CPGA_STAGE_LOOKUP";
    
    private string FnlTriggerTblName = "CPGA_RULETRIGGERS";
    private string FnlPatternTblName = "CPGA_RULEPATTERNS";
    private string FnlSplitFuncTblName = "cpga_splitfunction";
    private string FnlOvrrdesTblName = "cpga_entity_ovrrdes_tbl";
    private string FnlLookupTblName = "cpga_lookup_tbl"; 
    private string WebDimTblName = "web_dimensions_tbl";

    protected void Page_Load(object sender, EventArgs e)
    {
        Master.PageTitle = "CPGA Processing";
        Table myTbl = WPUtil.BuildProgressBar(BuildCPGAProcCode, CPGAAsRelatesTo, 0, "Images", Master.curUser.UserId);
        if (myTbl != null)
            divProgBar.Controls.Add(myTbl);

        BasicOraReader Rdr = new BasicOraReader(DbAccess.GetOracleConnectionString());
        string Cmd = string.Format(@"SELECT a.endtime FROM rpt_process_status_tbl a
  where ProcessCode='{0}' and AsRelatesTo='{1}' and Status='S'
  order by ProcessId desc",
            LoadRulesProcCode, CPGAAsRelatesTo);
        if (Rdr.Open(Cmd) == true)
        {
            if (Rdr.oraRdr.Read() == true)
                lblLastLoaded.Text = Rdr.oraRdr.GetDateTime(0).ToString("MM/dd/yyyy HH:mm");
            else
                lblLastLoaded.Text = "Has not been loaded";
        }
        Rdr.Dispose();
    }
    protected void btnUpload_Click(object sender, EventArgs e)
    {
        if (fuUserFile.HasFile == false)
        {
            Master.Message = "You must select a CPGA Rule file to load.";
            return;
        }

        if (chkEntity.Checked == false && chkRules.Checked == false && chkSplit.Checked == false)
        {
            Master.Message = "You must checked at least 'Triggers and Patterns', Entities or Split Function.";
            return;
        }

        if (DbAccess.callCheckProcessRunning(BuildCPGAProcCode, CPGAAsRelatesTo, Master.curUser.UserId) > 0)
        {
            Master.Message = "The CPGA Build process is currently running, so the CPGA Rules can not be uploaded.";
            return;
        }

        if (DbAccess.callCheckProcessRunning(LoadRulesProcCode, CPGAAsRelatesTo, Master.curUser.UserId) > 0)
        {
            Master.Message = "Someone else is currently loading CPGA rules.";
            return;
        }

        Master.Message = "";

        int ProcessId = DbAccess.callAddNewProcess(LoadRulesProcCode, CPGAAsRelatesTo, null, "COMPLETE", "R", "Loading",
            Master.curUser.UserId, BuildCPGAProcCode, CPGAAsRelatesTo, Master.curUser.UserId);

        //  Check to see if the CPGA Build process is running.  If it is, don't let them load the 
        //  data.
        //BasicOraReader Rdr = new BasicOraReader(DbAccess.GetOracleConnStr());
        DataSet dsResult = null;
        string Filename = "";
        try
        {
            //  Upload the file and load the data based on the extension of the file.
            Filename = string.Format("Archive/{1}_{2}_{0}{3}",
                DateTime.Now.ToString("yyyyMMdd_HHmmss"),
                Master.curUser.UserId, "CPGAData",
                Path.GetExtension(fuUserFile.FileName));
            Filename = Server.MapPath(Filename);
            fuUserFile.SaveAs(Filename);

            //  Just in case there are errors, lets clear out the table now
            while (tblValErrs.Rows.Count > 1)
                tblValErrs.Rows.RemoveAt(1);

            string TotalMsg = "";
            InitializeExcelColArrays();
            bool bContinue = true;
            if (chkRules.Checked == true)
            {
                //  Load the data
                string Msg;
                int RecCnt = Utils.CopyExcelToTable(Filename, "ARuleTriggers", TmpTriggerTblName, true,
                    arrTriggers, out Msg, Master.curUser.UserId);
                if (RecCnt > 0)
                    TotalMsg += string.Format("<br>{0} records were validated from {1}.<br/>", RecCnt, "ARuleTriggers");
                else
                {
                    TotalMsg += "<br>An error occurred processing ARuleTriggers: " + Msg + "\r\n";
                    bContinue = false;
                }
                RecCnt = Utils.CopyExcelToTable(Filename, "SRuleTriggers", TmpTriggerTblName, false,
                     arrTriggers, out Msg, Master.curUser.UserId);
                if (RecCnt > 0)
                    TotalMsg += string.Format("<br>{0} records were validated from {1}.<br/>", RecCnt, "SRuleTriggers");
                else
                {
                    TotalMsg += "<br>An error occurred processing SRuleTriggers: " + Msg + "\r\n";
                    bContinue = false;
                }

                RecCnt = Utils.CopyExcelToTable(Filename, "CreateARuleDimPatterns", TmpPatternTblName, true,
                    arrPatterns, out Msg, Master.curUser.UserId);
                if (RecCnt > 0)
                    TotalMsg += string.Format("<br>{0} records were validated from {1}.<br/>", RecCnt, "CreateARuleDimPatterns");
                else
                {
                    TotalMsg += "<br>An error occurred processing CreateARuleDimPatterns: " + Msg + "\r\n";
                    bContinue = false;
                }

                RecCnt = Utils.CopyExcelToTable(Filename, "CreateSRuleDimPatterns", TmpPatternTblName, false,
                     arrPatterns, out Msg, Master.curUser.UserId);
                if (RecCnt > 0)
                    TotalMsg += string.Format("<br>{0} records were validated from {1}.<br/>", RecCnt, "CreateSRuleDimPatterns");
                else
                {
                    TotalMsg += "<br>An error occurred processing CreateSRuleDimPatterns: " + Msg + "\r\n";
                    bContinue = false;
                }
            }

            if (chkSplit.Checked == true)
            {
                string Msg;
                int RecCnt = Utils.CopyExcelToTable(Filename, "FunctionToSplitFunction", TmpSplitFuncTblName, true,
                     arrSplitFunc, out Msg, Master.curUser.UserId);
                if (RecCnt > 0)
                    TotalMsg += string.Format("<br>{0} records were validated from {1}.<br/>", RecCnt, "FunctionToSplitFunction");
                else
                {
                    TotalMsg += "<br>An error occurred processing FunctionToSplitFunction: " + Msg + "\r\n";
                    bContinue = false;
                }
            }

            if (chkEntity.Checked == true)
            {
                //  Load the data
                string Msg;
                int RecCnt = Utils.CopyExcelToTable(Filename, "EntityGenUpdates", TmpOvrrdesTblName, true,
                    arrEntities, out Msg, Master.curUser.UserId);
                if (RecCnt >= 0)
                    TotalMsg += string.Format("<br>{0} records were validated from {1}.<br/>", RecCnt, "EntityGenUpdates");
                else
                {
                    TotalMsg += "<br>An error occurred processing EntityGenUpdates: " + Msg + "\r\n";
                    bContinue = false;
                }
            }
            if (!bContinue)
            {
                Master.Message = TotalMsg + "<br><b>Because of errors encountered, no records were saved to the final tables.</b>";
                DbAccess.callEndProcessStep(ProcessId, "COMPLETE", "E", TotalMsg, Master.curUser.UserId);
                return;
            }
            else if (chkEntity.Checked == true || chkRules.Checked == true || chkSplit.Checked == true)
            {
                //  Call the Validation routines
                dsResult = DbAccess.callCpgaValidate(chkRules.Checked ? TmpTriggerTblName : null,
                    chkRules.Checked ? TmpPatternTblName : null,
                    chkSplit.Checked ? TmpSplitFuncTblName : null,
                    chkEntity.Checked ? TmpOvrrdesTblName : null, Master.curUser.UserId);
                if (dsResult == null)
                {
                    Master.Message = "<br>An error occurred calling the CPGA Stored Procedure.  The data could not be validated.";
                    DbAccess.callEndProcessStep(ProcessId, "COMPLETE", "E", "An error occurred calling the CPGA Stored Procedure.",
                        Master.curUser.UserId);
                    return;
                }

                if (dsResult.Tables[0].Rows.Count > 0)
                {
                    FillValErrTable(dsResult);
                    Master.Message = "<br>There are invalid records in the supplied CPGA Tables.";
                    DbAccess.callEndProcessStep(ProcessId, "COMPLETE", "E", "There was invalid data in the Rules File.",
                        Master.curUser.UserId);
                    return;
                }
            }

            if (chkRules.Checked == true)
            {
                string NotInTriggers, NotInPatterns;
                if (DbAccess.callCpgaValPatsTrigs(TmpTriggerTblName, TmpPatternTblName,
                    null, out NotInTriggers, out NotInPatterns, Master.curUser.UserId) == false)
                {
                    Master.Message = "<br>An error occurred calling the patterns and triggers validation routine.";
                    DbAccess.callEndProcessStep(ProcessId, "COMPLETE", "E", "An error occurred calling the patterns and triggers validation routine.",
                        Master.curUser.UserId);
                    return;
                }

                //  If a rule is defined in the triggers table, but not in the patterns table
                //  it is an error because we are expecting those triggers, but there will be 
                //  no matching data from the pattern.
                if (NotInPatterns.Length > 0)
                {
                    Master.Message = string.Format("The Rules [{0}] are defined in the triggers table, but there are no coresponding patterns.  Either define patterns for these rules or remove the rules from the triggers table.",
                        NotInPatterns);
                    DbAccess.callEndProcessStep(ProcessId, "COMPLETE", "E", Master.Message,
                        Master.curUser.UserId);
                    return;
                }

                //  If a rule is defined in the triggers table, but not in the patterns table
                //  it is an error because we are expecting those triggers, but there will be 
                //  no matching data from the pattern.
                if (NotInTriggers.Length > 0)
                {
                    TotalMsg += string.Format("<br>Warning: The Rules [{0}] are defined in the patterns table, but there are no matching rules in the triggers table.<br/>",
                        NotInTriggers);
                }
            }

            //  Everything validated OK.  Lets update the real tables.
            if (chkRules.Checked == true)
            {
                // jevans 3/14/2011 - moved to after overlap
                //CopyTmpToFinal(arrTriggers, TmpTriggerTblName, FnlTriggerTblName, true);
                //CopyTmpToFinal(arrPatterns, TmpPatternTblName, FnlPatternTblName, true);

                //  Check to see if there are any overlapped data.  These are warnings only.  
                //  We need to call explode first to make sure we have all the lookup items.
                WebSettings ws = DbAccess.LoadWebSetting(Master.curUser.EmployeeID);
                if (DbAccess.callCpgaExplode(TmpPatternTblName, TmpTriggerTblName, TmpSplitFuncTblName, StgLookupTblName, WebDimTblName, ws.CurrentPeriod, Master.curUser.EmployeeID) < 0)
                {
                    TotalMsg += "<br>An error occurred trying to load the lookup table.";
                    DbAccess.callEndProcessStep(ProcessId, "COMPLETE", "E", TotalMsg, Master.curUser.UserId);
                    Master.Message = TotalMsg;
                    return; 
                }
                else
                {
                    string WarnErr;
                    // jevans 4/6/11 copy tmp to stage 
                    CopyTmpToFinal(arrTriggers, TmpTriggerTblName, StgTriggerTblName, true);
                    CopyTmpToFinal(arrPatterns, TmpPatternTblName, StgPatternTblName, true);

                    // jevans 3/14/2011 - overlaps no receives stage table names 
                    dsResult = DbAccess.callCpgaOverlap(ws.CurrentPeriod, StgPatternTblName, StgTriggerTblName, StgLookupTblName, out WarnErr, Master.curUser.UserId);
                    if (dsResult == null)
                    {
                        TotalMsg += "<br>An error occurred calling the CPGA Overlap Stored Procedure.  The data could not be validated.<br/>";
                        DbAccess.callEndProcessStep(ProcessId, "COMPLETE", "E", TotalMsg, Master.curUser.UserId);
                        Master.Message = TotalMsg;
                        return;
                    }
                    else
                        if (dsResult.Tables[0].Rows.Count > 0)
                        {
                            FillOverlapTable(dsResult);
                            TotalMsg = "<br>Error: There are some intersections defined by multiple rules.<br/>";
                            Master.Message = TotalMsg;
                            DbAccess.callEndProcessStep(ProcessId, "COMPLETE", "E", TotalMsg, Master.curUser.UserId);
                            return;
                        }
                        else
                        {
                            // jevans 3/14/2011 - no overlaps, so move stage to final 
                            CopyTmpToFinal(arrLookup, StgLookupTblName, FnlLookupTblName, false);
                            CopyTmpToFinal(arrTriggers, StgTriggerTblName, FnlTriggerTblName, true);
                            CopyTmpToFinal(arrPatterns, StgPatternTblName, FnlPatternTblName, true);
                        }
                }
            }

            if (chkSplit.Checked == true)
                CopyTmpToFinal(arrSplitFunc, TmpSplitFuncTblName, FnlSplitFuncTblName, false);

            if (chkEntity.Checked == true)
                CopyTmpToFinal(arrEntities, TmpOvrrdesTblName, FnlOvrrdesTblName, false);

            Master.Message = TotalMsg + "<br><b>All records were loaded to final tables</b>";
            DbAccess.callEndProcessStep(ProcessId, "COMPLETE", "S", "CPGA Rules were successfully uploaded.",
                Master.curUser.UserId);
        }
        catch (Exception ex)
        {
            Master.Message += HypMDUA.ERROR_MESSAGE + "<BR>" + ex.Message;
            DbAccess.callEndProcessStep(ProcessId, "COMPLETE", "E", "An error occurred while trying to upload the CPGA data.",
                Master.curUser.UserId);
            GeneralDatabaseAccess.LogEvent(Master.curUser.UserId, "CpgaInfo.aspx", "btnUpload_Click", ex, UserToolLogLevel.Error);
        }
    }

    private void InitializeExcelColArrays()
    {
        ExcelToMapInfo etm = null;
        arrTriggers = new ArrayList();
        arrTriggers.Add(new ExcelToMapInfo("ReportingLine", "reportingline", 80));
        arrTriggers.Add(new ExcelToMapInfo("Account", "account", 80));
        arrTriggers.Add(new ExcelToMapInfo("Scenario", "scenario", 80));
        arrTriggers.Add(new ExcelToMapInfo("Product", "product", 80));
        arrTriggers.Add(new ExcelToMapInfo("SubAccount", "subaccount", 80));
        arrTriggers.Add(new ExcelToMapInfo("ServiceType", "servicetype", 80));
        arrTriggers.Add(new ExcelToMapInfo("Function", "function", 80));
        arrTriggers.Add(new ExcelToMapInfo("Equipment", "equipment", 80));
        arrTriggers.Add(new ExcelToMapInfo("TechType", "techtype", 80));
        arrTriggers.Add(new ExcelToMapInfo("StartDate", "start_time", ExcelToMapInfo.FldTypes.DbInteger));
        arrTriggers.Add(new ExcelToMapInfo("EndDate", "end_time", ExcelToMapInfo.FldTypes.DbInteger));
        etm = new ExcelToMapInfo("Rule", "rule", 20);
        etm.MustExist = true;
        arrTriggers.Add(etm);
        etm = new ExcelToMapInfo("SubRuleInd", "subrule", 10);
        etm.ValIfNull = " ";
        arrTriggers.Add(etm);

        arrPatterns = new ArrayList();
        etm = new ExcelToMapInfo("Rule", "rule", 20);
        etm.MustExist = true;
        arrPatterns.Add(etm);
        etm = new ExcelToMapInfo("SubRuleInd", "SubRule", 10);
        etm.ValIfNull = " ";
        arrPatterns.Add(etm);
        arrPatterns.Add(new ExcelToMapInfo("SeqNbr", "sequencenumber", ExcelToMapInfo.FldTypes.DbInteger));
        arrPatterns.Add(new ExcelToMapInfo("ReportingLine", "reportingline", 80));
        arrPatterns.Add(new ExcelToMapInfo("Account", "account", 80));
        arrPatterns.Add(new ExcelToMapInfo("Scenario", "scenario", 80));
        arrPatterns.Add(new ExcelToMapInfo("Product", "product", 80));
        arrPatterns.Add(new ExcelToMapInfo("SubAccount", "subaccount", 80));
        arrPatterns.Add(new ExcelToMapInfo("ServiceType", "servicetype", 80));
        arrPatterns.Add(new ExcelToMapInfo("Function", "function", 80));
        arrPatterns.Add(new ExcelToMapInfo("CostCenter", "CostCenter", 80));
        arrPatterns.Add(new ExcelToMapInfo("Equipment", "equipment", 80));
        arrPatterns.Add(new ExcelToMapInfo("TechType", "techtype", 80));
        etm = new ExcelToMapInfo("Operand", "operand", 80);
        etm.TrimValues = "()";
        arrPatterns.Add(etm);
        arrPatterns.Add(new ExcelToMapInfo("StartDate", "start_time", ExcelToMapInfo.FldTypes.DbInteger));
        arrPatterns.Add(new ExcelToMapInfo("EndDate", "end_time", ExcelToMapInfo.FldTypes.DbInteger));
        arrPatterns.Add(new ExcelToMapInfo("Percent", "percent", ExcelToMapInfo.FldTypes.DbInteger));

        arrLookup = new ArrayList();
        arrLookup.Add(new ExcelToMapInfo("ALLOCATION_RULE", "ALLOCATION_RULE", 50));
        arrLookup.Add(new ExcelToMapInfo("SUBRULE", "SUBRULE", 16));
        arrLookup.Add(new ExcelToMapInfo("DIMENSION_TYPE", "DIMENSION_TYPE", 50));
        arrLookup.Add(new ExcelToMapInfo("MEMBER_NAME", "MEMBER_NAME", 50));
        arrLookup.Add(new ExcelToMapInfo("ROLLUP_NAME", "ROLLUP_NAME", 50));
        arrLookup.Add(new ExcelToMapInfo("RULE_TYPE", "RULE_TYPE", 1));
        arrLookup.Add(new ExcelToMapInfo("CLOSEPERIOD", "CLOSEPERIOD", ExcelToMapInfo.FldTypes.DbInteger));

        arrSplitFunc = new ArrayList();
        etm = new ExcelToMapInfo("LEV0Function", "LEV0FUNC", 20);
        etm.MustExist = true;
        arrSplitFunc.Add(etm);
        arrSplitFunc.Add(new ExcelToMapInfo("LEV0FunctionAlias", "LEV0FUNCALIAS", 10));
        arrSplitFunc.Add(new ExcelToMapInfo("SplitFunction", "SPLITFUNC", 80));
        arrSplitFunc.Add(new ExcelToMapInfo("StartDate", "start_time", ExcelToMapInfo.FldTypes.DbInteger));
        arrSplitFunc.Add(new ExcelToMapInfo("EndDate", "end_time", ExcelToMapInfo.FldTypes.DbInteger));

        arrEntities = new ArrayList();
        etm = new ExcelToMapInfo("Entity", "Entity", 6);
        etm.MustExist = true;
        arrEntities.Add(etm);
        arrEntities.Add(new ExcelToMapInfo("CPGA", "CPGA", 50));
        arrEntities.Add(new ExcelToMapInfo("IncInDriver", "Include_for_driver", 1));
        arrEntities.Add(new ExcelToMapInfo("StartDate", "start_time", ExcelToMapInfo.FldTypes.DbInteger));
        arrEntities.Add(new ExcelToMapInfo("EndDate", "end_time", ExcelToMapInfo.FldTypes.DbInteger));
    }

    private int FillValErrTable(DataSet dsResult)
    {
        //Color AltBgnd = Color.FromArgb(231, 242, 254); //#E7F2FE
        //Color RegBgnd = Color.White;
        int MainRowCnt = tblValErrs.Rows.Count - 1;

        tblValErrs.Visible = true;

        foreach (DataRow dr in dsResult.Tables[0].Rows)
        {
            ++MainRowCnt;

            //  Create a row for the budget group.
            TableRow tr = new TableRow();
            //tr.BackColor = (((MainRowCnt & 1) == 1) ? RegBgnd : AltBgnd);
            tblValErrs.Rows.Add(tr);

            for (int c = 0; c < dsResult.Tables[0].Columns.Count; c++)
            {
                TableCell tc = new TableCell();
                tc.Text = string.Format("{0}", dr[c]);
                tr.Cells.Add(tc);
            }
        }
        dsResult.Dispose();
        return MainRowCnt;
    }

    private int FillOverlapTable(DataSet dsResult)
    {
        //Color AltBgnd = Color.FromArgb(231, 242, 254); //#E7F2FE
        //Color RegBgnd = Color.White;
        int MainRowCnt = tblOverlap.Rows.Count - 1;

        tblOverlap.Visible = true;
        tblOverlap.Rows[0].Cells.Clear();
        foreach (DataColumn dc in dsResult.Tables[0].Columns)
        {
            TableCell tchdr = new TableCell();
            tchdr.Text = dc.Caption.Length == 0 ? dc.ColumnName : dc.Caption;
            tblOverlap.Rows[0].Cells.Add(tchdr);
        }

        int NbrFlds = dsResult.Tables[0].Columns.Count;
        foreach (DataRow dr in dsResult.Tables[0].Rows)
        {
            ++MainRowCnt;

            //  Create a row for the budget group.
            TableRow tr = new TableRow();
            //tr.BackColor = (((MainRowCnt & 1) == 1) ? RegBgnd : AltBgnd);
            tblOverlap.Rows.Add(tr);

            for (int c = 0; c < NbrFlds; c++)
            {
                TableCell tc = new TableCell();
                tc.Text = string.Format("{0}", dr[c]);
                tr.Cells.Add(tc);
            }
        }
        dsResult.Dispose();
        return MainRowCnt;
    }

    private int CopyTmpToFinal(ArrayList arrColInfo, string TmpTblName, string FnlTblName, bool IncUpdateTime)
    {
        BasicOraCommand Wrtr = new BasicOraCommand(DbAccess.GetOracleConnectionString());

        Wrtr.Exec("Truncate Table " + FnlTblName);
        string ErrMsg = Wrtr.LastErrorMessage;
        if (ErrMsg.Length > 0)
            throw new Exception(string.Format("An error occurred trying to truncate the {0} table: {1}",
                FnlTblName, ErrMsg));
        string InsCols = "";

        foreach (ExcelToMapInfo em in arrColInfo)
        {
            if (InsCols.Length > 0)
                InsCols += ",";
            InsCols += em.TblColName;
        }

        string InsCmd = string.Format("insert into {0} ({1}{3}) (select {1}{4} from {2})",
            FnlTblName, InsCols, TmpTblName,
            IncUpdateTime ? ",update_time" : "",
            IncUpdateTime ? ",sysdate" : "");
        int RecCnt = Wrtr.ExecOpened(InsCmd);

        ErrMsg = Wrtr.LastErrorMessage;
        Wrtr.Dispose();
        if (ErrMsg.Length > 0)
            throw new Exception(string.Format("An error occurred trying to write data to the {0} table: {1}",
                FnlTblName, ErrMsg));

        return RecCnt;
    }

    protected void btnDownload_Click(object sender, EventArgs e)
    {
        string Filename = string.Format("Downloads/CPGA_{1}_{0}.xlsb",
            DateTime.Now.ToString("yyyyMMdd_HHmmss"),
            Master.curUser.UserId);
        Filename = Server.MapPath(Filename);

        string Msg;
        string TotalMsg = "";
        InitializeExcelColArrays();
        int RecCnt = Utils.CopyTableToExcel(Filename, "ARuleTriggers", "CPGA_RULETRIGGERS", true,
            arrTriggers, "rule like 'A%'", out Msg, Master.curUser.UserId);
        if (RecCnt < 0)
            TotalMsg += "An error occurred processing ARuleTriggers: " + Msg + "\r\n";

        RecCnt = Utils.CopyTableToExcel(Filename, "CreateARuleDimPatterns", "CPGA_RULEPATTERNS", true,
            arrPatterns, "rule like 'A%'", out Msg, Master.curUser.UserId);
        if (RecCnt < 0)
            TotalMsg += "An error occurred processing CreateARuleDimPatterns: " + Msg + "\r\n";

        RecCnt = Utils.CopyTableToExcel(Filename, "SRuleTriggers", "CPGA_RULETRIGGERS", true,
             arrTriggers, "rule like 'S%'", out Msg, Master.curUser.UserId);
        if (RecCnt < 0)
            TotalMsg += "An error occurred processing SRuleTriggers: " + Msg + "\r\n";

        RecCnt = Utils.CopyTableToExcel(Filename, "CreateSRuleDimPatterns", "CPGA_RULEPATTERNS", true,
             arrPatterns, "rule like 'S%'", out Msg, Master.curUser.UserId);
        if (RecCnt < 0)
            TotalMsg += "An error occurred processing CreateSRuleDimPatterns: " + Msg + "\r\n";

        RecCnt = Utils.CopyTableToExcel(Filename, "FunctionToSplitFunction", "CPGA_SPLITFUNCTION", true,
             arrSplitFunc, "", out Msg, Master.curUser.UserId);
        if (RecCnt < 0)
            TotalMsg += "An error occurred processing FunctionToSplitFunction: " + Msg + "\r\n";

        RecCnt = Utils.CopyTableToExcel(Filename, "EntityGenUpdates", "CPGA_ENTITY_OVRRDES_TBL", true,
            arrEntities, "", out Msg, Master.curUser.UserId);
        if (RecCnt < 0)
            TotalMsg += "An error occurred processing EntityGenUpdates: " + Msg + "\r\n";

        if (TotalMsg.Length > 0)
        {
            Master.Message = TotalMsg;
            return;
        }

        Response.Redirect(string.Format("DownloadFile.aspx?DocName={0}&Del=Y",
                Filename));
    }
    protected void btnBuild_Click(object sender, EventArgs e)
    {
        Master.Message = "The Build process has not been implemented yet.";
    }
}
         