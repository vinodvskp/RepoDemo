﻿using System;
using System.Collections;
using System.Configuration;
using System.Data.OleDb;
using System.Drawing;
using System.Text;
using System.Web.UI.WebControls;
using Oracle.DataAccess.Client;

public partial class LoadData : System.Web.UI.Page
{
    private string[] arrCoaCor = null;
    private ArrayList arrNodes = null;
    public delegate string DetermineDelCmd(BasicOraReader Rdr);

    protected void Page_Load(object sender, EventArgs e)
    {
        Master.PageTitle = "Load Database Data";

        if (Master.SignedIn(UserRole.Admin) == false)
            return;

        if (IsPostBack == false)
        {
            StringBuilder jsCmd = new StringBuilder();
            jsCmd.AppendLine(@"<script type=""text/javascript"">
function SetAllChecks(val)
{");
            jsCmd.AppendLine(string.Format("    document.getElementById('{0}').checked=val;", chkAccount.ClientID));
            jsCmd.AppendLine(string.Format("    document.getElementById('{0}').checked=val;", chkCostCenter.ClientID));
            jsCmd.AppendLine(string.Format("    document.getElementById('{0}').checked=val;", chkEntity.ClientID));
            jsCmd.AppendLine(string.Format("    document.getElementById('{0}').checked=val;", chkFunction.ClientID));
            jsCmd.AppendLine(string.Format("    document.getElementById('{0}').checked=val;", chkKPI.ClientID));
            jsCmd.AppendLine(string.Format("    document.getElementById('{0}').checked=val;", chkProduct.ClientID));
            jsCmd.AppendLine(string.Format("    document.getElementById('{0}').checked=val;", chkReporting.ClientID));
            jsCmd.AppendLine(string.Format("    document.getElementById('{0}').checked=val;", chkScenario.ClientID));
            jsCmd.AppendLine(string.Format("    document.getElementById('{0}').checked=val;", chkService.ClientID));
            jsCmd.AppendLine(string.Format("    document.getElementById('{0}').checked=val;", chkSubAccount.ClientID));
            jsCmd.AppendLine(string.Format("    document.getElementById('{0}').checked=val;", chkTime.ClientID));
            jsCmd.AppendLine(string.Format("    document.getElementById('{0}').checked=val;", chkView.ClientID));
            jsCmd.AppendLine(string.Format("    document.getElementById('{0}').checked=val;", chkYears.ClientID));
            jsCmd.AppendLine(string.Format("    document.getElementById('{0}').checked=val;", chkCompany.ClientID));

            jsCmd.AppendLine("}");
            jsCmd.AppendLine("</script>");
            litJScript.Text = jsCmd.ToString();
        }
    }
    protected void btnCopy_Click(object sender, EventArgs e)
    {
        if (fuDBAccess.HasFile == false)
        {
            Master.Message = "You need to select the DB Access file that has the data";
            return;
        }

        string DestFilename = Server.MapPath("Downloads\\" + fuDBAccess.FileName);
        //DestFilename = @"\\njwartm1\erpimpl\Essbase_ReArchitecture\Master Data Update Automation\Rptgt1C.mdb";
        fuDBAccess.SaveAs(DestFilename);

        if (chkAccount.Checked == true)
            lblAccount.Text = BulkCopyData(DestFilename, "Account", "ACCOUNT");
        if (chkFunction.Checked == true)
            lblFunction.Text = BulkCopyData(DestFilename, "Function", "FUNCTION");
        if (chkProduct.Checked == true)
            lblProduct.Text = BulkCopyData(DestFilename, "Product", "PRODUCT");
        if (chkReporting.Checked == true)
        {
            lblReporting.Text = BulkCopyData(DestFilename, "ReportingLine", "REPORTINGLINE");
            lblReporting.Text += CreateCoaCorTbl();
        }
        if (chkService.Checked == true)
            lblService.Text = BulkCopyData(DestFilename, "ServiceType", "SERVICETYPE");
        if (chkSubAccount.Checked == true)
            lblSubAccount.Text = BulkCopyData(DestFilename, "SubAccount", "SUBACCOUNT");
        if (chkCostCenter.Checked == true)
            lblCostCenter.Text = BulkCopyData(DestFilename, "CostCenter", "COSTCENTER");
        if (chkEntity.Checked == true)
            lblEntity.Text = BulkCopyData(DestFilename, "Entities", "ENTITY");
        if (chkKPI.Checked == true)
            lblKPI.Text = BulkCopyData(DestFilename, "KPI", "KPI");
        if (chkScenario.Checked == true)
            lblScenario.Text = BulkCopyData(DestFilename, "Scenario", "SCENARIO");
        if (chkView.Checked == true)
            lblView.Text = BulkCopyData(DestFilename, "View", "VIEW");
        if (chkTime.Checked == true)
            lblTime.Text = BulkCopyData(DestFilename, "Time", "TIME");
        if (chkYears.Checked == true)
            lblYears.Text = BulkCopyData(DestFilename, "Years", "YEARS");
        if (chkCompany.Checked == true)
            lblCompany.Text = BulkCopyData(DestFilename, "Company", "COMPANY");

        Utils.DeleteFile(DestFilename, Master.curUser.EmployeeID);

        btnValidate_Click(sender, e);
    }

    private string BulkCopyData(string SrcFilename, string SrcTable, string DimType)
    {
        string Status = "Error";
        DimType = DimType.ToUpper();
        try
        {
            // Connection String to import file
            string srcConn = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0}",
                SrcFilename);

            // Create Connection to import file
            using (OleDbConnection conn = new OleDbConnection(srcConn))
            {

                conn.Open();
                string Cmd = "select Parent, Member_Name, Alias, Consolidation, Storage, Two_Pass, Formula, [Comment], [Level], [Generation] from [" +
                    SrcTable + "]";

                OleDbCommand command = new OleDbCommand(Cmd, conn);

                using (OleDbDataReader dr = command.ExecuteReader())
                {
                    OracleConnection oraConn = new OracleConnection(DbAccess.GetOracleConnStr());
                    OracleCommand sqlCmd = null;
                    try
                    {
                        Cmd = string.Format("delete from WEB_DIMENSIONS_TBL where Dim_Type='{0}'", DimType);
                        oraConn.Open();
                        sqlCmd = new OracleCommand(Cmd, oraConn);
                        sqlCmd.ExecuteNonQuery();

                        if (DimType == DbAccess.AccountTblName)
                        {
                            sqlCmd.CommandText = Cmd = "delete from WEB_MAP_ACCOUNT_TBL";
                            sqlCmd.ExecuteNonQuery();
                        }
                        else if (DimType == DbAccess.CostCenterTblName)
                        {
                            sqlCmd.CommandText = Cmd = "delete from WEB_MAP_CostCenter_TBL";
                            sqlCmd.ExecuteNonQuery();
                        }
                        else if (DimType == DbAccess.FunctionTblName)
                        {
                            sqlCmd.CommandText = Cmd = "delete from WEB_MAP_Function_TBL";
                            sqlCmd.ExecuteNonQuery();
                        }

                        //Cmd = string.Format("insert into {0} (PARENT,MEMBER_NAME,ALIAS,CONSOLIDATION,DIM_STORAGE) values (:PARENT,:MEMBER_NAME,:ALIAS,:CONSOLIDATION,:DIM_STORAGE)",
                        //    DestTable);
                        //sqlCmd.CommandText = Cmd;
                        //OracleParameter opParent = sqlCmd.Parameters.Add(":PARENT", OracleDbType.Varchar2, 80);
                        //OracleParameter opMember = sqlCmd.Parameters.Add(":MEMBER_NAME", OracleDbType.Varchar2, 80);
                        //OracleParameter opAlias = sqlCmd.Parameters.Add(":ALIAS", OracleDbType.Varchar2, 80);
                        //OracleParameter opConsolidation = sqlCmd.Parameters.Add(":CONSOLIDATION", OracleDbType.Char, 1);
                        //OracleParameter opStorage = sqlCmd.Parameters.Add(":DIM_STORAGE", OracleDbType.Varchar2, 20);
                        //sqlCmd.Prepare();
                        int TotRecs = 0;
                        DateTime StartTime = DateTime.Now;

                        while (dr.Read() == true)
                        {
                            TotRecs++;
                            string Parent = "";
                            string Alias = "";
                            if (dr.IsDBNull(0) == false)
                                Parent = dr.GetString(0);
                            if (dr.IsDBNull(2) == false)
                                Alias = dr.GetString(2);
                            string TwoPass = dr.GetString(5);
                            string Formula = "";

                            if (dr.IsDBNull(6) == false)
                            {
                                Formula = dr.GetString(6);
                                if (Formula.Length > 4000)
                                    Formula = Formula.Substring(0, 4000);
                                Formula = Formula.Replace("'", "''");
                            }

                            string Comment = "";
                            if (dr.IsDBNull(7) == false)
                                Comment = dr.GetString(7).Replace("'", "''");

                            Cmd = string.Format("insert into Web_DIMENSIONS_TBL (DIM_TYPE,PARENT,MEMBER_NAME,ALIAS,CONSOLIDATION,DIM_STORAGE,TWO_PASS,FORMULA,FLD_COMMENT, Level_Nbr, Generation_Nbr,LAST_UPDATED) values ('{0}','{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}',TO_TIMESTAMP(LOCALTIMESTAMP, 'DD-MON-RR HH.MI.SSXFF PM'))",
                                DimType, Parent.ToUpper(), dr.GetString(1).ToUpper(), Alias.Replace("'", "''"),
                                dr.GetString(3), dr.GetString(4), TwoPass, Formula,
                                Comment, dr.GetString(8), dr.GetString(9));
                            sqlCmd.CommandText = Cmd;

                            //opParent.Value = Parent;
                            //opMember.Value = dr.GetString(1);
                            //opAlias.Value = Alias;
                            //opConsolidation.Value = dr.GetString(3)[0];
                            //opStorage.Value = dr.GetString(4);
                            sqlCmd.ExecuteNonQuery();
                        }
                        dr.Close();

                        TimeSpan ts = DateTime.Now.Subtract(StartTime);
                        Status = string.Format("Successfully added {0} records in {1}",
                            TotRecs, ts.ToString());
                    }
                    catch (Exception ex)
                    {
                        //  Log the error to a table.
                        DbAccess.LogEvent(Master.curUser.EmployeeID, "LoadData", Cmd, ex, LogLevel.Error);
                        Status = "Error: " + ex.Message;
                    }

                    if (sqlCmd != null)
                    {
                        sqlCmd.CommandText = "Commit";
                        try
                        {
                            sqlCmd.ExecuteNonQuery();
                        }
                        catch (Exception ex1)
                        {
                            Status = "Error: " + ex1.Message;
                        }
                    }

                    if (oraConn != null)
                    {
                        oraConn.Close();
                        oraConn.Dispose();
                    }
                }
            }

        }
        catch (System.Web.HttpException ex)
        {
            Status = "Error: " + ex.Message;
        }
        return Status;
    }

    private string CreateCoaCorTbl()
    {
        HypDimension root = Utils.BuildDimTree("REPORTINGLINE", Master.curUser.EmployeeID);
        if (root == null)
            return "  There was an error generating the COA/COR Table.";

        int ItemsAdded = 0;
        string CoaCors = ConfigurationManager.AppSettings["CoaCorRLs"];
        arrCoaCor = CoaCors.Split('|');
        arrNodes = new ArrayList();
        HypDimension CurNode = root;
        CheckChildrenForCoaCor(CurNode, false);

        if (arrNodes.Count > 0)
        {
            //  Add Items to CoaCor table
            BasicOraCommand Wrtr = new BasicOraCommand(DbAccess.GetOracleConnStr());
            Wrtr.Open();
            string Cmd = "delete from WEB_COACOR_RL_TBL";
            Wrtr.ExecOpened(Cmd);

            foreach (HypDimension Node in arrNodes)
            {
                Cmd = string.Format("insert into WEB_COACOR_RL_TBL values ('{0}')",
                    Node.MemberName);
                if (Wrtr.ExecOpened(Cmd) == 1)
                    ItemsAdded++;
            }

            Wrtr.Dispose();
        }
        return string.Format("  {0} Items added to the COR/COA Table.", ItemsAdded);
    }

    private void CheckChildrenForCoaCor(HypDimension CurNode, bool IncInArr)
    {
        if (CurNode == null)
            return;

        if (IncInArr == false)
        {
            foreach (string itm in arrCoaCor)
            {
                if (itm.Equals(CurNode.MemberName) == true)
                {
                    IncInArr = true;
                    break;
                }
            }
        }

        if (IncInArr == true)
            arrNodes.Add(CurNode);

        if (CurNode.arrChildren != null && CurNode.arrChildren.Count > 0)
        {
            foreach (HypDimension Node in CurNode.arrChildren)
                CheckChildrenForCoaCor(Node, IncInArr);
        }
    }

    private int CleanupTables()
    {
        ClearTable();

        BasicOraReader Rdr = new BasicOraReader(DbAccess.GetOracleConnStr());
        string Cmd = string.Format(@"Select d.PRP_RPT_SOURCE,d.dim_rpt_reportngline,d.dim_rpt_account,d.dim_rpt_kpi,
        d.dim_rpt_view,d.dim_rpt_scenario,d.dim_rpt_product,d.dim_rpt_subaccount,
        d.dim_rpt_servicetype,d.dim_rpt_function,d.dim_rpt_costcenter,d.dim_rpt_entity,d.dim_rpt_company,
    r.Member_Name as ReportingLine,a.Member_Name as Account,k.Member_Name as KPI,
    v.Member_Name as RptView,s.Member_Name as Scenario,
    p.Member_Name as Product,u.Member_Name as SubAccount,
    t.Member_Name as ServiceType,f.Member_Name as RptFunction,
    c.Member_Name as CostCenter,e.Member_Name as Entity,co.Member_name as Company
    from {0} d
    left outer join WEB_DIMENSIONS_TBL r on r.Member_Name=d.dim_rpt_reportngline and r.dim_storage <> 'Shared Member' and r.Dim_Type='REPORTINGLINE' and r.Level_Nbr='Lev0'
    left outer join WEB_DIMENSIONS_TBL a on a.Member_Name=d.dim_rpt_account and a.dim_storage <> 'Shared Member' and a.Dim_Type='ACCOUNT' and a.Level_Nbr='Lev0'
    left outer join WEB_DIMENSIONS_TBL k on k.Member_Name=d.dim_rpt_kpi and k.dim_storage <> 'Shared Member' and k.Dim_Type='KPI' and k.Level_Nbr='Lev0'
    left outer join WEB_DIMENSIONS_TBL v on v.Member_Name=d.dim_rpt_view and v.dim_storage <> 'Shared Member' and v.Dim_Type='VIEW' and v.Level_Nbr='Lev0'
    left outer join WEB_DIMENSIONS_TBL s on s.Member_Name=d.dim_rpt_scenario and s.dim_storage <> 'Shared Member' and s.Dim_Type='SCENARIO' and s.Level_Nbr='Lev0'
    left outer join WEB_DIMENSIONS_TBL p on p.Member_Name=d.dim_rpt_product and p.dim_storage <> 'Shared Member' and p.Dim_Type='PRODUCT' and p.Level_Nbr='Lev0'
    left outer join WEB_DIMENSIONS_TBL u on u.Member_Name=d.dim_rpt_subaccount and u.dim_storage <> 'Shared Member' and u.Dim_Type='SUBACCOUNT' and u.Level_Nbr='Lev0'
    left outer join WEB_DIMENSIONS_TBL t on t.Member_Name=d.dim_rpt_servicetype and t.dim_storage <> 'Shared Member' and t.Dim_Type='SERVICETYPE' and t.Level_Nbr='Lev0'
    left outer join WEB_DIMENSIONS_TBL f on f.Member_Name=d.dim_rpt_function and f.dim_storage <> 'Shared Member' and f.Dim_Type='FUNCTION' and f.Level_Nbr='Lev0'
    left outer join WEB_DIMENSIONS_TBL c on c.Member_Name=d.dim_rpt_costcenter  and c.dim_storage <> 'Shared Member' and c.Dim_Type='COSTCENTER' and c.Level_Nbr='Lev0'
    left outer join WEB_DIMENSIONS_TBL e on e.Member_Name=d.dim_rpt_entity and e.dim_storage <> 'Shared Member' and e.Dim_Type='ENTITY' and e.Level_Nbr='Lev0'
    left outer join WEB_DIMENSIONS_TBL co on co.Member_Name=d.dim_rpt_company and co.dim_storage <> 'Shared Member' and co.Dim_Type='COMPANY' and co.Level_Nbr='Lev0'
    where 
       (r.Member_Name is null or 
        a.Member_Name is null or 
        k.Member_Name is null or
        v.Member_Name is null or 
        s.Member_Name is null or 
        p.Member_Name is null or 
        u.Member_Name is null or 
        t.Member_Name is null or 
        f.Member_Name is null or 
        c.Member_Name is null or 
        e.Member_Name is null or
        co.Member_Name is null)",
            ConfigurationManager.AppSettings["UserInputValidationTbl"]);

        int NbrBadRecs = 0;
        if (Rdr.Open(Cmd) == true && Rdr.oraRdr.HasRows)
        {
            ArrayList arrDelCmds = FillTable(Rdr, GenValidateDelCmd, ConfigurationManager.AppSettings["UserInputValidationTbl"]);
            NbrBadRecs = arrDelCmds.Count;

            if (chkDelInvalid.Checked == true)
            {
                BasicOraCommand Wrtr = new BasicOraCommand(DbAccess.GetOracleConnStr());
                Wrtr.Open();
                foreach (string delCmd in arrDelCmds)
                {
                    Wrtr.ExecOpened(delCmd);
                }
                Wrtr.Dispose();
            }
        }

        return NbrBadRecs;
    }

    public string GenValidateDelCmd(BasicOraReader Rdr)
    {
        return string.Format(@"delete from {0} where PRP_RPT_SOURCE='{1}' and
dim_rpt_reportngline='{2}' and dim_rpt_account='{3}' and dim_rpt_kpi='{4}' and
dim_rpt_view='{5}' and dim_rpt_scenario='{6}' and dim_rpt_product='{7}' and
dim_rpt_subaccount='{8}' and dim_rpt_servicetype='{9}' and dim_rpt_function='{10}' and
dim_rpt_costcenter='{11}' and dim_rpt_entity='{12}' and dim_rpt_company='{13}'",
            ConfigurationManager.AppSettings["UserInputValidationTbl"],
            Rdr.oraRdr[0], Rdr.oraRdr[1], Rdr.oraRdr[2], Rdr.oraRdr[3], Rdr.oraRdr[4],
            Rdr.oraRdr[5], Rdr.oraRdr[6], Rdr.oraRdr[7], Rdr.oraRdr[8], Rdr.oraRdr[9],
            Rdr.oraRdr[10], Rdr.oraRdr[11], Rdr.oraRdr[12]);
    }

    private void ClearTable()
    {
        while (tblErrs.Rows.Count > 1)
            tblErrs.Rows.RemoveAt(1);
    }

    private ArrayList FillTable(BasicOraReader Rdr, DetermineDelCmd GetDelCmd, string SourceTable)
    {
        Color AltBgnd = Color.FromArgb(231, 242, 254); //#E7F2FE
        Color RegBgnd = Color.White;
        int MainRowCnt = 0;
        int FldCnt = tblErrs.Rows[0].Cells.Count;

        tblErrs.Visible = true;
        divCleanup.Style["display"] = "block";

        MainRowCnt = tblErrs.Rows.Count;
        TableRow tr = new TableRow();
        tr.BackColor = (((MainRowCnt & 1) == 1) ? RegBgnd : AltBgnd);
        tblErrs.Rows.Add(tr);

        TableCell tc = new TableCell();
        tc.ColumnSpan = FldCnt;
        tc.Text = SourceTable.ToUpper();
        tc.Font.Bold = true;
        tr.Cells.Add(tc);

        ArrayList arrDelCmds = new ArrayList();
        while (Rdr.oraRdr.Read())
        {
            ++MainRowCnt;

            //  Create a row for the budget group.
            tr = new TableRow();
            tr.BackColor = (((MainRowCnt & 1) == 1) ? RegBgnd : AltBgnd);
            tblErrs.Rows.Add(tr);

            for (int c = 0; c < FldCnt; c++)
            {
                tc = new TableCell();
                tc.Text = string.Format("{0}", Rdr.oraRdr[c]);
                tr.Cells.Add(tc);
            }

            arrDelCmds.Add(GetDelCmd(Rdr));
        }
        Rdr.Close();
        return arrDelCmds;
    }
    protected void btnValidate_Click(object sender, EventArgs e)
    {
        divCleanup.Style["display"] = "none";
        int NbrBad = CleanupTables();

        if (NbrBad == 0)
            Master.Message += "There were no invalid Key Combinations detected.";
        else
            Master.Message += string.Format("There were {0} invalid Key Combinations detected.", NbrBad);
    }
}
