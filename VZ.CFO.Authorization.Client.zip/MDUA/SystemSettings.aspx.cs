﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using MDUA.DataAccess;
using MDUA.BusinessLogic;
using MDUA.DTO;

public partial class SystemSettings : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Master.PageTitle = "System Settings";
        WebSettings Settings = Utils.LoadWebSetting(Master.curUser.EmployeeID);
        // jevans 5/23/2012 - if web settings is null, database is not available.
        if (Settings == null)
        {
            Master.Message = "MDUA could not load web settings from the database, and cannot continue.  <P>" + HypMDUA.ERROR_MESSAGE;
            return;
        }
        if (Master.SignedIn(UserRole.Admin) == false)
            return;

        if (IsPostBack == false)
        {
            lblActiveSessions.Text = Utils.numActiveSessions.ToString();

            BasicOraReader Rdr = new BasicOraReader(DbAccess.GetOracleConnectionString());
            if (Rdr.Open("Select Alias from Web_dimensions_tbl where dim_type='YEARS' and not Alias is null") == true)
            {
                while (Rdr.oraRdr.Read())
                    ddlYears.Items.Add(Rdr.oraRdr.GetString(0));
                Rdr.Close();
            }
            /*
                        if (Rdr.Open("Select SETTINGVALUE from rpt_settings_tbl where COMPONENT='SYSTEM' and SETTINGNAME='BROADCAST'") == true)
                        {
                            if (Rdr.oraRdr.Read())
                                txtBroadcast.Text = Rdr.oraRdr.GetString(0);
                            Rdr.Close();
                        }

                        if (Rdr.Open("Select Month, Year from RPT_CURRENT_MONTH_TBL") == true)
                        {
                            if (Rdr.oraRdr.Read())
                            {
                                ddlMonths.SelectedValue = string.Format("{0}", Rdr.oraRdr[0]);
                                ddlYears.SelectedValue = Rdr.oraRdr.GetString(1);
                            }
                            Rdr.Dispose();
                            Rdr = null;
                        }
            */
           
            ddlAllowFileUploads.SelectedValue = Settings.UserFeedEnabled ? "Y" : "N";
            ddlCoaCor.SelectedValue = Settings.CoaCorEnabled ? "Y" : "N";
            txtBroadcast.Text = Settings.BroadcastMessage;
            ddlMonths.SelectedValue = Settings.CurrentMonthInt.ToString();
            ddlYears.SelectedValue = Settings.CurrentYear;
        }
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        WebSettings Stgs = Utils.LoadWebSetting(Master.curUser.EmployeeID);
        // jevans 5/23/2012 - if web settings is null, database is not available.
        if (Stgs == null)
        {
            Master.Message = "MDUA could not load web settings from the database, and cannot continue.  <P>" + HypMDUA.ERROR_MESSAGE;
            return;
        }
        Stgs.UserFeedEnabled = (ddlAllowFileUploads.SelectedValue == "Y");
        Stgs.CoaCorEnabled = (ddlCoaCor.SelectedValue == "Y");

        string Brdcst = txtBroadcast.Text.Trim().Replace("''", "'");
        Brdcst = Brdcst.Replace("'", "''");
        Stgs.BroadcastMessage = Brdcst;
        Stgs.CurrentYear = ddlYears.SelectedValue;
        Stgs.CurrentMonth = ddlMonths.SelectedValue;

        if (DbAccess.SaveWebSetting(Stgs, Master.curUser.EmployeeID) == true)
            Master.Message = "The Settings have been successfully Updated.";
        else
            Master.Message = "An error occurred while trying to save the settings.";
    }
}
