﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace MDUA
{
    public partial class SampleBSPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            LoadSimpleTable();
            LoadSortTable();
        }


        private void LoadSimpleTable()
        {
            //<asp:TableCell ID="TableCell2" runat="server">Event</asp:TableCell>
            //            <asp:TableCell ID="TableCell3" runat="server">Job Name</asp:TableCell>
            //            <asp:TableCell ID="TableCell4" runat="server" HorizontalAlign="Center">Description</asp:TableCell>
            //            <asp:TableCell ID="TableCell5" runat="server">Button Text</asp:TableCell>
            //            <asp:TableCell ID="TableCell6" runat="server">Nbr Users</asp:TableCell>
            TableRow tr = new TableRow();
            tr.Cells.Add(new TableCell() { Text = "1" });
            tr.Cells.Add(new TableCell() { Text = "Job A" });
            tr.Cells.Add(new TableCell() { Text = "Job A Description" });
            tr.Cells.Add(new TableCell() { Text = "Button Text" });
            tr.Cells.Add(new TableCell() { Text = "100" });
            tblSimple.Rows.Add(tr);

            tr = new TableRow();
            tr.Cells.Add(new TableCell() { Text = "2" });
            tr.Cells.Add(new TableCell() { Text = "Job B" });
            tr.Cells.Add(new TableCell() { Text = "Job B Description" });
            tr.Cells.Add(new TableCell() { Text = "Button Text" });
            tr.Cells.Add(new TableCell() { Text = "200" });
            tblSimple.Rows.Add(tr);

            tr = new TableRow();
            tr.Cells.Add(new TableCell() { Text = "3" });
            tr.Cells.Add(new TableCell() { Text = "Job C" });
            tr.Cells.Add(new TableCell() { Text = "Job C Description" });
            tr.Cells.Add(new TableCell() { Text = "Button Text" });
            tr.Cells.Add(new TableCell() { Text = "300" });
            tblSimple.Rows.Add(tr);
        }

        private void LoadSortTable()
        {
            tblSortable.Attributes.Add("data-toggle", "table");
            tblSortable.Attributes.Add("data-search", "false");
            tblSortable.Attributes.Add("data-sortable", "true");
            TableHeaderCell1.Attributes.Add("data-sortable", "false");
            TableCell1.Attributes.Add("data-sortable", "true");
            TableCell7.Attributes.Add("data-sortable", "true");
            TableCell8.Attributes.Add("data-sortable", "true");
            TableCell9.Attributes.Add("data-sortable", "true");
            TableCell10.Attributes.Add("data-sortable", "true");

            TableRow tr = new TableRow();

            Button btnAdd = new Button();
            btnAdd.Text = "A";
            btnAdd.CssClass = "btn btn-default btn-circle";
            TableCell tcAction = new TableCell();
            tcAction.Controls.Add(btnAdd);
            tr.Cells.Add(tcAction);

            tr.Cells.Add(new TableCell() { Text = "1" });
            tr.Cells.Add(new TableCell() { Text = "Job A" });
            tr.Cells.Add(new TableCell() { Text = "Job A Description" });

            TextBox txt = new TextBox();
            TableCell tcBtn = new TableCell();
            tcBtn.Controls.Add(txt);
            tr.Cells.Add(tcBtn);

            tr.Cells.Add(new TableCell() { Text = "100" });
            tblSortable.Rows.Add(tr);

            tr = new TableRow();
            btnAdd = new Button();
            btnAdd.Text = "D";
            btnAdd.CssClass = "btn btn-primary btn-circle";
            LinkButton del = new LinkButton();
            del.CssClass = "btn btn-danger btn-circle";
            var span = new HtmlGenericControl("span");
            span.Attributes.Add("aria-hidden", "true");
            span.Attributes.Add("class", "glyphicon glyphicon-remove");
            del.Controls.Add(span);
            tcAction = new TableCell();
            tcAction.Controls.Add(del);

            tr.Cells.Add(tcAction);
            tr.Cells.Add(new TableCell() { Text = "2" });
            tr.Cells.Add(new TableCell() { Text = "Job B" });
            tr.Cells.Add(new TableCell() { Text = "Job B Description" });
            tr.Cells.Add(new TableCell() { Text = "Button Text" });
            tr.Cells.Add(new TableCell() { Text = "200" });
            tblSortable.Rows.Add(tr);

            tr = new TableRow();
            btnAdd = new Button();
            btnAdd.Text = "D";
            btnAdd.CssClass = "btn btn-primary btn-circle";
            tcAction = new TableCell();
            tcAction.Controls.Add(btnAdd);
            tr.Cells.Add(tcAction);
            tr.Cells.Add(new TableCell() { Text = "3" });
            tr.Cells.Add(new TableCell() { Text = "Job C" });
            tr.Cells.Add(new TableCell() { Text = "Job C Description" });
            tr.Cells.Add(new TableCell() { Text = "Button Text" });
            tr.Cells.Add(new TableCell() { Text = "300" });
            tblSortable.Rows.Add(tr);
        }
        
    }
}