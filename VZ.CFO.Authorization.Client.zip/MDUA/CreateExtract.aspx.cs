﻿using System;
using System.Collections;
using System.IO;
using System.Web.UI.WebControls;
using MDUA.DataAccess;
using MDUA.BusinessLogic;

public partial class CreateExtract : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Master.PageTitle = "Create Extract";
        if (Master.SignedIn(UserRole.Admin) == false)
            return;

        if (IsPostBack == false)
        {
            ArrayList arrData = DbAccess.LoadLookupType("DIM_TYPE", Master.curUser.EmployeeID);
            foreach (HypWebLookup wl in arrData)
            {
                ListItem li = new ListItem(wl.Description, wl.Value);
                ddlDimension.Items.Add(li);
            }
        }
    }
    protected void btnExtract_Click(object sender, EventArgs e)
    {
        HypDimension root = Utils.BuildDimTree(ddlDimension.SelectedValue, Master.curUser.EmployeeID);
        if (root == null)
            return;

        string DirName = Server.MapPath("Downloads");
        if (Directory.Exists(DirName) == false)
            Directory.CreateDirectory(DirName);

        string Filename = Server.MapPath(string.Format("Downloads\\{0}_Extract.txt", ddlDimension.SelectedValue));

        ArrayList arrNodes = new ArrayList();
        arrNodes.Add(root);
        using (StreamWriter sw = new StreamWriter(Filename, false))
        {
            WriteItems(sw, arrNodes);
        }

        Server.Transfer("~/DownloadFile.aspx?DocName=" + Filename + "&Del=Y");
    }

    private void WriteItems(StreamWriter sw, ArrayList arrChildren)
    {
        foreach (HypDimension node in arrChildren)
        {
            //PARENT, MEMBER_NAME, ALIAS, ALIAS2, LOCATION, LOCATION_SIBLING, CONSOLIDATION, DIM_STORAGE
            sw.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}\t{5}",
                node.Parent == null ? "" : node.Parent,
                node.MemberName, node.Alias, node.Alias2, node.Consolidation, node.Storage);

            if (node.arrChildren != null && node.arrChildren.Count > 0)
                WriteItems(sw, node.arrChildren);
        }
    }
}
