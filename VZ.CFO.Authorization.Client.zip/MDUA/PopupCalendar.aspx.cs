﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class PopupCalendar : System.Web.UI.Page
{
    public string strFormName;
    public string strCtrlName;
    public string strSelectedDate;

    //  The following javascript code is placed in the calling aspx file.  It will call this
    //  calendar page.

    //  Start of Javascript code to go in calling aspx page.
    //<script type="text/javascript" language="javascript">
    //function GetDate(CtrlName)
    //{
    //    /****************************************************      
    //    Use Javascript method (window.open) to PopUp a new window    
    //    which contain a Calendar Control. In the meantime, we'll    
    //    pass the Parent Form Name and Request Control Name in the QueryString!      
    //    *****************************************************/

    //    ChildWindow = window.open('http://tax.patrick.vzwcorp.com:3387/emsdev/Calendar.aspx?FormName=' + document.forms[0].name + '&CtrlName=' + CtrlName, "PopUpCalendar", "width=250,height=240,top=200,left=200,toolbars=no,scrollbars=no,status=no,resizable=no");    
    //}   
    //
    //function CheckWindow()   
    //{      
    //    ChildWindow.close();   
    //}
    //</script>
    //  End of Javascript code to go in the calling page.

    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack == false)
        {
            //  Set the Calendar to Today's Date in the first load
            myCalendar.SelectedDate = DateTime.Now;

            string curDte = Request.QueryString["Dte"];
            if (curDte.Trim().Length > 0)
            {
                try
                {
                    DateTime dt = DateTime.Parse(curDte);
                    myCalendar.SelectedDate = dt;
                }
                catch (Exception)
                {
                }
            }
        }

        myCalendar.VisibleDate = myCalendar.SelectedDate;

        //  Set the selected Date to a temp string
        //  set FormName and Control Name to 2 string from the values in QueryString
        strSelectedDate = myCalendar.SelectedDate.ToString("MM/dd/yyyy");
        strFormName = Request.QueryString["FormName"];
        strCtrlName = Request.QueryString["CtrlName"];

        strSelectedDate = myCalendar.SelectedDate.ToString("MM/dd/yyyy");
    }
    protected void myCalendar_SelectionChanged(object sender, EventArgs e)
    {
        // Change the Temp Selected Date Object if change is made
        strSelectedDate = myCalendar.SelectedDate.ToString("MM/dd/yyyy");

        string SetDataJScript = "\n<script type=\"text/javascript\" language=\"Javascript\">\n" +
            "   window.opener.document.forms[\"" + strFormName +
            "\"].elements[\"" + strCtrlName + "\"].value = \"" + strSelectedDate + "\";\n" +
            "   window.close();\n</script" + ">\n"; //Don't ask, tool bug.
        Literal1.Text = SetDataJScript;
    }

    //protected void ddl_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    //  Change the VisibleDate of the Calendar according to 
    //    //  the DropDownList dynamically
    //    myCalendar.VisibleDate = new DateTime(int.Parse(ddlYear.SelectedItem.Value), int.Parse(ddlMonth.SelectedItem.Value), 1);    
    //}
}
