﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using System.IO;

public partial class LoadUserSecurity : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Master.PageTitle = "Security - Load User File";
        if (Master.SignedIn(UserRole.Admin) == false)
            return;

        if (IsPostBack == false)
        {
            string Cmd = "Select Cube,DescName from WEB_CUBES_TBL order by DescName";
            BasicOraReader Rdr = new BasicOraReader();
            if (Rdr.Open(Cmd) == true)
            {
                while (Rdr.oraRdr.Read())
                {
                    ListItem li = new ListItem(Rdr.oraRdr.GetString(1),
                        Rdr.oraRdr.GetString(0));
                    ddlCubes.Items.Add(li);
                }
                Rdr.Close();
            }

        }
    }

    protected void btnLoad_Click(object sender, EventArgs e)
    {
        Master.Message = "";

        if (fuUserFile.HasFile == false)
        {
            Master.Message = "You must select a File to upload.";
            return;
        }

        string Ext = Path.GetExtension(fuUserFile.FileName).ToUpper();
        if (Ext.Equals(".TXT") == false)
        {
            Master.Message = "The file must be a tab delimited text file.";
            return;
        }

        BasicOraReader Rdr = null;

        try
        {
            //  Upload the file and load the data based on the extension of the file.
            string Filename = "Archive/SecUser.txt";
            Filename = Server.MapPath(Filename);
            fuUserFile.SaveAs(Filename);

            ArrayList arrData = new ArrayList();
            string[] arrTokens = new string[] { "CC", "RL", "FN", "PR", "EN", "AC", "SA", "ST", "KP", "SC", "VW", "TM", "YR" };

            using (StreamReader sr = new StreamReader(Filename))
            {
                string Data;
                Data = sr.ReadLine();
                while ((Data = sr.ReadLine()) != null)
                {
                    if (Data.Trim().Length == 0)
                        continue;
                    string[] Flds = Data.Split('\t');
                    Data = Flds[0] + '\t' + Flds[14] + '\t';
                    for (int i = 15; i < Flds.Length; i++)
                    {
                        if (Flds[i].Length > 0)
                            Data += arrTokens[i - 15] + '|' + Flds[i] + '|';
                    }
                    arrData.Add(Data);
                }
            }
            Utils.DeleteFile(Filename, Master.curUser.EmployeeID);

            //  Now lets sort the records to group all the same user ids together and 
            //  then load them into the database.
            arrData.Sort();

            string LstUid = "";
            string Cmd;
            int TotalProfiles = 0;
            int TotalUsers = 0;
            Rdr = new BasicOraReader(DbAccess.GetOracleUIConnStr());

            if (arrData.Count > 0 && chkDeleteFirst.Checked == true)
            {
                Cmd = "delete from WEB_SEC_USERS_TBL";
                DbAccess.RunNonQuery(Cmd, DbAccess.GetOracleUIConnStr(), Master.curUser.EmployeeID);
                Cmd = "delete from WEB_SEC_USER_PROFILE_TBL";
                DbAccess.RunNonQuery(Cmd, DbAccess.GetOracleUIConnStr(), Master.curUser.EmployeeID);
            }

            foreach (string ud in arrData)
            {
                if (TotalProfiles > 50)
                    break;

                string[] uf = ud.Split('\t');
                if (uf[0].Equals(LstUid) == false)
                {
                    LstUid = uf[0];
                    Cmd = string.Format("Select UserId from WEB_SEC_USERS_TBL where userid='{0}'",
                        LstUid);

                    if (Rdr.Open(Cmd) == true && Rdr.oraRdr.Read() == false)
                    {
                        ActiveDirectoryRtns.ADUserInfo ui =
                            ActiveDirectoryRtns.ADSearchUser(LstUid);
                        if (ui != null)
                        {
                            Cmd = string.Format("insert into WEB_SEC_USERS_TBL (userid, firstname, lastname, email) values ('{0}','{1}','{2}','{3}')",
                                LstUid, ui.FirstName, ui.LastName, ui.email);
                            if (DbAccess.RunNonQuery(Cmd, DbAccess.GetOracleUIConnStr(), Master.curUser.EmployeeID) != 1)
                                continue;
                            TotalUsers++;
                        }
                    }
                    Rdr.Close();
                }

                //  Now write out the profile data.
                Cmd = string.Format("insert into WEB_SEC_USER_PROFILE_TBL (cube, userid, filterid, replacements) values ('{0}','{1}','{2}','{3}')",
                    ddlCubes.SelectedValue, LstUid, uf[1], uf[2]);
                if (DbAccess.RunNonQuery(Cmd, DbAccess.GetOracleUIConnStr(), Master.curUser.EmployeeID) == 1)
                    TotalProfiles++;
            }

            Master.Message = string.Format("{0} Users were added and {1} User Profile items were added",
                TotalUsers, TotalProfiles);
        }
        catch (Exception)
        {
        }
    }
}
