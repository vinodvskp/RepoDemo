﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using MDUA.DataAccess;
using MDUA.BusinessLogic;

using System.Drawing;

public partial class LogViewer : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Master.PageTitle = "Log Viewer";

        if (IsPostBack == false)
        {
            //  Don't let non admins change the file message type.
            // jevans 12/9/2010 - developers need to see error log:
            //if (Master.curUser.Role != UserRole.Admin)
            ddlMsgType.Enabled = true;
            FillTable();
        }
    }
    protected void btnRefresh_Click(object sender, EventArgs e)
    {
        FillTable();
    }

    private void FillTable() {

        string Cmd = string.Format(
@"select l.date_logged, l.from_where, l.action, l.status, u.last_name, u.first_name
  from web_log l left outer join web_users u on logged_by = u.employee_id
  where l.log_level={0}"
            , ddlMsgType.SelectedValue);

        if (!ddlRange.SelectedValue.Equals("0")) {
            DateTime dt = DateTime.Now.Subtract(new TimeSpan(Int16.Parse(ddlRange.SelectedItem.Value), 0, 0, 0));
            Cmd += string.Format(" and trunc(l.date_logged) >= to_date('{0:dd-MM-yyyy}','dd-MM-yyyy')", dt); 
        }

        Cmd += " order by date_logged desc";

        BasicOraReader Rdr = new BasicOraReader(GeneralDatabaseAccess.GetOracleConnectionString());
        if (Rdr.Open(Cmd) == false)
            return;

        while (tblLog.Rows.Count > 1)
            tblLog.Rows.RemoveAt(1);

        //Color AltBgnd = Color.FromArgb(231, 242, 254); //#E7F2FE
        //Color RegBgnd = Color.White;
        int MainRowCnt = 0;

        while (Rdr.oraRdr.Read() == true)
        {
            ++MainRowCnt;

            //  Create a row for the budget group.
            TableRow tr = new TableRow();
            //tr.BackColor = (((MainRowCnt & 1) == 1) ? RegBgnd : AltBgnd);
            tblLog.Rows.Add(tr);

            TableCell tc = new TableCell();
            tc.HorizontalAlign = HorizontalAlign.Left;
            string val = Rdr.oraRdr[0].GetType().ToString();
            tc.Text = Rdr.oraRdr[0].ToString();
            tr.Cells.Add(tc);

            tc = new TableCell();
            tc.HorizontalAlign = HorizontalAlign.Left;
            if (Rdr.oraRdr.IsDBNull(4) == false)
                tc.Text = string.Format("{0} {1}", Rdr.oraRdr[4], Rdr.oraRdr[5]);
            tr.Cells.Add(tc);

            tc = new TableCell();
            tc.HorizontalAlign = HorizontalAlign.Left;
            tc.Text = Rdr.oraRdr["FROM_WHERE"].ToString();
            tr.Cells.Add(tc);

            tc = new TableCell();
            tc.HorizontalAlign = HorizontalAlign.Left;
            tc.Text = Rdr.oraRdr["ACTION"].ToString();
            tr.Cells.Add(tc);

            tc = new TableCell();
            tc.HorizontalAlign = HorizontalAlign.Left;
            tc.Text = Rdr.oraRdr["STATUS"].ToString();
            tr.Cells.Add(tc);
        }
    }
}
