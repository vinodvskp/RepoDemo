﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using MDUA.DataAccess;
using MDUA.BusinessLogic;
using System.Drawing;
using MDUA.DTO;

public partial class Users : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Master.PageTitle = "User Maintenance";
        if  (Master.curUser.Role != UserRole.Admin)
        {
            if (Master.curUser.CanAssignUserFileType == false 
              //  && Master.curUser.CanAssignBalShtFileType == false  
                  && Master.curUser.CanAssignAutosysOD == false
                ) 
            {
                Master.PendingMessage = "You don't have access to edit user profiles.";
                Server.Transfer("~/Default.aspx");
                return;
            }
        }

        if (IsPostBack == true && Master.curUser.Role != UserRole.Admin)
        {
            btnRefresh.Visible = false;
        }

        //Master.NavInstructionsVisible = true;
        FillTable();
    }
    protected void btnRefresh_Click(object sender, EventArgs e)
    {
        ArrayList arrUsers = ActiveDirectoryRtns.ADSearchUsers(ConfigurationManager.AppSettings["ADGroup"]);
        if (arrUsers != null && arrUsers.Count > 0)
        {
            GeneralDatabaseAccess.RefreshUserInfo(arrUsers, Master.curUser.EmployeeID);
            Master.Message = "Users have been refreshed";
            FillTable();
        }
        else
            Master.Message = "Either no users to update or there was an error getting the list of users";
    }

    private void FillTable()
    {
        string Cmd = 
@"select u.employee_id, u.last_name, u.first_name, r.description, u.active
  from web_users u  left outer join web_user_roles r on u.role = r.role
  order by last_name, first_name";

        BasicOraReader Rdr = new BasicOraReader(GeneralDatabaseAccess.GetOracleConnectionString());
        if (Rdr.Open(Cmd) == false)
            return;

        while (tblUsers.Rows.Count > 1)
            tblUsers.Rows.RemoveAt(1);

        //Color AltBgnd = Color.FromArgb(231, 242, 254); //#E7F2FE
        //Color RegBgnd = Color.White;
        int MainRowCnt = 0;

        while (Rdr.oraRdr.Read() == true)
        {
            ++MainRowCnt;

            //  Create a row for the budget group.
            TableRow tr = new TableRow();
            //tr.BackColor = (((MainRowCnt & 1) == 1) ? RegBgnd : AltBgnd);
            tblUsers.Rows.Add(tr);

            TableCell tc = new TableCell();
            tc.HorizontalAlign = HorizontalAlign.Center;

            ImageButton imgbtn = new ImageButton();
            imgbtn.ImageUrl = "~/Images/TextFile.gif";
            //imgbtn.PostBackUrl = string.Format("~/UserProfile.aspx?ID={0}",
            //    Rdr.oraRdr[0]);
            imgbtn.PostBackUrl = string.Format("~/MDMFramework/Home#/adminFunctions/userProfile/{0}",
                Rdr.oraRdr[0]);

            imgbtn.AlternateText = "Edit User's Profile";
            imgbtn.Attributes["onmouseover"] = "this.src='Images/TextFileHilite.gif'";
            imgbtn.Attributes["onmouseout"] = "this.src='Images/TextFile.gif'";
            tc.Controls.Add(imgbtn);
            tr.Cells.Add(tc);

            tc = new TableCell();
            tc.Text = string.Format("{0}", Rdr.oraRdr[1]);
            tr.Cells.Add(tc);

            tc = new TableCell();
            tc.Text = string.Format("{0}", Rdr.oraRdr[2]);
            tr.Cells.Add(tc);

            tc = new TableCell();
            tc.HorizontalAlign = HorizontalAlign.Center;
            tc.Text = (string)Rdr.oraRdr[3];
            tr.Cells.Add(tc);

            tc = new TableCell();
            tc.HorizontalAlign = HorizontalAlign.Center;
            tc.Text = Rdr.oraRdr[4].ToString().Equals("Y") ? "Yes" : "No";
            if (tc.Text == "No")
                tr.ForeColor = Color.Red;
            tr.Cells.Add(tc);
        }
    }
}
