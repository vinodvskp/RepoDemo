﻿// JScript File
function GetDate(CtrlName)
{
    var DateFld = document.getElementById(CtrlName);
    //var CtrlName = DateFld.Name;
    ChildWindow = window.open('PopupCalendar.aspx?FormName=' + document.forms[0].name + '&CtrlName=' + CtrlName + '&Dte=' + DateFld.value, "PopUpCalendar", "width=250,height=240,top=200,left=200,toolbars=no,scrollbars=no,status=no,resizable=no");
}

function CheckWindow()
{
    ChildWindow.close();
}

