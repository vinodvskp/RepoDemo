﻿using System;
using System.Collections;
using System.Drawing;
using System.Web.UI.WebControls;
using MDUA.BusinessLogic;
using MDUA.DTO;
using MDUA.DataAccess;

public partial class AuditTblDownload : System.Web.UI.Page
{
    #region events

    private const string ProductOfferDropDownValue = "Product Offer";
    private const string ProductOfferValidationTableSql = "v_product_offer_dimensions";
    private const string EquipmentDropDownValue = "Equipment";
    private const string DevicePaymentLoanDropDownValue = "Device Payment Loan";
    private const string DevicePaymentLoanValidationTableSql = "V_DPLOAN_DIMENSIONS";

    /// <summary>
    /// This constant represents the column count in tblAudit.
    /// </summary>
    private const int TotalColsInAudit = 63;

    protected void Page_Load(object sender, EventArgs e)
    {
        
        Master.PageTitle = "Audit Table Download";
        //Master.NavInstructionsVisible = true;
        string tableName = string.Empty;
        switch (ddlCubeName.SelectedValue)
        {
            case EquipmentDropDownValue: tableName = "V_EQUIPMENT_DIMENSIONS"; break;
            case "Location": tableName = "V_LOCATION_DIMENSIONS"; break;
            case "Data Warehouse": tableName = "V_DW_DIMENSIONS"; break;
            case "Planning": tableName = "V_ASO_PLANNING_DIMENSIONS"; break;
            case ProductOfferDropDownValue: tableName = ProductOfferValidationTableSql; break;
            case DevicePaymentLoanDropDownValue: tableName = DevicePaymentLoanValidationTableSql; break;
            default: tableName = "web_dimensions_tbl"; break;
        }
        // jevans 8/17/2011 - 24524 - some dim names changed in loc dim table 
        // jevans 4/10/2011 - 24735 - AND equipment dim table 
        string dimensionName = string.Empty;
        // jevans 8/17/2011 - 24524  - always populate based on drop down 
        //  added table name as well as dim name for location look up 
        //if (IsPostBack == false)

        dimensionName = ddlCubeName.SelectedValue == "Data Warehouse" ? "CUSTOMERACCOUNT" : "ACCOUNT";
        hlAccount.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtAccount.ClientID, dimensionName, tableName);
        hlCompany.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtCompany.ClientID, "COMPANY", tableName);
        dimensionName = ddlCubeName.SelectedValue == "Location" ? "COST_CENTER" : "COSTCENTER";
        hlCostCenter.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtCostCenter.ClientID, dimensionName, tableName);
        dimensionName = ddlCubeName.SelectedValue == EquipmentDropDownValue || ddlCubeName.SelectedValue == "Data Warehouse" ? "ENTITIES" : "ENTITY";
        hlEntity.HRef = string.Format("javascript:SearchTree('{0}','{1}', '{2}')", txtEntity.ClientID, dimensionName, tableName);
        hlEquipment.HRef = string.Format("javascript:SearchTree('{0}','{1}', '{2}')", txtEquipment.ClientID, "EQUIPMENT", tableName);
        hlFunction.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtFunction.ClientID, "FUNCTION", tableName);
        hlKPI.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtKPI.ClientID, "KPI", tableName);
        hlProduct.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtProduct.ClientID, "PRODUCT", tableName);
        dimensionName = ddlCubeName.SelectedValue == "Location" ? "REPORTING_LINE" : "REPORTINGLINE";
        hlReportingLine.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtReportingLine.ClientID, dimensionName, tableName);
        hlScenario.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtScenario.ClientID, "SCENARIO", tableName);
        dimensionName = ddlCubeName.SelectedValue == "Location" ? "SERVICE_TYPE" : "SERVICETYPE";
        hlServiceType.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtServiceType.ClientID, dimensionName, tableName);
        hlSubAccount.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtSubAccount.ClientID, "SUBACCOUNT", tableName);
        dimensionName = ddlCubeName.SelectedValue == "Location" ? "TECH_TYPE" :"TECHTYPE" ;
        hlTechType.HRef = string.Format("javascript:SearchTree('{0}','{1}', '{2}')", txtTechType.ClientID, dimensionName, tableName);
        dimensionName = ddlCubeName.SelectedValue == "Location" ? "VIEWS" : "VIEW";
        hlView.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtView.ClientID, dimensionName, tableName);

        // jevans 24524 - add location dims 
        hlDesignType.HRef = string.Format("javascript:SearchTree('{0}','{1}','V_LOCATION_DIMENSIONS')", txtDesignType.ClientID, "DESIGN_TYPE");
        hlLocationType.HRef = string.Format("javascript:SearchTree('{0}','{1}','V_LOCATION_DIMENSIONS')", txtLocationType.ClientID, "LOCATION_TYPE");
        hllocationSubtype.HRef = string.Format("javascript:SearchTree('{0}','{1}','V_LOCATION_DIMENSIONS')", txtLocationSubType.ClientID, "LOCATION_SUBTYPE");
        hlLocationTierCode.HRef = string.Format("javascript:SearchTree('{0}','{1}','V_LOCATION_DIMENSIONS')", txtLocationTierCode.ClientID, "LOCATION_TIER_CODE");
        hlStoreStatus.HRef = string.Format("javascript:SearchTree('{0}','{1}','V_LOCATION_DIMENSIONS')", txtStoreStatus.ClientID, "STORE_STATUS");

        // jevans 24735 - add equipment dims 
        hlDiscountCode.HRef = string.Format("javascript:SearchTree('{0}','{1}','V_EQUIPMENT_DIMENSIONS')", txtDiscountType.ClientID, "DISCOUNTTYPE");
        hlMethodTypeCode.HRef = string.Format("javascript:SearchTree('{0}','{1}','V_EQUIPMENT_DIMENSIONS')", txtMethodologyType.ClientID, "METHODOLOGYTYPE");
        hlSaleTypeCode.HRef = string.Format("javascript:SearchTree('{0}','{1}','V_EQUIPMENT_DIMENSIONS')", txtSaleType.ClientID, "SALETYPE");
        hlContractTerm.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtContractTerm.ClientID, "CONTRACTTERM", tableName);
        hlProgramEligible.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtProgramEligible.ClientID, "PROGRAMELIGIBLE", tableName);

        // jevans 24737 - add VES/DWH dims 
        hlBranch.HRef = string.Format("javascript:SearchTree('{0}','{1}','V_DW_DIMENSIONS')", txtBranch.ClientID, "BRANCH");
        hlOwningGeography.HRef = string.Format("javascript:SearchTree('{0}','{1}','V_DW_DIMENSIONS')", txtOwningGeography.ClientID, "OWNINGGEO");
        hlOwningManager.HRef = string.Format("javascript:SearchTree('{0}','{1}','V_DW_DIMENSIONS')", txtOwningManager.ClientID, "OWNINGMGR");
        hlVertical.HRef = string.Format("javascript:SearchTree('{0}','{1}','V_DW_DIMENSIONS')", txtVertical.ClientID, "VERTICAL");
        hlVersion.HRef = string.Format("javascript:SearchTree('{0}','{1}','V_DW_DIMENSIONS')", txtVersion.ClientID, "VERSION");
        hlPrevType.HRef = string.Format("javascript:SearchTree('{0}','{1}','V_DW_DIMENSIONS')", txtPrevType.ClientID, "PREVTYPE");
        
        
        hlSegment.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtSegment.ClientID, "SEGMENT", tableName);
        hlConnectionType.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtConnectionType.ClientID, "CONNECTIONTYPE", tableName);

        hlOrganization.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtOrganization.ClientID, "ORGANIZATION", tableName);
        hlOrgChart.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtOrgChart.ClientID, "ORGCHART", tableName);
        hlAccountSize.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtAccountSize.ClientID, "ACCOUNTSIZE", tableName);
        hlHRHV.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtHRHV.ClientID, "HRHV", tableName);
        hlEthnicity.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtEthnicity.ClientID, "ETHNICITY", tableName);
     
        hlBillSystemCustomerType.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtBillSystemCustomerType.ClientID, "BILLSYSTEMCUSTOMERTYPE", tableName);
        hlLoanStatus.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtLoanStatus.ClientID, "LOANSTATUS", tableName);
        hlTreasuryTenure.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtTreasuryTenure.ClientID, "TREASURYTENURE", tableName);

        //Planning
        h1PlannedEntity.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtPlannedEntity.ClientID, "PLANNED ENTITY", tableName);
        h1BusSegment.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtBusinessSegment.ClientID, "BUSINESSSEGMENT", tableName);
        h1ExtSegment.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtExtSegment.ClientID, "EXTERNALSEGMENT", tableName);
        h1GLAccount.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtGLAccount.ClientID, "GL ACCOUNT", tableName);
        h1LOB.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtLOB.ClientID, "LINEOFBUSINESS", tableName);
        h1Region.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtRegion.ClientID, "REGION", tableName);

        //Device Payment Loan
        hlAging.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtAging.ClientID, "AGING", tableName);
        hlEntities.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtEntities.ClientID, "ENTITIES", tableName);
        hlCustomerTenure.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtCustomerTenure.ClientID, "CUSTOMERTENURE", tableName);
        hlCreditRiskType.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtCreditRiskType.ClientID, "CREDITRISKTYPE", tableName);
        hlLoanTenure.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtLoanTenure.ClientID, "LOANTENURE", tableName);
        hlLoanVintage.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtLoanVintage.ClientID, "LOANVINTAGE", tableName);
        hlCollectionStatus.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtCollectionStatus.ClientID, "COLLECTIONSTATUS", tableName);
        hlFICO.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtFICO.ClientID, "FICO", tableName);
        hlUpgradeEligibility.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtUpgradeEligibility.ClientID, "UPG_ELIG", tableName);
        hlTranche.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtTranche.ClientID, "TRANCHE", tableName);
        hlOriginalLoanEquipment.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtOriginalLoanEquipment.ClientID, "ORIGINALLOANEQUIPMENT", tableName);
        hlFirstPaymentMade.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtFirstPaymentMade.ClientID, "FIRSTPAYMENTMADE", tableName);
        hlWriteOffReason.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtWriteOffReason.ClientID, "WRITEOFF_REASON", tableName);
        hlDeactChangeReason.HRef = string.Format("javascript:SearchTree('{0}','{1}','{2}')", txtDeactChangeReason.ClientID, "DEACTCHANGEREASON", tableName);


        if (IsPostBack == false)
        {
            dimensionName = ddlCubeName.SelectedValue == "Location" ? "YEAR" : "YEARS";
            ArrayList arrYears = Utils.GetDimensions(dimensionName, tableName, Master.curUser.EmployeeID);
            arrYears.Sort(new SortByAuditAlias());
            ddlYears.Items.Clear();
            foreach (Dimension dim in arrYears)
            {
                if (dim.Alias.Trim().Length > 0)
                    ddlYears.Items.Add(dim.Alias.Trim());
            }
        } // end of if post back
        // jevans 8/1/2011 - 24524 - location  requires different dimensions 
        DisplayDimensions(ddlCubeName.SelectedValue);
    }

    protected void btnView_Click(object sender, EventArgs e) {
        Master.Message = string.Empty;
        int skipped;
        ArrayList a = GetAuditObjects(false, out skipped);

        try {
            if (a == null) {
                Utils.LogEvent(Master.curUser.EmployeeID, "AuditTblDownload", "btnView_Click", "GetAudit Returned Null", UserToolLogLevel.Error);
                Master.Message = HypMDUA.ERROR_MESSAGE;
                return;
            }
            if (a.Count == 0) {
                // failed to validate parameter(s) 
                if (Master.Message.Length == 0) {
                    Master.Message = "There were no audit records that meet your criteria.";
                    tblAudit.Visible = false;
                }
                return;
            }
            tblAudit.Visible = true;
            decimal LastAuditId = 0;

            //Color AltBgnd = Color.FromArgb(231, 242, 254); //#E7F2FE
            //Color RegBgnd = Color.White;
            int MainRowCnt = 0;
            TableCell cell = null;
            int visibleCells = 0;
            TableRow tableRow = null;

            tblAudit.Rows[0].Cells[41].Visible = false;
            tblAudit.Rows[0].Cells[42].Visible = false;
            tblAudit.Rows[0].Cells[43].Visible = false;
            tblAudit.Rows[0].Cells[44].Visible = false;
            tblAudit.Rows[0].Cells[45].Visible = false;
            tblAudit.Rows[0].Cells[46].Visible = false;

            switch (ddlCubeName.SelectedValue) {
                case "Planning":
                    for (int i = 0; i <= TotalColsInAudit; i++)
                    {
                        tblAudit.Rows[0].Cells[i].Visible = false;
                    }    
                    PlanningActualFact planFact = null;
                    if (a.Count > 0)
                    {
                        planFact = (PlanningActualFact)a[0];
                    }
                    else
                    {
                        return;
                    }

                    //make header column visible
                    /*
                    string visibleColumns = "4,7,8,10,11,16,24,40,41,42,43,44,45,46";
                    for (int i = 0; i < visibleColumns.Split(',').Length; i++)
                    {                     
                        tblAudit.Rows[0].Cells[int.Parse(visibleColumns.Split(',')[i])].Visible = true;
                    }
                    */
                    int Numberofcols = 14;
                    for (int i = 0; i < Numberofcols; i++)
                    {
                        tblAudit.Rows[0].Cells[i].Visible = true;
                    }

                    //Generic 

                    tblAudit.Rows[0].Cells[0].Text = "Account";
                    tblAudit.Rows[0].Cells[1].Text = "Business Segment";
                    tblAudit.Rows[0].Cells[2].Text = "Contract Term";
                    tblAudit.Rows[0].Cells[3].Text = "External Segment";
                    tblAudit.Rows[0].Cells[4].Text = "Function";
                    tblAudit.Rows[0].Cells[5].Text = "GL Account";
                    tblAudit.Rows[0].Cells[6].Text = "Line of Business";
                    tblAudit.Rows[0].Cells[7].Text = "Planned Entity";
                    tblAudit.Rows[0].Cells[8].Text = "Product";
                    tblAudit.Rows[0].Cells[9].Text = "Region";
                    tblAudit.Rows[0].Cells[10].Text = "Scenario";
                    tblAudit.Rows[0].Cells[11].Text = "Service Type";
                    tblAudit.Rows[0].Cells[12].Text = "Tech Type";
                    tblAudit.Rows[0].Cells[13].Text = "Amount";

                    // count visible cells:
                    for (int i = 0; i < tblAudit.Rows[0].Cells.Count; ++i)
                    {
                        visibleCells += tblAudit.Rows[0].Cells[i].Visible ? 1 : 0;
                    }

                    foreach (PlanningActualFact f in a)
                    {
                        if (!f.AuditId.Equals(LastAuditId))
                        {
                            ++MainRowCnt;
                            tableRow = new TableRow();
                            //tableRow.BackColor = (((MainRowCnt & 1) == 1) ? RegBgnd : AltBgnd);
                            tblAudit.Rows.Add(tableRow);

                            //  Create a row for the budget group.
                            LastAuditId = f.AuditId;

                            // dimensions                             
                            tableRow.Cells.Add(GenerateCell(f.Account, f.Account != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.BusinessSegment, f.BusinessSegment != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.ContractTerm, f.ContractTerm != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.ExternalSegment, f.ExternalSegment != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Function, f.Function != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.GLAccount, f.GLAccount != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.LineOfBusiness, f.LineOfBusiness != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.PlannedEntity, f.PlannedEntity != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Product, f.Product != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Region, f.Region != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Scenario, f.Scenario != string.Empty));                            
                            tableRow.Cells.Add(GenerateCell(f.ServiceType, f.ServiceType != string.Empty));                            
                            tableRow.Cells.Add(GenerateCell(f.TechType, f.TechType != string.Empty));                                 
                            tableRow.Cells.Add(GenerateCell(f.Amount, true, horizontalAlign: HorizontalAlign.Right));                                                                                                               
                            
                                                
                            tableRow.Cells[tableRow.Cells.Count - 1].Wrap = false;
                            // end of if last audit changed

                            //  Create a row for the budget group.
                            TableRow tr = new TableRow();
                            //tr.BackColor = (((MainRowCnt & 1) == 1) ? RegBgnd : AltBgnd);
                            tblAudit.Rows.Add(tr);

                            if (f.AuditId == 0)
                            {
                                tr.Cells.Add(GenerateCell("The Audit Record for this item is missing", true, columnSpan: visibleCells));
                            }
                            else
                            {
                                // display audit line
                                tr.Cells.Add(GenerateCell(string.Format("{0} {1}", f.FactUser.FirstName, f.FactUser.LastName), true, HorizontalAlign.Right, visibleCells - 4));
                                tr.Cells.Add(GenerateCell(f.FactUser.UserId, true));
                                tr.Cells.Add(GenerateCell(string.Format("{0:MM/dd/yyyy HH:mm}", f.DateModified), true, columnSpan: 2));
                                tr.Cells.Add(GenerateCell(f.FactAudit.ToString(), true, HorizontalAlign.Right));
                                tableRow.Cells[tableRow.Cells.Count - 1].Wrap = false;
                            }

                        }
                    }

                    break;
                case DevicePaymentLoanDropDownValue:
                    for (int i = 0; i <= TotalColsInAudit; i++)
                    {
                        tblAudit.Rows[0].Cells[i].Visible = false;
                    }
                    DevicePaymentLoanFact dpFact = null;
                    if (a.Count > 0)
                    {
                        dpFact = (DevicePaymentLoanFact)a[0];
                    }
                    else
                    {
                        return;
                    }

                    //make header column visible
                    /*
                    string visibleColumns = "4,7,8,10,11,16,24,40,41,42,43,44,45,46";
                    for (int i = 0; i < visibleColumns.Split(',').Length; i++)
                    {                     
                        tblAudit.Rows[0].Cells[int.Parse(visibleColumns.Split(',')[i])].Visible = true;
                    }
                    */
                    int dpNumberofcols = 24;
                    for (int i = 0; i < dpNumberofcols; i++)
                    {
                        tblAudit.Rows[0].Cells[i].Visible = true;
                    }

                    //Generic 

                    tblAudit.Rows[0].Cells[0].Text = "Reporting Line";
                    tblAudit.Rows[0].Cells[1].Text = "Scenario";
                    tblAudit.Rows[0].Cells[2].Text = "Service Type";
                    tblAudit.Rows[0].Cells[3].Text = "Function";
                    tblAudit.Rows[0].Cells[4].Text = "Equipment";
                    tblAudit.Rows[0].Cells[5].Text = "Contract Term";

                    tblAudit.Rows[0].Cells[6].Text = "Aging";
                    tblAudit.Rows[0].Cells[7].Text = "Entities";
                    tblAudit.Rows[0].Cells[8].Text = "Customer Tenure";
                    tblAudit.Rows[0].Cells[9].Text = "Credit Risk Type";
                    tblAudit.Rows[0].Cells[10].Text = "Loan Tenure";
                    tblAudit.Rows[0].Cells[11].Text = "Loan Vintage";
                    tblAudit.Rows[0].Cells[12].Text = "Collection Status";
                    tblAudit.Rows[0].Cells[13].Text = "FICO";
                    tblAudit.Rows[0].Cells[14].Text = "Upg Elig";
                    tblAudit.Rows[0].Cells[15].Text = "Tranche";
                    tblAudit.Rows[0].Cells[16].Text = "Original Loan Equipment";
                    tblAudit.Rows[0].Cells[17].Text = "First Payment Made";
                    tblAudit.Rows[0].Cells[18].Text = "WriteOff Reason";
                    tblAudit.Rows[0].Cells[19].Text = "Deact Change Reason";
                    
                    tblAudit.Rows[0].Cells[20].Text = "Bill System Customer Type";
                    tblAudit.Rows[0].Cells[21].Text = "Loan Status";
                    tblAudit.Rows[0].Cells[22].Text = "Treasury Tenure";
                    
                    
                    tblAudit.Rows[0].Cells[23].Text = "Amount";

                    // count visible cells:
                    for (int i = 0; i < tblAudit.Rows[0].Cells.Count; ++i)
                    {
                        visibleCells += tblAudit.Rows[0].Cells[i].Visible ? 1 : 0;
                    }

                    foreach (DevicePaymentLoanFact f in a)
                    {
                        if (!f.AuditId.Equals(LastAuditId))
                        {
                            ++MainRowCnt;
                            tableRow = new TableRow();
                            //tableRow.BackColor = (((MainRowCnt & 1) == 1) ? RegBgnd : AltBgnd);
                            tblAudit.Rows.Add(tableRow);

                            //  Create a row for the budget group.
                            LastAuditId = f.AuditId;

                            // dimensions                             

                            tableRow.Cells.Add(GenerateCell(f.ReportingLine, f.ReportingLine != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Scenario, f.Scenario != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.ServiceType, f.ServiceType != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Function, f.Function != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Equipment, f.Equipment != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.ContractTerm, f.ContractTerm != string.Empty));
                            
                            tableRow.Cells.Add(GenerateCell(f.Aging, f.Aging != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Entities, f.Entities != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.CustomerTenure, f.CustomerTenure != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.CreditRiskType, f.CreditRiskType != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.LoanTenure, f.LoanTenure != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.LoanVintage, f.LoanVintage != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.CollectionStatus, f.CollectionStatus != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Fico, f.Fico != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.UpgradeEligibility, f.UpgradeEligibility != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Tranche, f.Tranche != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.OriginalLoanEquipment, f.OriginalLoanEquipment != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.FirstPaymentMade, f.FirstPaymentMade != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.WriteOffReason, f.WriteOffReason != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.DeactChangeReason, f.DeactChangeReason != string.Empty));

                            tableRow.Cells.Add(GenerateCell(f.BillSystemCustomerType, f.BillSystemCustomerType != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.LoanStatus, f.LoanStatus != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.TreasuryTenure, f.TreasuryTenure != string.Empty));

                            tableRow.Cells.Add(GenerateCell(f.Amount, true, horizontalAlign: HorizontalAlign.Right));


                            tableRow.Cells[tableRow.Cells.Count - 1].Wrap = false;
                            // end of if last audit changed

                            //  Create a row for the budget group.
                            TableRow tr = new TableRow();
                            //tr.BackColor = (((MainRowCnt & 1) == 1) ? RegBgnd : AltBgnd);
                            tblAudit.Rows.Add(tr);

                            if (f.AuditId == 0)
                            {
                                tr.Cells.Add(GenerateCell("The Audit Record for this item is missing", true, columnSpan: visibleCells));
                            }
                            else
                            {
                                // display audit line
                                tr.Cells.Add(GenerateCell(string.Format("{0} {1}", f.FactUser.FirstName, f.FactUser.LastName), true, HorizontalAlign.Right, visibleCells - 4));
                                tr.Cells.Add(GenerateCell(f.FactUser.UserId, true));
                                tr.Cells.Add(GenerateCell(string.Format("{0:MM/dd/yyyy HH:mm}", f.DateModified), true, columnSpan: 2));
                                tr.Cells.Add(GenerateCell(f.FactAudit.ToString(), true, HorizontalAlign.Right));
                                tableRow.Cells[tableRow.Cells.Count - 1].Wrap = false;
                            }

                        }
                    }

                    break;
                case ProductOfferDropDownValue:
                    ProductOfferFact productOfferFact = null;
                    if (a.Count > 0) {
                        productOfferFact = (ProductOfferFact)a[0];
                    } else {
                        return;
                    }

                    // hide column headers if no data 
                    tblAudit.Rows[0].Cells[0].Visible = productOfferFact.FactDate > DateTime.MinValue;
                    tblAudit.Rows[0].Cells[1].Visible = false;
                    tblAudit.Rows[0].Cells[2].Visible = false;
                    tblAudit.Rows[0].Cells[3].Visible = true;
                    tblAudit.Rows[0].Cells[4].Visible = productOfferFact.Account != string.Empty;
                    tblAudit.Rows[0].Cells[5].Visible = false;
                    tblAudit.Rows[0].Cells[6].Visible = false;
                    tblAudit.Rows[0].Cells[7].Visible = true;
                    tblAudit.Rows[0].Cells[8].Visible = productOfferFact.Product != string.Empty;
                    tblAudit.Rows[0].Cells[9].Visible = false;
                    tblAudit.Rows[0].Cells[10].Visible = true;
                    tblAudit.Rows[0].Cells[11].Visible = true;
                    tblAudit.Rows[0].Cells[12].Visible = productOfferFact.CostCenter != string.Empty;
                    tblAudit.Rows[0].Cells[13].Visible = true;
                    tblAudit.Rows[0].Cells[14].Visible = false;
                    tblAudit.Rows[0].Cells[15].Visible = true;
                    tblAudit.Rows[0].Cells[16].Visible = false;
                    tblAudit.Rows[0].Cells[17].Visible = false;
                    tblAudit.Rows[0].Cells[18].Visible = false;
                    tblAudit.Rows[0].Cells[19].Visible = false;
                    tblAudit.Rows[0].Cells[20].Visible = false;
                    tblAudit.Rows[0].Cells[21].Visible = false;
                    tblAudit.Rows[0].Cells[22].Visible = false;
                    tblAudit.Rows[0].Cells[23].Visible = false;
                    tblAudit.Rows[0].Cells[24].Visible = false;
                    tblAudit.Rows[0].Cells[25].Visible = productOfferFact.ContractTerm != string.Empty;
                    tblAudit.Rows[0].Cells[26].Visible = false;
                    tblAudit.Rows[0].Cells[27].Visible = false;
                    tblAudit.Rows[0].Cells[28].Visible = false;
                    tblAudit.Rows[0].Cells[29].Visible = productOfferFact.ConnectionType != string.Empty;
                    tblAudit.Rows[0].Cells[30].Visible = false;
                    tblAudit.Rows[0].Cells[31].Visible = false;
                    tblAudit.Rows[0].Cells[32].Visible = productOfferFact.Segment != string.Empty;
                    tblAudit.Rows[0].Cells[33].Visible = false;
                    tblAudit.Rows[0].Cells[34].Visible = false;
                    tblAudit.Rows[0].Cells[35].Visible = productOfferFact.Organization != string.Empty;
                    tblAudit.Rows[0].Cells[36].Visible = productOfferFact.OrgChart != string.Empty;
                    tblAudit.Rows[0].Cells[37].Visible = productOfferFact.AccountSize != string.Empty;
                    tblAudit.Rows[0].Cells[38].Visible = productOfferFact.HRHV != string.Empty;
                    tblAudit.Rows[0].Cells[39].Visible = productOfferFact.Ethnicity != string.Empty;

                    // count visible cells:
                    for (int i = 0; i < tblAudit.Rows[0].Cells.Count; ++i) {
                        visibleCells += tblAudit.Rows[0].Cells[i].Visible ? 1 : 0;
                    }

                    foreach (ProductOfferFact f in a) {
                        if (!f.AuditId.Equals(LastAuditId)) {
                            ++MainRowCnt;
                            tableRow = new TableRow();
                            //tableRow.BackColor = (((MainRowCnt & 1) == 1) ? RegBgnd : AltBgnd);
                            tblAudit.Rows.Add(tableRow);

                            //  Create a row for the budget group.
                            LastAuditId = f.AuditId;

                            // dimensions 
                            tableRow.Cells.Add(GenerateCell(f.FactDate.ToShortDateString(), f.FactDate > DateTime.MinValue));
                            tableRow.Cells.Add(GenerateCell(f.Year, f.Year != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.ReportingLine, true));
                            tableRow.Cells.Add(GenerateCell(f.Account, f.Account != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Scenario, f.Scenario != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Product, f.Product != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.ServiceType, f.ServiceType != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Function, f.Function != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.CostCenter, f.CostCenter != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Entity, f.Entity != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Equipment, f.Equipment != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.ContractTerm, f.ContractTerm != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.ConnectionType, f.ConnectionType != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Segment, f.Segment != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Organization, f.Organization != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.OrgChart, f.OrgChart != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.AccountSize, f.AccountSize != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.HRHV, f.HRHV != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Ethnicity, f.Ethnicity != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Amount, true, horizontalAlign: HorizontalAlign.Right));
                            tableRow.Cells[tableRow.Cells.Count - 1].Wrap = false;
                            // end of if last audit changed
                        }

                        //  Create a row for the budget group.
                        TableRow tr = new TableRow();
                        //tr.BackColor = (((MainRowCnt & 1) == 1) ? RegBgnd : AltBgnd);
                        tblAudit.Rows.Add(tr);

                        if (f.AuditId == 0) {
                            tr.Cells.Add(GenerateCell("The Audit Record for this item is missing", true, columnSpan: visibleCells));
                        } else {
                            // display audit line
                            tr.Cells.Add(GenerateCell(string.Format("{0} {1}", f.FactUser.FirstName, f.FactUser.LastName), true, HorizontalAlign.Right, visibleCells - 4));
                            tr.Cells.Add(GenerateCell(f.FactUser.UserId, true));
                            tr.Cells.Add(GenerateCell(string.Format("{0:MM/dd/yyyy HH:mm}", f.DateModified), true, columnSpan: 2));
                            tr.Cells.Add(GenerateCell(f.FactAudit.ToString(), true, HorizontalAlign.Right));
                            tableRow.Cells[tableRow.Cells.Count - 1].Wrap = false;
                        }
                    }// end of while 
                    break;
                case EquipmentDropDownValue:
                    EquipmentFact equipmentFact = null;
                    if (a.Count > 0) {
                        equipmentFact = (EquipmentFact)a[0];
                    } else {
                        return;
                    }

                    // hide column headers if no data 
                    tblAudit.Rows[0].Cells[0].Visible = equipmentFact.FactDate > DateTime.MinValue;
                    tblAudit.Rows[0].Cells[1].Visible = equipmentFact.Year != string.Empty;
                    tblAudit.Rows[0].Cells[2].Visible = false;
                    tblAudit.Rows[0].Cells[4].Visible = false;
                    tblAudit.Rows[0].Cells[8].Visible = false;
                    tblAudit.Rows[0].Cells[9].Visible = false;
                    tblAudit.Rows[0].Cells[12].Visible = equipmentFact.CostCenter != string.Empty;
                    tblAudit.Rows[0].Cells[14].Visible = false;
                    tblAudit.Rows[0].Cells[16].Visible = false;
                    tblAudit.Rows[0].Cells[18].Visible = false;
                    tblAudit.Rows[0].Cells[19].Visible = false;
                    tblAudit.Rows[0].Cells[20].Visible = false;
                    tblAudit.Rows[0].Cells[21].Visible = false;
                    tblAudit.Rows[0].Cells[22].Visible = false;
                    tblAudit.Rows[0].Cells[23].Visible = equipmentFact.MethodologyType != string.Empty;
                    tblAudit.Rows[0].Cells[24].Visible = equipmentFact.SaleType != string.Empty;
                    tblAudit.Rows[0].Cells[25].Visible = equipmentFact.ContractTerm != string.Empty;
                    tblAudit.Rows[0].Cells[26].Visible = false;
                    tblAudit.Rows[0].Cells[27].Visible = equipmentFact.DiscountType != string.Empty;
                    tblAudit.Rows[0].Cells[28].Visible = false;
                    tblAudit.Rows[0].Cells[29].Visible = false;
                    tblAudit.Rows[0].Cells[30].Visible = false;
                    tblAudit.Rows[0].Cells[31].Visible = false;
                    tblAudit.Rows[0].Cells[32].Visible = false;
                    tblAudit.Rows[0].Cells[33].Visible = false;
                    tblAudit.Rows[0].Cells[34].Visible = false;
                    tblAudit.Rows[0].Cells[35].Visible = false;
                    tblAudit.Rows[0].Cells[36].Visible = false;
                    tblAudit.Rows[0].Cells[37].Visible = false;
                    tblAudit.Rows[0].Cells[38].Visible = false;
                    tblAudit.Rows[0].Cells[39].Visible = false;

                    // count visible cells:
                    for (int i = 0; i < tblAudit.Rows[0].Cells.Count; ++i) {
                        visibleCells += tblAudit.Rows[0].Cells[i].Visible ? 1 : 0;
                    }

                    foreach (EquipmentFact f in a) {
                        if (!f.AuditId.Equals(LastAuditId)) {
                            ++MainRowCnt;
                            tableRow = new TableRow();
                            //tableRow.BackColor = (((MainRowCnt & 1) == 1) ? RegBgnd : AltBgnd);
                            tblAudit.Rows.Add(tableRow);

                            //  Create a row for the budget group.
                            LastAuditId = f.AuditId;

                            // dimensions 
                            tableRow.Cells.Add(GenerateCell(f.FactDate.ToShortDateString(), f.FactDate > DateTime.MinValue));
                            tableRow.Cells.Add(GenerateCell(f.Year, f.Year != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.ReportingLine, true));
                            tableRow.Cells.Add(GenerateCell(f.KPI, f.KPI != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.View, f.View != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Scenario, f.Scenario != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.ServiceType, f.ServiceType != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Function, f.Function != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.CostCenter, f.CostCenter != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Entity, f.Entity != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Equipment, f.Equipment != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.TechType, f.TechType != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.MethodologyType, f.MethodologyType != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.SaleType, f.SaleType != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.ContractTerm, f.ContractTerm != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.DiscountType, f.DiscountType != string.Empty));
                            // jevans 5/4/2012 - 24735 - service dims
                            
                            tableRow.Cells.Add(GenerateCell(f.Amount, true, horizontalAlign: HorizontalAlign.Right));
                            // end of if last audit changed
                        }

                        //  Create a row for the budget group.
                        TableRow tr = new TableRow();
                        //tr.BackColor = (((MainRowCnt & 1) == 1) ? RegBgnd : AltBgnd);
                        tblAudit.Rows.Add(tr);

                        if (f.AuditId == 0) {
                            tr.Cells.Add(GenerateCell("The Audit Record for this item is missing", true, columnSpan: visibleCells));
                        } else {
                            // display audit line
                            tr.Cells.Add(GenerateCell(string.Format("{0} {1}", f.FactUser.FirstName, f.FactUser.LastName), true, HorizontalAlign.Right, visibleCells - 4));
                            tr.Cells.Add(GenerateCell(f.FactUser.UserId, true));
                            tr.Cells.Add(GenerateCell(string.Format("{0:MM/dd/yyyy HH:mm}", f.DateModified), true, columnSpan: 2));
                            tr.Cells.Add(GenerateCell(f.FactAudit.ToString(), true, HorizontalAlign.Right));
                        }
                    }// end of while 

                    break;
                default:
                    FactDTO f1 = null;
                    if (a.Count > 0) {
                        f1 = (FactDTO)a[0];
                    } else {
                        return;
                    }

                    // hide column headers if no data 
                    tblAudit.Rows[0].Cells[0].Visible = f1.FactDate > DateTime.MinValue;
                    tblAudit.Rows[0].Cells[1].Visible = f1.Year != string.Empty;
                    tblAudit.Rows[0].Cells[2].Visible = f1.Month != string.Empty;
                    tblAudit.Rows[0].Cells[4].Visible = f1.Account != string.Empty;
                    tblAudit.Rows[0].Cells[8].Visible = f1.Product != string.Empty;
                    tblAudit.Rows[0].Cells[9].Visible = f1.SubAccount != string.Empty;
                    tblAudit.Rows[0].Cells[12].Visible = f1.CostCenter != string.Empty;
                    tblAudit.Rows[0].Cells[14].Visible = f1.Company != string.Empty;
                    tblAudit.Rows[0].Cells[16].Visible = f1.PreviousType != string.Empty;
                    tblAudit.Rows[0].Cells[18].Visible = f1.StoreStatus != string.Empty;
                    tblAudit.Rows[0].Cells[19].Visible = f1.DesignType != string.Empty;
                    tblAudit.Rows[0].Cells[20].Visible = f1.LocationType != string.Empty;
                    tblAudit.Rows[0].Cells[21].Visible = f1.LocationSubtype != string.Empty;
                    tblAudit.Rows[0].Cells[22].Visible = f1.LocationTierCode != string.Empty;
                    tblAudit.Rows[0].Cells[23].Visible = f1.MethodType != string.Empty;
                    tblAudit.Rows[0].Cells[24].Visible = f1.SaleType != string.Empty;
                    tblAudit.Rows[0].Cells[25].Visible = f1.ContractTerm != string.Empty;
                    tblAudit.Rows[0].Cells[26].Visible = f1.ProgramEligible != string.Empty;
                    tblAudit.Rows[0].Cells[27].Visible = f1.DiscountType != string.Empty;
                    tblAudit.Rows[0].Cells[28].Visible = f1.Branch != string.Empty;
                    tblAudit.Rows[0].Cells[29].Visible = f1.ConnectionType != string.Empty;
                    tblAudit.Rows[0].Cells[30].Visible = f1.OwningGeo != string.Empty;
                    tblAudit.Rows[0].Cells[31].Visible = f1.OwningMgr != string.Empty;
                    tblAudit.Rows[0].Cells[32].Visible = f1.Segment != string.Empty;
                    tblAudit.Rows[0].Cells[33].Visible = f1.Version != string.Empty;
                    tblAudit.Rows[0].Cells[34].Visible = f1.Vertical != string.Empty;
                    tblAudit.Rows[0].Cells[35].Visible = false;
                    tblAudit.Rows[0].Cells[36].Visible = false;
                    tblAudit.Rows[0].Cells[37].Visible = false;
                    tblAudit.Rows[0].Cells[38].Visible = false;
                    tblAudit.Rows[0].Cells[39].Visible = false;

                    // count visible cells:
                    for (int i = 0; i < tblAudit.Rows[0].Cells.Count; ++i) {
                        visibleCells += tblAudit.Rows[0].Cells[i].Visible ? 1 : 0;
                    }

                    foreach (FactDTO f in a) {
                        if (!f.AuditId.Equals(LastAuditId)) {
                            ++MainRowCnt;
                            tableRow = new TableRow();
                            //tableRow.BackColor = (((MainRowCnt & 1) == 1) ? RegBgnd : AltBgnd);
                            tblAudit.Rows.Add(tableRow);

                            //  Create a row for the budget group.
                            LastAuditId = f.AuditId;

                            // dimensions 
                            tableRow.Cells.Add(GenerateCell(f.FactDate.ToShortDateString(), f.FactDate > DateTime.MinValue));
                            tableRow.Cells.Add(GenerateCell(f.Year, f.Year != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Month, f.Month != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.ReportingLine, true));
                            tableRow.Cells.Add(GenerateCell(f.Account, f.Account != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.KPI, f.KPI != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.View, f.View != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Scenario, f.Scenario != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Product, f.Product != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.SubAccount, f.SubAccount != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.ServiceType, f.ServiceType != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Function, f.Function != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.CostCenter, f.CostCenter != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Entity, f.Entity != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Company, f.Company != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Equipment, f.Equipment != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.PreviousType, f.PreviousType != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.TechType, f.TechType != string.Empty));
                            // jevans 8/17/2011 - 24524 - location dims
                            tableRow.Cells.Add(GenerateCell(f.StoreStatus, f.StoreStatus != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.DesignType, f.DesignType != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.LocationType, f.LocationType != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.LocationSubtype, f.LocationSubtype != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.LocationTierCode, f.LocationTierCode != string.Empty));
                            // jevans 24735 new equipment dims
                            tableRow.Cells.Add(GenerateCell(f.MethodType, f.MethodType != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.SaleType, f.SaleType != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.ContractTerm, f.ContractTerm != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.ProgramEligible, f.ProgramEligible != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.DiscountType, f.DiscountType != string.Empty));
                            // jevans 5/4/2012 - 24735 - service dims
                            tableRow.Cells.Add(GenerateCell(f.Branch, f.Branch != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.ConnectionType, f.ConnectionType != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.OwningGeo, f.OwningGeo != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.OwningMgr, f.OwningMgr != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Segment, f.Segment != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Version, f.Version != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Vertical, f.Vertical != string.Empty));
                            tableRow.Cells.Add(GenerateCell(f.Fact, true, horizontalAlign: HorizontalAlign.Right));
                            // end of if last audit changed
                        }

                        //  Create a row for the budget group.
                        TableRow tr = new TableRow();
                        //tr.BackColor = (((MainRowCnt & 1) == 1) ? RegBgnd : AltBgnd);
                        tblAudit.Rows.Add(tr);

                        if (f.AuditId == 0) {
                            tr.Cells.Add(GenerateCell("The Audit Record for this item is missing", true, columnSpan: visibleCells));
                        } else {
                            // display audit line
                            tr.Cells.Add(GenerateCell(string.Format("{0} {1}", f.FactUser.FirstName, f.FactUser.LastName), true, HorizontalAlign.Right, visibleCells - 4));
                            tr.Cells.Add(GenerateCell(f.FactUser.UserId, true));
                            tr.Cells.Add(GenerateCell(string.Format("{0:MM/dd/yyyy HH:mm}", f.CreateModifyDate), true, columnSpan: 2));
                            tr.Cells.Add(GenerateCell(f.FactAudit.ToString(), true, HorizontalAlign.Right));
                        }
                    }// end of while 

                    break;


            }            

            if (skipped > 0) {
                cell = new TableCell();
                cell.Text = string.Format("{0} Rows were not displayed", skipped);
                cell.ColumnSpan = tblAudit.Rows[0].Cells.Count;
                TableRow tr = new TableRow();
                tr.Cells.Add(cell);
            }
        } catch (Exception ex) {
            Master.Message = HypMDUA.ERROR_MESSAGE;
            Utils.LogEvent(Master.curUser.EmployeeID, "AuditTblDownload.aspx", "btnView_Click", ex, UserToolLogLevel.Error);
        }

    } // end of view button

    protected TableCell GenerateCell(string text, bool visible, HorizontalAlign horizontalAlign = HorizontalAlign.NotSet, int columnSpan = 0) {
        TableCell cell = new TableCell();
        cell.Text = text;
        cell.Visible = visible;
        cell.HorizontalAlign = horizontalAlign;
        cell.ColumnSpan = columnSpan;
        return cell;
    }

    protected void btnDownload_Click(object sender, EventArgs e)
    {
        Master.Message = string.Empty;
        try
        {
            string Filename = string.Format("Downloads/Audit_{1}_{0}.csv",
                DateTime.Now.ToString("yyyyMMdd_HHmmss"),
                Master.curUser.UserId);

            Filename = Server.MapPath(Filename);

            int skipped;
            ArrayList a = GetAuditObjects(true, out skipped);

            if (a == null)
            {
                Utils.LogEvent(Master.curUser.EmployeeID, "AuditTblDownload", "btnDownload_Click", "", UserToolLogLevel.Error);
                Master.Message = HypMDUA.ERROR_MESSAGE;
                return;
            }
            if (a.Count == 0)
            {
                // failed to validate parameter(s)
                if (Master.Message.Length == 0)
                {
                    Master.Message = "There were no audit records that meet your criteria.";
                    tblAudit.Visible = false;
                }
                return;
            }
            Master.Message = string.Format("There were {0} audit records written to file.", a.Count.ToString());

            switch (ddlCubeName.SelectedValue) {
                case ProductOfferDropDownValue:
                    if (ProductOfferDatabaseAccess.WriteAuditDataToCsv(Filename, "Audit", a, Master.curUser.EmployeeID)) {
                        Response.Redirect(string.Format("DownloadFile.aspx?DocName={0}&Del=Y", Filename));
                    } else {
                        Master.Message = HypMDUA.ERROR_MESSAGE;
                    }
                    break;
                case EquipmentDropDownValue:
                    if (EquipmentDatabaseAccess.WriteAuditDataToCsv(Filename, "Audit", a, Master.curUser.EmployeeID)) {
                        Response.Redirect(string.Format("DownloadFile.aspx?DocName={0}&Del=Y", Filename));
                    } else {
                        Master.Message = HypMDUA.ERROR_MESSAGE;
                    }
                    break;
                case "Planning":
                    if (PlanningActualsDatabaseAccess.WriteAuditDataToCsv(Filename, "Audit", a, Master.curUser.EmployeeID))
                    {
                        Response.Redirect(string.Format("DownloadFile.aspx?DocName={0}&Del=Y", Filename));
                    }
                    else
                    {
                        Master.Message = HypMDUA.ERROR_MESSAGE;
                    }
                    break;
                case DevicePaymentLoanDropDownValue:
                    if (DevicePaymentLoanDatabaseAccess.WriteAuditDataToCsv(Filename, "Audit", a, Master.curUser.EmployeeID))
                    {
                        Response.Redirect(string.Format("DownloadFile.aspx?DocName={0}&Del=Y", Filename));
                    }
                    else
                    {
                        Master.Message = HypMDUA.ERROR_MESSAGE;
                    }
                    break;
                default:
                    if (Utils.WriteAuditDataToCSV(Filename, "Audit", a, Master.curUser.EmployeeID)) {
                        Response.Redirect(string.Format("DownloadFile.aspx?DocName={0}&Del=Y", Filename));
                    } else {
                        Master.Message = HypMDUA.ERROR_MESSAGE;
                    }
                    break;
            }
        }
        catch (System.Threading.ThreadAbortException)
        {
            // thread was aborted ... do nothing
        }
        catch (Exception ex)
        {
            Master.Message = HypMDUA.ERROR_MESSAGE;
            Utils.LogEvent(Master.curUser.EmployeeID, "AuditTblDownload.aspx", "btnDownload_click", ex, UserToolLogLevel.Error);
        }
    } // end of download button 

    protected void ddlCubeName_SelectedIndexChanged(object sender, EventArgs e)
    {
        Master.Message = string.Empty;
        DisplayDimensions(ddlCubeName.SelectedValue);
    }

    #endregion

    #region utilities

    /// <summary>
    /// Return fact joined with audit table.
    /// </summary>
    /// <param name="getAll">get max display or all rows for download</param>
    /// <param name="rowsSkipped">the number of rows not fetched and displayed</param>
    /// <returns></returns>
    private ArrayList GetAuditObjects(bool getAll, out int rowsSkipped) {
        FactDTO f = new FactDTO();
        ProductOfferFact prodOfferFact = new ProductOfferFact();
        EquipmentFact equipmentFact = new EquipmentFact();
        PlanningActualFact planningFact = new PlanningActualFact();
        DevicePaymentLoanFact dpFact = new DevicePaymentLoanFact();
        string outString = string.Empty;

        f.TableName = ddlCubeName.SelectedValue;
        switch (ddlCubeName.SelectedValue) {

            #region Create location related filters

            case "Location":
                if (!CreateDimensionFilter(txtReportingLine, "REPORTING_LINE", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Reporting Line.";
                } else {
                    f.ReportingLine = outString;
                }
                if (!CreateDimensionFilter(txtAccount, "ACCOUNT", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Account.";
                } else { 
                    f.Account = outString; 
                }
                if (!CreateDimensionFilter(txtKPI, "KPI", out outString)) {
                    Master.Message += "<br>An invalid value was specified for KPI.";
                } else { 
                    f.KPI = outString; 
                }
                if (!CreateDimensionFilter(txtView, "VIEWS", out outString)) {
                    Master.Message += "<br>An invalid value was specified for View.";
                } else {
                    f.View = outString;
                }
                if (!CreateDimensionFilter(txtScenario, "SCENARIO", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Scenario.";
                } else {
                    f.Scenario = outString;
                }
                if (!CreateDimensionFilter(txtProduct, "PRODUCT", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Product.";
                } else {
                    f.Product = outString;
                }
                if (!CreateDimensionFilter(txtSubAccount, "SUBACCOUNT", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Sub Account.";
                } else {
                    f.SubAccount = outString;
                }
                if (!CreateDimensionFilter(txtServiceType, "SERVICE_TYPE", out outString)) {
                    Master.Message += "<br>An invalid value was specified for  Service Type.";
                } else {
                    f.ServiceType = outString;
                }
                if (!CreateDimensionFilter(txtFunction, "FUNCTION", out outString)) {
                    Master.Message += "<br>An invalid value was specified for  Function.";
                } else {
                    f.Function = outString;
                }
                if (!CreateDimensionFilter(txtCostCenter, "COST_CENTER", out outString)) {
                    Master.Message += "<br>An invalid value was specified for  Cost Center.";
                } else {
                    f.CostCenter = outString;
                }
                if (!CreateDimensionFilter(txtEntity, "Location", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Location.";
                } else {
                    f.Entity = outString;
                }
                if (!CreateDimensionFilter(txtEquipment, "EQUIPMENT", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Equipment.";
                } else {
                    f.Equipment = outString;
                }
                if (!CreateDimensionFilter(txtTechType, "TECH_TYPE", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Tech Type.";
                } else {
                    f.TechType = outString;
                }
                if (!CreateDimensionFilter(txtStoreStatus, "STORE_STATUS", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Store Status.";
                } else {
                    f.StoreStatus = outString;
                }
                if (!CreateDimensionFilter(txtDesignType, "DESIGN_TYPE", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Design Type.";
                } else {
                    f.DesignType = outString;
                }
                if (!CreateDimensionFilter(txtLocationType, "LOCATION_TYPE", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Location Type.";
                } else {
                    f.LocationType = outString;
                }
                if (!CreateDimensionFilter(txtLocationSubType, "LOCATION_SUBTYPE", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Location Sub Type.";
                } else {
                    f.LocationSubtype = outString;
                }
                if (!CreateDimensionFilter(txtLocationTierCode, "LOCATION_TIER_CODE", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Location Tier Code.";
                } else {
                    f.LocationTierCode = outString;
                }
                break;

            #endregion

            #region Create equipment related filters

            case EquipmentDropDownValue:
                if (!CreateDimensionFilter(txtReportingLine, "REPORTINGLINE", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Reporting Line.";
                } else {
                    equipmentFact.ReportingLine = outString;
                }
                if (!CreateDimensionFilter(txtKPI, "KPI", out outString)){
                    Master.Message += "<br>An invalid value was specified for KPI.";
                } else {
                    equipmentFact.KPI = outString;
                }
                if (!CreateDimensionFilter(txtView, "VIEW", out outString)) {
                    Master.Message += "<br>An invalid value was specified for View.";
                } else {
                    equipmentFact.View = outString;
                }
                if (!CreateDimensionFilter(txtScenario, "SCENARIO", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Scenario.";
                } else {
                    equipmentFact.Scenario = outString;
                }
                if (!CreateDimensionFilter(txtServiceType, "SERVICETYPE", out outString)) {
                    Master.Message += "<br>An invalid value was specified for  Service Type.";
                } else {
                    equipmentFact.ServiceType = outString;
                }
                if (!CreateDimensionFilter(txtFunction, "FUNCTION", out outString)) {
                    Master.Message += "<br>An invalid value was specified for  Function.";
                } else {
                    equipmentFact.Function = outString;
                }
                if (!CreateDimensionFilter(txtCostCenter, "COSTCENTER", out outString)) {
                    Master.Message += "<br>An invalid value was specified for  Cost Center.";
                } else {
                    equipmentFact.CostCenter = outString;
                }
                if (!CreateDimensionFilter(txtEntity, "ENTITIES", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Entities.";
                } else {
                    equipmentFact.Entity = outString;
                }
                if (!CreateDimensionFilter(txtEquipment, "EQUIPMENT", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Equipment.";
                } else {
                    equipmentFact.Equipment = outString;
                }
                if (!CreateDimensionFilter(txtTechType, "TECHTYPE", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Tech Type.";
                } else {
                    equipmentFact.TechType = outString;
                }
                if (!CreateDimensionFilter(txtMethodologyType, "METHODLOGYTYPE", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Method Type.";
                } else {
                    equipmentFact.MethodologyType = outString;
                }
                if (!CreateDimensionFilter(txtSaleType, "SALETYPE", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Sale Type.";
                } else {
                    equipmentFact.SaleType = outString;
                }
                if (!CreateDimensionFilter(txtContractTerm, "CONTRACTTERM", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Contract Term.";
                } else {
                    equipmentFact.ContractTerm = outString;
                }
                if (!CreateDimensionFilter(txtDiscountType, "DISCOUNTTYPE", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Discount Type.";
                } else {
                    equipmentFact.DiscountType = outString;
                }
                break;

            #endregion

            #region Create data warehouse related filters

            case "Data Warehouse":
                if (!CreateDimensionFilter(txtReportingLine, "REPORTINGLINE", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Reporting Line.";
                } else {
                    f.ReportingLine = outString;
                }
                if (!CreateDimensionFilter(txtAccount, "CUSTOMERACCOUNT", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Account.";
                } else {
                    f.Account = outString;
                }
                if (!CreateDimensionFilter(txtKPI, "KPI", out outString)) {
                    Master.Message += "<br>An invalid value was specified for KPI.";
                } else {
                    f.KPI = outString;
                }
                if (!CreateDimensionFilter(txtView, "VIEW", out outString)) {
                    Master.Message += "<br>An invalid value was specified for View.";
                } else {
                    f.View = outString;
                }
                if (!CreateDimensionFilter(txtScenario, "SCENARIO", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Scenario.";
                } else {
                    f.Scenario = outString;
                }
                if (!CreateDimensionFilter(txtProduct, "PRODUCT", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Product.";
                } else {
                    f.Product = outString;
                }
                if (!CreateDimensionFilter(txtSubAccount, "SUBACCOUNT", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Sub Account.";
                } else {
                    f.SubAccount = outString;
                }
                if (!CreateDimensionFilter(txtServiceType, "SERVICETYPE", out outString)) {
                    Master.Message += "<br>An invalid value was specified for  Service Type.";
                } else {
                    f.ServiceType = outString;
                }
                if (!CreateDimensionFilter(txtFunction, "FUNCTION", out outString)) {
                    Master.Message += "<br>An invalid value was specified for  Function.";
                } else {
                    f.Function = outString;
                }
                if (!CreateDimensionFilter(txtCostCenter, "COSTCENTER", out outString)) {
                    Master.Message += "<br>An invalid value was specified for  Cost Center.";
                } else {
                    f.CostCenter = outString;
                }
                if (!CreateDimensionFilter(txtEntity, "ENTITIES", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Entities.";
                } else {
                    f.Entity = outString;
                }
                if (!CreateDimensionFilter(txtEquipment, "EQUIPMENT", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Equipment.";
                } else {
                    f.Equipment = outString;
                }
                if (!CreateDimensionFilter(txtTechType, "TECHTYPE", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Tech Type.";
                } else {
                    f.TechType = outString;
                }
                if (!CreateDimensionFilter(txtPrevType, "PREVTYPE", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Previous Type.";
                } else {
                    f.PreviousType = outString;
                }
                if (!CreateDimensionFilter(txtBranch, "BRANCH", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Branch.";
                } else {
                    f.Branch = outString;
                }
                if (!CreateDimensionFilter(this.txtConnectionType, "CONNECTIONTYPE", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Connection Type.";
                } else {
                    f.ConnectionType = outString;
                }
                if (!CreateDimensionFilter(this.txtOwningGeography, "OWNINGGEO", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Owning Geography.";
                } else {
                    f.OwningGeo = outString;
                }
                if (!CreateDimensionFilter(this.txtOwningManager, "OWNINGMGR", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Owning Manager.";
                } else {
                    f.OwningMgr = outString;
                }
                if (!CreateDimensionFilter(txtSegment, "SEGMENT", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Segment.";
                } else {
                    f.Segment = outString;
                }
                if (!CreateDimensionFilter(this.txtVertical, "VERTICAL", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Vertical.";
                } else {
                    f.Vertical = outString;
                }
                if (!CreateDimensionFilter(this.txtVersion, "VERSION", out  outString)) {
                    Master.Message += "<br>An invalid value was specified for Version.";
                } else {
                    f.Version = outString;
                }
                if (!CreateDimensionFilter(txtContractTerm, "CONTRACTTERM", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Contract Term.";
                } else {
                    f.ContractTerm = outString;
                }
                if (!CreateDimensionFilter(txtProgramEligible, "PROGRAMELIGIBLE", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Program Eligible.";
                } else {
                    f.ProgramEligible = outString;
                }
                break;

            #endregion

            #region Create product offer related filters

            case ProductOfferDropDownValue:
                if (!CreateDimensionFilter(txtReportingLine, "REPORTINGLINE", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Reporting Line.";
                } else {
                    prodOfferFact.ReportingLine = outString;
                }
                if (!CreateDimensionFilter(txtEntity, "ENTITIES", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Entities.";
                } else {
                    prodOfferFact.Entity = outString;
                }
                if (!CreateDimensionFilter(txtEquipment, "EQUIPMENT", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Equipment.";
                } else {
                    prodOfferFact.Equipment = outString;
                }
                if (!CreateDimensionFilter(txtServiceType, "SERVICETYPE", out outString)) {
                    Master.Message += "<br>An invalid value was specified for  Service Type.";
                } else {
                    prodOfferFact.ServiceType = outString;
                }
                if (!CreateDimensionFilter(txtScenario, "SCENARIO", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Scenario.";
                } else {
                    prodOfferFact.Scenario = outString;
                }
                if (!CreateDimensionFilter(txtContractTerm, "CONTRACTTERM", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Contract Term.";
                } else {
                    prodOfferFact.ContractTerm = outString;
                }
                if (!CreateDimensionFilter(txtKPI, "ORGANIZATION", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Organization.";
                } else {
                    prodOfferFact.Organization = outString;
                }
                if (!CreateDimensionFilter(txtProduct, "PRODUCT", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Product.";
                } else {
                    prodOfferFact.Product = outString;
                }
                if (!CreateDimensionFilter(this.txtConnectionType, "CONNECTIONTYPE", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Connection Type.";
                } else {
                    prodOfferFact.ConnectionType = outString;
                }
                if (!CreateDimensionFilter(txtAccount, "ACCOUNT", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Account.";
                } else {
                    prodOfferFact.Account = outString;
                }
                if (!CreateDimensionFilter(txtFunction, "FUNCTION", out outString)) {
                    Master.Message += "<br>An invalid value was specified for  Function.";
                } else {
                    prodOfferFact.Function = outString;
                }
                if (!CreateDimensionFilter(txtSegment, "SEGMENT", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Segment.";
                } else {
                    prodOfferFact.Segment = outString;
                }
                if (!CreateDimensionFilter(txtCostCenter, "COSTCENTER", out outString)) {
                    Master.Message += "<br>An invalid value was specified for  Cost Center.";
                } else {
                    prodOfferFact.CostCenter = outString;
                }                
                if (!CreateDimensionFilter(txtView, "ORGCHART", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Org Chart.";
                } else {
                    prodOfferFact.OrgChart = outString;
                }
                if (!CreateDimensionFilter(txtSubAccount, "ACCOUNTSIZE", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Account Size.";
                } else {
                    prodOfferFact.AccountSize = outString;
                }
                if (!CreateDimensionFilter(txtEntity, "HRHV", out outString)) {
                    Master.Message += "<br>An invalid value was specified for HRHV.";
                } else {
                    prodOfferFact.HRHV = outString;
                }
                if (!CreateDimensionFilter(txtTechType, "ETHNICITY", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Ethnicity.";
                } else {
                    prodOfferFact.Ethnicity = outString;
                }
                break;

            #endregion


            #region Create product offer related filters

            case "Planning":                
                
                if (!CreateDimensionFilter(txtServiceType, "SERVICETYPE", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for  Service Type.";
                }
                else
                {
                    planningFact.ServiceType = outString;
                }
                if (!CreateDimensionFilter(txtScenario, "SCENARIO", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for Scenario.";
                }
                else
                {
                    prodOfferFact.Scenario = outString;
                }
                if (!CreateDimensionFilter(txtContractTerm, "CONTRACTTERM", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for Contract Term.";
                }
                else
                {
                    planningFact.ContractTerm = outString;
                }
                
                if (!CreateDimensionFilter(txtProduct, "PRODUCT", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for Product.";
                }
                else
                {
                    planningFact.Product = outString;
                }
                
                if (!CreateDimensionFilter(txtAccount, "ACCOUNT", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for Account.";
                }
                else
                {
                    prodOfferFact.Account = outString;
                }
                if (!CreateDimensionFilter(txtFunction, "FUNCTION", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for  Function.";
                }
                else
                {
                    planningFact.Function = outString;
                }
                if (!CreateDimensionFilter(txtBusinessSegment, "BUSINESSSEGMENT", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for Business Segment.";
                }
                else
                {
                    planningFact.BusinessSegment = outString;
                }                             
                if (!CreateDimensionFilter(txtGLAccount, "GLACCOUNT", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for GL Account.";
                }
                else
                {
                    planningFact.GLAccount = outString;
                }
                if (!CreateDimensionFilter(txtExtSegment, "EXTERNALSEGMENT", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for External Segment.";
                }
                else
                {
                    planningFact.ExternalSegment = outString;
                }
                if (!CreateDimensionFilter(txtTechType, "TECHTYPE", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for Tech Type.";
                }
                else
                {
                    planningFact.TechType = outString;
                }
                if (!CreateDimensionFilter(txtLOB, "LINEOFBUSINESS", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for Line of Business.";
                }
                else
                {
                    planningFact.LineOfBusiness = outString;
                }
                if (!CreateDimensionFilter(txtRegion, "REGION", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for Region.";
                }
                else
                {
                    planningFact.Region  = outString;
                }
                if (!CreateDimensionFilter(txtPlannedEntity, "PLANNEDENTITY", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for Planned Entity.";
                }
                else
                {
                    planningFact.PlannedEntity  = outString;
                }
                break;

            #endregion

            #region Create DPLoan related filters

            case DevicePaymentLoanDropDownValue:

                //common dimensions
                if (!CreateDimensionFilter(txtScenario, "SCENARIO", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for Scenario.";
                }
                else
                {
                    dpFact.Scenario = outString;
                }
                if (!CreateDimensionFilter(txtReportingLine, "REPORTINGLINE", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for Reporting Line.";
                }
                else
                {
                    dpFact.ReportingLine = outString;
                }
                if (!CreateDimensionFilter(txtFunction, "FUNCTION", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for Function.";
                }
                else
                {
                    dpFact.Function = outString;
                }
                if (!CreateDimensionFilter(txtContractTerm, "CONTRACTTERM", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for Contract Term.";
                }
                else
                {
                    dpFact.ContractTerm = outString;
                }
                if (!CreateDimensionFilter(txtServiceType, "SERVICETYPE", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for Service Type.";
                }
                else
                {
                    dpFact.ServiceType = outString;
                }
                if (!CreateDimensionFilter(txtEquipment, "EQUIPMENT", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for Equipment.";
                }
                else
                {
                    dpFact.Equipment = outString;
                }
                //DPLoan specific dimensions

                if (!CreateDimensionFilter(txtAging, "AGING", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for Aging.";
                }
                else
                {
                    dpFact.Aging = outString;
                }
                if (!CreateDimensionFilter(txtEntities, "ENTITIES", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for Entities.";
                }
                else
                {
                    dpFact.Entities = outString;
                }
                if (!CreateDimensionFilter(txtCustomerTenure, "CUSTOMERTENURE", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for Customer Tenure.";
                }
                else
                {
                    dpFact.CustomerTenure = outString;
                }

                if (!CreateDimensionFilter(txtCreditRiskType, "CREDITRISKTYPE", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for Credit Risk Type.";
                }
                else
                {
                    dpFact.CreditRiskType = outString;
                }

                if (!CreateDimensionFilter(txtLoanTenure, "LOANTENURE", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for Loan Tenure.";
                }
                else
                {
                    dpFact.LoanTenure = outString;
                }
                if (!CreateDimensionFilter(txtLoanVintage, "LOANVINTAGE", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for Loan Vintage.";
                }
                else
                {
                    dpFact.LoanVintage = outString;
                }
                if (!CreateDimensionFilter(txtCollectionStatus, "COLLECTIONSTATUS", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for Collection Status.";
                }
                else
                {
                    dpFact.CollectionStatus = outString;
                }
                if (!CreateDimensionFilter(txtFICO, "FICO", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for FICO.";
                }
                else
                {
                    dpFact.Fico = outString;
                }
                if (!CreateDimensionFilter(txtUpgradeEligibility, "UPG_ELIG", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for Upg Elig";
                }
                else
                {
                    dpFact.UpgradeEligibility = outString;
                }
                if (!CreateDimensionFilter(txtTranche, "TRANCHE", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for Tranche.";
                }
                else
                {
                    dpFact.Tranche = outString;
                }
                if (!CreateDimensionFilter(txtOriginalLoanEquipment, "ORIGINALLOANEQUIPMENT", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for Line of Original Loan Equipment.";
                }
                else
                {
                    dpFact.OriginalLoanEquipment = outString;
                }
                if (!CreateDimensionFilter(txtFirstPaymentMade, "FIRSTPAYMENTMADE", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for First Payment Made.";
                }
                else
                {
                    dpFact.FirstPaymentMade = outString;
                }
                if (!CreateDimensionFilter(txtWriteOffReason, "WRITEOFF_REASON", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for WriteOff Reason.";
                }
                else
                {
                    dpFact.WriteOffReason = outString;
                }
                if (!CreateDimensionFilter(txtDeactChangeReason, "DEACTCHANGEREASON", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for Deact Change Reason.";
                }
                else
                {
                    dpFact.DeactChangeReason = outString;
                }
                if (!CreateDimensionFilter(txtBillSystemCustomerType, "BILLSYSTEMCUSTOMERTYPE", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for Bill System Customer Type.";
                }
                else
                {
                    dpFact.BillSystemCustomerType = outString;
                }
                if (!CreateDimensionFilter(txtLoanStatus, "LOANSTATUS", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for Loan Status.";
                }
                else
                {
                    dpFact.LoanStatus = outString;
                }
                if (!CreateDimensionFilter(txtTreasuryTenure, "TREASURYTENURE", out outString))
                {
                    Master.Message += "<br>An invalid value was specified for TreasuryTenure.";
                }
                else
                {
                    dpFact.TreasuryTenure = outString;
                }
                break;

            #endregion

            #region Create reporting related filters

            default:
                if (!CreateDimensionFilter(txtReportingLine, "REPORTINGLINE", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Reporting Line.";
                } else {
                    f.ReportingLine = outString;
                }
                if (!CreateDimensionFilter(txtAccount, "ACCOUNT", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Account.";
                } else {
                    f.Account = outString;
                }
                if (!CreateDimensionFilter(txtKPI, "KPI", out outString)) {
                    Master.Message += "<br>An invalid value was specified for KPI.";
                } else {
                    f.KPI = outString;
                }
                if (!CreateDimensionFilter(txtView, "VIEW", out outString)) {
                    Master.Message += "<br>An invalid value was specified for View.";
                } else {
                    f.View = outString;
                }
                if (!CreateDimensionFilter(txtScenario, "SCENARIO", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Scenario.";
                } else {
                    f.Scenario = outString;
                }
                if (!CreateDimensionFilter(txtProduct, "PRODUCT", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Product.";
                } else {
                    f.Product = outString;
                }
                if (!CreateDimensionFilter(txtSubAccount, "SUBACCOUNT", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Sub Account.";
                } else {
                    f.SubAccount = outString;
                }
                if (!CreateDimensionFilter(txtServiceType, "SERVICETYPE", out outString)) {
                    Master.Message += "<br>An invalid value was specified for  Service Type.";
                } else {
                    f.ServiceType = outString;
                }
                if (!CreateDimensionFilter(txtFunction, "FUNCTION", out outString)) {
                    Master.Message += "<br>An invalid value was specified for  Function.";
                } else {
                    f.Function = outString;
                }
                if (!CreateDimensionFilter(txtCostCenter, "COSTCENTER", out outString)) {
                    Master.Message += "<br>An invalid value was specified for  Cost Center.";
                } else {
                    f.CostCenter = outString;
                }
                if (!CreateDimensionFilter(txtEntity, "ENTITY", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Entity.";
                } else {
                    f.Entity = outString;
                }
                if (!CreateDimensionFilter(txtCompany, "COMPANY", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Company.";
                } else {
                    f.Company = outString;
                }
                if (!CreateDimensionFilter(txtEquipment, "EQUIPMENT", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Equipment.";
                } else {
                    f.Equipment = outString;
                }
                if (!CreateDimensionFilter(txtTechType, "TECHTYPE", out outString)) {
                    Master.Message += "<br>An invalid value was specified for Tech Type.";
                } else {
                    f.TechType = outString;
                }        
                break;

            #endregion
        }

        if (Master.Message.Length > 0) {
            // return zero objects
            rowsSkipped = 0;
            return new ArrayList();
        }

        switch (ddlCubeName.SelectedValue) {
            case ProductOfferDropDownValue:
                return ProductOfferDatabaseAccess.GetAuditTable(prodOfferFact, ddlTime.SelectedValue, ddlYears.SelectedValue, out rowsSkipped);
            case EquipmentDropDownValue:
                return EquipmentDatabaseAccess.GetAuditTable(equipmentFact, ddlTime.SelectedValue, ddlYears.SelectedValue, out rowsSkipped);
            case "Planning":
                return PlanningActualsDatabaseAccess.GetAuditTable(planningFact, ddlTime.SelectedValue, ddlYears.SelectedValue, out rowsSkipped);
            case DevicePaymentLoanDropDownValue:
                return DevicePaymentLoanDatabaseAccess.GetAuditTable(dpFact, ddlTime.SelectedValue, ddlYears.SelectedValue, out rowsSkipped);
            default: return Utils.GetAuditTable(getAll, f, ddlDay.SelectedValue, ddlTime.SelectedValue, ddlYears.SelectedValue, out rowsSkipped);
                
        }

        
    }

    protected void DisplayDimensions(string CubeName)
    {
        this.pnlReportingLine.Visible = CubeName != "Planning";
        this.pnlCompany.Visible = CubeName == "Proforma/RPTG";
        this.pnlLocDims.Visible = CubeName == "Location";
        this.pnlProduct.Visible = CubeName != EquipmentDropDownValue && CubeName != DevicePaymentLoanDropDownValue;
        this.pnlSubAccount.Visible = CubeName != EquipmentDropDownValue && CubeName != ProductOfferDropDownValue && CubeName != "Planning" && CubeName != DevicePaymentLoanDropDownValue;
        this.pnlContractTerm.Visible = CubeName == EquipmentDropDownValue || CubeName == "Data Warehouse" || CubeName == ProductOfferDropDownValue || CubeName == "Planning" || CubeName == DevicePaymentLoanDropDownValue;
        this.pnlProgramEligible.Visible = CubeName == "Data Warehouse";
        this.pnlEqpDims.Visible = CubeName == EquipmentDropDownValue;
        this.pnlDay.Visible = CubeName == EquipmentDropDownValue;
        this.pnlDWHDims.Visible = CubeName == "Data Warehouse";
        this.pnlConnectionType.Visible = CubeName == "Data Warehouse" || CubeName == "Prod Offer";
        this.pnlSegment.Visible = CubeName == "Data Warehouse" || CubeName == "Prod Offer";

        this.pnlCostCenter.Visible = CubeName != "Data Warehouse" && CubeName != "Planning" && CubeName != DevicePaymentLoanDropDownValue;
        this.pnlProdOffer.Visible = CubeName == ProductOfferDropDownValue;
        this.pnlTechType.Visible = CubeName != ProductOfferDropDownValue && CubeName != DevicePaymentLoanDropDownValue;
        this.pnlViewKPI.Visible = CubeName != ProductOfferDropDownValue && CubeName != "Planning" && CubeName != DevicePaymentLoanDropDownValue;
        this.pnlEntity.Visible = CubeName != "Planning" && CubeName != DevicePaymentLoanDropDownValue;
        this.pnlEquipment.Visible = CubeName != "Planning";
        
        //Planning Dimesions
        this.pnlExternalSegment.Visible = CubeName == "Planning";
        this.pnlBusinessSegment.Visible = CubeName == "Planning";
        this.pnlLOB.Visible = CubeName == "Planning";
        this.pnlPlannedEntity.Visible = CubeName == "Planning";
        this.pnlRegion.Visible = CubeName == "Planning";
        this.pnlGLAccount.Visible = false; //CubeName == "Planning";

        //Device Payment Loan Dimensions
        this.pnlDevicePaymentLoan.Visible = CubeName == DevicePaymentLoanDropDownValue;
    }

    private bool CreateDimensionFilter(TextBox criteriaBox, string dimensionName, out string filter) {
        string strItems = string.Empty;
        filter = string.Empty;

        if (criteriaBox.Text.Trim().Length > 0 && criteriaBox.Visible) {
            string tableName = string.Empty;
            switch (ddlCubeName.SelectedValue) {
                case "Location": tableName = "V_LOCATION_DIMENSIONS"; break;
                case EquipmentDropDownValue: tableName = "V_EQUIPMENT_DIMENSIONS"; break;
                case "Data Warehouse": tableName = "V_DW_DIMENSIONS"; break;
                case "Planning": tableName = "V_ASO_PLANNING_DIMENSIONS"; break;
                case ProductOfferDropDownValue: tableName = ProductOfferValidationTableSql; break;
                case DevicePaymentLoanDropDownValue: tableName = DevicePaymentLoanValidationTableSql; break;
                default: tableName = "web_dimensions_tbl"; break;
            }
            int dimensionsFound = 0;
            FindAllLevel0Under(Utils.BuildDimTree(dimensionName, tableName, Master.curUser.EmployeeID), false, criteriaBox.Text.Trim().ToUpper(), ref strItems, ref dimensionsFound);
            if (strItems.Length == 0) {
                return false;
            } else {
                filter = strItems;
            }
            // jevans 8/2/2012 - restrict string of criteria to 1000 values
            if (dimensionsFound > 1000) {
                Master.Message = "The selected dimension value(s) resulted in more than 1000 criteria values, which is not permitted.";
            }
        }
        return true;
    }

    private void FindAllLevel0Under(Dimension currentNode, bool includeInArray, string findValue, ref string arrLev0s, ref int iFoundDims)
    {
        if (currentNode == null)
            return;

        if (!includeInArray) {
            if (currentNode.MemberName.Equals(findValue))
                includeInArray = true;
        }

        if (includeInArray && (currentNode.LevelNbr.Equals("Lev0") || currentNode.LevelNbr.Equals("0"))) {
            if (arrLev0s.Length > 0)
                arrLev0s += ",";
            arrLev0s += "'" + currentNode.MemberName + "'";
            iFoundDims++;
        }

        if (currentNode.arrChildren != null && currentNode.arrChildren.Count > 0)
        {
            foreach (Dimension Node in currentNode.arrChildren)
                FindAllLevel0Under(Node, includeInArray, findValue, ref arrLev0s, ref iFoundDims);
        }
    }

    public class SortByAuditAlias : IComparer
    {
        public int Compare(object obj1, object obj2)
        {
            Dimension dim1 = (Dimension)obj1;
            Dimension dim2 = (Dimension)obj2;

            return -(String.Compare(dim1.Alias, dim2.Alias));
        }

    #endregion
    }
}

