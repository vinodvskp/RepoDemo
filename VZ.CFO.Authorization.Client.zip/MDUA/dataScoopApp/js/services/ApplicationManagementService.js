﻿(function () {
    angular.module('vmApp')
.service('applicationManagementService', ['$q', '$http', 'authenticationService', 'serverVariableService', applicationManagementService]);

    function applicationManagementService($q, $http, authenticationService, serverVariableService) {
        var self = this;

        self.getAllApplications = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getAllApplicationsWorker, successCallback, errorCallback);
        }

        function getAllApplicationsWorker(authToken, payload) {
            return $http({
                method: 'GET',
                headers: { 'Authorization': authToken },
                url: serverVariableService.DATASCOOP_ENDPOINT() + '/ApplicationMgrService.svc/RestService/GetApplications?employeeId='+ payload.employeeId
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return applications data");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }

        self.getAllTemplates = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getTemplatesWorker, successCallback, errorCallback);
        }

        function getTemplatesWorker(authToken, payload) {
            return $http({
                method: 'GET',
                headers: { 'Authorization': authToken },
                url: serverVariableService.DATASCOOP_ENDPOINT() + '/ApplicationMgrService.svc/RestService/GetTemplates?employeeId=' + payload.employeeId + '&applicationId=' + payload.applicationId
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return templates data");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }

        self.getApplicationsById = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getApplicationsByIdWorker, successCallback, errorCallback);
        }

        function getApplicationsByIdWorker(authToken, payload) {
            return $http({
                method: 'GET',
                headers: { 'Authorization': authToken },
                url: serverVariableService.DATASCOOP_ENDPOINT() + '/ApplicationMgrService.svc/RestService/GetApplicationById?employeeId=' + payload.employeeId + '&applicationId=' + payload.applicationId
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return applications data");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }

        self.getTemplatesById = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getTemplatesByIdWorker, successCallback, errorCallback);
        }

        function getTemplatesByIdWorker(authToken, payload) {
            return $http({
                method: 'GET',
                headers: { 'Authorization': authToken },
                url: serverVariableService.DATASCOOP_ENDPOINT() + '/ApplicationMgrService.svc/RestService/GetTemplateById?employeeId='+ payload.employeeId + '&templateId=' + payload.templateId
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return templates data");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }
        self.getAllRepositories = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getAllRepositoriesWorker, successCallback, errorCallback);
        }

        function getAllRepositoriesWorker(authToken, payload) {
            return $http({
                method: 'GET',
                headers: { 'Authorization': authToken },
                url: serverVariableService.DATASCOOP_ENDPOINT() + '/ApplicationMgrService.svc/RestService/GetAllRepos'
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return repositories data");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }
        self.saveTemplate = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, saveTemplateWorker, successCallback, errorCallback);
        }

        function saveTemplateWorker(authToken, payload) {
            return $http({
                method: 'POST',
                headers: { 'Authorization': authToken },
                url: serverVariableService.DATASCOOP_ENDPOINT() + '/ApplicationMgrService.svc/RestService/SaveTemplate?employeeId=' + payload.employeeId + '&applicationId=' + payload.applicationId,
                data: payload.template
            })
             .then(function (response) {
                 if (response.status == 200) {
                     // this callback will be called asynchronously
                     // when the response is available
                     return $q.when(response.data);
                 }
                 else {
                     return $q.reject("request call does not return groups data");
                 }
             }, function (response) {
                 var resp = response;
                 return $q.reject(resp);
             });
        }
        self.saveApplication = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, saveApplicationWorker, successCallback, errorCallback);
        }

        function saveApplicationWorker(authToken, payload) {            
            return $http({
                method: 'POST',
                headers: { 'Authorization': authToken },
                url: serverVariableService.DATASCOOP_ENDPOINT() + '/ApplicationMgrService.svc/RestService/SaveApplication?employeeId=' + payload.employeeId,
                data: payload.application
            })
                      .then(function (response) {
                          if (response.status == 200) {
                              // this callback will be called asynchronously
                              // when the response is available
                              return $q.when(response.data);
                          }
                          else {
                              return $q.reject("request call does not return save application data");
                          }
                      }, function (response) {
                          var resp = response;
                          return $q.reject(resp);
                      });
        }

        self.getallSheetOperations = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, allSheetsOperationsWorker, successCallback, errorCallback);
        }

        function allSheetsOperationsWorker(authToken, payload) {
            var url = serverVariableService.DATASCOOP_ENDPOINT() + '/ApplicationMgrService.svc/RestService/GetAllSheetOperations';
            return $http({
                method: 'GET',
                headers: { 'Authorization': authToken },
                url: url,
                data: payload.template
            })
                      .then(function (response) {
                          if (response.status == 200) {
                              // this callback will be called asynchronously
                              // when the response is available
                              return $q.when(response.data);
                          }
                          else {
                              return $q.reject("request call does not return all Sheets Operations");
                          }
                      }, function (response) {
                          var resp = response;
                          return $q.reject(resp);
                      });
        }

        self.downloadTemplate = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, downloadTemplateWorker, successCallback, errorCallback);
        }

        function downloadTemplateWorker(authToken, payload) {
            var url = serverVariableService.DATASCOOP_ENDPOINT() + '/ApplicationMgrService.svc/RestService/DownloadTemplate?templateId=' + payload.templateId
            return $http({
                method: 'GET',
                headers: { 'Authorization': authToken },
                url: url,
                data: payload.template
            })
                      .then(function (response) {
                          if (response.status == 200) {
                              // this callback will be called asynchronously
                              // when the response is available
                              return $q.when(response.data);
                          }
                          else {
                              return $q.reject("request call does not download template");
                          }
                      }, function (response) {
                          var resp = response;
                          return $q.reject(resp);
                      });
        }

        self.uploadTemplate = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, uploadTemplateWorker, successCallback, errorCallback);
        }

        function uploadTemplateWorker(authToken, payload) {
            var url = serverVariableService.DATASCOOP_ENDPOINT() + '/ApplicationMgrService.svc/RestService/UploadTemplateWithName?templateId=' + payload.templateId + '&name=' + payload.templateFileName;
            return $http({
                method: 'POST',
                headers: { 'Authorization': authToken },
                url: url,
                data: '"' +  payload.base64EncodedFile + '"'
            })
                      .then(function (response) {
                          if (response.status == 200) {
                              // this callback will be called asynchronously
                              // when the response is available
                              return $q.when(response.data);
                          }
                          else {
                              return $q.reject("request call does not upload template");
                          }
                      }, function (response) {
                          var resp = response;
                          return $q.reject(resp);
                      });
        }

        self.deleteTemplate = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, deleteTemplateWorker, successCallback, errorCallback);
        }

        function deleteTemplateWorker(authToken, payload) {
            var url = serverVariableService.DATASCOOP_ENDPOINT() + '/ApplicationMgrService.svc/RestService/DeleteTemplate?employeeId=' + payload.employeeId + '&applicationId=' + payload.applicationId  + '&templateId=' + payload.templateId;
            return $http({
                method: 'POST',
                headers: { 'Authorization': authToken },
                url: url
            })
            .then(function (response) {
                if (response.status == 200) {
                    // this callback will be called asynchronously
                    // when the response is available
                    return $q.when(response.data);
                }
                else {
                    return $q.reject("request call does not upload template");
                }
                }, function (response) {
                var resp = response;
                return $q.reject(resp);
            });
        }


        self.getSprocConfigs = function (payload, successCallback, errorCallback) {
            authenticationService.serviceCallDispatcher(payload, getSprocConfigsWorker, successCallback, errorCallback);
        }

        function getSprocConfigsWorker(authToken, payload) {
            var url = serverVariableService.DATASCOOP_ENDPOINT() + '/ApplicationMgrService.svc/RestService/GetSprocConfigs?applicationId=' + payload.applicationId;
            return $http({
                method: 'GET',
                headers: { 'Authorization': authToken },
                url: url,
                data: payload.template
            })
                      .then(function (response) {
                          if (response.status == 200) {
                              // this callback will be called asynchronously
                              // when the response is available
                              return $q.when(response.data);
                          }
                          else {
                              return $q.reject("request call does not return all Sheets Operations");
                          }
                      }, function (response) {
                          var resp = response;
                          return $q.reject(resp);
                      });
        }
    }

}());