﻿
(function () {

    angular.module('vmApp')
        .controller('ApplicationManagementController', ['$scope', '$q', '$log', '$filter', '$uibModal', 'alertingService', 'orderByFilter', 'spinnerService', 'applicationManagementService', 'serverVariableService', ApplicationManagementController])
        .controller('uploadTemplateModalInstanceController', ['$uibModalInstance', 'templateId', function ($uibModalInstance, templateId) {
            var self = this;
            self.SelectedTemplateId = templateId;
            self.FileUploadVM = null;
            self.ok = function ($event) {
                $uibModalInstance.close(self.FileUploadVM);
            }
            self.cancel = function () {
                $uibModalInstance.dismiss('cancel');
            };
            self.onFileSelect = function (fileUpload) {
                self.FileUploadVM = new FileUploadViewModel(self.SelectedTemplateId, '', '', '');
                //$scope.$apply();
                var files = fileUpload.files;
                if (files.length > 0) {
                    var fileReader = new FileReader();
                    var fileNameSplit = files[0].name.split('.');
                    var fileExtension = fileNameSplit[fileNameSplit.length - 1];
                    if (fileExtension.toUpperCase() == 'XLSX' || fileExtension.toUpperCase() == "XLS") {
                        fileReader.readAsDataURL(files[0]);
                        fileReader.onload = function (event) {
                            self.FileUploadVM.base64EncodedFile = event.target.result.split(',')[1];
                            self.FileUploadVM.templateFileName = files[0].name;
                            //self.FileUploadVM.isFileLoading = "complete";
                            //$scope.$apply();
                        }
                    }
                    else {
                        self.FileUploadVM = null;
                        $("#fileform")[0].reset();
                        //$scope.$apply();
                    }

                    //if (window.FormData !== undefined) {
                    //    var data = new FormData();
                    //    data.append("file0", files[0]);
                    //    self.fileUploadTabVM.File = data;
                    //    self.fileUploadTabVM.IsFileLoading = "complete";
                    //    self.fileUploadTabVM.FileDisplayText = files[0].name;
                    //    $scope.$apply();
                    //}
                    //else {
                    //    self.$parent.showAlert('danger', 'Your browser does not support file upload. Please use another browser.');
                    //}
                }


            }

        }])
        .controller('deleteTemplateModalInstanceController', ['$uibModalInstance', function ($uibModalInstance) {
            var self = this;
            self.ok = function ($event) {
                $uibModalInstance.close("OK");
            }
            self.cancel = function () {
                $uibModalInstance.dismiss('cancel');
            };

        }])
        .controller('orderSheetModalInstanceController', ['$uibModalInstance', 'cubeSheets', function ($uibModalInstance, cubeSheets) {
            var self = this;
            self.CubeSheets = cubeSheets;
            self.SeletedSheetIndex = null;
            self.ok = function ($event) {
                $uibModalInstance.close(self.CubeSheets);
            }
            self.cancel = function () {
                $uibModalInstance.dismiss('cancel');
            };
            self.up = function () {
                if (self.SeletedSheetIndex > 0) {
                    self.CubeSheets.splice(self.SeletedSheetIndex - 1, 0, self.CubeSheets.splice(self.SeletedSheetIndex, 1)[0]);
                    self.SeletedSheetIndex--;
                }
            }
            self.down = function () {
                if (self.SeletedSheetIndex < self.CubeSheets.length - 1) {
                    self.CubeSheets.splice(self.SeletedSheetIndex + 1, 0, self.CubeSheets.splice(self.SeletedSheetIndex, 1)[0]);
                    self.SeletedSheetIndex++;
                }

            }

        }])
        .controller('editApplicationModalInstanceController', ['$uibModalInstance', 'selectedApplication', function ($uibModalInstance, selectedApplication) {
            var self = this;
            self.selectedApplication = selectedApplication;
            self.ok = function ($event) {

                $uibModalInstance.close(selectedApplication);
            }
            self.cancel = function () {
                $uibModalInstance.dismiss('cancel');
            };

        }]);

    function ApplicationManagementController($scope, $q, $log, $filter, uibModal, alertingService, orderByFilter, spinnerService, applicationManagementService, serverVariableService) {
        var self = this;
        self.appMgmtTab = "appMgmtTab";
        self.templateMgmtTab = "templateMgmttab";
        self.createEditTmplTab = "createEditTmplTab";
        self.activeTab = "";
        self.applicationsInfo = [];
        self.templatesInfo = [];
        self.selectedApplication = undefined;
        self.selectedTemplate = undefined;
        self.addNewTemplate = undefined;
        self.showAllColumns = false;
        self.allRepositories = [];
        var allRepositories = [];

        $scope.availableSprocs = [];

        $scope.vm.validationSummary = [];
        $scope.vm.popupValidationSummary = [];
        $scope.opsRangeViewModel = {};
        self.rangeTypes = {
            VALIDVALUES: "VALIDVALUES",
            INVALIDVALUES: "INVALIDVALUES",
            RANGE: "RANGE"
        }
        self.ranges = {};

        self.FileUploadVM = null;

        $scope.showAlert = function (alertType, message) {
            console.log(message);
            $scope.vm.validationSummary.push({ type: alertType, msg: message });
        }
        $scope.closeValidationSummary = function (index) {
            $scope.vm.validationSummary.splice(index, 1);
        };

        $scope.showAlertinPopup = function (alertType, message) {
            console.log(message);
            $scope.vm.popupValidationSummary.push({ type: alertType, msg: message });
        }
        $scope.closepopupValidationSummary = function (index) {
            $scope.vm.popupValidationSummary.splice(index, 1);
        };

        self.ErrorBases = [
            {
                name: "ErrorDivideByZero",
                value: -2146826281,
                isSelected: false
            },
            {
                name: "ErrorNotAvailable",
                value: -2146826246,
                isSelected: false
            },
			{
			    name: "ErrorNotValidCell",
			    value: -2146826259,
			    isSelected: false
			},
            {
                name: "ErrorNotValidFormula",
                value: -2146826288,
                isSelected: false
            },
            {
                name: "ErrorNotValidNumericValue",
                value: -2146826252,
                isSelected: false
            },
            {
                name: "ErrorNotValidValue",
                value: -2146826265,
                isSelected: false
            },
            {
                name: "ErrorNullValue",
                value: -2146826273,
                isSelected: false
            }
        ];

        self.OnSelectApplication = function (application) {
            //self.selectedApplication = angular.copy(application);
            self.selectedApplication = application;
            self.templateMgmtGridOptions.data = self.selectedApplication.CubeTemplates;
            //self.templateMgmtGridOptions.data = application.CubeTemplates.map(function (tmpl) {
            //self.templateMgmtGridOptions.data = self.selectedApplication.CubeTemplates.map(function (tmpl) {
            //    if (tmpl.LastRunOn) {
            //        tmpl.LastRunOn = $filter('mydate')(tmpl.LastRunOn);
            //    }
            //    if (tmpl.lastModifiedBy) {
            //        tmpl.LastModifiedBy = $filter('mydate')(tmpl.LastModifiedBy);
            //    }
            //    return tmpl;
            //});


            applicationManagementService.getSprocConfigs({ applicationId: self.selectedApplication.Id },
                function (data) {
                    $scope.availableSprocs.splice(0, $scope.availableSprocs.length);
                    for (var i = 0; i < data.length; i++) {
                        $scope.availableSprocs.push(data[i]);
                    }
                },
                function (error) {
                    console.log("Error fetching sprocs");
                });
        }




        self.OnSelectTemplate = function (template) {
            self.selectedTemplate = template;
            self.OperationsMgmtGridOptions.data = [];
            self.selectedSheet = undefined;
        }

        self.OnSelectSheet = function (sheet) {
            spinnerService.show("overlaySpinner");
            self.selectedSheet = sheet;
            self.OperationsMgmtGridOptions.data = sheet.OperationTypes;
            allRepositories = allRepositories.map(function (r) { r.isSelected = false; return r; });
            if (self.selectedSheet.Repos) {
                self.allRepositories = allRepositories.filter(function (repo) { return self.selectedSheet.Repos.filter(function (eRepo) { return repo.Id == eRepo.Id }).length == 0 });
            }
            else {
                self.allRepositories = allRepositories;
            }
            spinnerService.hide("overlaySpinner");
        }

        self.addNewTemplate = function (application) {
            self.addNewTemplate = application;
        }

        self.formatJsonDate = function (x) {
            if (x != null) {
                var s = x.substr(0, x.length - 2)
                var substringedDate = s.substring(6);
                var parsedIntDate = parseInt(substringedDate);
                return new Date(parsedIntDate);
            }
            else {
                return "-";
            }
        }

        self.appMgmtGridOptions = {

            columnDefs: [
							{
							    name: "",
							    field: "Id",
							    width: 40,
							    cellTemplate: '<div class="ui-grid-cell-contents"><input type="radio" name="selectApplication" ng-click="grid.appScope.appMgmt.OnSelectApplication(row.entity)" /></div>'
							},
							{ name: "Application Name", field: "Name" },
							//{ name: "Current Status", field: "CurrentRunStatus" },
							//{ name: "LastRunStatus", field: "LastRunStatus" },
							{ name: "InputOperation", field: "InputOperation" },
							{ name: "MaxCurrentProcess", field: "MaxConcurrentProcess" },
                            { name: "LastModifiedBy", field: "LastModifiedOn" },
							{
							    name: "LastModifiedDate",
							    field: "LastModifiedBy",
							    //cellTemplate: '<div class="ui-grid-cell-contents">{{row.entity.LastModifiedBy | date:"MM\u002fdd\u002fyyyy HH\u003amm\u003ass"}}</div>'
							    cellTemplate: '<div class="ui-grid-cell-contents">{{grid.appScope.appMgmt.formatJsonDate(row.entity.LastModifiedBy) | date:"MM\u002fdd\u002fyyyy HH\u003amm\u003ass"}}</div>'
							}],
            enableFiltering: false,
            enableSorting: true,
            showGridFooter: true,
        };

        self.templateMgmtGridOptions = {
            columnDefs: [],
            enableFiltering: false,
            enableSorting: true,
            showGridFooter: true,
        };

        self.OperationsMgmtGridOptions = {
            columnDefs: [

                         { name: "Operation Name", field: "OperationDesc" },
                         { name: "Input Parameters", field: "InputOperation" },
                         {
                             name: "Actions", field: "TemplateFileName",
                             cellTemplate: '<div class="ui-grid-cell-contents"><a href="javascript:void(0)" ng-click="grid.appScope.appMgmt.OpenModalForOpsForm(row.entity)">edit</a> / <a href="javascript:void(0)" ng-click="grid.appScope.appMgmt.confirmDeletionForOperation(row.entity)">delete </a></div>'
                         }],

            enableFiltering: false,
            enableSorting: true,
            showGridFooter: true,
        };



        self.toggleTemplateColumns = function (showAllColumns) {
            self.showAllColumns = showAllColumns;
            var requiredColumnsDef = [];
            if (self.showAllColumns) {
                requiredColumnsDef = [
                                {
                                    name: "",
                                    field: "Id",
                                    width: 40,
                                    cellTemplate: '<div class="ui-grid-cell-contents"><input type="radio" name="OnSelectTemplate" ng-click="grid.appScope.appMgmt.OnSelectTemplate(row.entity)" /></div>'
                                },
                                { name: "Name", field: "Name" },
                                { name: "File Name", field: "TemplateFileName" },
                                { name: "Is Standalone", field: "IsStandalone" },
                                { name: "Last run status", field: "LastRunStatus" },
                                {
                                    name: "LastRunDate",
                                    field: "LastRunOn",
                                    cellTemplate: '<div class="ui-grid-cell-contents">{{grid.appScope.appMgmt.formatJsonDate(row.entity.LastRunOn) | date:"MM\u002fdd\u002fyyyy HH\u003amm\u003ass"}}</div>'
                                },
                                { name: "Curent status", field: "CurrentRunStatus" },
                                { name: "Order", field: "OrderNo" },
                                { name: "Continue on Fail", field: "IsContinueOnFail" },
                                { name: "Last Modified By", field: "LastModifiedOn" },
                                {
                                    name: "Last Modified On",
                                    field: "LastModifiedBy",
                                    cellTemplate: '<div class="ui-grid-cell-contents">{{grid.appScope.appMgmt.formatJsonDate(row.entity.LastModifiedBy) | date:"MM\u002fdd\u002fyyyy HH\u003amm\u003ass"}}</div>'
                                }];


            }
            else {
                requiredColumnsDef = [
                                {
                                    name: "",
                                    field: "Id",
                                    width: 40,
                                    cellTemplate: '<div class="ui-grid-cell-contents"><input type="radio" name="OnSelectTemplate" ng-click="grid.appScope.appMgmt.OnSelectTemplate(row.entity)" /></div>'
                                },
                                { name: "Name", field: "Name" },
                                { name: "File Name", field: "TemplateFileName" },
                                { name: "Is Standalone", field: "IsStandalone" },
                                { name: "Order", field: "OrderNo" },
                                { name: "Continue on Fail", field: "IsContinueOnFail" }];
            }

            self.templateMgmtGridOptions.columnDefs = requiredColumnsDef;
        }

        var getRangeStringFromArray = function (rangeName) {

            var rangeStr = rangeName + "~";
            if (self.ranges[rangeName]) {
                rangeStr += self.ranges[rangeName].map(function (r) {
                    var rStr = "";
                    if (r.from || r.to || r.from != undefined || r.to != undefined) {
                        rStr = r.from + ((r.from || r.from == 0) && (r.to || r.to == 0) ? ":" : "") + r.to;
                    }
                    return rStr;
                }).join(",");;
            }
            return rangeStr;
        }
        var getRangeString = function (rangeName, from, to) {

            var rangeStr = rangeName + "~";

            if (from || to || from != undefined || to != undefined) {
                rangeStr += from + ((from || from == 0) && (to || to == 0) && from.length > 0 ? ":" : "") + to;

            }
            return rangeStr;
        }

        self.selectSproc = function (selectedSproc) {
            if ($scope.opsViewModel != null) {
                $scope.opsViewModel.SelectedSproc = selectedSproc;
            }
            else {
                console.log("selectedSproc: opsViewModel not found");
            }
            
        }

        //Edit or Add operations
        self.OpenModalForOpsForm = function (opsModel) {
            var isNew = false;
            var prevOpsModel = {};
            self.ranges = {};
            // remove data interferance with previous operation viewmodel.
            $scope.opsViewModel = angular.copy({});
            if (!opsModel) {
                isNew = true;
                // adding new item to operatioins
                $scope.opsViewModel = opsModel || {};
            }
            else {
                prevOpsModel = opsModel;
            }

            //Assign The values in Edit Mode
            $scope.opsViewModel.OperationType = prevOpsModel.OperationType;
            $scope.opsViewModel.OperationDesc = prevOpsModel.OperationDesc;
            $scope.opsViewModel.IsContinueOnFail = (prevOpsModel.IsContinueOnFail == undefined || prevOpsModel.IsContinueOnFail == null) ? true : prevOpsModel.IsContinueOnFail;
            $scope.opsRangeViewModel.ospModelValidFrom = "";
            $scope.opsRangeViewModel.ospModelValidTo = "";
            $scope.opsRangeViewModel.ospModelInValidFrom = "";
            $scope.opsRangeViewModel.ospModelInValidTo = "";
            $scope.opsRangeViewModel.isNumeric = false;

            $scope.opsViewModel.QlikTaskName = "";
            $scope.opsViewModel.SelectedSproc = null;


            var InValidValuesSplit = [];
            if (prevOpsModel.InputOperation != null) {

                $scope.ShowRangeOperationType = true;
                var res = prevOpsModel.InputOperation.split("|");

                //Valida Values
                var ValidValuesSplit = res[0].split("~")[1].split(":");
                if (ValidValuesSplit[0] == "ISNUMERIC") {
                    $scope.opsRangeViewModel.isNumericSelected = true;
                }
                else {
                    $scope.opsRangeViewModel.isNumericSelected = false;
                    $scope.opsRangeViewModel.ospModelValidFrom = typeof ValidValuesSplit[0] == "undefined" ? "" : ValidValuesSplit[0];
                    $scope.opsRangeViewModel.ospModelValidTo = typeof ValidValuesSplit[1] == "undefined" ? "" : ValidValuesSplit[1];

                }

                //Invalid Values
                if (res[1].indexOf(",") >= 0) {
                    var InValidValuesSplit1 = res[1].split("~");
                    var InValidValuesSplit2 = InValidValuesSplit1[1].split(",");
                    if (InValidValuesSplit2[0].indexOf(":") >= 0) {
                        var InValidValuesSplit3 = InValidValuesSplit2[0].split(":");
                        $scope.opsRangeViewModel.ospModelInValidFrom = typeof InValidValuesSplit3[0] == "undefined" ? "" : InValidValuesSplit3[0];
                        $scope.opsRangeViewModel.ospModelInValidTo = typeof InValidValuesSplit3[1] == "undefined" ? "" : InValidValuesSplit3[1];

                        InValidValuesSplit = InValidValuesSplit2;
                    }
                    else {

                        InValidValuesSplit = InValidValuesSplit2;
                    }


                }
                else {
                    InValidValuesSplit = res[1].split(",")[0].split("~")[1].split(":");
                    if (InValidValuesSplit.length == 1) {
                        InValidValuesSplit = InValidValuesSplit;
                    }
                    else {

                        $scope.opsRangeViewModel.ospModelInValidFrom = typeof InValidValuesSplit[0] == "undefined" ? "" : InValidValuesSplit[0];
                        $scope.opsRangeViewModel.ospModelInValidTo = typeof InValidValuesSplit[1] == "undefined" ? "" : InValidValuesSplit[1];
                    }
                }

                //Range
                var RangeValuesSplit = res[2].split("~");
                var RangeValuesSplit1 = RangeValuesSplit[1].split(",");
                for (var i = 0; i < RangeValuesSplit1.length; i++) {
                    var RangeValuesSplit2 = RangeValuesSplit1[i].split(":");
                    $scope.opsRangeViewModel.ospModelRangeFrom = typeof RangeValuesSplit2[0] == "undefined" ? "" : RangeValuesSplit2[0];
                    $scope.opsRangeViewModel.ospModelRangeTo = typeof RangeValuesSplit2[1] == "undefined" ? "" : RangeValuesSplit2[1];
                    self.addToRanges("RANGE");
                }


            }
            else {
                $scope.ShowRangeOperationType = false;
                InValidValuesSplit = [];
                $scope.opsRangeViewModel.ospModelValidFrom = "";
                $scope.opsRangeViewModel.ospModelValidTo = "";
                $scope.opsRangeViewModel.ospModelInValidFrom = "";
                $scope.opsRangeViewModel.ospModelInValidTo = "";

            }


            $scope.opsFormPopUp = uibModal.open({
                animation: true,
                templateUrl: 'OperationsViewModalForm.html',
                size: 'lg',
                scope: $scope,
                windowClass: "dimension-form-container"
            });

            // $scope.opsRangeViewModel.ospModelRangeFrom = $scope.opsRangeViewModel.ospModelRangeTo = $scope.opsRangeViewModel.ospModelInValidFrom = $scope.opsRangeViewModel.ospModelInValidTo = $scope.opsRangeViewModel.ospModelValidFrom = $scope.opsRangeViewModel.ospModelValidTo = "";
            self.ErrorBases = self.ErrorBases.map(function (eb) {
                eb.isSelected = false;
                if (InValidValuesSplit.length == 0) {
                    eb.isSelected = false;
                }
                else {
                    $.each(InValidValuesSplit, function (i, val) {
                        if (eb.value == val) {
                            eb.isSelected = true;
                        }
                    });

                }
                return eb;
            });

                      
            $scope.opsFormPopUp.result.then(function (isConfirmed) {
                if (isConfirmed) {
                    if ($scope.opsViewModel.OperationType == 6) {
                        var selectedErrorBaseValue = self.ErrorBases.filter(function (eb) { return eb.isSelected; }).map(function (eb) { return eb.value; }).join(",");
                        var invalidRangeValue = getRangeString(self.rangeTypes.INVALIDVALUES, $scope.opsRangeViewModel.ospModelInValidFrom, $scope.opsRangeViewModel.ospModelInValidTo);
                        var validValues = "";

                        if ($scope.opsRangeViewModel.isNumeric) {
                            validValues = "VALIDVALUES~ISNUMERIC";
                        }
                        else {
                            validValues = getRangeString("VALIDVALUES", $scope.opsRangeViewModel.ospModelValidFrom, $scope.opsRangeViewModel.ospModelValidTo);
                        }

                        if (selectedErrorBaseValue != "") {
                            invalidRangeValue = ($scope.opsRangeViewModel.ospModelInValidFrom || $scope.opsRangeViewModel.ospModelInValidTo) ? invalidRangeValue + "," + selectedErrorBaseValue : invalidRangeValue + selectedErrorBaseValue;
                        }

                        $scope.opsViewModel.InputOperation = validValues + "|" + invalidRangeValue + "|" + getRangeStringFromArray("RANGE");
                    }

                    if ($scope.opsViewModel.OperationType == 8) {
                        $scope.opsViewModel.InputOperation = $scope.opsViewModel.QlikTaskName;
                    }

                    if ($scope.opsViewModel.OperationType == 5) {
                        $scope.opsViewModel.InputOperation = $scope.opsViewModel.SelectedSproc.Name;
                    }

                    if (isNew) {
                        self.selectedSheet.OperationTypes = self.selectedSheet.OperationTypes ? self.selectedSheet.OperationTypes : [];
                        self.selectedSheet.OperationTypes.push($scope.opsViewModel);
                        self.OperationsMgmtGridOptions.data = self.selectedSheet.OperationTypes;
                        $scope.opsRangeViewModel.ospModelValidFrom = "";
                        $scope.opsRangeViewModel.ospModelValidTo = "";
                        $scope.opsRangeViewModel.isNumeric = "";
                        $scope.opsViewModel.QlikTaskName = "";
                        $scope.opsViewModel.SelectedSproc = null;
                    }
                    else {
                        angular.extend(opsModel, $scope.opsViewModel);
                    }
                    // save/update the Operation item/model
                } else {
                    if (!isNew) {
                        angular.extend($scope.opsViewModel, prevOpsModel);
                    }
                    //discard the save/update.
                }
            }, function (error) {

            })
        }
        self.confirmDeletionForOperation = function (operation) {
            $scope.opsDeletePopUp = uibModal.open({
                animation: true,
                templateUrl: 'DeleteOperationPopUp.html',
                size: 'sm',
                scope: $scope,
                windowClass: "dimension-form-container"
            });

            $scope.opsDeletePopUp.result.then(function (isConfirmed) {
                if (isConfirmed) {

                    self.selectedSheet.OperationTypes = self.selectedSheet.OperationTypes.filter(function (opn) { return opn != operation });
                    self.OperationsMgmtGridOptions.data = self.selectedSheet.OperationTypes;
                }

            });

        }

        self.confirmDeletionForSheet = function () {
            $scope.deleteSheetePopUp = uibModal.open({
                animation: true,
                templateUrl: 'DeleteSheetPopUp.html',
                size: 'sm',
                scope: $scope,
                windowClass: "dimension-form-container"
            });

            $scope.deleteSheetePopUp.result.then(function (isConfirmed) {
                if (isConfirmed) {
                    self.selectedTemplate.CubeSheets = self.selectedTemplate.CubeSheets.filter(function (sheet) { return sheet.Id != self.selectedSheet.Id });
                    self.OperationsMgmtGridOptions.data = [];
                    self.selectedSheet = undefined;
                    self.selectedApplication.CubeTemplates = self.selectedApplication.CubeTemplates.map(function (tmpl) { return tmpl.Id == self.selectedTemplate.Id ? self.selectedTemplate : tmpl; });
                    updateApplicationsGrid(self.selectedApplication);
                }
            });
        }

        //Manage Applications
        self.OpenModalForAppsForm = function (appsModal) {

            $scope.vm.validationSummary = [];
            if (!$("input[name='selectApplication']").is(':checked')) {

                $scope.showAlert('danger', "Please select at least one application.");
                return;
            }

            var modalInstance = uibModal.open({
                templateUrl: 'ApplicationsViewModalForm.html', //refers to modal content
                controller: 'editApplicationModalInstanceController as amc', //inner controller
                scope: $scope, //scope elements
                ariaLabelledBy: 'modal-title',
                ariaDescribedBy: 'modal-body',
                resolve: {
                    selectedApplication: function () {
                        return angular.copy(self.selectedApplication);
                    }
                }
                //
            });
            modalInstance.result.then(function (updatedApplication) {
                spinnerService.show("overlaySpinner");

                if (updatedApplication.Notification.ValidateRecipientsString(updatedApplication.Notification.DisplayCcRecipients)
                && updatedApplication.Notification.ValidateRecipientsString(updatedApplication.Notification.DisplayToRecipients)) {

                    updatedApplication.Notification.CcRecipients = updatedApplication.Notification.RecipientStringToObject(updatedApplication.Notification.DisplayCcRecipients);
                    updatedApplication.Notification.ToRecipients = updatedApplication.Notification.RecipientStringToObject(updatedApplication.Notification.DisplayToRecipients);
                    //make LastModifiedBy null otherwise we will have to convert the date format to json date format.
                    updatedApplication.LastModifiedBy = null;
                    var payload = { employeeId: serverVariableService.USER_EID(), application: updatedApplication };
                    applicationManagementService.saveApplication(payload, saveApplicationSuccessCallback, saveApplicationErrorCallback);
                }
                else {
                    spinnerService.hide("overlaySpinner");
                    $scope.showAlert('danger', 'Invalid Email addresses');
                }

            }, function () {
                self.FileUploadVM = null;
                console.log('Modal dismissed at: ' + new Date());
            });


        }

        function saveApplicationSuccessCallback(response) {

            if (response.ResponseType == 0) {
                $scope.showAlert('success', response.Message);
            }
            else if (response.ResponseType == 1) {
                $scope.showAlert('danger', response.Message);
            }
            else {
                $scope.showAlert('danger', 'Error occured while saving application.');
            }

            var payload = { employeeId: serverVariableService.USER_EID(), applicationId: self.selectedApplication.Id };
            applicationManagementService.getApplicationsById(payload, getApplicationsByIdSuccessCallback, getApplicationsByIdErrorCallback);

        }

        function saveApplicationErrorCallback(response) {
            $scope.showAlert('danger', 'Error occured while saving application.');
            spinnerService.hide("overlaySpinner");
        }

        function getApplicationsByIdSuccessCallback(response) {
            //var r = response;

            for (var aInd = 0; aInd < self.applicationsInfo.length; aInd++) {
                if (self.applicationsInfo[aInd].Id == response.Id) {
                    self.applicationsInfo[aInd] = new ApplicationViewModel(response);

                    self.selectedApplication = self.applicationsInfo[aInd];
                    self.templateMgmtGridOptions.data = self.selectedApplication.CubeTemplates;

                }
            }

            //self.selectedApplication = response;
            //self.applicationsInfo.push(new ApplicationViewModel(response));
            spinnerService.hide("overlaySpinner");
        }

        function getApplicationsByIdErrorCallback(response) {
            $scope.showAlert('danger', 'Error occured while retrieving application.');
            spinnerService.hide("overlaySpinner");
        }

        self.editTemplate = function (isUpdateSheet) {
            self.allRepositories = allRepositories;
            if (self.selectedTemplate) {
                spinnerService.show("overlaySpinner");
                var payload = {
                    employeeId: serverVariableService.USER_EID(),
                    templateId: self.selectedTemplate.Id
                };
                self.showLoadingSheets = true;
                applicationManagementService.getTemplatesById(payload, function (templateresponse) {
                    self.showLoadingSheets = false;
                    spinnerService.hide("overlaySpinner");
                    self.selectedTemplate = new TemplateViewModel({
                        Id: templateresponse.Id,
                        Name: templateresponse.Name,
                        TemplateFileName: templateresponse.TemplateFileName,
                        IsStandalone: templateresponse.IsStandalone,
                        IsContinueOnFail: templateresponse.IsContinueOnFail,
                        OrderNo: templateresponse.OrderNo,
                        CubeSheets: templateresponse.CubeSheets,
                        OperationTypes: templateresponse.OperationTypes,
                        Repos: templateresponse.Repos,
                        Notification: templateresponse.Notification
                    });

                    if (isUpdateSheet && self.selectedSheet != undefined && self.selectedSheet != null) {
                        var selectedSheet = self.selectedTemplate.CubeSheets.filter(function (sheet) { return sheet.Name == self.selectedSheet.Name })[0];
                        if (selectedSheet) {
                            self.selectedSheet = selectedSheet;
                        }
                    }

                }, function (error) {
                    spinnerService.hide("overlaySpinner");
                    // show error.
                });
                self.activeTab = self.createEditTmplTab;
            }

        }

        self.addTemplate = function () {
            self.showLoadingSheets = true;
            self.activeTab = self.createEditTmplTab;
            self.selectedTemplate = new TemplateViewModel({
                Id: 0,
                Name: "",
                TemplateFileName: "",
                IsStandalone: false,
                IsContinueOnFail: false,
                OrderNo: "",
                CubeSheets: []
            });

            $scope.OpsViewModel = {};
            self.showLoadingSheets = false;
        }

        var updateApplicationsGrid = function (application) {
            if (application) {
                self.applicationsInfo = self.applicationsInfo.map(function (app) {
                    return app.Id == application.Id ? angular.copy(application) : app;
                });

                self.appMgmtGridOptions.data = self.applicationsInfo;
                self.OnSelectApplication(self.selectedApplication);
            }
        }

        self.saveTemplate = function () {
            if (!self.selectedTemplate.OrderNo) {
                $scope.showAlert('danger', "Please provide Order Number.");
                return;
            }
           
            spinnerService.show("overlaySpinner");
            self.selectedTemplate.TemplateFileName = self.selectedTemplate.TemplateFileName || self.selectedTemplate.Name;

            if (self.selectedTemplate.Notification.ValidateRecipientsString(self.selectedTemplate.Notification.DisplayCcRecipients)
			&& self.selectedTemplate.Notification.ValidateRecipientsString(self.selectedTemplate.Notification.DisplayToRecipients)) {

                self.selectedTemplate.Notification.CcRecipients = self.selectedTemplate.Notification.RecipientStringToObject(self.selectedTemplate.Notification.DisplayCcRecipients);
                self.selectedTemplate.Notification.ToRecipients = self.selectedTemplate.Notification.RecipientStringToObject(self.selectedTemplate.Notification.DisplayToRecipients);

                var payLoad = {
                    employeeId: serverVariableService.USER_EID(),
                    applicationId: self.selectedApplication.Id,
                    template: self.selectedTemplate
                };
                applicationManagementService.saveTemplate(payLoad, function (response) {
                    spinnerService.hide("overlaySpinner");
                    $scope.showAlert('success', response.Message);
                    if (self.selectedTemplate.Id == 0) {
                        self.selectedTemplate.Id = response.Id;
                        self.selectedApplication.CubeTemplates.push(self.selectedTemplate);
                    }
                    else {
                        self.selectedApplication.CubeTemplates = self.selectedApplication.CubeTemplates.map(function (tmpl) {
                            if (tmpl.Id == self.selectedTemplate.Id) {
                                self.selectedTemplate.LastRunOn = tmpl.LastRunOn;
                                return angular.copy(self.selectedTemplate);
                            }
                            return tmpl;
                        });
                    }
                    self.editTemplate(true);
                    updateApplicationsGrid(self.selectedApplication);
                },
				function (error) {
				    $scope.showAlert('danger', error.Message ? error.Message : "Unable to save template");
				    spinnerService.hide("overlaySpinner");
				});
            }
            else {
                $scope.showAlert('danger', 'Invalid Email addresses');
                spinnerService.hide("overlaySpinner");
            }
        }

        self.saveApplication = function () {
            var payload = { employeeId: serverVariableService.USER_EID(), application: self.selectedApplication }
            applicationManagementService.saveApplication(payload, function (successResponse) {
                $scope.appsFormPopUp.close();
            }, function (error) {
                // show eroror occuerd
                $scope.showAlert('danger', error.Message ? error.Message : "Unable to save Application");
            });
        }

        //$scope.DownloadTemplate = function () {
        //    var downloadtemplatereq = new TemplateDownloadViewModel($scope.templateId);
        //    applicationManagementService.downloadTemplate(downloadtemplatereq);
        //}

        function TemplateDownloadViewModel(templateId) {
            var self = this;
            self.templateId = templateId;

        }

        self.addSheet = function () {
            self.selectedTemplate.CubeSheets.push(new SheetViewModel({
                Id: 0,
                Name: "New Sheet",
                OperationTypes: [],
                Repos: []
            }));
            self.OnSelectSheet(self.selectedTemplate.CubeSheets[self.selectedTemplate.CubeSheets.length - 1]);
        }

        self.addRepos = function () {
            if (!self.selectedSheet) {
                // repos can not be added if sheet is not selected.
                return;
            }
            if (!self.selectedSheet.Repos) {
                self.selectedSheet.Repos = [];
            }

            self.selectedSheet.Repos = self.selectedSheet.Repos.concat(self.allRepositories.filter(function (repo) { return repo.isSelected; }).map(function (repo) {
                var addedRepo = angular.copy(repo);
                addedRepo.isSelected = false;
                return addedRepo;
            }));
            self.allRepositories = self.allRepositories.filter(function (repo) { return !repo.isSelected });
        }

        //self.uploadTemplateFile = function (evt) {
        //    spinnerService.show("overlaySpinner");
        //    if (window.File && window.FileReader && window.FileList && window.Blob) {
        //        var files = evt.files;
        //        var file = files[0];
        //        if (files && file) {
        //            var reader = new FileReader();
        //            reader.onload = function (readerEvt) {
        //                var base64encodedStr = readerEvt.target.result;
        //                base64encodedStr = base64encodedStr.split("base64,")[1];
        //                applicationManagementService.uploadTemplate({ templateId: self.selectedTemplate.Id, base64EncodedFile: base64encodedStr }, function (successResponse) {
        //                    // success uploadTemplate
        //                    console.log(successResponse);
        //                }, function (error) {
        //                    // error
        //                    spinnerService.hide("overlaySpinner");
        //                });

        //            };
        //            reader.readAsDataURL(file);
        //        }
        //    }
        //    spinnerService.hide("overlaySpinner");
        //}

        self.removeRepos = function () {
            self.allRepositories = self.allRepositories.concat(self.selectedSheet.Repos.filter(function (repo) { return repo.isSelected; }).map(function (repo) {
                var removedRepo = angular.copy(repo);
                removedRepo.isSelected = false;
                return removedRepo;
            }));
            self.selectedSheet.Repos = self.selectedSheet.Repos.filter(function (repo) { return !repo.isSelected });

        }

        self.selectOperation = function (operation) {
            angular.extend($scope.opsViewModel, operation);
            console.log($scope.opsViewModel);
            $scope.opsRangeViewModel.ospModelValidFrom = "";
            $scope.opsRangeViewModel.ospModelValidTo = "";
            $scope.opsRangeViewModel.ospModelInValidFrom = "";
            $scope.opsRangeViewModel.ospModelInValidTo = "";
            $scope.opsRangeViewModel.isNumericSelected = false;
            $scope.opsViewModel.IsContinueOnFail = true;
            if (operation.OperationType == 6) {
                $scope.ShowRangeOperationType = true;
            }
            else {
                $scope.ShowRangeOperationType = false;

            }
        }
        self.addToRanges = function (rangeName) {
            if (!self.ranges[rangeName]) {
                self.ranges[rangeName] = [];
            }
            if ($scope.opsRangeViewModel.ospModelRangeFrom || $scope.opsRangeViewModel.ospModelRangeTo || $scope.opsRangeViewModel.ospModelRangeFrom != undefined || $scope.opsRangeViewModel.ospModelRangeTo != undefined) {
                self.ranges[rangeName].push({
                    rangeName: rangeName,
                    from: $scope.opsRangeViewModel.ospModelRangeFrom,
                    to: $scope.opsRangeViewModel.ospModelRangeTo
                });
                $scope.opsRangeViewModel.ospModelRangeFrom = $scope.opsRangeViewModel.ospModelRangeTo = "";
            }
        }

        self.removeFromValidArray = function (index, rangeName) {
            self.ranges[rangeName].splice(index, 1);
        }

        self.openModalForUploadTemplateForm = function (uploadTemplateModal) {
            var modalInstance = uibModal.open({
                templateUrl: 'UploadTemplateModalForm.html', //refers to modal content
                controller: 'uploadTemplateModalInstanceController as umc', //inner controller
                scope: $scope, //scope elements
                ariaLabelledBy: 'modal-title',
                ariaDescribedBy: 'modal-body',
                resolve: {
                    templateId: function () {
                        return self.selectedTemplate.Id;
                    }
                }
            });
            modalInstance.result.then(function (fileUploadVM) {
                spinnerService.show("overlaySpinner");
                if (fileUploadVM == null) {
                    $scope.showAlert('danger', 'Choose an excel file to upload.');
                    spinnerService.hide("overlaySpinner");
                }
                else {
                    applicationManagementService.uploadTemplate(fileUploadVM, uploadTemplateSuccessCallback, uploadTemplateErrorCallback);
                }

            }, function () {
                //self.FileUploadVM = null;
                console.log('Modal dismissed at: ' + new Date());
            });

        }

        self.onDownloadTemplate = function (templateId, fileName) {
            var dlAnchor = $("#downloadAnchor")[0];
            dlAnchor.href = generateDownloadTemplateURL(templateId, fileName);
            dlAnchor.target = '_self';
            //dlAnchor.attr('download', 'DownloadTemplate.xlsx');
            $("#downloadAnchor")[0].click();
        }

        self.openModalForDeleteTemplateForm = function (uploadTemplateModal) {
            var modalInstance = uibModal.open({
                templateUrl: 'DeleteTemplateModalForm.html', //refers to modal content
                controller: 'deleteTemplateModalInstanceController as dmc', //inner controller
                scope: $scope, //scope elements
                ariaLabelledBy: 'modal-title',
                ariaDescribedBy: 'modal-body'
                //
            });
            modalInstance.result.then(function (confirm) {
                spinnerService.show("overlaySpinner");

                var payload = { employeeId: serverVariableService.USER_EID(), applicationId: self.selectedApplication.Id, templateId: self.selectedTemplate.Id };
                applicationManagementService.deleteTemplate(payload, deleteTemplateSuccessCallback, deleteTemplateErrorCallback);

            }, function () {
                self.FileUploadVM = null;
                console.log('Modal dismissed at: ' + new Date());
            });

        }

        self.openModalForOrderSheetForm = function (uploadTemplateModal) {
            var modalInstance = uibModal.open({
                templateUrl: 'OrderSheetModalForm.html', //refers to modal content
                controller: 'orderSheetModalInstanceController as omc', //inner controller
                scope: $scope, //scope elements
                ariaLabelledBy: 'modal-title',
                ariaDescribedBy: 'modal-body',
                resolve: {
                    cubeSheets: function () {
                        return angular.copy(self.selectedTemplate.CubeSheets);
                    }
                }
                //
            });

            modalInstance.result.then(function (reOrderedSheets) {
                spinnerService.show("overlaySpinner");
                self.selectedTemplate.CubeSheets.splice(0, self.selectedTemplate.CubeSheets.length);

                self.selectedTemplate.CubeSheets = reOrderedSheets.splice(0);
                //for (var sInd = 0; sInd < reOrderedSheets.length; sInd++) {
                //    self.selectedTemplate.CubeSheets.push(reOrderedSheets[sInd]);
                //}
                spinnerService.hide("overlaySpinner");

                //var payload = { employeeId: serverVariableService.USER_EID(), applicationId: self.selectedApplication.Id, templateId: self.selectedTemplate.Id };
                //applicationManagementService.deleteTemplate(payload, $scope.deleteTemplateSuccessCallback, $scope.deleteTemplateErrorCallback);

            }, function () {
                //$scope.FileUploadVM = null;
                console.log('Modal dismissed at: ' + new Date());
            });
        }

        //self.onCancelUpload = function () {
        //    $("#fileform")[0].reset();
        //    self.fileUploadTabVM.FileForUploadInbase64 = null;
        //    self.fileUploadTabVM.FileDisplayText = null;
        //    self.fileUploadTabVM.IsFileLoading = "complete";
        //}


        function uploadTemplateSuccessCallback(response) {
            spinnerService.hide("overlaySpinner");
            self.FileUploadVM = null;
            if (response == true) {
                $scope.showAlert('success', "Template Uploaded Successfully.");
            }
            else {
                $scope.showAlert('danger', "Error uploading template.");
            }

        }

        function uploadTemplateErrorCallback (response) {
            spinnerService.hide("overlaySpinner");
            self.FileUploadVM = null;
            $scope.showAlert('danger', "Error uploading template.");
        }

        function deleteTemplateSuccessCallback (response) {

            if (response.ResponseType == 0) {
                $scope.showAlert('success', "Template Deleted Successfully.");

                //Refresh application with latest template view model
                var payload = { employeeId: serverVariableService.USER_EID(), applicationId: self.selectedApplication.Id };
                applicationManagementService.getAllTemplates(payload, getTemplatesByAppIdSuccessCallback, getTemplatesByAppIdErrorCallback);

            }
            else if (response.ResponseType == 1) {
                $scope.showAlert('danger', response.Message);
            }
            else {
                $scope.showAlert('danger', "Error uploading template.");
            }
        }

        $scope.Validate = function () {

            //Empty the  Validation Summary
            $scope.vm.popupValidationSummary = [];

            if (typeof $scope.opsViewModel.OperationType == "undefined") {
                $scope.showAlertinPopup('danger', "Please Select Operation");
                return;
            }
            if ($scope.opsViewModel.OperationType == 6) {
                if (typeof $scope.appMgmt.ranges.RANGE == "undefined") {
                    $scope.showAlertinPopup('danger', "Please enter Range ");
                    return;
                }
                if ($scope.opsRangeViewModel.ospModelRangeFrom == "" && $scope.opsRangeViewModel.ospModelRangeTo == "" && $scope.appMgmt.ranges.RANGE.length == 0) {
                    $scope.showAlertinPopup('danger', "Please enter Range ");
                    return;
                }

                var hasInvalidValueSelected = self.ErrorBases.filter(function (eBase) { return eBase.isSelected; }).length > 0;
                if ($scope.opsRangeViewModel.ospModelValidFrom == "" && $scope.opsRangeViewModel.ospModelValidTo == "" && $scope.opsRangeViewModel.ospModelInValidFrom == "" && $scope.opsRangeViewModel.ospModelInValidTo == "" && !$scope.opsRangeViewModel.isNumeric && !hasInvalidValueSelected) {
                    $scope.showAlertinPopup('danger', "Please enter Valid values or Invalid values");
                    return;
                }
            }
            $scope.opsFormPopUp.close(true);
        }

        function getTemplatesByAppIdSuccessCallback(response) {
            self.selectedApplication.CubeTemplates.splice(0, self.selectedApplication.CubeTemplates.length);
            for (var tInd = 0; tInd < response.length; tInd++) {
                self.selectedApplication.CubeTemplates.push(response[tInd]);
            }
            spinnerService.hide("overlaySpinner");
        }

        function getTemplatesByAppIdErrorCallback(response) {
            spinnerService.hide("overlaySpinner");
            $scope.showAlert('danger', "Error retreiving templates.");
        }

        function deleteTemplateErrorCallback (response) {
            spinnerService.hide("overlaySpinner");
            $scope.showAlert('danger', "Error deleting template.");
        }

        function generateDownloadTemplateURL(templateId, fileName) {
            return serverVariableService.DATASCOOP_ENDPOINT() + '/ApplicationMgrService.svc/RestService/DownloadTemplateFile' + "?templateId=" + templateId + "&fileName=" + fileName;
        }

        $scope.ManageTemplate = function () {
            $scope.vm.validationSummary = [];
            if (!self.selectedApplication) {
                $scope.showAlert('danger', "Please select at least one application.");
            }
            else {
                $scope.appMgmt.activeTab = $scope.appMgmt.templateMgmtTab;
            }
        }

        function getAllApplicationsSuccessCallBack(response) {
            spinnerService.hide("overlaySpinner");

            for (var aInd = 0; aInd < response.length; aInd++) {
                self.applicationsInfo.push(new ApplicationViewModel(response[aInd]));
            }


            //self.applicationsInfo = data.map(function (appInfo) {
            //    appInfo.LastModifiedBy = $filter('mydate')(appInfo.LastModifiedBy);
            //    return new ApplicationViewModel(appInfo)
            //});
            self.appMgmtGridOptions.data = self.applicationsInfo;
            //console.log("data: ", data, self.applicationsInfo);
        }

        function getAllApplicationsErrorCallBack(response) {
            spinnerService.hide("overlaySpinner");
            $scope.showAlert('danger', "Error retreiving applications.");
        }



        // controller initialization/start function
        var init = function () {
            spinnerService.show("overlaySpinner");
            self.toggleTemplateColumns(false);
            var payload = { employeeId: serverVariableService.USER_EID() };
            applicationManagementService.getAllApplications(payload, getAllApplicationsSuccessCallBack, getAllApplicationsErrorCallBack);
            self.activeTab = self.appMgmtTab;
            console.log("application management controller initialised.");
            applicationManagementService.getAllRepositories({}, function (data) {
                self.allRepositories = data;
                allRepositories = angular.copy(data);
            }, function () {
                // error in retrieving the repositories.
            });
            applicationManagementService.getallSheetOperations({}, function (data) {
                self.allOperations = data;
            }, function () {
                // error in retrieving the operations.
            });

            self.activeTab = self.appMgmtTab;
            console.log("application management controller initialised.");
        }

        //controller initialization starts here 
        init();

    }

    // view models
    function ApplicationViewModel(application) {
        var self = this;
        self.Id = application.Id;
        self.Name = application.Name;
        self.CurrentRunStatus = application.CurrentRunStatus;
        self.LastRunStatus = application.LastRunStatus;
        self.InputOperation = application.InputOperation;
        self.MaxConcurrentProcess = application.MaxConcurrentProcess;
        self.LastModifiedOn = application.LastModifiedOn;
        self.LastModifiedBy = application.LastModifiedBy;
        self.CubeTemplates = application.CubeTemplates;
        self.Notification = (application.Notification == null) ? new NotificationViewModel(0, null, null, 1) : new NotificationViewModel(application.Notification.Id, application.Notification.CcRecipients, application.Notification.ToRecipients, application.Notification.Type);
    }

    function TemplateViewModel(template) {
        var self = this;
        self.Id = template.Id;
        self.Name = template.Name;
        self.DownloadTemplate = template.DownloadTemplate;
        self.TemplateFileName = template.TemplateFileName;
        self.IsStandalone = template.IsStandalone;
        self.LastRunStatus = template.LastRunStatus;
        self.LastRunOn = template.LastRunOn;
        self.CurrentRunStatus = template.CurrentRunStatus;
        self.OrderNo = template.OrderNo;
        self.IsContinueOnFail = template.IsContinueOnFail;
        self.LastModifiedBy = template.LastModifiedBy;
        self.LastModifiedOn = template.LastModifiedOn;
        self.Notification = (template.Notification == null) ? new NotificationViewModel(0, null, null, 1) : new NotificationViewModel(template.Notification.Id, template.Notification.CcRecipients, template.Notification.ToRecipients, template.Notification.Type);
        self.CubeSheets = template.CubeSheets;
    }

    function SheetViewModel(sheet) {
        var self = this;
        self.Id = sheet.Id;
        self.Name = sheet.Name;
        self.OperationTypes = sheet.OperationTypes;
        self.Repos = sheet.Repos;
    }

    function FileUploadViewModel(templateId, base64EncodedFile, fileExtension, templateFileName) {
        var self = this;
        self.base64EncodedFile = base64EncodedFile;
        self.templateId = templateId;
        self.fileExtension = fileExtension;
        self.templateFileName = templateFileName;
    }


    function NotificationViewModel(id, ccRecipients, toRecipients, type) {
        var self = this;
        self.Id = id;
        self.CcRecipients = ccRecipients;
        self.ToRecipients = toRecipients;
        self.Type = type;


        self.setDisplayRecipients = function (recipientsObject) {
            var recipients = "";
            for (rInd = 0; rInd < recipientsObject.length; rInd++) {
                recipients = recipients + ";" + recipientsObject[rInd].replace("mailto:", "");
            }

            if (recipients.indexOf(';') == 0) {
                recipients = recipients.slice(1);
            }

            return recipients;
        }

        self.DisplayCcRecipients = (ccRecipients == null) ? "" : self.setDisplayRecipients(ccRecipients);
        self.DisplayToRecipients = (toRecipients == null) ? "" : self.setDisplayRecipients(toRecipients);
        self.ValidateEmail= function (email) {
            var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return re.test(email);
        }
        self.ValidateRecipientsString = function (recipientsString) {
            if (recipientsString != null & recipientsString != undefined) {
                var recipientArray = recipientsString.split(";");
                if (recipientArray.length > 0) {
                    for (var rInd = 0; rInd < recipientArray.length; rInd++) {
                        if (recipientArray[rInd].trim() != '' && self.ValidateEmail(recipientArray[rInd].trim()) == false) {
                            return false;
                        }
                    }

                }
            }
            return true;
        }
        self.RecipientStringToObject = function (recipientsString) {
            var recipientObject = [];
            if (recipientsString != null & recipientsString != undefined) {
                var recipientArray = recipientsString.split(";");
                if (recipientArray.length > 0) {
                    for (var rInd = 0; rInd < recipientArray.length; rInd++) {
                        if (recipientArray[rInd].trim() != '') {
                            recipientObject.push('mailto:' + recipientArray[rInd].trim());
                        }

                    }
                }
            }
            return recipientObject;
        }


    }


}());