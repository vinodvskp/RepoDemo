﻿var app = angular.module('vmApp');
app.filter("mydate", function () {
    return function (x) {
        if(x != null)
        {
            try{
            console.log(x);
            var s = x.substr(0, x.length - 2)
            var substringedDate = s.substring(6);
            var parsedIntDate = parseInt(substringedDate);
            return new Date(parsedIntDate);
            }
            catch(error){
                return x;
            }
        }
        else {
            return "-";
        }

        //return new Date(parseInt(x.substr(6)));
    };
});