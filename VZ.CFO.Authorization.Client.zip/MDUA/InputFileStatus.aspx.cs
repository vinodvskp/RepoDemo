﻿using System;
using System.Collections;
using System.Drawing;
using System.Web.UI.WebControls;
//using MDUA.ClassLibrary;
using MDUA.DTO;
using MDUA.DataAccess;
using MDUA.BusinessLogic;
using System.Collections.Generic;

public partial class InputFileStatus : System.Web.UI.Page
{

    public class SortBySource : IComparer<JobStatusDTO>
    {
        private bool _sortDesc = false;

        public SortBySource(bool SortDesc)
        {
            _sortDesc = SortDesc;
        }

        #region IComparer<JobStatusDTO> Members

        public int Compare(JobStatusDTO x, JobStatusDTO y) {
            return _sortDesc ? String.Compare(y.Source, x.Source) : String.Compare(x.Source, y.Source);            
        }

        #endregion
    }

    public class SortByDescription : IComparer<JobStatusDTO>
    {
        private bool _sortDesc = false;

        public SortByDescription(bool SortDesc)
        {
            _sortDesc = SortDesc;
        }
        
        #region IComparer<JobStatusDTO> Members

        public int Compare(JobStatusDTO x, JobStatusDTO y) {
            return _sortDesc ? String.Compare(y.Description, x.Description) : String.Compare(x.Description, y.Description);            
        }

        #endregion
    }

    public class SortByCreateDate : IComparer<JobStatusDTO>
    {
        private bool _sortDesc = false;

        public SortByCreateDate(bool SortDesc)
        {
            _sortDesc = SortDesc;
        }
        
        #region IComparer<JobStatusDTO> Members

        public int Compare(JobStatusDTO x, JobStatusDTO y) {
            return _sortDesc ? y.dtCreate.CompareTo(x.dtCreate) : x.dtCreate.CompareTo(y.dtCreate);            
        }

        #endregion
    }

    public class SortByLoadBy : IComparer<JobStatusDTO>
    {
        private bool _sortDesc = false;

        public SortByLoadBy(bool SortDesc)
        {
            _sortDesc = SortDesc;
        }
        
        public int Compare(JobStatusDTO x, JobStatusDTO y) {
            return _sortDesc ? y.ScheduledLoadInt.CompareTo(x.ScheduledLoadInt) : x.ScheduledLoadInt.CompareTo(y.ScheduledLoadInt);
        }
    }

    public class SortByOwner : IComparer<JobStatusDTO> {
        private bool _sortDesc = false;

        public SortByOwner(bool SortDesc)
        {
            _sortDesc = SortDesc;
        }
        
        public int Compare(JobStatusDTO x, JobStatusDTO y) {
            return _sortDesc ? y.Owner.CompareTo(x.Owner) : x.Owner.CompareTo(y.Owner);
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            Master.PageTitle = "Input File Status";

            //  If this is an Anonymous User, don't show them the navigation bar.
            //if (Master.curUser.Role == UserRole.AnonymousUser)
               // this.globalnav = false;

            if (!IsPostBack) {
                WebSettings Settings = Utils.LoadWebSetting(Master.curUser.EmployeeID);
                // jevans 5/23/2012 - if web settings is null, database is not available.
                if (Settings == null) {
                    Master.Message = "MDUA could not load web settings from the database, and cannot continue.  <P>" + HypMDUA.ERROR_MESSAGE;
                    return;
                } 
                //  Add fiscal periods for current year going back 10 years
                for (int i = DateTime.Now.Year; i > DateTime.Now.Year - 10; i--) {
                    for (int j = 12; j >= 0; j--) {
                        ddlPeriods.Items.Add(i.ToString() + j.ToString().PadLeft(2, '0'));
                    }
                }

                if (ddlPeriods.Items.FindByValue(Settings.CurrentPeriod) == null) {
                    ddlPeriods.Items.Insert(0, Settings.CurrentPeriod);
                }
                ddlPeriods.SelectedValue = Settings.CurrentPeriod;

                foreach (ListItem item in ddlPeriods.Items) {
                    Settings.CurrentPeriod = item.Value;
                    item.Text = Settings.CurrentMonthString + " " + Settings.CurrentYear;
                    item.Value = Settings.CurrentPeriod;
                }
                
                List<JobStatusDTO> jobList = Utils.RetrieveJobStatus(ddlPeriods.SelectedValue);
                if (jobList != null) {
                    FillTable(new SortBySource(false));
                    Session["LastSort"] = "SortBySource";
                } else {
                    Master.Message = HypMDUA.ERROR_MESSAGE;
                }
                // save in session for future use 
                Session.Add("StatusInputFileInfo", jobList);
                FillTable(new SortBySource(false));
                Session["LastSort"] = "SortBySource";
            }
        }
        catch (Exception ex)
        {
            Master.Message = HypMDUA.ERROR_MESSAGE;
            GeneralDatabaseAccess.LogEvent(Master.curUser.EmployeeID, "InputFileStatus.aspx", "Page_Load", ex, UserToolLogLevel.Error);
        }
    }

    private void FillTable(IComparer<JobStatusDTO> comparer)
    {
        try
        {
            List<JobStatusDTO> jobList = (List<JobStatusDTO>)Session["StatusInputFileInfo"];
            if (jobList == null)
                return;

            jobList.Sort(comparer);

            //Color AltBgnd = Color.FromArgb(231, 242, 254); //#E7F2FE
            //Color RegBgnd = Color.White;
            int MainRowCnt = 0;

            while (tblStatus.Rows.Count > 1)
                tblStatus.Rows.RemoveAt(1);

            foreach (JobStatusDTO si in jobList.ToArray()) {
                ++MainRowCnt;

                //  Create a row for the budget group.
                TableRow tr = new TableRow();
                //BS
                //tr.HorizontalAlign = HorizontalAlign.Left;
                //tr.BackColor = (((MainRowCnt & 1) == 1) ? RegBgnd : AltBgnd);
                tblStatus.Rows.Add(tr);

                //BS
                if (si.dtCreate == DateTime.MinValue) //  || si.Status == "Error")
                    tr.ForeColor = Color.Red;
                //else
                //    tr.ForeColor = Color.Black;

                TableCell tc;

                //  Add Source.
                tc = new TableCell();
                tc.Text = si.Source;
                tr.Cells.Add(tc);

                //  Description
                tc = new TableCell();
                tc.Text = si.Description;
                tr.Cells.Add(tc);
   
              
                //  User.
                tc = new TableCell();
                tc.Text = si.Owner;
                tr.Cells.Add(tc);

                tc = new TableCell();
                tc.Text = si.ScheduledLoad;
                tr.Cells.Add(tc);

                tc = new TableCell();
                if (si.dtCreate != DateTime.MinValue)
                    tc.Text = si.dtCreate.ToString(); //"MM/dd/yyyy  hh:mm");
                tr.Cells.Add(tc);
            }
        }
        catch (Exception ex)
        {
            Master.Message = HypMDUA.ERROR_MESSAGE;
            GeneralDatabaseAccess.LogEvent(Master.curUser.EmployeeID, "InputFileStatus.aspx", "Page_Load", ex, UserToolLogLevel.Error);
        }
    }

  
    protected void btnSortSource_Click(object sender, EventArgs e)
    {

        FillTable(new SortBySource(Session["LastSort"].ToString() == "SortBySource"));
        Session["LastSort"] = ((Session["LastSort"].ToString() == "SortBySource") ? "" : "SortBySource");
    }
    protected void btnSortDescription_Click(object sender, EventArgs e)
    {
        FillTable(new SortByDescription(Session["LastSort"].ToString() == "SortByDescription"));
        Session["LastSort"] = ((Session["LastSort"].ToString() == "SortByDescription") ? "" : "SortByDescription");
    }
    protected void btnSortLoadedBy_Click(object sender, EventArgs e)
    {
        FillTable(new SortByOwner((Session["LastSort"].ToString() == "SortByOwner")));
        Session["LastSort"] = ((Session["LastSort"].ToString() == "SortByOwner") ? "" : "SortByOwner");
    }
    
    protected void btnSortSchLoadDate_Click(object sender, EventArgs e)
    {
        FillTable(new SortByLoadBy((Session["LastSort"].ToString() == "SortByLoadBy")));
        Session["LastSort"] = ((Session["LastSort"].ToString() == "SortByLoadBy") ? "" : "SortByLoadBy");
    }
    protected void btnSortLastLoaded_Click(object sender, EventArgs e)
    {
        FillTable(new SortByCreateDate((Session["LastSort"].ToString() == "SortByCreateDate")));
        Session["LastSort"] = ((Session["LastSort"].ToString() == "SortByCreateDate") ? "" : "SortByCreateDate");
    }
    protected void ddlPeriods_SelectedIndexChanged(object sender, EventArgs e)
    {
        ReturnCodeDTO rc = new ReturnCodeDTO();
        Session.Remove("StatusInputFileInfo");
        List<JobStatusDTO> jobList = Utils.RetrieveJobStatus(ddlPeriods.SelectedValue);
        if (jobList != null) {
            Session.Add("StatusInputFileInfo", jobList);
            FillTable(new SortBySource(false));
            Session["LastSort"] = "SortBySource";
        } else {
            Master.Message = HypMDUA.ERROR_MESSAGE;
        }
    }
}