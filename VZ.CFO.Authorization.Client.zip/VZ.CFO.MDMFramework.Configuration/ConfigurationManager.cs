﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Configuration
{
    public abstract class ConfigurationManager : ConfigurationDataProvider
    {
        /// <summary>
        /// Constructor accepts config to set the dbcontext
        /// </summary>
        /// <param name="config"></param>
        protected ConfigurationManager(ConfigurationDataProvider config)
        {
            if (null == config)
            {
                throw new ArgumentNullException("config");
            }
            this.Config = config;
        }

        private ConfigurationDataProvider Config { get; set; }



        protected override string OnGetPortalConnectionString()
        {
            return this.Config.PortalConnectionString;
        }

        protected override Contracts.Data.Config.DbProfile[] OnGetDbProfiles()
        {
            return this.Config.GetDbProfiles();
        }

        protected override Contracts.Data.Config.FTProfile[] OnGetFTProfiles()
        {
            return this.Config.GetFTProfiles();
        }

        protected override Contracts.Data.Config.HomeMenuItem[] OnGetHomeMenuItems()
        {
            return this.Config.GetHomeMenuItems();
        }

        protected override Contracts.Data.Config.MessageDictionary[] OnGetMessageDictionary()
        {
            return this.Config.GetMessageDictionary();
        }

        protected override Contracts.Data.Config.MenuConfig OnGetMenuConfig()
        {
            return this.Config.GetMenuConfig();
        }
        protected override Contracts.Data.Config.ESPJobConfig OnGetESPJobConfig()
        {
            return this.Config.GetESPJobConfig();
        }

        protected override string OnGetEncryptionSalt()
        {
            return this.Config.EncryptionSalt;
        }

        protected override string OnPushNotificationDbConnectionString()
        {
            return this.Config.PushNotificationDbConnectionString;
        }

        protected override string OnPortalSchemaPrefix()
        {
            return this.Config.PortalSchemaPrefix;
        }

        protected override bool OnCanAllowMigration()
        {
            return this.Config.CanAllowMigration;
        }

        protected override string OnGetLogLocation()
        {
            return this.Config.GetLogLocation;
        }

        protected override string OnGetFactFileArchiveLocation()
        {
            return this.Config.GetFactFileArchiveLocation;
        }

        protected override string OnGetLdapConnection()
        {
            return this.Config.LdapConnection;
        }

        protected override string OnGetLdapEncryptedPassword()
        {
            return this.Config.LdapEncryptedPassword;
        }

        protected override string OnGetLdapUserName()
        {
            return this.Config.LdapUserName;
        }

        protected override double OnMaxUploadSizeInMB()
        {
            return this.Config.MaxUploadSizeInMB;
        }

        protected override string OnAllowedFileTypes()
        {
            return this.Config.AllowedFileTypes;
        }

        protected override string OnLdapGroupName()
        {
            return this.Config.LdapGroupName;
        }
    }
}
