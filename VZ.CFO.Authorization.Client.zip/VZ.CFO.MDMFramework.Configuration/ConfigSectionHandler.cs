﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Common;

namespace VZ.CFO.MDMFramework.Configuration
{
    public class ConfigSectionHandler : IConfigurationSectionHandler
    {
        private string configSectionName = string.Empty;
        
        public ConfigSectionHandler() { }
        
        public ConfigSectionHandler(string sectionName)
        {
            configSectionName = sectionName;
        }

        public object Create(object parent, object configContext, System.Xml.XmlNode section)
        {

            //Contracts.Data.Config.MenuConfig menuConfig = new Contracts.Data.Config.MenuConfig();

            ////Home Menu
            //Contracts.Data.MDUA.Menu homeMenu = new Contracts.Data.MDUA.Menu() 
            //{ 
            //    Id = "home", IsClickable = true, IsEnabled = true, Name = "Home",
            //    RequiredClaims = new Contracts.Data.Security.Claim[] { new Contracts.Data.Security.Claim("MDMFramework.UserRole.0", "READONLY"), new Contracts.Data.Security.Claim("MDMFramework.UserRole.0", "USER"), new Contracts.Data.Security.Claim("MDMFramework.UserRole.0", "ADMINISTRATOR") }
            //};
            
            ////Self Serve
            //Contracts.Data.MDUA.Menu selfServeMenu = new Contracts.Data.MDUA.Menu() 
            //{ 
            //    Id = "selfServe", 
            //    IsClickable = false, 
            //    IsEnabled = true, 
            //    Name = "Self Serve",
            //    SubMenus = new Contracts.Data.MDUA.Menu[]
            //    {
            //        new Contracts.Data.MDUA.Menu() 
            //        { 
            //            Id = "versionManagement", IsClickable = true, IsEnabled = true, Name = "Version Management",
            //            RequiredClaims = new Contracts.Data.Security.Claim[] { new Contracts.Data.Security.Claim("MDMFramework.VM.0", "READ"), new Contracts.Data.Security.Claim("MDMFramework.VM.0", "EDIT"), new Contracts.Data.Security.Claim("MDMFramework.VM.0", "TRACKING") },
            //            SubMenus = new Contracts.Data.MDUA.Menu[]
            //            {
            //                new Contracts.Data.MDUA.Menu() 
            //                { 
            //                    Id = "createRequest", IsClickable = true, IsEnabled = true, Name = "Create Request",
            //                    RequiredClaims = new Contracts.Data.Security.Claim[] { new Contracts.Data.Security.Claim("MDMFramework.VM.0", "EDIT") }
            //                },
            //                new Contracts.Data.MDUA.Menu() 
            //                { 
            //                    Id = "requestTracking", IsClickable = true, IsEnabled = true, Name = "Request Tracking",
            //                    RequiredClaims = new Contracts.Data.Security.Claim[] { new Contracts.Data.Security.Claim("MDMFramework.VM.0", "TRACKING") }
            //                }
            //            }
            //        },
            //        new Contracts.Data.MDUA.Menu() 
            //        { 
            //            Id = "mappingTable", IsClickable = false, IsEnabled = true, Name = "Mapping Table",
            //            RequiredClaims = new Contracts.Data.Security.Claim[] { new Contracts.Data.Security.Claim("MDMFramework.MT.0", "READ"), new Contracts.Data.Security.Claim("MDMFramework.MT.0", "EDIT"), new Contracts.Data.Security.Claim("MDMFramework.MT.0", "MIGRATE") },
            //            SubMenus = new Contracts.Data.MDUA.Menu[]
            //            {
            //                new Contracts.Data.MDUA.Menu() 
            //                { 
            //                    Id = "manage", IsClickable = true, IsEnabled = true, Name = "Manage",
            //                    RequiredClaims = new Contracts.Data.Security.Claim[] { new Contracts.Data.Security.Claim("MDMFramework.MT.0", "READ"), new Contracts.Data.Security.Claim("MDMFramework.MT.0", "EDIT"), new Contracts.Data.Security.Claim("MDMFramework.MT.0", "MIGRATE") }
            //                },
            //                new Contracts.Data.MDUA.Menu() 
            //                { 
            //                    Id = "audit", IsClickable = true, IsEnabled = true, Name = "Audit",
            //                    RequiredClaims = new Contracts.Data.Security.Claim[] { new Contracts.Data.Security.Claim("MDMFramework.MT.0", "READ"), new Contracts.Data.Security.Claim("MDMFramework.MT.0", "EDIT"), new Contracts.Data.Security.Claim("MDMFramework.MT.0", "MIGRATE") }
            //                }
            //            }
            //        }
            //    }
            //};
            ////Jobs
            //Contracts.Data.MDUA.Menu jobsMenu = new Contracts.Data.MDUA.Menu()
            //{
            //    Id = "jobs",
            //    IsClickable = false,
            //    IsEnabled = true,
            //    Name = "Jobs",
            //    SubMenus = new Contracts.Data.MDUA.Menu[]
            //    {
            //        new Contracts.Data.MDUA.Menu() 
            //        { 
            //            Id = "onDemandJobs", IsClickable = true, IsEnabled = true, Name = "On Demand Jobs",
            //            RequiredClaims = new Contracts.Data.Security.Claim[] { new Contracts.Data.Security.Claim("MDMFramework.ODJ.0", "TRIGGER")}
            //        }
            //    }
            //};
            ////Admin
            //Contracts.Data.MDUA.Menu adminMenu = new Contracts.Data.MDUA.Menu()
            //{
            //    Id = "adminFunctions",
            //    IsClickable = false,
            //    IsEnabled = true,
            //    Name = "Admin Functions",
            //    SubMenus = new Contracts.Data.MDUA.Menu[]
            //    {
            //        new Contracts.Data.MDUA.Menu() 
            //        { 
            //            Id = "userProfile", IsClickable = true, IsEnabled = true, Name = "User Profile",
            //            RequiredClaims = new Contracts.Data.Security.Claim[] { new Contracts.Data.Security.Claim("MDMFramework.UserRole.0", "ADMINISTRATOR")}
            //        }
            //    }
            //};

            //menuConfig.AvailableMenus = new Contracts.Data.MDUA.Menu[] { homeMenu, selfServeMenu, jobsMenu, adminMenu };
            //Contracts.Data.Config.MDMFrameworkConfig tc = new Contracts.Data.Config.MDMFrameworkConfig();
            //tc.MenuConfiguration = menuConfig;

            //string s = Utility.SerializeObject(tc);

            //List<Contracts.Data.Config.MessageDictionary> md = new List<Contracts.Data.Config.MessageDictionary>();
            //md.Add(new Contracts.Data.Config.MessageDictionary() { MessageCode = 123, Message = "msg1" });
            //md.Add(new Contracts.Data.Config.MessageDictionary() { MessageCode = 1235, Message = "msg2" });
            //Contracts.Data.Config.MDMFrameworkConfig mc = new Contracts.Data.Config.MDMFrameworkConfig();
            //mc.MessageConfig = md.ToArray();
            //string s = Utility.SerializeObject(mc);

            Contracts.Data.Config.MDMFrameworkConfig retConf = null;
            string szConfig = section.OuterXml;
            retConf = (Contracts.Data.Config.MDMFrameworkConfig)Utility.DeserializeObject<Contracts.Data.Config.MDMFrameworkConfig>(szConfig);
            return retConf;
        }
    }
}
