﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Providers.Manager;
using VZ.CFO.MDMFramework.Providers.Manager.MDUA;
using VZ.CFO.MDMFramework.Server.Providers;
using VZ.CFO.MDMFramework.Providers.Manager.PushNotification;
using VZ.CFO.MDMFramework.Providers.Data;
using VZ.CFO.MDMFramework.Providers.Manager.Reporting;
namespace VZ.CFO.MDMFramework.Configuration
{
    public class ServerConfigurationManager : ConfigurationManager
    {

        private Contracts.Service.PushNotification.IPushNotificationService pushNotificationManagerInstance = null;

        /// <summary>
        /// Constructor which accepts the Config parameter to set the DBContext
        /// </summary>
        /// <param name="config"></param>
        public ServerConfigurationManager(ConfigurationDataProvider config)
            : base(config)
        {
            
        }

        protected override VZ.CFO.MDMFramework.Providers.Data.IMappingTableDBManager OnGetMappingTableDataProvider()
        {
            return new DbMappingTableDataProvider(OnGetPortalConnectionString(), OnGetEncryptionSalt(), OnGetDbProfiles(), OnPortalSchemaPrefix());            
        }

        protected override Contracts.Service.MappingTableMgmt.IMappingTableManager OnGetMappingTableManager()
        {
            return new MappingTableManager(GetMappingTableDataProvider(), OnCanAllowMigration(), GetOpsStatusLogManagerDataProvider(), GetODJobManager(), OnGetMessageDictionary());
        }

        protected override Contracts.Service.MDUA.IUserAccessManager OnGetUserAccessManager()
        {
            return new UserAccessManager(GetUserAccessDataProvider(), GetMenuConfig(), GetOpsStatusLogManagerDataProvider());
        }

        protected override Contracts.Service.MDUA.IUserAccessManager OnGetUserAccessDataProvider()
        {
            return new DbUserAccessDataProvider(OnGetPortalConnectionString(), OnGetEncryptionSalt(), OnGetLdapConnection(), OnGetLdapUserName(), OnGetLdapEncryptedPassword(), OnGetOpsStatusLogManagerDataProvider(), OnLdapGroupName());
        }

        protected override Contracts.Service.PushNotification.IPushNotificationService OnGetPushNotificationDataProvider()
        {
            return new DbPushNotificationDataProvider(OnPushNotificationDbConnectionString(), OnGetEncryptionSalt(), new Contracts.Data.PushNotification.PushNotificationCallback());
        }

        protected override Contracts.Service.PushNotification.IPushNotificationService OnGetPushNotificationManager()
        {
            return new PushNotificationManager(OnGetPushNotificationDataProvider());
        }

        protected override Contracts.Service.PushNotification.IPushNotificationService OnGetPushNotificationManagerInstance()
        {
            if (pushNotificationManagerInstance == null)
            {
                pushNotificationManagerInstance = OnGetPushNotificationManager();
            }

            return pushNotificationManagerInstance;
        }

        protected override Contracts.Service.MDUA.IODJobManager OnGetODJobManager()
        {
            return new ODJobsManager(OnGetODJobManagerDataProvider(), OnGetESPJobConfig(), OnGetOpsStatusLogManagerDataProvider());
        }

        protected override Contracts.Service.MDUA.IODJobManager OnGetODJobManagerDataProvider()
        {
            return new DbODJobsManagerDataProvider(OnGetPortalConnectionString(), OnGetEncryptionSalt(), OnGetESPJobConfig(), OnGetOpsStatusLogManagerDataProvider());
            
        }

        protected override Providers.Data.IOpsStatusLogManager OnGetOpsStatusLogManagerDataProvider()
        {
            return new DbOpsStatusLogManagerDataProvider(OnGetPortalConnectionString(), OnGetEncryptionSalt());
        }

        protected override Contracts.Service.ILogManager OnGetLogDataProvider()
        {
            return new TextFileLogProvider(OnGetLogLocation());
        }

        protected override Contracts.Service.ILogManager OnGetLogManager()
        {
            return new LogManager(OnGetLogDataProvider());
        }

        protected override Contracts.Service.ISecurityManager OnGetSecurityManager()
        {
            return new SecurityManager(OnGetEncryptionSalt());
        }

        protected override IFactTableManagerDataProvider OnGetFactTableManagerDataProvider()
        {
            return new DbFactTableManagerDataProvider(OnGetPortalConnectionString(), OnGetDbProfiles(), OnGetEncryptionSalt(), OnGetOpsStatusLogManagerDataProvider());
        }
        protected override Contracts.Service.MDUA.IFactTableManager OnGetFactTableManager()
        {
            return new FactTableManager(OnGetFactTableManagerDataProvider());
        }

        protected override IFactTableUserUploadDataProvider OnGetFactTableUserUploadManagerDataProvider()
        {
            return new DbFactTableUserUploadManagerDataProvider(OnGetPortalConnectionString(), OnGetEncryptionSalt(), OnGetDbProfiles(), OnGetFactTableManager(), OnGetOpsStatusLogManagerDataProvider());
        }

        protected override Contracts.Service.MDUA.IFactTableUserUpload OnGetFactTableUserUploadManager()
        {
            return new FactTableUserUploadManager(OnGetFactTableManager(), OnGetSecurityManager(), OnGetOpsStatusLogManagerDataProvider(), OnGetFactTableUserUploadManagerDataProvider(), OnGetUserAccessManager(), OnGetFactFileArchiveLocation(), OnMaxUploadSizeInMB());
        }

        protected override Contracts.Service.IExportTableManager OnGetExportTableManagerDataProvider()
        {
            return new DbExportTableManagerDataProvider(OnGetPortalConnectionString(), OnGetEncryptionSalt(), OnGetSecurityManager());
        }

        protected override Contracts.Service.IExportTableManager OnGetExportTableManager()
        {
            return new ExportTableManager(OnGetExportTableManagerDataProvider());
        }

        protected override Contracts.Service.MDUA.IFileTransferManager OnGetFileTransferDataProvider()
        {
            return new DbFileTransferManagerDataProvider(OnGetPortalConnectionString(), OnGetEncryptionSalt());
        }

        protected override Contracts.Service.MDUA.IFileTransferManager OnGetFileTransferManager()
        {
            return new FileTransferManager(OnGetFileTransferDataProvider(), OnGetFTProfiles(), OnGetFactFileArchiveLocation(), OnGetOpsStatusLogManagerDataProvider(), OnAllowedFileTypes());
        }

        protected override IReportingDataProvider OnGetReportingDataProvider()
        {
            return new OracleDbReportingDataProvider(OnGetPortalConnectionString(), OnGetEncryptionSalt(), OnGetDbProfiles());
        }

        protected override Contracts.Service.Reporting.IReportingManager OnGetReportingManager()
        {
            return new ReportingManager(OnGetReportingDataProvider());
        }
    }   
}
