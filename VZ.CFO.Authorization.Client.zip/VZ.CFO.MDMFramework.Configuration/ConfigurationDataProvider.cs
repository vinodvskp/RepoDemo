﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Service;
using VZ.CFO.MDMFramework.Providers;
using VZ.CFO.MDMFramework.Providers.Data;

namespace VZ.CFO.MDMFramework.Configuration
{
    public abstract class ConfigurationDataProvider : DataProvider
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        protected ConfigurationDataProvider() 
            : base(null, null)
        {
        }

        #region configitems
        public string PortalConnectionString { get { return OnGetPortalConnectionString(); } }
        protected abstract string OnGetPortalConnectionString();

        public Contracts.Data.Config.DbProfile[] GetDbProfiles()
        {
            return OnGetDbProfiles();
        }
        protected abstract Contracts.Data.Config.DbProfile[] OnGetDbProfiles();

        public Contracts.Data.Config.FTProfile[] GetFTProfiles()
        {
            return OnGetFTProfiles();
        }
        protected abstract Contracts.Data.Config.FTProfile[] OnGetFTProfiles();

        public Contracts.Data.Config.HomeMenuItem[] GetHomeMenuItems()
        {
            return OnGetHomeMenuItems();
        }
        protected abstract Contracts.Data.Config.HomeMenuItem[] OnGetHomeMenuItems();

        public Contracts.Data.Config.MenuConfig GetMenuConfig()
        {
            return OnGetMenuConfig();
        }
        protected abstract Contracts.Data.Config.MenuConfig OnGetMenuConfig();

        public string EncryptionSalt { get { return OnGetEncryptionSalt(); } }
        protected abstract string OnGetEncryptionSalt();

        public string PushNotificationDbConnectionString { get { return OnPushNotificationDbConnectionString(); } }
        protected abstract string OnPushNotificationDbConnectionString();

        public string PortalSchemaPrefix { get { return OnPortalSchemaPrefix(); } }
        protected abstract string OnPortalSchemaPrefix();

        public bool CanAllowMigration { get { return OnCanAllowMigration(); } }
        protected abstract bool OnCanAllowMigration();
        protected abstract Contracts.Data.Config.ESPJobConfig OnGetESPJobConfig();

        public Contracts.Data.Config.ESPJobConfig GetESPJobConfig()
        {
            return OnGetESPJobConfig();
        }
        public string GetLogLocation { get { return OnGetLogLocation(); } }
        protected abstract string OnGetLogLocation();

        public Contracts.Data.Config.MessageDictionary[] GetMessageDictionary()
        {
            return OnGetMessageDictionary();
        }
        protected abstract Contracts.Data.Config.MessageDictionary[] OnGetMessageDictionary();

        public string GetFactFileArchiveLocation { get { return OnGetFactFileArchiveLocation(); } }
        protected abstract string OnGetFactFileArchiveLocation();

        public string LdapConnection { get { return OnGetLdapConnection(); } }
        protected abstract string OnGetLdapConnection();

        public string LdapUserName { get { return OnGetLdapUserName(); } }
        protected abstract string OnGetLdapUserName();

        public string LdapEncryptedPassword { get { return OnGetLdapEncryptedPassword(); } }
        protected abstract string OnGetLdapEncryptedPassword();

        public double MaxUploadSizeInMB { get { return OnMaxUploadSizeInMB(); } }
        protected abstract double OnMaxUploadSizeInMB();

        public string AllowedFileTypes { get { return OnAllowedFileTypes(); } }
        protected abstract string OnAllowedFileTypes();

        public string LdapGroupName { get { return OnLdapGroupName(); } }
        protected abstract string OnLdapGroupName();

        #endregion
        #region managers

        public VZ.CFO.MDMFramework.Providers.Data.IMappingTableDBManager GetMappingTableDataProvider()
        {
            return OnGetMappingTableDataProvider();
        }
        protected abstract VZ.CFO.MDMFramework.Providers.Data.IMappingTableDBManager OnGetMappingTableDataProvider();
        
        public Contracts.Service.MappingTableMgmt.IMappingTableManager GetMappingTableManager() 
        {
            return OnGetMappingTableManager();
        }
        protected abstract Contracts.Service.MappingTableMgmt.IMappingTableManager OnGetMappingTableManager();

        public Contracts.Service.MDUA.IUserAccessManager GetUserAccessManager()
        {
            return OnGetUserAccessManager();
        }
        protected abstract Contracts.Service.MDUA.IUserAccessManager OnGetUserAccessManager();

        public Contracts.Service.MDUA.IUserAccessManager GetUserAccessDataProvider()
        {
            return OnGetUserAccessDataProvider();
        }
        protected abstract Contracts.Service.MDUA.IUserAccessManager OnGetUserAccessDataProvider();

        public Contracts.Service.PushNotification.IPushNotificationService GetPushNotificationManager()
        {
            return OnGetPushNotificationManager();
        }
        protected abstract Contracts.Service.PushNotification.IPushNotificationService OnGetPushNotificationManager();

        public Contracts.Service.PushNotification.IPushNotificationService GetPushNotificationDataProvider()
        {
            return OnGetPushNotificationDataProvider();
        }
        protected abstract Contracts.Service.PushNotification.IPushNotificationService OnGetPushNotificationDataProvider();

        public Contracts.Service.PushNotification.IPushNotificationService GetPushNotificationManagerInstance()
        {
            return OnGetPushNotificationManagerInstance();
        }
        protected abstract Contracts.Service.PushNotification.IPushNotificationService OnGetPushNotificationManagerInstance();

        public Contracts.Service.MDUA.IODJobManager GetODJobManager()
        {
            return OnGetODJobManager();
        }
        protected abstract Contracts.Service.MDUA.IODJobManager OnGetODJobManager();

        public Contracts.Service.MDUA.IODJobManager GetODJobManagerDataProvider()
        {
            return OnGetODJobManagerDataProvider();
        }
        protected abstract Contracts.Service.MDUA.IODJobManager OnGetODJobManagerDataProvider();

        public Providers.Data.IOpsStatusLogManager GetOpsStatusLogManagerDataProvider()
        {
            return OnGetOpsStatusLogManagerDataProvider();
        }
        protected abstract Providers.Data.IOpsStatusLogManager OnGetOpsStatusLogManagerDataProvider();

        public ILogManager GetLogManager()
        {
            return OnGetLogManager();
        }
        protected abstract ILogManager OnGetLogManager();

        public ILogManager GetLogDataProvider()
        {
            return OnGetLogDataProvider();
        }

        protected abstract ILogManager OnGetLogDataProvider();

        public ISecurityManager GetSecurityManager()
        {
            return OnGetSecurityManager();
        }
        protected abstract ISecurityManager OnGetSecurityManager();

        public Contracts.Service.MDUA.IFactTableManager GetFactTableManagerDataProvider()
        {
            return OnGetFactTableManagerDataProvider();
        }
        public Contracts.Service.IExportTableManager GetExportTableManagerDataProvider()
        {
            return OnGetExportTableManagerDataProvider();
        }
        protected abstract IFactTableManagerDataProvider OnGetFactTableManagerDataProvider();
        protected abstract Contracts.Service.IExportTableManager OnGetExportTableManagerDataProvider();

        public Contracts.Service.MDUA.IFactTableManager GetFactTableManager()
        {
            return OnGetFactTableManager();
        }
        protected abstract Contracts.Service.MDUA.IFactTableManager OnGetFactTableManager();
        protected abstract Contracts.Service.IExportTableManager OnGetExportTableManager();
        public Contracts.Service.IExportTableManager GetExportTableManager()
        {
            return OnGetExportTableManager();
        }

        public IFactTableUserUploadDataProvider GetFactTableUserUploadManagerDataProvider()
        {
            return OnGetFactTableUserUploadManagerDataProvider();
        }
        protected abstract IFactTableUserUploadDataProvider OnGetFactTableUserUploadManagerDataProvider();

        public Contracts.Service.MDUA.IFactTableUserUpload GetFactTableUserUploadManager()
        {
            return OnGetFactTableUserUploadManager();
        }
        protected abstract Contracts.Service.MDUA.IFactTableUserUpload OnGetFactTableUserUploadManager();

        public Contracts.Service.MDUA.IFileTransferManager GetFileTransferDataProvider()
        {
            return OnGetFileTransferDataProvider();
        }
        protected abstract Contracts.Service.MDUA.IFileTransferManager OnGetFileTransferDataProvider();

        public Contracts.Service.MDUA.IFileTransferManager GetFileTransferManager()
        {
            return OnGetFileTransferManager();
        }
        protected abstract Contracts.Service.MDUA.IFileTransferManager OnGetFileTransferManager();

        public Contracts.Service.Reporting.IReportingManager GetReportingManager()
        {
            return OnGetReportingManager();
        }
        protected abstract Contracts.Service.Reporting.IReportingManager OnGetReportingManager();

        public IReportingDataProvider GetReportingDataProvider()
        {
            return OnGetReportingDataProvider();
        }
        protected abstract IReportingDataProvider OnGetReportingDataProvider();
             
        #endregion
    }
}
