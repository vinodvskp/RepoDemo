﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Providers.Data;
using VZ.CFO.MDMFramework.Providers.Manager;
using VZ.CFO.MDMFramework.Server.Providers;

namespace VZ.CFO.MDMFramework.Configuration
{
    public class FileBasedConfigDataProvider : ConfigurationDataProvider
    {

        private const string ConfigKeyPortalDb = "MDMFramework.PortalDb.ConnectionString";
        private const string ConfigKeyMDMConf = "MDMFramework.Config";
        private const string ConfigKeyEncryptionSalt = "EncryptionSalt";
        private const string ConfigKeyPushNotificationDbConnStr = "MDMFramework.PushNotification.ConnectionString";
        private const string ConfigKeyPortalSchemaPrefix = "MDMFramework.PortalSchemaPrefix";
        private const string ConfigKeyCanAllowMigration = "MDMFramework.MappingTable.AllowMigration";
        private const string ConfigKeyEspRestApiUrl = "EspRestApiUrl";
        private const string ConfigKeyEspPrefix = "EspPrefix";
        private const string ConfigKeyEspUserName = "EspUserName";
        private const string ConfigKeyEspPwd = "EspPassword";
        private const string ConfigKeyRestSvcRequestOffsetTime = "RestSvcRequestOffsetTime";
        private const string ConfigKeyEspTimezone = "EspTimezone";
        private const string ConfigKeyLogLocation = "MDMFramework.LogLocation";
        private const string ConfigKeyFactFileArchiveLocation = "MDMFramework.FactTable.FileArchiveDir";
        private const string ConfigKeyLdapConnection = "MDMFramework.LDAP.Connection";
        private const string ConfigKeyLdapUserName = "MDMFramework.LDAP.UserName";
        private const string ConfigKeyLdapEncryptedPassword = "MDMFramework.LDAP.EncryptedPassword";
        private const string ConfigKeyMaxUploadSizeInMB = "MDMFramework.FactTable.MaxUploadSizeInMB";
        private const string ConfigKeyAllowedFileTypes = "MDMFramework.FileTransfer.AllowedFileTypes";
        private const string ConfigKeyLdapGroupName = "MDMFramework.LDAP.GroupName";
        
        protected override string OnGetPortalConnectionString()
        {
            return GetConnectionString(GetAppSettingValue(ConfigKeyPortalDb));
        }

        protected override string OnPushNotificationDbConnectionString()
        {
            return GetConnectionString(GetAppSettingValue(ConfigKeyPushNotificationDbConnStr));
        }

        protected override Contracts.Data.Config.DbProfile[] OnGetDbProfiles()
        {
            return GetDbProfileFromConfig();
        }

        protected override Contracts.Data.Config.HomeMenuItem[] OnGetHomeMenuItems()
        {
            return GetHomeMenuConfig();
        }

        protected override Contracts.Data.Config.MessageDictionary[] OnGetMessageDictionary()
        {
            return GetMessageDictionaryConfig();
        }

        protected virtual string GetAppSettingValue(string key)
        {
            if (string.IsNullOrEmpty(key))
            {
                throw new ArgumentNullException("key");
            }
            return System.Configuration.ConfigurationManager.AppSettings[key];
        }

        protected virtual string GetConnectionString(string name)
        {
            if (string.IsNullOrEmpty(name))
            {
                throw new ArgumentNullException("name");
            }
            System.Configuration.ConnectionStringSettings css = System.Configuration.ConfigurationManager.ConnectionStrings[name];

            return null == css ? null : css.ConnectionString;
        }

        protected override VZ.CFO.MDMFramework.Providers.Data.IMappingTableDBManager OnGetMappingTableDataProvider()
        {
            return new DbMappingTableDataProvider(OnGetPortalConnectionString(), OnGetEncryptionSalt(), GetDbProfileFromConfig(), OnPortalSchemaPrefix());
        }

        protected override Contracts.Service.MappingTableMgmt.IMappingTableManager OnGetMappingTableManager()
        {
            return new MappingTableManager(GetMappingTableDataProvider(), OnCanAllowMigration(), GetOpsStatusLogManagerDataProvider(), GetODJobManager(), GetMessageDictionaryConfig());
        }

        protected override Contracts.Service.MDUA.IUserAccessManager OnGetUserAccessManager()
        {
            return new Providers.Manager.MDUA.UserAccessManager(GetUserAccessDataProvider(), GetMenuConfig(), GetOpsStatusLogManagerDataProvider());
        }

        protected override Contracts.Service.MDUA.IUserAccessManager OnGetUserAccessDataProvider()
        {
            return new DbUserAccessDataProvider(OnGetPortalConnectionString(), OnGetEncryptionSalt(), OnGetLdapConnection(), OnGetLdapUserName(), OnGetLdapEncryptedPassword(), OnGetOpsStatusLogManagerDataProvider(), OnLdapGroupName());
        }

        protected override Contracts.Service.PushNotification.IPushNotificationService OnGetPushNotificationManager()
        {
            return new Providers.Manager.PushNotification.PushNotificationManager(GetPushNotificationDataProvider());
        }

        protected override Contracts.Service.PushNotification.IPushNotificationService OnGetPushNotificationDataProvider()
        {
            return new DbPushNotificationDataProvider(OnPushNotificationDbConnectionString(), OnGetEncryptionSalt(), new Contracts.Data.PushNotification.PushNotificationCallback());
        }

        protected override Contracts.Service.MDUA.IODJobManager OnGetODJobManagerDataProvider()
        {
            return new DbODJobsManagerDataProvider(OnGetPortalConnectionString(), OnGetEncryptionSalt(), GetESPJobConfig(), OnGetOpsStatusLogManagerDataProvider());
        }

        protected override Contracts.Service.MDUA.IODJobManager OnGetODJobManager()
        {
            return new Providers.Manager.MDUA.ODJobsManager(GetODJobManagerDataProvider(), GetESPJobConfig(), GetOpsStatusLogManagerDataProvider());
        }

        protected override Contracts.Service.ISecurityManager OnGetSecurityManager()
        {
            return new Providers.Manager.SecurityManager(OnGetEncryptionSalt());
        }

        protected override string OnGetEncryptionSalt()
        {
            return GetAppSettingValue(ConfigKeyEncryptionSalt);
        }

        protected override Contracts.Service.PushNotification.IPushNotificationService OnGetPushNotificationManagerInstance()
        {
            throw new NotImplementedException();
        }

        protected override Contracts.Data.Config.MenuConfig OnGetMenuConfig()
        {
            return GetMenuConfig();
        }
        protected override Contracts.Data.Config.ESPJobConfig OnGetESPJobConfig()
        {
            return GetESPJobConfig();
        }
        protected override Contracts.Data.Config.FTProfile[] OnGetFTProfiles()
        {
            return GetFTProfileFromConfig();
        }

        protected override Contracts.Service.MDUA.IFileTransferManager OnGetFileTransferDataProvider()
        {
            return new DbFileTransferManagerDataProvider(OnGetPortalConnectionString(), OnGetEncryptionSalt());
        }

        protected override Contracts.Service.MDUA.IFileTransferManager OnGetFileTransferManager()
        {
            return new Providers.Manager.MDUA.FileTransferManager(OnGetFileTransferDataProvider(), OnGetFTProfiles(), OnGetFactFileArchiveLocation(), OnGetOpsStatusLogManagerDataProvider(), OnAllowedFileTypes());
        }

        private Contracts.Data.Config.DbProfile[] GetDbProfileFromConfig()
        {
            //Contracts.Data.Config.MDMFramworkConfig mconfig = new Contracts.Data.Config.MDMFramworkConfig();
            //List<Contracts.Data.Config.DbProfile> dbp = new List<Contracts.Data.Config.DbProfile>();
            //dbp.Add(new Contracts.Data.Config.DbProfile() { Name = "n1", ConnectionString = "cs1", EncryptedPassword = "ep", EncryptedUserName = "epud" });
            //dbp.Add(new Contracts.Data.Config.DbProfile() { Name = "n2", ConnectionString = "cs1", EncryptedPassword = "ep", EncryptedUserName = "epud" });
            //mconfig.DbProfileList = dbp.ToArray();
            //var s = Common.Utility.SerlializeToJsonString(mconfig);
            //var ds = Common.Utility.SerializeObject(mconfig);


            //var configPath = GetAppSettingValue(ConfigKeyMDMConf);
            //var configFileContent = System.IO.File.ReadAllText(configPath);
            //Contracts.Data.Config.DbProfile[] dbProfile = null;
            //Contracts.Data.Config.MDMFramworkConfig mdmFrameworkConfig = Common.Utility.DeserializeObject<Contracts.Data.Config.MDMFramworkConfig>(configFileContent);

            Contracts.Data.Config.DbProfile[] dbProfile = null;
            Contracts.Data.Config.MDMFrameworkConfig mdmFrameworkConfig = (Contracts.Data.Config.MDMFrameworkConfig)System.Configuration.ConfigurationManager.GetSection("MDMFrameworkConfig");
            if (mdmFrameworkConfig != null && mdmFrameworkConfig.DbProfileList != null)
            {
                dbProfile = mdmFrameworkConfig.DbProfileList;
            }
            return dbProfile;
        }

        private Contracts.Data.Config.FTProfile[] GetFTProfileFromConfig()
        {
            Contracts.Data.Config.FTProfile[] ftProfile = null;
            Contracts.Data.Config.MDMFrameworkConfig mdmFrameworkConfig = (Contracts.Data.Config.MDMFrameworkConfig)System.Configuration.ConfigurationManager.GetSection("MDMFrameworkConfig");
            if (mdmFrameworkConfig != null && mdmFrameworkConfig.DbProfileList != null)
            {
                ftProfile = mdmFrameworkConfig.FtProfileList;
            }
            return ftProfile;
        }

        private Contracts.Data.Config.MessageDictionary[] GetMessageDictionaryConfig()
        {
            Contracts.Data.Config.MessageDictionary[] messageDictionary = null;
            Contracts.Data.Config.MDMFrameworkConfig mdmFrameworkConfig = (Contracts.Data.Config.MDMFrameworkConfig)System.Configuration.ConfigurationManager.GetSection("MDMFrameworkConfig");
            if (mdmFrameworkConfig != null && mdmFrameworkConfig.MessageConfig != null)
            {
                messageDictionary = mdmFrameworkConfig.MessageConfig;
            }
            return messageDictionary;
        }

        private Contracts.Data.Config.MenuConfig GetMenuConfig()
        {
            Contracts.Data.Config.MenuConfig menuConfig = null;
            
            Contracts.Data.Config.MDMFrameworkConfig mdmFrameworkConfig = (Contracts.Data.Config.MDMFrameworkConfig)System.Configuration.ConfigurationManager.GetSection("MDMFrameworkConfig");
            if (mdmFrameworkConfig != null && mdmFrameworkConfig.MenuConfiguration != null)
            {
                menuConfig = mdmFrameworkConfig.MenuConfiguration;
            }

            return menuConfig;
        }
        private Contracts.Data.Config.ESPJobConfig GetESPJobConfig()
        {
            Contracts.Data.Config.ESPJobConfig espJobConfig = new Contracts.Data.Config.ESPJobConfig();

            espJobConfig.EspRestApiUrl = GetAppSettingValue(ConfigKeyEspRestApiUrl);
            espJobConfig.EspUserName = GetAppSettingValue(ConfigKeyEspUserName);
            espJobConfig.EspPwd = GetAppSettingValue(ConfigKeyEspPwd);
            espJobConfig.RestSvcRequestOffsetTime = GetAppSettingValue(ConfigKeyEspRestApiUrl);
            espJobConfig.EspTimezone = GetAppSettingValue(ConfigKeyEspTimezone);
            espJobConfig.EspPrefix = GetAppSettingValue(ConfigKeyEspPrefix);
            return espJobConfig;
        }

        private Contracts.Data.Config.HomeMenuItem[] GetHomeMenuConfig()
        {
            var config = (Contracts.Data.Config.MDMFrameworkConfig)System.Configuration.ConfigurationManager.GetSection("MDMFrameworkConfig");

            return config != null ? config.HomeMenuConfig : null;
        }

        protected override string OnPortalSchemaPrefix()
        {
            return GetAppSettingValue(ConfigKeyPortalSchemaPrefix);
        }

        protected override bool OnCanAllowMigration()
        {
            bool canAllowMigration;
            bool.TryParse(GetAppSettingValue(ConfigKeyCanAllowMigration), out canAllowMigration);
            return canAllowMigration;
        }

        protected override Providers.Data.IOpsStatusLogManager OnGetOpsStatusLogManagerDataProvider()
        {
            return new DbOpsStatusLogManagerDataProvider(OnGetPortalConnectionString(), OnGetEncryptionSalt());
        }

        protected override string OnGetLogLocation()
        {
            return GetAppSettingValue(ConfigKeyLogLocation);
        }

        protected override Contracts.Service.ILogManager OnGetLogDataProvider()
        {
            return new TextFileLogProvider(OnGetLogLocation());
        }

        protected override Contracts.Service.ILogManager OnGetLogManager()
        {
            return new LogManager(GetLogDataProvider());
        }
        protected override IFactTableManagerDataProvider OnGetFactTableManagerDataProvider()
        {
            return new DbFactTableManagerDataProvider(OnGetPortalConnectionString(), OnGetDbProfiles(), OnGetEncryptionSalt(), OnGetOpsStatusLogManagerDataProvider());
        }
        protected override Contracts.Service.MDUA.IFactTableManager OnGetFactTableManager()
        {
            return new Providers.Manager.MDUA.FactTableManager(OnGetFactTableManagerDataProvider());
        }

        protected override string OnGetFactFileArchiveLocation()
        {
            return GetAppSettingValue(ConfigKeyFactFileArchiveLocation);
        }

        protected override IFactTableUserUploadDataProvider OnGetFactTableUserUploadManagerDataProvider()
        {
            return new DbFactTableUserUploadManagerDataProvider(OnGetPortalConnectionString(), OnGetEncryptionSalt(), OnGetDbProfiles(), OnGetFactTableManager(), OnGetOpsStatusLogManagerDataProvider());
        }

        protected override Contracts.Service.MDUA.IFactTableUserUpload OnGetFactTableUserUploadManager()
        {
            return new Providers.Manager.MDUA.FactTableUserUploadManager(OnGetFactTableManager(), OnGetSecurityManager(), OnGetOpsStatusLogManagerDataProvider(), OnGetFactTableUserUploadManagerDataProvider(), OnGetUserAccessManager(), OnGetFactFileArchiveLocation(), OnMaxUploadSizeInMB());
        }

        protected override Contracts.Service.IExportTableManager OnGetExportTableManagerDataProvider()
        {
            return new DbExportTableManagerDataProvider(OnGetPortalConnectionString(), OnGetEncryptionSalt(), OnGetSecurityManager());
        }

        protected override Contracts.Service.IExportTableManager OnGetExportTableManager()
        {
            return new ExportTableManager(OnGetExportTableManagerDataProvider());
        }

        protected override string OnGetLdapConnection()
        {
            return GetAppSettingValue(ConfigKeyLdapConnection);
        }

        protected override string OnGetLdapUserName()
        {
            return GetAppSettingValue(ConfigKeyLdapUserName);
        }

        protected override string OnGetLdapEncryptedPassword()
        {
            return GetAppSettingValue(ConfigKeyLdapEncryptedPassword);
        }

        protected override double OnMaxUploadSizeInMB()
        {
            return Convert.ToDouble(GetAppSettingValue(ConfigKeyMaxUploadSizeInMB));
        }

        protected override string OnAllowedFileTypes()
        {
            return GetAppSettingValue(ConfigKeyAllowedFileTypes);
        }

        protected override string OnLdapGroupName()
        {
            return GetAppSettingValue(ConfigKeyLdapGroupName);
        }

        protected override IReportingDataProvider OnGetReportingDataProvider()
        {
            return new OracleDbReportingDataProvider(OnGetPortalConnectionString(), OnGetEncryptionSalt(), OnGetDbProfiles());
        }

        protected override Contracts.Service.Reporting.IReportingManager OnGetReportingManager()
        {
            return new Providers.Manager.Reporting.ReportingManager(OnGetReportingDataProvider());
        }
    }
}
