﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Providers.Data
{
    public abstract class OpsStatusLogManagerDataProvider : DataProvider, IOpsStatusLogManager
    {

        public OpsStatusLogManagerDataProvider(string connectionString, string encryptionSalt)
            : base(connectionString, encryptionSalt)
        { }

        public long StartProcess(string module, string comment, string action, bool logStep, string actionType, string source, string target)
        {
            return OnStartProcess(module, comment, action, logStep, actionType, source, target);
        }

        public void StartStep(long runStatusId, string action, string action_type, string source, string target)
        {
            OnStartStep(runStatusId, action, action_type, source, target);
        }

        public void EndStep(long runStatusId)
        {
            OnEndStep(runStatusId);
        }

        public void NextStep(long runStatusId, long rows, string comment, string action, string actionType, string source, string target)
        {
            OnNextStep(runStatusId, rows, comment, action, actionType, source, target);
        }
        public void LogEvent(string who, string fromLocation, string action, Exception exception, Contracts.Data.MDUA.UserToolLogLevel logLevel)
        {
            OnLogEvent(who, fromLocation, action, exception, logLevel);
        }
        protected abstract long OnStartProcess(string module, string comment, string action, bool logStep, string actionType, string source, string target);
        protected abstract void OnStartStep(long runStatusId, string action, string action_type, string source, string target);
        protected abstract void OnEndStep(long runStatusId);
        protected abstract void OnNextStep(long runStatusId, long rows, string comment, string action, string actionType, string source, string target);
        protected abstract void OnEndProcess(long runStatusId, string finalComment);
        protected abstract void OnLogEvent(string who, string fromLocation, string action, Exception exception, Contracts.Data.MDUA.UserToolLogLevel logLevel);


        public void EndProcess(long runStatusId, string finalComment)
        {
            OnEndProcess(runStatusId, finalComment);
        }


        public void LogEvent(string who, string fromLocation, string action, string status, Contracts.Data.MDUA.UserToolLogLevel logLevel)
        {
            OnLogEvent(who, fromLocation, action, status, logLevel);
        }
        protected abstract void OnLogEvent(string who, string fromLocation, string action, string status, Contracts.Data.MDUA.UserToolLogLevel logLevel);
    }
}
