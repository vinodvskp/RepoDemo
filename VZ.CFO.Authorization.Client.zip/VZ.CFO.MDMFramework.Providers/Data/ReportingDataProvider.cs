﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Data.Reporting;
using VZ.CFO.MDMFramework.Contracts.Service.Reporting;

namespace VZ.CFO.MDMFramework.Providers.Data
{
    public abstract class ReportingDataProvider : DataProvider, IReportingDataProvider
    {
        public ReportingDataProvider(string connectionString, string encryptionSalt)
            : base(connectionString, encryptionSalt)
        { }

        public Contracts.Data.Reporting.Report GetReport(string userId, long reportId)
        {
            return OnGetReport(userId, reportId);
        }

        public async Task<Contracts.Data.Reporting.ReportingResponse> GetReportDataAsync(string userId, long reportId)
        {
            //Not supported
            var task = Task.Run(() => OnGetReportDataAsync(userId, reportId));
            return await task;
        }

        public async Task<Contracts.Data.Reporting.ReportingResponse> GetReportDataAsync(string userId, long reportId, int pageNumber, int rowsPerPage, int totalRecords)
        {
            //Not supported
            var task = Task.Run(() => OnGetReportDataAsync(userId, reportId, pageNumber, rowsPerPage, totalRecords));
            return await task;
        }

        public Task<ReportingResponse> GetReportDataAsync(string userId, long reportId, KnownValues.RepositoryType repositoryType)
        {
            //This should fetch data based on reporting data
            throw new NotImplementedException();
        }

        public Task<ReportingResponse> GetReportDataAsync(string userId, long reportId, KnownValues.RepositoryType repositoryType, int pageNumber, int rowsPerPage, int totalRecords)
        {
            //This should fetch data based on reporting data
            throw new NotImplementedException();
        }

        public ReportGroup[] GetReports(string userId)
        {
            return OnGetReports(userId);
        }

        public ReportGroup GetReportsByGroupId(string userId, long groupId)
        {
            return OnGetReportsByGroupId(userId, groupId);
        }

        //
        protected abstract Contracts.Data.Reporting.Report OnGetReport(string userId, long reportId);
        protected abstract Contracts.Data.Reporting.ReportingResponse OnGetReportDataAsync(string userId, long reportId);
        protected abstract Contracts.Data.Reporting.ReportingResponse OnGetReportDataAsync(string userId, long reportId, int pageNumber, int rowsPerPage, int totalRecords);
        protected abstract Task<ReportingResponse> OnGetReportDataAsync(string userId, long reportId, KnownValues.RepositoryType repositoryType);
        protected abstract Task<ReportingResponse> OnGetReportDataAsync(string userId, long reportId, KnownValues.RepositoryType repositoryType, int pageNumber, int rowsPerPage, int totalRecords);
        protected abstract ReportGroup[] OnGetReports(string userId);
        protected abstract ReportGroup OnGetReportsByGroupId(string userId, long groupId);


        public Task<string> ExportReport(string userId, long reportId)
        {
            throw new NotImplementedException();
        }
    }
}
