﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Data.Config;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables;
using VZ.CFO.MDMFramework.Contracts.Data;
using VZ.CFO.MDMFramework.Contracts.Service.MDUA;
namespace VZ.CFO.MDMFramework.Providers.Data
{
    public abstract class FactTableManagerDataProvider : DataProvider, IFactTableManagerDataProvider
    {
        public FactTableManagerDataProvider(string connectionString, string encryptionSalt)
            : base(connectionString, encryptionSalt)
        { }

        public FactTable[] GetAllFactTables(string userId)
        {
            return OnGetAllFactTables(userId);
        }
        public FactTable GetFactTable(string userId, long factTableId)
        {
            return OnGetFactTable(userId, factTableId);
        }
        public FactFileType[] GetFactFileTypes(string userId, long factTableId)
        {
            return OnGetFactFileTypes(userId, factTableId);
        }
        public FactTable[] GetFactFileTypesBasic(string userId)
        {
            return OnGetFactFileTypesBasic(userId);
        }
        public FactFileType GetFactFileType(string userId, FileTypeRequest fileTypeRequest)
        {
            return OnGetFactFileType(userId, fileTypeRequest);
        }

        public FileTypeResponse SaveFileType(string userId, FactFileType factFileType)
        {
            return OnSaveFileType(userId, factFileType);
        }
        public FileTypeResponse DeleteFileType(string userId, FileTypeRequest fileTypeRequest)
        {
           return  OnDeleteFileType(userId, fileTypeRequest);
        }
      
        public KeyComboResponse GetKeyCombinations(string userId, KeyComboRequest keyComboRequest)
        {
            return OnGetKeyCombinations(userId, keyComboRequest);
        }
     
        public KeyComboMoveResponse MoveKeyCombinations(string userId, KeyComboMoveRequest keyComboMoveRequest)
        {
            return OnMoveKeyCombinations(userId, keyComboMoveRequest);
        }

        public KeyComboDeleteResponse DeleteKeyCombinations(string userId, KeyComboDeleteRequest keyComboDeleteRequest)
        {
            return OnDeleteKeyCombinations(userId, keyComboDeleteRequest);
        }
        public TableInfo GetTableInfo(string userId, long tableId)
        {
            return OnGetTableInfo(userId, tableId);
        }

        public FactTable  GetFactTableBasicInfo(string userId, long tableId)
        {
            return OnGetFactTableBasicInfo(userId, tableId);
        }
        public string GetDbConnectionString(string dbProfileName)
        {
            return OnGetDbConnectionString(dbProfileName);
        }

        public string GetFileTypeCodeById(long factTableId, long fileTypeCodeId)
        {
            return OnGetFileTypeCodeById(factTableId, fileTypeCodeId);
        }

        public string GetPagingQueryTemplate()
        {
            return OnGetPagingQueryTemplate();
        }

        public FactTableSettings GetFactTableSetting(string userId)
        {
            return OnGetFactTableSetting(userId);
        }

        public FactProcessUploadedFileResponse GetAuditData(string userId, FactAuditRequest auditRequest)
        {
            return OnGetAuditData(userId, auditRequest);
        }
        protected abstract FactProcessUploadedFileResponse OnGetAuditData(string userId, FactAuditRequest auditRequest);


        public FactProcessUploadedFileResponse GetAuditData(string userId, FactAuditRequest auditRequest, FactTable factTable)
        {
            return OnGetAuditData(userId, auditRequest, factTable);
        }
        protected abstract FactProcessUploadedFileResponse OnGetAuditData(string userId, FactAuditRequest auditRequest, FactTable factTable);

        public string[] GetDimensionValues(string userId, FactAuditRequest auditRequest, FactTable factTable)
        {
            return OnGetDimensionValues(userId, auditRequest, factTable);
        }


        public string[] GetDimensionValues(string userId, FactAuditRequest auditRequest)
        {
            return OnGetDimensionValues(userId, auditRequest);
        }

        public FactReportingPeriod GetCurrentPeriod(string userId, long factTableId)
        {
            return OnGetCurrentPeriod(userId, factTableId);
        }

        protected abstract FactTable[] OnGetAllFactTables(string userId);
        protected abstract FactFileType[] OnGetFactFileTypes(string userId, long factTableId);
        protected abstract FactTable[] OnGetFactFileTypesBasic(string userId);
        protected abstract FactTable OnGetFactTable(string userId, long factTableId);
        protected abstract FactFileType OnGetFactFileType(string userId, FileTypeRequest fileTypeRequest);
        protected abstract FileTypeResponse OnDeleteFileType(string userId, FileTypeRequest fileTypeRequest);
        protected abstract FileTypeResponse OnSaveFileType(string userId, FactFileType factFileType);
        protected abstract KeyComboResponse OnGetKeyCombinations(string userId, KeyComboRequest keyComboRequest);
        protected abstract KeyComboMoveResponse OnMoveKeyCombinations(string userId, KeyComboMoveRequest keyComboMoveRequest);
        protected abstract KeyComboDeleteResponse OnDeleteKeyCombinations(string userId, KeyComboDeleteRequest keyComboDeleteRequest);
        protected abstract TableInfo OnGetTableInfo(string userId, long tableId);
        protected abstract FactTable OnGetFactTableBasicInfo(string userId, long tableId);
        protected abstract string OnGetDbConnectionString(string dbProfileName);
        protected abstract string OnGetFileTypeCodeById(long factTableId, long fileTypeCodeId);
        protected abstract string  OnGetPagingQueryTemplate();
        protected abstract FactTableSettings OnGetFactTableSetting(string userId);
        protected abstract string[] OnGetDimensionValues(string userId, FactAuditRequest auditRequest, FactTable factTable);
        protected abstract string[] OnGetDimensionValues(string userId, FactAuditRequest auditRequest);
        protected abstract FactReportingPeriod OnGetCurrentPeriod(string userId, long factTableId);

        public string ExportAuditData(string userId, FactAuditRequest auditRequest)
        {
            throw new NotImplementedException();
        }
    }
}
