﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Providers.Data
{
    public interface IOpsStatusLogManager
    {
        long StartProcess(string module, string comment, string action, bool logStep, string actionType, string source, string target);
        void StartStep(long runStatusId, string action, string action_type, string source, string target);
        void EndStep(long runStatusId);
        void NextStep(long runStatusId, long rows, string comment, string action, string actionType, string source, string target);
        void EndProcess(long runStatusId, string finalComment);
        void LogEvent(string who, string fromLocation, string action, Exception exception, Contracts.Data.MDUA.UserToolLogLevel logLevel);
        void LogEvent(string who, string fromLocation, string action, string status, Contracts.Data.MDUA.UserToolLogLevel logLevel);
    }
}
