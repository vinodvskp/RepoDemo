﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Service.MDUA;

namespace VZ.CFO.MDMFramework.Providers.Data
{
    public abstract class FileTransferDataProvider : DataProvider, IFileTransferManager
    {
        public FileTransferDataProvider(string connectionString, string encryptionSalt)
            : base(connectionString, encryptionSalt)
        { }

        public Contracts.Data.MDUA.FileTransfer.FileTransferProfile[] GetFileTransferProfiles(string userId)
        {
            return OnGetFileTransferProfiles(userId);
        }

        public Contracts.Data.MDUA.FileTransfer.FileTransferResponse TransferFile(Contracts.Data.MDUA.FileTransfer.FileTransferRequest fileTransferRequest)
        {
            return OnTransferFile(fileTransferRequest);
        }

        public Contracts.Data.MDUA.FileTransfer.FileTransferProfile GetFileTransferProfile(string userId, long profileId)
        {
            return OnGetFileTransferProfile(userId, profileId);
        }

        protected abstract Contracts.Data.MDUA.FileTransfer.FileTransferProfile[] OnGetFileTransferProfiles(string userId);

        protected abstract Contracts.Data.MDUA.FileTransfer.FileTransferResponse OnTransferFile(Contracts.Data.MDUA.FileTransfer.FileTransferRequest fileTransferRequest);

        protected abstract Contracts.Data.MDUA.FileTransfer.FileTransferProfile OnGetFileTransferProfile(string userId, long profileId);
    }
}
