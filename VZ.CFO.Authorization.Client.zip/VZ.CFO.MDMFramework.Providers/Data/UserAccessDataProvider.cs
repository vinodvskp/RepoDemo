﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Data;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA;
using VZ.CFO.MDMFramework.Contracts.Data.Security;

namespace VZ.CFO.MDMFramework.Providers.Data
{
    public abstract class UserAccessDataProvider : DataProvider, Contracts.Service.MDUA.IUserAccessManager
    {
        public UserAccessDataProvider(string connectionString, string encryptionSalt)
            : base(connectionString, encryptionSalt)
        { }

        public Contracts.Data.MDUA.UserAccess[] GetUserAccessByEmployeeId(string employeeId)
        {
            return OnGetUserAccessByEmployeeId(employeeId);
        }

        public Contracts.Data.MDUA.UserAccess[] GetUserAccessByUserId(string userId)
        {
            return OnGetUserAccessByUserId(userId);
        }

        public bool SaveUserAccessByEmployeeId(string userId, string employeeId, string accessObjectType, Contracts.Data.MDUA.UserAccess[] userAccess)
        {
            return OnSaveUserAccessByEmployeeId(userId, employeeId, accessObjectType, userAccess);
        }

        public Claim[] GetUserAccess(string id, string authenticationSourceType)
        {
            return OnGetUserAccess(id, authenticationSourceType);
        }
        public Contracts.Data.MDUA.UserAccess[] GetUserAccessForAccessObjType(string employeeId, string accessObjectType)
        {
            return OnGetUserAccessForAccessObjType(employeeId, accessObjectType);
        }
        public Contracts.Data.MDUA.Menu[] GetMenuForUser(System.Security.Claims.Claim[] userClaims)
        {
            throw new NotImplementedException();
        }


        public Contracts.Data.MDUA.UserInfo[] GetAllUsers()
        {
            return OnGetAllUsers();
        }

        public Contracts.Data.MDUA.UserInfo GetUser(string employeeId)
        {
            return OnGetUser(employeeId);
        }

        public Contracts.Data.MDUA.UserInfo GetUserFromLdap(string vzid)
        {
            return OnGetUserFromLdap(vzid);
        }

        public bool SaveUserInfo(string userId, Contracts.Data.MDUA.UserInfo userInfo)
        {
            return OnSaveUserInfo(userId, userInfo);
        }

        public bool DeleteUserInfo(string userId, string employeeId)
        {
            return OnDeleteUserInfo(employeeId);
        }

        public Contracts.Data.MDUA.ODJobs.ODJobGroup[] GetODJobAccess(string employeeId)
        {
            return OnGetODJobAccess(employeeId);
        }

        public Contracts.Data.MDUA.FactTables.FactTable[] GetFactFileTypeAccess(string employeeId)
        {
            return OnGetFactFileTypeAccess(employeeId);
        }

        public Contracts.Data.MDUA.ODJobs.ODJobGroup[] GetAllODJobs()
        {
            return OnGetAllODJobs();
        }
        public Contracts.Data.MDUA.FactTables.FactTable[] GetAllFactFile()
        {
            return OnGetAllFactFile();
        }

        public bool SaveLegacyUserAccess(string userId, Contracts.Data.MDUA.User.LegacyUserAccess legacyUserAccess)
        {
            return OnSaveLegacyUserAccess(userId, legacyUserAccess);
        }

        public async Task<Contracts.Data.MDUA.UserAccessFlatPage> GetUserAccessFlatAsync(string userId, int pageNumber, int rowsPerPage, int totalRecords)
        {
            var task = Task.Run(() => OnGetUserAccessFlat(userId, string.Empty, pageNumber, rowsPerPage, totalRecords));
            return await task;
        }

        public Contracts.Data.MDUA.UserAccessFlatPage GetUserAccessFlat(string userId, string accessObjectType, int pageNumber, int rowsPerPage, int totalRecords)
        {
            return OnGetUserAccessFlat(userId, accessObjectType, pageNumber, rowsPerPage, totalRecords);
        }

        public Task<string> ExportUsers(string userId, ExportUserType exportType)
        {
            throw new NotImplementedException();
        }

        public Contracts.Data.GenericResponse RefreshUsersFromADGroup(string employeeId)
        {
            return OnRefreshUsersFromADGroup(employeeId);
        }

        protected abstract Contracts.Data.MDUA.UserAccess[] OnGetUserAccessByEmployeeId(string employeeId);
        protected abstract Contracts.Data.MDUA.UserAccess[] OnGetUserAccessByUserId(string userId);
        protected abstract bool OnSaveUserAccessByEmployeeId(string userId, string employeeId, string accessObjectType, Contracts.Data.MDUA.UserAccess[] userAccess);
        protected abstract Claim[] OnGetUserAccess(string id, string authenticationSourceType);
        protected abstract Contracts.Data.MDUA.UserAccess[] OnGetUserAccessForAccessObjType(string employeeId, string accessObjectType);
        protected abstract Contracts.Data.MDUA.Menu[] OnGetMenuForUser(System.Security.Claims.Claim[] userClaims);
        protected abstract Contracts.Data.MDUA.UserInfo[] OnGetAllUsers();
        protected abstract Contracts.Data.MDUA.UserInfo OnGetUser(string employeeId);
        protected abstract Contracts.Data.MDUA.UserInfo OnGetUserFromLdap(string vzid);
        protected abstract bool OnSaveUserInfo(string userId, Contracts.Data.MDUA.UserInfo userInfo);
        protected abstract bool OnDeleteUserInfo(string employeeId);
        protected abstract Contracts.Data.MDUA.ODJobs.ODJobGroup[] OnGetODJobAccess(string employeeId);
        protected abstract Contracts.Data.MDUA.FactTables.FactTable[] OnGetFactFileTypeAccess(string employeeId);
        protected abstract Contracts.Data.MDUA.ODJobs.ODJobGroup[] OnGetAllODJobs();
        protected abstract Contracts.Data.MDUA.FactTables.FactTable[] OnGetAllFactFile();
        protected abstract bool OnSaveLegacyUserAccess(string userId, Contracts.Data.MDUA.User.LegacyUserAccess legacyUserAccess);
        
        protected abstract Contracts.Data.MDUA.UserAccessFlatPage OnGetUserAccessFlat(string userId, string accessObjectType, int pageNumber, int rowsPerPage, int totalRecords);
        protected abstract Contracts.Data.GenericResponse OnRefreshUsersFromADGroup(string employeeId);
        protected abstract VZ.CFO.MDMFramework.Contracts.Data.MDUA.User.HomepageContent OnGetHomepageContent(string employeeId);
        protected abstract bool OnUpdateHomepageContent(string employeeId, VZ.CFO.MDMFramework.Contracts.Data.MDUA.User.HomepageContent homepageContent);

        public void AuditUser(AuditInfo auditInfo)
        {
            throw new NotImplementedException();
        }

        public VZ.CFO.MDMFramework.Contracts.Data.MDUA.User.HomepageContent GetHomepageContent(string employeeId)
        {
            return this.OnGetHomepageContent(employeeId);
        }

        public bool UpdateHomepageContent(string employeeId, VZ.CFO.MDMFramework.Contracts.Data.MDUA.User.HomepageContent homepageContent)
        {
            return this.OnUpdateHomepageContent(employeeId, homepageContent);
        }
    }
}
