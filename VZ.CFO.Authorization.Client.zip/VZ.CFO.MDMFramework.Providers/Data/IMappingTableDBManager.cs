﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Data.MappingTableMgmt;
using VZ.CFO.MDMFramework.Contracts.Service.MappingTableMgmt;

namespace VZ.CFO.MDMFramework.Providers.Data
{
    public interface IMappingTableDBManager : IMappingTableManager
    {
        Contracts.Data.MappingTableMgmt.MappingTableWriteResponse SaveMappingTableData(string userId, Contracts.Data.MappingTableMgmt.MappingTable mappingTable, Contracts.Data.MappingTableMgmt.MappingTableWriteRequest writeRequest);
        Contracts.Data.MappingTableMgmt.MappingTableWriteResponse ValidationMappingTableData(string userId, Contracts.Data.MappingTableMgmt.MappingTable mappingTable, Contracts.Data.MappingTableMgmt.MappingTableWriteRequest writeRequest);
        Contracts.Data.MappingTableMgmt.MappingTableWriteResponse ValidateMappingTableMigrationData(string userId, Contracts.Data.MappingTableMgmt.MappingTable mappingTable, long runStatusId);
        Contracts.Data.MappingTableMgmt.MappingTableWriteResponse MigrateMappingTableData(string userId, Contracts.Data.MappingTableMgmt.MappingTable mappingTable, Contracts.Data.MappingTableMgmt.MappingTableWriteRequest writeRequest);
        /// <summary>
        /// Stage Mapping Table Data for validation and Save
        /// </summary>
        long StageMappingTableData(string userId, Contracts.Data.MappingTableMgmt.MappingTable mappingTable, Contracts.Data.MappingTableMgmt.MappingTableWriteRequest writeRequest);

        long ArchiveStageData(string userId, long runStatusId);

        long StageFromChangeControl(string userId, MappingTable mappingTableInfo, Contracts.Data.MappingTableMgmt.MappingTableWriteRequest writeRequest);

        void WriteMappingTableAuditLog(string userId, long mappingTableId, string action, int auditType, bool isValidationOverriden);

        void UpdateLastValidated(string userId, long mappingTableId);
    }
}
