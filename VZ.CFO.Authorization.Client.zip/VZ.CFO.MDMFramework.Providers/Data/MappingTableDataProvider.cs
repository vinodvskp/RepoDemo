﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Providers
{
    public abstract class MappingTableDataProvider : DataProvider, VZ.CFO.MDMFramework.Providers.Data.IMappingTableDBManager
    {
        public MappingTableDataProvider(string connectionString, string encryptionSalt)
            : base(connectionString, encryptionSalt)
        { }

        public Contracts.Data.MappingTableMgmt.MappingTable[] GetAllMappingTables(string userId)
        {
            return OnGetAllMappingTables(userId);
        }

        public Contracts.Data.MappingTableMgmt.MappingTable GetMappingTableInfo(string userId, long mappingTableId)
        {
            return OnGetMappingTableInfo(userId, mappingTableId);
        }

        public Contracts.Data.MappingTableMgmt.MappingTableDataPage GetMappingTable(string userId, long mappingTableId, int pageNumber, int rowsPerPage, int totalRecords)
        {
            return OnGetMappingTable(userId, mappingTableId, pageNumber, rowsPerPage, totalRecords);
        }

        public Contracts.Data.MappingTableMgmt.MappingTable GetMappingTable(string userId, long id, int rowsPerPage)
        {
            return OnGetMappingTable(userId, id, rowsPerPage);
        }

        public Contracts.Data.MappingTableMgmt.MappingTableWriteResponse SaveMappingTableData(string userId, Contracts.Data.MappingTableMgmt.MappingTableWriteRequest writeRequest)
        {
            return OnSaveMappingTableData(userId, null, writeRequest);
        }

        public Contracts.Data.MappingTableMgmt.MappingTableWriteResponse ValidationMappingTableData(string userId, Contracts.Data.MappingTableMgmt.MappingTableWriteRequest writeRequest)
        {
            return OnValidationMappingTableData(userId, null, writeRequest);
        }

        public Contracts.Data.MappingTableMgmt.MappingTableWriteResponse SaveMappingTableData(string userId, Contracts.Data.MappingTableMgmt.MappingTable mappingTable, Contracts.Data.MappingTableMgmt.MappingTableWriteRequest writeRequest)
        {
            return OnSaveMappingTableData(userId, mappingTable, writeRequest);
        }

        public Contracts.Data.MappingTableMgmt.MappingTableWriteResponse ValidationMappingTableData(string userId, Contracts.Data.MappingTableMgmt.MappingTable mappingTable, Contracts.Data.MappingTableMgmt.MappingTableWriteRequest writeRequest)
        {
            return OnValidationMappingTableData(userId, mappingTable, writeRequest);
        }

        public Contracts.Data.MappingTableMgmt.AuditLogPage GetAuditDataPage(string userId, long mappingTableId, Contracts.Data.MappingTableMgmt.KnownValues.AuditType auditType, int pageNumber, int rowsPerPage, int totalRecords, string searchKey)
        {
            return OnGetAuditDataPage(userId, mappingTableId, auditType, pageNumber, rowsPerPage, totalRecords, searchKey);
        }

        public Contracts.Data.MappingTableMgmt.AuditLogPage GetAuditData(string userId, long mappingTableId, Contracts.Data.MappingTableMgmt.KnownValues.AuditType auditType, int rowsPerPage, string searchKey)
        {
            return OnGetAuditData(userId, mappingTableId, auditType, rowsPerPage, searchKey);
        }

        public Contracts.Data.MappingTableMgmt.MappingTableWriteResponse MigrateMappingValues(string userId, Contracts.Data.MappingTableMgmt.MappingTableWriteRequest writeRequest)
        {
            return OnMigrateMappingValues(userId, writeRequest);
        }

        public async Task<Contracts.Data.MappingTableMgmt.MappingTableDataPage> GetMappingTableAsync(string userId, long mappingTableId, int pageNumber, int rowsPerPage, int totalRecords)
        {
            var task = Task.Run(() => OnGetMappingTableAsync(userId, mappingTableId, pageNumber, rowsPerPage, totalRecords));
            return await task;
        }

        public async Task<string> ExportMappingTable(string userId, long mappingTableId)
        {
            var task = Task.Run(() => OnExportMappingTable(userId, mappingTableId));
            return await task;
        }

        public long StageMappingTableData(string userId, Contracts.Data.MappingTableMgmt.MappingTable mappingTable, Contracts.Data.MappingTableMgmt.MappingTableWriteRequest writeRequest)
        {
            return OnStageMappingTableData(userId, mappingTable, writeRequest);
        }

        public long ArchiveStageData(string userId, long runStatusId)
        {
            return OnArchiveStageData(userId, runStatusId);
        }

        public long StageFromChangeControl(string userId, Contracts.Data.MappingTableMgmt.MappingTable mappingTableInfo, Contracts.Data.MappingTableMgmt.MappingTableWriteRequest writeRequest)
        {
            return OnStageFromChangeControl(userId, mappingTableInfo, writeRequest);
        }

        public Contracts.Data.MappingTableMgmt.MappingTableWriteResponse ValidateMappingTableMigrationData(string userId, Contracts.Data.MappingTableMgmt.MappingTable mappingTable, long runStatusId)
        {
            return OnValidateMappingTableMigrationData(userId, mappingTable, runStatusId);
        }

        public Contracts.Data.MappingTableMgmt.MappingTableWriteResponse MigrateMappingTableData(string userId, Contracts.Data.MappingTableMgmt.MappingTable mappingTable, Contracts.Data.MappingTableMgmt.MappingTableWriteRequest writeRequest)
        {
            return OnMigrateMappingTableData(userId, mappingTable, writeRequest);
        }

        public async Task<Contracts.Data.MappingTableMgmt.MappingTableDataPage> GetMappingTableFromLowerEnvAsync(string userId, long mappingTableId, int pageNumber, int rowsPerPage, int totalRecords)
        {
            var task = Task.Run(() => OnGetMappingTableFromLowerEnvAsync(userId, mappingTableId, pageNumber, rowsPerPage, totalRecords));
            return await task;
        }

        public Contracts.Data.MappingTableMgmt.MappingTableDataPage GetMappingTableFromLowerEnv(string userId, long mappingTableId, int pageNumber, int rowsPerPage, int totalRecords)
        {
            return OnGetMappingTableFromLowerEnv(userId, mappingTableId, pageNumber, rowsPerPage, totalRecords);
        }

        public Contracts.Data.MappingTableMgmt.MappingTable GetMappingTableFromLowerEnv(string userId, long id, int rowsPerPage)
        {
            return OnGetMappingTableFromLowerEnv(userId, id, rowsPerPage);
        }

        public void WriteMappingTableAuditLog(string userId, long mappingTableId, string action, int auditType, bool isValidationOverriden)
        {
            OnWriteMappingTableAuditLog(userId, mappingTableId, action, auditType, isValidationOverriden);
        }

        public void UpdateLastValidated(string userId, long mappingTableId)
        {
            OnUpdateLastValidated(userId, mappingTableId);
        }

        protected abstract Contracts.Data.MappingTableMgmt.MappingTable[] OnGetAllMappingTables(string userId);
        protected abstract Contracts.Data.MappingTableMgmt.MappingTable OnGetMappingTableInfo(string userId, long mappingTableId);
        protected abstract Contracts.Data.MappingTableMgmt.MappingTableDataPage OnGetMappingTable(string userId, long mappingTableId, int pageNumber, int rowsPerPage, int totalRecords);
        protected abstract Contracts.Data.MappingTableMgmt.MappingTable OnGetMappingTable(string userId, long id, int rowsPerPage);
        protected abstract Contracts.Data.MappingTableMgmt.MappingTableWriteResponse OnSaveMappingTableData(string userId, Contracts.Data.MappingTableMgmt.MappingTable mappingTable, Contracts.Data.MappingTableMgmt.MappingTableWriteRequest writeRequest);
        protected abstract Contracts.Data.MappingTableMgmt.MappingTableWriteResponse OnValidationMappingTableData(string userId, Contracts.Data.MappingTableMgmt.MappingTable mappingTable, Contracts.Data.MappingTableMgmt.MappingTableWriteRequest writeRequest);
        protected abstract Contracts.Data.MappingTableMgmt.AuditLogPage OnGetAuditDataPage(string userId, long mappingTableId, Contracts.Data.MappingTableMgmt.KnownValues.AuditType auditType, int pageNumber, int rowsPerPage, int totalRecords, string searchKey);
        protected abstract Contracts.Data.MappingTableMgmt.AuditLogPage OnGetAuditData(string userId, long mappingTableId, Contracts.Data.MappingTableMgmt.KnownValues.AuditType auditType, int rowsPerPage, string searchKey);
        protected abstract Contracts.Data.MappingTableMgmt.MappingTableWriteResponse OnMigrateMappingValues(string userId, Contracts.Data.MappingTableMgmt.MappingTableWriteRequest writeRequest);
        protected abstract Contracts.Data.MappingTableMgmt.MappingTableDataPage OnGetMappingTableAsync(string userId, long mappingTableId, int pageNumber, int rowsPerPage, int totalRecords);
        protected abstract string OnExportMappingTable(string userId, long mappingTableId);
        protected abstract long OnStageMappingTableData(string userId, Contracts.Data.MappingTableMgmt.MappingTable mappingTable, Contracts.Data.MappingTableMgmt.MappingTableWriteRequest writeRequest);
        protected abstract long OnArchiveStageData(string userId, long runStatusId);
        protected abstract long OnStageFromChangeControl(string userId, Contracts.Data.MappingTableMgmt.MappingTable mappingTableInfo, Contracts.Data.MappingTableMgmt.MappingTableWriteRequest writeRequest);
        protected abstract Contracts.Data.MappingTableMgmt.MappingTableWriteResponse OnValidateMappingTableMigrationData(string userId, Contracts.Data.MappingTableMgmt.MappingTable mappingTable, long runStatusId);
        protected abstract Contracts.Data.MappingTableMgmt.MappingTableWriteResponse OnMigrateMappingTableData(string userId, Contracts.Data.MappingTableMgmt.MappingTable mappingTable, Contracts.Data.MappingTableMgmt.MappingTableWriteRequest writeRequest);
        protected abstract Contracts.Data.MappingTableMgmt.MappingTableDataPage OnGetMappingTableFromLowerEnvAsync(string userId, long mappingTableId, int pageNumber, int rowsPerPage, int totalRecords);
        protected abstract Contracts.Data.MappingTableMgmt.MappingTableDataPage OnGetMappingTableFromLowerEnv(string userId, long mappingTableId, int pageNumber, int rowsPerPage, int totalRecords);
        protected abstract Contracts.Data.MappingTableMgmt.MappingTable OnGetMappingTableFromLowerEnv(string userId, long id, int rowsPerPage);
        protected abstract void OnWriteMappingTableAuditLog(string userId, long mappingTableId, string action, int auditType, bool isValidationOverriden);
        protected abstract void OnUpdateLastValidated(string userId, long mappingTableId);

        
    }
}
