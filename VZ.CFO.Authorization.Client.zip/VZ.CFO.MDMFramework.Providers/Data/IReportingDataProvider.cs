﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Data.Reporting;
using VZ.CFO.MDMFramework.Contracts.Service.Reporting;

namespace VZ.CFO.MDMFramework.Providers.Data
{
    public interface IReportingDataProvider : IReportingManager
    {
        Task<Contracts.Data.Reporting.ReportingResponse> GetReportDataAsync(string userId, long reportId, KnownValues.RepositoryType repositoryType);
        Task<Contracts.Data.Reporting.ReportingResponse> GetReportDataAsync(string userId, long reportId, KnownValues.RepositoryType repositoryType, int pageNumber, int rowsPerPage, int totalRecords);
    }
}
