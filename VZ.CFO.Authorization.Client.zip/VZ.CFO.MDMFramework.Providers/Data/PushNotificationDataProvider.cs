﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Service.PushNotification;
using VZ.CFO.MDMFramework.Contracts.Data.PushNotification;

namespace VZ.CFO.MDMFramework.Providers.Data
{
    public abstract class PushNotificationDataProvider : PushNotificationDataDataProvider, IPushNotificationService
    {
        public PushNotificationDataProvider(string connectionString, string encryptionSalt, PushNotificationCallback pushCallback)
            : base(connectionString, encryptionSalt, pushCallback)
        {
        }

        public bool IsRunning()
        {
            return OnIsRunning();            
        }

        public void StartService()
        {
            OnStartService();
        }

        public void StopService()
        {
            OnStopService();
        }

        public string ClientSubscription(string clientId, string appName, string appModule)
        {
            return OnClientSubscription(clientId, appName, appModule);
        }

        public bool ClientUnSubscribe(string clientId)
        {
            return OnClientUnSubscribe(clientId);
        }

        public PushNotificationCallback GetPushNotificationCallbackRef()
        {
            return OnGetPushNotificationCallbackRef();
        }

        protected abstract bool OnIsRunning();
        protected abstract void OnStartService();
        protected abstract void OnStopService();
        protected abstract string OnClientSubscription(string clientId, string appName, string appModule);
        protected abstract bool OnClientUnSubscribe(string clientId);
        protected abstract PushNotificationCallback OnGetPushNotificationCallbackRef();
    }
}
