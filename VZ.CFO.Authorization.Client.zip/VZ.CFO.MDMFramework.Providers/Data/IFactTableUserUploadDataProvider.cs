﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Service.MDUA;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables;
using VZ.CFO.MDMFramework.Contracts.Data;
namespace VZ.CFO.MDMFramework.Providers.Data
{
    public interface IFactTableUserUploadDataProvider : IFactTableUserUpload
    {
        FactProcessUploadedFileResponse StageExcelContents(FactProcessUploadedFileRequest request, FactTable factTable, FactFileType factFileType, TableInfo factData);
        FactProcessUploadedFileResponse ProcessStagedData(Contracts.Data.MDUA.FactTables.FactProcessUploadedFileRequest request, FactTable factTable, FactFileType factFileType, TableInfo factData);
        FactProcessUploadedFileResponse ProcessMissingKeysAndStagedData(Contracts.Data.MDUA.FactTables.FactProcessUploadedFileRequest request, FactTable factTable, FactFileType factFileType, TableInfo factData);
    }
}
