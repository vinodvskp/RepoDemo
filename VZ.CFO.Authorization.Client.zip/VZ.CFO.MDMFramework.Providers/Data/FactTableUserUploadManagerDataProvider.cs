﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Data;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables;

namespace VZ.CFO.MDMFramework.Providers.Data
{
    public abstract class FactTableUserUploadManagerDataProvider : DataProvider, IFactTableUserUploadDataProvider
    {
        public FactTableUserUploadManagerDataProvider(string connectionString, string encryptionSalt)
            : base(connectionString, encryptionSalt)
        { }

        public string UploadFactFile(string userId, string fileTypeName, string base64EncodedFile)
        {
            return OnUploadFactFile(userId, fileTypeName, base64EncodedFile);
        }

        protected abstract string OnUploadFactFile(string userId, string fileTypeName, string base64EncodedFile);

        public Contracts.Data.MDUA.FactTables.FactProcessUploadedFileResponse StageExcelContents(FactProcessUploadedFileRequest request, FactTable factTable, FactFileType factFileType, TableInfo factData)
        {
            return OnStageExcelContents(request, factTable, factFileType, factData);
        }
        protected abstract Contracts.Data.MDUA.FactTables.FactProcessUploadedFileResponse OnStageExcelContents(FactProcessUploadedFileRequest request, FactTable factTable, FactFileType factFileType, TableInfo factData);

        public Contracts.Data.MDUA.FactTables.FactProcessUploadedFileResponse ProcessStagedData(Contracts.Data.MDUA.FactTables.FactProcessUploadedFileRequest request, FactTable factTable, FactFileType factFileType, TableInfo factData)
        {
            return OnProcessStagedData(request, factTable, factFileType, factData);
        }
        protected abstract Contracts.Data.MDUA.FactTables.FactProcessUploadedFileResponse OnProcessStagedData(Contracts.Data.MDUA.FactTables.FactProcessUploadedFileRequest request, FactTable factTable, FactFileType factFileType, TableInfo factData);

        public Contracts.Data.MDUA.FactTables.FactProcessUploadedFileResponse UploadFactData(Contracts.Data.MDUA.FactTables.FactProcessUploadedFileRequest processRequest)
        {
            return OnUploadFactData(processRequest);
        }
        protected abstract Contracts.Data.MDUA.FactTables.FactProcessUploadedFileResponse OnUploadFactData(Contracts.Data.MDUA.FactTables.FactProcessUploadedFileRequest processRequest);
        
        public string[] GetDimYears()
        {
            return OnGetDimYears();
        }
        protected abstract string[] OnGetDimYears();


        public FactProcessUploadedFileResponse AddKeysFromStagedData(string userId, long runStatusId, long factTableId, long factFileTypeId)
        {
            return OnAddKeysFromStagedData(userId, runStatusId, factTableId, factFileTypeId);
        }
        protected abstract FactProcessUploadedFileResponse OnAddKeysFromStagedData(string userId, long runStatusId, long factTableId, long factFileTypeId);


        public FactProcessUploadedFileResponse ProcessMissingKeysAndStagedData(FactProcessUploadedFileRequest request, FactTable factTable, FactFileType factFileType, TableInfo factData)
        {
            return OnProcessMissingKeysAndStagedData(request, factTable, factFileType, factData);
        }
        protected abstract FactProcessUploadedFileResponse OnProcessMissingKeysAndStagedData(FactProcessUploadedFileRequest request, FactTable factTable, FactFileType factFileType, TableInfo factData);


        public FactProcessUploadedFileResponse AddKeysAndUploadFact(FactProcessUploadedFileRequest processRequest)
        {
            throw new NotImplementedException();
        }


        public string UploadFactFileByte(string userId, string fileTypeName, byte[] fileInBytes)
        {
            return OnUploadFactFileByte(userId, fileTypeName, fileInBytes);
        }
        protected abstract string OnUploadFactFileByte(string userId, string fileTypeName, byte[] fileInBytes);


        public double GetMaxUploadFileSize()
        {
            throw new NotImplementedException();
        }
    }
}
