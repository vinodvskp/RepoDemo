﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Data.Config;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables;
using VZ.CFO.MDMFramework.Contracts.Data;
using VZ.CFO.MDMFramework.Contracts.Service.MDUA;
using VZ.CFO.MDMFramework.Contracts.Service;
namespace VZ.CFO.MDMFramework.Providers.Data
{
    public abstract class ExportTableManagerDataProvider: DataProvider,IExportTableManager
    {
        public ExportTableManagerDataProvider(string connectionString, string encryptionSalt)
            : base(connectionString, encryptionSalt)
        { }

        public async Task<string> ExportTable(string userId, TableInfo tableInfo)
        {
            string fileAsBase64String = string.Empty;

            if (tableInfo == null)
            {
                throw new Exception("Table does not exists or you do not have access to " + tableInfo.TableName);
            }
            TableValuesPage firstPage = OnGetTableDataPage(tableInfo, 0);
            if (firstPage == null)
            {
                throw new Exception("Error getting data for " + tableInfo.TableName + " table");
            }
            //Collection to hold tasks to retreive page data
            List<Task<TableValuesPage>> remainingPagesTasks = new List<Task<TableValuesPage>>();
            List<TableValuesPage> remainingPages = new List<TableValuesPage>();

            //Add tasks to retreive page data
            for (int pageIndex = 1; pageIndex <tableInfo.TotalPages; pageIndex++)
            {
                remainingPagesTasks.Add(GetTableDataPageAsync(tableInfo, pageIndex));
            }

            //Parallelly fetch data for all pages
            while (remainingPagesTasks.Count > 0)
            {
                Task<TableValuesPage> firstFinishedTask = await Task.WhenAny(remainingPagesTasks);
                remainingPagesTasks.Remove(firstFinishedTask);

                TableValuesPage completedPage = await firstFinishedTask;
                remainingPages.Add(completedPage);
            }

            //Collection to hold the merged data
            Dictionary<int, List<string>> mergedColumnData = new Dictionary<int, List<string>>();

            //Initialize the string list in the dictionary using the data in the first page
            for (int colIndex = 0; colIndex < tableInfo.Columns.Length; colIndex++)
            {
                List<string> colData = new List<string>();
                colData.AddRange(firstPage.Data[colIndex].Values.ToList());
                mergedColumnData.Add(colIndex, colData);
            }

            //merge the column data from all other pages
            for (int pageNumber = 2; pageNumber <= tableInfo.TotalPages; pageNumber++)
            {
                var pageToMerge = remainingPages.FirstOrDefault(p => p.PageNumber == pageNumber);
                for (int colIndex = 0; colIndex < tableInfo.Columns.Length; colIndex++)
                {
                    mergedColumnData[colIndex].AddRange(pageToMerge.Data[colIndex].Values.ToList());
                }
            }

            tableInfo.Data = new ColumnData[tableInfo.Columns.Length];
            for (int colIndex = 0; colIndex < tableInfo.Columns.Length; colIndex++)
            {
                tableInfo.Data[colIndex] = new ColumnData();
                if (mergedColumnData[colIndex] != null )
                {
                    tableInfo.Data[colIndex].Values = mergedColumnData[colIndex].ToArray();
                }
            }

            //generate a temp file in the system's temp location
            var fileName = System.IO.Path.GetTempFileName();
            //Write it to mapping file
            if (WriteMappingDataToCsv(fileName, "sample", tableInfo.ColumnHeaders.ToArray(), tableInfo.Data))
            {
                //Convert the temp file to binary
                byte[] csvBinary = File.ReadAllBytes(fileName);
                //convert binary to base64 string
                fileAsBase64String = Convert.ToBase64String(csvBinary);
            }

            //return csv file as base64 string
            return fileAsBase64String;
        }
        public async Task<TableValuesPage> GetTableDataPageAsync(TableInfo tableInfo, int pageIndex)
        {
            Task<TableValuesPage> task = Task.Run(() => OnGetTableDataPage(tableInfo, pageIndex));
            return await task;
        }

        public string GetSignedUrlKey(string userId, string content)
        {
            return OnGetSignedUrlKey(userId, content); ;
        }
        public string VerifySignedUrlKey(string content, string signedUrl)
        {
            return OnVerifySignedUrlKey(content, signedUrl) ;
        }

        public  bool WriteMappingDataToCsv(string filename, string sheetName, string[] columnHeaders, ColumnData[] columnData)
        {
            bool returnValue = false;
            try
            {
                using (StreamWriter writer = new StreamWriter(filename))
                {
                    writer.WriteLine(string.Join(",", columnHeaders));
                    if( columnData[0].Values != null) {
                        for (int rowIndex = 0; rowIndex < columnData[0].Values.Length; rowIndex++)
                        {
                            List<string> rowStringArray = new List<string>();
                            for (int colIndex = 0; colIndex < columnData.Length; colIndex++)
                            {
                                rowStringArray.Add(string.Format("\"{0}\"", columnData[colIndex].Values[rowIndex]));
                            }
                            writer.WriteLine(string.Join(",", rowStringArray.ToArray()));
                        }
                    }
                    writer.Dispose();
                }

                returnValue = true;
            }
            catch(Exception ex)
            {
                //TODO: Handle exception
                returnValue = false;
            }
            return returnValue;
        }

        protected abstract TableValuesPage OnGetTableDataPage(TableInfo tableInfo, int pageIndex);
        protected abstract string OnGetSignedUrlKey(string userId, string content);
        protected abstract string OnVerifySignedUrlKey(string content, string signedUrl);
    }
}
