﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Data.Config;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA.ODJobs;
using VZ.CFO.MDMFramework.Contracts.Service.MDUA;

namespace VZ.CFO.MDMFramework.Providers.Data 
{
    public abstract class ODJobsManagerDataProvider : DataProvider, IODJobManager
    {
        public ODJobsManagerDataProvider(string connectionString, string encryptionSalt, ESPJobConfig espJobConfig, MDMFramework.Providers.Data.IOpsStatusLogManager opsStatusDbManager)
            : base(connectionString, encryptionSalt)
        { }

        public ODJobGroup[] GetAllODJobGroups(string userId)
        {
            return OnGetAllODJobGroups(userId); 
        }
        public ODJob[] GetAllODJobs(string userId, long groupId)
        {
            return OnGetAllODJobs(userId, groupId);
        }

        public ODJob GetODJob(string userId, long jobId)
        {
            return OnGetODJob(userId, jobId);
        }

        public ODJobParamValue[] GetODJobParamValues(string userId, long paramId)
        {
            return OnGetODJobParamValues(userId, paramId);
        }

        public ODJobParamValue[] GetODJobParamValues(string userId, long paramId, ODJobParamValue[] associatedParamValues)
        {
            return OnGetODJobParamValues(userId, paramId, associatedParamValues);
        }

        public VZ.CFO.MDMFramework.Contracts.Data.MDUA.ODJobs.EspMessage TriggerODJob(string userId, ODJobTriggerRequest triggerRequest)
        {
            return OnTriggerODJob(userId, triggerRequest);
        }

        public Task<VZ.CFO.MDMFramework.Contracts.Data.MDUA.ODJobs.EspJobStatus> GetODJobStatus(string userId, long jobId)
        {
            return OnGetODJobStatus(userId, jobId);
        }

        public VZ.CFO.MDMFramework.Contracts.Data.MDUA.ODJobs.EspJobStatus GetODJobStatus(string userId, long jobId, long? generation)
        {
            return OnGetODJobStatus(userId, jobId, generation);
        }

        public EspJobStatus GetJobStatus(string jobName, string subApplName, string userId, long? generation)
        {
            return OnGetJobStatus(jobName, subApplName, userId, generation);
        }

        protected abstract ODJobGroup[] OnGetAllODJobGroups(string userId);
        protected abstract ODJob[] OnGetAllODJobs(string userId, long groupId);
        protected abstract ODJob OnGetODJob(string userId, long jobId);
        protected abstract ODJobParamValue[] OnGetODJobParamValues(string userId, long paramId);
        protected abstract ODJobParamValue[] OnGetODJobParamValues(string userId, long paramId, ODJobParamValue[] associatedParamValues);
        protected abstract VZ.CFO.MDMFramework.Contracts.Data.MDUA.ODJobs.EspMessage OnTriggerODJob(string userId, ODJobTriggerRequest triggerRequest);
        protected abstract Task<VZ.CFO.MDMFramework.Contracts.Data.MDUA.ODJobs.EspJobStatus> OnGetODJobStatus(string userId, long jobId);
        protected abstract VZ.CFO.MDMFramework.Contracts.Data.MDUA.ODJobs.EspJobStatus OnGetODJobStatus(string userId, long jobId, long? generation);
        protected abstract EspJobStatus OnGetJobStatus(string jobName, string subApplName, string userId, long? generation);

        
    }
}
