﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables;
using VZ.CFO.MDMFramework.Contracts.Service.MDUA;

namespace VZ.CFO.MDMFramework.Providers.Data
{
    public interface IFactTableManagerDataProvider : IFactTableManager
    {
        FactProcessUploadedFileResponse GetAuditData(string userId, FactAuditRequest auditRequest, FactTable factTable);
        string[] GetDimensionValues(string userId, FactAuditRequest auditRequest, FactTable factTable);
    }
}
