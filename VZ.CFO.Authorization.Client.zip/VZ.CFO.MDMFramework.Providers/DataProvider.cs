﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Common;
namespace VZ.CFO.MDMFramework.Providers
{
    public abstract class DataProvider
    {
        /// <summary>
        /// Initializes a new instance of the DataProvider class
        /// </summary>
        /// <param name="connectionString">The connection string.</param>
        protected DataProvider(string connectionString, string encryptionSalt)
        {
            this.EncryptionSalt = encryptionSalt;
            if (string.IsNullOrEmpty(connectionString) == false)
            {
                System.Data.Common.DbConnectionStringBuilder dbConnBuilder = new System.Data.Common.DbConnectionStringBuilder();
                dbConnBuilder.ConnectionString = connectionString;
                if (dbConnBuilder.ContainsKey("User Id"))
                {
                    dbConnBuilder["User Id"] = Utility.Decrypt(dbConnBuilder["User Id"].ToString(), encryptionSalt);
                }
                if (dbConnBuilder.ContainsKey("Password"))
                {
                    dbConnBuilder["Password"] = Utility.Decrypt(dbConnBuilder["Password"].ToString(), encryptionSalt);
                }
                this.ConnectionString = dbConnBuilder.ConnectionString;
            }
        }

        /// <summary>
        /// Initializes a new instance of the DataProvider class
        /// </summary>
        /// <param name="connectionString">The connection string.</param>
        protected DataProvider(string connectionString)
        {
            this.EncryptionSalt = string.Empty;
            this.ConnectionString = connectionString;
        }

        /// <summary>
        /// Gets the connection string.
        /// </summary>
        /// <value>
        /// The connection string.
        /// </value>
        protected string ConnectionString { get; private set; }

        /// <summary>
        /// 
        /// </summary>
        protected string EncryptionSalt { get; private set; }
    }
}
