﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Service;

namespace VZ.CFO.MDMFramework.Providers.Manager
{
    public class LogManager : ILogManager
    {
        private ILogManager logDataProvider = null;

        public LogManager(ILogManager logDataProvider)
        {
            this.logDataProvider = logDataProvider;
        }

        public void LogMessage(string module, string message)
        {
            logDataProvider.LogMessage(module, message);
        }

        public void LogException(string module, Exception ex)
        {
            logDataProvider.LogException(module, ex);
        }
    }
}
