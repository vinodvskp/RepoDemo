﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Service;
using VZ.CFO.MDMFramework.Contracts.Data.Security;
using System.Security.Cryptography;

namespace VZ.CFO.MDMFramework.Providers.Manager
{
    public class SecurityManager : ISecurityManager
    {
        private string encryptionSalt;
        public SecurityManager(string encryptionSalt)
        {
            this.encryptionSalt = encryptionSalt;
        }


        private static string SignData(RSAParameters privateKey, string data)
        {
            byte[] signedBytes;

            using(var rsa = new RSACryptoServiceProvider())
            {
                var encoder = new UTF8Encoding();
                byte[] orginalData = encoder.GetBytes(data);
                
                try
                {
                    rsa.ImportParameters(privateKey);
                    signedBytes = rsa.SignData(orginalData, CryptoConfig.MapNameToOID("SHA512"));
                }
                catch(CryptographicException e)
                {
                    return null;
                }
                finally
                {
                    rsa.PersistKeyInCsp = false;
                }
            }

            return Convert.ToBase64String(signedBytes);
        }

        private static bool VerifyData(string originalMessage, string signedMessage, RSAParameters publicKey)
        {
            bool success = false;
            using (var rsa = new RSACryptoServiceProvider())
            {
                //byte[] bytesToVerify = Convert.FromBase64String(originalMessage);
                var encoder = new UTF8Encoding();
                byte[] bytesToVerify = encoder.GetBytes(originalMessage);
                byte[] signedBytes = Convert.FromBase64String(signedMessage);

                try
                {
                    rsa.ImportParameters(publicKey);

                    SHA512Managed Hash = new SHA512Managed();

                    byte[] hashedData = Hash.ComputeHash(signedBytes);

                    success = rsa.VerifyData(bytesToVerify, CryptoConfig.MapNameToOID("SHA512"), signedBytes);
                }
                catch (CryptographicException e)
                {
                    success = false;
                }
                finally
                {
                    rsa.PersistKeyInCsp = false;
                }
            }
            return success;
        }

        public string GetSignedUrlKey(string userId, string content)
        {
            SignedUrlKey signedUrlKey = new SignedUrlKey() 
            {
                SignedForContent = content,
                SignedForUser = userId,
                ExpiresOn = DateTime.UtcNow.AddMinutes(60)
            };

            //serialise to json
            string serialized = Common.Utility.SerializeToJson(signedUrlKey);
            //encrypt
            string encryptedString = Common.Utility.Encrypt(serialized, encryptionSalt);
            //convert to base64
            string encryptedbase64String = Common.Utility.ConvertToBase64String(encryptedString);

            return encryptedbase64String;
        }

        public string VerifySignedUrlKey(string content, string signedUrl)
        {
            //bool isVerified = false;
            string verifiedUserId = string.Empty;

            try
            {
                //convert to encrypted
                string encrypted = Common.Utility.ConvertFromBase64String(signedUrl);
                //decrypt
                string serialized = Common.Utility.Decrypt(encrypted, encryptionSalt);
                //deserialize
                SignedUrlKey signedUrlKey = Common.Utility.DeserializeFromJson<SignedUrlKey>(serialized);
                //cannot check for userId here because, request for export will not contain authToken and so user Id cannot be verified.
                if (signedUrlKey != null && signedUrlKey.ExpiresOn > DateTime.UtcNow && signedUrlKey.SignedForContent == content) //&& signedUrlKey.SignedForUser == userId)
                {
                    //return the userId from signedKey if verification pass
                    verifiedUserId = signedUrlKey.SignedForUser;
                }
            }
            catch
            {
                //return empty user id
                verifiedUserId = string.Empty;
            }

            return verifiedUserId;
        }


        public string GetContentFromSignedUrl(string userId, string signedUrl)
        {
            string content = string.Empty;

            try
            {
                //convert to encrypted
                string encrypted = Common.Utility.ConvertFromBase64String(signedUrl);
                //decrypt
                string serialized = Common.Utility.Decrypt(encrypted, encryptionSalt);
                //deserialize
                SignedUrlKey signedUrlKey = Common.Utility.DeserializeFromJson<SignedUrlKey>(serialized);
                content = signedUrlKey.SignedForContent;
            }
            catch
            {
                //return empty user id
                content = string.Empty;
            }

            return content;
        }
    }
}
