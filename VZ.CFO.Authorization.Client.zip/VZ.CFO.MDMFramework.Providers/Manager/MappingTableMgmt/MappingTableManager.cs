﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Common;
using VZ.CFO.MDMFramework.Contracts.Data.MappingTableMgmt;

namespace VZ.CFO.MDMFramework.Providers.Manager
{
    public class MappingTableManager : Contracts.Service.MappingTableMgmt.IMappingTableManager
    {

        private VZ.CFO.MDMFramework.Providers.Data.IMappingTableDBManager mappingTableDBManager;
        private bool canAllowMigration = false;
        private static readonly string uniqueRowName = "urowid";

        private readonly MDMFramework.Providers.Data.IOpsStatusLogManager opsStatusDbManager;

        private readonly MDMFramework.Contracts.Service.MDUA.IODJobManager odJobManager;

        private readonly List<Contracts.Data.Config.MessageDictionary> messageDictionary = new List<Contracts.Data.Config.MessageDictionary>();

        private KnownValues.RoleType[] requiredSaveRoles = new KnownValues.RoleType[] { KnownValues.RoleType.EDIT };
        private KnownValues.RoleType[] requiredValidationRoles = new KnownValues.RoleType[] { KnownValues.RoleType.EDIT, KnownValues.RoleType.MIGRATE };
        private KnownValues.RoleType[] requiredMigrationRoles = new KnownValues.RoleType[] { KnownValues.RoleType.MIGRATE };

        public MappingTableManager(VZ.CFO.MDMFramework.Providers.Data.IMappingTableDBManager mappingTableDBManager, bool canAllowMigration, MDMFramework.Providers.Data.IOpsStatusLogManager opsStatusDbManager, MDMFramework.Contracts.Service.MDUA.IODJobManager odJobManager, Contracts.Data.Config.MessageDictionary[] messageDictionary)
        {
            if (mappingTableDBManager == null)
            {
                throw new ArgumentNullException("mappingTableDBManager");
            }
            this.mappingTableDBManager = mappingTableDBManager;
            this.canAllowMigration = canAllowMigration;
            this.opsStatusDbManager = opsStatusDbManager;
            this.odJobManager = odJobManager;
            if(messageDictionary != null)
            {
                this.messageDictionary.AddRange(messageDictionary);
            }
        }


        private bool hasAccess(KnownValues.RoleType[] userRoles, KnownValues.RoleType[] requiredRoles)
        {
            bool canAccess = false;
            canAccess = userRoles.Intersect(requiredRoles).Any();
            return canAccess;
        }

        public Contracts.Data.MappingTableMgmt.MappingTable[] GetAllMappingTables(string userId)
        {
            return mappingTableDBManager.GetAllMappingTables(userId);
        }

        public MappingTable GetMappingTableInfo(string userId, long mappingTableId)
        {
            return mappingTableDBManager.GetMappingTableInfo(userId, mappingTableId);
        }

        public Contracts.Data.MappingTableMgmt.MappingTableDataPage GetMappingTable(string userId, long mappingTableId, int pageNumber, int rowsPerPage, int totalRecords)
        {
            return mappingTableDBManager.GetMappingTable(userId, mappingTableId, pageNumber, rowsPerPage, totalRecords);
        }

        public MappingTable GetMappingTable(string userId, long id, int rowsPerPage)
        {
            return mappingTableDBManager.GetMappingTable(userId, id, rowsPerPage);
        }

        public Task<MappingTableDataPage> GetMappingTableFromLowerEnvAsync(string userId, long mappingTableId, int pageNumber, int rowsPerPage, int totalRecords)
        {
            return mappingTableDBManager.GetMappingTableFromLowerEnvAsync(userId, mappingTableId, pageNumber, rowsPerPage, totalRecords);
        }

        public MappingTableDataPage GetMappingTableFromLowerEnv(string userId, long mappingTableId, int pageNumber, int rowsPerPage, int totalRecords)
        {
            return mappingTableDBManager.GetMappingTableFromLowerEnv(userId, mappingTableId, pageNumber, rowsPerPage, totalRecords);
        }

        public MappingTableWriteResponse SaveMappingTableData(string userId, MappingTable mappingTable, MappingTableWriteRequest writeRequest)
        {
            throw new NotImplementedException();
        }

        public MappingTableWriteResponse ValidationMappingTableData(string userId, MappingTable mappingTable, MappingTableWriteRequest writeRequest)
        {
            throw new NotImplementedException();
        }

        public long StageMappingTableData(string userId, MappingTable mappingTable, MappingTableWriteRequest writeRequest)
        {
            if (string.IsNullOrEmpty(userId))
            {
                throw new ArgumentNullException("userid cannot be null");
            }

            if (mappingTable == null)
            {
                throw new ArgumentNullException("mappingTable cannot be null");
            }

            if (writeRequest == null)
            {
                throw new ArgumentNullException("writeRequest cannot be null");
            }

            if (writeRequest.MappingTableId == 0)
            {
                throw new ArgumentException("writeRequest.MappingTableId should be greater than 0");
            }

            //This check is not needed because user may try to validate data that was saved overriding validation
            //if ((writeRequest.AddRecords == null || writeRequest.AddRecords.Length == 0) &&
            //    (writeRequest.ModifiedRecords == null || writeRequest.ModifiedRecords.Length == 0) &&
            //    (writeRequest.DeletedRecords == null || writeRequest.DeletedRecords.Length == 0))
            //{
            //    throw new ArgumentException("At least row should be available for staging data");
            //}

            return mappingTableDBManager.StageMappingTableData(userId, mappingTable, writeRequest);
        }

        public MappingTableWriteResponse SaveMappingTableData(string userId, MappingTableWriteRequest writeRequest)
        {
            if (string.IsNullOrEmpty(userId))
            {
                throw new ArgumentNullException("userid cannot be null");
            }

            if (writeRequest == null)
            {
                throw new ArgumentNullException("writeRequest cannot be null");
            }

            if (writeRequest.MappingTableId == 0)
            {
                throw new ArgumentException("writeRequest.MappingTableId should be greater than 0");
            }

            //This check is not needed because user may try to validate data that was saved overriding validation
            //if ((writeRequest.AddRecords == null || writeRequest.AddRecords.Length == 0) &&
            //    (writeRequest.ModifiedRecords == null || writeRequest.ModifiedRecords.Length == 0) &&
            //    (writeRequest.DeletedRecords == null || writeRequest.DeletedRecords.Length == 0))
            //{
            //    throw new ArgumentException("At least row should be available for validation");
            //}

            MappingTableWriteResponse response = new MappingTableWriteResponse() { MappingTableId = writeRequest.MappingTableId };

            //Get Mapping Table Info
            MappingTable mappingTableInfo = mappingTableDBManager.GetMappingTableInfo(userId, writeRequest.MappingTableId);

            if (mappingTableInfo == null)
            {
                throw new MDMFrameworkException(ErrorConstants.KnownException, "Either mapping table does not exist or you dont have access");
            }

            if (hasAccess(mappingTableInfo.UserRoleType, requiredSaveRoles) == false)
            {
                throw new MDMFrameworkException(ErrorConstants.KnownException, "You dont have access to save");
            }

            if (writeRequest.IsForceSave == true && mappingTableInfo.CanSkipValidation == false)
            {
                response.MessageType = KnownValues.MappingTableWriteResponseMsgType.Error;
                response.Message = "Cannot skip validation for this mapping table";
                return response;
                //throw new MDMFrameworkException(ErrorConstants.KnownException, "Cannot skip validation for this mapping table");
            }

            //Start the process
            writeRequest.RunStatusId = opsStatusDbManager.StartProcess("MappingTable", mappingTableInfo.Name, "Stage", true, "Save", "UI", string.Empty);
            

            try
            {
                //Stage the data
                StageMappingTableData(userId, mappingTableInfo, writeRequest);
                
                //opsStatusDbManager.EndStep(writeRequest.RunStatusId);

                bool canSave = false;
                //Skip validation if save is forced
                if (writeRequest.IsForceSave)
                {
                    //If validation sproc is not called, then move the staged data to archive
                    mappingTableDBManager.ArchiveStageData(userId, writeRequest.RunStatusId);
                    canSave = true;
                }
                else
                {
                    //start validation step;
                    opsStatusDbManager.StartStep(writeRequest.RunStatusId, "validation", "save", string.Empty, string.Empty);

                    MappingTableWriteResponse validationResponse = mappingTableDBManager.ValidationMappingTableData(userId, mappingTableInfo, writeRequest);

                    string validationActionTextForAudit = "Validation for Save (Success)";

                    //Return validation results if validation failed.
                    if (validationResponse.ValidationResults != null && validationResponse.ValidationResults.Length > 0)
                    {
                        response.ValidationResults = validationResponse.ValidationResults;
                        validationActionTextForAudit = "Validation for Save (Failed)";
                    }
                    else
                    {
                        //proceed to save otherwise
                        canSave = true;
                    }
                    //end validation step 
                    opsStatusDbManager.EndStep(writeRequest.RunStatusId);

                    mappingTableDBManager.WriteMappingTableAuditLog(userId, mappingTableInfo.Id, validationActionTextForAudit, Convert.ToInt32(KnownValues.AuditType.TABLE), false);
                }

                //Save only if validation passed or if its forced
                if (canSave)
                {

                    MigrationDependencyCheckResult migrationCheckResult = null;
                    if(mappingTableInfo.MigrationDependencies.Length > 0)
                    {
                        //start migration check step
                        opsStatusDbManager.StartStep(writeRequest.RunStatusId, "Migration Check", "Start", string.Empty, string.Empty);
                        migrationCheckResult = CheckDependentODJobStatus(userId, mappingTableInfo.MigrationDependencies);
                        //end migration check step
                        opsStatusDbManager.EndStep(writeRequest.RunStatusId);
                    }

                    if (migrationCheckResult == null || migrationCheckResult.IsSuccess == true)
                    {
                        //start save step
                        opsStatusDbManager.StartStep(writeRequest.RunStatusId, "save", "save", string.Empty, string.Empty);

                        //TODO: Check for migration dependencies
                        MappingTableWriteResponse saveResponse = mappingTableDBManager.SaveMappingTableData(userId, mappingTableInfo, writeRequest);
                        response.RowsDeleted = saveResponse.RowsDeleted;
                        response.RowsMerged = saveResponse.RowsMerged;
                        response.MessageCode = saveResponse.MessageCode;
                        response.MessageType = saveResponse.MessageType;

                        if (saveResponse.MessageType == KnownValues.MappingTableWriteResponseMsgType.Success)
                        {
                            if (writeRequest.IsForceSave == false)
                            {
                                //update last validated fields on successful validation 
                                mappingTableDBManager.UpdateLastValidated(userId, mappingTableInfo.Id);
                            }

                            mappingTableDBManager.WriteMappingTableAuditLog(userId, mappingTableInfo.Id, "Save (Success)", Convert.ToInt32(KnownValues.AuditType.TABLE), writeRequest.IsForceSave);

                            //end save step
                            opsStatusDbManager.EndStep(writeRequest.RunStatusId);

                            //end Save Process
                            opsStatusDbManager.EndProcess(writeRequest.RunStatusId, "Save completed successfully");
                        }
                        else
                        {
                            var m = messageDictionary.FirstOrDefault(md => md.MessageCode == response.MessageCode);
                            if (m == null)
                            {
                                throw new MDMFrameworkException("Unknown Oracle Error on save" + Convert.ToString(response.MessageCode));
                            }
                            else
                            {
                                response.Message = m.Message;
                                opsStatusDbManager.EndProcess(writeRequest.RunStatusId, string.Format("Save fail - {0} - {1}", m.MessageCode, m.Message));
                            }
                        }
                    }
                    else
                    {
                        response.MessageType = KnownValues.MappingTableWriteResponseMsgType.Error;
                        response.Message = "One or more migration dependencies are running";
                        opsStatusDbManager.EndProcess(writeRequest.RunStatusId, "Save fail - migration dep chk failed");
                    }
                }

                
            }
            catch
            {
                opsStatusDbManager.EndProcess(writeRequest.RunStatusId, "Save failed");
                throw;
            }
            return response;
        }

        public MappingTableWriteResponse ValidationMappingTableData(string userId, MappingTableWriteRequest writeRequest)
        {
            if (string.IsNullOrEmpty(userId))
            {
                throw new ArgumentNullException("userid cannot be null");
            }

            if (writeRequest == null)
            {
                throw new ArgumentNullException("writeRequest cannot be null");
            }

            if (writeRequest.MappingTableId == 0)
            {
                throw new ArgumentException("writeRequest.MappingTableId should be greater than 0");
            }

            if (writeRequest.RequestType == KnownValues.RequestType.None)
            {
                throw new InvalidOperationException("Request Type cannot be none");
            }

            //This check is not needed because user may try to validate data that was saved overriding validation
            //if ((writeRequest.AddRecords == null || writeRequest.AddRecords.Length == 0) &&
            //    (writeRequest.ModifiedRecords == null || writeRequest.ModifiedRecords.Length == 0) &&
            //    (writeRequest.DeletedRecords == null || writeRequest.DeletedRecords.Length == 0))
            //{
            //    throw new ArgumentException("At least row should be available for validation");
            //}

            //Get Mapping Table Info
            MappingTable mappingTableInfo = mappingTableDBManager.GetMappingTableInfo(userId, writeRequest.MappingTableId);

            if (mappingTableInfo == null)
            {
                throw new MDMFrameworkException("Either mapping table does not exist or you dont have access");
            }

            MappingTableWriteResponse writeResponse = null;

            if (writeRequest.RequestType == KnownValues.RequestType.EDIT)
            {
                if (hasAccess(mappingTableInfo.UserRoleType, requiredSaveRoles))
                {
                    //Start process
                    writeRequest.RunStatusId = opsStatusDbManager.StartProcess("Mapping Table", mappingTableInfo.Name, "Stage", true, "Valdiation", string.Empty, string.Empty);
                    try
                    {
                        //Stage the data in edit mode
                        StageMappingTableData(userId, mappingTableInfo, writeRequest);

                        //end stage step
                        opsStatusDbManager.EndStep(writeRequest.RunStatusId);

                        //Start validation step
                        opsStatusDbManager.StartStep(writeRequest.RunStatusId, "Validation", "Edit", string.Empty, string.Empty);

                        writeResponse = mappingTableDBManager.ValidationMappingTableData(userId, mappingTableInfo, writeRequest);

                        string validationActionTextForAudit = "Validation for Edit Mode (Success)";
                        if (writeResponse.ValidationResults != null && writeResponse.ValidationResults.Length > 0)
                        {
                            validationActionTextForAudit = "Validation for Edit Mode (Failure)";
                        }
                        else
                        {
                            //update last validated fields on successful validation 
                            mappingTableDBManager.UpdateLastValidated(userId, mappingTableInfo.Id);
                        }
                        mappingTableDBManager.WriteMappingTableAuditLog(userId, mappingTableInfo.Id, validationActionTextForAudit, Convert.ToInt32(KnownValues.AuditType.TABLE), false);

                        //End Validation step
                        opsStatusDbManager.EndStep(writeRequest.RunStatusId);

                        //End Process
                        opsStatusDbManager.EndProcess(writeRequest.RunStatusId, "Validation success");
                    }
                    catch
                    {
                        //End Process
                        opsStatusDbManager.EndProcess(writeRequest.RunStatusId, "Validation failed");
                        throw;
                    }
                    
                }
                else
                {
                    throw new MDMFrameworkException(ErrorConstants.KnownException, "You should have edit access to this mapping table to validate in non migration environment.");
                }
            }
            else
            {

                if (hasAccess(mappingTableInfo.UserRoleType, requiredMigrationRoles))
                {
                    //Start process
                    writeRequest.RunStatusId = opsStatusDbManager.StartProcess("Mapping Table", mappingTableInfo.Name, "Stage", true, "Validation", string.Empty, string.Empty);

                    try
                    {
                        //Stage the data in migration mode
                        mappingTableDBManager.StageFromChangeControl(userId, mappingTableInfo, writeRequest);
                        //end stage step
                        opsStatusDbManager.EndStep(writeRequest.RunStatusId);

                        //Start validation step
                        opsStatusDbManager.StartStep(writeRequest.RunStatusId, "Validation", "Migrate", string.Empty, string.Empty);

                        writeResponse = mappingTableDBManager.ValidateMappingTableMigrationData(userId, mappingTableInfo, writeRequest.RunStatusId);

                        string validationActionTextForAudit = "Validation for Migrate Mode (Success)";
                        if (writeResponse.ValidationResults != null && writeResponse.ValidationResults.Length > 0)
                        {
                            validationActionTextForAudit = "Validation for Migrate Mode (Failure)";
                        }
                        else
                        {
                            //update last validated fields on successful validation 
                            mappingTableDBManager.UpdateLastValidated(userId, mappingTableInfo.Id);
                        }
                        mappingTableDBManager.WriteMappingTableAuditLog(userId, mappingTableInfo.Id, validationActionTextForAudit, Convert.ToInt32(KnownValues.AuditType.TABLE), false);

                        //End Validation step
                        opsStatusDbManager.EndStep(writeRequest.RunStatusId);

                        //End Process
                        opsStatusDbManager.EndProcess(writeRequest.RunStatusId, "Validation Success");
                    }
                    catch
                    {
                        opsStatusDbManager.EndProcess(writeRequest.RunStatusId, "Validation Failed");
                        throw;
                    }

                    
                }
                else
                {
                    throw new MDMFrameworkException("You should have migrate access to this mapping table to validate in migration environment.");
                }
            }

            //Validate
            return writeResponse;
        }

        public Contracts.Data.MappingTableMgmt.AuditLogPage GetAuditDataPage(string userId, long mappingTableId, Contracts.Data.MappingTableMgmt.KnownValues.AuditType auditType, int pageNumber, int rowsPerPage, int totalRecords, string searchKey)
        {
            return mappingTableDBManager.GetAuditDataPage(userId, mappingTableId, auditType, pageNumber, rowsPerPage, totalRecords, searchKey);
        }

        public AuditLogPage GetAuditData(string userId, long mappingTableId, Contracts.Data.MappingTableMgmt.KnownValues.AuditType auditType, int rowsPerPage, string searchKey)
        {
            return mappingTableDBManager.GetAuditData(userId, mappingTableId, auditType, rowsPerPage, searchKey);
        }

        public MappingTableWriteResponse MigrateMappingValues(string userId, Contracts.Data.MappingTableMgmt.MappingTableWriteRequest writeRequest)
        {
            if (string.IsNullOrEmpty(userId))
            {
                throw new ArgumentNullException("userid cannot be null");
            }

            if (canAllowMigration == false)
            {
                throw new InvalidOperationException("Mapping table migration is not allowed on this environment");
            }

            if (writeRequest == null)
            {
                throw new ArgumentException("writeRequest");
            }

            MappingTableWriteResponse response = new MappingTableWriteResponse() { MappingTableId = writeRequest.MappingTableId };

            //Get Mapping Table Info
            MappingTable mappingTableInfo = mappingTableDBManager.GetMappingTableInfo(userId, writeRequest.MappingTableId);

            if (mappingTableInfo == null)
            {
                throw new MDMFrameworkException(ErrorConstants.KnownException, "Either mapping table does not exist or you dont have access");
            }

            if (hasAccess(mappingTableInfo.UserRoleType, requiredMigrationRoles) == false)
            {
                throw new MDMFrameworkException(ErrorConstants.KnownException, "You dont have access to migrate");
            }

            if (writeRequest.IsForceSave == true && mappingTableInfo.CanSkipValidation == false)
            {
                response.MessageType = KnownValues.MappingTableWriteResponseMsgType.Error;
                response.Message = "Cannot skip validation for this mapping table";
                //throw new MDMFrameworkException(ErrorConstants.KnownException, "Cannot skip validation for this mapping table");
            }

            //Start Process
            writeRequest.RunStatusId = opsStatusDbManager.StartProcess("Mapping Table", string.Empty, "Stage", true, "Migration", string.Empty, string.Empty);

            try
            {
                //Stage data from change control mapping table to migration environment
                mappingTableDBManager.StageFromChangeControl(userId, mappingTableInfo, writeRequest);

                //opsStatusDbManager.EndStep(writeRequest.RunStatusId);

                bool canMigrate = false;

                if (writeRequest.IsForceSave == true)
                {
                    mappingTableDBManager.ArchiveStageData(userId, writeRequest.RunStatusId);
                    canMigrate = true;
                }
                else
                {
                    //Start validation step
                    opsStatusDbManager.StartStep(writeRequest.RunStatusId, "Validation", "Migration", string.Empty, string.Empty);

                    MappingTableWriteResponse validationResponse = mappingTableDBManager.ValidateMappingTableMigrationData(userId, mappingTableInfo, writeRequest.RunStatusId);

                    string validationActionTextForAudit = "Validation for Migration (Success)";

                    //Return validation results if validation failed.
                    if (validationResponse.ValidationResults != null && validationResponse.ValidationResults.Length > 0)
                    {
                        response.ValidationResults = validationResponse.ValidationResults;
                        validationActionTextForAudit = "Validation for Migration (Failed)";
                    }
                    else
                    {
                        //proceed to migrate otherwise
                        canMigrate = true;
                    }

                    //End validation step
                    opsStatusDbManager.EndStep(writeRequest.RunStatusId);
                    mappingTableDBManager.WriteMappingTableAuditLog(userId, mappingTableInfo.Id, validationActionTextForAudit, Convert.ToInt32(KnownValues.AuditType.TABLE), false);
                }

                //Save only if validation passed or if its forced
                if (canMigrate)
                {
                    MigrationDependencyCheckResult migrationCheckResult = null;
                    if (mappingTableInfo.MigrationDependencies.Length > 0)
                    {
                        //start migration check step
                        opsStatusDbManager.StartStep(writeRequest.RunStatusId, "Migration Check", "Start", string.Empty, string.Empty);
                        migrationCheckResult = CheckDependentODJobStatus(userId, mappingTableInfo.MigrationDependencies);
                        //end migration check step
                        opsStatusDbManager.EndStep(writeRequest.RunStatusId);
                    }

                    if (migrationCheckResult == null || migrationCheckResult.IsSuccess == true)
                    {
                        //Start migration step
                        opsStatusDbManager.StartStep(writeRequest.RunStatusId, "Migrate", "Migrate", string.Empty, string.Empty);

                        //TODO: Check for migration dependencies
                        MappingTableWriteResponse mergeResponse = mappingTableDBManager.MigrateMappingTableData(userId, mappingTableInfo, writeRequest);
                        response.RowsMerged = mergeResponse.RowsMerged;
                        response.MessageCode = mergeResponse.MessageCode;
                        response.MessageType = mergeResponse.MessageType;

                        if (mergeResponse.MessageType == KnownValues.MappingTableWriteResponseMsgType.Success)
                        {
                            if (writeRequest.IsForceSave == false)
                            {
                                //update last validated fields on successful validation 
                                mappingTableDBManager.UpdateLastValidated(userId, mappingTableInfo.Id);
                            }

                            mappingTableDBManager.WriteMappingTableAuditLog(userId, mappingTableInfo.Id, "Migration (Success)", Convert.ToInt32(KnownValues.AuditType.TABLE), writeRequest.IsForceSave);

                            //Stop migration step
                            opsStatusDbManager.EndStep(writeRequest.RunStatusId);
                            opsStatusDbManager.EndProcess(writeRequest.RunStatusId, "Migration Success");
                        }
                        else
                        {
                            var m = messageDictionary.FirstOrDefault(md => md.MessageCode == response.MessageCode);
                            if (m == null)
                            {
                                throw new MDMFrameworkException("Unknown Oracle Error on migrate" + Convert.ToString(response.MessageCode));
                            }
                            else
                            {
                                response.Message = m.Message;
                                opsStatusDbManager.EndProcess(writeRequest.RunStatusId, string.Format("Migrate fail - {0} - {1}", m.MessageCode, m.Message));
                            }
                        }
                        
                    }
                    else
                    {
                        response.MessageType = KnownValues.MappingTableWriteResponseMsgType.Error;
                        response.Message = "One or more migration dependencies are running.";
                        opsStatusDbManager.EndProcess(writeRequest.RunStatusId, "Migrate fail - migration dep chk failed");
                    }
                }

            }
            catch
            {
                opsStatusDbManager.EndProcess(writeRequest.RunStatusId, "Migration failed");
                throw;
            }
            return response;
        }

        public async Task<string> ExportMappingTable(string userId, long mappingTableId)
        {
            string fileAsBase64String = string.Empty;

            //Get the mapping Table info
            var mappingTable = mappingTableDBManager.GetMappingTableInfo(userId, mappingTableId);

            if (mappingTable == null)
            {
                throw new MDMFrameworkException(ErrorConstants.KnownException, "Mapping Table does not exists or you do not have access.");
            }

            //Get the first page of the table
            MappingTable firstPage = GetMappingTable(userId, mappingTableId, 10);
            if (firstPage == null)
            {
                throw new MDMFrameworkException(ErrorConstants.KnownException, "Error getting data for mapping table");
            }

            //Collection to hold tasks to retreive page data
            List<Task<MappingTableDataPage>> remainingPagesTasks = new List<Task<MappingTableDataPage>>();
            List<MappingTableDataPage> remainingPages = new List<MappingTableDataPage>();

            //Add tasks to retreive page data
            for (int pageIndex = 2; pageIndex <= firstPage.PagingInfo.TotalPages; pageIndex++)
            {
                remainingPagesTasks.Add(GetMappingTableAsync(userId, mappingTableId, pageIndex, 10, firstPage.PagingInfo.TotalResults));
            }

            //Parallelly fetch data for all pages
            while (remainingPagesTasks.Count > 0)
            {
                Task<MappingTableDataPage> firstFinishedTask = await Task.WhenAny(remainingPagesTasks);
                remainingPagesTasks.Remove(firstFinishedTask);

                MappingTableDataPage completedPage = await firstFinishedTask;
                remainingPages.Add(completedPage);
            }

            //Collection to hold the merged data
            Dictionary<int, List<string>> mergedColumnData = new Dictionary<int, List<string>>();

            //Initialize the string list in the dictionary using the data in the first page
            for (int colIndex = 0; colIndex < mappingTable.Columns.Length; colIndex++)
            {
                List<string> colData = new List<string>();
                colData.AddRange(firstPage.PagingInfo.Result[colIndex].Data);
                mergedColumnData.Add(colIndex, colData);
            }

            //merge the column data from all other pages
            for (int pageNumber = 2; pageNumber <= firstPage.PagingInfo.TotalPages; pageNumber++)
            {
                var pageToMerge = remainingPages.FirstOrDefault(p => p.PageNumber == pageNumber);
                for (int colIndex = 0; colIndex < mappingTable.Columns.Length; colIndex++)
                {
                    mergedColumnData[colIndex].AddRange(pageToMerge.Result[colIndex].Data);
                }
            }

            //Reconcile merged data into the firstpage object
            for (int colIndex = 0; colIndex < mappingTable.Columns.Length; colIndex++)
            {
                firstPage.PagingInfo.Result[colIndex].Data = mergedColumnData[colIndex].ToArray();
            }

            //generate a temp file in the system's temp location
            var fileName = System.IO.Path.GetTempFileName();
            //Write it to mapping file
            if (WriteMappingDataToCsv(fileName, "sample", mappingTable.Columns, firstPage.PagingInfo.Result))
            {
                //Convert the temp file to binary
                byte[] csvBinary = File.ReadAllBytes(fileName);
                //convert binary to base64 string
                fileAsBase64String = Convert.ToBase64String(csvBinary);
            }

            //return csv file as base64 string
            return fileAsBase64String;
        }

        public static bool WriteMappingDataToCsv(string filename, string sheetName, string[] columnHeaders, MappingColumnValues[] columnData)
        {
            bool returnValue = false;
            try
            {
                using (StreamWriter writer = new StreamWriter(filename))
                {
                    writer.WriteLine(string.Join(",", Array.FindAll(columnHeaders, c => c != uniqueRowName)));

                    for (int rowIndex = 0; rowIndex < columnData[0].Data.Length; rowIndex++)
                    {
                        List<string> rowStringArray = new List<string>();
                        for (int colIndex = 1; colIndex < columnData.Length; colIndex++)
                        {
                            rowStringArray.Add(string.Format("\"{0}\"", columnData[colIndex].Data[rowIndex]));
                        }
                        writer.WriteLine(string.Join(",", rowStringArray.ToArray()));
                    }

                    writer.Dispose();
                }

                returnValue = true;
            }
            catch
            {
                //TODO: Handle exception
                returnValue = false;
            }
            return returnValue;
        }

        public async Task<MappingTableDataPage> GetMappingTableAsync(string userId, long mappingTableId, int pageNumber, int rowsPerPage, int totalRecords)
        {
            return await mappingTableDBManager.GetMappingTableAsync(userId, mappingTableId, pageNumber, rowsPerPage, totalRecords);
        }

        public MappingTable GetMappingTableFromLowerEnv(string userId, long id, int rowsPerPage)
        {
            return mappingTableDBManager.GetMappingTableFromLowerEnv(userId, id, rowsPerPage);
        }

        private MigrationDependencyCheckResult CheckDependentODJobStatus(string userId, MigrationDependency[] migrationDependencies)
        {

            List<MigrationDependency> migrationDependencyList = new List<MigrationDependency>();
            migrationDependencyList.AddRange(migrationDependencies);

            MigrationDependencyCheckResult checkResult = null;

            List<Contracts.Data.MDUA.ODJobs.EspJobStatus> jobStatusList = new List<Contracts.Data.MDUA.ODJobs.EspJobStatus>();

            ParallelLoopResult result = Parallel.ForEach(migrationDependencyList, d =>
            {
                if (d.Type == Contracts.Data.MappingTableMgmt.KnownValues.MigrationDependencyType.ESPX)
                {
                    Contracts.Data.MDUA.ODJobs.EspJobStatus jobStatus = odJobManager.GetJobStatus(d.Parameters, d.ConnectionParameters, userId, 0);
                    if (jobStatus != null)
                    {
                        lock (jobStatusList)
                        {
                            jobStatusList.Add(jobStatus);
                        }
                    }
                }
            });

            if (result.IsCompleted == false)
            {
                return null;
            }

            bool isSuccess = true;
            List<string> messageList = new List<string>();
            foreach(Contracts.Data.MDUA.ODJobs.EspJobStatus s in jobStatusList)
            {
                if (s.Status != Contracts.Data.MDUA.EspJobStatusState.AppNotDefined && s.Status != Contracts.Data.MDUA.EspJobStatusState.NoMatchingAppOrUnAuthorized
                    && s.Status != Contracts.Data.MDUA.EspJobStatusState.Completed)
                {
                    isSuccess = false;
                    if(string.IsNullOrEmpty(s.InCompleteJobs) == false)
                    {
                        messageList.Add(s.InCompleteJobs);
                    }
                }
            }
            checkResult = new MigrationDependencyCheckResult();
            checkResult.IsSuccess = isSuccess;
            checkResult.Message = string.Join(", ", messageList);

            return checkResult;
        }

        private class MigrationDependencyCheckResult
        {
            public string  Message { get; set; }
            public bool IsSuccess { get; set; }
        }
    }
}
