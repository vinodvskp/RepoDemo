﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Common;
using VZ.CFO.MDMFramework.Contracts.Data;
using VZ.CFO.MDMFramework.Contracts.Data.Reporting;
using VZ.CFO.MDMFramework.Contracts.Service.Reporting;
using VZ.CFO.MDMFramework.Providers.Data;

namespace VZ.CFO.MDMFramework.Providers.Manager.Reporting
{
    public class ReportingManager : IReportingManager
    {
        private IReportingDataProvider reportingDataProvider;

        public ReportingManager(IReportingDataProvider reportingDataProvider)
        {
            this.reportingDataProvider = reportingDataProvider;
        }

        public Contracts.Data.Reporting.Report GetReport(string userId, long reportId)
        {
            return reportingDataProvider.GetReport(userId, reportId);
        }

        public async Task<Contracts.Data.Reporting.ReportingResponse> GetReportDataAsync(string userId, long reportId)
        {
            return await reportingDataProvider.GetReportDataAsync(userId, reportId);
        }

        public async Task<Contracts.Data.Reporting.ReportingResponse> GetReportDataAsync(string userId, long reportId, int pageNumber, int rowsPerPage, int totalRecords)
        {
            return await reportingDataProvider.GetReportDataAsync(userId, reportId, pageNumber, rowsPerPage, totalRecords);
        }

        public Contracts.Data.Reporting.ReportGroup[] GetReports(string userId)
        {
            return reportingDataProvider.GetReports(userId);
        }

        public Contracts.Data.Reporting.ReportGroup GetReportsByGroupId(string userId, long groupId)
        {
            return reportingDataProvider.GetReportsByGroupId(userId, groupId);
        }


        public async Task<string> ExportReport(string userId, long reportId)
        {
            string fileAsBase64String = string.Empty;

            //Get the report info
            var reportInfo = reportingDataProvider.GetReport(userId, reportId);

            if (reportInfo == null)
            {
                throw new MDMFrameworkException(ErrorConstants.KnownException, "Report does not exists or you do not have access.");
            }

            //Get the first page of the table
            ReportingResponse firstPage = await GetReportDataAsync(userId, reportId, 1, 2500, 0);
            if (firstPage == null)
            {
                throw new MDMFrameworkException(ErrorConstants.KnownException, "Error getting first page data for report");
            }

            //Collection to hold tasks to retreive page data
            List<Task<ReportingResponse>> remainingPagesTasks = new List<Task<ReportingResponse>>();
            List<ReportingResponse> remainingPages = new List<ReportingResponse>();

            //Add tasks to retreive page data
            for (int pageIndex = 2; pageIndex <= firstPage.ReportingData.TotalPages; pageIndex++)
            {
                remainingPagesTasks.Add(GetReportDataAsync(userId, reportId, pageIndex, 2500, firstPage.ReportingData.TotalRows));
            }

            //Parallelly fetch data for all pages
            while (remainingPagesTasks.Count > 0)
            {
                Task<ReportingResponse> firstFinishedTask = await Task.WhenAny(remainingPagesTasks);
                remainingPagesTasks.Remove(firstFinishedTask);

                ReportingResponse completedPage = await firstFinishedTask;
                remainingPages.Add(completedPage);
            }

            //Collection to hold the merged data
            Dictionary<int, List<string>> mergedColumnData = new Dictionary<int, List<string>>();

            //Initialize the string list in the dictionary using the data in the first page
            for (int colIndex = 0; colIndex < reportInfo.Columns.Length; colIndex++)
            {
                List<string> colData = new List<string>();
                colData.AddRange(firstPage.ReportingData.Data[colIndex].Values);
                mergedColumnData.Add(colIndex, colData);
            }

            //merge the column data from all other pages
            for (int pageNumber = 2; pageNumber <= firstPage.ReportingData.TotalPages; pageNumber++)
            {
                var pageToMerge = remainingPages.FirstOrDefault(p => p.ReportingData.PageNumber == pageNumber);
                for (int colIndex = 0; colIndex < reportInfo.Columns.Length; colIndex++)
                {
                    mergedColumnData[colIndex].AddRange(pageToMerge.ReportingData.Data[colIndex].Values);                    
                }
            }

            //Reconcile merged data into the firstpage object
            for (int colIndex = 0; colIndex < reportInfo.Columns.Length; colIndex++)
            {
                firstPage.ReportingData.Data[colIndex].Values = mergedColumnData[colIndex].ToArray();
            }

            //generate a temp file in the system's temp location
            var fileName = System.IO.Path.GetTempFileName();
            //Write it to mapping file
            if (WriteMappingDataToCsv(fileName, "sample", reportInfo.Columns, firstPage.ReportingData.Data))
            {
                //Convert the temp file to binary
                byte[] csvBinary = File.ReadAllBytes(fileName);
                //convert binary to base64 string
                fileAsBase64String = Convert.ToBase64String(csvBinary);
            }

            //return csv file as base64 string
            return fileAsBase64String;
        }

        private static bool WriteMappingDataToCsv(string filename, string sheetName, ReportField[] columnHeaders, ColumnData[] columnData)
        {
            bool returnValue = false;
            try
            {

                List<string> columnHeaderNameList = new List<string>();
                foreach (var columnHeader in columnHeaders)
                {
                    columnHeaderNameList.Add(columnHeader.DisplayName);
                }

                using (StreamWriter writer = new StreamWriter(filename))
                {
                    writer.WriteLine(string.Join(",", columnHeaderNameList.ToArray()));

                    for (int rowIndex = 0; rowIndex < columnData[0].Values.Length; rowIndex++)
                    {
                        List<string> rowStringArray = new List<string>();
                        for (int colIndex = 0; colIndex < columnData.Length; colIndex++)
                        {
                            rowStringArray.Add(string.Format("\"{0}\"", columnData[colIndex].Values[rowIndex]));
                        }
                        writer.WriteLine(string.Join(",", rowStringArray.ToArray()));
                    }

                    writer.Dispose();
                }

                returnValue = true;
            }
            catch
            {
                //TODO: Handle exception
                returnValue = false;
            }
            return returnValue;
        }
    }
}
