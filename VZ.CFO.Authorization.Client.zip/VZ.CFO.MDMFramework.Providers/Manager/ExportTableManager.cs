﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Service;
using VZ.CFO.MDMFramework.Contracts.Data;
namespace VZ.CFO.MDMFramework.Providers.Manager
{
    public class ExportTableManager : IExportTableManager
    {
        private IExportTableManager dbExportTableManagerDataProvider = null;
        public ExportTableManager(IExportTableManager dbExportTableManagerDataProvider) {
            this.dbExportTableManagerDataProvider = dbExportTableManagerDataProvider;
        }
        public async Task<string> ExportTable(string userId, TableInfo tableInfo)
        {
            return await dbExportTableManagerDataProvider.ExportTable(userId, tableInfo);
        }
        public string GetSignedUrlKey(string userId, string content)
        {
            return dbExportTableManagerDataProvider.GetSignedUrlKey(userId, content);
        }
        public string VerifySignedUrlKey(string content, string signedUrl)
        {
            return dbExportTableManagerDataProvider.VerifySignedUrlKey(content, signedUrl);
        }
    }
}
