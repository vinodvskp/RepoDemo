﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA.ODJobs;
using VZ.CFO.MDMFramework.Contracts.Service.MDUA;
namespace VZ.CFO.MDMFramework.Providers.Manager.MDUA
{
    public class ODJobsManager : IODJobManager
    {
        private IODJobManager odJobManagerDataProvider = null;
        private Contracts.Data.Config.ESPJobConfig espJobConfig;
        
        public ODJobsManager(IODJobManager odJobManagerDataProvider, Contracts.Data.Config.ESPJobConfig espJobConfig, MDMFramework.Providers.Data.IOpsStatusLogManager opsStatusDbManager)
        {
            this.odJobManagerDataProvider = odJobManagerDataProvider;
            this.espJobConfig = espJobConfig;
           
        }
        public ODJobGroup[] GetAllODJobGroups(string userId)
        {
            return odJobManagerDataProvider.GetAllODJobGroups(userId);
        }
        public ODJob[] GetAllODJobs(string userId, long groupId)
        {
            return odJobManagerDataProvider.GetAllODJobs(userId, groupId);
        }

        public ODJob GetODJob(string userId, long jobId)
        {
            return odJobManagerDataProvider.GetODJob(userId, jobId);
        }

        public ODJobParamValue[] GetODJobParamValues(string userId, long paramId)
        {
            return odJobManagerDataProvider.GetODJobParamValues(userId, paramId);
        }

        public ODJobParamValue[] GetODJobParamValues(string userId, long paramId, ODJobParamValue[] associatedParamValues)
        {
            return odJobManagerDataProvider.GetODJobParamValues(userId, paramId, associatedParamValues);
        }

        public VZ.CFO.MDMFramework.Contracts.Data.MDUA.ODJobs.EspMessage TriggerODJob(string userId, ODJobTriggerRequest triggerRequest)
        {
            return odJobManagerDataProvider.TriggerODJob(userId, triggerRequest);
        }

        public Task<VZ.CFO.MDMFramework.Contracts.Data.MDUA.ODJobs.EspJobStatus> GetODJobStatus(string userId, long jobId)
        {
            return odJobManagerDataProvider.GetODJobStatus(userId, jobId);
        }

        public VZ.CFO.MDMFramework.Contracts.Data.MDUA.ODJobs.EspJobStatus GetODJobStatus(string userId, long jobId, long? generation)
        {
            return odJobManagerDataProvider.GetODJobStatus(userId, jobId, generation);
        }


        public EspJobStatus GetJobStatus(string jobName, string subApplName, string userId, long? generation)
        {
            return odJobManagerDataProvider.GetJobStatus(jobName, subApplName, userId, generation);
        }
    }
}
