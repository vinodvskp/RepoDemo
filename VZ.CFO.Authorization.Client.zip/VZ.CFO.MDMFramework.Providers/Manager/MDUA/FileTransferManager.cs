﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Configuration;
using VZ.CFO.MDMFramework.Contracts.Data.Config;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA.FileTransfer;
using VZ.CFO.MDMFramework.Contracts.Service.MDUA;
using VZ.CFO.MDMFramework.Providers.Data;
using VZ.CFO.MDMFramework.Common;
using WinSCP;

namespace VZ.CFO.MDMFramework.Providers.Manager.MDUA
{
    public class FileTransferManager : IFileTransferManager
    {
        private const string UPLOAD_LIMIT = "file size is too big, the upload limit is {0}MB";
        private const string DOWNLOAD_LIMIT = "file size is too big, the download limit is {0}GB";

        private IFileTransferManager dbFileTransferDataProvider = null;
        private FTProfile[] ftProfileList = null;
        private string archiveFileLocation = string.Empty;
        private IOpsStatusLogManager opsLogManager = null;
        private string[] allowedFileTypes = null;
        private static string phase = "doog si elibom-t";
        private static string TZ = ConfigurationManager.AppSettings["EspTimezone"].ToString();

        Func<RemoteFileInfo, FileTransferFileInfo> convert = remote => new FileTransferFileInfo
        {
            FileType = remote.FileType,
            Name = remote.Name,
            FullName = remote.FullName,
            Path = remote.FullName.Encrypt(phase),
            IsDirectory = remote.IsDirectory,
            LastModifiedTime = remote.LastWriteTime.ToEasternTime().ToString("MM/dd/yyyy HH:mm tt", System.Globalization.CultureInfo.InvariantCulture),
            Length = remote.Length,
            TimeZone = TZ,
            Files = remote.IsDirectory ? new List<FileTransferFileInfo>() : null
        };

        public FileTransferManager(IFileTransferManager dbFileTransferDataProvider, FTProfile[] ftProfiles, string archiveFileLocation, IOpsStatusLogManager opsLogManager, string allowedFileTypes)
        {
            this.dbFileTransferDataProvider = dbFileTransferDataProvider;
            this.ftProfileList = ftProfiles;
            this.archiveFileLocation = archiveFileLocation;
            this.opsLogManager = opsLogManager;
            this.allowedFileTypes = allowedFileTypes.Split(',');
        }


        public Contracts.Data.MDUA.FileTransfer.FileTransferProfile[] GetFileTransferProfiles(string userId)
        {
            return dbFileTransferDataProvider.GetFileTransferProfiles(userId);
        }

        public Contracts.Data.MDUA.FileTransfer.FileTransferResponse TransferFile(FileTransferRequest fileTransferRequest)
        {
            FileTransferResponse response = new FileTransferResponse() { ActionStatus = true };

            if (fileTransferRequest == null)
            {
                throw new ArgumentNullException("fileTransferRequest cannot be null");
            }

            if (fileTransferRequest.RequestType == FileTransferKnownValues.FileTransferRequestType.Upload && fileTransferRequest.File == null)
            {
                throw new ArgumentNullException("fileTransferRequest.File cannot be null");
            }

            if (fileTransferRequest.ProfileId == 0)
            {
                throw new ArgumentNullException("fileTransferRequest.ProfileId cannot be 0");
            }

            if (fileTransferRequest.RequestType == FileTransferKnownValues.FileTransferRequestType.Upload && string.IsNullOrEmpty(fileTransferRequest.FileName))
            {
                throw new ArgumentNullException("fileTransferRequest.FileName cannot be null");
            }

            var fileTransferProfile = dbFileTransferDataProvider.GetFileTransferProfile(fileTransferRequest.UserId, fileTransferRequest.ProfileId);

            if (fileTransferProfile == null)
            {
                response.MessageType = FileTransferKnownValues.MessageTypes.Error;
                response.Message = "Either the profile is not available or you don't have access to perform this operation";
                return response;
            }

            var ftProfile = ftProfileList.FirstOrDefault(p => p.ProfileName == fileTransferProfile.ProfileName);

            if (ftProfile == null)
            {
                throw new Exception("ftprofile not found");
            }

            SessionOptions sessionOptions = new SessionOptions()
            {
                Protocol = Protocol.Sftp,
                HostName = ftProfile.HostName,
                UserName = ftProfile.UserName,
                SshHostKeyFingerprint = ftProfile.SshHostKeyFingerprint,
                SshPrivateKeyPath = ftProfile.SshPrivateKeyPath
            };


            switch (fileTransferRequest.RequestType)
            {
                case FileTransferKnownValues.FileTransferRequestType.Upload:
                    
                    string filename = string.Format(@"{0}\{1}", archiveFileLocation, string.IsNullOrEmpty(fileTransferProfile.DefaultFileName) ? fileTransferRequest.FileName : fileTransferProfile.DefaultFileName);
                    filename = Common.Utility.SanitizeFilePath(archiveFileLocation, filename, allowedFileTypes);
                    File.WriteAllBytes(filename, fileTransferRequest.File);
                    var status = ToServer(filename, sessionOptions, fileTransferProfile, fileTransferRequest);
                    if (!status)
                    {
                        response.ActionStatus = false;
                        response.MessageType = FileTransferKnownValues.MessageTypes.Error;
                        response.Message = string.Format(UPLOAD_LIMIT, fileTransferProfile.UploadLimitInMB);
                    }
                    else
                        response.Folder = ListFolder(sessionOptions, fileTransferProfile, fileTransferRequest); // after successful upload, update the folder information
                    break;
                case FileTransferKnownValues.FileTransferRequestType.Download:
                    var tuple = FromServer(sessionOptions, fileTransferProfile, fileTransferRequest);
                    if (tuple.Item2)
                        response.DownLoadLocation = tuple.Item1;
                    else
                    {
                        response.ActionStatus = false;
                        response.MessageType = FileTransferKnownValues.MessageTypes.Error;
                        response.Message = string.Format(DOWNLOAD_LIMIT, fileTransferProfile.DownLoadLimitInGB);
                    }
                    break;
                case FileTransferKnownValues.FileTransferRequestType.FolderListing:
                    response.Folder = ListFolder(sessionOptions, fileTransferProfile, fileTransferRequest);
                    break;
                case FileTransferKnownValues.FileTransferRequestType.Delete:
                    if (!DeleteFile(sessionOptions, fileTransferRequest))
                    {
                        response.ActionStatus = false;
                        response.MessageType = FileTransferKnownValues.MessageTypes.Error;
                        response.Message = "Failed to delete the file";
                    }
                    break;
                case FileTransferKnownValues.FileTransferRequestType.Rename:
                    var fileInfo = Rename(sessionOptions, fileTransferProfile, fileTransferRequest);
                    if (fileInfo == null)
                    {
                        response.MessageType = FileTransferKnownValues.MessageTypes.Error;
                        response.Message = "Failed to rename the file";
                        response.ActionStatus = false;
                    }
                    else
                    {
                        response.Folder = fileInfo;
                    }
                    break;
            }

            opsLogManager.LogEvent(fileTransferRequest.UserId, "TransferFile", "Transfer File", string.Format("Profile Id - {0}; File Name - {1}", fileTransferRequest.ProfileId, fileTransferRequest.FileName), Contracts.Data.MDUA.UserToolLogLevel.Audit);
            return response;
        }


        public Contracts.Data.MDUA.FileTransfer.FileTransferProfile GetFileTransferProfile(string userId, long profileId)
        {
            return dbFileTransferDataProvider.GetFileTransferProfile(userId, profileId);
        }

        private Tuple<String, bool> FromServer(SessionOptions options, FileTransferProfile profile, FileTransferRequest request)
        {
            var path = request.FilePath.Decrypt(phase);
            var localPath = GetLocalLocation(path);
            var ret = Tuple.Create(localPath, true);
            using (var session = new Session())
            {
                session.Open(options);
                var fileInfo = session.GetFileInfo(path);
                if (VerifyFileLimit(fileInfo.Length, profile, request))
                    session.GetFiles(path, localPath, false, new TransferOptions { TransferMode = TransferMode.Binary }).Check();
                else
                    ret = Tuple.Create(string.Empty, false);
                session.Close();
            }
            return ret;
        }

        private bool ToServer(string filename, SessionOptions options, FileTransferProfile profile, FileTransferRequest request)
        {
            var flag = true;
            var path = request.FilePath.Decrypt(phase);
            var pathsep = FilePathSeparator(profile);

            using (var session = new Session())
            {
                session.Open(options);
                if (VerifyFileLimit(request.File.LongLength, profile, request))
                    session.PutFiles(filename, string.IsNullOrEmpty(path) ? profile.TargetDirectory : string.Join(pathsep, path.TrimEnd(pathsep[0]), "*")).Check();
                else
                    flag = false;
                session.Close();
            }
            return flag;
        }

        private bool VerifyFileLimit(long length, FileTransferProfile profile, FileTransferRequest request)
        {
            switch(request.RequestType) {
                case FileTransferKnownValues.FileTransferRequestType.Upload:
                    return length <= profile.UploadLimit;
                case FileTransferKnownValues.FileTransferRequestType.Download:
                    return length <= profile.DownloadLimit;
                default:
                    return true;
            }
        }

        private bool DeleteFile(SessionOptions options, FileTransferRequest request)
        {
            var path = request.FilePath.Decrypt(phase);
            using (var session = new Session())
            {
                session.Open(options);
                try
                {
                    session.RemoveFiles(path).Check();
                }
                catch
                {
                    return false;
                }
                return true;
            }
        }

        private FileTransferFileInfo Rename(SessionOptions options, FileTransferProfile profile, FileTransferRequest request)
        {
            var path = request.FilePath.Decrypt(phase);
            var newPath = Path.Combine(Path.GetDirectoryName(path), request.FileName);
            newPath = profile.DestinationOsType == 0 ? Regex.Replace(newPath, @"\\", Path.AltDirectorySeparatorChar.ToString()) : newPath;
            var filter = GenerateFilter(profile);

            using (var session = new Session())
            {
                session.Open(options);
                try
                {
                    //rename the same name will throw exception.
                    session.MoveFile(path, newPath);
                    var fileInfo = session.GetFileInfo(newPath);
                    var ret = convert(fileInfo);
                    ret.Oldpath = request.FilePath;
                    ret.Oldfullname = path;
                    ret.Oldname = Path.GetFileName(path);

                    if (ret.IsDirectory)
                    {
                        var allFiles = session.EnumerateRemoteFiles(newPath, null, EnumerationOptions.AllDirectories | EnumerationOptions.EnumerateDirectories).Where(filter).OrderBy(f => f.FullName).ToList();
                        var stack = new Stack<FileTransferFileInfo>();
                        stack.Push(ret);
                        return ToFileTree(stack, allFiles);
                    }
                    else
                        return ret;
                }
                catch
                {
                    return null;
                }
                
            }
        }

        private Func<RemoteFileInfo, bool> GenerateFilter(FileTransferProfile profile)
        {
            var rootPath = GetRootPath(profile);
            var pattern = string.IsNullOrEmpty(profile.Filter) ? "^[^.]" : string.Format("^{0}", profile.Filter);
            return remote => !remote.FullName.StartsWith(string.Join(FilePathSeparator(profile), rootPath, ".")) && Regex.IsMatch(remote.Name, pattern, RegexOptions.IgnoreCase);
        }

        private string NormalizePath(string path, FileTransferProfile profile)
        {
            var rootPath = GetRootPath(profile);
            return string.IsNullOrEmpty(path) ? rootPath : path;
        }

        private string GetRootPath(FileTransferProfile profile)
        {
            var pathsep = FilePathSeparator(profile);
            return profile.TargetDirectory.TrimEnd(pathsep[0], '*');
        }

        private FileTransferFileInfo ListFolder(SessionOptions options, FileTransferProfile profile, FileTransferRequest request)
        {
            var filter = GenerateFilter(profile);
            var path = NormalizePath(request.FilePath.Decrypt(phase), profile);

            using (var session = new Session())
            {
                session.Open(options);
                var allFiles = session.EnumerateRemoteFiles(path, null, EnumerationOptions.AllDirectories | EnumerationOptions.EnumerateDirectories).Where(filter).OrderBy(f => f.FullName).ToList();
                var stack = new Stack<FileTransferFileInfo>();
                stack.Push(new FileTransferFileInfo { FileType = 'D', IsDirectory = true, FullName = path, Name = Path.GetFileName(path), Path = request.FilePath, Files = new List<FileTransferFileInfo>() });
                return ToFileTree(stack, allFiles);
            }
        }

        private FileTransferFileInfo ToFileTree(Stack<FileTransferFileInfo> stack, IEnumerable<RemoteFileInfo> files)
        {

            foreach (var file in files)
            {

                while (!file.FullName.StartsWith(stack.Peek().FullName))                                    //pop stack if not the directory of new node
                {
                    var node = stack.Pop();
                    node.Files = node.Files.OrderBy(f => !f.IsDirectory).ThenBy(f => f.Name).ToList();      //sort directory files if done;          
                }

                var newNode = convert(file);
                stack.Peek().Files.Add(newNode);

                if (file.IsDirectory)                                                                       //push directory
                    stack.Push(newNode); 
    
            }
            var root = stack.Last();                                                                        //only need the deepest elemnet
            root.Files = root.Files.OrderBy(f => !f.IsDirectory).ThenBy(f => f.Name).ToList();               // sort the root directory
            return root;
        }

        private string GetLocalLocation(string path)
        {
            return Path.Combine(this.archiveFileLocation, Path.GetFileName(path));
        }

        private string FilePathSeparator(FileTransferProfile profile)
        {
            return profile.DestinationOsType == 0 ? Path.AltDirectorySeparatorChar.ToString() : Path.DirectorySeparatorChar.ToString();
        }
  
    }

    internal static class StringExt
    {
        public static string Encrypt(this String text, String phase)
        {
            if (String.IsNullOrEmpty(text))
                return text;

            var encrypted = Utility.Encrypt(text, phase);
            var base64 = Convert.ToBase64String(Encoding.UTF8.GetBytes(encrypted));
            return Regex.Replace(base64, "[+]", "-");
        }

        public static string Decrypt(this String text, String phase)
        {
            if (String.IsNullOrEmpty(text))
                return text;

            var replaced = Regex.Replace(text, "-", "[+]");
            var bytes = Convert.FromBase64String(replaced);
            return Utility.Decrypt(Encoding.UTF8.GetString(bytes), phase);
        }
    }

    internal static class DateTimeExt
    {
        public static DateTime ToEasternTime(this DateTime dt)
        {
            return TimeZoneInfo.ConvertTimeFromUtc(dt.ToUniversalTime(), TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time"));
        }
    }
}
