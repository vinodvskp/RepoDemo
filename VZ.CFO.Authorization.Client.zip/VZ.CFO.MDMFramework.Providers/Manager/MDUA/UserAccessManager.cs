﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Common;
using VZ.CFO.MDMFramework.Contracts.Data;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA.ODJobs;
using VZ.CFO.MDMFramework.Contracts.Data.Security;
using VZ.CFO.MDMFramework.Providers.Data;

namespace VZ.CFO.MDMFramework.Providers.Manager.MDUA
{
    public class UserAccessManager : Contracts.Service.MDUA.IUserAccessManager
    {
        private Contracts.Service.MDUA.IUserAccessManager userAccessDataProvider;
        private Contracts.Data.Config.MenuConfig menuConfig;
        private IOpsStatusLogManager opsLogManager;

        public UserAccessManager(Contracts.Service.MDUA.IUserAccessManager userAccessDataProvider, Contracts.Data.Config.MenuConfig menuConfig, IOpsStatusLogManager opsLogManager)
        {
            if (userAccessDataProvider == null)
            {
                throw new ArgumentNullException("userAccessDataProvider");
            }

            //if (menuConfig == null)
            //{
            //    throw new ArgumentNullException("menuConfig");
            //}

            this.userAccessDataProvider = userAccessDataProvider;
            this.menuConfig = menuConfig;
            this.opsLogManager = opsLogManager;
        }

        public Contracts.Data.MDUA.UserAccess[] GetUserAccessByEmployeeId(string employeeId)
        {
            return userAccessDataProvider.GetUserAccessByEmployeeId(employeeId);
        }

        public Contracts.Data.MDUA.UserAccess[] GetUserAccessByUserId(string userId)
        {
            return userAccessDataProvider.GetUserAccessByUserId(userId);
        }

        public bool SaveUserAccessByEmployeeId(string userId, string employeeId, string accessObjectType, Contracts.Data.MDUA.UserAccess[] userAccess)
        {
            return userAccessDataProvider.SaveUserAccessByEmployeeId(userId, employeeId, accessObjectType, userAccess);
        }

        public Claim[] GetUserAccess(string id, string authenticationSourceType)
        {
            return userAccessDataProvider.GetUserAccess(id, authenticationSourceType);
        }

        public Contracts.Data.MDUA.UserAccess[] GetUserAccessForAccessObjType(string employeeId, string accessObjectType)
        {
            return userAccessDataProvider.GetUserAccessForAccessObjType(employeeId, accessObjectType);
        }

        public Contracts.Data.MDUA.Menu[] GetMenuForUser(System.Security.Claims.Claim[] userClaims)
        {
            //userClaims = userAccessDataProvider.GetUserAccess("3565045889", "Sso");
            List<System.Security.Claims.Claim> userClaimList = new List<System.Security.Claims.Claim>();
            List<Contracts.Data.MDUA.Menu> availableMenus = GetAllMenus();
            List<Contracts.Data.MDUA.Menu> verifiedMenus = new List<Contracts.Data.MDUA.Menu>();
            //If UserClaim is null, dont send any menu out
            if (userClaims == null)
            {
                availableMenus = null;
            }

            if (availableMenus != null)
            {
                //add user claims to list so that its easy to perform search operations
                userClaimList.AddRange(userClaims);

                //iterate through all menu and its sub menus and remove any menus that user does have appropirate claims
                foreach (Contracts.Data.MDUA.Menu menu in availableMenus)
                {
                    var verifiedmenu = BuildMenu(userClaimList, menu);

                    if (verifiedmenu != null)
                    {
                        menu.IsEnabled = true;
                        verifiedMenus.Add(verifiedmenu);
                    }
                }
            }
            return verifiedMenus.ToArray();

            //return availableMenus.ToArray();
        }

        /// <summary>
        /// Recursive method to build menu
        /// </summary>
        /// <param name="userClaimList"></param>
        /// <param name="menu"></param>
        /// <returns></returns>
        private static Contracts.Data.MDUA.Menu BuildMenu(List<System.Security.Claims.Claim> userClaimList, Contracts.Data.MDUA.Menu menu)
        {
            // base condition
            if (menu.SubMenus == null)
            {
                //Return the menu only if the claims match
                if(VerifyClaimsForMenu(userClaimList, menu))
                {
                    menu.IsEnabled = true;
                    return menu;
                }
                else
                {
                    return null;
                }
            }
            else
            {
                //Recursive call for each submenu and include to final list only if the claims match
                List<Contracts.Data.MDUA.Menu> subMenuList = new List<Contracts.Data.MDUA.Menu>();
                foreach (var subMenu in menu.SubMenus)
                {
                    var verifiedSubMenu = BuildMenu(userClaimList, subMenu);

                    if (verifiedSubMenu != null && verifiedSubMenu.IsEnabled)
                    {
                        subMenuList.Add(verifiedSubMenu);
                    }
                }
                menu.IsEnabled = (subMenuList.Count > 0) ? true : false;
                menu.SubMenus = (subMenuList.Count > 0) ? subMenuList.ToArray() : null;
                return (subMenuList.Count > 0) ? menu : null;
            }
        }
        /// <summary>
        /// Verifies whether user has at least one claim that the menu is associated with
        /// </summary>
        /// <param name="userClaimList"></param>
        /// <param name="menu"></param>
        /// <returns></returns>
        private static bool VerifyClaimsForMenu(List<System.Security.Claims.Claim> userClaimList, Contracts.Data.MDUA.Menu menu)
        {
            bool isAnyRequiredClaimAvailable = false;
            if (menu.RequiredClaims == null)
            {
                menu.IsEnabled = false;
                isAnyRequiredClaimAvailable = false;
            }
            else
            {
                foreach (Claim requiredClaim in menu.RequiredClaims)
                {
                    if (userClaimList.Any(c => c.Type == requiredClaim.Type && c.Value == requiredClaim.Value))
                    {
                        isAnyRequiredClaimAvailable = true;
                        break;
                    }
                }
            }
            
            return isAnyRequiredClaimAvailable;
        }

        
        /// <summary>
        /// Read all available menus from configuration
        /// </summary>
        /// <returns></returns>
        private List<Contracts.Data.MDUA.Menu> GetAllMenus()
        {
            var menuList = new List<Contracts.Data.MDUA.Menu>();
            //if (menuConfig != null)
            //{
            //    menuList.AddRange(menuConfig.AvailableMenus);
            //}
            menuList.AddRange(GetAvailableMenus());
            return menuList;
        }

        private Contracts.Data.MDUA.Menu[] GetAvailableMenus() 
        {
            //Home Menu
            Contracts.Data.MDUA.Menu homeMenu = new Contracts.Data.MDUA.Menu()
            {
                Id = "home",
                IsClickable = true,
                IsEnabled = true,
                Name = "Home",
                RequiredClaims = new Contracts.Data.Security.Claim[] { new Contracts.Data.Security.Claim("MDMFramework.UserRole.0", "READONLY"), new Contracts.Data.Security.Claim("MDMFramework.UserRole.0", "USER"), new Contracts.Data.Security.Claim("MDMFramework.UserRole.0", "ADMINISTRATOR") },
                CanDisplay = true
            };

            //Self Serve
            Contracts.Data.MDUA.Menu selfServeMenu = new Contracts.Data.MDUA.Menu()
            {
                Id = "selfServe",
                IsClickable = false,
                IsEnabled = true,
                Name = "Self Serve",
                CanDisplay = true,
                SubMenus = new Contracts.Data.MDUA.Menu[]
                {
                    new Contracts.Data.MDUA.Menu() 
                    { 
                        Id = "userUploadParent", IsClickable = true, IsEnabled = true, Name = "User Upload",
                        //RequiredClaims = new Contracts.Data.Security.Claim[] {  },
                        CanDisplay = true,
                        SubMenus = new Contracts.Data.MDUA.Menu[]
                        {
                            new Contracts.Data.MDUA.Menu() 
                            { 
                                Id = "manageFileTypes", IsClickable = true, IsEnabled = true, Name = "Manage File Types", CanDisplay = true,
                                RequiredClaims = new Contracts.Data.Security.Claim[] 
                                { 
                                    new Contracts.Data.Security.Claim("MDMFramework.UserUpload.0", Contracts.Data.KnownValues.Security.ClaimValues.UserUpload.CanAddNewFileType)
                                },
                            },
                            new Contracts.Data.MDUA.Menu() 
                            { 
                                Id = "userUpload", IsClickable = true, IsEnabled = true, Name = "User Upload", CanDisplay = true,
                                RequiredClaims = new Contracts.Data.Security.Claim[] 
                                { 
                                    new Contracts.Data.Security.Claim("MDMFramework.UserRole.0", Contracts.Data.KnownValues.Security.ClaimValues.UserRole.Admin),
                                    new Contracts.Data.Security.Claim("MDMFramework.UserRole.0", Contracts.Data.KnownValues.Security.ClaimValues.UserRole.User),
                                    new Contracts.Data.Security.Claim("MDMFramework.UserUpload.0", Contracts.Data.KnownValues.Security.ClaimValues.UserUpload.CanPostAdjImmediately),
                                    new Contracts.Data.Security.Claim("MDMFramework.UserUpload.0", Contracts.Data.KnownValues.Security.ClaimValues.UserUpload.CanPostAdjToAnyPeriod),
                                    new Contracts.Data.Security.Claim("MDMFramework.UserUpload.0", Contracts.Data.KnownValues.Security.ClaimValues.UserUpload.CanPostFactData),
                                    new Contracts.Data.Security.Claim("MDMFramework.UserUpload.0", Contracts.Data.KnownValues.Security.ClaimValues.UserUpload.CanPostToAnyPeriod)
                                }
                            },
                            new Contracts.Data.MDUA.Menu() 
                            { 
                                Id = "factTableDownload", IsClickable = true, IsEnabled = true, Name = "Fact Table Download", CanDisplay = true,
                                RequiredClaims = new Contracts.Data.Security.Claim[] 
                                { 
                                    new Contracts.Data.Security.Claim("MDMFramework.UserRole.0", Contracts.Data.KnownValues.Security.ClaimValues.UserRole.Admin),
                                    new Contracts.Data.Security.Claim("MDMFramework.UserRole.0", Contracts.Data.KnownValues.Security.ClaimValues.UserRole.User),
                                    new Contracts.Data.Security.Claim("MDMFramework.UserUpload.0", Contracts.Data.KnownValues.Security.ClaimValues.UserUpload.CanPostAdjImmediately),
                                    new Contracts.Data.Security.Claim("MDMFramework.UserUpload.0", Contracts.Data.KnownValues.Security.ClaimValues.UserUpload.CanPostAdjToAnyPeriod),
                                    new Contracts.Data.Security.Claim("MDMFramework.UserUpload.0", Contracts.Data.KnownValues.Security.ClaimValues.UserUpload.CanPostFactData),
                                    new Contracts.Data.Security.Claim("MDMFramework.UserUpload.0", Contracts.Data.KnownValues.Security.ClaimValues.UserUpload.CanPostToAnyPeriod)
                                }
                            },
                            new Contracts.Data.MDUA.Menu() 
                            { 
                                Id = "auditTableDownload", IsClickable = true, IsEnabled = true, Name = "Audit Table Download", CanDisplay = true,
                                RequiredClaims = new Contracts.Data.Security.Claim[] 
                                { 
                                    new Contracts.Data.Security.Claim("MDMFramework.UserRole.0", Contracts.Data.KnownValues.Security.ClaimValues.UserRole.Admin),
                                    new Contracts.Data.Security.Claim("MDMFramework.UserRole.0", Contracts.Data.KnownValues.Security.ClaimValues.UserRole.User)
                                }
                            },
                            new Contracts.Data.MDUA.Menu() 
                            { 
                                Id = "userUploadLegacy", IsClickable = true, IsEnabled = true, Name = "User Input Upload (Legacy)", CanDisplay = true,
                                RequiredClaims = new Contracts.Data.Security.Claim[] 
                                { 
                                    new Contracts.Data.Security.Claim("MDMFramework.UserRole.0", Contracts.Data.KnownValues.Security.ClaimValues.UserRole.Admin),
                                    new Contracts.Data.Security.Claim("MDMFramework.UserRole.0", Contracts.Data.KnownValues.Security.ClaimValues.UserRole.User),
                                    new Contracts.Data.Security.Claim("MDMFramework.UserUpload.0", Contracts.Data.KnownValues.Security.ClaimValues.UserUpload.CanPostAdjImmediately),
                                    new Contracts.Data.Security.Claim("MDMFramework.UserUpload.0", Contracts.Data.KnownValues.Security.ClaimValues.UserUpload.CanPostAdjToAnyPeriod),
                                    new Contracts.Data.Security.Claim("MDMFramework.UserUpload.0", Contracts.Data.KnownValues.Security.ClaimValues.UserUpload.CanPostFactData),
                                    new Contracts.Data.Security.Claim("MDMFramework.UserUpload.0", Contracts.Data.KnownValues.Security.ClaimValues.UserUpload.CanPostToAnyPeriod)
                                }, RelativePath = "UserInputUpload.aspx"
                            },
                            new Contracts.Data.MDUA.Menu() 
                            { 
                                Id = "userInputFileTypes", IsClickable = true, IsEnabled = true, Name = "User Input File Types (Legacy)", CanDisplay = true,
                                RequiredClaims = new Contracts.Data.Security.Claim[] 
                                { 
                                    new Contracts.Data.Security.Claim("MDMFramework.UserUpload.0", Contracts.Data.KnownValues.Security.ClaimValues.UserUpload.CanAddNewFileType)
                                }, RelativePath = "OpsFileTypes.aspx"
                            },
                            new Contracts.Data.MDUA.Menu() 
                            { 
                                Id = "userInputKeysLegacy", IsClickable = true, IsEnabled = true, Name = "User Input Keys (Legacy)", CanDisplay = true,
                                RequiredClaims = new Contracts.Data.Security.Claim[] 
                                { 
                                    new Contracts.Data.Security.Claim("MDMFramework.UserRole.0", Contracts.Data.KnownValues.Security.ClaimValues.UserRole.Admin),
                                    new Contracts.Data.Security.Claim("MDMFramework.UserRole.0", Contracts.Data.KnownValues.Security.ClaimValues.UserRole.User)
                                }, RelativePath = "UserInputNewKey.aspx"
                            },
                            new Contracts.Data.MDUA.Menu() 
                            { 
                                Id = "moveKeyComboLegacy", IsClickable = true, IsEnabled = true, Name = "Move Key Combo (Legacy)", CanDisplay = true,
                                RequiredClaims = new Contracts.Data.Security.Claim[] 
                                { 
                                    new Contracts.Data.Security.Claim("MDMFramework.UserUpload.0", Contracts.Data.KnownValues.Security.ClaimValues.UserUpload.CanAddUserInputKeys)
                                }, RelativePath = "MoveKeyCombos.aspx"
                            },
                            new Contracts.Data.MDUA.Menu() 
                            { 
                                Id = "cpgaProcessingLegacy", IsClickable = true, IsEnabled = true, Name = "CPGA Processing (Legacy)", CanDisplay = true,
                                RequiredClaims = new Contracts.Data.Security.Claim[] 
                                { 
                                    new Contracts.Data.Security.Claim("MDMFramework.UserUpload.0", Contracts.Data.KnownValues.Security.ClaimValues.UserUpload.CanProcessCpga),
                                    new Contracts.Data.Security.Claim("MDMFramework.UserRole.0", Contracts.Data.KnownValues.Security.ClaimValues.UserRole.Admin)
                                }, RelativePath = "CpgaInfo.aspx"
                            },
                            new Contracts.Data.MDUA.Menu() 
                            { 
                                Id = "factTableDownloadLegacy", IsClickable = true, IsEnabled = true, Name = "Fact Table Download (Legacy)", CanDisplay = true,
                                RequiredClaims = new Contracts.Data.Security.Claim[] 
                                { 
                                    new Contracts.Data.Security.Claim("MDMFramework.UserRole.0", Contracts.Data.KnownValues.Security.ClaimValues.UserRole.User),
                                    new Contracts.Data.Security.Claim("MDMFramework.UserRole.0", Contracts.Data.KnownValues.Security.ClaimValues.UserRole.Admin)
                                }, RelativePath = "OpsFactDownload.aspx"
                            },                            
                            new Contracts.Data.MDUA.Menu() 
                            { 
                                Id = "auditTableLegacy", IsClickable = true, IsEnabled = true, Name = "Audit Table (Legacy)", CanDisplay = true,
                                RequiredClaims = new Contracts.Data.Security.Claim[] 
                                { 
                                    new Contracts.Data.Security.Claim("MDMFramework.UserRole.0", Contracts.Data.KnownValues.Security.ClaimValues.UserRole.User),
                                    new Contracts.Data.Security.Claim("MDMFramework.UserRole.0", Contracts.Data.KnownValues.Security.ClaimValues.UserRole.Admin)
                                }, RelativePath = "AuditTblDownload.aspx"
                            }
                        }
                    },
                    new Contracts.Data.MDUA.Menu() 
                    { 
                        Id = "versionManagement", IsClickable = true, IsEnabled = true, Name = "Version Management",
                        RequiredClaims = new Contracts.Data.Security.Claim[] { new Contracts.Data.Security.Claim("MDMFramework.VM.0", "READ"), new Contracts.Data.Security.Claim("MDMFramework.VM.0", "EDIT"), new Contracts.Data.Security.Claim("MDMFramework.VM.0", "TRACKING") },
                        CanDisplay = true,
                        SubMenus = new Contracts.Data.MDUA.Menu[]
                        {
                            new Contracts.Data.MDUA.Menu() 
                            { 
                                Id = "dashboard", IsClickable = true, IsEnabled = true, Name = "Dashboard", CanDisplay = true,
                                RequiredClaims = new Contracts.Data.Security.Claim[] { new Contracts.Data.Security.Claim("MDMFramework.VM.0", "READ"), new Contracts.Data.Security.Claim("MDMFramework.VM.0", "EDIT"), new Contracts.Data.Security.Claim("MDMFramework.VM.0", "TRACKING") },
                            },
                            new Contracts.Data.MDUA.Menu() 
                            { 
                                Id = "createRequest", IsClickable = true, IsEnabled = true, Name = "Create Request", CanDisplay = true,
                                RequiredClaims = new Contracts.Data.Security.Claim[] { new Contracts.Data.Security.Claim("MDMFramework.VM.0", "EDIT") }
                            },
                            new Contracts.Data.MDUA.Menu() 
                            { 
                                Id = "requestTracking", IsClickable = true, IsEnabled = true, Name = "Track Request", CanDisplay = true,
                                RequiredClaims = new Contracts.Data.Security.Claim[] { new Contracts.Data.Security.Claim("MDMFramework.VM.0", "EDIT"), new Contracts.Data.Security.Claim("MDMFramework.VM.0", "TRACKING") }
                            },
                            new Contracts.Data.MDUA.Menu() 
                            { 
                                // this item is not a menu but needed to check if the user has access this page
                                Id = "requestDetail", IsClickable = false, IsEnabled = true, Name = "Request Details", CanDisplay = false,
                                RequiredClaims = new Contracts.Data.Security.Claim[] { new Contracts.Data.Security.Claim("MDMFramework.VM.0", "EDIT"), new Contracts.Data.Security.Claim("MDMFramework.VM.0", "TRACKING") }
                            }
                        }
                    },
                    new Contracts.Data.MDUA.Menu() 
                    { 
                        Id = "mappingTable", IsClickable = false, IsEnabled = true, Name = "Mapping Tables", CanDisplay = true,
                        RequiredClaims = new Contracts.Data.Security.Claim[] { new Contracts.Data.Security.Claim("MDMFramework.MT.0", "READ"), new Contracts.Data.Security.Claim("MDMFramework.MT.0", "EDIT"), new Contracts.Data.Security.Claim("MDMFramework.MT.0", "MIGRATE") },
                        SubMenus = new Contracts.Data.MDUA.Menu[]
                        {
                            new Contracts.Data.MDUA.Menu() 
                            { 
                                Id = "manage", IsClickable = true, IsEnabled = true, Name = "Manage", CanDisplay = true,
                                RequiredClaims = new Contracts.Data.Security.Claim[] { new Contracts.Data.Security.Claim("MDMFramework.MT.0", "READ"), new Contracts.Data.Security.Claim("MDMFramework.MT.0", "EDIT"), new Contracts.Data.Security.Claim("MDMFramework.MT.0", "MIGRATE") }
                            },
                            new Contracts.Data.MDUA.Menu() 
                            { 
                                Id = "audit", IsClickable = true, IsEnabled = true, Name = "Audit", CanDisplay = true,
                                RequiredClaims = new Contracts.Data.Security.Claim[] { new Contracts.Data.Security.Claim("MDMFramework.MT.0", "READ"), new Contracts.Data.Security.Claim("MDMFramework.MT.0", "EDIT"), new Contracts.Data.Security.Claim("MDMFramework.MT.0", "MIGRATE") }
                            }
                        }
                    },
                    //File Transfer
                    new Contracts.Data.MDUA.Menu()
                    {
                        Id = "fileTransferParent",
                        IsClickable = false,
                        IsEnabled = true,
                        Name = "File Transfer",
                        RequiredClaims = new Contracts.Data.Security.Claim[] { new Contracts.Data.Security.Claim("MDMFramework.FT.0", "EDIT")},
                        CanDisplay = true,
                        SubMenus = new Contracts.Data.MDUA.Menu[]
                        {
                            new Contracts.Data.MDUA.Menu() 
                            { 
                                Id = "fileTransfer", IsClickable = true, IsEnabled = true, Name = "File Transfer", CanDisplay = true,
                                RequiredClaims = new Contracts.Data.Security.Claim[] { new Contracts.Data.Security.Claim("MDMFramework.FT.0", "EDIT")}
                            }
                        }
                    },
                    //Data Scoop
                    new Contracts.Data.MDUA.Menu()
                    {
                        Id = "datascoop",
                        IsClickable = false,
                        IsEnabled = true,
                        Name = "Data Scoop",
                        RequiredClaims = new Contracts.Data.Security.Claim[] { new Contracts.Data.Security.Claim("MDMFramework.DST.0", "EDIT"), new Contracts.Data.Security.Claim("MDMFramework.DSA.0", "EDIT")},
                        CanDisplay = true,
                        SubMenus = new Contracts.Data.MDUA.Menu[]
                        {
                            new Contracts.Data.MDUA.Menu() 
                            { 
                                Id = "datascoopApp", IsClickable = true, IsEnabled = true, Name = "Manage Applications", CanDisplay = true,
                                RequiredClaims = new Contracts.Data.Security.Claim[] { new Contracts.Data.Security.Claim("MDMFramework.DST.0", "EDIT"), new Contracts.Data.Security.Claim("MDMFramework.DSA.0", "EDIT")}
                            }
                        }
                    },
                    //Jobs
                    new Contracts.Data.MDUA.Menu()
                    {
                        Id = "jobs",
                        IsClickable = false,
                        IsEnabled = true,
                        Name = "Jobs",
                        RequiredClaims = new Contracts.Data.Security.Claim[] { new Contracts.Data.Security.Claim("MDMFramework.ODJ.0", "TRIGGER")},
                        CanDisplay = true,
                        SubMenus = new Contracts.Data.MDUA.Menu[]
                        {
                            new Contracts.Data.MDUA.Menu() 
                            { 
                                Id = "onDemandJobs", IsClickable = true, IsEnabled = true, Name = "On Demand Jobs", CanDisplay = true,
                                RequiredClaims = new Contracts.Data.Security.Claim[] { new Contracts.Data.Security.Claim("MDMFramework.ODJ.0", "TRIGGER")}
                            },
                            new Contracts.Data.MDUA.Menu() 
                            { 
                                Id = "feedStatus", IsClickable = true, IsEnabled = true, Name = "Feed Status", CanDisplay = true,
                                RequiredClaims = new Contracts.Data.Security.Claim[] { 
                                new Contracts.Data.Security.Claim("MDMFramework.UserRole.0", Contracts.Data.KnownValues.Security.ClaimValues.UserRole.Admin),
                                new Contracts.Data.Security.Claim("MDMFramework.UserRole.0", Contracts.Data.KnownValues.Security.ClaimValues.UserRole.User)
                                }, RelativePath = "InputFileStatus.aspx"
                            }
                        }
                    },
                    //Reporting
                    new Contracts.Data.MDUA.Menu()
                    {
                        Id = "reporting",
                        IsClickable = true,
                        IsEnabled = true,
                        Name = "Reporting",
                        RequiredClaims = new Contracts.Data.Security.Claim[] { new Contracts.Data.Security.Claim("MDMFramework.RPT.0", "READ") },
                        CanDisplay = true
                    }
                }
            };
            //Admin
            Contracts.Data.MDUA.Menu adminMenu = new Contracts.Data.MDUA.Menu()
            {
                Id = "adminFunctions",
                IsClickable = false,
                IsEnabled = true,
                Name = "Admin Functions",
                CanDisplay = true,
                SubMenus = new Contracts.Data.MDUA.Menu[]
                {
                    new Contracts.Data.MDUA.Menu() 
                    { 
                        Id = "manageUsers", IsClickable = true, IsEnabled = true, Name = "Manage Users", CanDisplay = true,
                        RequiredClaims = new Contracts.Data.Security.Claim[] 
                        { 
                            new Contracts.Data.Security.Claim("MDMFramework.UserRole.0", Contracts.Data.KnownValues.Security.ClaimValues.UserRole.Admin),
                            new Contracts.Data.Security.Claim("MDMFramework.UserUpload.0", Contracts.Data.KnownValues.Security.ClaimValues.UserUpload.CanAssignAutosysOD),
                            new Contracts.Data.Security.Claim("MDMFramework.UserUpload.0", Contracts.Data.KnownValues.Security.ClaimValues.UserUpload.CanAssignUserFileType)
                        }//, RelativePath = "Users.aspx"
                    },
                    new Contracts.Data.MDUA.Menu() 
                    { 
                        Id = "userProfile", IsClickable = true, IsEnabled = true, Name = "User Profile", CanDisplay = true,
                        RequiredClaims = new Contracts.Data.Security.Claim[] 
                        { 
                            new Contracts.Data.Security.Claim("MDMFramework.UserRole.0", Contracts.Data.KnownValues.Security.ClaimValues.UserRole.Admin),
                            new Contracts.Data.Security.Claim("MDMFramework.UserUpload.0", Contracts.Data.KnownValues.Security.ClaimValues.UserUpload.CanAssignAutosysOD),
                            new Contracts.Data.Security.Claim("MDMFramework.UserUpload.0", Contracts.Data.KnownValues.Security.ClaimValues.UserUpload.CanAssignUserFileType)
                        }
                    },
                    new Contracts.Data.MDUA.Menu() 
                    { 
                        Id = "viewLogs", IsClickable = true, IsEnabled = true, Name = "View Logs", CanDisplay = true,
                        RequiredClaims = new Contracts.Data.Security.Claim[] 
                        { 
                            new Contracts.Data.Security.Claim("MDMFramework.UserRole.0", Contracts.Data.KnownValues.Security.ClaimValues.UserRole.Admin),
                            new Contracts.Data.Security.Claim("MDMFramework.UserUpload.0", Contracts.Data.KnownValues.Security.ClaimValues.UserUpload.CanAssignAutosysOD),
                            new Contracts.Data.Security.Claim("MDMFramework.UserUpload.0", Contracts.Data.KnownValues.Security.ClaimValues.UserUpload.CanAssignUserFileType)
                        }, RelativePath = "LogViewer.aspx"
                    },
                    new Contracts.Data.MDUA.Menu() 
                    { 
                        Id = "odJobSetup", IsClickable = true, IsEnabled = true, Name = "OD Job Setup", CanDisplay = true,
                        RequiredClaims = new Contracts.Data.Security.Claim[] 
                        { 
                            new Contracts.Data.Security.Claim("MDMFramework.UserRole.0", Contracts.Data.KnownValues.Security.ClaimValues.UserRole.Admin)
                        },
                        RelativePath = "AutosysJobSetup.aspx"
                    },
                    new Contracts.Data.MDUA.Menu() 
                    { 
                        Id = "systemSettings", IsClickable = true, IsEnabled = true, Name = "System Settings", CanDisplay = true,
                        RequiredClaims = new Contracts.Data.Security.Claim[] 
                        { 
                            new Contracts.Data.Security.Claim("MDMFramework.UserRole.0", Contracts.Data.KnownValues.Security.ClaimValues.UserRole.Admin)
                        },
                        RelativePath = "SystemSettings.aspx"
                    }
                }
            };

            return new Contracts.Data.MDUA.Menu[] { homeMenu, selfServeMenu, adminMenu };
        }

        public Contracts.Data.MDUA.UserInfo[] GetAllUsers()
        {
            return userAccessDataProvider.GetAllUsers();
        }

        public Contracts.Data.MDUA.UserInfo GetUser(string employeeId)
        {
            var userInfo = userAccessDataProvider.GetUser(employeeId);
            return UpdateAccessType(userInfo.UserAccess, userInfo);
        }

        public Contracts.Data.MDUA.UserInfo GetUserFromLdap(string vzid)
        {
            return userAccessDataProvider.GetUserFromLdap(vzid);
        }

        public bool SaveUserInfo(string userId, Contracts.Data.MDUA.UserInfo userInfo)
        {
            if (CanUpdateUsers(userId))
            {
                return userAccessDataProvider.SaveUserInfo(userId, userInfo);
            }
            else 
            {
                throw new MDMFrameworkException(string.Format("User {0} not authorized to update users", userId));
            }
        }

        public bool DeleteUserInfo(string userId, string employeeId)
        {
            return userAccessDataProvider.DeleteUserInfo(userId, employeeId);
        }

        public Contracts.Data.MDUA.ODJobs.ODJobGroup[] GetAllODJobs()
        {
            return userAccessDataProvider.GetAllODJobs();
        }

        public Contracts.Data.MDUA.ODJobs.ODJobGroup[] GetODJobAccess(string employeeId)
        {
            return userAccessDataProvider.GetODJobAccess(employeeId);
        }

        public Contracts.Data.MDUA.FactTables.FactTable[] GetFactFileTypeAccess(string employeeId)
        {
            return userAccessDataProvider.GetFactFileTypeAccess(employeeId);
        }

        public Contracts.Data.MDUA.FactTables.FactTable[] GetAllFactFile()
        {
            return userAccessDataProvider.GetAllFactFile();
        }

        private string UpdateAccessType(UserInfo userInfo)
        {
            string userAccess = "|";
            if (userInfo.CanAddNewFileKeys)
            {
                userAccess += "ADFK|";
            }
            if (userInfo.CanAddNewFileTypes)
            {
                userAccess += "ADFT|";
            }
            if (userInfo.CanAssignFileTypesForUser)
            {
                userAccess += "ASFT|";
            }
            if (userInfo.CanAssignODJ)
            {
                userAccess += "ASAO|";
            }
            if (userInfo.CanModifyOutline)
            {
                userAccess += "MDOL|";
            }
            if (userInfo.CanPostAdjAnyPeriod)
            {
                userAccess += "POAP|";
            }
            if (userInfo.CanPostAdjImm)
            {
                userAccess += "ADJN|";
            }
            if (userInfo.CanPostUserFeedsForPrevPer)
            {
                userAccess += "PFAP|";
            }
            if (userInfo.CanProcessCPGA)
            {
                userAccess += "CPGA|";
            }

            return userAccess;
        }

        private UserInfo UpdateAccessType(string userAccess, UserInfo userInfo)
        {
            
            userInfo.CanAddNewFileKeys = userAccess.Contains("ADFK");
            userInfo.CanAddNewFileTypes = userAccess.Contains("ADFT");
            userInfo.CanAssignFileTypesForUser = userAccess.Contains("ASFT");
            userInfo.CanAssignODJ = userAccess.Contains("ASAO");
            userInfo.CanModifyOutline = userAccess.Contains("MDOL");
            userInfo.CanPostAdjAnyPeriod = userAccess.Contains("POAP");
            userInfo.CanPostAdjImm = userAccess.Contains("ADJN");
            userInfo.CanPostUserFeedsForPrevPer = userAccess.Contains("PFAP");
            userInfo.CanProcessCPGA = userAccess.Contains("CPGA");

            return userInfo;
        }

        private static bool WriteUserAccessToCsv(string filename, string sheetName, string[] columnHeaders, UserAccessFlat[] userAccessCollection)
        {
            bool returnValue = false;
            try
            {
                //Module Name, Module Item Name, Employee Id, Last Name, First Name, Access
                using (StreamWriter writer = new StreamWriter(filename))
                {
                    writer.WriteLine(string.Join(",", columnHeaders));

                    foreach (var userAccessItem in userAccessCollection)
                    {
                        List<string> rowData = new List<string>();
                        rowData.Add(userAccessItem.AccessObjectType);
                        rowData.Add(userAccessItem.AccessObjectName);
                        rowData.Add(userAccessItem.User.EmployeeId);
                        rowData.Add(userAccessItem.User.LastName);
                        rowData.Add(userAccessItem.User.FirstName);
                        rowData.Add(userAccessItem.AccessType[0]);
                        writer.WriteLine(string.Join(",", rowData.ToArray()));
                    }
                    writer.Dispose();
                }

                returnValue = true;
            }
            catch
            {
                //TODO: Handle exception
                returnValue = false;
            }
            return returnValue;
        }

        private static bool WriteUsersToCsv(string filename, string sheetName, string[] columnHeaders, UserInfo[] userCollection)
        {
            bool returnValue = false;
            try
            {
                //Module Name, Module Item Name, Employee Id, Last Name, First Name, Access
                using (StreamWriter writer = new StreamWriter(filename))
                {
                    writer.WriteLine(string.Join(",", columnHeaders));

                    foreach (var user in userCollection)
                    {
                        List<string> rowData = new List<string>();
                        rowData.Add(user.EmployeeId);
                        rowData.Add(user.UserId);
                        rowData.Add(user.LastName);
                        rowData.Add(user.FirstName);
                        rowData.Add(user.UserRole.ToString());
                        rowData.Add(user.Active ? "Yes" : "No");
                        writer.WriteLine(string.Join(",", rowData.ToArray()));
                    }
                    writer.Dispose();
                }

                returnValue = true;
            }
            catch
            {
                //TODO: Handle exception
                returnValue = false;
            }
            return returnValue;
        }

        public bool SaveLegacyUserAccess(string userId, Contracts.Data.MDUA.User.LegacyUserAccess legacyUserAccess)
        {
            if (legacyUserAccess == null)
            {
                throw new ArgumentNullException("legacyUserAccess cannot be null");
            }

            if (legacyUserAccess.FactFileTypes != null)
            {
                List<FactFileType> factFileTypes = new List<FactFileType>();
                factFileTypes.AddRange(legacyUserAccess.FactFileTypes);

                if (factFileTypes.Any(f => f.FactTableType == FactTableKnownValues.FactTableType.Fbit && (f.FileTypeCodeId == null || f.FileTypeCodeId == 0)))
                {
                    throw new ArgumentException("One ore more fact file types of fbit type does not have valid code id");
                }

                if (factFileTypes.Any(f => f.FactTableType == FactTableKnownValues.FactTableType.Legacy && (f.Code.Trim() == string.Empty)))
                {
                    throw new ArgumentException("One ore more fact file types of legacy type does has empty code");
                }
            }

            if (legacyUserAccess.ODJobs != null)
            {
                List<ODJob> odJobs = new List<ODJob>();
                odJobs.AddRange(legacyUserAccess.ODJobs);

                if (odJobs.Any(j => j.Id == 0))
                {
                    throw new ArgumentException("job id cannot be 0");
                }
            }

            if (legacyUserAccess.EmployeeId.Trim() == string.Empty)
            {
                throw new ArgumentNullException("employee id is null or empty");
            }

            var user = GetUser(legacyUserAccess.EmployeeId);

            if (user == null)
            {
                throw new ArgumentException("User not found");
            }

            if (legacyUserAccess.UserInformation != null)
            {
                legacyUserAccess.UserInformation.UserAccess = UpdateAccessType(legacyUserAccess.UserInformation);
            }

            return userAccessDataProvider.SaveLegacyUserAccess(userId, legacyUserAccess);
        }


        public async Task<UserAccessFlatPage> GetUserAccessFlatAsync(string userId, int pageNumber, int rowsPerPage, int totalRecords)
        {
            return await userAccessDataProvider.GetUserAccessFlatAsync(userId, pageNumber, rowsPerPage, totalRecords);
        }

        public UserAccessFlatPage GetUserAccessFlat(string userId, string accessObjectType, int pageNumber, int rowsPerPage, int totalRecords)
        {
            return userAccessDataProvider.GetUserAccessFlat(userId, accessObjectType, pageNumber, rowsPerPage, totalRecords);
        }


        public async Task<string> ExportUsers(string userId, ExportUserType exportType)
        {

            //Check if user has permissions to export
            //var user = userAccessDataProvider.GetUser(userId);
            //var canExport = (user != null && (user.UserRole == PortalUserRole.Administrator || user.CanAssignODJ == true || user.CanAssignFileTypesForUser)) ? true : false;
            var canExport = CanUpdateUsers(userId);
            if (canExport == false)
            {
                throw new MDMFrameworkException(ErrorConstants.KnownException, "You do not have access to perform this function.");
            }

            if (exportType == ExportUserType.UsersView)
            {
                return await ExportUsers(userId);
            }
            else if (exportType == ExportUserType.UserAccessView)
            {
                return await ExportUserAccess(userId);
            }
            else
            {
                throw new InvalidOperationException();
            }
        }


        private async Task<string> ExportUserAccess(string userId) 
        {
            string fileAsBase64String = string.Empty;
            int maxRowPerPage = 200;
            //Get the first page of the table
            UserAccessFlatPage firstPage = GetUserAccessFlat(userId, string.Empty, 1, maxRowPerPage, 0);
            if (firstPage == null)
            {
                throw new MDMFrameworkException(ErrorConstants.KnownException, "Error getting data for export users");
            }

            List<Task<UserAccessFlatPage>> remainingPagesTasks = new List<Task<UserAccessFlatPage>>();
            List<UserAccessFlatPage> remainingPages = new List<UserAccessFlatPage>();
            List<UserAccessFlat> userAccessFlatList = new List<UserAccessFlat>();

            //Add first page data to collection
            userAccessFlatList.AddRange(firstPage.UserAccessList);

            //Add tasks to retreive page data
            for (int pageCount = 2; pageCount <= firstPage.TotalPages; pageCount++)
            {
                remainingPagesTasks.Add(GetUserAccessFlatAsync(userId, pageCount, firstPage.RowsPerPage, firstPage.TotalRows));
            }

            //Parallelly fetch data for all pages
            while (remainingPagesTasks.Count > 0)
            {
                Task<UserAccessFlatPage> firstFinishedTask = await Task.WhenAny(remainingPagesTasks);
                remainingPagesTasks.Remove(firstFinishedTask);

                UserAccessFlatPage completedPage = await firstFinishedTask;
                remainingPages.Add(completedPage);
            }

            //Collection to hold the merged data
            Dictionary<int, List<UserAccessFlat>> mergedUserAccessData = new Dictionary<int, List<UserAccessFlat>>();

            for (int pageCount = 2; pageCount <= firstPage.TotalPages; pageCount++)
            {
                var pageToMerge = remainingPages.FirstOrDefault(p => p.PageNumber == pageCount);
                userAccessFlatList.AddRange(pageToMerge.UserAccessList);
            }

            //generate a temp file in the system's temp location
            var fileName = System.IO.Path.GetTempFileName();
            //Write it to mapping file
            var csvColumns = new string[] { "Module Name", "Module Item Name", "Employee Id", "Last Name", "First Name", "Access" };
            if (WriteUserAccessToCsv(fileName, "sample", csvColumns, userAccessFlatList.ToArray()))
            {
                //Convert the temp file to binary
                byte[] csvBinary = File.ReadAllBytes(fileName);
                //convert binary to base64 string
                fileAsBase64String = Convert.ToBase64String(csvBinary);
            }

            //return csv file as base64 string
            return fileAsBase64String;
        }

        private async Task<string> ExportUsers(string userId)
        {
            string fileAsBase64String = string.Empty;

            var task = Task.Run(() => GetAllUsers());
            UserInfo[] userList = await task;

            //generate a temp file in the system's temp location
            var fileName = System.IO.Path.GetTempFileName();
            //Write it to mapping file
            string[] columnHeaders = new string[] { "Employee Id", "VZID", "Last Name", "First Name", "Role", "Active" };
            if (WriteUsersToCsv(fileName, "sample", columnHeaders, userList))
            {
                //Convert the temp file to binary
                byte[] csvBinary = File.ReadAllBytes(fileName);
                //convert binary to base64 string
                fileAsBase64String = Convert.ToBase64String(csvBinary);
            }

            //return csv file as base64 string
            return fileAsBase64String;
        }


        public Contracts.Data.GenericResponse RefreshUsersFromADGroup(string employeeId)
        {
            var response = new Contracts.Data.GenericResponse();
            //Check if user has permissions to refresh
            //var user = userAccessDataProvider.GetUser(employeeId);
            //var canRefresh = (user != null && (user.UserRole == PortalUserRole.Administrator || user.CanAssignODJ == true || user.CanAssignFileTypesForUser)) ? true : false;
            var canRefresh = CanUpdateUsers(employeeId);
            if (canRefresh == false)
            {
                response.ResponseType = Contracts.Data.KnownValues.ResponseTypes.Error;
                response.Message = "You do not have access to perform this function.";
            }
            else
            {
                response = userAccessDataProvider.RefreshUsersFromADGroup(employeeId);
            }

            return response;
        }

        private bool CanUpdateUsers(string employeeId) 
        {
            //var user = userAccessDataProvider.GetUser(employeeId);
            var user = GetUser(employeeId);
            
            return (user != null && (user.UserRole == PortalUserRole.Administrator || user.CanAssignODJ == true || user.CanAssignFileTypesForUser)) ? true : false;
        }


        public void AuditUser(AuditInfo auditInfo)
        {
            opsLogManager.LogEvent(auditInfo.EmployeeId, auditInfo.Location, auditInfo.Action, auditInfo.Status, UserToolLogLevel.Audit);
        }

        public VZ.CFO.MDMFramework.Contracts.Data.MDUA.User.HomepageContent GetHomepageContent(string employeeId)
        {
            return userAccessDataProvider.GetHomepageContent(employeeId);
        }

        public bool UpdateHomepageContent(string employeeId, VZ.CFO.MDMFramework.Contracts.Data.MDUA.User.HomepageContent homepageContent)
        {
            return userAccessDataProvider.UpdateHomepageContent(employeeId, homepageContent);
        }
    }
}
