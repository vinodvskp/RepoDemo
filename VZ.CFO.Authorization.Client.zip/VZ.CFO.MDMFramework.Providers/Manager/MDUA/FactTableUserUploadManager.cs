﻿using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables;
using VZ.CFO.MDMFramework.Common;
using VZ.CFO.MDMFramework.Contracts.Data;
using VZ.CFO.MDMFramework.Providers.Data;
using VZ.CFO.MDMFramework.Contracts.Service.MDUA;

namespace VZ.CFO.MDMFramework.Providers.Manager.MDUA
{
    public class FactTableUserUploadManager : Contracts.Service.MDUA.IFactTableUserUpload
    {
        private Contracts.Service.MDUA.IFactTableManager factTableManager = null;
        private Contracts.Service.ISecurityManager securityManager = null;
        private string factFileArchiveDir = string.Empty;
        private readonly MDMFramework.Providers.Data.IOpsStatusLogManager opsStatusDbManager;
        private readonly IFactTableUserUploadDataProvider factTableUserUploadData;
        private readonly IUserAccessManager userAccessManager;
        private readonly double MaxUploadSizeInMB;

        public FactTableUserUploadManager(Contracts.Service.MDUA.IFactTableManager factTableManager, Contracts.Service.ISecurityManager securityManager, MDMFramework.Providers.Data.IOpsStatusLogManager opsStatusDbManager, IFactTableUserUploadDataProvider factTableUserUploadData, IUserAccessManager userAccessManager, string factFileArchiveDir, double maxUploadSizeInMB)
        {
            this.factTableUserUploadData = factTableUserUploadData;
            this.factTableManager = factTableManager;
            this.securityManager = securityManager;
            this.opsStatusDbManager = opsStatusDbManager;
            this.factFileArchiveDir = factFileArchiveDir;
            this.userAccessManager = userAccessManager;
            this.MaxUploadSizeInMB = maxUploadSizeInMB;
        }

        private enum DataValidationType
        {
            None = 0,
            ShortData = 1,
            DoubleData = 2,
            IntData = 3
        }

        private string[] GetFactFieldNames(FactDimension[] factDimensions, FactTableKnownValues.FactUploadType factUploadType, bool isForBinding)
        {
            List<string> factFieldNameList = new List<string>();
            string prefix = (isForBinding == true ? ":" : string.Empty);
            foreach (var d in factDimensions)
            {
                factFieldNameList.Add(prefix + d.StageTableColumnName);
            }

            if (factUploadType == FactTableKnownValues.FactUploadType.Month)
            {
                if (string.IsNullOrEmpty(prefix))
                {
                    factFieldNameList.AddRange(FactTableKnownValues.FactMonthTypeUploadKnownColumns);
                }
                else
                {
                    foreach (var fieldName in FactTableKnownValues.FactMonthTypeUploadKnownColumns)
                    {
                        factFieldNameList.Add(prefix + fieldName);
                    }
                }

            }

            if (factUploadType == FactTableKnownValues.FactUploadType.Yearly)
            {
                if (string.IsNullOrEmpty(prefix))
                {
                    factFieldNameList.AddRange(FactTableKnownValues.FactYearTypeUploadKnownColumns);
                }
                else
                {
                    foreach (var fieldName in FactTableKnownValues.FactYearTypeUploadKnownColumns)
                    {
                        factFieldNameList.Add(prefix + fieldName);
                    }
                }
            }
            return factFieldNameList.ToArray();
        }

        //private string GetColumnsForBinding(List<string> columnList)
        //{
        //    foreach()
        //}

        private bool isValidatableColumn(string colName)
        {
            if (FactTableKnownValues.FactMonthTypeUploadKnownColumns.Contains(colName) || FactTableKnownValues.FactYearTypeUploadKnownColumns.Contains(colName))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private FactProcessUploadedFileResponse UploadFactDataCore(FactProcessUploadedFileRequest processRequest)
        {

            FactProcessUploadedFileResponse response = new FactProcessUploadedFileResponse();
            List<string> factFieldNames = null;
            Dictionary<string, int> fieldReferences = new Dictionary<string, int>();


            if (processRequest == null)
            {
                response.MessageType = FactTableKnownValues.ResponseMsgType.Fatal;
                response.Message = "processRequest cannot be null";
                return response;
            }

            if (string.IsNullOrEmpty(processRequest.SignedUrl))
            {
                response.MessageType = FactTableKnownValues.ResponseMsgType.Fatal;
                response.Message = "processRequest.SignedUrl cannot be empty";
                return response;
            }

            if (processRequest.ReportingPeriod == null)
            {
                response.MessageType = FactTableKnownValues.ResponseMsgType.Fatal;
                response.Message = "processRequest.ReportingPeriod cannot be null";
                return response;
            }

            if (processRequest.ReportingPeriod.Month <= 0 && processRequest.ReportingPeriod.Month > 12)
            {
                response.MessageType = FactTableKnownValues.ResponseMsgType.Error;
                response.Message = "Invalid reporting period";
                return response;
            }

            string uploadFileName = securityManager.GetContentFromSignedUrl(processRequest.UserId, processRequest.SignedUrl);

            //Verify Signed url
            string verifiedUserId = securityManager.VerifySignedUrlKey(uploadFileName, processRequest.SignedUrl);

            if (string.IsNullOrEmpty(verifiedUserId) || verifiedUserId != processRequest.UserId)
            {
                response.MessageType = FactTableKnownValues.ResponseMsgType.Error;
                response.Message = "Invalid signed url";
                return response;
            }

            try
            {
                Utility.SanitizeFilePath(factFileArchiveDir, uploadFileName, new string[] { ".xlsx", ".xls" });
            }
            catch (Exception ex)
            {
                response.MessageType = FactTableKnownValues.ResponseMsgType.Error;
                response.Message = ex.Message;
                return response;
            }
            

            //validate if file uploaded is within allowed limit
            long uploadedFileSize = new System.IO.FileInfo(uploadFileName).Length;
            if (Utility.ConvertBytesToMegabytes(uploadedFileSize) > MaxUploadSizeInMB)
            {
                response.MessageType = FactTableKnownValues.ResponseMsgType.Error;
                response.Message = string.Format("File uploaded is more than permissible limit (Max limit is {0} MB)", MaxUploadSizeInMB);
                return response;
            }


            var factSettings = factTableManager.GetFactTableSetting(processRequest.UserId);
            var userInfo = userAccessManager.GetUser(processRequest.UserId);

            if (factSettings == null || string.IsNullOrEmpty(factSettings.CurrentMonth) || string.IsNullOrEmpty(factSettings.CurrentYear))
            {
                response.MessageType = FactTableKnownValues.ResponseMsgType.Fatal;
                response.Message = "Fact Settings cannot be retreived";
                return response;
            }

            //Stage Excel contents
            var factTable = factTableManager.GetFactTable(processRequest.UserId, processRequest.FactTableId);
            ////Get file type                
            var fileTypeRequest = new FileTypeRequest() { FactTableId = processRequest.FactTableId, FileTypeCodeId = processRequest.FileTypeCodeId};
            var factFileType = factTableManager.GetFactFileType(processRequest.UserId, fileTypeRequest);

            var knownColumns = FactTableKnownValues.GetFactKnownColumns(factFileType.Contains13ColFacts || factFileType.IsOutlook);

            List<string> availableDimensions = new List<string>();
            List<string> dimensionStageColName = new List<string>();
            if (processRequest.UploadProcessType == FactTableKnownValues.FactUploadProcessType.KeyCombo)
            {
                foreach (var dimension in factTable.AvailableDimensions)
                {
                    if (dimension.IsKeyComboField == true)
                    {
                        availableDimensions.Add(dimension.Code);
                        dimensionStageColName.Add(dimension.StageTableColumnName);
                    }
                }
            }
            else
            {
                foreach (var dimension in factTable.AvailableDimensions)
                {
                    availableDimensions.Add(dimension.Code);
                    dimensionStageColName.Add(dimension.StageTableColumnName);
                }
            }

            List<string> excelFieldNames = new List<string>();
            //foreach (var dimension in factTable.AvailableDimensions)
            //{
            //    excelFieldNames.Add(dimension.Code);
            //}
            excelFieldNames.AddRange(availableDimensions);
            if (processRequest.UploadProcessType == FactTableKnownValues.FactUploadProcessType.FactData)
            {
                foreach (var kc in knownColumns)
                {
                    excelFieldNames.Add(kc.Name);
                }
            }

            List<string> excel13MFieldNames = new List<string>();
            //foreach (var dimension in factTable.AvailableDimensions)
            //{
            //    excel13MFieldNames.Add(dimension.Code);                
            //}
            excel13MFieldNames.AddRange(availableDimensions);
            if (processRequest.UploadProcessType == FactTableKnownValues.FactUploadProcessType.FactData)
            {
                foreach (var kc in knownColumns)
                {
                    excel13MFieldNames.Add(kc.Name);
                }   
            }

            List<string> sqlFieldNames = new List<string>();
            sqlFieldNames.Add("line_number");
            
            //sqlFieldNames.AddRange(availableDimensions);
            sqlFieldNames.AddRange(dimensionStageColName);
            if (processRequest.UploadProcessType == FactTableKnownValues.FactUploadProcessType.FactData)
            {
                foreach (var kc in knownColumns)
                {
                    sqlFieldNames.Add(kc.Name);
                }
                
            }
            



            
            factFieldNames = new List<string>();
            if (factFileType.Contains13ColFacts || factFileType.IsOutlook)
            {
                factFieldNames.AddRange(excel13MFieldNames);
            }
            else
            {
                factFieldNames.AddRange(excelFieldNames);
            }

            if (factTable == null)
            {
                //TODO: handle user access

            }

            ////Open excel and read contents

            //validate fields
            List<string> missingUploadFields = new List<string>();
            var sqlText = string.Format(" select * from [{0}$]", factFileType.Code);

            Dictionary<string, List<string>> factDataDiction = new Dictionary<string, List<string>>();
            try
            {
                using (OleDbConnection excelConnection = new OleDbConnection(Utility.GetExcelConnectionString(uploadFileName)))
                using (OleDbCommand excelCommand = new OleDbCommand(sqlText, excelConnection))
                {
                    excelConnection.Open();

                    using (OleDbDataReader excelReader = excelCommand.ExecuteReader())
                    {
                        for (int i = 0; i < factFieldNames.Count; i++)
                        {
                            bool matchWasFound = false;
                            for (int j = 0; j < excelReader.VisibleFieldCount; j++)
                            {
                                if (factFieldNames[i].Equals(excelReader.GetName(j).ToUpper()))
                                {
                                    matchWasFound = true;
                                    fieldReferences.Add(factFieldNames[i], j);  // capture index for later use
                                    break;
                                }
                            }
                            if (!matchWasFound)
                            {
                                missingUploadFields.Add(factFieldNames[i]);
                            }

                        }

                        if (missingUploadFields.Count > 0)
                        {
                            response.MessageType = FactTableKnownValues.ResponseMsgType.Error;
                            response.Message = string.Format("The Load Process failed to find the following field(s) in the file: {0}", string.Join(", ", missingUploadFields));
                            response.RunStatusId = -1;
                            return response;
                        }


                        //factDataDiction is should be based on excelFieldNames
                        //foreach (var colName in sqlFieldNames)
                        //{
                        //    factDataDiction.Add(colName, new List<string>());
                        //}
                        factDataDiction.Add("line_number", new List<string>());
                        foreach (var colName in excelFieldNames)
                        {
                            factDataDiction.Add(colName, new List<string>());
                        }

                        int excelReadCounter = 0;
                        int nullRowCounter = 0;
                        int rowsSkipped = 0;

                        while (excelReader.Read())
                        {
                            excelReadCounter++;
                            nullRowCounter = 0;
                            foreach (int i in fieldReferences.Values)
                            {
                                if (excelReader.IsDBNull(i))
                                {
                                    nullRowCounter++;
                                }
                            }

                            //TODO: why -2 ?
                            if (nullRowCounter >= factFieldNames.Count - 2)
                            {
                                rowsSkipped++;
                                continue;
                            }

                            factDataDiction["line_number"].Add(Convert.ToString(excelReadCounter));

                            //collect the values from dimensions
                            foreach (var dimension in availableDimensions)
                            {
                                factDataDiction[dimension].Add(excelReader.GetValue(fieldReferences[dimension]).ToString().Trim());
                            }
                           
                            //collect the values from known columns after validation
                            if (processRequest.UploadProcessType == FactTableKnownValues.FactUploadProcessType.FactData)
                            {
                                foreach (var kc in knownColumns)
                                {
                                    string validatedData = string.Empty;

                                    if (kc.ValidationType == FactTableKnownValues.FactKnownColumnValidationType.DoubleData)
                                    {
                                        var data = Convert.ToString(excelReader.GetValue(fieldReferences[kc.Name]));
                                        if(String.IsNullOrEmpty(data)) 
                                            validatedData = null;
                                        else 
                                            try
                                            {
                                                validatedData = decimal.Parse(data, System.Globalization.NumberStyles.Currency | System.Globalization.NumberStyles.AllowExponent).ToString();
                                            }
                                            catch (FormatException)
                                            {
                                                response.MessageType = FactTableKnownValues.ResponseMsgType.Error;
                                                response.Message = string.Format("The column '{0}' in row {1} contains a non-numeric or null value.", kc.Name, excelReadCounter);
                                                return response;
                                            }
                                    }
                                    else if (kc.ValidationType == FactTableKnownValues.FactKnownColumnValidationType.ShortData)
                                    {
                                        short shortData;
                                        if (Int16.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences[kc.Name])), out shortData))
                                        {
                                            validatedData = Convert.ToString(shortData);
                                        }
                                        else
                                        {
                                            if ((kc.PeformNullCheckForAdjustment && factFileType.IsAdjustment) || kc.CanAllowNullNonAdjustment == false)
                                            {
                                                response.MessageType = FactTableKnownValues.ResponseMsgType.Error;
                                                response.Message = string.Format("The column '{0}' in row {1} contains an invalid value.", kc.Name, excelReadCounter);
                                                return response;
                                            }
                                            else
                                            {
                                                validatedData = null;
                                            }
                                        }
                                    }
                                    else if (kc.ValidationType == FactTableKnownValues.FactKnownColumnValidationType.IntData)
                                    {
                                        int intData;
                                        if (Int32.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences[kc.Name])).Replace(",", string.Empty).Replace(";", string.Empty), out intData))
                                        {
                                            validatedData = Convert.ToString(intData);
                                        }
                                        else
                                        {
                                            if ((kc.PeformNullCheckForAdjustment && factFileType.IsAdjustment) || kc.CanAllowNullNonAdjustment == false)
                                            {
                                                response.MessageType = FactTableKnownValues.ResponseMsgType.Error;
                                                response.Message = string.Format("The column '{0}' in row {1} contains a non-numeric or null value.", kc.Name, excelReadCounter);
                                                return response;
                                            }
                                            else
                                            {
                                                validatedData = null;
                                            }
                                        }
                                    }

                                    factDataDiction[kc.Name].Add(validatedData);
                                }
                            }
                        }
                    }
                }
            }
            catch (OleDbException)
            {
                response.MessageType = FactTableKnownValues.ResponseMsgType.Error;
                response.Message = string.Format("There was an error opening the Excel file.  Make sure that a Worksheet named '{0}' exists.", factFileType.Code);
                return response;
            }

            TableInfo factTableInfo = new TableInfo();
            factTableInfo.Columns = sqlFieldNames.ToArray();
            factTableInfo.ColumnHeaders = excelFieldNames.ToArray();
            List<ColumnData> factTableData = new List<ColumnData>();
            //foreach (var fieldName in sqlFieldNames)
            foreach (var fieldName in factDataDiction.Keys)
            {
                var col = new ColumnData() { Values = factDataDiction[fieldName].ToArray() };
                factTableData.Add(col);
            }
            factTableInfo.Data = factTableData.ToArray();

            try
            {
                //start process request
                processRequest.RunStatusId = opsStatusDbManager.StartProcess("UploadFactData", factFileType.Code, "Stage data", true, "Stage", string.Empty, string.Empty);
                //stage data
                var stageResponse = factTableUserUploadData.StageExcelContents(processRequest, factTable, factFileType, factTableInfo);

                if (stageResponse.RowsAffected == 0)
                {
                    opsStatusDbManager.EndProcess(processRequest.RunStatusId, "UploadFactData failed - no rows staged");
                    response.MessageType = FactTableKnownValues.ResponseMsgType.Error;
                    response.Message = "There were no rows found in the uploaded spreadsheet";
                    return response;
                }
                else
                {
                    //start process staged data step
                    opsStatusDbManager.StartStep(processRequest.RunStatusId, "ProcessStagedData", "Validate", string.Empty, string.Empty);
                    //Process Staged contents
                    var processResponse = factTableUserUploadData.ProcessStagedData(processRequest, factTable, factFileType, factTableInfo);
                    //end process staged data step
                    opsStatusDbManager.EndStep(processRequest.RunStatusId);

                    //end process request
                    opsStatusDbManager.EndProcess(processRequest.RunStatusId, "UploadFactData completed successfully");

                    //Get status and send response back
                    response = processResponse;


                    //Set message type to success when StageProcessStatus is -2; this means, it suceeded but has warning
                    if (response.StageProcessStatus == FactTableKnownValues.StageProcessingStatus.TransactionLevelWarning)
                    {
                        response.MessageType = FactTableKnownValues.ResponseMsgType.Success;
                    }

                    //Set message type to error when it has at least one transactional error message because UI only looks for MessageType                    
                    if (response.TransactionalMessages != null && response.TransactionalMessages.FirstOrDefault(m => m.MessageType == FactTableKnownValues.StageProcessingStatus.TransactionLevelError) != null)
                    {
                        response.MessageType = FactTableKnownValues.ResponseMsgType.Error;
                        response.Message = "Uploading fact data failed";
                    }


                }
            }
            catch
            {
                response.MessageType = FactTableKnownValues.ResponseMsgType.Fatal;
                response.Message = "Error uploading fact data";
                opsStatusDbManager.EndProcess(processRequest.RunStatusId, "UploadFactData failed");
                throw;
            }
            response.RunStatusId = processRequest.RunStatusId;
            return response;
        }

        private FactProcessUploadedFileResponse AddKeysAndUploadFactCore(FactProcessUploadedFileRequest processRequest)
        {

            FactProcessUploadedFileResponse response = new FactProcessUploadedFileResponse();
            Dictionary<string, int> fieldReferences = new Dictionary<string, int>();


            if (processRequest == null)
            {
                response.MessageType = FactTableKnownValues.ResponseMsgType.Fatal;
                response.Message = "processRequest cannot be null";
                return response;
            }


            //Stage Excel contents
            var factTable = factTableManager.GetFactTable(processRequest.UserId, processRequest.FactTableId);
            ////Get file type                
            var fileTypeRequest = new FileTypeRequest() { FactTableId = processRequest.FactTableId, FileTypeCodeId = processRequest.FileTypeCodeId };
            var factFileType = factTableManager.GetFactFileType(processRequest.UserId, fileTypeRequest);

            var knownColumns = FactTableKnownValues.GetFactKnownColumns(factFileType.Contains13ColFacts || factFileType.IsOutlook);

            List<string> sqlFieldNames = new List<string>();
            sqlFieldNames.Add("line_number");

            List<string> dimensionStageColName = new List<string>();
            foreach (var dimension in factTable.AvailableDimensions)
            {
                sqlFieldNames.Add(dimension.Code);
                dimensionStageColName.Add(dimension.StageTableColumnName);
            }
            foreach (var kc in knownColumns)
            {
                sqlFieldNames.Add(kc.Name);
            }

            TableInfo factTableInfo = new TableInfo();
            factTableInfo.ColumnHeaders = sqlFieldNames.ToArray();
            factTableInfo.Columns = dimensionStageColName.ToArray();

            try
            {
                //start process staged data step
                opsStatusDbManager.StartStep(processRequest.RunStatusId, "ProcessStagedData", "Validate", string.Empty, string.Empty);
                //Process Staged contents
                var processResponse = factTableUserUploadData.ProcessMissingKeysAndStagedData(processRequest, factTable, factFileType, factTableInfo);
                //end process staged data step
                opsStatusDbManager.EndStep(processRequest.RunStatusId);

                //end process request
                //opsStatusDbManager.EndProcess(processRequest.RunStatusId, "UploadFactData completed successfully");
                //Get status and send response back
                response = processResponse;
            }
            catch
            {
                response.MessageType = FactTableKnownValues.ResponseMsgType.Fatal;
                response.Message = "Error uploading fact data";
                opsStatusDbManager.EndProcess(processRequest.RunStatusId, "ProcessMissingKeysAndStagedData failed");
                throw;
            }
            response.RunStatusId = processRequest.RunStatusId;
            return response;
        }

        public string UploadFactFile(string userId, string fileTypeName, string base64EncodedFile)
        {
            Byte[] fileInByteArray = Convert.FromBase64String(base64EncodedFile);
            //string filename = string.Format("Archive/{1}_{2}_{0}{3}", DateTime.Now.ToString("yyyyMMdd_HHmmss"), userId, fileTypeName, ".xlsx");
            string filename = string.Format(@"{0}\{1}_{2}_{3}", factFileArchiveDir, userId, DateTime.Now.ToString("yyyyMMdd_HHmmss"), fileTypeName);
            File.WriteAllBytes(filename, fileInByteArray);
            return securityManager.GetSignedUrlKey(userId, filename);
        }

        public FactProcessUploadedFileResponse UploadFactData(FactProcessUploadedFileRequest processRequest)
        {
            return UploadFactDataCore(processRequest);
        }


        public string[] GetDimYears()
        {
            List<string> dimyears = new List<string>();
            int currentYear = DateTime.Now.Year;

            for (int prevYearCounter = 7; prevYearCounter > 0; prevYearCounter--) 
            {
                dimyears.Add(Convert.ToString(currentYear - prevYearCounter));
            }

            dimyears.Add(Convert.ToString(currentYear));

            for (int futureYearCounter = 1; futureYearCounter <= 9; futureYearCounter++)
            {
                dimyears.Add(Convert.ToString(currentYear + futureYearCounter));
            }


            //    dimyears.Add("2015");
            //dimyears.Add("2016");
            //dimyears.Add("2017");
            //dimyears.Add("2018");
            //dimyears.Add("2019");
            //dimyears.Add("2020");
            //dimyears.Add("2021");
            return dimyears.ToArray();
            //return factTableUserUploadData.GetDimYears();
        }


        public FactProcessUploadedFileResponse AddKeysFromStagedData(string userId, long runStatusId, long factTableId, long factFileTypeId)
        {
            return factTableUserUploadData.AddKeysFromStagedData(userId, runStatusId, factTableId, factFileTypeId);
        }


        public FactProcessUploadedFileResponse AddKeysAndUploadFact(FactProcessUploadedFileRequest processRequest)
        {
            return AddKeysAndUploadFactCore(processRequest);
        }

        public double GetMaxUploadFileSize()
        {
            return MaxUploadSizeInMB;
        }

        public string UploadFactFileByte(string userId, string fileTypeName, byte[] fileInBytes)
        {
            string filename = Utility.SanitizeFilePath(factFileArchiveDir, string.Format(@"{0}\{1}_{2}_{3}", factFileArchiveDir, userId, DateTime.Now.ToString("yyyyMMdd_HHmmss"), fileTypeName), new string[] {".xls", ".xlsx"});
            File.WriteAllBytes(filename, fileInBytes);
            return securityManager.GetSignedUrlKey(userId, filename);
        }
    }
}
