﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Contracts.Data.MDUA.FactTables;
using VZ.CFO.MDMFramework.Contracts.Data;
using VZ.CFO.MDMFramework.Contracts.Service.MDUA;
using VZ.CFO.MDMFramework.Providers.Data;
using System.IO;
namespace VZ.CFO.MDMFramework.Providers.Manager.MDUA
{
    public class FactTableManager : IFactTableManager
    {
        private IFactTableManagerDataProvider dbFactTableManagerDataProvider = null;        

        public FactTableManager(IFactTableManagerDataProvider dbFactTableManagerDataProvider)
        {
            this.dbFactTableManagerDataProvider = dbFactTableManagerDataProvider;
        }
        public FactTable[] GetAllFactTables(string userId)
        {
            return dbFactTableManagerDataProvider.GetAllFactTables(userId);
        }

        public FactTable GetFactTable(string userId, long factTableId)
        {
            return dbFactTableManagerDataProvider.GetFactTable(userId, factTableId);
        }
        public FactFileType[] GetFactFileTypes(string userId,long factTableId)
        {
            return dbFactTableManagerDataProvider.GetFactFileTypes(userId, factTableId);
        }

        public FactTable[] GetFactFileTypesBasic(string userId)
        {
            return dbFactTableManagerDataProvider.GetFactFileTypesBasic(userId);
        }
        public FactFileType GetFactFileType(string userId, FileTypeRequest fileTypeRequest)
        {
            return dbFactTableManagerDataProvider.GetFactFileType(userId, fileTypeRequest);
        }
        public FileTypeResponse SaveFileType(string userId, FactFileType factFileType)
        {
            return dbFactTableManagerDataProvider.SaveFileType(userId, factFileType);
        }
        public FileTypeResponse DeleteFileType(string userId, FileTypeRequest fileTypeRequest)
        {
            return dbFactTableManagerDataProvider.DeleteFileType(userId, fileTypeRequest);
        }
       
        public KeyComboResponse GetKeyCombinations(string userId, KeyComboRequest keyComboRequest)
        {
            return dbFactTableManagerDataProvider.GetKeyCombinations(userId, keyComboRequest);
        }
        public KeyComboDeleteResponse DeleteKeyCombinations(string userId, KeyComboDeleteRequest keyComboDeleteRequest)
        {
            return dbFactTableManagerDataProvider.DeleteKeyCombinations(userId, keyComboDeleteRequest);
        }
     
        public KeyComboMoveResponse MoveKeyCombinations(string userId, KeyComboMoveRequest keyComboMoveRequest)
        {
            return dbFactTableManagerDataProvider.MoveKeyCombinations(userId, keyComboMoveRequest);
        }

        public TableInfo GetTableInfo(string userId, long tableId)
        {
            return dbFactTableManagerDataProvider.GetTableInfo(userId, tableId);
        }
        public FactTable GetFactTableBasicInfo(string userId, long tableId)
        {
            return dbFactTableManagerDataProvider.GetFactTableBasicInfo(userId, tableId);
        }
        public string GetDbConnectionString(string dbProfileName)
        {
            return dbFactTableManagerDataProvider.GetDbConnectionString(dbProfileName);
        }

        public string GetFileTypeCodeById(long factTableId, long fileTypeCodeId)
        {
            return dbFactTableManagerDataProvider.GetFileTypeCodeById(factTableId, fileTypeCodeId);
        }

        public string GetPagingQueryTemplate()
        {
            return dbFactTableManagerDataProvider.GetPagingQueryTemplate();
        }


        public FactTableSettings GetFactTableSetting(string userId)
        {
            return dbFactTableManagerDataProvider.GetFactTableSetting(userId);
        }


        public FactProcessUploadedFileResponse GetAuditData(string userId, FactAuditRequest auditRequest)
        {
            FactTable factTable = GetFactTable(userId, auditRequest.FactTableId);
            return dbFactTableManagerDataProvider.GetAuditData(userId, auditRequest, factTable);
        }


        public string[] GetDimensionValues(string userId, FactAuditRequest auditRequest)
        {
            FactTable factTable = GetFactTable(userId, auditRequest.FactTableId);
            return dbFactTableManagerDataProvider.GetDimensionValues(userId, auditRequest, factTable);
        }

        public string ExportAuditData(string userId, FactAuditRequest auditRequest)
        {
            string fileAsBase64String = string.Empty;
            FactProcessUploadedFileResponse auditResponse = GetAuditData(userId, auditRequest);

            //generate a temp file in the system's temp location
            var fileName = System.IO.Path.GetTempFileName();
            //Write it to mapping file
            if (WriteAuditDataToCsv(fileName, auditResponse.ResponseTableColumns, auditResponse.ResponseTableData))
            {
                //Convert the temp file to binary
                byte[] csvBinary = File.ReadAllBytes(fileName);
                //convert binary to base64 string
                fileAsBase64String = Convert.ToBase64String(csvBinary);
            }

            //return csv file as base64 string
            return fileAsBase64String;
        }

        public static bool WriteAuditDataToCsv(string filename, string[] columnHeaders, ColumnData[] columnData)
        {
            bool returnValue = false;
            try
            {
                using (StreamWriter writer = new StreamWriter(filename))
                {
                    writer.WriteLine(string.Join(",", columnHeaders));

                    for (int rowIndex = 0; rowIndex < columnData[0].Values.Length; rowIndex++)
                    {
                        List<string> rowStringArray = new List<string>();
                        for (int colIndex = 0; colIndex < columnData.Length; colIndex++)
                        {
                            rowStringArray.Add(string.Format("\"{0}\"", columnData[colIndex].Values[rowIndex]));
                        }
                        writer.WriteLine(string.Join(",", rowStringArray.ToArray()));
                    }

                    writer.Dispose();
                }

                returnValue = true;
            }
            catch
            {
                //TODO: Handle exception
                returnValue = false;
            }
            return returnValue;
        }


        public FactReportingPeriod GetCurrentPeriod(string userId, long factTableId)
        {
            return dbFactTableManagerDataProvider.GetCurrentPeriod(userId, factTableId);
        }
    }
}
