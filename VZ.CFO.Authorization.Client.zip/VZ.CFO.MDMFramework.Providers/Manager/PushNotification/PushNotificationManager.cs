﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Providers.Manager.PushNotification
{
    public class PushNotificationManager : VZ.CFO.MDMFramework.Contracts.Service.PushNotification.IPushNotificationService
    {
        private static Contracts.Data.PushNotification.PushNotificationCallback _pushCallback = null;
        private Contracts.Service.PushNotification.IPushNotificationService pushNotificationDBManager = null;
        private List<Contracts.Data.PushNotification.PushNotificationClientInfo> connectedClients = null;
        public PushNotificationManager(Contracts.Service.PushNotification.IPushNotificationService pushNotificationDBManager)
        {
            this.pushNotificationDBManager = pushNotificationDBManager;
            connectedClients = new List<Contracts.Data.PushNotification.PushNotificationClientInfo>();
            _pushCallback = pushNotificationDBManager.GetPushNotificationCallbackRef();
        }

        public bool IsRunning()
        {
            return pushNotificationDBManager.IsRunning();
        }

        public void StartService()
        {
            pushNotificationDBManager.StartService();
        }

        public void StopService()
        {
            pushNotificationDBManager.StopService();
        }

        public string ClientSubscription(string clientId, string appName, string appModule)
        {
            if(connectedClients.Count == 0 && pushNotificationDBManager.IsRunning() == false)
            {
                pushNotificationDBManager.StartService();
            }
            connectedClients.Add(new Contracts.Data.PushNotification.PushNotificationClientInfo() { ClientId = clientId, ApplicationName = appName, ApplicationModuleName  = appModule } );
            return clientId;
        }

        public bool ClientUnSubscribe(string clientId)
        {
            bool returnValue = false;

            var unSubscribedClient = connectedClients.FirstOrDefault(c => c.ClientId == clientId);
            if(unSubscribedClient != null)
            {
                returnValue = connectedClients.Remove(unSubscribedClient);
            }

            if(connectedClients.Count == 0 && pushNotificationDBManager.IsRunning() == true)
            {
                pushNotificationDBManager.StopService();
            }
            
            return returnValue;
        }

        public Contracts.Data.PushNotification.PushNotificationCallback GetPushNotificationCallbackRef()
        {
            return _pushCallback;
        }
    }
}
