﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.Providers
{
    public class PushNotificationDataDataProvider : DataProvider
    {
        protected Contracts.Data.PushNotification.PushNotificationCallback pushCallBack { get; private set; }

        public PushNotificationDataDataProvider(string connectionString, string encryptionSalt, Contracts.Data.PushNotification.PushNotificationCallback pushCallback)
            : base(connectionString, encryptionSalt)
        {
            this.pushCallBack = pushCallback;
        }
    }
}
