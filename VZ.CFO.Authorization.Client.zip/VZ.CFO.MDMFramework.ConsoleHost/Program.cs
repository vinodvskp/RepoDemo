﻿using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.MDMFramework.Configuration;
using Microsoft.Owin.Hosting;

namespace VZ.CFO.MDMFramework.ConsoleHost
{
    internal sealed class Program
    {
        static void Main(string[] args)
        {

            //string baseAddress = "http://localhost:9012/";

            //Services.Startup.Startup.RegisterDataProviders(new Configuration.ServerConfigurationManager(new Configuration.FileBasedConfigDataProvider()));

            ////Start OWIN Host
            //System.Console.WriteLine("Starting Webapi Server");
            //using (WebApp.Start<Services.Startup.Startup>(url: baseAddress))
            //{
            //    System.Console.WriteLine(String.Format("WebApi server started at: {0}", baseAddress));
            //    DisplayServiceRoutes();
            //    System.Console.WriteLine("Press ENTER to stop it...");
            //    System.Console.ReadLine();
            //}
            RegisterDataProvider(new Configuration.ServerConfigurationManager(new Configuration.FileBasedConfigDataProvider()));
        }

        //private static void DisplayServiceRoutes()
        //{
        //    ServiceRouteParser parser = new ServiceRouteParser();
        //    parser.RouteFound += parser_RouteFound;
        //    System.Console.WriteLine("Supported routes...");
        //    parser.TraverseServiceRoutes<Services.Startup.Startup, Services.Controllers.MappingTableMgmt.MappingTableMgmtController>();
        //}

        //private static void parser_RouteFound(object sender, ServiceRouteParser.RouteEventArgs e)
        //{
        //    System.Console.WriteLine("\t" + e.Path + "\t" + e.Verbs);
        //}

        private static void RegisterDataProvider(ConfigurationManager config)
        {

            //register configuration provider, in case its needed elsewhere            
            Microsoft.Practices.Unity.UnityContainer container = new Microsoft.Practices.Unity.UnityContainer();
            container.RegisterInstance(typeof(Configuration.IConfigurationManager), typeof(Configuration.IConfigurationManager).Name, config,
                new ContainerControlledLifetimeManager());

            container.RegisterInstance(typeof(Providers.MappingTableDataProvider), typeof(Providers.MappingTableDataProvider).Name, config.CreateMappingTableDataProvider(""), 
                new ContainerControlledLifetimeManager());

            Providers.DataProviderFactory.ActivateFactoryInstace(container);
        }

    }
}
