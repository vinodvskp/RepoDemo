﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.ConsoleHost
{
    public class ServiceRouteParser
    {
        public class RouteEventArgs : EventArgs
        {
            /// <summary>
            /// Initializes a new instance of the <see cref="RouteEventArgs"/> class.
            /// </summary>
            /// <param name="path">The path.</param>
            /// <param name="verbs">The verbs.</param>
            public RouteEventArgs(string path, string verbs)
            {
                this.Path = path;
                this.Verbs = verbs;
            }

            public string Path { get; private set; }

            /// <summary>
            /// Gets the verbs.
            /// </summary>
            /// <value>
            /// The verbs.
            /// </value>
            public string Verbs { get; private set; }
        }

        public event EventHandler<RouteEventArgs> RouteFound;

        /// <summary>
        /// Formats the HTTP action.
        /// </summary>
        private static string FormatHttpAction(System.Web.Http.Controllers.IActionHttpMethodProvider action)
        {
            if (null == action)
            {
                return string.Empty;
            }

            string verb = string.Empty;

            foreach (var method in action.HttpMethods)
            {
                if (verb.Length > 0)
                {
                    verb += ", ";
                }
                verb += method.Method;
            }

            return verb;
        }

        /// <summary>
        /// Traverses the service routes.
        /// </summary>
        /// <typeparam name="TAssembly">Type that represents a class within an assembly that contains the service implementation</typeparam>
        /// <typeparam name="TBase">Type that represents a base class used to determine service type eligibility</typeparam>
        public void TraverseServiceRoutes<TAssembly, TBase>()
        {
            Type[] serviceTypes = typeof(TAssembly).Assembly.GetTypes();
            SortedSet<string> list = new SortedSet<string>();
            Dictionary<string, List<string>> pathVerbs = new Dictionary<string, List<string>>();

            foreach (Type t in serviceTypes)
            {
                if (false == typeof(TBase).IsAssignableFrom(t))
                {
                    continue;
                }

                string prefix = string.Empty;

                object[] routes = t.GetCustomAttributes(typeof(System.Web.Http.RoutePrefixAttribute), false);
                if (null != routes && routes.Length > 0)
                {
                    System.Web.Http.RoutePrefixAttribute route = routes[0] as System.Web.Http.RoutePrefixAttribute;
                    if (null != route)
                    {
                        prefix = route.Prefix;
                    }
                }

                //enumerate over methods
                System.Reflection.MethodInfo[] methods = t.GetMethods(System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance);
                foreach (System.Reflection.MethodInfo method in methods)
                {
                    object[] mroutes = method.GetCustomAttributes(typeof(System.Web.Http.RouteAttribute), false);
                    if (null != mroutes && mroutes.Length > 0)
                    {
                        System.Web.Http.RouteAttribute route = mroutes[0] as System.Web.Http.RouteAttribute;
                        if (null == route)
                        {
                            continue;
                        }

                        object[] verbs = method.GetCustomAttributes(typeof(System.Web.Http.Controllers.IActionHttpMethodProvider), false);

                        string verb = string.Empty;
                        if (verbs != null && verbs.Length > 0)
                        {
                            verb = FormatHttpAction(verbs[0] as System.Web.Http.Controllers.IActionHttpMethodProvider);
                        }

                        string path = prefix + "/" + route.Template;
                        list.Add(path);
                        if (false == pathVerbs.ContainsKey(path))
                        {
                            pathVerbs.Add(path, new List<string>());
                        }

                        pathVerbs[path].Add(verb);
                    }
                }
            }

            foreach (string item in list)
            {
                string verbs = string.Empty;
                if (pathVerbs.ContainsKey(item))
                {
                    foreach (string verb in pathVerbs[item])
                    {
                        if (verbs.Length > 0)
                        {
                            verbs += ", ";
                        }
                        verbs += verb;
                    }
                }

                OnRouteFound(item, verbs);
            }
        }

        /// <summary>
        /// Traverse when Route Found.
        /// </summary>
        /// <param name="path">The path.</param>
        /// <param name="verbs">The verbs.</param>
        private void OnRouteFound(string path, string verbs)
        {
            if (null == RouteFound)
            {
                return;
            }

            RouteFound(this, new RouteEventArgs(path, verbs));
        }
    }
}
