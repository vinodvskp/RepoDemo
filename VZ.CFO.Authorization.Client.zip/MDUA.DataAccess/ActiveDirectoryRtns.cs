using System;
using System.Collections;
using System.Configuration;
using System.DirectoryServices;
using MDUA.DTO;

namespace MDUA.DataAccess
{

    /// <summary>
    ///  ActiveDirectoryRtns class handles user info from Hyperion Reporting AD Group
    /// </summary>
    public class ActiveDirectoryRtns
    {
        public class ADUserInfo
        {
            public string FirstName = "";
            public string LastName = "";
            public string email = "";
            public string EmployeeId = "";
            public string EmployeeNumber = "";
            public string UserId = "";

            public ADUserInfo()
            {
            }
        }

        public ActiveDirectoryRtns()
        {
        }

        private static DirectorySearcher getSearcher() {
            DirectoryEntry entry = new DirectoryEntry();
            entry.Path = ConfigurationManager.AppSettings["ADServer"];
            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["ADUsername"])) {
                entry.Username = ConfigurationManager.AppSettings["ADUsername"];
            }
            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["ADPassword"])) {
                entry.Password = ConfigurationManager.AppSettings["ADPassword"];
            }

            return new DirectorySearcher(entry);
        }

        public static string ExtractUserName(string path)
        {
            string[] userPath = path.Split('\\');
            return userPath[userPath.Length - 1];
        }
        
        public static ArrayList GetADGroupUsers(string groupName)
        {
            SearchResult result;
            DirectorySearcher search = getSearcher();
            search.Filter = string.Format("(cn={0})", groupName);
            search.PropertiesToLoad.Add("member");

            ArrayList arrNames = new ArrayList();

            try
            {
                result = search.FindOne();
            }
            catch (DirectoryServicesCOMException dsce)
            {
                MDUA.DataAccess.GeneralDatabaseAccess.LogEvent(null, "ActiveDirectoryRtns.GetADGroupUsers", dsce.Message, "Failure", UserToolLogLevel.Error);
                return arrNames;
            }

            if (result != null)
            {
                for (int counter = 0; counter < result.Properties["member"].Count; counter++)
                {
                    // "CN=Bellone\\, Patrick bellopa,OU=IT,OU=Users,OU=HQ,DC=uswin,DC=ad,DC=vzwcorp,DC=com"
                    string MemberInfo = (string)result.Properties["member"][counter];
                    int Start = MemberInfo.IndexOf("CN=");
                    if (Start >= 0)
                    {
                        int End = MemberInfo.IndexOf('=', Start + 3);
                        if (End < 0)
                            MemberInfo = MemberInfo.Substring(Start + 3);
                        else
                        {
                            End = MemberInfo.Substring(Start + 3, End - Start).LastIndexOf(',');
                            MemberInfo = MemberInfo.Substring(Start + 3, End);
                        }

                        Start = MemberInfo.LastIndexOf(' ');
                        arrNames.Add(MemberInfo.Substring(Start + 1));
                    }
                }
            }

            return arrNames;
        }

        public static ArrayList ADSearchUsers(string groupName)
        {
            ArrayList arrUsers = GetADGroupUsers(groupName);
            if (arrUsers == null || arrUsers.Count == 0)
                return null;

            DirectorySearcher mySearcher = getSearcher();
            mySearcher.PageSize = 10;
            mySearcher.CacheResults = false;

            //Add all properties that need to be fetched   
            mySearcher.PropertiesToLoad.Add("samAccountName");
            mySearcher.PropertiesToLoad.Add("employeeid");
            mySearcher.PropertiesToLoad.Add("employeeNumber");
            mySearcher.PropertiesToLoad.Add("mail");
            mySearcher.PropertiesToLoad.Add("sn");
            mySearcher.PropertiesToLoad.Add("givenname");

            //The search scope specifies how deep the search needs to be, it can be either 
            //"base"- which means only in the current 
            //level, and "OneLevel" which means the
            //base and one level below and then "subtree"-which means the entire tree needs 
            //to be searched.
            mySearcher.SearchScope = SearchScope.Subtree;

            ArrayList arrNames = new ArrayList();
            foreach (string sUser in arrUsers)
            {
                mySearcher.Filter = string.Format("(&(objectCategory=user)(samAccountName={0}))", sUser);
                //mySearcher.Filter = string.Format("(&(objectCategory=user)(cn={0}))", sUser);
                SearchResultCollection resultUsers = mySearcher.FindAll();

                foreach (SearchResult srUser in resultUsers)
                {
                    try
                    {
                        DirectoryEntry de = srUser.GetDirectoryEntry();

                        //  Get the search result from the collection
                        ADUserInfo aui = new ADUserInfo();
                        aui.email = (string)de.Properties["mail"].Value;
                        aui.EmployeeId = (string)de.Properties["employeeid"].Value;
                        aui.EmployeeNumber = (string)de.Properties["employeeNumber"].Value;
                        aui.FirstName = (string)de.Properties["givenname"].Value;
                        aui.LastName = (string)de.Properties["sn"].Value;
                        aui.UserId = (string)de.Properties["samAccountName"].Value;
                        arrNames.Add(aui);

                        de.Close();
                    }

                    catch (Exception ex)
                    {
                        MDUA.DataAccess.GeneralDatabaseAccess.LogEvent(null, "ActiveDirectoryRtns.ADSearchUsers", ex.Message, ex, UserToolLogLevel.FatalError);
                        throw ex;
                    }
                }
            }

            return arrNames;
        }

    } // end of class
} // end of namespace 