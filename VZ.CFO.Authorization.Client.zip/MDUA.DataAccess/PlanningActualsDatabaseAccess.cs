﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Security.Cryptography;
using MDUA.DTO;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;
using System.Reflection;


namespace MDUA.DataAccess {
    public class PlanningActualsDatabaseAccess {

        private static string[] planningFieldNames = new string[] {
            "SCENARIO", "EXTERNAL_SEGMENT", "ACCOUNT", "GL_ACCOUNT", "BUSINESS_SEGMENT"
            , "LINE_OF_BUSINESS", "PRODUCT", "TECH_TYPE", "REGION", "CONTRACT_TERM", "SERVICE_TYPE"
            , "PLANNED_ENTITY", "FUNCTION"
            , "FISCAL_PERIOD", "AMOUNT"
        };

        private static string[] planning13MonthFieldNames = new string[] {
            "SCENARIO", "EXTERNAL_SEGMENT", "ACCOUNT", "GL_ACCOUNT", "BUSINESS_SEGMENT"
            , "LINE_OF_BUSINESS", "PRODUCT", "TECH_TYPE", "REGION", "CONTRACT_TERM", "SERVICE_TYPE"
            , "PLANNED_ENTITY", "FUNCTION"
            , "YEAR", "BEGBAL", "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL"
            , "AUG", "SEP", "OCT", "NOV", "DEC"
        };

        private static int _maxRows = 0;

        private static int MaxRows {
            get {
                if (_maxRows == 0 && !int.TryParse(ConfigurationManager.AppSettings["UploadMaxLinesDisplayed"], out _maxRows))
                    _maxRows = 1000;
                return _maxRows;
            }
        }

        public static int DefaultRowsToFetch {
            get {
                int result;
                return Int32.TryParse(ConfigurationManager.AppSettings["DefaultRowsToFetch"], out result) ? result : 1000;
            }
        }

        public static string GetOracleConnectionString() {
            return ConfigurationManager.ConnectionStrings["PlanningOracle"].ConnectionString;
        }

        public static string GetExcelConnectionString(string filename) {
            string fileExtension = Path.GetExtension(filename).ToLower();
            if (fileExtension.Equals(".xls")) {
                return string.Format(@"Provider=Microsoft.Jet.OLEDB.4.0; Data Source={0};Extended Properties=""Excel 8.0;IMEX=1;""", filename);
            } else if (fileExtension.Equals(".xlsx")) {
                return string.Format(@"Provider=Microsoft.ACE.OLEDB.12.0; Data Source={0};Extended Properties=""Excel 12.0 Xml;IMEX=1;""", filename);
            }
            return string.Empty;
        }

        public PlanningActualsDatabaseAccess() { }
        
        public static ReturnCodeDTO ValidateDimensionValue(string dimensionName, string value) {
            string sqlText = "etl_web_planning.validate_dimension_value";
            ReturnCodeDTO rc = new ReturnCodeDTO();
            try {
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new OracleParameter("@is_valid", OracleDbType.Int32, ParameterDirection.ReturnValue));
                    command.Parameters.Add(new OracleParameter("@i_dimension_name", OracleDbType.Varchar2, dimensionName, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@i_value", OracleDbType.Varchar2, value, ParameterDirection.Input));

                    command.ExecuteNonQuery();
                    if (!Convert.ToBoolean(Convert.ToInt32(command.Parameters["@is_valid"].Value.ToString()))) {
                        rc.Message = string.Format("{0} is not a valid {1} value", value, dimensionName);
                        rc.ReturnCode = 1;
                    }
                    rc.Success = true;
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                rc.Success = false;
                rc.Message = string.Format("There was an error validating the value {0}", value);
            }

            return rc;
        }

        public static int LoadExcelToStage(string filename, FileType fileType, string owner, bool checkFact, out string message, out int runStatusId) {
            const int maxRowsPerUpdate = 2000;
            int totalRecordsAdded = -2;     // total records returned: -1 user error, -2 program error
            int rowsSkipped = 0;
            int currentBindArrayIndex = 0;
            string sqlText = string.Empty;
            DateTime now = DateTime.Now;
            message = string.Empty;         // the return string 
            int excelRowsRead = 0;
            int numberNullFields;
            int index;
            double amountValue;
            short tempShort;
            int tempInt;
            string[] fieldNames = fileType.IsOutlook || fileType.Is13Month ? PlanningActualsDatabaseAccess.planning13MonthFieldNames : PlanningActualsDatabaseAccess.planningFieldNames;
            Dictionary<string, int> fieldReferences = new Dictionary<string, int>();

            List<int> lineNumbersList = new List<int>();
            List<string> scenarioList = new List<string>();
            List<string> externalSegmentList = new List<string>();
            List<string> accountsList = new List<string>();
            List<string> glAccountsList = new List<string>();
            List<string> businessSegmentList = new List<string>();
            List<string> lineOfBusinessList = new List<string>();
            List<string> productList = new List<string>();
            List<string> techTypeList = new List<string>();
            List<string> regionList = new List<string>();
            List<string> contractTermList = new List<string>();
            List<string> serviceTypeList = new List<string>();
            List<string> plannedEntityList = new List<string>();
            List<string> functionList = new List<string>();
            
            List<string> yearList = new List<string>();
            List<string> fiscalPeriodList = new List<string>();
            List<double> amountList = new List<double>();
            List<OracleParameterStatus> amountNullList = new List<OracleParameterStatus>();
            List<double> begbalAmountList = new List<double>();
            List<OracleParameterStatus> begbalAmountNullList = new List<OracleParameterStatus>();
            List<double> januaryAmountList = new List<double>();
            List<OracleParameterStatus> januaryAmountNullList = new List<OracleParameterStatus>();
            List<double> februaryAmountList = new List<double>();
            List<OracleParameterStatus> februaryAmountNullList = new List<OracleParameterStatus>();
            List<double> marchAmountList = new List<double>();
            List<OracleParameterStatus> marchAmountNullList = new List<OracleParameterStatus>();
            List<double> aprilAmountList = new List<double>();
            List<OracleParameterStatus> aprilAmountNullList = new List<OracleParameterStatus>();
            List<double> mayAmountList = new List<double>();
            List<OracleParameterStatus> mayAmountNullList = new List<OracleParameterStatus>();
            List<double> juneAmountList = new List<double>();
            List<OracleParameterStatus> juneAmountNullList = new List<OracleParameterStatus>();
            List<double> julyAmountList = new List<double>();
            List<OracleParameterStatus> julyAmountNullList = new List<OracleParameterStatus>();
            List<double> augustAmountList = new List<double>();
            List<OracleParameterStatus> augustAmountNullList = new List<OracleParameterStatus>();
            List<double> septemberAmountList = new List<double>();
            List<OracleParameterStatus> septemberAmountNullList = new List<OracleParameterStatus>();
            List<double> octoberAmountList = new List<double>();
            List<OracleParameterStatus> octoberAmountNullList = new List<OracleParameterStatus>();
            List<double> novemberAmountList = new List<double>();
            List<OracleParameterStatus> novemberAmountNullList = new List<OracleParameterStatus>();
            List<double> decemberAmountList = new List<double>();
            List<OracleParameterStatus> decemberAmountNullList = new List<OracleParameterStatus>();

            try {
                string missingUploadFields = string.Empty;

                sqlText = string.Format(" select * from [{0}$]", fileType.FileTypeCode);

                using (OleDbConnection excelConnection = new OleDbConnection(GetExcelConnectionString(filename)))
                using (OleDbCommand excelCommand = new OleDbCommand(sqlText, excelConnection)) {
                    excelConnection.Open();

                    using (OleDbDataReader excelReader = excelCommand.ExecuteReader()) {
                        //  Check each field that should be in the file and make sure it is there.
                        for (int i = 0; i < fieldNames.Length; i++) {
                            bool matchWasFound = false;
                            for (int j = 0; j < excelReader.VisibleFieldCount; j++) {
                                if (fieldNames[i].Equals(excelReader.GetName(j).ToUpper())) {
                                    matchWasFound = true;
                                    fieldReferences.Add(fieldNames[i], j);  // capture index for later use
                                    break;
                                }
                            }
                            if (!matchWasFound) {
                                missingUploadFields += "<li>" + fieldNames[i];
                            }
                        }
                        if (missingUploadFields.Length > 1) {
                            message = string.Format("The Load Process failed to find the following field(s) in the file: {0}<br>", missingUploadFields);
                            runStatusId = -1;
                            return -1;
                        }

                        using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                        using (OracleCommand command = connection.CreateCommand()) {
                            connection.Open();
                            using (OracleTransaction transaction = connection.BeginTransaction()) {

                                command.CommandType = CommandType.StoredProcedure;
                                command.CommandText = "etl_web_planning.start_process";

                                command.Parameters.Add(new OracleParameter("@name", OracleDbType.Varchar2, "PLANNING_ACTUALS_UPLOAD", ParameterDirection.Input));
                                command.Parameters.Add(new OracleParameter("@file_type", OracleDbType.Varchar2, fileType.FileTypeCode, ParameterDirection.Input));
                                command.Parameters.Add(new OracleParameter("@run_status_id", OracleDbType.Int32, ParameterDirection.Output));

                                command.ExecuteNonQuery();
                                runStatusId = int.Parse(command.Parameters["@run_status_id"].Value.ToString());

                                command.CommandType = CommandType.Text;
                                command.Parameters.Clear();

                                sqlText = string.Format(
@"insert into {0} (
    line_number, scenario, external_segment, account, gl_account, business_segment
    , line_of_business, product, tech_type, region, contract_term, service_type
    , planned_entity, function
    , source, owner, run_status_id
    {1}
    
  ) values (
    :line_number, :scenario, :external_segment, :account, :gl_account, :business_segment
    , :line_of_business, :product, :tech_type, :region, :contract_term, :service_type
    , :planned_entity, :function
    , '{2}', '{3}', {4}
    {5}
  )"
                                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                                    , checkFact
                                         ? (fileType.Is13Month
                                            ? ", fiscal_year, begbal, jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, dec"
                                            : ", fiscal_period, amount")
                                        : string.Empty
                                    , fileType.FileTypeCode
                                    , owner
                                    , runStatusId
                                    , checkFact
                                        ? (fileType.Is13Month
                                            ? ", :fiscal_year, :begbal, :jan, :feb, :mar, :apr, :may, :jun, :jul, :aug, :sep, :oct, :nov, :dec"
                                            : ", :fiscal_period, :amount")
                                        : string.Empty);

                                command.Parameters.Clear();
                                command.CommandText = sqlText;

                                // add parameters
                                command.Parameters.Add(new OracleParameter(":line_number", OracleDbType.Int32));
                                command.Parameters.Add(new OracleParameter(":scenario", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":external_segment", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":account", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":gl_account", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":business_segment", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":line_of_business", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":product", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":tech_type", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":region", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":contract_term", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":service_type", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":planned_entity", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":function", OracleDbType.Varchar2));
                                
                                if (checkFact) {
                                    if (fileType.Is13Month) {
                                        command.Parameters.Add(new OracleParameter(":fiscal_year", OracleDbType.Varchar2));
                                        command.Parameters.Add(new OracleParameter(":begbal", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":jan", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":feb", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":mar", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":apr", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":may", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":jun", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":jul", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":aug", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":sep", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":oct", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":nov", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":dec", OracleDbType.Double));
                                    } else {
                                        command.Parameters.Add(new OracleParameter(":fiscal_period", OracleDbType.Varchar2));
                                        command.Parameters.Add(new OracleParameter(":amount", OracleDbType.Double));
                                    }
                                }

                                command.BindByName = true;

                                totalRecordsAdded = 0;
                                while (excelReader.Read()) {
                                    excelRowsRead++;
                                    numberNullFields = 0;
                                    foreach (int i in fieldReferences.Values) {
                                        if (excelReader.IsDBNull(i)) numberNullFields++;
                                    }

                                    //TODO: Not sure about - 2
                                    // skip if all fields are null
                                    if (numberNullFields >= fieldNames.Length - 2) {
                                        rowsSkipped++;
                                        continue;
                                    }

                                    #region Add excel rows to lists

                                    lineNumbersList.Add(excelRowsRead);
                                    scenarioList.Add(excelReader.GetValue(fieldReferences["SCENARIO"]).ToString().Trim());
                                    externalSegmentList.Add(excelReader.GetValue(fieldReferences["EXTERNAL_SEGMENT"]).ToString().Trim());
                                    accountsList.Add(excelReader.GetValue(fieldReferences["ACCOUNT"]).ToString().Trim());
                                    glAccountsList.Add(excelReader.GetValue(fieldReferences["GL_ACCOUNT"]).ToString().Trim());
                                    businessSegmentList.Add(excelReader.GetValue(fieldReferences["BUSINESS_SEGMENT"]).ToString().Trim());
                                    lineOfBusinessList.Add(excelReader.GetValue(fieldReferences["LINE_OF_BUSINESS"]).ToString().Trim());
                                    productList.Add(excelReader.GetValue(fieldReferences["PRODUCT"]).ToString().Trim());
                                    techTypeList.Add(excelReader.GetValue(fieldReferences["TECH_TYPE"]).ToString().Trim());
                                    regionList.Add(excelReader.GetValue(fieldReferences["REGION"]).ToString().Trim());
                                    contractTermList.Add(excelReader.GetValue(fieldReferences["CONTRACT_TERM"]).ToString().Trim());
                                    serviceTypeList.Add(excelReader.GetValue(fieldReferences["SERVICE_TYPE"]).ToString().Trim());
                                    plannedEntityList.Add(excelReader.GetValue(fieldReferences["PLANNED_ENTITY"]).ToString().Trim());
                                    functionList.Add(excelReader.GetValue(fieldReferences["FUNCTION"]).ToString().Trim());
                                    
                                    if (checkFact) {
                                        if (fileType.Is13Month || fileType.IsOutlook) {
                                            // validate year is a number
                                            if (!Int16.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["YEAR"])), out tempShort)) {
                                                message = string.Format("The column 'YEAR' in row {0} contains an invalid value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                yearList.Add(Convert.ToString(tempShort));
                                            }

                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["BEGBAL"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                begbalAmountList.Add(amountValue);
                                                begbalAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                begbalAmountList.Add(0); // placeholder in array
                                                begbalAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["JAN"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                januaryAmountList.Add(amountValue);
                                                januaryAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                januaryAmountList.Add(0); // placeholder in array
                                                januaryAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["FEB"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                februaryAmountList.Add(amountValue);
                                                februaryAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                februaryAmountList.Add(0); // placeholder in array
                                                februaryAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["MAR"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                marchAmountList.Add(amountValue);
                                                marchAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                marchAmountList.Add(0); // placeholder in array
                                                marchAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["APR"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                aprilAmountList.Add(amountValue);
                                                aprilAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                aprilAmountList.Add(0); // placeholder in array
                                                aprilAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["MAY"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                mayAmountList.Add(amountValue);
                                                mayAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                mayAmountList.Add(0); // placeholder in array
                                                mayAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["JUN"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                juneAmountList.Add(amountValue);
                                                juneAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                juneAmountList.Add(0); // placeholder in array
                                                juneAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["JUL"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                julyAmountList.Add(amountValue);
                                                julyAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                julyAmountList.Add(0); // placeholder in array
                                                julyAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["AUG"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                augustAmountList.Add(amountValue);
                                                augustAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                augustAmountList.Add(0); // placeholder in array
                                                augustAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["SEP"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                septemberAmountList.Add(amountValue);
                                                septemberAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                septemberAmountList.Add(0); // placeholder in array
                                                septemberAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["OCT"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                octoberAmountList.Add(amountValue);
                                                octoberAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                octoberAmountList.Add(0); // placeholder in array
                                                octoberAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["NOV"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                novemberAmountList.Add(amountValue);
                                                novemberAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                novemberAmountList.Add(0); // placeholder in array
                                                novemberAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["DEC"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                decemberAmountList.Add(amountValue);
                                                decemberAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                decemberAmountList.Add(0); // placeholder in array
                                                decemberAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                        } else {
                                            // validate the fiscal period
                                            if (!Int32.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["FISCAL_PERIOD"])), out tempInt)) {
                                                message = string.Format("Fiscal period in row {0} contains an invalid value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                fiscalPeriodList.Add(Convert.ToString(tempInt));
                                            }

                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["AMOUNT"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                amountList.Add(amountValue);
                                                amountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Amount column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                amountList.Add(0); // placeholder in array
                                                amountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                        }
                                    }

                                    #endregion

                                    currentBindArrayIndex++;
                                    index = 0;
                                    if (currentBindArrayIndex == maxRowsPerUpdate) {
                                        command.Parameters[index].Value = lineNumbersList.ToArray();
                                        command.Parameters[++index].Value = scenarioList.ToArray();                                        
                                        command.Parameters[++index].Value = externalSegmentList.ToArray();
                                        command.Parameters[++index].Value = accountsList.ToArray();
                                        command.Parameters[++index].Value = glAccountsList.ToArray();
                                        command.Parameters[++index].Value = businessSegmentList.ToArray();
                                        command.Parameters[++index].Value = lineOfBusinessList.ToArray();
                                        command.Parameters[++index].Value = productList.ToArray();
                                        command.Parameters[++index].Value = techTypeList.ToArray();
                                        command.Parameters[++index].Value = regionList.ToArray();
                                        command.Parameters[++index].Value = contractTermList.ToArray();
                                        command.Parameters[++index].Value = serviceTypeList.ToArray();
                                        command.Parameters[++index].Value = plannedEntityList.ToArray();
                                        command.Parameters[++index].Value = functionList.ToArray();
                                        
                                        if (checkFact) {
                                            if (fileType.Is13Month || fileType.IsOutlook) {
                                                command.Parameters[++index].Value = yearList.ToArray();
                                                command.Parameters[++index].Value = begbalAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = begbalAmountNullList.ToArray();
                                                command.Parameters[++index].Value = januaryAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = januaryAmountNullList.ToArray();
                                                command.Parameters[++index].Value = februaryAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = februaryAmountNullList.ToArray();
                                                command.Parameters[++index].Value = marchAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = marchAmountNullList.ToArray();
                                                command.Parameters[++index].Value = aprilAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = aprilAmountNullList.ToArray();
                                                command.Parameters[++index].Value = mayAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = mayAmountNullList.ToArray();
                                                command.Parameters[++index].Value = juneAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = juneAmountNullList.ToArray();
                                                command.Parameters[++index].Value = julyAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = julyAmountNullList.ToArray();
                                                command.Parameters[++index].Value = augustAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = augustAmountNullList.ToArray();
                                                command.Parameters[++index].Value = septemberAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = septemberAmountNullList.ToArray();
                                                command.Parameters[++index].Value = octoberAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = octoberAmountNullList.ToArray();
                                                command.Parameters[++index].Value = novemberAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = novemberAmountNullList.ToArray();
                                                command.Parameters[++index].Value = decemberAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = decemberAmountNullList.ToArray();
                                            } else {
                                                command.Parameters[++index].Value = fiscalPeriodList.ToArray();
                                                command.Parameters[++index].Value = amountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = amountNullList.ToArray();
                                            }
                                        }

                                        command.ArrayBindCount = currentBindArrayIndex;
                                        totalRecordsAdded += command.ExecuteNonQuery();
                                        currentBindArrayIndex = 0;
                                        lineNumbersList.Clear();
                                        scenarioList.Clear();
                                        externalSegmentList.Clear();
                                        accountsList.Clear();
                                        glAccountsList.Clear();
                                        businessSegmentList.Clear();
                                        lineOfBusinessList.Clear();
                                        productList.Clear();
                                        techTypeList.Clear();
                                        regionList.Clear();
                                        contractTermList.Clear();
                                        serviceTypeList.Clear();
                                        plannedEntityList.Clear();
                                        functionList.Clear();

                                        if (checkFact) {
                                            if (fileType.Is13Month || fileType.IsOutlook) {
                                                yearList.Clear();
                                                index = command.Parameters.IndexOf(":begbal"); // this offset is important
                                                begbalAmountList.Clear();
                                                begbalAmountNullList.Clear();
                                                command.Parameters[index].ArrayBindStatus = null;
                                                januaryAmountList.Clear();
                                                januaryAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                februaryAmountList.Clear();
                                                februaryAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                marchAmountList.Clear();
                                                marchAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                aprilAmountList.Clear();
                                                aprilAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                mayAmountList.Clear();
                                                mayAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                juneAmountList.Clear();
                                                juneAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                julyAmountList.Clear();
                                                julyAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                augustAmountList.Clear();
                                                augustAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                septemberAmountList.Clear();
                                                septemberAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                octoberAmountList.Clear();
                                                octoberAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                novemberAmountList.Clear();
                                                novemberAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                decemberAmountList.Clear();
                                                decemberAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                            } else {
                                                fiscalPeriodList.Clear();
                                                amountList.Clear();
                                                amountNullList.Clear();
                                                command.Parameters[":amount"].ArrayBindStatus = null;
                                            }
                                        }
                                    }
                                }
                                index = 0;
                                if (currentBindArrayIndex > 0) {
                                    command.Parameters[index].Value = lineNumbersList.ToArray();
                                    command.Parameters[++index].Value = scenarioList.ToArray();
                                    command.Parameters[++index].Value = externalSegmentList.ToArray();
                                    command.Parameters[++index].Value = accountsList.ToArray();
                                    command.Parameters[++index].Value = glAccountsList.ToArray();
                                    command.Parameters[++index].Value = businessSegmentList.ToArray();
                                    command.Parameters[++index].Value = lineOfBusinessList.ToArray();
                                    command.Parameters[++index].Value = productList.ToArray();
                                    command.Parameters[++index].Value = techTypeList.ToArray();
                                    command.Parameters[++index].Value = regionList.ToArray();
                                    command.Parameters[++index].Value = contractTermList.ToArray();
                                    command.Parameters[++index].Value = serviceTypeList.ToArray();
                                    command.Parameters[++index].Value = plannedEntityList.ToArray();
                                    command.Parameters[++index].Value = functionList.ToArray();
                                    
                                    if (checkFact) {
                                        if (fileType.Is13Month || fileType.IsOutlook) {
                                            command.Parameters[++index].Value = yearList.ToArray();
                                            command.Parameters[++index].Value = begbalAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = begbalAmountNullList.ToArray();
                                            command.Parameters[++index].Value = januaryAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = januaryAmountNullList.ToArray();
                                            command.Parameters[++index].Value = februaryAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = februaryAmountNullList.ToArray();
                                            command.Parameters[++index].Value = marchAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = marchAmountNullList.ToArray();
                                            command.Parameters[++index].Value = aprilAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = aprilAmountNullList.ToArray();
                                            command.Parameters[++index].Value = mayAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = mayAmountNullList.ToArray();
                                            command.Parameters[++index].Value = juneAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = juneAmountNullList.ToArray();
                                            command.Parameters[++index].Value = julyAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = julyAmountNullList.ToArray();
                                            command.Parameters[++index].Value = augustAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = augustAmountNullList.ToArray();
                                            command.Parameters[++index].Value = septemberAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = septemberAmountNullList.ToArray();
                                            command.Parameters[++index].Value = octoberAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = octoberAmountNullList.ToArray();
                                            command.Parameters[++index].Value = novemberAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = novemberAmountNullList.ToArray();
                                            command.Parameters[++index].Value = decemberAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = decemberAmountNullList.ToArray();
                                        } else {
                                            command.Parameters[++index].Value = fiscalPeriodList.ToArray();
                                            command.Parameters[++index].Value = amountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = amountNullList.ToArray();
                                        }
                                    }
                                    command.ArrayBindCount = currentBindArrayIndex;
                                    totalRecordsAdded += command.ExecuteNonQuery();
                                }
                                transaction.Commit();
                            }
                            excelReader.Close();
                            excelConnection.Close();
                            connection.Close();
                        }
                    }
                }
            } catch (OleDbException) {
                message = string.Format("There was an error opening the Excel file.  Make sure that a Worksheet named '{0}' exists.", fileType.FileTypeCode);
                runStatusId = -1;
                return -1;
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                message = ex.Message + "<BR>" + ex.StackTrace;
                runStatusId = -1;
                return -2;
            }
            System.Diagnostics.Debug.WriteLine(DateTime.Now);
            return totalRecordsAdded;
        }

        public static ArrayList ProcessStagedData(int runStatusId, string fiscalPeriod, FileType fileType, string userId, out StageProcessingStatus status, out string message, out int rows, out int rowsSkipped) {
            string sqlText = "etl_web_planning.process_stage_to_fact";
            int rowCount = 0;
            ArrayList results = new ArrayList();
            int procedureStatus;
            rows = 0;
            rowsSkipped = 0;
            try {
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new OracleParameter("@i_run_status_id", OracleDbType.Int32, runStatusId, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@i_user_id", OracleDbType.Varchar2, userId, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@i_source", OracleDbType.Varchar2, fileType.FileTypeCode, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@i_fiscal_period", OracleDbType.Varchar2, fiscalPeriod, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@status", OracleDbType.Int32, ParameterDirection.Output));
                    command.Parameters.Add(new OracleParameter("@rows", OracleDbType.Int32, ParameterDirection.Output));

                    command.ExecuteNonQuery();
                    procedureStatus = Convert.ToInt32(command.Parameters["@status"].Value.ToString());
                    rows = Convert.ToInt32(command.Parameters["@rows"].Value.ToString());
                    message = string.Empty;
                    status = (StageProcessingStatus)procedureStatus;
                    command.Parameters.Clear();
                    command.CommandType = CommandType.Text;

                    switch (status) {
                        case StageProcessingStatus.CriticalValidationsFailed:
                        case StageProcessingStatus.AdditionOfKeysRequired:
                            command.CommandText = string.Format(
@"
select a.line_number, b.message
    , a.scenario, a.external_segment, a.account, a.gl_account, a.business_segment
    , a.line_of_business, a.product, a.tech_type, a.region, a.contract_term, a.service_type
    , a.planned_entity, a.function
    , a.source, a.owner, a.run_status_id
  {0}
from {1} a, web_validation_tracking b
where a.run_status_id = b.run_status_id and a.line_number = b.line_number
  and a.run_status_id = :i_run_status_id
order by line_number"

                                , fileType.Is13Month ? ", a.fiscal_year, a.begbal, a.jan, a.feb, a.mar, a.apr, a.may, a.jun, a.jul, a.aug, a.sep, a.oct, a.nov, a.dec" : ", a.fiscal_period, a.amount"
                                , fileType.Is13Month ? "stg_planning_actuals_user_13m" : "stg_planning_actuals_user");
                            command.Parameters.Add(new OracleParameter("@i_run_status_id", OracleDbType.Int32, runStatusId, ParameterDirection.Input));
                            using (OracleDataReader reader = command.ExecuteReader()) {
                                reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                                if (reader.HasRows) {
                                    int i;
                                    while (reader.Read()) {
                                        if (rowCount < MaxRows) {
                                            rowCount++;
                                            i = 0;
                                            PlanningActualFact record = new PlanningActualFact();
                                            if (!reader.IsDBNull(i)) record.Line = reader.GetDecimal(i);
                                            if (!reader.IsDBNull(++i)) record.Message = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Scenario = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.ExternalSegment = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Account = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.GLAccount = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.BusinessSegment = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.LineOfBusiness = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Product = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.TechType = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Region = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.ContractTerm = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.ServiceType = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.PlannedEntity = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Function = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Source = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Owner = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.RunStatusId = reader.GetValue(i).ToString();

                                            if (fileType.Is13Month) {
                                                if (!reader.IsDBNull(++i)) record.Year = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_BegBal = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Jan = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Feb = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Mar = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Apr = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_May = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Jun = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Jul = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Aug = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Sep = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Oct = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Nov = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Dec = reader.GetValue(i).ToString();
                                            } else {
                                                if (!reader.IsDBNull(++i)) record.FiscalPeriod = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Amount = reader.GetValue(i).ToString();
                                            }
                                            results.Add(record);
                                        } else {
                                            rowsSkipped++;
                                        }
                                    }
                                }
                                reader.Close();
                            }

                            break;
                        case StageProcessingStatus.LoadedToFact:
                            command.CommandText = fileType.Is13Month ?
@"with base_data as (
    select  a.scenario, a.external_segment, a.account, a.gl_account, a.business_segment
      , a.line_of_business, a.product, a.tech_type, a.region, a.contract_term, a.service_type
      , a.planned_entity, a.function
      , a.source, a.owner, a.run_status_id
      , substr(a.fiscal_period, 0, 4) year, substr(a.fiscal_period, 5, 2) month
      , a.amount, count(*) over () total_records
    from planning_actuals_user a
    where a.run_status_id = :i_run_status_id
  )
  select scenario, external_segment, account, gl_account, business_segment
    , line_of_business, product, tech_type, region, contract_term, service_type
    , planned_entity, function
    , source, owner, run_status_id
    , year, begbal, jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, dec
  from (
    select * from base_data
    pivot ( 
      sum(amount)for month in ( 
        '00' as begbal, '01' as jan, '02' as feb, '03' as mar, '04' as apr, '05' as may, '06' as jun
        , '07' as jul, '08' as aug, '09' as sep, '10' as oct, '11' as nov, '12' as dec
      )
    )
  ) "

                                :
@" select a.scenario, a.external_segment, a.account, a.gl_account, a.business_segment
      , a.line_of_business, a.product, a.tech_type, a.region, a.contract_term, a.service_type
      , a.planned_entity, a.function
      , a.source, a.owner, a.run_status_id, a.fiscal_period, a.amount
   from planning_actuals_user a
   where a.run_status_id = :i_run_status_id ";

                            command.Parameters.Add(new OracleParameter("@i_run_status_id", OracleDbType.Int32, runStatusId, ParameterDirection.Input));
                            using (OracleDataReader reader = command.ExecuteReader()) {
                                reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                                if (reader.HasRows) {
                                    int i;
                                    while (reader.Read()) {
                                        if (rowCount < MaxRows) {
                                            rowCount++;
                                            i = 0;
                                            PlanningActualFact record = new PlanningActualFact();
                                            if (!reader.IsDBNull(i)) record.Scenario = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.ExternalSegment = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Account = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.GLAccount = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.BusinessSegment = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.LineOfBusiness = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Product = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.TechType = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Region = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.ContractTerm = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.ServiceType = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.PlannedEntity = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Function = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Source = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Owner = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.RunStatusId = reader.GetValue(i).ToString();

                                            if (fileType.Is13Month) {
                                                if (!reader.IsDBNull(++i)) record.Year = reader.GetString(i);
                                                if (!reader.IsDBNull(++i)) record.Fact_BegBal = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Jan = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Feb = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Mar = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Apr = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_May = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Jun = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Jul = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Aug = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Sep = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Oct = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Nov = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Dec = reader.GetValue(i).ToString();
                                            } else {
                                                if (!reader.IsDBNull(++i)) record.FiscalPeriod = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Amount = reader.GetValue(i).ToString();
                                            }
                                            results.Add(record);
                                        } else {
                                            rowsSkipped++;
                                        }
                                    }
                                }
                                reader.Close();
                            }
                        break;
                    }

                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                message = string.Empty;
                status = StageProcessingStatus.CriticalValidationsFailed;
            }

            return results;
        }

        public static ArrayList ProcessMissingKeysAndStagedData(int runStatusId, FileType fileType, string userId, out StageProcessingStatus status, out int rows, out int rowsSkipped) {
            string sqlText = "etl_web_planning.add_keys_and_load_to_fact";
            ArrayList results = new ArrayList();
            int procedureStatus;
            int rowCount = 0;
            rowsSkipped = 0;
            rows = 0;
            try {
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new OracleParameter("@i_run_status_id", OracleDbType.Int32, runStatusId, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@i_user_id", OracleDbType.Varchar2, userId, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@i_source", OracleDbType.Varchar2, fileType.FileTypeCode, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@status", OracleDbType.Int32, ParameterDirection.Output));
                    command.Parameters.Add(new OracleParameter("@rows", OracleDbType.Int32, ParameterDirection.Output));

                    command.ExecuteNonQuery();
                    procedureStatus = Convert.ToInt32(command.Parameters["@status"].Value.ToString());
                    rows = Convert.ToInt32(command.Parameters["@rows"].Value.ToString());
                    status = (StageProcessingStatus)procedureStatus;
                    command.Parameters.Clear();
                    command.CommandType = CommandType.Text;
                    command.CommandText = fileType.Is13Month ?
@"with base_data as (
    select  a.scenario, a.external_segment, a.account, a.gl_account, a.business_segment
      , a.line_of_business, a.product, a.tech_type, a.region, a.contract_term, a.service_type
      , a.planned_entity, a.function
      , a.source, a.owner, a.run_status_id
      , substr(a.fiscal_period, 0, 4) year, substr(a.fiscal_period, 5, 2) month
      , a.amount, count(*) over () total_records
    from planning_actuals_user a
    where a.run_status_id = :i_run_status_id
  )
  select scenario, external_segment, account, gl_account, business_segment
    , line_of_business, product, tech_type, region, contract_term, service_type
    , planned_entity, function
    , source, owner, run_status_id
    , year, begbal, jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, dec
  from (
    select * from base_data
    pivot ( 
      sum(amount)for month in ( 
        '00' as begbal, '01' as jan, '02' as feb, '03' as mar, '04' as apr, '05' as may, '06' as jun
        , '07' as jul, '08' as aug, '09' as sep, '10' as oct, '11' as nov, '12' as dec
      )
    )
  ) "

                                :
@" select a.scenario, a.external_segment, a.account, a.gl_account, a.business_segment
      , a.line_of_business, a.product, a.tech_type, a.region, a.contract_term, a.service_type
      , a.planned_entity, a.function
      , a.source, a.owner, a.run_status_id, a.fiscal_period, a.amount
   from planning_actuals_user a
   where a.run_status_id = :i_run_status_id ";

                    command.Parameters.Add(new OracleParameter("@i_run_status_id", OracleDbType.Int32, runStatusId, ParameterDirection.Input));
                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        if (reader.HasRows) {
                            int i;
                            while (reader.Read()) {
                                if (rowCount < MaxRows) {
                                    rowCount++;
                                    i = 0;
                                    PlanningActualFact record = new PlanningActualFact();
                                    if (!reader.IsDBNull(i)) record.Scenario = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.ExternalSegment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.Account = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.GLAccount = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.BusinessSegment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.LineOfBusiness = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.Product = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.TechType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.Region = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.ContractTerm = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.ServiceType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.PlannedEntity = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.Function = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.Source = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.Owner = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.RunStatusId = reader.GetValue(i).ToString();

                                    if (fileType.Is13Month) {
                                        if (!reader.IsDBNull(++i)) record.Year = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) record.Fact_BegBal = reader.GetValue(i).ToString();
                                        if (!reader.IsDBNull(++i)) record.Fact_Jan = reader.GetValue(i).ToString();
                                        if (!reader.IsDBNull(++i)) record.Fact_Feb = reader.GetValue(i).ToString();
                                        if (!reader.IsDBNull(++i)) record.Fact_Mar = reader.GetValue(i).ToString();
                                        if (!reader.IsDBNull(++i)) record.Fact_Apr = reader.GetValue(i).ToString();
                                        if (!reader.IsDBNull(++i)) record.Fact_May = reader.GetValue(i).ToString();
                                        if (!reader.IsDBNull(++i)) record.Fact_Jun = reader.GetValue(i).ToString();
                                        if (!reader.IsDBNull(++i)) record.Fact_Jul = reader.GetValue(i).ToString();
                                        if (!reader.IsDBNull(++i)) record.Fact_Aug = reader.GetValue(i).ToString();
                                        if (!reader.IsDBNull(++i)) record.Fact_Sep = reader.GetValue(i).ToString();
                                        if (!reader.IsDBNull(++i)) record.Fact_Oct = reader.GetValue(i).ToString();
                                        if (!reader.IsDBNull(++i)) record.Fact_Nov = reader.GetValue(i).ToString();
                                        if (!reader.IsDBNull(++i)) record.Fact_Dec = reader.GetValue(i).ToString();
                                    } else {
                                        if (!reader.IsDBNull(++i)) record.FiscalPeriod = reader.GetValue(i).ToString();
                                        if (!reader.IsDBNull(++i)) record.Amount = reader.GetValue(i).ToString();
                                    }
                                    results.Add(record);
                                } else {
                                    rowsSkipped++;
                                }
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                status = StageProcessingStatus.CriticalValidationsFailed;
            }

            return results;
        }

        public static string BuildFactDownloadSql(FileType fileType, DateTime reportingPeriod, DateTime startDate) {
            string sqlText = string.Empty;
            try {
                sqlText = string.Format(
@"select /*+ parallel(4) */ fiscal_period, scenario, external_segment, account, gl_account, business_segment
    , line_of_business, product, tech_type, region, contract_term, service_type
    , planned_entity, function
    , amount, source, audit_id, owner, run_status_id, date_created, date_modified 
  from planning_actuals_user
  where amount is not null and fiscal_period >= '{0}' and fiscal_period <= '{1}' and source='{2}'"
                    , startDate.ToString("yyyyMM"), reportingPeriod.ToString("yyyyMM"), fileType.FileTypeCode
                );

                return sqlText;
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(null, MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                return string.Empty;
            }
        }

        public static ArrayList GetCurrentKeys(FileType fileType, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                sqlText = string.Format(
@"select rowid, scenario, external_segment, account, gl_account, business_segment
    , line_of_business, product, tech_type, region, contract_term, service_type
    , planned_entity, function
  from planning_actuals_validate 
  where source = '{0}'
  order by scenario, external_segment, account, gl_account, business_segment
    , line_of_business, product, tech_type, region, contract_term, service_type
    , planned_entity, function"
                  , fileType.FileTypeCode);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        while (reader.Read()) {
                            if (rowCount < maxRows) {
                                int i = 0;
                                PlanningActualFact record = new PlanningActualFact();
                                record.RowId = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) record.Scenario = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) record.ExternalSegment = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) record.Account = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) record.GLAccount = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) record.BusinessSegment = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) record.LineOfBusiness = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) record.Product = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) record.TechType = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) record.Region = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) record.ContractTerm = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) record.ServiceType = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) record.PlannedEntity = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) record.Function = reader.GetString(i);
                                a.Add(record);
                                rowCount++;
                            } else {
                                // max row was reached 
                                rowsSkipped++;
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        public static int DeleteKeys(FileType fileType, List<string> rowids, bool deleteAll) {
            const int maxRowsPerUpdate = 2000;
            int totalRecordsDeleted = 0;
            string sqlText = string.Empty;
            int idsToProcess;
            int index = 0;

            try {
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = connection.CreateCommand()) {
                    connection.Open();

                    if (deleteAll) {
                        sqlText = @"delete from planning_actuals_validate where source = :source";
                        command.CommandType = CommandType.Text;
                        command.CommandText = sqlText;
                        command.Parameters.Add(new OracleParameter("source", OracleDbType.Varchar2, fileType.FileTypeCode, ParameterDirection.Input));
                        totalRecordsDeleted = command.ExecuteNonQuery();
                    } else {
                        using (OracleTransaction transaction = connection.BeginTransaction()) {
                            sqlText = @"delete from planning_actuals_validate where rowid = chartorowid(:rid)";
                            command.CommandType = CommandType.Text;
                            command.Parameters.Clear();
                            command.CommandText = sqlText;

                            command.Parameters.Add(new OracleParameter(":rid", OracleDbType.Varchar2));
                            command.BindByName = true;

                            totalRecordsDeleted = 0;
                            idsToProcess = rowids.Count;

                            index = 0;

                            while (idsToProcess > maxRowsPerUpdate) {
                                command.Parameters[0].Value = rowids.GetRange(index, maxRowsPerUpdate).ToArray();
                                command.ArrayBindCount = maxRowsPerUpdate;
                                totalRecordsDeleted += command.ExecuteNonQuery();
                                index += maxRowsPerUpdate;
                                idsToProcess -= maxRowsPerUpdate;
                            }

                            command.Parameters[0].Value = rowids.GetRange(index, idsToProcess).ToArray();
                            command.ArrayBindCount = idsToProcess;
                            totalRecordsDeleted += command.ExecuteNonQuery();
                            transaction.Commit();
                        }
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                return -2;
            }

            return totalRecordsDeleted;
        }

        public static void MoveKeys(FileType targetFileType, string sourceFileType, List<string> rowids, bool moveAll, out int totalFactsMoved, out int totalKeysMoved) {
            const int maxRowsPerUpdate = 2000;
            int idsToProcess;
            int index = 0;
            totalFactsMoved = 0;
            totalKeysMoved = 0;

            try {
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = connection.CreateCommand())
                using (OracleCommand commandFact = connection.CreateCommand()) {

                    connection.Open();
                    using (OracleTransaction transaction = connection.BeginTransaction()) {

                        if (moveAll) {
                            commandFact.CommandText = @"update planning_actuals_user set source = :source where source = :previous_source";
                            commandFact.CommandType = CommandType.Text;
                            commandFact.Parameters.Add(new OracleParameter("source", OracleDbType.Varchar2, targetFileType.FileTypeCode, ParameterDirection.Input));
                            commandFact.Parameters.Add(new OracleParameter("previous_source", OracleDbType.Varchar2, sourceFileType, ParameterDirection.Input));

                            command.CommandText = @"update planning_actuals_validate set source = :source where source = :previous_source";
                            command.CommandType = CommandType.Text;
                            command.Parameters.Add(new OracleParameter("source", OracleDbType.Varchar2, targetFileType.FileTypeCode, ParameterDirection.Input));
                            command.Parameters.Add(new OracleParameter("previous_source", OracleDbType.Varchar2, sourceFileType, ParameterDirection.Input));
                            totalFactsMoved = commandFact.ExecuteNonQuery();
                            totalKeysMoved = command.ExecuteNonQuery();
                        } else {
                            command.CommandType = CommandType.Text;
                            command.Parameters.Clear();
                            command.CommandText = string.Format(@"update planning_actuals_validate set source = '{0}' where rowid = chartorowid(:1)", targetFileType.FileTypeCode);
                            command.Parameters.Add(new OracleParameter("@rid", OracleDbType.Varchar2));
                            //command.BindByName = true;

                            commandFact.CommandType = CommandType.Text;
                            commandFact.Parameters.Clear();
                            commandFact.CommandText = string.Format(
@"update planning_actuals_user set source = '{0}' 
  where rowid in (
    select /*+ parallel(f 4) */ f.rowid 
    from planning_actuals_user f, planning_actuals_validate v
    where v.rowid = chartorowid(:1) 
      and f.scenario = v.scenario and f.external_segment = v.external_segment
      and f.account = v.account and f.gl_account = v.gl_account
      and f.business_segment = v.business_segment and f.line_of_business = v.line_of_business
      and f.product = v.product and f.tech_type = v.tech_type and f.region = v.region
      and f.contract_term = v.contract_term and f.service_type = v.service_type
      and f.planned_entity = v.planned_entity and f.function = v.function
      and f.source = v.source
  )"
                                , targetFileType.FileTypeCode);
                            commandFact.Parameters.Add(new OracleParameter("@rid", OracleDbType.Varchar2));
                            
                            totalKeysMoved = 0;
                            totalFactsMoved = 0;
                            idsToProcess = rowids.Count;

                            index = 0;

                            while (idsToProcess > maxRowsPerUpdate) {
                                command.Parameters[0].Value = rowids.GetRange(index, maxRowsPerUpdate).ToArray();
                                commandFact.Parameters[0].Value = rowids.GetRange(index, maxRowsPerUpdate).ToArray();
                                command.ArrayBindCount = maxRowsPerUpdate;
                                commandFact.ArrayBindCount = maxRowsPerUpdate;
                                totalFactsMoved += commandFact.ExecuteNonQuery();
                                totalKeysMoved += command.ExecuteNonQuery();
                                index += maxRowsPerUpdate;
                                idsToProcess -= maxRowsPerUpdate;
                            }

                            command.Parameters[0].Value = rowids.GetRange(index, idsToProcess).ToArray();
                            commandFact.Parameters[0].Value = rowids.GetRange(index, idsToProcess).ToArray();
                            command.ArrayBindCount = idsToProcess;
                            commandFact.ArrayBindCount = idsToProcess;
                            totalFactsMoved += commandFact.ExecuteNonQuery();
                            totalKeysMoved += command.ExecuteNonQuery();
                        }
                        transaction.Commit();
                    }
                    connection.Close();
                }

            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, string.Empty, ex, UserToolLogLevel.Error);
                throw;
            }
        }

        public static ArrayList ProcessStagedKeyData(int runStatusId, string fiscalPeriod, FileType fileType, string userId, out StageProcessingStatus status, out string message, out int rows, out int rowsSkipped) {
            string sqlText = "etl_web_planning.process_staged_key_data";
            ArrayList results = new ArrayList();
            int procedureStatus;
            int rowCount = 0;
            rowsSkipped = 0;
            rows = 0;
            try {
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new OracleParameter("@i_run_status_id", OracleDbType.Int32, runStatusId, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@i_user_id", OracleDbType.Varchar2, userId, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@i_source", OracleDbType.Varchar2, fileType.FileTypeCode, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@i_fiscal_period", OracleDbType.Varchar2, fiscalPeriod, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@status", OracleDbType.Int32, ParameterDirection.Output));
                    command.Parameters.Add(new OracleParameter("@rows", OracleDbType.Int32, ParameterDirection.Output));

                    command.ExecuteNonQuery();
                    procedureStatus = Convert.ToInt32(command.Parameters["@status"].Value.ToString());
                    rows = Convert.ToInt32(command.Parameters["@rows"].Value.ToString());
                    message = string.Empty;
                    status = (StageProcessingStatus)procedureStatus;
                    command.Parameters.Clear();
                    command.CommandType = CommandType.Text;

                    switch (status) {
                        case StageProcessingStatus.CriticalValidationsFailed:
                            command.CommandText = string.Format(
@"
select a.line_number, b.message
  , a.scenario, a.external_segment, a.account, a.gl_account, a.business_segment
  , a.line_of_business, a.product, a.tech_type, a.region, a.contract_term, a.service_type
  , a.planned_entity, a.function
  , a.source, a.owner, a.run_status_id
from {0} a, web_validation_tracking b
where a.run_status_id = b.run_status_id and a.line_number = b.line_number
  and a.run_status_id = :i_run_status_id
order by line_number"
                                , fileType.Is13Month ? "stg_planning_actuals_user_13m" : "stg_planning_actuals_user");
                            command.Parameters.Add(new OracleParameter("@i_run_status_id", OracleDbType.Int32, runStatusId, ParameterDirection.Input));
                            using (OracleDataReader reader = command.ExecuteReader()) {
                                reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                                if (reader.HasRows) {
                                    int i;
                                    while (reader.Read()) {
                                        if (rowCount < MaxRows) {
                                            rowCount++;
                                            i = 0;
                                            PlanningActualFact record = new PlanningActualFact();
                                            if (!reader.IsDBNull(i)) record.Line = reader.GetDecimal(i);
                                            if (!reader.IsDBNull(++i)) record.Message = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Scenario = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.ExternalSegment = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Account = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.GLAccount = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.BusinessSegment = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.LineOfBusiness = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Product = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.TechType = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Region = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.ContractTerm = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.ServiceType = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.PlannedEntity = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Function = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Source = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Owner = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.RunStatusId = reader.GetValue(i).ToString();
                                            results.Add(record);
                                        } else {
                                            rowsSkipped++;
                                        }
                                    }
                                }
                                reader.Close();
                            }

                            break;
                        default:
                            if (rows == 0) {
                                return null;
                            }
                            command.CommandText = string.Format(
@"
select a.line_number
  , a.scenario, a.external_segment, a.account, a.gl_account, a.business_segment
  , a.line_of_business, a.product, a.tech_type, a.region, a.contract_term, a.service_type
  , a.planned_entity, a.function
  , a.source, a.owner, a.run_status_id
from {0} a
where a.run_status_id = :i_run_status_id
  and line_number in (
    select line_number from web_validation_tracking where run_status_id = :i_run_status_id
  )
order by line_number"
                                , fileType.Is13Month ? "stg_planning_actuals_user_13m" : "stg_planning_actuals_user");
                            command.Parameters.Add(new OracleParameter("@i_run_status_id", OracleDbType.Int32, runStatusId, ParameterDirection.Input));
                            using (OracleDataReader reader = command.ExecuteReader()) {
                                reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                                if (reader.HasRows) {
                                    int i;
                                    while (reader.Read()) {
                                        if (rowCount < MaxRows) {
                                            rowCount++;
                                            i = 0;
                                            PlanningActualFact record = new PlanningActualFact();
                                            if (!reader.IsDBNull(i)) record.Line = reader.GetDecimal(i);
                                            if (!reader.IsDBNull(++i)) record.Scenario = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.ExternalSegment = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Account = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.GLAccount = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.BusinessSegment = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.LineOfBusiness = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Product = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.TechType = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Region = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.ContractTerm = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.ServiceType = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.PlannedEntity = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Function = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Source = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Owner = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.RunStatusId = reader.GetValue(i).ToString();
                                            results.Add(record);
                                        } else {
                                            rowsSkipped++;
                                        }
                                    }
                                }
                                reader.Close();
                            }

                            break;
                    }

                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                message = string.Empty;
                status = StageProcessingStatus.CriticalValidationsFailed;
            }

            return results;
        }

        public static ArrayList AddKeysFromStagedData(FileType fileType, int runStatusId, out bool addWasSuccessful, out int rows) {
            string sqlText = "etl_web_planning.add_keys_from_stage";
            ArrayList results = new ArrayList();
            rows = 0;
            try {
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new OracleParameter("@i_run_status_id", OracleDbType.Int32, runStatusId, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@i_source", OracleDbType.Varchar2, fileType.FileTypeCode, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@status", OracleDbType.Varchar2, ParameterDirection.Output));
                    command.Parameters["@status"].Size = 30;
                    command.Parameters.Add(new OracleParameter("@rows", OracleDbType.Int32, ParameterDirection.Output));

                    command.ExecuteNonQuery();
                    addWasSuccessful = (command.Parameters["@status"].Value.ToString() == "Y");
                    rows = Convert.ToInt32(command.Parameters["@rows"].Value.ToString());
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                addWasSuccessful = false;
            }

            return results;
        }

        public static ArrayList GetAuditTable(PlanningActualFact criteria, string month, string year, out int rowsSkipped) {
            string sqlText = string.Empty;
            string filter = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;
            /*
             * a.scenario, a.external_segment, a.account, a.gl_account, a.business_segment
  , a.line_of_business, a.product, a.tech_type, a.region, a.contract_term, a.service_type
  , a.planned_entity, a.function 
             */
            try {
                if (criteria.Scenario.Length > 0) filter += string.Format(" and f.scenario in ({0})", criteria.Scenario);
                if (criteria.ExternalSegment.Length > 0) filter += string.Format(" and f.external_segment in ({0})", criteria.ExternalSegment);
                if (criteria.Account.Length > 0) filter += string.Format(" and f.account in ({0})", criteria.Account);
                if (criteria.GLAccount.Length > 0) filter += string.Format(" and f.gl_account in ({0})", criteria.GLAccount);
                if (criteria.BusinessSegment.Length > 0) filter += string.Format(" and f.business_segment in ({0})", criteria.BusinessSegment);
                if (criteria.LineOfBusiness.Length > 0) filter += string.Format(" and f.line_of_business in ({0})", criteria.LineOfBusiness);
                if (criteria.Product.Length > 0) filter += string.Format(" and f.product in ({0})", criteria.Product);
                if (criteria.TechType.Length > 0) filter += string.Format(" and f.tech_type in ({0})", criteria.TechType);
                if (criteria.Region.Length > 0) filter += string.Format(" and f.region in ({0})", criteria.Region);
                if (criteria.ContractTerm.Length > 0) filter += string.Format(" and f.contract_term in ({0})", criteria.ContractTerm);
                if (criteria.ServiceType.Length > 0) filter += string.Format(" and f.service_type in ({0})", criteria.ServiceType);
                if (criteria.PlannedEntity.Length > 0) filter += string.Format(" and f.planned_entity in ({0})", criteria.PlannedEntity);
                if (criteria.Function.Length > 0) filter += string.Format(" and f.function in ({0})", criteria.Function);

                sqlText = string.Format(
@" select f.fiscal_period, f.scenario, f.external_segment, f.account, f.gl_account, f.business_segment
     , f.line_of_business, f.product, f.tech_type, f.region, f.contract_term, f.service_type
     , f.planned_entity, f.function, f.amount, f.source, f.audit_id, t.date_created
    , t.amount AuditFact, t.owner, u.first_name, u.last_name
from planning_actuals_user f
  left outer join planning_actuals_audit t on f.audit_id=t.audit_id
  left outer join web_users u on u.user_id = t.owner
where f.fiscal_period = '{0}' and f.audit_id is not null  {1}
order by f.fiscal_period, f.scenario, f.external_segment, f.account, f.gl_account, f.business_segment
     , f.line_of_business, f.product, f.tech_type, f.region, f.contract_term, f.service_type
     , f.planned_entity, f.function, f.audit_id"
                    , string.Format("{0}{1}", year, month.Length == 1 ? String.Format("0{0}", month) : month)
                    , filter
                );

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();
                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        if (reader.HasRows) {
                            while (reader.Read()) {
                                if (rowCount < MaxRows) {
                                    int i = 0;

                                    PlanningActualFact record = new PlanningActualFact();
                                    if (!reader.IsDBNull(i)) record.FiscalPeriod = reader.GetValue(i).ToString();
                                    if (!reader.IsDBNull(++i)) record.Scenario = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.ExternalSegment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.Account = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.GLAccount = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.BusinessSegment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.LineOfBusiness = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.Product = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.TechType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.Region = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.ContractTerm = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.ServiceType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.PlannedEntity = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.Function = reader.GetString(i);
                                    record.Amount = (!reader.IsDBNull(++i)) ? reader.GetDecimal(i).ToString() : string.Empty;
                                    if (!reader.IsDBNull(++i)) record.Source = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.AuditId = reader.GetDecimal(i);
                                    if (!reader.IsDBNull(++i)) record.DateModified = reader.GetDateTime(i);
                                    record.FactAudit = (!reader.IsDBNull(++i)) ? reader.GetDecimal(i).ToString() : string.Empty;
                                    record.FactUser = new UserInfo();
                                    if (!reader.IsDBNull(++i)) record.FactUser.UserId = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.FactUser.FirstName = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.FactUser.LastName = reader.GetString(i);
                                    a.Add(record);
                                    rowCount++;
                                } else {
                                    // max row was reached 
                                    rowsSkipped++;
                                }
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        public static bool WriteAuditDataToCsv(string filename, string sheetName, ArrayList auditData, string requestor) {
            bool returnValue = false;
            try {
                int rowCount = 0;
                  
                using (StreamWriter writer = new StreamWriter(filename)) {
                    writer.WriteLine(@"fiscal_period, scenario, external_segment, account, gl_account, business_segment, line_of_business, product, tech_type, region, contract_term, service_type, planned_entity, function, amount, source, audit_id, owner, date_modified, audit_amount, name");
                    foreach (PlanningActualFact f in auditData) {
                        writer.WriteLine(
                            string.Format(@"{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},{15},{16},{17},{18},{19},{20}"
                                , f.FiscalPeriod, f.Scenario, f.ExternalSegment, f.Account, f.GLAccount, f.BusinessSegment, f.LineOfBusiness, f.Product, f.TechType, f.Region, f.ContractTerm, f.ServiceType, f.PlannedEntity, f.Function, f.Amount, f.Source
                                , f.AuditId.ToString(), f.Owner, string.Format("{0:MM/dd/yyyy HH:mm}", f.DateModified), f.FactAudit.ToString()
                                , string.Format("{0} {1}", f.FactUser.FirstName, f.FactUser.LastName)
                            )
                        );
                        rowCount++;
                    }

                    writer.Dispose();
                }
                GeneralDatabaseAccess.LogEvent(requestor, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name, string.Format("Finished Writing {0} rows to CSV ", rowCount.ToString()), UserToolLogLevel.Message);

                returnValue = true;
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(requestor, MethodBase.GetCurrentMethod().DeclaringType.Name, MethodBase.GetCurrentMethod().Name, ex, UserToolLogLevel.Error);
            }

            return returnValue;
        }


        public static int WriteDataToCsv(string requestor, string filename, string sheetName, string commandText) {
            int rowsWritten = 0;
            System.Diagnostics.Debug.WriteLine(DateTime.Now);
            StringBuilder currentLine = new StringBuilder();
            try {
                System.Diagnostics.Debug.WriteLine(commandText);
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(commandText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        System.Diagnostics.Debug.WriteLine("FetchSize: " + reader.FetchSize);
                        using (StreamWriter writer = new StreamWriter(filename)) {
                            for (int i = 0; i < (reader.FieldCount - 1); i++) {
                                currentLine.Append(reader.GetName(i));
                                currentLine.Append(",");
                            }
                            currentLine.AppendLine(reader.GetName((reader.FieldCount - 1)));
                            writer.Write(currentLine.ToString());
                            GeneralDatabaseAccess.LogEvent(requestor, "PlanningActualsDatabaseAccess", MethodBase.GetCurrentMethod().Name, string.Format("Writing CSV of {0}", sheetName), UserToolLogLevel.Message);

                            while (reader.Read()) {
                                currentLine.Clear();
                                for (int i = 0; i < (reader.FieldCount - 1); i++) {
                                    currentLine.Append(reader.IsDBNull(i) ? "NULL" : reader[i]);
                                    currentLine.Append(',');
                                }
                                currentLine.AppendLine(reader.IsDBNull(reader.FieldCount - 1) ? "NULL" : reader[reader.FieldCount - 1].ToString());
                                writer.Write(currentLine.ToString());
                                rowsWritten++;
                            }
                            writer.Close();
                            GeneralDatabaseAccess.LogEvent(requestor, "PlanningActualsDatabaseAccess", MethodBase.GetCurrentMethod().Name, string.Format("Finished Writing {0} rows to CSV ", rowsWritten.ToString()), UserToolLogLevel.Message);
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(requestor, "PlanningActualsDatabaseAccess", MethodBase.GetCurrentMethod().Name, ex, UserToolLogLevel.Error);
                return -1;
            }
            System.Diagnostics.Debug.WriteLine(DateTime.Now);
            return rowsWritten;
        }

        #region Feed Status Support Routines

        public static List<JobStatusDTO> RetrieveJobStatus(string period) {
            string sqlText = string.Empty;
            List<JobStatusDTO> list = new List<JobStatusDTO>();
            JobStatusDTO jobStatus;
            
            try {
                sqlText = string.Format(
@"select distinct t.input_file_code, a.endtime, t.description, t.scheduled_load_date
    , u.first_name, u.last_name
  , a.created_by           
  , t.is_13month, t.is_adjustment, a.status, a.message
from ops_user_input_file t
  left outer join (
    select p.as_relates_to, max(p.end_time) endtime, p.created_by, status, message
    from ops_run_status p
    where (p.status like 'Complete%' or p.status='Success') and p.fiscal_period={0} 
    group by p.As_Relates_To, p.created_by, status, message
  ) a on t.input_file_code=a.as_relates_to
    left outer join web_users u on u.user_id=CREATED_BY
where t.show_on_upload_status='Y' and t.dest_table like 'PLANNING%'
order by 1, 2 desc "
                  , period);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;

                        string lastSource = "";
                        while (reader.Read()) {
                            if (lastSource == reader.GetString(0))
                                continue;
                            lastSource = reader.GetString(0);
                            jobStatus = new JobStatusDTO();
                            if (!reader.IsDBNull(1)) jobStatus.dtCreate = reader.GetDateTime(1);
                            jobStatus.Source = lastSource;
                            if (!reader.IsDBNull(2)) jobStatus.Description = reader.GetString(2);
                            if (!reader.IsDBNull(4) && !reader.IsDBNull(5)) {
                                jobStatus.Owner = string.Format("{0} {1}", reader[4], reader[5]); 
                            } else {
                                if (!reader.IsDBNull(6)) jobStatus.Owner = reader.GetString(6);
                            }
                            if (!reader.IsDBNull(3)) {
                                jobStatus.ScheduledLoad = reader.GetString(3);
                            }
                            switch (reader[9].ToString()) {
                                case "E": jobStatus.Status = "Error"; break;
                                case "S": jobStatus.Status = "Complete"; break;
                                default: jobStatus.Status = reader[9].ToString(); break;
                            }
                            jobStatus.Message = reader[10].ToString();
                            list.Add(jobStatus);
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                
                //list = null;
            }
            return list;
        }

        #endregion
    }
}

