﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using Oracle.DataAccess.Client;
using System.Reflection;
using MDUA.DTO;
using System.Data;
using System.Collections;

namespace MDUA.DataAccess {
    public class GeneralDatabaseAccess {
        public GeneralDatabaseAccess () {}

        #region public attributes

        //public static string AutosysCS {
        //    get { return ConfigurationManager.ConnectionStrings["AutosysCS"].ConnectionString; }
        //}

        //public static string AutosysSchema {
        //    get { return ConfigurationManager.AppSettings["AutosysSchema"]; }
        //}

        //public static string AutosysTablePrefix {
        //    get { return ConfigurationManager.AppSettings["AutosysTablePrefix"]; }
        //}
        
        public static int DefaultRowsToFetch {
            get { 
                int result;
                return Int32.TryParse(ConfigurationManager.AppSettings["DefaultRowsToFetch"], out result) ? result : 1000;
            } 
        }

        public static string GetOracleConnectionString() {
            return ConfigurationManager.ConnectionStrings["GeneralOracle"].ConnectionString;
        }
        
        #endregion

        #region Utility Routines

        public static void LogEvent(string who, string fromLocation, string action, Exception exception, UserToolLogLevel logLevel) {
            // save to database
            string logMessage = string.Format("Message:{0}<br>Trace: {1}", exception.Message, exception.StackTrace);
            LogEvent(who, fromLocation, action, logMessage, logLevel);

            StringBuilder message = new StringBuilder();
            message.AppendFormat("<br>{0}: {1}", "Type", exception.GetType().ToString());
            message.AppendFormat("<br>{0}: {1}", "From", fromLocation);
            message.AppendFormat("<br>{0}: {1}", "Method", exception.TargetSite);
            message.AppendFormat("<br>{0}: {1}", "Action", action);
            message.AppendFormat("<br>{0}: {1}", "User", who);
            message.AppendFormat("<br>{0}: {1}", "Message", exception.Message);
            message.AppendFormat("<br>{0}: {1}", "StackTrace", exception.StackTrace);

            string subject = string.Format("HypMDUA ({0}): An exception occurred", ConfigurationManager.AppSettings["ServiceName"]);
            SendEmail(ConfigurationManager.AppSettings["SupportEmail"], subject, message.ToString(), who);
        }

        public static void LogEvent(string who, string fromLocation, string action, string status, UserToolLogLevel logLevel) {
            string sqlText = "web_util.log_event";  
                
            try {
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add(new OracleParameter("@i_logged_by", OracleDbType.Varchar2)).Value = string.IsNullOrEmpty(who) ? " " : who;
                    command.Parameters.Add(new OracleParameter("@i_from_where", OracleDbType.Varchar2)).Value = fromLocation;
                    command.Parameters.Add(new OracleParameter("@i_action", OracleDbType.Varchar2)).Value = (action.Length > 4000) ? action.Substring(0, 3999) : action;
                    command.Parameters.Add(new OracleParameter("@i_status", OracleDbType.Varchar2)).Value = (status.Length > 4000) ? status.Substring(0, 3999) : status;
                    command.Parameters.Add(new OracleParameter("@i_log_level", OracleDbType.Int32)).Value = (short)logLevel;                    
                    command.ExecuteNonQuery();
                    connection.Close();
                }
            } catch { }
        }

        public static void SendEmail(string mailTo, string mailSubject, string mailMessage, string who) {
            string sqlText = "web_util.send_mail";
                
            try {
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add(new OracleParameter("msg_to", OracleDbType.Varchar2, ParameterDirection.Input)).Value = mailTo;
                    command.Parameters.Add(new OracleParameter("msg_subject", OracleDbType.Varchar2, ParameterDirection.Input)).Value = mailSubject;
                    command.Parameters.Add(new OracleParameter("msg_text", OracleDbType.Varchar2, ParameterDirection.Input)).Value = mailMessage;
                    command.ExecuteNonQuery();
                    connection.Close();
                }
            } catch (Exception ex) {
                LogEvent(who, MethodBase.GetCurrentMethod().Name, "SendEmail", string.Format("error:{0}<br>Stack:{1}", ex.Message, ex.StackTrace), UserToolLogLevel.Error);
            } 
        }

        # endregion

        #region User Routines

        public static List<UserToolRole> GetRoles() {
            string sqlText = string.Empty;
            List<UserToolRole> userRoles = new List<UserToolRole>();
            UserToolRole role;
            try {
                sqlText = string.Format(@"select role, description from web_user_roles order by description");

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        while (reader.Read()) {
                            role = new UserToolRole();
                            if (!reader.IsDBNull(0)) role.Role = reader.GetInt32(0).ToString();
                            if (!reader.IsDBNull(1)) role.Description = reader.GetString(1);
                            userRoles.Add(role);
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
            }
            return userRoles;
        }

        public static List<UserFileTypeDescription> GetUserFileTypeDescriptions(string employeeId) {
            string sqlText = string.Empty;
            List<UserFileTypeDescription> userFileTypeDescriptions = new List<UserFileTypeDescription>();
            UserFileTypeDescription userFileTypeDescription;
            try {
                sqlText = string.Format(
@"select f.fact_table_desc, i.input_file_code, i.description, w.employee_id
  from ops_user_input_file i
    join master_fact_table f on f.fact_table_id=i.fact_table_id
    left outer join ops_user_input_file_access w on w.employee_id='{0}'
      and w.input_file_code=i.input_file_code
  where i.is_user_feed = 'Y'
  order by f.fact_table_desc, i.input_file_code"
                    , employeeId);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        while (reader.Read()) {
                            userFileTypeDescription = new UserFileTypeDescription();
                            if (!reader.IsDBNull(0)) userFileTypeDescription.FactTableDescription = reader.GetString(0);
                            if (!reader.IsDBNull(1)) userFileTypeDescription.FileTypeCode = reader.GetString(1);
                            if (!reader.IsDBNull(2)) userFileTypeDescription.Description = reader.GetString(2);
                            if (!reader.IsDBNull(3)) userFileTypeDescription.EmployeeId = reader.GetString(3);
                            userFileTypeDescriptions.Add(userFileTypeDescription);
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
            }
            return userFileTypeDescriptions;
        }

        public static List<UserOnDemandDescription> GetUserOnDemandDescriptions(string employeeId) {
            string sqlText = string.Empty;
            List<UserOnDemandDescription> userOnDemandDescriptions = new List<UserOnDemandDescription>();
            UserOnDemandDescription userOnDemandDescription;
            try {
                sqlText = string.Format(
@"select a.event, a.job_name, a.button_text, d.display_order, a.job_id
                  from ops_on_demand_jobs a
                  left outer join ops_on_demand_job_access d on
                    a.job_id = d.job_id and d.employee_id='{0}'
                  order by d.display_order, a.button_text"
                    , employeeId);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        int eventColumn = reader.GetOrdinal("event");
                        int jobNameColumn = reader.GetOrdinal("job_name");
                        int buttonTextColumn = reader.GetOrdinal("button_text");
                        int displayOrderColumn = reader.GetOrdinal("display_order");
                        int jobIdColumn = reader.GetOrdinal("job_id");

                        while (reader.Read()) {
                            userOnDemandDescription = new UserOnDemandDescription();
                            if (!reader.IsDBNull(eventColumn)) userOnDemandDescription.AutomationToolEvent = reader.GetString(eventColumn);
                            if (!reader.IsDBNull(jobNameColumn)) userOnDemandDescription.AutomationToolJobName = reader.GetString(jobNameColumn);
                            if (!reader.IsDBNull(buttonTextColumn)) userOnDemandDescription.ButtonText = reader.GetString(buttonTextColumn);
                            if (!reader.IsDBNull(displayOrderColumn)) userOnDemandDescription.SequenceId = reader.GetInt32(displayOrderColumn);
                            if (!reader.IsDBNull(jobIdColumn)) userOnDemandDescription.JobId = reader.GetInt32(jobIdColumn);
                            userOnDemandDescriptions.Add(userOnDemandDescription);
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
            }
            return userOnDemandDescriptions;
        }

        public static UserInfo GetUserData(string employeeNumber) {
            string sqlText = string.Empty;
            UserInfo user = null;
            
            try {
                sqlText = string.Format(
@"select first_name, last_name, email, active, role, user_id, user_access 
  from web_users 
  where employee_id='{0}'"
                    , employeeNumber);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        if (reader.Read()) {
                            user = new UserInfo();
                            user.EmployeeID = employeeNumber;
                            if (!reader.IsDBNull(0)) user.FirstName = reader.GetString(0);
                            if (!reader.IsDBNull(1)) user.LastName = reader.GetString(1);
                            if (!reader.IsDBNull(2)) user.EMail = reader.GetString(2);
                            if (!reader.IsDBNull(3)) user.Active = reader.GetString(3).Equals("Y");
                            if (!reader.IsDBNull(4)) user.Role = (UserRole)reader.GetInt32(4);
                            user.UserId = reader.IsDBNull(5) ? employeeNumber : reader.GetString(5);
                            user.UserAccess = reader.IsDBNull(6) ? "|" : reader.GetString(6);
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
            }
            return user;
        }

        
        public static bool UpdateUserInfo(UserInfo user, string requestor, List<string> inputFiles, List<int> onDemandJobs)
        {
            string sqlText = string.Empty;

            try {
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand("user_util.update_user_access", connection))
                using (OracleCommand commandClearAccess = new OracleCommand("user_util.remove_file_types_od_access", connection))
                using (OracleCommand commandFileTypes = new OracleCommand("user_util.add_user_file_type_access", connection))
                using (OracleCommand commandOnDemandJobs = new OracleCommand("user_util.add_user_on_demand_access", connection)) {

                    connection.Open();

                    using (OracleTransaction transaction = connection.BeginTransaction()) {
                        // first update user record
                        sqlText = command.CommandText;
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new OracleParameter("@update_count", OracleDbType.Int32, ParameterDirection.ReturnValue));
                        command.Parameters.Add(new OracleParameter("@i_employee_id", OracleDbType.Varchar2)).Value = user.EmployeeID;
                        command.Parameters.Add(new OracleParameter("@i_role", OracleDbType.Int32)).Value = (int)user.Role;
                        command.Parameters.Add(new OracleParameter("@i_user_access", OracleDbType.Varchar2)).Value = user.UserAccess;
                        command.ExecuteNonQuery();
                        if (Convert.ToInt32(command.Parameters["@update_count"].Value.ToString()) < 1) {
                            return false;
                        }

                        // delete current file types for user
                        sqlText = commandClearAccess.CommandText;
                        commandClearAccess.CommandType = CommandType.StoredProcedure;
                        commandClearAccess.Parameters.Add(new OracleParameter("@i_employee_id", OracleDbType.Varchar2)).Value = user.EmployeeID;
                        commandClearAccess.ExecuteNonQuery();
                        
                        // next update file types for user
                        if (inputFiles.Count > 0) {
                            sqlText = commandFileTypes.CommandText;
                            commandFileTypes.CommandType = CommandType.StoredProcedure;
                            commandFileTypes.Parameters.Add(new OracleParameter("@i_employee_id", OracleDbType.Varchar2)).Value = Enumerable.Repeat<string>(user.EmployeeID, inputFiles.Count).ToArray<string>();
                            commandFileTypes.Parameters.Add(new OracleParameter("@i_input_file_code", OracleDbType.Varchar2)).Value = inputFiles.ToArray<string>();
                            commandFileTypes.ArrayBindCount = inputFiles.Count;
                            commandFileTypes.ExecuteNonQuery();
                        }

                        // next update on demand jobs for user
                        if (onDemandJobs.Count > 0) {
                            sqlText = commandOnDemandJobs.CommandText;

                            //List<string> jobNames = new List<string>(onDemandJobs.Count);
                            //List<string> events = new List<string>(onDemandJobs.Count);
                            //foreach (string onDemandJob in onDemandJobs.ToArray<string>()) {
                            //    jobNames.Add(onDemandJob.Split('|')[1]);
                            //    events.Add(onDemandJob.Split('|')[0]);
                            //}

                            commandOnDemandJobs.CommandType = CommandType.StoredProcedure;
                            commandOnDemandJobs.Parameters.Add(new OracleParameter("@i_employee_id", OracleDbType.Varchar2)).Value = Enumerable.Repeat<string>(user.EmployeeID, onDemandJobs.Count).ToArray<string>();
                            //commandOnDemandJobs.Parameters.Add(new OracleParameter("@i_job_name", OracleDbType.Varchar2)).Value = jobNames.ToArray<string>();
                            //commandOnDemandJobs.Parameters.Add(new OracleParameter("@i_event", OracleDbType.Varchar2)).Value = events.ToArray<string>();
                            commandOnDemandJobs.Parameters.Add(new OracleParameter("@i_job_id", OracleDbType.Int32)).Value = onDemandJobs.ToArray<Int32>();
                            commandOnDemandJobs.Parameters.Add(new OracleParameter("@i_sequence", OracleDbType.Varchar2)).Value = Enumerable.Range(1, onDemandJobs.Count).ToArray();
                            commandOnDemandJobs.ArrayBindCount = onDemandJobs.Count;
                            commandOnDemandJobs.ExecuteNonQuery();
                        }

                        transaction.Commit();
                    }
                    connection.Close();

                }
            } catch (Exception ex) {
                LogEvent(requestor, MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                return false;
            } 
            return true;
        }

        public static bool RefreshUserInfo(ArrayList allADUsers, string requestor) {
            string sqlText = "";
            try {
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString())) {
                    connection.Open();
                    sqlText = "user_util.user_refresh_start";
                    using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                        command.CommandType = CommandType.StoredProcedure;
                        command.ExecuteNonQuery();
                    }
                    sqlText = "user_util.update_user";

                    using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(new OracleParameter("@i_employee_id", OracleDbType.Varchar2));
                        command.Parameters.Add(new OracleParameter("@i_first_name", OracleDbType.Varchar2));
                        command.Parameters.Add(new OracleParameter("@i_last_name", OracleDbType.Varchar2));
                        command.Parameters.Add(new OracleParameter("@i_email", OracleDbType.Varchar2));
                        command.Parameters.Add(new OracleParameter("@i_user_id", OracleDbType.Varchar2));
                        foreach (ActiveDirectoryRtns.ADUserInfo adUserInfo in allADUsers) {
                            command.Parameters[0].Value = ConfigurationManager.AppSettings["EmployeeIdActiveDirectorySource"].Equals("id") ? adUserInfo.EmployeeId : adUserInfo.EmployeeNumber;
                            command.Parameters[1].Value = adUserInfo.FirstName;
                            command.Parameters[2].Value = adUserInfo.LastName;
                            command.Parameters[3].Value = adUserInfo.email;
                            command.Parameters[4].Value = adUserInfo.UserId;
                            command.ExecuteNonQuery();
                        }
                    }
                    
                    sqlText = "user_util.user_refresh_end";
                    using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                        command.CommandType = CommandType.StoredProcedure;
                        command.ExecuteNonQuery();
                    }
                    connection.Close();                        
                }
            } catch (Exception ex) {
                LogEvent(requestor, MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                return false;
            }
            return true;
        }
                
        #endregion

        #region Target (Fact Table) related routines

        public static List<CustomTargetAttribute> GetCustomAttributes(FactTable factTable) {
            string sqlText = string.Empty;
            List<CustomTargetAttribute> attributes = new List<CustomTargetAttribute>();
            CustomTargetAttribute attribute;
            try {
                sqlText = string.Format(
@"select column_name, attribute_name, description, attribute_type, dropdown_values
  from web_target_custom_attributes 
  where target_id = {0}
  order by display_order"
                    , (int)factTable);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        while (reader.Read()) {
                            attribute = new CustomTargetAttribute();
                            attribute.Target = factTable;
                            attribute.ColumnName = reader.GetString(0);
                            attribute.AttributeName = reader.GetString(1);
                            attribute.Description = reader.GetString(2);
                            CustomAttributeType attributeType;
                            Enum.TryParse<CustomAttributeType>(reader.GetString(3), out attributeType);
                            attribute.AttributeType = attributeType;
                            if (!reader.IsDBNull(4)) attribute.DropdownItems = reader.GetString(4).Split('|');
                            attributes.Add(attribute);
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
            }
            return attributes;
        }

        public static List<AutomapFieldInfo> GetAutomapFields(FactTable factTable) {
            string sqlText = string.Empty;
            List<AutomapFieldInfo> automapFields = new List<AutomapFieldInfo>();
            AutomapFieldInfo automapField;
            try {
                sqlText = string.Format(
@"select column_name, to_char(automap_id), description
  from web_target_automap_info 
  where target_id = {0}"
                    , (int)factTable);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        while (reader.Read()) {
                            automapField = new AutomapFieldInfo();
                            automapField.Target = factTable;
                            automapField.ColumnName = reader.GetString(0);
                            automapField.AutomapId = reader.GetString(1);
                            automapField.Description = reader.GetString(2);
                            automapFields.Add(automapField);
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
            }
            return automapFields;
        }

        #endregion

        #region File Type Routines

        public static List<FactTableDTO> GetFactTableNames()  {
            string sqlText = string.Empty;
            List<FactTableDTO> factTables = new List<FactTableDTO>();
            FactTableDTO table;
            try {
                sqlText = string.Format(@"select fact_table_id||';'||fact_table_name fact_table_id, fact_table_desc from master_fact_table where fact_table_type = 1 order by fact_table_desc");

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        while (reader.Read()) {
                            table = new FactTableDTO();
                            table.FactTableId = reader.GetString(0);
                            table.FactTableDescription = reader.GetString(1);
                            factTables.Add(table);
                            //if (!reader.IsDBNull(0)) role.Role = reader.GetInt32(0).ToString();
                            //if (!reader.IsDBNull(1)) role.Description = reader.GetString(1);
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
            }
            return factTables;
        }

        public static MasterFactTable GetFactTable(string factTableId, string factTableName, string requestor) {
            string sqlText = string.Empty;
            MasterFactTable factTable = new MasterFactTable();

            try {
                sqlText = string.Format(
@"select fact_table_id, fact_table_name, fact_table_desc, stage_table_year_name, stage_table_month_name
    , pre_fact_load_procedure, key_combo_table_name, fact_table_with_outline_values, allows_adjustments, allows_outlook
  from master_fact_table 
  where {0}"        
                , factTableId.Length > 0 ? "fact_table_id = " + factTableId : "fact_table_name='" + factTableName + "'");

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        if (reader.Read()) {
                            int i = -1;
                            int.TryParse(reader.GetValue(++i).ToString(), out factTable.FactTableId);
                            if (!reader.IsDBNull(++i)) factTable.FactTableName = reader.GetString(i);
                            if (!reader.IsDBNull(++i)) factTable.FactTableDesc = reader.GetString(i);
                            if (!reader.IsDBNull(++i)) factTable.StageTableYearName = reader.GetString(i);
                            if (!reader.IsDBNull(++i)) factTable.StageTableMonthName = reader.GetString(i);
                            if (!reader.IsDBNull(++i)) factTable.PreFactLoadProcedure = reader.GetString(i).Trim();
                            if (!reader.IsDBNull(++i)) factTable.KeyComboTableName = reader.GetString(i).Trim();
                            if (!reader.IsDBNull(++i)) factTable.FactTableWithValues = reader.GetString(i).Trim();
                            if (!reader.IsDBNull(++i)) factTable.AllowsAdjustments = reader.GetString(i).ToUpper().Equals("Y");
                            if (!reader.IsDBNull(++i)) factTable.AllowsOutlook = reader.GetString(i).ToUpper().Equals("Y");
                            if (factTable.FactTableName.ToUpper().StartsWith("RPT_") || factTable.FactTableName.ToUpper().StartsWith("CPGA_")) factTable.IsLegacy = true;
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                LogEvent(requestor, MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                return null;
            }
            return factTable;
        }

        public static List<MasterDimension> GetFactDimensions(FactTable factTable, bool is13Month, bool includePeriodAndFacts, bool onlyIncludeUserFeedFields) {
            string sqlText = string.Empty;
            List<MasterDimension> dimensions = new List<MasterDimension>();
            MasterDimension dimension;

            try {
                sqlText = string.Format(
@"select d.dimension_id, df.stage_table_column_name, df.dimension_type_name, d.dimension_Name, d.dimension_type
    , df.master_table_name, df.validation_column, df.member_prefix, df.default_table_alias, df.extra_validation_clause
    , df.outlook_key_combo_validation, df.is_included_in_user_feed  
  from master_dimension d
    join map_dimension_fact_table df on d.dimension_id=df.dimension_id 
  where df.fact_table_id={0} {1}
  order by dimension_name"
                    , (int)factTable, onlyIncludeUserFeedFields ? "and is_included_in_user_feed = 'Y'" : "" );
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        while (reader.Read()) {
                            int i = 0;
                            dimension = new MasterDimension();

                            int.TryParse(reader.GetValue(i).ToString(), out dimension.Id);
                            dimension.FactColumnName = reader.GetString(++i);
                            dimension.DimensionTypeName = reader.GetString(++i);
                            dimension.DimensionLabel = reader.GetString(++i);
                            dimension.DimVariableType = reader.GetString(++i);
                            dimension.MasterTable = reader.GetString(++i);
                            dimension.ValidationColumn = reader.GetString(++i);
                            dimension.Prefix = reader.GetString(++i).Trim();
                            dimension.TableAlias = reader.GetString(++i).Trim();
                            if (!reader.IsDBNull(++i)) dimension.ExtraValidationClause = reader.GetString(i).Trim();
                            if (!reader.IsDBNull(++i)) dimension.KeyComboValidation = reader.GetString(i).Trim();
                            dimension.IsIncludedInUserFeed = (!reader.IsDBNull(++i)) ? reader.GetString(i).Trim().ToUpper().Equals("Y") : false;
                            dimensions.Add(dimension);
                        }
                        reader.Close();

                        //  If we don't care about the period or fact fields, leave now.  This would be true
                        //  if we are just processing the keys.
                        if (!includePeriodAndFacts)
                            return dimensions;
                        
                        dimensions.Add(new MasterDimension("YEAR", "YEAR", "number"));

                        //  If it is 13 months, add all the individual fact fields; otherwise, just load the 
                        //  fiscal period and one amount.
                        if (is13Month) {
                            string[] months = new string[] { "FACT_BEGBAL", "FACT_JAN", "FACT_FEB", "FACT_MAR", "FACT_APR", "FACT_MAY", "FACT_JUN", "FACT_JUL", "FACT_AUG", "FACT_SEP", "FACT_OCT", "FACT_NOV", "FACT_DEC" };
                            foreach (string month in months) {
                                dimensions.Add(new MasterDimension(month, month, "number"));                               
                            }
                        } else {
                            dimensions.Add(new MasterDimension("time", "time", "number"));
                            dimensions.Add(new MasterDimension("fact_amt", "fact_amt", "number"));
                        }

                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                LogEvent(string.Empty, MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
            }
            return dimensions;
        }

        public static bool AddUpdateFileType(FileType hft, string Requestor)
        {
            OracleConnection oraConn = new OracleConnection(GetOracleConnectionString());
            OracleCommand sqlCmd = null;
            string Cmd = null;
            bool bRet = false;
            try
            {
                Cmd = string.Format("Delete from ops_user_input_file where Input_File_code='{0}'",
                    hft.FileTypeCode);
                oraConn.Open();
                sqlCmd = new OracleCommand(Cmd, oraConn);
                if (sqlCmd.ExecuteNonQuery() > 0)
                {
                    Cmd = string.Format("Delete from ops_user_input_file_field where Input_File_code='{0}'",
                         hft.FileTypeCode);
                    sqlCmd.CommandText = Cmd;
                    sqlCmd.ExecuteNonQuery();
                }

                Cmd = string.Format("insert into ops_user_input_file (fact_table_id, Input_File_Code, Description, is_Adjustment, is_13Month, is_outlook, is_User_Feed, Uses_Valid_Keys, Show_On_Upload_Status,Scheduled_Load_Date,Dest_Table) values ({0},'{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}')",
                   hft.FactTableId, hft.FileTypeCode, hft.Description, (hft.IsAdjustment ? "Y" : "N"),
                   (hft.Is13Month ? "Y" : "N"), (hft.IsOutlook ? "Y" : "N"), (hft.IsUserFeed ? "Y" : "N"),
                   (hft.UsesValidKeyCombos ? "Y" : "N"), (hft.ShowOnUploadStatus ? "Y" : "N"),
                   hft.ScheduledLoadDate, hft.DestinationTable);
                sqlCmd.CommandText = Cmd;
                if (sqlCmd.ExecuteNonQuery() == 1)
                {
                    //  Add in the Field Information.
                    foreach (FileTypeField tFld in hft.fields)
                    {
                        Cmd = string.Format("insert into ops_user_input_file_field (Input_File_Code, Member_Name, Forced_Value, Field_source) values ('{0}','{1}','{2}',{3})",
                        hft.FileTypeCode, tFld.FactColumnName, tFld.ForcedValue, (int)tFld.Source);
                        sqlCmd.CommandText = Cmd;
                        sqlCmd.ExecuteNonQuery();
                    }

                    GeneralDatabaseAccess.LogEvent(Requestor, "AddUpdateFileType", "AddUpdateFileType", "Success", UserToolLogLevel.Audit);
                    bRet = true;
                }
            } catch (Exception ex) {
                //  Log the error to a table.
                GeneralDatabaseAccess.LogEvent(Requestor, "AddUpdateFileType", Cmd, ex, UserToolLogLevel.Error);
            }
            finally
            {
                if (oraConn != null)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                }
            }

            return bRet;
        }

        public static int LockFileType(string FileType, string ClosePeriod, string UserId,
         string Requestor, out string ErrMsg)
        {
            ErrMsg = "";
            BasicOraReader Rdr = new BasicOraReader(DbAccess.GetOracleConnectionString());

            string Cmd = string.Format(@"Select As_relates_to FROM ops_run_status where process_name='INPUT_FILE' and as_relates_to='{0}' and
            NOT START_TIME IS NULL and END_TIME IS NULL",
                FileType);
            if (Rdr.Open(Cmd))
            {
                if (Rdr.oraRdr.Read())
                {
                    ErrMsg = string.Format("A {0} process is already running.  Please try again in about a minute.",
                        FileType);
                    Rdr.Dispose();
                    return -2;
                }
                Rdr.Close();
            }

            //  Add a process to reserve our spot.
            int SeqNbr = DbAccess.RunStatusAdd("INPUT_FILE", ClosePeriod, "In Progress", "Running",
                UserId, FileType);
            if (SeqNbr == -1)
            {
                ErrMsg = "RunStatusAdd failed to return a Sequence Number";
                return -1;
            }

            //  Verify that no one snuck in in front of use and is processing their stuff now.
            // jevans 3/15/2012 process_id mysteriously changed to run_status_id? 
            Cmd = string.Format(@"Select min(run_status_id) FROM ops_run_status where as_relates_to = '{0}' 
                    and NOT START_TIME IS NULL and END_TIME IS NULL",
                FileType);
            if (Rdr.Open(Cmd))
            {
                if (Rdr.oraRdr.Read() == false || Rdr.oraRdr.GetDecimal(0) != SeqNbr)
                {
                    ErrMsg = "A Task is already running that is blocking this request.  Please try again in a minute.";
                    DbAccess.RunStatusComplete(SeqNbr, "Error", "This Process was blocked by another process that is already running.", 0, FileType);
                    return -3;
                }
            }
            else
            {
                ErrMsg = "An error occurred while checking for existing process.";
                return -1;
            }

            return SeqNbr;
        }

        /// <summary>
        /// Returns array of file type based on either fact table, file type or requestor permission
        /// </summary>
        public static List<FileType> GetFileTypes(int factTableId, string fileTypeCode, string requestor) {
            string sqlText = string.Empty;
            List<FileType> fileTypes = new List<FileType>();            
            FileType fileType = null;

            try {
                sqlText = string.Format(
@"select distinct l.input_file_code, l.description, l.dest_table, m.stage_table_year_name, m.stage_table_month_name
    , m.key_combo_table_name, l.fact_table_id, l.is_adjustment, l.is_13month, l.is_user_feed, l.uses_valid_keys
    , l.is_outlook, l.show_on_upload_status, l.scheduled_load_date, f.member_name
    , f.forced_value, f.field_source, df.dimension_type_name 
  from ops_user_input_file l
    join master_fact_table m on l.fact_table_id= m.fact_table_id
    left join ops_user_input_file_field f on l.input_file_code = f.input_file_code 
    left join  map_dimension_fact_table df on  f.member_name  =  df.stage_table_column_name and l.fact_table_id=df.fact_table_id    
    {0}
    where m.fact_table_type = 1 
    {1}
    {2} 
  order by l.description, l.input_file_code, f.member_name "
                    , requestor.Length == 0 ? "" : string.Format(" join ops_user_input_file_access u on l.input_file_code=u.input_file_code and u.employee_id = '{0}' ", requestor)
                    , factTableId == 0 ? "" : string.Format(" and l.fact_table_id = {0}", factTableId.ToString())
                    , fileTypeCode.Length == 0 ? "" : string.Format(" and l.Input_File_Code = '{0}'", fileTypeCode));

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        while (reader.Read()) {
                            int i = 0;
                            if (fileType == null || !fileType.FileTypeCode.Equals(reader.GetString(i))) {
                                fileType = new FileType();
                                fileType.FileTypeCode = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) fileType.Description = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) fileType.DestinationTable = reader.GetString((i));
                                if (!reader.IsDBNull(++i)) fileType.StageYearTable = reader.GetString((i));
                                if (!reader.IsDBNull(++i)) fileType.StageMonthTable = reader.GetString((i));
                                if (!reader.IsDBNull(++i)) fileType.ValidationKeyTable = reader.GetString((i));
                                int.TryParse(string.Format("{0}", reader[(++i)]), out fileType.FactTableId);

                                fileType.IsAdjustment = reader.GetString(++i).Trim().ToUpper().Equals("Y");
                                fileType.Is13Month = reader.GetString(++i).Trim().ToUpper().Equals("Y");
                                fileType.IsUserFeed = reader.GetString(++i).Trim().ToUpper().Equals("Y");
                                fileType.UsesValidKeyCombos = reader.GetString(++i).Trim().ToUpper().Equals("Y");
                                fileType.IsOutlook = reader.GetString(++i).Trim().ToUpper().Equals("Y");
                                fileType.ShowOnUploadStatus = reader.GetString(++i).Trim().ToUpper().Equals("Y");
                                if (!reader.IsDBNull(++i)) fileType.ScheduledLoadDate = reader.GetString(i);
                                fileTypes.Add(fileType);
                            }
                            i = 13;
                            if (!reader.IsDBNull(++i)) {
                                FileTypeField fileTypeFields = new FileTypeField();
                                fileTypeFields.FactColumnName = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) fileTypeFields.ForcedValue = reader.GetString(i).Trim();
                                if (!reader.IsDBNull(++i)) fileTypeFields.Source = (FileTypeFieldSource)reader.GetDecimal(i);
                                if (!reader.IsDBNull(++i)) fileTypeFields.DimensionTypeName = reader.GetString(i).Trim();
                                fileType.fields.Add(fileTypeFields);
                            }
                        }
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                LogEvent(string.Empty, MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                fileTypes = null;
            }
            return fileTypes;
        }

        public static bool AddUpdateInputFile(FileType hft, string Requestor) {
            BasicOraCommand Wrtr = new BasicOraCommand(GetOracleConnectionString());
            string Cmd = null;
            bool bRet = false;
            try
            {
                Cmd = string.Format("Delete from ops_user_input_file where Input_File_Code='{0}'",
                    hft.FileTypeCode);
                if (Wrtr.Exec(Cmd) > 0)
                {
                    Cmd = string.Format("Delete from ops_user_input_file_field where Input_File_Code='{0}'",
                         hft.FileTypeCode);
                    Wrtr.ExecOpened(Cmd);
                }
                else
                    if (Wrtr.LastErrorMessage.Length > 0)
                        throw new Exception(Wrtr.LastErrorMessage);

                Cmd = string.Format("insert into ops_user_input_file (fact_table_id, Input_File_Code, Description, is_Adjustment, is_13Month, is_outlook, is_User_Feed, Uses_Valid_Keys, Show_On_Upload_Status,Scheduled_Load_Date,Dest_Table) values ({0},'{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}')",
                    hft.FactTableId, hft.FileTypeCode, hft.Description, (hft.IsAdjustment ? "Y" : "N"),
                    (hft.Is13Month ? "Y" : "N"), (hft.IsOutlook ? "Y" : "N"), (hft.IsUserFeed ? "Y" : "N"),
                    (hft.UsesValidKeyCombos ? "Y" : "N"), (hft.ShowOnUploadStatus ? "Y" : "N"),
                    hft.ScheduledLoadDate, hft.DestinationTable);

                if (Wrtr.ExecOpened(Cmd) == 1)
                {
                    //  Add in the Field Information.
                    foreach (FileTypeField tFld in hft.fields)
                    {
                        Cmd = string.Format("insert into ops_user_input_file_field (Input_File_Code, Member_Name, Forced_Value, Field_source) values ('{0}','{1}','{2}',{3})",
                            hft.FileTypeCode, tFld.FactColumnName, tFld.ForcedValue, (int)tFld.Source);
                        Wrtr.ExecOpened(Cmd);
                    }

                    LogEvent(Requestor, "AddUpdateInputFile",
                       "AddUpdateInputFile", "Success", UserToolLogLevel.Audit);
                    bRet = true;
                }
            }
            catch (Exception ex)
            {
                //  Log the error to a table.
                LogEvent(Requestor, "AddUpdateInputFile", Cmd, ex, UserToolLogLevel.Error);
            }

            if (Wrtr != null)
                Wrtr.Dispose();

            return bRet;
        }

        public static int RunNonQuery(string Cmd, string ConnectStr, string Requestor)
        {
            OracleConnection oraConn = new OracleConnection(ConnectStr);
            OracleCommand sqlCmd = null;
            int iRet = -1;
            try
            {
                oraConn.Open();
                sqlCmd = new OracleCommand(Cmd, oraConn);
                iRet = sqlCmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                //  Log the error to a table.
                LogEvent(Requestor, "RunNonQuery", Cmd, ex, UserToolLogLevel.Error);
            }
            finally
            {
                if (oraConn != null)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                }
            }
            return iRet;
        }

        public static bool DeleteInputFileType(string InputFileCode, string Requestor)
        {
            string Cmd = string.Format("Delete from ops_user_input_file where Input_File_Code='{0}'",
                InputFileCode);

            if (RunNonQuery(Cmd, GetOracleConnectionString(), Requestor) == -1)
                return false;

            Cmd = string.Format("Delete from ops_user_input_file_field where Input_File_Code='{0}'",
                 InputFileCode);
            if (RunNonQuery(Cmd, GetOracleConnectionString(), Requestor) == -1)
                return false;

            GeneralDatabaseAccess.LogEvent(Requestor, "UserInputFile.aspx", "Delete File Type",
                string.Format("File Type {0} was deleted", InputFileCode), UserToolLogLevel.Audit);
            return true;

        }

        // called by OPS upload input file
        public static DataSet callInputFilePreFactLoad(string StoredProcName, string RunId, string Requestor)
        {
            OracleConnection oraConn = new OracleConnection(GetOracleConnectionString());
            OracleCommand sqlCmd = null;
            DataSet dsResult = null;
            try
            {
                oraConn.Open();

                sqlCmd = new OracleCommand(StoredProcName, oraConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                OracleParameter pRunId = new OracleParameter("i_run_id", OracleDbType.Int32, ParameterDirection.Input);
                OracleParameter pRowSet = new OracleParameter("p_rowset", OracleDbType.RefCursor, ParameterDirection.Output);

                pRunId.Value = Int32.Parse(RunId);

                sqlCmd.Parameters.Add(pRunId);
                sqlCmd.Parameters.Add(pRowSet);

                dsResult = new DataSet();
                OracleDataAdapter da = new OracleDataAdapter(sqlCmd);
                da.Fill(dsResult);
            }
            catch (Exception ex)
            {
                //  Log the error to a table.
                GeneralDatabaseAccess.LogEvent(Requestor, "callInputFilePreFactLoad", StoredProcName, ex, UserToolLogLevel.Error);
                if (dsResult != null)
                {
                    dsResult.Dispose();
                    dsResult = null;
                }
            }
            finally
            {
                if (oraConn != null)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                }
            }
            return dsResult;
        }

        #endregion
                        
        #region Lookup Table Routines
        //TODO: Needs to be fixed
        public static WebSettings LoadWebSetting(string requestor)
        {
            WebSettings config = new WebSettings();
            BasicOraReader Rdr = new BasicOraReader(DbAccess.GetOracleConnectionString());
            try
            {
                if (Rdr.Open("select SettingName, SettingValue, userid from rpt_settings_tbl") == false)
                {
                    // throw exception so email gets sent 
                    throw new Exception(Rdr.LastErrorMessage);
                }

                while (Rdr.oraRdr.Read())
                {
                    if (Rdr.oraRdr.GetString(0).ToUpper().Equals("BROADCAST")) {
                        config.BroadcastMessage = Rdr.oraRdr.GetString(1);
                    } else if (Rdr.oraRdr.GetString(0).ToUpper().Equals("CURRPERIOD")) {
                        config.CurrentPeriod = Rdr.oraRdr.GetString(1);
                    } else if (Rdr.oraRdr.GetString(0).ToUpper().Equals("ENABLECOACOR")) {
                        config.CoaCorEnabled = Rdr.oraRdr.GetString(1).ToLower().Equals("true");
                        config.CoaCorUser = Rdr.oraRdr.GetString(2);
                    } else if (Rdr.oraRdr.GetString(0).ToUpper().Equals("ENABLEFEED")) {
                        config.UserFeedEnabled = Rdr.oraRdr.GetString(1).ToLower().Equals("true");
                        config.UserFeedUser = Rdr.oraRdr.GetString(2);
                    }
                }
                Rdr.Close();
                Rdr.Dispose();
                
                return config;
            }
            catch (Exception ex)
            {
                LogEvent(requestor, MethodBase.GetCurrentMethod().Name, "LoadWebSettings", ex, UserToolLogLevel.FatalError);
                return null;
            }
        }


        public static bool SaveWebSetting(WebSettings Settings, string Requestor)
        {
            WebSettings PrevSettings = LoadWebSetting(Requestor);

            BasicOraCommand Wrtr = new BasicOraCommand(DbAccess.GetOracleConnectionString());
            Wrtr.Open();
            string CmdFmt = @"Update rpt_settings_tbl 
            set SettingValue='{0}', userid='{1}', LastUpdateDate=sysdate 
            where Component='{2}' and SettingName='{3}'";
            string Cmd;
            if (PrevSettings.CoaCorEnabled != Settings.CoaCorEnabled)
            {
                Cmd = string.Format(CmdFmt, Settings.CoaCorEnabled ? "TRUE" : "FALSE",
                    Requestor, "USERFEED", "ENABLECOACOR");
                if (Wrtr.ExecOpened(Cmd) < 1)
                    GeneralDatabaseAccess.LogEvent(Requestor, "SaveWebSetting", Cmd, Wrtr.LastErrorMessage, UserToolLogLevel.Error);
                GeneralDatabaseAccess.LogEvent(Requestor, "SaveWebSetting",
                    Settings.CoaCorEnabled ? "Enabled CoaCor" : "Disabled CoaCor",
                    "Success", UserToolLogLevel.Audit);
            }
            if (PrevSettings.UserFeedEnabled != Settings.UserFeedEnabled)
            {
                Cmd = string.Format(CmdFmt, Settings.UserFeedEnabled ? "TRUE" : "FALSE",
                    Requestor, "USERFEED", "ENABLEFEED");
                if (Wrtr.ExecOpened(Cmd) < 1)
                    GeneralDatabaseAccess.LogEvent(Requestor, "SaveWebSetting", Cmd, Wrtr.LastErrorMessage, UserToolLogLevel.Error);
                // jevans 7/25/2012 - this event was examining "CoaCorEnabled" instead of "UserFeedEnabled"
                GeneralDatabaseAccess.LogEvent(Requestor, "SaveWebSetting",
                    Settings.UserFeedEnabled ? "Enabled User Feed" : "Disabled User Feed",
                    "Success", UserToolLogLevel.Audit);
            }
            if (PrevSettings.BroadcastMessage != Settings.BroadcastMessage)
            {
                Cmd = string.Format(CmdFmt, Settings.BroadcastMessage,
                    Requestor, "SYSTEM", "BROADCAST");
                if (Wrtr.ExecOpened(Cmd) < 1)
                    GeneralDatabaseAccess.LogEvent(Requestor, "SaveWebSetting", Cmd, Wrtr.LastErrorMessage, UserToolLogLevel.Error);
                GeneralDatabaseAccess.LogEvent(Requestor, "SaveWebSetting",
                    "Broadcast Updated",
                    "Success", UserToolLogLevel.Audit);
            }
            if (PrevSettings.CurrentPeriod != Settings.CurrentPeriod)
            {
                Cmd = string.Format(CmdFmt, Settings.CurrentPeriod,
                    Requestor, "SYSTEM", "CURRPERIOD");
                if (Wrtr.ExecOpened(Cmd) < 1)
                    GeneralDatabaseAccess.LogEvent(Requestor, "SaveWebSetting", Cmd, Wrtr.LastErrorMessage, UserToolLogLevel.Error);

                GeneralDatabaseAccess.LogEvent(Requestor, "SaveWebSetting",
                    "Current Period Changed to " + Settings.CurrentPeriod,
                    "Success", UserToolLogLevel.Audit);
            }
            Wrtr.Dispose();

            return true;
        }

        public static ArrayList GetDimYears()
        {
            BasicOraReader Rdr = new BasicOraReader(DbAccess.GetOracleConnectionString());
            ArrayList a = new ArrayList();
            if (Rdr.Open("select alias from web_dimensions_tbl where dim_type='YEARS' and not alias is null"))
            {
                while (Rdr.oraRdr.Read())
                    a.Add(Rdr.oraRdr.GetString(0));
                Rdr.Close();
            }
            else
            {
                // throw exception so email gets sent 
                Rdr.Dispose();
                throw new Exception(Rdr.LastErrorMessage);
            }
            Rdr.Dispose();
            return a;

        }
        #endregion

        #region Autosys Routines
        
        
        public static OnDemandJobInfo GetOnDemandJob(int jobId, string Requestor)
        {
            string Cmd = string.Format(@"select description, button_text, event, date_created, date_modified, job_name, SUB_APPL_NAME
        From ops_on_demand_jobs where job_id='{0}'",
                jobId);

            BasicOraReader Rdr = new BasicOraReader(GetOracleConnectionString());
            if (Rdr.Open(Cmd) && Rdr.oraRdr.Read())
            {
                int descriptionCol = Rdr.oraRdr.GetOrdinal("description");
                int buttonTextCol = Rdr.oraRdr.GetOrdinal("button_text");
                int eventCol = Rdr.oraRdr.GetOrdinal("event");
                int dateModifiedCol = Rdr.oraRdr.GetOrdinal("date_created");
                int dateCreatedCol = Rdr.oraRdr.GetOrdinal("date_modified");
                int jobNameCol = Rdr.oraRdr.GetOrdinal("job_name");
                int subApplNameCol = Rdr.oraRdr.GetOrdinal("SUB_APPL_NAME");

                OnDemandJobInfo jobInfo = new OnDemandJobInfo();
                jobInfo.JobId = jobId;
                jobInfo.JobName = Rdr.oraRdr.GetString(jobNameCol);
                jobInfo.Description = Rdr.oraRdr.GetString(descriptionCol);
                jobInfo.ButtonText = Rdr.oraRdr.GetString(buttonTextCol);
                jobInfo.Event = Rdr.oraRdr.GetString(eventCol);
                jobInfo.DateCreated = Rdr.oraRdr.GetDateTime(dateCreatedCol);
                jobInfo.DateModified = Rdr.oraRdr.GetDateTime(dateModifiedCol);
                jobInfo.SubApplName = (Rdr.oraRdr.IsDBNull(subApplNameCol) ? string.Empty : Rdr.oraRdr.GetString(subApplNameCol));
                Rdr.Dispose();
                return jobInfo;
            }
            else
            {
                // throw exception so email gets sent 
                Rdr.Dispose();
                throw new Exception(Rdr.LastErrorMessage);
            }
        }
        #endregion
        

    }
}

    
        