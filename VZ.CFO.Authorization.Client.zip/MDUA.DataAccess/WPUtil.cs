using System;
//using System.Web.UI.WebControls.WebParts;
//using System.Web.UI.HtmlControls;
using System.Collections;
//using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for WPUtil
/// </summary>
public class WPUtil
{
	public WPUtil()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public static Table BuildProgressBar(string ProcessCode, string AsRelatesTo, int ProcessId, string ImagesDir, string Requestor)
    {
        WPProcessInfo pi = GetProcessInfo(ProcessCode, AsRelatesTo, ProcessId, true, Requestor);
        Table myTbl = new Table();
        TableRow tr = new TableRow();
        myTbl.Rows.Add(tr);
        myTbl.CellPadding = 0;
        myTbl.CellSpacing = 0;
        myTbl.BorderWidth = 0;

        //  If the ProcessId = 0, then it means there are no status for this process.
        if (pi.ProcessId == 0)
        {
            TableCell errTc = new TableCell();
            tr.Cells.Add(errTc);

            BasicOraReader Rdr = new BasicOraReader(DbAccess.GetOracleConnStr());
            Rdr.Open(string.Format("Select ProcessDescription from rpt_process_type_tbl where asrelatesto like '{0}' and processcode = '{1}'",
                AsRelatesTo, ProcessCode));
            if (Rdr.oraRdr.Read() == true)
                errTc.Text = string.Format("There are no previous runs of the {0} process.", Rdr.oraRdr.GetString(0));
            else
                errTc.Text = "There are no previous runs of that process.";
            Rdr.Dispose();
            return myTbl;
        }

        //  Retrieve all the data for this process id so that we can build a Progress Bar.
        if (pi.arrSteps == null || pi.arrSteps.Count == 0)
            return null;

        TableRow trDesc = new TableRow();
        myTbl.Rows.Add(trDesc);

        TableCell tcLastLine = null;
        foreach (WPProcessStep ps in pi.arrSteps)
        {
            //  Create a Hint String.  The format is:
            //  Start Time: time
            //  End Time: time
            //  Elapsed: Elapsed
            //  Status: status
            string Hint = "";

            Hint += "Start Time: ";
            if (ps.StartTime > DateTime.MinValue)
                Hint += ps.StartTime.ToString("MM/dd/yyyy  HH:mm:ss");
            else
                Hint += "Not started";

            Hint += "\r\nEnd Time: ";
            if (ps.EndTime > DateTime.MinValue)
                Hint += ps.EndTime.ToString("MM/dd/yyyy  HH:mm:ss");
            else
                Hint += "Not complete";

            Hint += "\r\nElapsed Time: ";
            if (ps.EndTime > DateTime.MinValue)
            {
                TimeSpan tsElapsed = ps.EndTime.Subtract(ps.StartTime);
                Hint += string.Format("{0}h {1}m {2}s", tsElapsed.Hours, tsElapsed.Minutes, tsElapsed.Seconds);
            }
            else
                Hint += "Not complete";

            Hint += "\r\nStatus: " + ps.StatusDesc;


            //  Build the Bar first.  It is made up of 3 bits, a line on the left (or spaces for first item),
            //  a colored dot based on the status, and another line (or spaces for the last item).
            TableCell tcLeftLine = new TableCell();
            TableCell tcDot = new TableCell();
            TableCell tcRgtLine = new TableCell();
            tr.Cells.Add(tcLeftLine);
            tr.Cells.Add(tcDot);
            tr.Cells.Add(tcRgtLine);

            tcLeftLine.Width = new Unit(67); //42);
            tcDot.Width = new Unit(15);
            tcRgtLine.Width = new Unit(68); //43);

            if (tcLastLine != null)
            {
                tcLeftLine.Style.Add(HtmlTextWriterStyle.BackgroundImage, "url(" + ImagesDir + "/pb-line.jpg)");
                tcLastLine.Style.Add(HtmlTextWriterStyle.BackgroundImage, "url(" + ImagesDir + "/pb-line.jpg)");
            }
            tcLastLine = tcRgtLine;

            Image imgDot = new Image();
            switch (ps.Status)
            {
                case "S":
                    imgDot.ImageUrl = ImagesDir + "/pb-green.jpg";
                    break;
                case "P":
                    imgDot.ImageUrl = ImagesDir + "/pb-yellow.jpg";
                    break;
                case "R":
                    imgDot.ImageUrl = ImagesDir + "/pb-blue.jpg";
                    break;
                case "E":
                    imgDot.ImageUrl = ImagesDir + "/pb-red.jpg";
                    break;
                case "C":
                    imgDot.ImageUrl = ImagesDir + "/pb-red.jpg";
                    break;
                default:
                    imgDot.ImageUrl = ImagesDir + "/pb-white.jpg";
                    break;
            }
            imgDot.ToolTip = Hint;
            tcDot.Controls.Add(imgDot);

            TableCell tcDesc = new TableCell();
            tcDesc.ColumnSpan = 3;
            tcDesc.HorizontalAlign = HorizontalAlign.Center;
            tcDesc.Wrap = true;
            trDesc.Cells.Add(tcDesc);
            Label lblDesc = new Label();
            lblDesc.Text = ps.StepDescription;
            lblDesc.ToolTip = Hint;
            lblDesc.SkinID = "ProgBarLbl";
            tcDesc.Controls.Add(lblDesc);
        }

        //  Create a summary line
        if (pi.arrSteps != null && pi.arrSteps.Count > 0)
        {
            TableRow trSum = new TableRow();
            myTbl.Rows.Add(trSum);
            TableCell tcSum = new TableCell();
            trSum.Cells.Add(tcSum);
            tcSum.ColumnSpan = myTbl.Rows[0].Cells.Count;

            Label lblSum = new Label();
            lblSum.SkinID = "ProgBarLbl";
            tcSum.Controls.Add(lblSum);

            if (((WPProcessStep)pi.arrSteps[pi.arrSteps.Count - 1]).EndTime == DateTime.MinValue)
            {
                //bool ErrFound = false;
                foreach (WPProcessStep ps in pi.arrSteps)
                {
                    if (ps.Status.Equals("E") || ps.Status.Equals("C"))
                    {
                        lblSum.Text = string.Format("The {0} process terminated with an error.", pi.Description);
                        break;
                    }
                    if (ps.StartTime != DateTime.MinValue && ps.EndTime == DateTime.MinValue)
                    {
                        lblSum.Text = string.Format("The {0} process is still running.", pi.Description);
                        break;
                    }
                }
            }
            else
            {
                TimeSpan tsSum = ((WPProcessStep)pi.arrSteps[pi.arrSteps.Count - 1]).EndTime.Subtract(
                    ((WPProcessStep)pi.arrSteps[0]).StartTime);
                lblSum.Text = string.Format("The {0} process ran for {1}h {2}m {3}s and had a final status of {4}",
                    pi.Description, tsSum.Hours, tsSum.Minutes, tsSum.Seconds,
                    ((WPProcessStep)pi.arrSteps[pi.arrSteps.Count - 1]).StatusDesc);
            }
        }

        return myTbl;
    }

    public static WPProcessInfo GetProcessInfo(string ProcessCode, string AsRelatesTo, int ProcessId, bool GetLatest, string Requestor)
    {
        BasicOraReader Rdr = new BasicOraReader(DbAccess.GetOracleConnStr());
        WPProcessInfo pi = new WPProcessInfo();
        string SelCmd;

        //  If the ProcessId = 0 and they want to get the latest, find the latest
        if (ProcessId == 0 && GetLatest == true)
        {
            SelCmd = string.Format(@"SELECT max(processid) FROM rpt_process_status_tbl
                where ProcessCode='{0}'", ProcessCode);
            if (AsRelatesTo.Length > 0)
                SelCmd += string.Format(" and asrelatesto='{0}'", AsRelatesTo);
            if (Rdr.Open(SelCmd) == false)
            {
                DbAccess.LogEvent(Requestor, "WPUtils", "GetProcessInfo", Rdr.LastErrorMessage, LogLevel.Error);
                return null;
            }

            //  If there is no process for this item, return a Progress Bar that says so.
            if (Rdr.oraRdr.Read() == true && Rdr.oraRdr.IsDBNull(0) == false)
                pi.ProcessId = ProcessId = (int)Rdr.oraRdr.GetDecimal(0);
        }

        //  If they supplied a ProcessID, but not the ProcessCode, lookup the process code
        if (ProcessId > 0 && (ProcessCode == null || ProcessCode.Length == 0))
        {
            SelCmd = string.Format(@"SELECT ProcessCode, AsRelatesTo FROM rpt_process_status_tbl
                where ProcessId={0}", ProcessId);
            if (Rdr.Open(SelCmd) == false)
            {
                DbAccess.LogEvent(Requestor, "WPUtils", "GetProcessInfo", SelCmd + ": " + Rdr.LastErrorMessage, LogLevel.Error);
                return null;
            }

            //  If there is no process for this item, return a Progress Bar that says so.
            if (Rdr.oraRdr.Read() == true)
            {
                ProcessCode = Rdr.oraRdr.GetString(0);
                AsRelatesTo = Rdr.oraRdr.GetString(1);
            }
        }

        pi.ProcessCode = ProcessCode;
        pi.AsRelatesTo = AsRelatesTo;
        pi.ProcessId = ProcessId;
        
        //  Retrieve the description
        SelCmd = string.Format(@"SELECT ProcessDescription FROM rpt_process_type_tbl
            where ProcessCode='{0}'", ProcessCode);
        if (AsRelatesTo.Length > 0)
            SelCmd += string.Format(" and asrelatesto='{0}'", AsRelatesTo);
        if (Rdr.Open(SelCmd) == false)
        {
            DbAccess.LogEvent(Requestor, "WPUtils", "GetProcessInfo", SelCmd + ": " + Rdr.LastErrorMessage, LogLevel.Error);
            return null;
        }

        //  If there is no process for this item, return a Progress Bar that says so.
        if (Rdr.oraRdr.Read() == true)
            pi.Description = Rdr.oraRdr.GetString(0);

        //  If we don't have a process id at this point, they just want the defined information without
        //  status information.
        if (ProcessId == 0)
        {
            //  Retrieve the Step information
            SelCmd = string.Format(@"SELECT a.seqnbr, a.step, a.stepdescription, a.notifyid, a.expectedduration
                FROM rpt_process_step_tbl a
                where ProcessCode='{0}'", ProcessCode);
            if (AsRelatesTo.Length > 0)
                SelCmd += string.Format(" and a.asrelatesto='{0}'", AsRelatesTo);
            SelCmd += " order by seqnbr";
            if (Rdr.Open(SelCmd) == false)
            {
                DbAccess.LogEvent(Requestor, "WPUtils", "GetProcessInfo", SelCmd + ": " + Rdr.LastErrorMessage, LogLevel.Error);
                return null;
            }

            pi.arrSteps = new ArrayList();

            //  If there is no process for this item, return a Progress Bar that says so.
            while (Rdr.oraRdr.Read() == true)
            {
                WPProcessStep ps = new WPProcessStep();
                ps.SeqNbr = (int) Rdr.oraRdr.GetDecimal(0);
                ps.Step = Rdr.oraRdr.GetString(1);
                ps.StepDescription = Rdr.oraRdr.GetString(2);
                ps.NotificationId = (int) Rdr.oraRdr.GetDecimal(3);
                ps.ExpectedDuration = (int) Rdr.oraRdr.GetDecimal(4);
                pi.arrSteps.Add(ps);
            }
            Rdr.Dispose();
            return pi;
        }

        //  Retrieve all the data for this process id so that we can build a Progress Bar.
        string SelSteps = string.Format(@"select s.seqnbr, s.step, s.stepdescription, s.notifyid, s.expectedduration, 
            p.ClosePeriod, p.starttime, p.endtime, p.status, p.message from 
            rpt_process_step_tbl s
            left outer join rpt_process_status_tbl p on ProcessId={0} and 
                p.ProcessCode=s.processcode and
                p.AsRelatesTo=s.asrelatesto and 
                p.Step = s.step
            where s.processCode='{1}' and s.AsRelatesTo='{2}'
            order by s.seqnbr", ProcessId, ProcessCode, AsRelatesTo);
        if (Rdr.Open(SelSteps) == false)
        {
            DbAccess.LogEvent(Requestor, "WPUtils", "GetProcessInfo", SelCmd + ": " + Rdr.LastErrorMessage, LogLevel.Error);
            return null;
        }

        pi.arrSteps = new ArrayList();
        while (Rdr.oraRdr.Read() == true)
        {
            WPProcessStep ps = new WPProcessStep();
            ps.SeqNbr = (int) Rdr.oraRdr.GetDecimal(0);
            ps.Step = Rdr.oraRdr.GetString(1);
            ps.StepDescription = Rdr.oraRdr.GetString(2);
            ps.NotificationId = (int) Rdr.oraRdr.GetDecimal(3);
            ps.ExpectedDuration = (int)Rdr.oraRdr.GetDecimal(4);
            if (Rdr.oraRdr.IsDBNull(5) == false)
                ps.ClosePeriod = Rdr.oraRdr.GetString(5);
            if (Rdr.oraRdr.IsDBNull(6) == false)
                ps.StartTime = Rdr.oraRdr.GetDateTime(6);
            if (Rdr.oraRdr.IsDBNull(7) == false)
                ps.EndTime = Rdr.oraRdr.GetDateTime(7);
            if (Rdr.oraRdr.IsDBNull(8) == false)
                ps.Status = Rdr.oraRdr.GetString(8);
            if (Rdr.oraRdr.IsDBNull(9) == false)
                ps.Message = Rdr.oraRdr.GetString(9);
            pi.arrSteps.Add(ps);
        }

        Rdr.Dispose();
        return pi;
    }
}
