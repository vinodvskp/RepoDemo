using System;
using System.Collections;
using System.Configuration;
using System.Data;
//using System.Web.Security;
//using System.Web.UI;
//using System.Web.UI.WebControls;
//using System.Web.UI.WebControls.WebParts;
//using System.Web.UI.HtmlControls;
using Oracle.DataAccess.Client;
using MDUA.DTO;

namespace MDUA.DataAccess
{
    /// <summary>
    /// Summary description for BasicSqlReader
    /// </summary>
    /// 



    public class BasicOraReader : IDisposable
    {
        private static string _DefaultConfigString = null;
        private static string _DefaultConnectionString = null;
        private string ConnString = "";
        private OracleConnection sqlConn = null;
        private OracleCommand sqlCmd = null;
        public OracleDataReader oraRdr = null;
        private string ErrMsg = "";

        // Track whether Dispose has been called.
        private bool disposed = false;


        public static string DefaultConfigString
        {
            set { _DefaultConfigString = value; }
            get { return _DefaultConfigString; }
        }

        public static string DefaultConnectionString
        {
            set { _DefaultConnectionString = value; }
            get { return _DefaultConnectionString; }
        }

        public string ConnectionString
        {
            set { ConnString = value; }
            get { return ConnString; }
        }

        public string LastErrorMessage
        {
            get { return ErrMsg; }
        }

        public BasicOraReader()
        {
            if (_DefaultConfigString != null && _DefaultConfigString.Length > 0)
                ConnString = ConfigurationManager.ConnectionStrings[_DefaultConfigString].ConnectionString;

            if (_DefaultConnectionString != null && _DefaultConnectionString.Length > 0)
                ConnString = _DefaultConnectionString;
        }

        public BasicOraReader(string ConnectionString)
        {
            ConnString = ConnectionString;
        }

        ~BasicOraReader()
        {
            Dispose(false);
        }

        public ReturnCodeDTO OpenReturn(string QueryString)
        {
            return OpenReturn(QueryString, null);
        }
       
        /// <summary>
        /// Opens an Oracle reader and returns a result object
        /// JEvans 12/9/2010
        /// </summary>
        /// <param name="QueryString">the selection query</param>
        /// <returns>a return code DTO</returns>
        public ReturnCodeDTO OpenReturn(string QueryString, params object[] Args)
        {
            ReturnCodeDTO rc = new ReturnCodeDTO();

            try
            {
                if (ConnString == null || ConnString.Length == 0)
                {
                    rc.Success = false;
                    rc.Message = "Connection is Null";
                }
                else
                {
                    sqlConn = new OracleConnection(ConnString);
                    sqlCmd = new OracleCommand(QueryString, sqlConn);

                    if (Args != null)
                    {
                        foreach (OracleParameter arg in Args)
                        {
                            if (arg != null)
                                sqlCmd.Parameters.Add(arg);
                        }
                    }

                    if (sqlConn.State != ConnectionState.Open)
                        sqlConn.Open();
                    oraRdr = sqlCmd.ExecuteReader();
                    rc.Success = true;
                }
            }
            catch (Exception ex)
            {
                rc.Message = string.Format("Exception: {0}<br>Stack:{1}", ex.Message, ex.StackTrace);
                ErrMsg = rc.Message;
                rc.Success = false;
                Close();
            }
            
            return rc;
        }

        public bool Open(string QueryString)
        {
            if (ConnString == null || ConnString.Length == 0)
                return false;

            Close();

            try
            {
                sqlConn = new OracleConnection(ConnString);
                sqlCmd = new OracleCommand(QueryString, sqlConn);
                sqlConn.Open();
                oraRdr = sqlCmd.ExecuteReader();
            }
            catch (Exception ex)
            {
                ErrMsg = ex.Message + "<br>" + ex.StackTrace;
                Close();
            }

            if (oraRdr != null)
                return true;

            return false;
        }

        public void Close()
        {
            if (oraRdr != null)
                oraRdr.Close();
            if (sqlConn != null)
            {
                sqlConn.Close();
                sqlConn.Dispose();
            }

            oraRdr = null;
            sqlConn = null;
        }

        #region IDisposable Members

        // Implement IDisposable.
        // Do not make this method virtual.
        // A derived class should not be able to override this method.
        public void Dispose()
        {
            Dispose(true);
            // Take yourself off the Finalization queue 
            // to prevent finalization code for this object
            // from executing a second time.
            GC.SuppressFinalize(this);
        }

        // Dispose(bool disposing) executes in two distinct scenarios.
        // If disposing equals true, the method has been called directly
        // or indirectly by a user's code. Managed and unmanaged resources
        // can be disposed.
        // If disposing equals false, the method has been called by the 
        // runtime from inside the finalizer and you should not reference 
        // other objects. Only unmanaged resources can be disposed.
        protected virtual void Dispose(bool disposing)
        {
            // Check to see if Dispose has already been called.
            if (!this.disposed)
            {
                // If disposing equals true, dispose all managed 
                // and unmanaged resources.
                if (disposing)
                {
                    // Dispose managed resources.
                    Close();
                }
                // Release unmanaged resources. If disposing is false, 
                // only the following code is executed.

                // Note that this is not thread safe.
                // Another thread could start disposing the object
                // after the managed resources are disposed,
                // but before the disposed flag is set to true.
                // If thread safety is necessary, it must be
                // implemented by the client.

            }
            disposed = true;
        }
        #endregion
    }


    public class BasicOraCommand : IDisposable
    {
        private OracleConnection sqlConn = null;
        private OracleCommand sqlCmd = null;
        private string ErrMsg = "";

        // Track whether Dispose has been called.
        private bool disposed = false;

        public string LastErrorMessage
        {
            get { return ErrMsg; }
        }

        public BasicOraCommand(string ConnStr)
        {
            sqlConn = new OracleConnection(ConnStr);
        }

        ~BasicOraCommand()
        {
            Dispose(false);
        }

        public int Exec(string Cmd)
        {
            return Exec(Cmd, null);
        }

        public int Exec(string Cmd, params object[] Args)
        {
            return Exec(Cmd, CommandType.Text, Args);
        }


        public ReturnCodeDTO ExecReturn(string Cmd, CommandType CmdType, params object[] Args)
        {
            ReturnCodeDTO rc = new ReturnCodeDTO();
            try
            {
                if (sqlConn == null)
                {
                    rc.Success = false;
                    rc.Message = "Connection is Null";
                }
                else
                {
                    sqlCmd = new OracleCommand(Cmd, sqlConn);
                    sqlCmd.CommandType = CmdType;
                    if (Args != null)
                    {
                        foreach (OracleParameter arg in Args)
                        {
                            if (arg != null)
                                sqlCmd.Parameters.Add(arg);
                        }
                    }
                    if (sqlConn.State != ConnectionState.Open)
                        sqlConn.Open();
                    rc.ReturnCode = sqlCmd.ExecuteNonQuery();
                    rc.Success = true;
                }
            }
            catch (Exception ex)
            {
                ErrMsg = ex.Message + "<br>" + ex.StackTrace;

                rc.Message = string.Format("Exception: {0}<br>Stack:{1}", ex.Message, ex.StackTrace);
                rc.Success = false;
                Close();
            }

            return rc;
        }

        public int Exec(string Cmd, CommandType CmdType, params object[] Args)
        {
            if (sqlConn == null)
                return -1;

            int Ret = -1;
            try
            {
                sqlCmd = new OracleCommand(Cmd, sqlConn);
                sqlCmd.CommandType = CmdType;
                sqlCmd.Parameters.Clear();
                if (Args != null)
                {
                    foreach (OracleParameter arg in Args)
                    {
                        if (arg != null)
                            sqlCmd.Parameters.Add(arg);
                    }
                }
                if (sqlConn.State != ConnectionState.Open)
                    sqlConn.Open();
                Ret = sqlCmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                ErrMsg = ex.Message + "<br>" + ex.StackTrace;
                Close();
            }

            return Ret;
        }

        public string Prepare(string Cmd, ArrayList Args)
        {
            if (sqlConn == null)
                return "Connection is not defined";

            string ErrMsg = "";
            try
            {
                sqlCmd = new OracleCommand(Cmd, sqlConn);
                if (Args != null)
                {
                    foreach (OracleParameter arg in Args)
                    {
                        if (arg != null)
                            sqlCmd.Parameters.Add(arg);
                    }
                }
                sqlCmd.Prepare();
            }
            catch (Exception ex)
            {
                ErrMsg = ex.Message + "<br>" + ex.StackTrace;
                Close();
            }

            return ErrMsg;
        }

        public void Open()
        {
            sqlConn.Open();
        }

        public void Open(string Cmd)
        {
            sqlConn.Open();
            if (sqlCmd == null)
                sqlCmd = new OracleCommand(Cmd, sqlConn);
            else
                sqlCmd.CommandText = Cmd;
        }

        public int ExecOpened(string Cmd)
        {
            return ExecOpened(Cmd, null);
        }

        public int ExecOpened(string Cmd, OracleParameter[] Args)
        {
            int Ret = -1;
            try
            {
                if (sqlCmd == null)
                    sqlCmd = new OracleCommand(Cmd, sqlConn);
                else
                    sqlCmd.CommandText = Cmd;
                if (Args != null)
                {
                    sqlCmd.Parameters.Clear();
                    foreach (OracleParameter arg in Args)
                    {
                        if (arg != null)
                            sqlCmd.Parameters.Add(arg);
                    }
                }
                if (sqlConn.State != ConnectionState.Open)
                    sqlConn.Open();
                Ret = sqlCmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                ErrMsg = ex.Message + "<br>" + ex.StackTrace;
            }

            return Ret;
        }

       
        public int ExecOpened()
        {
            int Ret = -1;
            try
            {
                if (sqlCmd == null)
                    return -1;

                Ret = sqlCmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                ErrMsg = ex.Message + "<br>" + ex.StackTrace;
            }

            return Ret;
        }

        public void Close()
        {
            if (sqlConn != null)
                sqlConn.Close();

            sqlConn = null;
        }

        #region IDisposable Members

        // Implement IDisposable.
        // Do not make this method virtual.
        // A derived class should not be able to override this method.
        public void Dispose()
        {
            Dispose(true);
            // Take yourself off the Finalization queue 
            // to prevent finalization code for this object
            // from executing a second time.
            GC.SuppressFinalize(this);
        }

        // Dispose(bool disposing) executes in two distinct scenarios.
        // If disposing equals true, the method has been called directly
        // or indirectly by a user's code. Managed and unmanaged resources
        // can be disposed.
        // If disposing equals false, the method has been called by the 
        // runtime from inside the finalizer and you should not reference 
        // other objects. Only unmanaged resources can be disposed.
        protected virtual void Dispose(bool disposing)
        {
            // Check to see if Dispose has already been called.
            if (!this.disposed)
            {
                // If disposing equals true, dispose all managed 
                // and unmanaged resources.
                if (disposing)
                {
                    // Dispose managed resources.
                    Close();
                }
                // Release unmanaged resources. If disposing is false, 
                // only the following code is executed.

                // Note that this is not thread safe.
                // Another thread could start disposing the object
                // after the managed resources are disposed,
                // but before the disposed flag is set to true.
                // If thread safety is necessary, it must be
                // implemented by the client.

            }
            disposed = true;
        }


        #endregion
    }
}