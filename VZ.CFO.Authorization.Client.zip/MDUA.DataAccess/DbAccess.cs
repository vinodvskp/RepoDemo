using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using MDUA.DTO;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;
using System.Reflection;
using System.Collections.Generic;

namespace MDUA.DataAccess {
    /// <summary>
    /// Summary description for DbAccess
    /// </summary>
    public class DbAccess {

        public DbAccess() {}

        #region locals

        private static string[] reportingFieldNames = new string[] {
            "DIM_RPT_REPORTNGLINE", "DIM_RPT_ACCOUNT", "DIM_RPT_KPI", "DIM_RPT_VIEW", 
            "DIM_RPT_SCENARIO", "DIM_RPT_PRODUCT", "DIM_RPT_SUBACCOUNT", "DIM_RPT_SERVICETYPE", 
            "DIM_RPT_FUNCTION", "DIM_RPT_COSTCENTER", "DIM_RPT_ENTITY", "DIM_RPT_COMPANY",
            "DIM_RPT_EQUIPMENT", "DIM_RPT_TECHTYPE", "DIM_RPT_YEARS", "DIM_RPT_TIME", 
            "FACT_RPT_MEASURE"  
        };
        private static string reportingFieldTypes = "SSSSSSSSSSSSSSSSN";

        private static string[] locationFieldNames = new string[] {
            "REPORTING_LINE", "ACCOUNT",   "KPI",  "VIEWS",  "SCENARIO", "PRODUCT", 
            "SUBACCOUNT",  "SERVICE_TYPE",  "FUNCTION",  "COST_CENTER",  "LOCATION", 
            "EQUIPMENT",  "TECH_TYPE",   
            "STORE_STATUS",  "DESIGN_TYPE",  "LOCATION_TYPE", "LOCATION_SUBTYPE",  
            "LOCATION_TIER_CODE", "YEAR", "TIME", "AMOUNT"};
        private static string locationFieldTypes = "SSSSSSSSSSSSSSSSSSSSN";

        private static string[] locationBudgetFieldNames = new string[] {
            "YEAR", "REPORTING_LINE", "ACCOUNT", "KPI", "VIEWS", "SCENARIO", 
            "PRODUCT", "SUBACCOUNT",  "SERVICE_TYPE",  "FUNCTION",  "COST_CENTER",  "LOCATION", 
            "EQUIPMENT",  "TECH_TYPE", "STORE_STATUS",  "DESIGN_TYPE",  "LOCATION_TYPE", "LOCATION_SUBTYPE",  
            "LOCATION_TIER_CODE",
            "BEGBAL", "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", 
            "AUG", "SEP", "OCT", "NOV", "DEC"};
        private static string locationBudgetFieldTypes = "SSSSSSSSSSSSSSSSSSSNNNNNNNNNNNNN";

        private static string[] equipmentFieldNames = new string[] {
            "FACT_DATE", "REPORTING_LINE", "ENTITY", "COST_CENTER", "KPI", "VIEWS",  
            "SCENARIO", "FUNCTION", "SERVICE_TYPE", "EQUIPMENT",  "TECH_TYPE",
            "METHODOLOGY_TYPE", "SALE_TYPE", "DISCOUNT_TYPE", "CONTRACT_TERM",
            "AMOUNT"
            };

        //private static string equipmentFieldTypes = "DSSSSSSSSSSSSSSN";

        private static string[] dataWarehouseFieldNames = new string[] {
            "BRANCH", "CONNECTION_TYPE", "EQUIPMENT", "PREVIOUS_TYPE", "FUNCTION",
	        "KPI", "ENTITY", "OWNING_GEOGRAPHY", "OWNING_MANAGER", "PRODUCT", "REPORTING_LINE",
	        "SCENARIO", "SEGMENT", "SERVICE_TYPE", "SUBACCOUNT", "TECH_TYPE", "VERSION",
	        "VERTICAL", "CUSTOMER_ACCOUNT", "VIEWS", "CONTRACT_TERM", "PROGRAM_ELIGIBILITY",
            "YEAR", "TIME", "AMOUNT"
        };

        private static string dataWarehouseFieldTypes = "SSSSSSSSSSSSSSSSSSSSSSSSN";

        private static string[] dataWarehouseBudgetFieldNames = new string[] {
            "BRANCH", "CONNECTION_TYPE", "EQUIPMENT", "PREVIOUS_TYPE", "FUNCTION",
	        "KPI", "ENTITY", "OWNING_GEOGRAPHY", "OWNING_MANAGER", "PRODUCT", "REPORTING_LINE",
	        "SCENARIO", "SEGMENT", "SERVICE_TYPE", "SUBACCOUNT", "TECH_TYPE", "VERSION",
	        "VERTICAL", "CUSTOMER_ACCOUNT", "VIEWS", "CONTRACT_TERM", "PROGRAM_ELIGIBILITY", "YEAR", "TIME",  
            "BEGBAL", "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", 
            "AUG", "SEP", "OCT", "NOV", "DEC" };
        private static string dataWarehouseBudgetFieldTypes = "SSSSSSSSSSSSSSSSSSSSSSSSNNNNNNNNNNNNN";

        private static string[] outlookFieldNames = new string[] {
            "DIM_RPT_REPORTNGLINE", "DIM_RPT_ACCOUNT", "DIM_RPT_KPI", "DIM_RPT_VIEW", 
            "DIM_RPT_SCENARIO", "DIM_RPT_PRODUCT", "DIM_RPT_SUBACCOUNT", 
            "DIM_RPT_SERVICETYPE", "DIM_RPT_FUNCTION", "DIM_RPT_COSTCENTER", "DIM_RPT_ENTITY", "DIM_RPT_COMPANY", 
            "DIM_RPT_EQUIPMENT", "DIM_RPT_TECHTYPE", 
            "DIM_RPT_YEARS", "BEGBAL", "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", 
            "AUG", "SEP", "OCT", "NOV", "DEC"
        };

        private static string outlookFieldTypes = "SSSSSSSSSSSSSSSNNNNNNNNNNNNN";

        #endregion
                
        #region public attributes

        //public static string AutosysCS {
        //    get { return ConfigurationManager.ConnectionStrings["AutosysCS"].ConnectionString; }
        //}

        //public static string AutosysSchema {
        //    get { return ConfigurationManager.AppSettings["AutosysSchema"]; }
        //}

        //public static string AutosysTablePrefix {
        //    get { return ConfigurationManager.AppSettings["AutosysTablePrefix"]; }
        //}
        
        public static int DefaultRowsToFetch {
            get { 
                int result;
                return Int32.TryParse(ConfigurationManager.AppSettings["DefaultRowsToFetch"], out result) ? result : 1000;
            } 
        }
        
        #endregion
        
        #region Connection String Routines
        
        private static byte[] Decrypt(byte[] cipherData, byte[] key, byte[] IV) {
            MemoryStream ms = new MemoryStream();
            Rijndael alg = Rijndael.Create();
            alg.Key = key;
            alg.IV = IV;
            CryptoStream cs = new CryptoStream(ms, alg.CreateDecryptor(), CryptoStreamMode.Write);
            cs.Write(cipherData, 0, cipherData.Length);
            cs.Close();
            byte[] decryptedData = ms.ToArray();
            return decryptedData;
        }

        // Decrypt a string into a string using a password
        // Uses Decrypt(byte[], byte[], byte[])
        private static string Decrypt(string cipherText, string password) {
            byte[] cipherBytes = Convert.FromBase64String(cipherText);
            PasswordDeriveBytes pdb = new PasswordDeriveBytes(password
                , new byte[] {
                    0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65,0x64, 0x76, 0x65, 0x64, 0x65, 0x76
                });
            byte[] decryptedData = Decrypt(cipherBytes, pdb.GetBytes(32), pdb.GetBytes(16));
            return System.Text.Encoding.Unicode.GetString(decryptedData);
        }

        public static string GetOracleConnectionString() {
            string encryptedConnectString = ConfigurationManager.AppSettings["OraDBEncrConnStr"];
            if (encryptedConnectString != null) {
                return Decrypt(encryptedConnectString, "HypMdua2008");
            }
            return ConfigurationManager.ConnectionStrings["ErpOracle"].ConnectionString;
        }

        public static string GetExcelConnectionString(string filename) {
            string fileExtension = Path.GetExtension(filename).ToLower();
            if (fileExtension.Equals(".xls")) {
                return string.Format(@"Provider=Microsoft.Jet.OLEDB.4.0; Data Source={0};Extended Properties=""Excel 8.0;IMEX=1;""", filename);
            } else if (fileExtension.Equals(".xlsx")) {
                return string.Format(@"Provider=Microsoft.ACE.OLEDB.12.0; Data Source={0};Extended Properties=""Excel 12.0 Xml;IMEX=1;""", filename);
            } 
            return string.Empty;
        }
                
        #endregion
        
        #region Lookup Table Routines

        public static WebSettings LoadWebSetting(string requestor) {
            WebSettings config = new WebSettings();
            BasicOraReader Rdr = new BasicOraReader(DbAccess.GetOracleConnectionString());
            try
            {
                if (Rdr.Open("select SettingName, SettingValue, userid from rpt_settings_tbl") == false)
                {
                    // throw exception so email gets sent 
                    throw new Exception(Rdr.LastErrorMessage);
                }

                while (Rdr.oraRdr.Read())
                {
                    if (Rdr.oraRdr.GetString(0).ToUpper().Equals("BROADCAST")) {
                        config.BroadcastMessage = Rdr.oraRdr.GetString(1);
                    } else if (Rdr.oraRdr.GetString(0).ToUpper().Equals("CURRPERIOD")) {
                        config.CurrentPeriod = Rdr.oraRdr.GetString(1);
                    } else if (Rdr.oraRdr.GetString(0).ToUpper().Equals("ENABLECOACOR")) {
                        config.CoaCorEnabled = Rdr.oraRdr.GetString(1).ToLower().Equals("true");
                        config.CoaCorUser = Rdr.oraRdr.GetString(2);
                    } else if (Rdr.oraRdr.GetString(0).ToUpper().Equals("ENABLEFEED")) {
                        config.UserFeedEnabled = Rdr.oraRdr.GetString(1).ToLower().Equals("true");
                        config.UserFeedUser = Rdr.oraRdr.GetString(2);
                    }
                }
                Rdr.Close();
                Rdr.Dispose();
                
                return config;
            }
            catch (Exception ex)
            {
                GeneralDatabaseAccess.LogEvent(requestor, "DBAccess.cs", "LoadWebSettings", ex, UserToolLogLevel.FatalError);
                return null;
            }
        }


        public static bool SaveWebSetting(WebSettings Settings, string Requestor)
        {
            WebSettings PrevSettings = LoadWebSetting(Requestor);

            BasicOraCommand Wrtr = new BasicOraCommand(DbAccess.GetOracleConnectionString());
            Wrtr.Open();
            string CmdFmt = @"Update rpt_settings_tbl 
            set SettingValue='{0}', userid='{1}', LastUpdateDate=sysdate 
            where Component='{2}' and SettingName='{3}'";
            string Cmd;
            if (PrevSettings.CoaCorEnabled != Settings.CoaCorEnabled)
            {
                Cmd = string.Format(CmdFmt, Settings.CoaCorEnabled ? "TRUE" : "FALSE",
                    Requestor, "USERFEED", "ENABLECOACOR");
                if (Wrtr.ExecOpened(Cmd) < 1)
                    GeneralDatabaseAccess.LogEvent(Requestor, "SaveWebSetting", Cmd, Wrtr.LastErrorMessage, UserToolLogLevel.Error);
                GeneralDatabaseAccess.LogEvent(Requestor, "SaveWebSetting",
                    Settings.CoaCorEnabled ? "Enabled CoaCor" : "Disabled CoaCor",
                    "Success", UserToolLogLevel.Audit);
            }
            if (PrevSettings.UserFeedEnabled != Settings.UserFeedEnabled)
            {
                Cmd = string.Format(CmdFmt, Settings.UserFeedEnabled ? "TRUE" : "FALSE",
                    Requestor, "USERFEED", "ENABLEFEED");
                if (Wrtr.ExecOpened(Cmd) < 1)
                    GeneralDatabaseAccess.LogEvent(Requestor, "SaveWebSetting", Cmd, Wrtr.LastErrorMessage, UserToolLogLevel.Error);
                // jevans 7/25/2012 - this event was examining "CoaCorEnabled" instead of "UserFeedEnabled"
                GeneralDatabaseAccess.LogEvent(Requestor, "SaveWebSetting",
                    Settings.UserFeedEnabled ? "Enabled User Feed" : "Disabled User Feed",
                    "Success", UserToolLogLevel.Audit);
            }
            if (PrevSettings.BroadcastMessage != Settings.BroadcastMessage)
            {
                Cmd = string.Format(CmdFmt, Settings.BroadcastMessage,
                    Requestor, "SYSTEM", "BROADCAST");
                if (Wrtr.ExecOpened(Cmd) < 1)
                    GeneralDatabaseAccess.LogEvent(Requestor, "SaveWebSetting", Cmd, Wrtr.LastErrorMessage, UserToolLogLevel.Error);
                GeneralDatabaseAccess.LogEvent(Requestor, "SaveWebSetting", "Broadcast Updated", "Success", UserToolLogLevel.Audit);
            }
            if (PrevSettings.CurrentPeriod != Settings.CurrentPeriod)
            {
                Cmd = string.Format(CmdFmt, Settings.CurrentPeriod,
                    Requestor, "SYSTEM", "CURRPERIOD");
                if (Wrtr.ExecOpened(Cmd) < 1)
                    GeneralDatabaseAccess.LogEvent(Requestor, "SaveWebSetting", Cmd, Wrtr.LastErrorMessage, UserToolLogLevel.Error);

                GeneralDatabaseAccess.LogEvent(Requestor, "SaveWebSetting",
                    "Current Period Changed to " + Settings.CurrentPeriod,
                    "Success", UserToolLogLevel.Audit);
            }
            Wrtr.Dispose();

            return true;
        }

        public static ArrayList GetDimYears()
        {
            BasicOraReader Rdr = new BasicOraReader(DbAccess.GetOracleConnectionString());
            ArrayList a = new ArrayList();
            if (Rdr.Open("select alias from web_dimensions_tbl where dim_type='YEARS' and not alias is null Order by alias"))
            {
                while (Rdr.oraRdr.Read())
                    a.Add(Rdr.oraRdr.GetString(0));
                Rdr.Close();
            }
            else
            {
                // throw exception so email gets sent 
                Rdr.Dispose();
                throw new Exception(Rdr.LastErrorMessage);
            }
            Rdr.Dispose();
            return a;

        }
        #endregion
        
        /*
        #region File Type Routines

        public static ArrayList GetFactTableNames()
        {
            string Cmd = "select fact_table_id||';'||fact_table_name fact_table_id, fact_table_desc FROM master_fact_table order by fact_table_desc";
            ArrayList a = new ArrayList();
            BasicOraReader Rdr = new BasicOraReader(DbAccess.GetOracleConnectionString());
            if (Rdr.Open(Cmd) == false)
                return null;

            while (Rdr.oraRdr.Read())
            {
                FactTableDTO f = new FactTableDTO();
                f.fact_table_id = Rdr.oraRdr.GetString(0);
                f.fact_table_desc = Rdr.oraRdr.GetString(1);
                a.Add(f);
            }// end while
            return a;
        }

        public static MasterFactTable GetFactTable(string FactTableId, string FactTableName, string Requestor)
        {
            string Cmd = "";
            try
            {
                MasterFactTable mft = new MasterFactTable();

                BasicOraReader Rdr = new BasicOraReader(DbAccess.GetOracleConnectionString());
                Cmd = @"Select fact_table_id, fact_table_name, fact_table_desc,
                       stage_table_year_name, stage_table_month_name,
                       pre_fact_load_procedure, key_combo_table_name, fact_table_with_outline_values, allows_adjustments
                from master_fact_table 
                where ";
                if (FactTableId.Length > 0)
                    Cmd += "fact_table_id=" + FactTableId;
                else
                    Cmd += "fact_table_name='" + FactTableName + "'";
                if (Rdr.Open(Cmd) == false)
                {
                    Rdr.Dispose();
                    throw new Exception(Rdr.LastErrorMessage);
                }

                if (Rdr.oraRdr.Read())
                {
                    int i = -1;
                    int.TryParse(Rdr.oraRdr.GetValue(++i).ToString(), out mft.FactTableId);
                    if (!Rdr.oraRdr.IsDBNull(++i))
                        mft.FactTableName = Rdr.oraRdr.GetString(i);
                    if (!Rdr.oraRdr.IsDBNull(++i))
                        mft.FactTableDesc = Rdr.oraRdr.GetString(i);
                    if (!Rdr.oraRdr.IsDBNull(++i))
                        mft.StageTableYearName = Rdr.oraRdr.GetString(i);
                    if (!Rdr.oraRdr.IsDBNull(++i))
                        mft.StageTableMonthName = Rdr.oraRdr.GetString(i);
                    if (!Rdr.oraRdr.IsDBNull(++i))
                        mft.PreFactLoadProcedure = Rdr.oraRdr.GetString(i).Trim();
                    if (!Rdr.oraRdr.IsDBNull(++i))
                        mft.KeyComboTableName = Rdr.oraRdr.GetString(i).Trim();
                    if (!Rdr.oraRdr.IsDBNull(++i))
                        mft.FactTableWithValues = Rdr.oraRdr.GetString(i).Trim();
                    if (!Rdr.oraRdr.IsDBNull(++i))
                        mft.AllowsAdjustments = Rdr.oraRdr.GetString(i).ToUpper().Equals("Y");

                    if (mft.FactTableName.ToUpper().StartsWith("RPT_")
                        || mft.FactTableName.ToUpper().StartsWith("CPGA_"))
                        mft.IsLegacy = true;
                }
                return mft;
            }
            catch (Exception ex)
            {
                GeneralDatabaseAccess.LogEvent(Requestor, "GetFactTable", Cmd, ex, LogLevel.Error);
                return null;
            }
        }

        public static bool AddUpdateFileType(HypFileType hft, string Requestor)
        {
            OracleConnection oraConn = new OracleConnection(GetOracleConnectionString());
            OracleCommand sqlCmd = null;
            string Cmd = null;
            bool bRet = false;
            try
            {
                Cmd = string.Format("Delete from ops_user_input_file where Input_File_code='{0}'",
                    hft.FileTypeCode);
                oraConn.Open();
                sqlCmd = new OracleCommand(Cmd, oraConn);
                if (sqlCmd.ExecuteNonQuery() > 0)
                {
                    Cmd = string.Format("Delete from ops_user_input_file_field where Input_File_code='{0}'",
                         hft.FileTypeCode);
                    sqlCmd.CommandText = Cmd;
                    sqlCmd.ExecuteNonQuery();
                }

                Cmd = string.Format("insert into ops_user_input_file (fact_table_id, Input_File_Code, Description, is_Adjustment, is_13Month, is_outlook, is_User_Feed, Uses_Valid_Keys, Show_On_Upload_Status,Scheduled_Load_Date,Dest_Table) values ({0},'{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}')",
                   hft.FactTableId, hft.FileTypeCode, hft.Description, (hft.isAdjustment ? "Y" : "N"),
                   (hft.is13Month ? "Y" : "N"), (hft.isOutlook ? "Y" : "N"), (hft.isUserFeed ? "Y" : "N"),
                   (hft.UsesValidKeyCombos ? "Y" : "N"), (hft.ShowOnUploadStatus ? "Y" : "N"),
                   hft.ScheduledLoadDate, hft.DestTable);
                sqlCmd.CommandText = Cmd;
                if (sqlCmd.ExecuteNonQuery() == 1)
                {
                    //  Add in the Field Information.
                    foreach (HypFileTypeFlds tFld in hft.arrFlds)
                    {
                        Cmd = string.Format("insert into ops_user_input_file_field (Input_File_Code, Member_Name, Forced_Value, Field_source) values ('{0}','{1}','{2}',{3})",
                        hft.FileTypeCode, tFld.FactColumnName, tFld.ForcedValue, (int)tFld.Source);
                        sqlCmd.CommandText = Cmd;
                        sqlCmd.ExecuteNonQuery();
                    }

                    GeneralDatabaseAccess.LogEvent(Requestor, "AddUpdateFileType", "AddUpdateFileType", "Success", LogLevel.Audit);
                    bRet = true;
                }
            }
            catch (Exception ex)
            {
                //  Log the error to a table.
                GeneralDatabaseAccess.LogEvent(Requestor, "AddUpdateFileType", Cmd, ex, LogLevel.Error);
            }
            finally
            {
                if (oraConn != null)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                }
            }

            return bRet;
        }

        public static int LockFileType(string FileType, string ClosePeriod, string UserId,
         string Requestor, out string ErrMsg)
        {
            ErrMsg = "";
            BasicOraReader Rdr = new BasicOraReader(DbAccess.GetOracleConnectionString());

            string Cmd = string.Format(@"Select As_relates_to FROM ops_run_status where process_name='INPUT_FILE' and as_relates_to='{0}' and
            NOT START_TIME IS NULL and END_TIME IS NULL",
                FileType);
            if (Rdr.Open(Cmd))
            {
                if (Rdr.oraRdr.Read())
                {
                    ErrMsg = string.Format("A {0} process is already running.  Please try again in about a minute.",
                        FileType);
                    Rdr.Dispose();
                    return -2;
                }
                Rdr.Close();
            }

            //  Add a process to reserve our spot.
            int SeqNbr = RunStatusAdd("INPUT_FILE", ClosePeriod, "In Progress", "Running",
                UserId, FileType);
            if (SeqNbr == -1)
            {
                ErrMsg = "RunStatusAdd failed to return a Sequence Number";
                return -1;
            }

            //  Verify that no one snuck in in front of use and is processing their stuff now.
            // jevans 3/15/2012 process_id mysteriously changed to run_status_id? 
            Cmd = string.Format(@"Select min(run_status_id) FROM ops_run_status where as_relates_to = '{0}' 
                    and NOT START_TIME IS NULL and END_TIME IS NULL",
                FileType);
            if (Rdr.Open(Cmd))
            {
                if (Rdr.oraRdr.Read() == false || Rdr.oraRdr.GetDecimal(0) != SeqNbr)
                {
                    ErrMsg = "A Task is already running that is blocking this request.  Please try again in a minute.";
                    RunStatusComplete(SeqNbr, "Error", "This Process was blocked by another process that is already running.", 0, FileType);
                    return -3;
                }
            }
            else
            {
                ErrMsg = "An error occurred while checking for existing process.";
                return -1;
            }

            return SeqNbr;
        }

        /// <summary>
        /// Returns array of file type based on either fact table, file type or requestor permission
        /// </summary>
        /// <param name="FactTableId">Fact Table ID</param>
        /// <param name="FileTypeCode">File Type Code</param>
        /// <param name="Requestor">Requestor Employee ID</param>
        /// <returns></returns>
        public static ArrayList GetFileTypes(int FactTableId, string FileTypeCode, string Requestor)
        {
            ArrayList arrTypes = new ArrayList();
            string Cmd = string.Empty;
            BasicOraReader Rdr = new BasicOraReader(DbAccess.GetOracleConnectionString());
            try
            {
                //  Get a list of File types based on fact id, type code, or ones this user can upload
                // jevans 24735 - 4/19/2012 - rewritten to retrieve stage naem and new dim name columns
                Cmd = string.Format(@"SELECT DISTINCT l.Input_File_Code, 
                            l.Description, 
                            l.Dest_Table,
                            m.stage_table_year_name,
                            m.stage_table_month_name, 
                            m.key_combo_table_name, 
                            l.fact_table_id,  
                            l.Is_Adjustment,
                            l.Is_13Month,
                            l.Is_User_Feed,
                            l.Uses_Valid_Keys,
                            l.is_outlook,
                            l.Show_On_Upload_Status,
                            l.Scheduled_Load_Date,
                            df.dimension_type_name,
                            f.Member_Name,
                            f.Forced_Value,
                            f.Field_Source
                    FROM ops_user_input_file l
                      join   master_fact_table m 
                        on l.fact_table_id= m.FACT_TABLE_ID 
                      left join   ops_user_input_file_field f
                        on l.Input_File_Code = f.Input_File_Code 
                      left join  map_dimension_fact_table df  
                        on  f.member_name  =  df.stage_table_column_name                     
                        and l.fact_table_id=df.FACT_TABLE_ID 
                    {0}
                    {1} 
                    {2} 
                    order by l.description, l.Input_File_Code, f.Member_Name ",
                    Requestor.Length == 0 ? "" : string.Format(" join ops_user_input_file_access u on l.Input_File_Code=u.Input_File_Code and u.EMPLOYEE_ID='{0}' ", Requestor),
                    FactTableId == 0 ? "" : string.Format(" WHERE l.fact_table_id={0}", FactTableId.ToString()),
                    FileTypeCode.Length == 0 ? "" : string.Format(" WHERE l.Input_File_Code='{0}'", FileTypeCode)
                    );

                if (Rdr.Open(Cmd) == false)
                    throw new Exception(Rdr.LastErrorMessage);

                HypFileType hft = null;
                while (Rdr.oraRdr.Read())
                {
                    int i = 0;
                    if (hft == null || hft.FileTypeCode.Equals(Rdr.oraRdr.GetString(0)) == false)
                    {
                        hft = new HypFileType();
                        hft.FileTypeCode = Rdr.oraRdr.GetString(i);
                        if (!Rdr.oraRdr.IsDBNull(++i))
                            hft.Description = Rdr.oraRdr.GetString(i);
                        if (!Rdr.oraRdr.IsDBNull(++i))
                            hft.DestTable = Rdr.oraRdr.GetString((i));
                        if (!Rdr.oraRdr.IsDBNull(++i))
                            hft.StgYearTable = Rdr.oraRdr.GetString((i));
                        if (!Rdr.oraRdr.IsDBNull(++i))
                            hft.StgMonthTable = Rdr.oraRdr.GetString((i));
                        if (!Rdr.oraRdr.IsDBNull(++i))
                            hft.ValKeyTable = Rdr.oraRdr.GetString((i));
                        int.TryParse(string.Format("{0}", Rdr.oraRdr[(++i)]), out hft.FactTableId);
                        string val = Rdr.oraRdr.GetString(++i).ToUpper();
                        hft.isAdjustment = (val[0] == 'Y');
                        val = Rdr.oraRdr.GetString(++i).ToUpper();
                        hft.is13Month = (val[0] == 'Y');
                        val = Rdr.oraRdr.GetString(++i).ToUpper();
                        hft.isUserFeed = (val[0] == 'Y');
                        val = Rdr.oraRdr.GetString(++i).ToUpper();
                        hft.UsesValidKeyCombos = (val[0] == 'Y');
                        val = Rdr.oraRdr.GetString(++i).ToUpper();
                        hft.isOutlook = (val[0] == 'Y');
                        val = Rdr.oraRdr.GetString(++i).ToUpper();
                        hft.ShowOnUploadStatus = (val[0] == 'Y');
                        if (Rdr.oraRdr.IsDBNull(++i) == false)
                            hft.ScheduledLoadDate = Rdr.oraRdr.GetString(i);
                        hft.SourceColName = hft.FactTableId == (int)FactTable.LocationUser
                                || hft.FactTableId == (int)FactTable.EquipmentUser
                                || hft.FactTableId == (int)FactTable.DataWarehouseUser
                                || hft.FactTableId == (int)FactTable.ProductOfferUser
                                ? "source" : "prp_rpt_source";

                        arrTypes.Add(hft);
                    }
                    i = 13;
                    if (Rdr.oraRdr.IsDBNull(++i) == false)
                    {
                        HypFileTypeFlds hftf = new HypFileTypeFlds();
                        hftf.DimensionTypeName = Rdr.oraRdr.GetString(i);
                        hftf.FactColumnName = Rdr.oraRdr.GetString(++i);
                        if (Rdr.oraRdr.IsDBNull(++i) == false)
                            hftf.ForcedValue = Rdr.oraRdr.GetString(i).Trim();
                        if (Rdr.oraRdr.IsDBNull(++i) == false)
                            hftf.Source = (HypFileTypeFldSource)Rdr.oraRdr.GetDecimal(i);
                        hft.arrFlds.Add(hftf);
                    }
                }
            }
            catch (Exception ex)
            {
                //  Log the error to a table.
                GeneralDatabaseAccess.LogEvent("", "GetInputFiles", Cmd, ex, LogLevel.Error);
                arrTypes = null;
            }

            Rdr.Close();
            return arrTypes;
        }

        public static bool AddUpdateInputFile(HypFileType hft, string Requestor)
        {
            BasicOraCommand Wrtr = new BasicOraCommand(DbAccess.GetOracleConnectionString());
            string Cmd = null;
            bool bRet = false;
            try
            {
                Cmd = string.Format("Delete from ops_user_input_file where Input_File_Code='{0}'",
                    hft.FileTypeCode);
                if (Wrtr.Exec(Cmd) > 0)
                {
                    Cmd = string.Format("Delete from ops_user_input_file_field where Input_File_Code='{0}'",
                         hft.FileTypeCode);
                    Wrtr.ExecOpened(Cmd);
                }
                else
                    if (Wrtr.LastErrorMessage.Length > 0)
                        throw new Exception(Wrtr.LastErrorMessage);

                Cmd = string.Format("insert into ops_user_input_file (fact_table_id, Input_File_Code, Description, is_Adjustment, is_13Month, is_outlook, is_User_Feed, Uses_Valid_Keys, Show_On_Upload_Status,Scheduled_Load_Date,Dest_Table) values ({0},'{1}','{2}','{3}','{4}','{5}','{6}','{7}','{8}','{9}','{10}')",
                    hft.FactTableId, hft.FileTypeCode, hft.Description, (hft.isAdjustment ? "Y" : "N"),
                    (hft.is13Month ? "Y" : "N"), (hft.isOutlook ? "Y" : "N"), (hft.isUserFeed ? "Y" : "N"),
                    (hft.UsesValidKeyCombos ? "Y" : "N"), (hft.ShowOnUploadStatus ? "Y" : "N"),
                    hft.ScheduledLoadDate, hft.DestTable);

                if (Wrtr.ExecOpened(Cmd) == 1)
                {
                    //  Add in the Field Information.
                    foreach (HypFileTypeFlds tFld in hft.arrFlds)
                    {
                        Cmd = string.Format("insert into ops_user_input_file_field (Input_File_Code, Member_Name, Forced_Value, Field_source) values ('{0}','{1}','{2}',{3})",
                            hft.FileTypeCode, tFld.FactColumnName, tFld.ForcedValue, (int)tFld.Source);
                        Wrtr.ExecOpened(Cmd);
                    }

                    LogEvent(Requestor, "AddUpdateInputFile",
                       "AddUpdateInputFile", "Success", LogLevel.Audit);
                    bRet = true;
                }
            }
            catch (Exception ex)
            {
                //  Log the error to a table.
                GeneralDatabaseAccess.LogEvent(Requestor, "AddUpdateInputFile", Cmd, ex, LogLevel.Error);
            }

            if (Wrtr != null)
                Wrtr.Dispose();

            return bRet;
        }

        public static int RunNonQuery(string Cmd, string ConnectStr, string Requestor)
        {
            OracleConnection oraConn = new OracleConnection(ConnectStr);
            OracleCommand sqlCmd = null;
            int iRet = -1;
            try
            {
                oraConn.Open();
                sqlCmd = new OracleCommand(Cmd, oraConn);
                iRet = sqlCmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                //  Log the error to a table.
                GeneralDatabaseAccess.LogEvent(Requestor, "RunNonQuery", Cmd, ex, LogLevel.Error);
            }
            finally
            {
                if (oraConn != null)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                }
            }
            return iRet;
        }

        public static bool DeleteInputFileType(string InputFileCode, string Requestor)
        {
            string Cmd = string.Format("Delete from ops_user_input_file where Input_File_Code='{0}'",
                InputFileCode);

            if (RunNonQuery(Cmd, DbAccess.GetOracleConnectionString(), Requestor) == -1)
                return false;

            Cmd = string.Format("Delete from ops_user_input_file_field where Input_File_Code='{0}'",
                 InputFileCode);
            if (RunNonQuery(Cmd, DbAccess.GetOracleConnectionString(), Requestor) == -1)
                return false;

            GeneralDatabaseAccess.LogEvent(Requestor, "UserInputFile.aspx", "Delete File Type",
                string.Format("File Type {0} was deleted", InputFileCode), LogLevel.Audit);
            return true;

        }

        // called by OPS upload input file
        public static DataSet callInputFilePreFactLoad(string StoredProcName, string RunId, string Requestor)
        {
            OracleConnection oraConn = new OracleConnection(GetOracleConnectionString());
            OracleCommand sqlCmd = null;
            DataSet dsResult = null;
            try
            {
                oraConn.Open();

                sqlCmd = new OracleCommand(StoredProcName, oraConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                OracleParameter pRunId = new OracleParameter("i_run_id", OracleDbType.Int32, ParameterDirection.Input);
                OracleParameter pRowSet = new OracleParameter("p_rowset", OracleDbType.RefCursor, ParameterDirection.Output);

                pRunId.Value = Int32.Parse(RunId);

                sqlCmd.Parameters.Add(pRunId);
                sqlCmd.Parameters.Add(pRowSet);

                dsResult = new DataSet();
                OracleDataAdapter da = new OracleDataAdapter(sqlCmd);
                da.Fill(dsResult);
            }
            catch (Exception ex)
            {
                //  Log the error to a table.
                GeneralDatabaseAccess.LogEvent(Requestor, "callInputFilePreFactLoad", StoredProcName, ex, LogLevel.Error);
                if (dsResult != null)
                {
                    dsResult.Dispose();
                    dsResult = null;
                }
            }
            finally
            {
                if (oraConn != null)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                }
            }
            return dsResult;
        }

        #endregion
        */

        #region Dimension Related Routines

        public static ArrayList GetDimensions(string dimensionType, string tableName, string requestor) {
            string sqlText = string.Empty;
            ArrayList dimensions = new ArrayList();
            Dimension dimension = null;
            int index = 0;

            try {
                sqlText = (tableName == "V_EQUIPMENT_DIMENSIONS" || tableName == "V_DW_DIMENSIONS" || tableName == "v_product_offer_dimensions" || tableName == "V_ASO_PLANNING_DIMENSIONS" || tableName == "V_DPLOAN_DIMENSIONS")
                    ? string.Format(
@"select parent_name, member_name, alias_name, storage_value, level_number, generation
  from {0} where upper(dimension_name)='{1}'", tableName, dimensionType)
                    : string.Format(
@"select parent, member_name, alias, dim_storage, level_nbr, generation_nbr 
  from {0} where dim_type='{1}'", tableName, dimensionType);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        while (reader.Read()) {
                            int i = 0;
                            dimension = new Dimension();
                            if (!reader.IsDBNull(i)) dimension.Parent = reader.GetString(i);
                            if (!reader.IsDBNull(++i)) dimension.MemberName = reader.GetString(i);
                            if (!reader.IsDBNull(++i)) dimension.Alias = reader.GetString(i);
                            if (!reader.IsDBNull(++i)) dimension.Storage = reader[i].ToString();
                            if (!reader.IsDBNull(++i)) {
                                dimension.LevelNbr = (reader.GetFieldType(i) == typeof(decimal)) ? reader.GetDecimal(i).ToString("0") : dimension.LevelNbr = reader.GetString(i);
                            }
                            if (!reader.IsDBNull(++i)) {
                                dimension.GenerationNbr = (reader.GetFieldType(i) == typeof(decimal)) ? reader.GetDecimal(i).ToString("0") : dimension.GenerationNbr = reader.GetString(i);
                            }
                            index = dimensions.BinarySearch(dimension);
                            if (index < 0) {
                                index = -index - 1;
                            }
                            dimensions.Insert(index, dimension);
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                dimensions = null;
            }
            return dimensions;
        }

        

        // called by opsfiletypes
        public static ReturnCodeDTO ValidDimension(string DimName, string ValidationField, string ValTableName, string AliasName, string Value, string ExtraValidationClause)
        {
            ReturnCodeDTO rc = new ReturnCodeDTO();
            string Cmd = string.Format("Select {0} from {1} {2} where {2}.{0}='{3}'",
               ValidationField, ValTableName, AliasName, Value);
            if (ExtraValidationClause.Length > 0)
                Cmd = string.Format("{0} and {1}", Cmd, ExtraValidationClause);

            rc.ReturnCode = 0;
            rc.Success = true;

            BasicOraReader Rdr = new BasicOraReader(DbAccess.GetOracleConnectionString());
            rc = Rdr.OpenReturn(Cmd);
            if (rc.Success == false)
            {
                GeneralDatabaseAccess.LogEvent("", "DbAccess", "ValidDimension", rc.Message, UserToolLogLevel.Error);
                rc.Message = string.Format("There was an error validating from the {0} table", ValTableName);
            } else if (Rdr.oraRdr.Read() == false)
            {
                rc.Message = string.Format("{0} is not a valid {1} value", Value, DimName);
                rc.ReturnCode = 1;
            }
            Rdr.Dispose();

            return rc;
        }

        #endregion
        
        #region User Data Input Files

        public static bool DeleteUserStageData(FileType fileType, DateTime dateCreated, string requestor) {
            string sqlText = string.Empty;
            string sqlText13Month = string.Empty;
            bool returnValue = false;
            int recordsDeleted = 0;

            try {
                switch ((FactTable)fileType.FactTableId) {
                    case FactTable.LocationUser:
                    case FactTable.EquipmentUser:
                    case FactTable.DataWarehouseUser:
                        sqlText = string.Format("delete from {0} where date_created=to_date('{1}', 'yyyy/mm/dd HH24.MI.SS')", fileType.StageMonthTable, dateCreated.ToString("yyyy/MM/dd HH:mm:ss"));
                        sqlText13Month = string.Format("delete from {0} where date_created=to_date('{1}', 'yyyy/mm/dd HH24.MI.SS')", fileType.StageYearTable, dateCreated.ToString("yyyy/MM/dd HH:mm:ss"));
                        break;
                    default:
                        sqlText = string.Format("delete from {0} where prp_rpt_createmodifydate=to_date('{1}', 'yyyy/mm/dd HH24.MI.SS')", fileType.StageMonthTable, dateCreated.ToString("yyyy/MM/dd HH:mm:ss"));
                        sqlText13Month = string.Format("delete from {0} where prp_rpt_createmodifydate=to_date('{1}', 'yyyy/mm/dd HH24.MI.SS')", fileType.StageYearTable, dateCreated.ToString("yyyy/MM/dd HH:mm:ss"));
                        break;
                }

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = connection.CreateCommand()) {
                    connection.Open();
                    using (OracleTransaction transaction = connection.BeginTransaction()) {
                        command.CommandText = sqlText;
                        recordsDeleted = command.ExecuteNonQuery();
                        if (fileType.Is13Month) {
                            sqlText = sqlText13Month;
                            command.CommandText = sqlText;
                            recordsDeleted += command.ExecuteNonQuery();
                        }
                        returnValue = true;
                        transaction.Commit();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(requestor, MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                returnValue = false;
            }

            return returnValue;
        }
                
        public static int LoadReportingExcelToStage(string filename, FileType fileType, DateTime now, string owner, bool checkFact, out string message) {
            const int maxRowsPerUpdate = 2000;
            int totalRecordsAdded = -2;     // total records returned: -1 user error, -2 program error
            int rowsImpacted = 0;
            int rowsSkipped = 0;
            int currentBindArrayIndex = 0;
            int index;
            string sqlText = string.Empty;
            message = string.Empty;         // the return string 
            int excelRowsRead = 0;
            int numberNullFields;
            double amountValue;
            short tempShort;
            string[] fieldNames = fileType.IsOutlook || fileType.Is13Month ? DbAccess.outlookFieldNames : DbAccess.reportingFieldNames;
            string fieldTypes = fileType.IsOutlook || fileType.Is13Month ? DbAccess.outlookFieldTypes : DbAccess.reportingFieldTypes;
            Dictionary<string, int> fieldReferences = new Dictionary<string, int>();

            List<int> lineNumbersList = new List<int>();
            List<string> reportingLineList = new List<string>();
            List<string> accountList = new List<string>();
            List<string> kpiList = new List<string>();
            List<string> viewsList = new List<string>();
            List<string> scenarioList = new List<string>();
            List<string> productList = new List<string>();
            List<string> subaccountList = new List<string>();
            List<string> serviceTypeList = new List<string>();
            List<string> functionList = new List<string>();
            List<string> costCenterList = new List<string>();
            List<string> entityList = new List<string>();
            List<string> companyList = new List<string>();
            List<string> equipmentList = new List<string>();
            List<string> techTypeList = new List<string>();
            List<string> fiscalYearList = new List<string>();
            List<string> fiscalMonthList = new List<string>();
            List<double> amountList = new List<double>();
            List<OracleParameterStatus> amountNullList = new List<OracleParameterStatus>();
            List<double> begbalAmountList = new List<double>();
            List<OracleParameterStatus> begbalAmountNullList = new List<OracleParameterStatus>();
            List<double> januaryAmountList = new List<double>();
            List<OracleParameterStatus> januaryAmountNullList = new List<OracleParameterStatus>();
            List<double> februaryAmountList = new List<double>();
            List<OracleParameterStatus> februaryAmountNullList = new List<OracleParameterStatus>();
            List<double> marchAmountList = new List<double>();
            List<OracleParameterStatus> marchAmountNullList = new List<OracleParameterStatus>();
            List<double> aprilAmountList = new List<double>();
            List<OracleParameterStatus> aprilAmountNullList = new List<OracleParameterStatus>();
            List<double> mayAmountList = new List<double>();
            List<OracleParameterStatus> mayAmountNullList = new List<OracleParameterStatus>();
            List<double> juneAmountList = new List<double>();
            List<OracleParameterStatus> juneAmountNullList = new List<OracleParameterStatus>();
            List<double> julyAmountList = new List<double>();
            List<OracleParameterStatus> julyAmountNullList = new List<OracleParameterStatus>();
            List<double> augustAmountList = new List<double>();
            List<OracleParameterStatus> augustAmountNullList = new List<OracleParameterStatus>();
            List<double> septemberAmountList = new List<double>();
            List<OracleParameterStatus> septemberAmountNullList = new List<OracleParameterStatus>();
            List<double> octoberAmountList = new List<double>();
            List<OracleParameterStatus> octoberAmountNullList = new List<OracleParameterStatus>();
            List<double> novemberAmountList = new List<double>();
            List<OracleParameterStatus> novemberAmountNullList = new List<OracleParameterStatus>();
            List<double> decemberAmountList = new List<double>();
            List<OracleParameterStatus> decemberAmountNullList = new List<OracleParameterStatus>();

            try {
                string missingUploadFields = string.Empty;

                sqlText = string.Format(" select * from [{0}$]", fileType.FileTypeCode);

                using (OleDbConnection excelConnection = new OleDbConnection(GetExcelConnectionString(filename)))
                using (OleDbCommand excelCommand = new OleDbCommand(sqlText, excelConnection)) {
                    excelConnection.Open();

                    using (OleDbDataReader excelReader = excelCommand.ExecuteReader()) {
                        //  Check each field that should be in the file and make sure it is there.
                        for (int i = 0; i < fieldNames.Length; i++) {
                            bool matchWasFound = false;
                            for (int j = 0; j < excelReader.VisibleFieldCount; j++) {
                                if (fieldNames[i].Equals(excelReader.GetName(j).ToUpper())) {
                                    matchWasFound = true;
                                    fieldReferences.Add(fieldNames[i], j);  // capture index for later use
                                    break;
                                }
                            }
                            if (!matchWasFound) {
                                missingUploadFields += "<li>" + fieldNames[i];
                            }
                        }
                        if (missingUploadFields.Length > 1) {
                            message = string.Format("The Load Process failed to find the following field(s) in the file: {0}<br>", missingUploadFields);
                            return -1;
                        }

                        using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                        using (OracleCommand command = connection.CreateCommand()) {
                            connection.Open();
                            using (OracleTransaction transaction = connection.BeginTransaction()) {
                                sqlText = string.Format("delete from {0} where prp_rpt_source='{1}'"
                                    , fileType.Is13Month || fileType.IsOutlook ? fileType.StageYearTable : fileType.StageMonthTable
                                    , fileType.FileTypeCode);
                                command.CommandText = sqlText;
                                rowsImpacted = command.ExecuteNonQuery();
                                
                                sqlText = string.Format(
@"insert into {0} (
    prp_rpt_source, prp_rpt_owner, prp_rpt_createmodifydate, linenbr, dim_rpt_reportngline, dim_rpt_account, dim_rpt_kpi, dim_rpt_view
    , dim_rpt_scenario, dim_rpt_product, dim_rpt_subaccount, dim_rpt_servicetype, dim_rpt_function, dim_rpt_costcenter, dim_rpt_entity
    , dim_rpt_company, dim_rpt_equipment, dim_rpt_techtype{1}
  ) values (
    '{2}', '{3}', to_date('{4}','YYYYMMDD HH24:MI:SS'), :line_nbr, :dim_rpt_reportngline, :dim_rpt_account, :dim_rpt_kpi, :dim_rpt_view
    , :dim_rpt_scenario, :dim_rpt_product, :dim_rpt_subaccount, :dim_rpt_servicetype, :dim_rpt_function, :dim_rpt_costcenter, :dim_rpt_entity
    , :dim_rpt_company, :dim_rpt_equipment, :dim_rpt_techtype{5}
  )"
                                    , fileType.Is13Month || fileType.IsOutlook ? fileType.StageYearTable : fileType.StageMonthTable
                                    , checkFact 
                                        ? (fileType.Is13Month || fileType.IsOutlook
                                            ? ", dim_rpt_years, begbal, jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, dec"
                                            : ", dim_rpt_years, dim_rpt_time, fact_rpt_measure") 
                                        : string.Empty
                                    , fileType.FileTypeCode
                                    , owner
                                    , now.ToString("yyyyMMdd HH:mm:ss")
                                    , checkFact 
                                        ? (fileType.Is13Month || fileType.IsOutlook
                                            ? ", :dim_rpt_years, :begbal, :jan, :feb, :mar, :apr, :may, :jun, :jul, :aug, :sep, :oct, :nov, :dec"
                                            : ", :dim_rpt_years, :dim_rpt_time, :fact_rpt_measure") 
                                        : string.Empty);
                                
                                command.Parameters.Clear();
                                command.CommandText = sqlText;

                                // add parameters
                                command.Parameters.Add(new OracleParameter(":line_nbr", OracleDbType.Int32));
                                command.Parameters.Add(new OracleParameter(":dim_rpt_reportngline", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":dim_rpt_account", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":dim_rpt_kpi", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":dim_rpt_view", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":dim_rpt_scenario", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":dim_rpt_product", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":dim_rpt_subaccount", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":dim_rpt_servicetype", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":dim_rpt_function", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":dim_rpt_costcenter", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":dim_rpt_entity", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":dim_rpt_company", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":dim_rpt_equipment", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":dim_rpt_techtype", OracleDbType.Varchar2));

                                if (checkFact) {
                                    command.Parameters.Add(new OracleParameter(":dim_rpt_years", OracleDbType.Varchar2));                                    
                                    if (fileType.Is13Month || fileType.IsOutlook) {
                                        command.Parameters.Add(new OracleParameter(":begbal", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":jan", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":feb", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":mar", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":apr", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":may", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":jun", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":jul", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":aug", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":sep", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":oct", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":nov", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":dec", OracleDbType.Double));
                                    } else {
                                        command.Parameters.Add(new OracleParameter(":dim_rpt_time", OracleDbType.Varchar2));
                                        command.Parameters.Add(new OracleParameter(":fact_rpt_measure", OracleDbType.Double));
                                    }
                                }

                                command.BindByName = true;

                                totalRecordsAdded = 0;
                                while (excelReader.Read()) {
                                    excelRowsRead++;
                                    numberNullFields = 0;
                                    foreach (int i in fieldReferences.Values) {
                                        if (excelReader.IsDBNull(i)) numberNullFields++;
                                    }

                                    //TODO: Not sure about - 2
                                    // skip if all fields are null
                                    if (numberNullFields >= fieldNames.Length - 2) {
                                        rowsSkipped++;
                                        continue;
                                    }

                                    lineNumbersList.Add(excelRowsRead);
                                    reportingLineList.Add(excelReader.GetValue(fieldReferences["DIM_RPT_REPORTNGLINE"]).ToString().Trim());
                                    accountList.Add(excelReader.GetValue(fieldReferences["DIM_RPT_ACCOUNT"]).ToString().Trim());
                                    kpiList.Add(excelReader.GetValue(fieldReferences["DIM_RPT_KPI"]).ToString().Trim());
                                    viewsList.Add(excelReader.GetValue(fieldReferences["DIM_RPT_VIEW"]).ToString().Trim());
                                    scenarioList.Add(excelReader.GetValue(fieldReferences["DIM_RPT_SCENARIO"]).ToString().Trim());
                                    productList.Add(excelReader.GetValue(fieldReferences["DIM_RPT_PRODUCT"]).ToString().Trim());
                                    subaccountList.Add(excelReader.GetValue(fieldReferences["DIM_RPT_SUBACCOUNT"]).ToString().Trim());
                                    serviceTypeList.Add(excelReader.GetValue(fieldReferences["DIM_RPT_SERVICETYPE"]).ToString().Trim());
                                    functionList.Add(excelReader.GetValue(fieldReferences["DIM_RPT_FUNCTION"]).ToString().Trim());
                                    costCenterList.Add(excelReader.GetValue(fieldReferences["DIM_RPT_COSTCENTER"]).ToString().Trim());
                                    entityList.Add(excelReader.GetValue(fieldReferences["DIM_RPT_ENTITY"]).ToString().Trim());
                                    companyList.Add(excelReader.GetValue(fieldReferences["DIM_RPT_COMPANY"]).ToString().Trim());
                                    equipmentList.Add(excelReader.GetValue(fieldReferences["DIM_RPT_EQUIPMENT"]).ToString().Trim());
                                    techTypeList.Add(excelReader.GetValue(fieldReferences["DIM_RPT_TECHTYPE"]).ToString().Trim());

                                    if (checkFact) {
                                        // validate year is a number
                                        if (!Int16.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["DIM_RPT_YEARS"])), out tempShort)) {
                                            message = string.Format("The column 'DIM_RPT_YEARS' in row {0} contains an invalid value.", excelRowsRead);
                                            return -1;
                                        } else {
                                            fiscalYearList.Add(Convert.ToString(tempShort));
                                        }

                                        if (fileType.Is13Month || fileType.IsOutlook) {
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["BEGBAL"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                begbalAmountList.Add(amountValue);
                                                begbalAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                begbalAmountList.Add(0); // placeholder in array
                                                begbalAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["JAN"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                januaryAmountList.Add(amountValue);
                                                januaryAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                januaryAmountList.Add(0); // placeholder in array
                                                januaryAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["FEB"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                februaryAmountList.Add(amountValue);
                                                februaryAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                februaryAmountList.Add(0); // placeholder in array
                                                februaryAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["MAR"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                marchAmountList.Add(amountValue);
                                                marchAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                marchAmountList.Add(0); // placeholder in array
                                                marchAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["APR"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                aprilAmountList.Add(amountValue);
                                                aprilAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                aprilAmountList.Add(0); // placeholder in array
                                                aprilAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["MAY"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                mayAmountList.Add(amountValue);
                                                mayAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                mayAmountList.Add(0); // placeholder in array
                                                mayAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["JUN"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                juneAmountList.Add(amountValue);
                                                juneAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                juneAmountList.Add(0); // placeholder in array
                                                juneAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["JUL"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                julyAmountList.Add(amountValue);
                                                julyAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                julyAmountList.Add(0); // placeholder in array
                                                julyAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                           
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["AUG"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                augustAmountList.Add(amountValue);
                                                augustAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                augustAmountList.Add(0); // placeholder in array
                                                augustAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["SEP"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                septemberAmountList.Add(amountValue);
                                                septemberAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                septemberAmountList.Add(0); // placeholder in array
                                                septemberAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["OCT"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                octoberAmountList.Add(amountValue);
                                                octoberAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                octoberAmountList.Add(0); // placeholder in array
                                                octoberAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["NOV"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                novemberAmountList.Add(amountValue);
                                                novemberAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                novemberAmountList.Add(0); // placeholder in array
                                                novemberAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["DEC"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                decemberAmountList.Add(amountValue);
                                                decemberAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                decemberAmountList.Add(0); // placeholder in array
                                                decemberAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                        } else {
                                            // validate that the time period is a number
                                            if (!Int16.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["DIM_RPT_TIME"])), out tempShort)) {
                                                message = string.Format("The column 'DIM_RPT_TIME' in row {0} contains an invalid value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                fiscalMonthList.Add(Convert.ToString(tempShort));
                                            }

                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["FACT_RPT_MEASURE"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                amountList.Add(amountValue);
                                                amountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                amountList.Add(0); // placeholder in array
                                                amountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                        } 
                                    }
                                        
                                    currentBindArrayIndex++;
                                    index = 0;
                                    if (currentBindArrayIndex == maxRowsPerUpdate) {
                                        command.Parameters[index].Value = lineNumbersList.ToArray();
                                        command.Parameters[++index].Value = reportingLineList.ToArray();
                                        command.Parameters[++index].Value = accountList.ToArray();
                                        command.Parameters[++index].Value = kpiList.ToArray();
                                        command.Parameters[++index].Value = viewsList.ToArray();
                                        command.Parameters[++index].Value = scenarioList.ToArray();
                                        command.Parameters[++index].Value = productList.ToArray();
                                        command.Parameters[++index].Value = subaccountList.ToArray();
                                        command.Parameters[++index].Value = serviceTypeList.ToArray();
                                        command.Parameters[++index].Value = functionList.ToArray();
                                        command.Parameters[++index].Value = costCenterList.ToArray();
                                        command.Parameters[++index].Value = entityList.ToArray();
                                        command.Parameters[++index].Value = companyList.ToArray();
                                        command.Parameters[++index].Value = equipmentList.ToArray();
                                        command.Parameters[++index].Value = techTypeList.ToArray();
                                        if (checkFact) {
                                            command.Parameters[++index].Value = fiscalYearList.ToArray();
                                            if (fileType.Is13Month || fileType.IsOutlook) {
                                                command.Parameters[++index].Value = begbalAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = begbalAmountNullList.ToArray();
                                                command.Parameters[++index].Value = januaryAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = januaryAmountNullList.ToArray();
                                                command.Parameters[++index].Value = februaryAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = februaryAmountNullList.ToArray();
                                                command.Parameters[++index].Value = marchAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = marchAmountNullList.ToArray();
                                                command.Parameters[++index].Value = aprilAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = aprilAmountNullList.ToArray();
                                                command.Parameters[++index].Value = mayAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = mayAmountNullList.ToArray();
                                                command.Parameters[++index].Value = juneAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = juneAmountNullList.ToArray();
                                                command.Parameters[++index].Value = julyAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = julyAmountNullList.ToArray();
                                                command.Parameters[++index].Value = augustAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = augustAmountNullList.ToArray();
                                                command.Parameters[++index].Value = septemberAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = septemberAmountNullList.ToArray();
                                                command.Parameters[++index].Value = octoberAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = octoberAmountNullList.ToArray();
                                                command.Parameters[++index].Value = novemberAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = novemberAmountNullList.ToArray();
                                                command.Parameters[++index].Value = decemberAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = decemberAmountNullList.ToArray();
                                            } else {
                                                command.Parameters[++index].Value = fiscalMonthList.ToArray();
                                                command.Parameters[++index].Value = amountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = amountNullList.ToArray();
                                            }
                                        }
                                        command.ArrayBindCount = currentBindArrayIndex;
                                        totalRecordsAdded += command.ExecuteNonQuery();
                                        currentBindArrayIndex = 0;
                                        lineNumbersList.Clear();
                                        reportingLineList.Clear();
                                        accountList.Clear();
                                        kpiList.Clear();
                                        viewsList.Clear();
                                        scenarioList.Clear();
                                        productList.Clear();
                                        subaccountList.Clear();
                                        serviceTypeList.Clear();
                                        functionList.Clear();
                                        costCenterList.Clear();
                                        entityList.Clear();
                                        companyList.Clear();
                                        equipmentList.Clear();
                                        techTypeList.Clear();

                                        if (checkFact) {
                                            fiscalYearList.Clear();
                                            if (fileType.Is13Month || fileType.IsOutlook) {
                                                index = command.Parameters.IndexOf(":begbal"); // important to set offset
                                                begbalAmountList.Clear();
                                                begbalAmountNullList.Clear();
                                                command.Parameters[index].ArrayBindStatus = null;
                                                januaryAmountList.Clear();
                                                januaryAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                februaryAmountList.Clear();
                                                februaryAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                marchAmountList.Clear();
                                                marchAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                aprilAmountList.Clear();
                                                aprilAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                mayAmountList.Clear();
                                                mayAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                juneAmountList.Clear();
                                                juneAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                julyAmountList.Clear();
                                                julyAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                augustAmountList.Clear();
                                                augustAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                septemberAmountList.Clear();
                                                septemberAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                octoberAmountList.Clear();
                                                octoberAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                novemberAmountList.Clear();
                                                novemberAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                decemberAmountList.Clear();
                                                decemberAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                            } else {
                                                fiscalMonthList.Clear();
                                                amountList.Clear();
                                                amountNullList.Clear();
                                                command.Parameters[":fact_rpt_measure"].ArrayBindStatus = null;
                                            }
                                        }
                                    }
                                }

                                index = 0;
                                if (currentBindArrayIndex > 0) {
                                    command.Parameters[index].Value = lineNumbersList.ToArray();
                                    command.Parameters[++index].Value = reportingLineList.ToArray();
                                    command.Parameters[++index].Value = accountList.ToArray();
                                    command.Parameters[++index].Value = kpiList.ToArray();
                                    command.Parameters[++index].Value = viewsList.ToArray();
                                    command.Parameters[++index].Value = scenarioList.ToArray();
                                    command.Parameters[++index].Value = productList.ToArray();
                                    command.Parameters[++index].Value = subaccountList.ToArray();
                                    command.Parameters[++index].Value = serviceTypeList.ToArray();
                                    command.Parameters[++index].Value = functionList.ToArray();
                                    command.Parameters[++index].Value = costCenterList.ToArray();
                                    command.Parameters[++index].Value = entityList.ToArray();
                                    command.Parameters[++index].Value = companyList.ToArray();
                                    command.Parameters[++index].Value = equipmentList.ToArray();
                                    command.Parameters[++index].Value = techTypeList.ToArray();
                                    if (checkFact) {
                                        command.Parameters[++index].Value = fiscalYearList.ToArray();
                                        if (fileType.Is13Month || fileType.IsOutlook) {
                                            command.Parameters[++index].Value = begbalAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = begbalAmountNullList.ToArray();
                                            command.Parameters[++index].Value = januaryAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = januaryAmountNullList.ToArray();
                                            command.Parameters[++index].Value = februaryAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = februaryAmountNullList.ToArray();
                                            command.Parameters[++index].Value = marchAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = marchAmountNullList.ToArray();
                                            command.Parameters[++index].Value = aprilAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = aprilAmountNullList.ToArray();
                                            command.Parameters[++index].Value = mayAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = mayAmountNullList.ToArray();
                                            command.Parameters[++index].Value = juneAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = juneAmountNullList.ToArray();
                                            command.Parameters[++index].Value = julyAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = julyAmountNullList.ToArray();
                                            command.Parameters[++index].Value = augustAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = augustAmountNullList.ToArray();
                                            command.Parameters[++index].Value = septemberAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = septemberAmountNullList.ToArray();
                                            command.Parameters[++index].Value = octoberAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = octoberAmountNullList.ToArray();
                                            command.Parameters[++index].Value = novemberAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = novemberAmountNullList.ToArray();
                                            command.Parameters[++index].Value = decemberAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = decemberAmountNullList.ToArray();
                                        } else {
                                            command.Parameters[++index].Value = fiscalMonthList.ToArray();
                                            command.Parameters[++index].Value = amountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = amountNullList.ToArray();
                                        }
                                    }
                                    command.ArrayBindCount = currentBindArrayIndex;
                                    totalRecordsAdded += command.ExecuteNonQuery();
                                }
                                transaction.Commit();
                            }
                            excelReader.Close();
                            excelConnection.Close();
                            connection.Close();
                        }
                    }
                }
            } catch (OleDbException) {
                message = string.Format("There was an error opening the Excel file.  Make sure that a Worksheet named '{0}' exists.", fileType.FileTypeCode);
                return -1;
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                message = ex.Message + "<BR>" + ex.StackTrace;
                return -2;
            }
            System.Diagnostics.Debug.WriteLine(DateTime.Now);
            return totalRecordsAdded;
        }

        public static int LoadLocationExcelToStage(string filename, FileType fileType, DateTime now, string owner, bool checkFact, out string message) {
            const int maxRowsPerUpdate = 2000;
            int totalRecordsAdded = -2;     // total records returned: -1 user error, -2 program error
            int rowsImpacted = 0;
            int rowsSkipped = 0;
            int currentBindArrayIndex = 0;
            string sqlText = string.Empty;
            message = string.Empty;         // the return string 
            int excelRowsRead = 0;
            int index;
            int numberNullFields;
            double amountValue;
            short tempShort;
            string[] fieldNames = fileType.IsOutlook || fileType.Is13Month ? DbAccess.locationBudgetFieldNames : DbAccess.locationFieldNames;
            string fieldTypes = fileType.IsOutlook || fileType.Is13Month ? DbAccess.locationBudgetFieldTypes : DbAccess.locationFieldTypes;
            Dictionary<string, int> fieldReferences = new Dictionary<string, int>();

            List<int> lineNumbersList = new List<int>();
            List<string> reportingLineList = new List<string>();
            List<string> accountList = new List<string>();
            List<string> kpiList = new List<string>();
            List<string> viewsList = new List<string>();
            List<string> scenarioList = new List<string>();
            List<string> productList = new List<string>();
            List<string> subaccountList = new List<string>();
            List<string> serviceTypeList = new List<string>();
            List<string> functionList = new List<string>();
            List<string> costCenterList = new List<string>();
            List<string> locationList = new List<string>();
            List<string> equipmentList = new List<string>();
            List<string> techTypeList = new List<string>();
            List<string> storeStatusList = new List<string>();
            List<string> designTypeList = new List<string>();
            List<string> locationSubtypeList = new List<string>();
            List<string> locationTypeList = new List<string>();
            List<string> locationTierCodeList = new List<string>();
            List<string> fiscalYearList = new List<string>();
            List<string> fiscalMonthList = new List<string>();
            List<double> amountList = new List<double>();
            List<OracleParameterStatus> amountNullList = new List<OracleParameterStatus>();
            List<double> begbalAmountList = new List<double>();
            List<OracleParameterStatus> begbalAmountNullList = new List<OracleParameterStatus>();
            List<double> januaryAmountList = new List<double>();
            List<OracleParameterStatus> januaryAmountNullList = new List<OracleParameterStatus>();
            List<double> februaryAmountList = new List<double>();
            List<OracleParameterStatus> februaryAmountNullList = new List<OracleParameterStatus>();
            List<double> marchAmountList = new List<double>();
            List<OracleParameterStatus> marchAmountNullList = new List<OracleParameterStatus>();
            List<double> aprilAmountList = new List<double>();
            List<OracleParameterStatus> aprilAmountNullList = new List<OracleParameterStatus>();
            List<double> mayAmountList = new List<double>();
            List<OracleParameterStatus> mayAmountNullList = new List<OracleParameterStatus>();
            List<double> juneAmountList = new List<double>();
            List<OracleParameterStatus> juneAmountNullList = new List<OracleParameterStatus>();
            List<double> julyAmountList = new List<double>();
            List<OracleParameterStatus> julyAmountNullList = new List<OracleParameterStatus>();
            List<double> augustAmountList = new List<double>();
            List<OracleParameterStatus> augustAmountNullList = new List<OracleParameterStatus>();
            List<double> septemberAmountList = new List<double>();
            List<OracleParameterStatus> septemberAmountNullList = new List<OracleParameterStatus>();
            List<double> octoberAmountList = new List<double>();
            List<OracleParameterStatus> octoberAmountNullList = new List<OracleParameterStatus>();
            List<double> novemberAmountList = new List<double>();
            List<OracleParameterStatus> novemberAmountNullList = new List<OracleParameterStatus>();
            List<double> decemberAmountList = new List<double>();
            List<OracleParameterStatus> decemberAmountNullList = new List<OracleParameterStatus>();

            try {
                string missingUploadFields = string.Empty;

                sqlText = string.Format(" select * from [{0}$]", fileType.FileTypeCode);

                using (OleDbConnection excelConnection = new OleDbConnection(GetExcelConnectionString(filename)))
                using (OleDbCommand excelCommand = new OleDbCommand(sqlText, excelConnection)) {
                    excelConnection.Open();

                    using (OleDbDataReader excelReader = excelCommand.ExecuteReader()) {
                        //  Check each field that should be in the file and make sure it is there.
                        for (int i = 0; i < fieldNames.Length; i++) {
                            bool matchWasFound = false;
                            for (int j = 0; j < excelReader.VisibleFieldCount; j++) {
                                if (fieldNames[i].Equals(excelReader.GetName(j).ToUpper())) {
                                    matchWasFound = true;
                                    fieldReferences.Add(fieldNames[i], j);  // capture index for later use
                                    break;
                                }
                            }
                            if (!matchWasFound) {
                                missingUploadFields += "<li>" + fieldNames[i];
                            }
                        }
                        if (missingUploadFields.Length > 1) {
                            message = string.Format("The Load Process failed to find the following field(s) in the file: {0}<br>", missingUploadFields);
                            return -1;
                        }

                        using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                        using (OracleCommand command = connection.CreateCommand()) {
                            connection.Open();
                            using (OracleTransaction transaction = connection.BeginTransaction()) {
                                sqlText = string.Format("delete from {0} where source='{1}'"
                                    , fileType.Is13Month || fileType.IsOutlook ? fileType.StageYearTable : fileType.StageMonthTable
                                    , fileType.FileTypeCode);
                                command.CommandText = sqlText;
                                rowsImpacted = command.ExecuteNonQuery();

                                sqlText = string.Format(
@"insert into {0} (
    source, owner, date_created, line_nbr, reporting_line, account, kpi, views, scenario, product, subaccount, service_type
    , function, cost_center, location, equipment, tech_type, store_status, design_type, location_subtype, location_type, location_tier_code{1}
  ) values (
    '{2}', '{3}', to_date('{4}','YYYYMMDD HH24:MI:SS'), :line_nbr, :reporting_line, :account, :kpi, :views, :scenario, :product, :subaccount, :service_type
    , :function, :cost_center, :location, :equipment, :tech_type, :store_status, :design_type, :location_subtype, :location_type, :location_tier_code{5}
  )"
                                    , fileType.Is13Month || fileType.IsOutlook ? fileType.StageYearTable : fileType.StageMonthTable
                                    , checkFact
                                        ? (fileType.Is13Month || fileType.IsOutlook
                                            ? ", year, begbal, jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, dec"
                                            : ", year, time, amount")
                                        : string.Empty
                                    , fileType.FileTypeCode
                                    , owner
                                    , now.ToString("yyyyMMdd HH:mm:ss")
                                    , checkFact
                                        ? (fileType.Is13Month || fileType.IsOutlook
                                            ? ", :year, :begbal, :jan, :feb, :mar, :apr, :may, :jun, :jul, :aug, :sep, :oct, :nov, :dec"
                                            : ", :year, :time, :amount")
                                        : string.Empty);

                                command.Parameters.Clear();
                                command.CommandText = sqlText;

                                // add parameters
                                command.Parameters.Add(new OracleParameter(":line_nbr", OracleDbType.Int32));
                                command.Parameters.Add(new OracleParameter(":reporting_line", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":account", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":kpi", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":views", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":scenario", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":product", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":subaccount", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":service_type", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":function", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":cost_center", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":location", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":equipment", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":tech_type", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":store_status", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":design_type", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":location_subtype", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":location_type", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":location_tier_code", OracleDbType.Varchar2));
        
                                if (checkFact) {
                                    command.Parameters.Add(new OracleParameter(":year", OracleDbType.Varchar2));
                                    if (fileType.Is13Month || fileType.IsOutlook) {
                                        command.Parameters.Add(new OracleParameter(":begbal", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":jan", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":feb", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":mar", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":apr", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":may", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":jun", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":jul", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":aug", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":sep", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":oct", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":nov", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":dec", OracleDbType.Double));
                                    } else {
                                        command.Parameters.Add(new OracleParameter(":time", OracleDbType.Varchar2));
                                        command.Parameters.Add(new OracleParameter(":amount", OracleDbType.Double));
                                    }
                                }

                                command.BindByName = true;

                                totalRecordsAdded = 0;
                                while (excelReader.Read()) {
                                    excelRowsRead++;
                                    numberNullFields = 0;
                                    foreach (int i in fieldReferences.Values) {
                                        if (excelReader.IsDBNull(i)) numberNullFields++;
                                    }

                                    //TODO: Not sure about - 2
                                    // skip if all fields are null
                                    if (numberNullFields >= fieldNames.Length - 2) {
                                        rowsSkipped++;
                                        continue;
                                    }

                                    lineNumbersList.Add(excelRowsRead);
                                    reportingLineList.Add(excelReader.GetValue(fieldReferences["REPORTING_LINE"]).ToString().Trim());
                                    accountList.Add(excelReader.GetValue(fieldReferences["ACCOUNT"]).ToString().Trim());
                                    kpiList.Add(excelReader.GetValue(fieldReferences["KPI"]).ToString().Trim());
                                    viewsList.Add(excelReader.GetValue(fieldReferences["VIEWS"]).ToString().Trim());
                                    scenarioList.Add(excelReader.GetValue(fieldReferences["SCENARIO"]).ToString().Trim());
                                    productList.Add(excelReader.GetValue(fieldReferences["PRODUCT"]).ToString().Trim());
                                    subaccountList.Add(excelReader.GetValue(fieldReferences["SUBACCOUNT"]).ToString().Trim());
                                    serviceTypeList.Add(excelReader.GetValue(fieldReferences["SERVICE_TYPE"]).ToString().Trim());
                                    functionList.Add(excelReader.GetValue(fieldReferences["FUNCTION"]).ToString().Trim());
                                    costCenterList.Add(excelReader.GetValue(fieldReferences["COST_CENTER"]).ToString().Trim());
                                    locationList.Add(excelReader.GetValue(fieldReferences["LOCATION"]).ToString().Trim());
                                    equipmentList.Add(excelReader.GetValue(fieldReferences["EQUIPMENT"]).ToString().Trim());
                                    techTypeList.Add(excelReader.GetValue(fieldReferences["TECH_TYPE"]).ToString().Trim());
                                    storeStatusList.Add(excelReader.GetValue(fieldReferences["STORE_STATUS"]).ToString().Trim());
                                    designTypeList.Add(excelReader.GetValue(fieldReferences["DESIGN_TYPE"]).ToString().Trim());
                                    locationSubtypeList.Add(excelReader.GetValue(fieldReferences["LOCATION_SUBTYPE"]).ToString().Trim());
                                    locationTypeList.Add(excelReader.GetValue(fieldReferences["LOCATION_TYPE"]).ToString().Trim());
                                    locationTierCodeList.Add(excelReader.GetValue(fieldReferences["LOCATION_TIER_CODE"]).ToString().Trim());

                                    if (checkFact) {
                                        // validate year is a number
                                        if (!Int16.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["YEAR"])), out tempShort)) {
                                            message = string.Format("The column 'YEAR' in row {0} contains an invalid value.", excelRowsRead);
                                            return -1;
                                        } else {
                                            fiscalYearList.Add(Convert.ToString(tempShort));
                                        }

                                        if (fileType.Is13Month || fileType.IsOutlook) {
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["BEGBAL"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                begbalAmountList.Add(amountValue);
                                                begbalAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                begbalAmountList.Add(0); // placeholder in array
                                                begbalAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["JAN"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                januaryAmountList.Add(amountValue);
                                                januaryAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                januaryAmountList.Add(0); // placeholder in array
                                                januaryAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["FEB"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                februaryAmountList.Add(amountValue);
                                                februaryAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                februaryAmountList.Add(0); // placeholder in array
                                                februaryAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["MAR"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                marchAmountList.Add(amountValue);
                                                marchAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                marchAmountList.Add(0); // placeholder in array
                                                marchAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["APR"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                aprilAmountList.Add(amountValue);
                                                aprilAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                aprilAmountList.Add(0); // placeholder in array
                                                aprilAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["MAY"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                mayAmountList.Add(amountValue);
                                                mayAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                mayAmountList.Add(0); // placeholder in array
                                                mayAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["JUN"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                juneAmountList.Add(amountValue);
                                                juneAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                juneAmountList.Add(0); // placeholder in array
                                                juneAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["JUL"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                julyAmountList.Add(amountValue);
                                                julyAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                julyAmountList.Add(0); // placeholder in array
                                                julyAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["AUG"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                augustAmountList.Add(amountValue);
                                                augustAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                augustAmountList.Add(0); // placeholder in array
                                                augustAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["SEP"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                septemberAmountList.Add(amountValue);
                                                septemberAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                septemberAmountList.Add(0); // placeholder in array
                                                septemberAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["OCT"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                octoberAmountList.Add(amountValue);
                                                octoberAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                octoberAmountList.Add(0); // placeholder in array
                                                octoberAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["NOV"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                novemberAmountList.Add(amountValue);
                                                novemberAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                novemberAmountList.Add(0); // placeholder in array
                                                novemberAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["DEC"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                decemberAmountList.Add(amountValue);
                                                decemberAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                decemberAmountList.Add(0); // placeholder in array
                                                decemberAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                        } else {
                                            // validate that the time period is a number
                                            if (!Int16.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["TIME"])), out tempShort)) {
                                                message = string.Format("The column 'TIME' in row {0} contains an invalid value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                fiscalMonthList.Add(Convert.ToString(tempShort));
                                            }

                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["AMOUNT"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                amountList.Add(amountValue);
                                                amountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                amountList.Add(0); // placeholder in array
                                                amountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                        }
                                    }

                                    currentBindArrayIndex++;
                                    index = 0;
                                    if (currentBindArrayIndex == maxRowsPerUpdate) {
                                        command.Parameters[index].Value = lineNumbersList.ToArray();
                                        command.Parameters[++index].Value = reportingLineList.ToArray();
                                        command.Parameters[++index].Value = accountList.ToArray();
                                        command.Parameters[++index].Value = kpiList.ToArray();
                                        command.Parameters[++index].Value = viewsList.ToArray();
                                        command.Parameters[++index].Value = scenarioList.ToArray();
                                        command.Parameters[++index].Value = productList.ToArray();
                                        command.Parameters[++index].Value = subaccountList.ToArray();
                                        command.Parameters[++index].Value = serviceTypeList.ToArray();
                                        command.Parameters[++index].Value = functionList.ToArray();
                                        command.Parameters[++index].Value = costCenterList.ToArray();
                                        command.Parameters[++index].Value = locationList.ToArray();
                                        command.Parameters[++index].Value = equipmentList.ToArray();
                                        command.Parameters[++index].Value = techTypeList.ToArray();
                                        command.Parameters[++index].Value = storeStatusList.ToArray();
                                        command.Parameters[++index].Value = designTypeList.ToArray();
                                        command.Parameters[++index].Value = locationSubtypeList.ToArray();
                                        command.Parameters[++index].Value = locationTypeList.ToArray();
                                        command.Parameters[++index].Value = locationTierCodeList.ToArray();
                                        if (checkFact) {
                                            command.Parameters[++index].Value = fiscalYearList.ToArray();
                                            if (fileType.Is13Month || fileType.IsOutlook) {
                                                command.Parameters[++index].Value = begbalAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = begbalAmountNullList.ToArray();
                                                command.Parameters[++index].Value = januaryAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = januaryAmountNullList.ToArray();
                                                command.Parameters[++index].Value = februaryAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = februaryAmountNullList.ToArray();
                                                command.Parameters[++index].Value = marchAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = marchAmountNullList.ToArray();
                                                command.Parameters[++index].Value = aprilAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = aprilAmountNullList.ToArray();
                                                command.Parameters[++index].Value = mayAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = mayAmountNullList.ToArray();
                                                command.Parameters[++index].Value = juneAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = juneAmountNullList.ToArray();
                                                command.Parameters[++index].Value = julyAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = julyAmountNullList.ToArray();
                                                command.Parameters[++index].Value = augustAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = augustAmountNullList.ToArray();
                                                command.Parameters[++index].Value = septemberAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = septemberAmountNullList.ToArray();
                                                command.Parameters[++index].Value = octoberAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = octoberAmountNullList.ToArray();
                                                command.Parameters[++index].Value = novemberAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = novemberAmountNullList.ToArray();
                                                command.Parameters[++index].Value = decemberAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = decemberAmountNullList.ToArray();
                                            } else {
                                                command.Parameters[++index].Value = fiscalMonthList.ToArray();
                                                command.Parameters[++index].Value = amountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = amountNullList.ToArray();
                                            }
                                        }
                                        command.ArrayBindCount = currentBindArrayIndex;
                                        totalRecordsAdded += command.ExecuteNonQuery();
                                        currentBindArrayIndex = 0;
                                        lineNumbersList.Clear();
                                        reportingLineList.Clear();
                                        accountList.Clear();
                                        kpiList.Clear();
                                        viewsList.Clear();
                                        scenarioList.Clear();
                                        productList.Clear();
                                        subaccountList.Clear();
                                        serviceTypeList.Clear();
                                        functionList.Clear();
                                        costCenterList.Clear();
                                        locationList.Clear();
                                        equipmentList.Clear();
                                        techTypeList.Clear();
                                        storeStatusList.Clear();
                                        designTypeList.Clear();
                                        locationSubtypeList.Clear();
                                        locationTypeList.Clear();
                                        locationTierCodeList.Clear();

                                        if (checkFact) {
                                            fiscalYearList.Clear();
                                            if (fileType.Is13Month || fileType.IsOutlook) {
                                                index = command.Parameters.IndexOf(":begbal"); // setting offset
                                                begbalAmountList.Clear();
                                                begbalAmountNullList.Clear();
                                                command.Parameters[index].ArrayBindStatus = null;
                                                januaryAmountList.Clear();
                                                januaryAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                februaryAmountList.Clear();
                                                februaryAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                marchAmountList.Clear();
                                                marchAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                aprilAmountList.Clear();
                                                aprilAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                mayAmountList.Clear();
                                                mayAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                juneAmountList.Clear();
                                                juneAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                julyAmountList.Clear();
                                                julyAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                augustAmountList.Clear();
                                                augustAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                septemberAmountList.Clear();
                                                septemberAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                octoberAmountList.Clear();
                                                octoberAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                novemberAmountList.Clear();
                                                novemberAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                decemberAmountList.Clear();
                                                decemberAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                            } else {
                                                fiscalMonthList.Clear();
                                                amountList.Clear();
                                                amountNullList.Clear();
                                                command.Parameters[":amount"].ArrayBindStatus = null;
                                            }
                                        }
                                    }
                                }
                                index = 0;
                                if (currentBindArrayIndex > 0) {
                                    command.Parameters[index].Value = lineNumbersList.ToArray();
                                    command.Parameters[++index].Value = reportingLineList.ToArray();
                                    command.Parameters[++index].Value = accountList.ToArray();
                                    command.Parameters[++index].Value = kpiList.ToArray();
                                    command.Parameters[++index].Value = viewsList.ToArray();
                                    command.Parameters[++index].Value = scenarioList.ToArray();
                                    command.Parameters[++index].Value = productList.ToArray();
                                    command.Parameters[++index].Value = subaccountList.ToArray();
                                    command.Parameters[++index].Value = serviceTypeList.ToArray();
                                    command.Parameters[++index].Value = functionList.ToArray();
                                    command.Parameters[++index].Value = costCenterList.ToArray();
                                    command.Parameters[++index].Value = locationList.ToArray();
                                    command.Parameters[++index].Value = equipmentList.ToArray();
                                    command.Parameters[++index].Value = techTypeList.ToArray();
                                    command.Parameters[++index].Value = storeStatusList.ToArray();
                                    command.Parameters[++index].Value = designTypeList.ToArray();
                                    command.Parameters[++index].Value = locationSubtypeList.ToArray();
                                    command.Parameters[++index].Value = locationTypeList.ToArray();
                                    command.Parameters[++index].Value = locationTierCodeList.ToArray();
                                    if (checkFact) {
                                        command.Parameters[++index].Value = fiscalYearList.ToArray();
                                        if (fileType.Is13Month || fileType.IsOutlook) {
                                            command.Parameters[++index].Value = begbalAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = begbalAmountNullList.ToArray();
                                            command.Parameters[++index].Value = januaryAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = januaryAmountNullList.ToArray();
                                            command.Parameters[++index].Value = februaryAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = februaryAmountNullList.ToArray();
                                            command.Parameters[++index].Value = marchAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = marchAmountNullList.ToArray();
                                            command.Parameters[++index].Value = aprilAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = aprilAmountNullList.ToArray();
                                            command.Parameters[++index].Value = mayAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = mayAmountNullList.ToArray();
                                            command.Parameters[++index].Value = juneAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = juneAmountNullList.ToArray();
                                            command.Parameters[++index].Value = julyAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = julyAmountNullList.ToArray();
                                            command.Parameters[++index].Value = augustAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = augustAmountNullList.ToArray();
                                            command.Parameters[++index].Value = septemberAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = septemberAmountNullList.ToArray();
                                            command.Parameters[++index].Value = octoberAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = octoberAmountNullList.ToArray();
                                            command.Parameters[++index].Value = novemberAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = novemberAmountNullList.ToArray();
                                            command.Parameters[++index].Value = decemberAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = decemberAmountNullList.ToArray();
                                        } else {
                                            command.Parameters[++index].Value = fiscalMonthList.ToArray();
                                            command.Parameters[++index].Value = amountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = amountNullList.ToArray();
                                        }
                                    }
                                    command.ArrayBindCount = currentBindArrayIndex;
                                    totalRecordsAdded += command.ExecuteNonQuery();
                                }
                                transaction.Commit();
                            }
                            excelReader.Close();
                            excelConnection.Close();
                            connection.Close();
                        }
                    }
                }
            } catch (OleDbException) {
                message = string.Format("There was an error opening the Excel file.  Make sure that a Worksheet named '{0}' exists.", fileType.FileTypeCode);
                return -1;
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                message = ex.Message + "<BR>" + ex.StackTrace;
                return -2;
            }
            System.Diagnostics.Debug.WriteLine(DateTime.Now);
            return totalRecordsAdded;
        }
                
        public static int LoadEquipmentExcelToStage(string filename, FileType fileType, DateTime now, string owner, bool checkFact, out string message) {
            const int maxRowsPerUpdate = 2000;
            int totalRecordsAdded = -2;     // total records returned: -1 user error, -2 program error
            int rowsImpacted = 0;
            int rowsSkipped = 0;
            int currentBindArrayIndex = 0;
            string sqlText = string.Empty;
            message = string.Empty;         // the return string 
            int excelRowsRead = 0;
            int numberNullFields;
            double amountValue;
            DateTime dateValue;
            string tempValue;
            Dictionary<string,int> fieldReferences = new Dictionary<string,int>();
            
            List<int> lineNumbersList = new List<int>(); 
            List<DateTime> factDateList = new List<DateTime>(); 
            List<string> reportingLineList = new List<string>();
            List<string> entityList = new List<string>();
            List<string> costCenterList = new List<string>();
            List<string> kpiList = new List<string>();
            List<string> viewsList = new List<string>();
            List<string> scenarioList = new List<string>();
            List<string> functionList = new List<string>();
            List<string> serviceTypeList = new List<string>();
            List<string> equipmentList = new List<string>();
            List<string> techTypeList = new List<string>();
            List<string> methodologyTypeList = new List<string>();
            List<string> saleTypeList = new List<string>();
            List<string> discountTypeList = new List<string>();
            List<string> contractTermList = new List<string>();
            List<double> amountList = new List<double>();
            List<OracleParameterStatus> amountNullList = new List<OracleParameterStatus>();

            try {
                string missingUploadFields = string.Empty;
                                
                sqlText = string.Format(" select * from [{0}$]", fileType.FileTypeCode);

                using (OleDbConnection excelConnection = new OleDbConnection(GetExcelConnectionString(filename)))
                using (OleDbCommand excelCommand = new OleDbCommand(sqlText, excelConnection)) {
                    excelConnection.Open();

                    using (OleDbDataReader excelReader = excelCommand.ExecuteReader()) {
                        //  Check each field that should be in the file and make sure it is there.
                        for (int i = 0; i < equipmentFieldNames.Length; i++) {
                            bool matchWasFound = false;
                            for (int j = 0; j < excelReader.VisibleFieldCount; j++) {
                                if (equipmentFieldNames[i].Equals(excelReader.GetName(j).ToUpper())) {
                                    matchWasFound = true;
                                    fieldReferences.Add(equipmentFieldNames[i], j);  // capture index for later use
                                    break;
                                }
                            }
                            if (!matchWasFound) {
                                missingUploadFields += "<li>" + equipmentFieldNames[i];
                            }
                        }
                        if (missingUploadFields.Length > 1) {
                            message = string.Format("The Load Process failed to find the following field(s) in the file: {0}<br>", missingUploadFields);
                            return -1;
                        }

                        using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                        using (OracleCommand command = connection.CreateCommand()) {
                            connection.Open();
                            using (OracleTransaction transaction = connection.BeginTransaction()) {
                                sqlText = string.Format("delete from {0} where source='{1}'", fileType.StageMonthTable, fileType.FileTypeCode);
                                command.CommandText = sqlText;
                                rowsImpacted = command.ExecuteNonQuery();

                                sqlText = string.Format(
@"insert into {0} (
    source, owner, date_created, line_nbr, reporting_line, entity, cost_center
    , kpi, views, scenario, function, service_type, equipment, tech_type, methodology_type
    , sale_type, discount_type, contract_term{1}
  ) values (
    '{2}', '{3}', to_date('{4}','YYYYMMDD HH24:MI:SS'), :line_nbr, :reporting_line, :entity, :cost_center
    , :kpi, :views, :scenario, :function, :service_type, :equipment, :tech_type, :methodology_type
    , :sale_type, :discount_type, :contract_term{5}
  )"
                                    , fileType.StageMonthTable
                                    , checkFact ? ", fact_date, amount" : string.Empty
                                    , fileType.FileTypeCode
                                    , owner
                                    , now.ToString("yyyyMMdd HH:mm:ss")
                                    , checkFact ? ", :fact_date, :amount" : string.Empty);

                                command.Parameters.Clear();
                                command.CommandText = sqlText;

                                // add parameters
                                command.Parameters.Add(new OracleParameter(":line_nbr", OracleDbType.Int32));
                                command.Parameters.Add(new OracleParameter(":reporting_line", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":entity", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":cost_center", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":kpi", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":views", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":scenario", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":function", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":service_type", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":equipment", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":tech_type", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":methodology_type", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":sale_type", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":discount_type", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":contract_term", OracleDbType.Varchar2));

                                if (checkFact) {
                                    command.Parameters.Add(new OracleParameter(":fact_date", OracleDbType.Date));
                                    command.Parameters.Add(new OracleParameter(":amount", OracleDbType.Double));
                                }

                                command.BindByName = true;

                                totalRecordsAdded = 0;
                                while (excelReader.Read()) {
                                    excelRowsRead++;
                                    numberNullFields = 0;
                                    foreach (int i in fieldReferences.Values) {
                                        if (excelReader.IsDBNull(i)) numberNullFields++;
                                    }
                                    // skip if all fields are null
                                    if (numberNullFields >= equipmentFieldNames.Length - 2) {
                                        rowsSkipped++;
                                        continue;
                                    }

                                    lineNumbersList.Add(excelRowsRead);
                                    reportingLineList.Add(excelReader.GetValue(fieldReferences["REPORTING_LINE"]).ToString().Trim());
                                    entityList.Add(excelReader.GetValue(fieldReferences["ENTITY"]).ToString().Trim());
                                    costCenterList.Add(excelReader.GetValue(fieldReferences["COST_CENTER"]).ToString().Trim());
                                    kpiList.Add(excelReader.GetValue(fieldReferences["KPI"]).ToString().Trim());
                                    viewsList.Add(excelReader.GetValue(fieldReferences["VIEWS"]).ToString().Trim());
                                    scenarioList.Add(excelReader.GetValue(fieldReferences["SCENARIO"]).ToString().Trim());
                                    functionList.Add(excelReader.GetValue(fieldReferences["FUNCTION"]).ToString().Trim());
                                    serviceTypeList.Add(excelReader.GetValue(fieldReferences["SERVICE_TYPE"]).ToString().Trim());
                                    equipmentList.Add(excelReader.GetValue(fieldReferences["EQUIPMENT"]).ToString().Trim());
                                    techTypeList.Add(excelReader.GetValue(fieldReferences["TECH_TYPE"]).ToString().Trim());
                                    methodologyTypeList.Add(excelReader.GetValue(fieldReferences["METHODOLOGY_TYPE"]).ToString().Trim());
                                    saleTypeList.Add(excelReader.GetValue(fieldReferences["SALE_TYPE"]).ToString().Trim());
                                    discountTypeList.Add(excelReader.GetValue(fieldReferences["DISCOUNT_TYPE"]).ToString().Trim());
                                    contractTermList.Add(excelReader.GetValue(fieldReferences["CONTRACT_TERM"]).ToString().Trim());

                                    if (checkFact) {
                                        tempValue = Convert.ToString(excelReader.GetValue(fieldReferences["FACT_DATE"]));
                                        if (DateTime.TryParse(tempValue, out dateValue)) {
                                            factDateList.Add(dateValue);
                                        } else {
                                            message = string.Format("Fact date in row {0} contains an invalid date.", excelRowsRead);
                                            return -1;
                                        }

                                        tempValue = Convert.ToString(excelReader.GetValue(fieldReferences["AMOUNT"]));
                                        tempValue.Replace(",", string.Empty);
                                        tempValue.Replace("$", string.Empty);
                                        if (double.TryParse(tempValue, out amountValue)) {
                                            amountList.Add(amountValue); 
                                            amountNullList.Add(OracleParameterStatus.Success);
                                        } else if (fileType.IsAdjustment) {
                                            message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                            return -1;
                                        } else {
                                            amountList.Add(0); // placeholder in array
                                            amountNullList.Add(OracleParameterStatus.NullInsert);
                                        }
                                        
                                    }
                                    currentBindArrayIndex++;

                                    if (currentBindArrayIndex == maxRowsPerUpdate) {
                                        command.Parameters[0].Value = lineNumbersList.ToArray();
                                        command.Parameters[1].Value = reportingLineList.ToArray();
                                        command.Parameters[2].Value = entityList.ToArray();
                                        command.Parameters[3].Value = costCenterList.ToArray();
                                        command.Parameters[4].Value = kpiList.ToArray();
                                        command.Parameters[5].Value = viewsList.ToArray();
                                        command.Parameters[6].Value = scenarioList.ToArray();
                                        command.Parameters[7].Value = functionList.ToArray();
                                        command.Parameters[8].Value = serviceTypeList.ToArray();
                                        command.Parameters[9].Value = equipmentList.ToArray();
                                        command.Parameters[10].Value = techTypeList.ToArray();
                                        command.Parameters[11].Value = methodologyTypeList.ToArray();
                                        command.Parameters[12].Value = saleTypeList.ToArray();
                                        command.Parameters[13].Value = discountTypeList.ToArray();
                                        command.Parameters[14].Value = contractTermList.ToArray();
                                        if (checkFact) {
                                            command.Parameters[15].Value = factDateList.ToArray();
                                            command.Parameters[16].Value = amountList.ToArray();
                                            command.Parameters[16].ArrayBindStatus = amountNullList.ToArray();
                                        }
                                        command.ArrayBindCount = currentBindArrayIndex;
                                        totalRecordsAdded += command.ExecuteNonQuery();
                                        currentBindArrayIndex = 0;
                                        lineNumbersList.Clear();
                                        reportingLineList.Clear();
                                        entityList.Clear();
                                        costCenterList.Clear();
                                        kpiList.Clear();
                                        viewsList.Clear();
                                        scenarioList.Clear();
                                        functionList.Clear();
                                        serviceTypeList.Clear();
                                        equipmentList.Clear();
                                        techTypeList.Clear();
                                        methodologyTypeList.Clear();
                                        saleTypeList.Clear();
                                        discountTypeList.Clear();
                                        contractTermList.Clear();
                                        if (checkFact) {
                                            factDateList.Clear();
                                            amountList.Clear();
                                            amountNullList.Clear();
                                            command.Parameters[16].ArrayBindStatus = null;
                                        }
                                    }
                                }

                                if (currentBindArrayIndex > 0) {
                                    command.Parameters[0].Value = lineNumbersList.ToArray();
                                    command.Parameters[1].Value = reportingLineList.ToArray();
                                    command.Parameters[2].Value = entityList.ToArray();
                                    command.Parameters[3].Value = costCenterList.ToArray();
                                    command.Parameters[4].Value = kpiList.ToArray();
                                    command.Parameters[5].Value = viewsList.ToArray();
                                    command.Parameters[6].Value = scenarioList.ToArray();
                                    command.Parameters[7].Value = functionList.ToArray();
                                    command.Parameters[8].Value = serviceTypeList.ToArray();
                                    command.Parameters[9].Value = equipmentList.ToArray();
                                    command.Parameters[10].Value = techTypeList.ToArray();
                                    command.Parameters[11].Value = methodologyTypeList.ToArray();
                                    command.Parameters[12].Value = saleTypeList.ToArray();
                                    command.Parameters[13].Value = discountTypeList.ToArray();
                                    command.Parameters[14].Value = contractTermList.ToArray();
                                    if (checkFact) {
                                        command.Parameters[15].Value = factDateList.ToArray();
                                        command.Parameters[16].Value = amountList.ToArray();
                                        command.Parameters[16].ArrayBindStatus = amountNullList.ToArray();
                                    }
                                    command.ArrayBindCount = currentBindArrayIndex;
                                    totalRecordsAdded += command.ExecuteNonQuery();
                                }
                                transaction.Commit();
                            }
                            excelReader.Close();
                            excelConnection.Close();
                            connection.Close();
                        }
                    }
                }
            } catch (OleDbException) {
                message = string.Format("There was an error opening the Excel file.  Make sure that a Worksheet named '{0}' exists.", fileType.FileTypeCode);
                return -1;
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                message = ex.Message + "<BR>" + ex.StackTrace;
                return -2;
            }
            System.Diagnostics.Debug.WriteLine(DateTime.Now);
            return totalRecordsAdded;
        }

        public static int LoadDataWarehouseExcelToStage(string filename, FileType fileType, DateTime now, string owner, bool checkFact, out string message) {
            const int maxRowsPerUpdate = 2000;
            int totalRecordsAdded = -2;     // total records returned: -1 user error, -2 program error
            int rowsImpacted = 0;
            int rowsSkipped = 0;
            int currentBindArrayIndex = 0;
            string sqlText = string.Empty;
            message = string.Empty;         // the return string 
            int excelRowsRead = 0;
            int numberNullFields;
            int index;
            double amountValue;
            short tempShort;
            string[] fieldNames = fileType.IsOutlook || fileType.Is13Month ? DbAccess.dataWarehouseBudgetFieldNames : DbAccess.dataWarehouseFieldNames;
            string fieldTypes = fileType.IsOutlook || fileType.Is13Month ? DbAccess.dataWarehouseBudgetFieldTypes : DbAccess.dataWarehouseFieldTypes;
            Dictionary<string, int> fieldReferences = new Dictionary<string, int>();

            List<int> lineNumbersList = new List<int>();
            List<string> reportingLineList = new List<string>();
            List<string> customerAccountList = new List<string>();
            List<string> kpiList = new List<string>();
            List<string> viewsList = new List<string>();
            List<string> scenarioList = new List<string>();
            List<string> productList = new List<string>();
            List<string> subaccountList = new List<string>();
            List<string> serviceTypeList = new List<string>();
            List<string> functionList = new List<string>();
            List<string> entityList = new List<string>();
            List<string> equipmentList = new List<string>();
            List<string> techTypeList = new List<string>();
            List<string> previousTypeList = new List<string>();
            List<string> connectionTypeList = new List<string>();
            List<string> segmentList = new List<string>();
            List<string> versionList = new List<string>();
            List<string> verticalList = new List<string>();
            List<string> owningGeographyList = new List<string>();
            List<string> owningManagerList = new List<string>();
            List<string> branchList = new List<string>();
            List<string> contractTermList = new List<string>();
            List<string> programEligibleList = new List<string>();
            List<string> fiscalYearList = new List<string>();
            List<string> fiscalMonthList = new List<string>();
            List<double> amountList = new List<double>();
            List<OracleParameterStatus> amountNullList = new List<OracleParameterStatus>();
            List<double> begbalAmountList = new List<double>();
            List<OracleParameterStatus> begbalAmountNullList = new List<OracleParameterStatus>();
            List<double> januaryAmountList = new List<double>();
            List<OracleParameterStatus> januaryAmountNullList = new List<OracleParameterStatus>();
            List<double> februaryAmountList = new List<double>();
            List<OracleParameterStatus> februaryAmountNullList = new List<OracleParameterStatus>();
            List<double> marchAmountList = new List<double>();
            List<OracleParameterStatus> marchAmountNullList = new List<OracleParameterStatus>();
            List<double> aprilAmountList = new List<double>();
            List<OracleParameterStatus> aprilAmountNullList = new List<OracleParameterStatus>();
            List<double> mayAmountList = new List<double>();
            List<OracleParameterStatus> mayAmountNullList = new List<OracleParameterStatus>();
            List<double> juneAmountList = new List<double>();
            List<OracleParameterStatus> juneAmountNullList = new List<OracleParameterStatus>();
            List<double> julyAmountList = new List<double>();
            List<OracleParameterStatus> julyAmountNullList = new List<OracleParameterStatus>();
            List<double> augustAmountList = new List<double>();
            List<OracleParameterStatus> augustAmountNullList = new List<OracleParameterStatus>();
            List<double> septemberAmountList = new List<double>();
            List<OracleParameterStatus> septemberAmountNullList = new List<OracleParameterStatus>();
            List<double> octoberAmountList = new List<double>();
            List<OracleParameterStatus> octoberAmountNullList = new List<OracleParameterStatus>();
            List<double> novemberAmountList = new List<double>();
            List<OracleParameterStatus> novemberAmountNullList = new List<OracleParameterStatus>();
            List<double> decemberAmountList = new List<double>();
            List<OracleParameterStatus> decemberAmountNullList = new List<OracleParameterStatus>();

            try {
                string missingUploadFields = string.Empty;

                sqlText = string.Format(" select * from [{0}$]", fileType.FileTypeCode);

                using (OleDbConnection excelConnection = new OleDbConnection(GetExcelConnectionString(filename)))
                using (OleDbCommand excelCommand = new OleDbCommand(sqlText, excelConnection)) {
                    excelConnection.Open();

                    using (OleDbDataReader excelReader = excelCommand.ExecuteReader()) {
                        //  Check each field that should be in the file and make sure it is there.
                        for (int i = 0; i < fieldNames.Length; i++) {
                            bool matchWasFound = false;
                            for (int j = 0; j < excelReader.VisibleFieldCount; j++) {
                                if (fieldNames[i].Equals(excelReader.GetName(j).ToUpper())) {
                                    matchWasFound = true;
                                    fieldReferences.Add(fieldNames[i], j);  // capture index for later use
                                    break;
                                }
                            }
                            if (!matchWasFound) {
                                missingUploadFields += "<li>" + fieldNames[i];
                            }
                        }
                        if (missingUploadFields.Length > 1) {
                            message = string.Format("The Load Process failed to find the following field(s) in the file: {0}<br>", missingUploadFields);
                            return -1;
                        }

                        using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                        using (OracleCommand command = connection.CreateCommand()) {
                            connection.Open();
                            using (OracleTransaction transaction = connection.BeginTransaction()) {
                                sqlText = string.Format("delete from {0} where source='{1}'"
                                    , fileType.Is13Month || fileType.IsOutlook ? fileType.StageYearTable : fileType.StageMonthTable
                                    , fileType.FileTypeCode);
                                command.CommandText = sqlText;
                                rowsImpacted = command.ExecuteNonQuery();

                                sqlText = string.Format(
@"insert into {0} (
    source, owner, date_created, line_nbr, reporting_line, customer_account, kpi, views, scenario, product, subaccount
    , service_type, function, entity, equipment, tech_type, previous_type, connection_type, segment, version
    , vertical, owning_geography, owning_manager, branch, contract_term, program_eligibility{1}
  ) values (
    '{2}', '{3}', to_date('{4}','YYYYMMDD HH24:MI:SS'), :line_nbr, :reporting_line, :customer_account, :kpi, :views, :scenario, :product, :subaccount
    , :service_type, :function, :entity, :equipment, :tech_type, :previous_type, :connection_type, :segment, :version
    , :vertical, :owning_geography, :owning_manager, :branch, :contract_term, :program_eligibility{5}
  )"
                                    , fileType.Is13Month || fileType.IsOutlook ? fileType.StageYearTable : fileType.StageMonthTable
                                    , checkFact
                                        ? (fileType.Is13Month || fileType.IsOutlook
                                            ? ", year, begbal, jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, dec"
                                            : ", year, time, amount")
                                        : string.Empty
                                    , fileType.FileTypeCode
                                    , owner
                                    , now.ToString("yyyyMMdd HH:mm:ss")
                                    , checkFact
                                        ? (fileType.Is13Month || fileType.IsOutlook
                                            ? ", :year, :begbal, :jan, :feb, :mar, :apr, :may, :jun, :jul, :aug, :sep, :oct, :nov, :dec"
                                            : ", :year, :time, :amount")
                                        : string.Empty);

                                command.Parameters.Clear();
                                command.CommandText = sqlText;

                                // add parameters
                                command.Parameters.Add(new OracleParameter(":line_nbr", OracleDbType.Int32));
                                command.Parameters.Add(new OracleParameter(":reporting_line", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":customer_account", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":kpi", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":views", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":scenario", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":product", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":subaccount", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":service_type", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":function", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":entity", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":equipment", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":tech_type", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":previous_type", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":connection_type", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":segment", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":version", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":vertical", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":owning_geography", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":owning_manager", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":branch", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":contract_term", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":program_eligibility", OracleDbType.Varchar2));
                                
                                if (checkFact) {
                                    command.Parameters.Add(new OracleParameter(":year", OracleDbType.Varchar2));
                                    if (fileType.Is13Month || fileType.IsOutlook) {
                                        command.Parameters.Add(new OracleParameter(":begbal", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":jan", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":feb", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":mar", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":apr", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":may", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":jun", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":jul", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":aug", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":sep", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":oct", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":nov", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":dec", OracleDbType.Double));
                                    } else {
                                        command.Parameters.Add(new OracleParameter(":time", OracleDbType.Varchar2));
                                        command.Parameters.Add(new OracleParameter(":amount", OracleDbType.Double));
                                    }
                                }

                                command.BindByName = true;

                                totalRecordsAdded = 0;
                                while (excelReader.Read()) {
                                    excelRowsRead++;
                                    numberNullFields = 0;
                                    foreach (int i in fieldReferences.Values) {
                                        if (excelReader.IsDBNull(i)) numberNullFields++;
                                    }

                                    //TODO: Not sure about - 2
                                    // skip if all fields are null
                                    if (numberNullFields >= fieldNames.Length - 2) {
                                        rowsSkipped++;
                                        continue;
                                    }

                                    lineNumbersList.Add(excelRowsRead);
                                    reportingLineList.Add(excelReader.GetValue(fieldReferences["REPORTING_LINE"]).ToString().Trim());
                                    customerAccountList.Add(excelReader.GetValue(fieldReferences["CUSTOMER_ACCOUNT"]).ToString().Trim());
                                    kpiList.Add(excelReader.GetValue(fieldReferences["KPI"]).ToString().Trim());
                                    viewsList.Add(excelReader.GetValue(fieldReferences["VIEWS"]).ToString().Trim());
                                    scenarioList.Add(excelReader.GetValue(fieldReferences["SCENARIO"]).ToString().Trim());
                                    productList.Add(excelReader.GetValue(fieldReferences["PRODUCT"]).ToString().Trim());
                                    subaccountList.Add(excelReader.GetValue(fieldReferences["SUBACCOUNT"]).ToString().Trim());
                                    serviceTypeList.Add(excelReader.GetValue(fieldReferences["SERVICE_TYPE"]).ToString().Trim());
                                    functionList.Add(excelReader.GetValue(fieldReferences["FUNCTION"]).ToString().Trim());
                                    entityList.Add(excelReader.GetValue(fieldReferences["ENTITY"]).ToString().Trim());
                                    equipmentList.Add(excelReader.GetValue(fieldReferences["EQUIPMENT"]).ToString().Trim());
                                    techTypeList.Add(excelReader.GetValue(fieldReferences["TECH_TYPE"]).ToString().Trim());
                                    previousTypeList.Add(excelReader.GetValue(fieldReferences["PREVIOUS_TYPE"]).ToString().Trim());
                                    connectionTypeList.Add(excelReader.GetValue(fieldReferences["CONNECTION_TYPE"]).ToString().Trim());
                                    segmentList.Add(excelReader.GetValue(fieldReferences["SEGMENT"]).ToString().Trim());
                                    versionList.Add(excelReader.GetValue(fieldReferences["VERSION"]).ToString().Trim());
                                    verticalList.Add(excelReader.GetValue(fieldReferences["VERTICAL"]).ToString().Trim());
                                    owningGeographyList.Add(excelReader.GetValue(fieldReferences["OWNING_GEOGRAPHY"]).ToString().Trim());
                                    owningManagerList.Add(excelReader.GetValue(fieldReferences["OWNING_MANAGER"]).ToString().Trim());
                                    branchList.Add(excelReader.GetValue(fieldReferences["BRANCH"]).ToString().Trim());
                                    contractTermList.Add(excelReader.GetValue(fieldReferences["CONTRACT_TERM"]).ToString().Trim());
                                    programEligibleList.Add(excelReader.GetValue(fieldReferences["PROGRAM_ELIGIBILITY"]).ToString().Trim());

                                    if (checkFact) {
                                        // validate year is a number
                                        if (!Int16.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["YEAR"])), out tempShort)) {
                                            message = string.Format("The column 'YEAR' in row {0} contains an invalid value.", excelRowsRead);
                                            return -1;
                                        } else {
                                            fiscalYearList.Add(Convert.ToString(tempShort));
                                        }

                                        if (fileType.Is13Month || fileType.IsOutlook) {
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["BEGBAL"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                begbalAmountList.Add(amountValue);
                                                begbalAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                begbalAmountList.Add(0); // placeholder in array
                                                begbalAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["JAN"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                januaryAmountList.Add(amountValue);
                                                januaryAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                januaryAmountList.Add(0); // placeholder in array
                                                januaryAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["FEB"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                februaryAmountList.Add(amountValue);
                                                februaryAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                februaryAmountList.Add(0); // placeholder in array
                                                februaryAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["MAR"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                marchAmountList.Add(amountValue);
                                                marchAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                marchAmountList.Add(0); // placeholder in array
                                                marchAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["APR"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                aprilAmountList.Add(amountValue);
                                                aprilAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                aprilAmountList.Add(0); // placeholder in array
                                                aprilAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["MAY"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                mayAmountList.Add(amountValue);
                                                mayAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                mayAmountList.Add(0); // placeholder in array
                                                mayAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["JUN"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                juneAmountList.Add(amountValue);
                                                juneAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                juneAmountList.Add(0); // placeholder in array
                                                juneAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["JUL"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                julyAmountList.Add(amountValue);
                                                julyAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                julyAmountList.Add(0); // placeholder in array
                                                julyAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["AUG"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                augustAmountList.Add(amountValue);
                                                augustAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                augustAmountList.Add(0); // placeholder in array
                                                augustAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["SEP"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                septemberAmountList.Add(amountValue);
                                                septemberAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                septemberAmountList.Add(0); // placeholder in array
                                                septemberAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["OCT"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                octoberAmountList.Add(amountValue);
                                                octoberAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                octoberAmountList.Add(0); // placeholder in array
                                                octoberAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["NOV"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                novemberAmountList.Add(amountValue);
                                                novemberAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                novemberAmountList.Add(0); // placeholder in array
                                                novemberAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["DEC"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                decemberAmountList.Add(amountValue);
                                                decemberAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                decemberAmountList.Add(0); // placeholder in array
                                                decemberAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                        } else {
                                            // validate that the time period is a number
                                            if (!Int16.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["TIME"])), out tempShort)) {
                                                message = string.Format("The column 'TIME' in row {0} contains an invalid value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                fiscalMonthList.Add(Convert.ToString(tempShort));
                                            }

                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["AMOUNT"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                amountList.Add(amountValue);
                                                amountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                amountList.Add(0); // placeholder in array
                                                amountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                        }
                                    }

                                    currentBindArrayIndex++;
                                    index = 0;
                                    if (currentBindArrayIndex == maxRowsPerUpdate) {
                                        command.Parameters[index].Value = lineNumbersList.ToArray();
                                        command.Parameters[++index].Value = reportingLineList.ToArray();
                                        command.Parameters[++index].Value = customerAccountList.ToArray();
                                        command.Parameters[++index].Value = kpiList.ToArray();
                                        command.Parameters[++index].Value = viewsList.ToArray();
                                        command.Parameters[++index].Value = scenarioList.ToArray();
                                        command.Parameters[++index].Value = productList.ToArray();
                                        command.Parameters[++index].Value = subaccountList.ToArray();
                                        command.Parameters[++index].Value = serviceTypeList.ToArray();
                                        command.Parameters[++index].Value = functionList.ToArray();
                                        command.Parameters[++index].Value = entityList.ToArray();
                                        command.Parameters[++index].Value = equipmentList.ToArray();
                                        command.Parameters[++index].Value = techTypeList.ToArray();
                                        command.Parameters[++index].Value = previousTypeList.ToArray();
                                        command.Parameters[++index].Value = connectionTypeList.ToArray();
                                        command.Parameters[++index].Value = segmentList.ToArray();
                                        command.Parameters[++index].Value = versionList.ToArray();
                                        command.Parameters[++index].Value = verticalList.ToArray();
                                        command.Parameters[++index].Value = owningGeographyList.ToArray();
                                        command.Parameters[++index].Value = owningManagerList.ToArray();
                                        command.Parameters[++index].Value = branchList.ToArray();
                                        command.Parameters[++index].Value = contractTermList.ToArray();
                                        command.Parameters[++index].Value = programEligibleList.ToArray();
                                        
                                        if (checkFact) {
                                            command.Parameters[++index].Value = fiscalYearList.ToArray();
                                            if (fileType.Is13Month || fileType.IsOutlook) {
                                                command.Parameters[++index].Value = begbalAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = begbalAmountNullList.ToArray();
                                                command.Parameters[++index].Value = januaryAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = januaryAmountNullList.ToArray();
                                                command.Parameters[++index].Value = februaryAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = februaryAmountNullList.ToArray();
                                                command.Parameters[++index].Value = marchAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = marchAmountNullList.ToArray();
                                                command.Parameters[++index].Value = aprilAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = aprilAmountNullList.ToArray();
                                                command.Parameters[++index].Value = mayAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = mayAmountNullList.ToArray();
                                                command.Parameters[++index].Value = juneAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = juneAmountNullList.ToArray();
                                                command.Parameters[++index].Value = julyAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = julyAmountNullList.ToArray();
                                                command.Parameters[++index].Value = augustAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = augustAmountNullList.ToArray();
                                                command.Parameters[++index].Value = septemberAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = septemberAmountNullList.ToArray();
                                                command.Parameters[++index].Value = octoberAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = octoberAmountNullList.ToArray();
                                                command.Parameters[++index].Value = novemberAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = novemberAmountNullList.ToArray();
                                                command.Parameters[++index].Value = decemberAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = decemberAmountNullList.ToArray();
                                            } else {
                                                command.Parameters[++index].Value = fiscalMonthList.ToArray();
                                                command.Parameters[++index].Value = amountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = amountNullList.ToArray();
                                            }
                                        }

                                        command.ArrayBindCount = currentBindArrayIndex;
                                        totalRecordsAdded += command.ExecuteNonQuery();
                                        currentBindArrayIndex = 0;
                                        lineNumbersList.Clear();
                                        reportingLineList.Clear();
                                        customerAccountList.Clear();
                                        kpiList.Clear();
                                        viewsList.Clear();
                                        scenarioList.Clear();
                                        productList.Clear();
                                        subaccountList.Clear();
                                        serviceTypeList.Clear();
                                        functionList.Clear();
                                        entityList.Clear();
                                        equipmentList.Clear();
                                        techTypeList.Clear();
                                        previousTypeList.Clear();
                                        connectionTypeList.Clear();
                                        segmentList.Clear();
                                        versionList.Clear();
                                        verticalList.Clear();
                                        owningGeographyList.Clear();
                                        owningManagerList.Clear();
                                        branchList.Clear();
                                        contractTermList.Clear();
                                        programEligibleList.Clear();

                                        if (checkFact) {
                                            fiscalYearList.Clear();
                                            if (fileType.Is13Month || fileType.IsOutlook) {
                                                index = command.Parameters.IndexOf(":begbal"); // this offset is important
                                                begbalAmountList.Clear();
                                                begbalAmountNullList.Clear();
                                                command.Parameters[index].ArrayBindStatus = null;
                                                januaryAmountList.Clear();
                                                januaryAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                februaryAmountList.Clear();
                                                februaryAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                marchAmountList.Clear();
                                                marchAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                aprilAmountList.Clear();
                                                aprilAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                mayAmountList.Clear();
                                                mayAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                juneAmountList.Clear();
                                                juneAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                julyAmountList.Clear();
                                                julyAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                augustAmountList.Clear();
                                                augustAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                septemberAmountList.Clear();
                                                septemberAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                octoberAmountList.Clear();
                                                octoberAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                novemberAmountList.Clear();
                                                novemberAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                decemberAmountList.Clear();
                                                decemberAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                            } else {
                                                fiscalMonthList.Clear();
                                                amountList.Clear();
                                                amountNullList.Clear();
                                                command.Parameters[":amount"].ArrayBindStatus = null;
                                            }
                                        }
                                    }
                                }
                                index = 0;
                                if (currentBindArrayIndex > 0) {
                                    command.Parameters[index].Value = lineNumbersList.ToArray();
                                    command.Parameters[++index].Value = reportingLineList.ToArray();
                                    command.Parameters[++index].Value = customerAccountList.ToArray();
                                    command.Parameters[++index].Value = kpiList.ToArray();
                                    command.Parameters[++index].Value = viewsList.ToArray();
                                    command.Parameters[++index].Value = scenarioList.ToArray();
                                    command.Parameters[++index].Value = productList.ToArray();
                                    command.Parameters[++index].Value = subaccountList.ToArray();
                                    command.Parameters[++index].Value = serviceTypeList.ToArray();
                                    command.Parameters[++index].Value = functionList.ToArray();
                                    command.Parameters[++index].Value = entityList.ToArray();
                                    command.Parameters[++index].Value = equipmentList.ToArray();
                                    command.Parameters[++index].Value = techTypeList.ToArray();
                                    command.Parameters[++index].Value = previousTypeList.ToArray();
                                    command.Parameters[++index].Value = connectionTypeList.ToArray();
                                    command.Parameters[++index].Value = segmentList.ToArray();
                                    command.Parameters[++index].Value = versionList.ToArray();
                                    command.Parameters[++index].Value = verticalList.ToArray();
                                    command.Parameters[++index].Value = owningGeographyList.ToArray();
                                    command.Parameters[++index].Value = owningManagerList.ToArray();
                                    command.Parameters[++index].Value = branchList.ToArray();
                                    command.Parameters[++index].Value = contractTermList.ToArray();
                                    command.Parameters[++index].Value = programEligibleList.ToArray();

                                    if (checkFact) {
                                        command.Parameters[++index].Value = fiscalYearList.ToArray();
                                        if (fileType.Is13Month || fileType.IsOutlook) {
                                            command.Parameters[++index].Value = begbalAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = begbalAmountNullList.ToArray();
                                            command.Parameters[++index].Value = januaryAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = januaryAmountNullList.ToArray();
                                            command.Parameters[++index].Value = februaryAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = februaryAmountNullList.ToArray();
                                            command.Parameters[++index].Value = marchAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = marchAmountNullList.ToArray();
                                            command.Parameters[++index].Value = aprilAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = aprilAmountNullList.ToArray();
                                            command.Parameters[++index].Value = mayAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = mayAmountNullList.ToArray();
                                            command.Parameters[++index].Value = juneAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = juneAmountNullList.ToArray();
                                            command.Parameters[++index].Value = julyAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = julyAmountNullList.ToArray();
                                            command.Parameters[++index].Value = augustAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = augustAmountNullList.ToArray();
                                            command.Parameters[++index].Value = septemberAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = septemberAmountNullList.ToArray();
                                            command.Parameters[++index].Value = octoberAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = octoberAmountNullList.ToArray();
                                            command.Parameters[++index].Value = novemberAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = novemberAmountNullList.ToArray();
                                            command.Parameters[++index].Value = decemberAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = decemberAmountNullList.ToArray();
                                        } else {
                                            command.Parameters[++index].Value = fiscalMonthList.ToArray();
                                            command.Parameters[++index].Value = amountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = amountNullList.ToArray();
                                        }
                                    }
                                    command.ArrayBindCount = currentBindArrayIndex;
                                    totalRecordsAdded += command.ExecuteNonQuery();
                                }
                                transaction.Commit();
                            }
                            excelReader.Close();
                            excelConnection.Close();
                            connection.Close();
                        }
                    }
                }
            } catch (OleDbException) {
                message = string.Format("There was an error opening the Excel file.  Make sure that a Worksheet named '{0}' exists.", fileType.FileTypeCode);
                return -1;
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                message = ex.Message + "<BR>" + ex.StackTrace;
                return -2;
            }
            System.Diagnostics.Debug.WriteLine(DateTime.Now);
            return totalRecordsAdded;
        }

        public static int UnpivotReportingFrom13Month(FileType fileType, out string message) {
            string sqlText = string.Empty;
            int recordsInserted = 0;
            message = string.Empty;

            try {
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = connection.CreateCommand()) {
                    connection.Open();
                    using (OracleTransaction transaction = connection.BeginTransaction()) {
                        sqlText = string.Format(
@"delete from {0} where prp_rpt_source='{1}'"
                            , fileType.StageMonthTable, fileType.FileTypeCode);

                        command.CommandText = sqlText;
                        command.ExecuteNonQuery();
                        sqlText = string.Format(
@"insert into {0} (
    dim_rpt_account, dim_rpt_company, dim_rpt_costcenter, dim_rpt_entity
    , dim_rpt_equipment, dim_rpt_function, dim_rpt_kpi, dim_rpt_product
    , dim_rpt_reportngline, dim_rpt_scenario, dim_rpt_servicetype, dim_rpt_subaccount
    , dim_rpt_techtype, dim_rpt_time, dim_rpt_view, dim_rpt_years
    , fact_rpt_measure, prp_rpt_createmodifydate, prp_rpt_owner, prp_rpt_source
    , xtr_rpt_col1, xtr_rpt_col2, xtr_rpt_col3, xtr_rpt_col4
    , linenbr
  ) 
  select dim_rpt_account, dim_rpt_company, dim_rpt_costcenter, dim_rpt_entity
    , dim_rpt_equipment, dim_rpt_function, dim_rpt_kpi, dim_rpt_product
    , dim_rpt_reportngline, dim_rpt_scenario, dim_rpt_servicetype, dim_rpt_subaccount
    , dim_rpt_techtype, dim_rpt_time, dim_rpt_view, dim_rpt_years
    , fact_rpt_measure, prp_rpt_createmodifydate, prp_rpt_owner, prp_rpt_source
    , xtr_rpt_col1, xtr_rpt_col2, xtr_rpt_col3, xtr_rpt_col4
    , linenbr
  from {1}
  unpivot include nulls (
    fact_rpt_measure for dim_rpt_time in (begbal as '0', jan as '1', feb as '2', mar as '3', apr as '4', may as '5', jun as '6', jul as '7', aug as '8', sep as '9', oct as '10', nov as '11', dec as '12' )
  )
  where prp_rpt_source = '{2}' "
                            , fileType.StageMonthTable, fileType.StageYearTable, fileType.FileTypeCode);
                        command.CommandText = sqlText;
                        recordsInserted = command.ExecuteNonQuery();
                        transaction.Commit();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(string.Empty, MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                message = "An error occurred trying to unpivot 13 month stage table" + ex.Message;
            }

            return recordsInserted;
        }

        public static int UnpivotReportingOneMonthFrom13Month(FileType fileType, int fiscalYear, int fiscalMonth, out string message) {
            string sqlText = string.Empty;
            int recordsInserted = 0;
            message = string.Empty;
            
            try {
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = connection.CreateCommand()) {
                    connection.Open();
                    using (OracleTransaction transaction = connection.BeginTransaction()) {
                        sqlText = string.Format(
@"delete from {0} where prp_rpt_source='{1}' and dim_rpt_time='{2}' and dim_rpt_years='{3}'"
                            , fileType.StageMonthTable, fileType.FileTypeCode, fiscalMonth.ToString(), fiscalYear.ToString());        

                        command.CommandText = sqlText;
                        command.ExecuteNonQuery();
                        sqlText = string.Format(
@"insert into {0} (
    dim_rpt_account, dim_rpt_company, dim_rpt_costcenter, dim_rpt_entity
    , dim_rpt_equipment, dim_rpt_function, dim_rpt_kpi, dim_rpt_product
    , dim_rpt_reportngline, dim_rpt_scenario, dim_rpt_servicetype, dim_rpt_subaccount
    , dim_rpt_techtype, dim_rpt_time, dim_rpt_view, dim_rpt_years
    , fact_rpt_measure, prp_rpt_createmodifydate, prp_rpt_owner, prp_rpt_source
    , xtr_rpt_col1, xtr_rpt_col2, xtr_rpt_col3, xtr_rpt_col4
    , linenbr
  ) 
  select dim_rpt_account, dim_rpt_company, dim_rpt_costcenter, dim_rpt_entity
    , dim_rpt_equipment, dim_rpt_function, dim_rpt_kpi, dim_rpt_product
    , dim_rpt_reportngline, dim_rpt_scenario, dim_rpt_servicetype, dim_rpt_subaccount
    , dim_rpt_techtype, dim_rpt_time, dim_rpt_view, dim_rpt_years
    , fact_rpt_measure, prp_rpt_createmodifydate, prp_rpt_owner, prp_rpt_source
    , xtr_rpt_col1, xtr_rpt_col2, xtr_rpt_col3, xtr_rpt_col4
    , linenbr
  from {1}
  unpivot include nulls (
    fact_rpt_measure for dim_rpt_time in (begbal as '0', jan as '1', feb as '2', mar as '3', apr as '4', may as '5', jun as '6', jul as '7', aug as '8', sep as '9', oct as '10', nov as '11', dec as '12' )
  )
  where prp_rpt_source = '{2}' and dim_rpt_years = '{3}' and dim_rpt_time = '{4}'"
                            , fileType.StageMonthTable, fileType.StageYearTable, fileType.FileTypeCode, fiscalYear.ToString(), fiscalMonth.ToString());
                        command.CommandText = sqlText;
                        recordsInserted = command.ExecuteNonQuery();
                        transaction.Commit();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(string.Empty, MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                message = string.Format("An error occurred trying to unpivot 13 month stage table for month = '{0}'", fiscalMonth) + ex.Message;
            }

            return recordsInserted;
        }

        public static int UnpivotLocationFrom13Month(FileType fileType, out string message) {
            string sqlText = string.Empty;
            int recordsInserted = 0;
            message = string.Empty;

            try {
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = connection.CreateCommand()) {
                    connection.Open();
                    using (OracleTransaction transaction = connection.BeginTransaction()) {
                        sqlText = string.Format(@"delete from {0} where source='{1}'", fileType.StageMonthTable, fileType.FileTypeCode);
                        command.CommandText = sqlText;
                        command.ExecuteNonQuery();
                        sqlText = string.Format(

@"insert into {0} (
    line_nbr, year, time, account, reporting_line, scenario, equipment, tech_type
    , views, location, product, service_type, kpi, cost_center, function, subaccount
    , store_status, design_type, location_subtype, location_type
    , location_tier_code, amount, source, owner, date_created
  )
  select line_nbr, year, fiscal_month, account, reporting_line, scenario, equipment, tech_type
    , views, location, product, service_type, kpi, cost_center, function, subaccount
    , store_status, design_type, location_subtype, location_type
    , location_tier_code, amount, source, owner, date_created
  from {1} 
  unpivot include nulls (
    amount for fiscal_month in (begbal as 0, jan as 1, feb as 2, mar as 3, apr as 4, may as 5, jun as 6, jul as 7, aug as 8, sep as 9, oct as 10, nov as 11, dec as 12 )
  )
  where source = '{2}'"
                            , fileType.StageMonthTable, fileType.StageYearTable, fileType.FileTypeCode);
                        command.CommandText = sqlText;
                        recordsInserted = command.ExecuteNonQuery();
                        transaction.Commit();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(string.Empty, MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                message = "An error occurred trying to unpivot 13 month stage table" + ex.Message;
            }

            return recordsInserted;
        }

        public static int UnpivotLocationOneMonthFrom13Month(FileType fileType, int fiscalYear, int fiscalMonth, out string message) {
            string sqlText = string.Empty;
            int recordsInserted = 0;
            message = string.Empty;

            try {
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = connection.CreateCommand()) {
                    connection.Open();
                    using (OracleTransaction transaction = connection.BeginTransaction()) {
                        sqlText = string.Format(
@"delete from {0} where source='{1}' and time='{2}' and year='{3}'"
                            , fileType.StageMonthTable, fileType.FileTypeCode, fiscalMonth.ToString(), fiscalYear.ToString());

                        command.CommandText = sqlText;
                        command.ExecuteNonQuery();
                        sqlText = string.Format(

@"insert into {0} (
    line_nbr, year, time, account, reporting_line, scenario, equipment, tech_type
    , views, location, product, service_type, kpi, cost_center, function, subaccount
    , store_status, design_type, location_subtype, location_type
    , location_tier_code, amount, source, owner, date_created
  )
  select line_nbr, year, fiscal_month, account, reporting_line, scenario, equipment, tech_type
    , views, location, product, service_type, kpi, cost_center, function, subaccount
    , store_status, design_type, location_subtype, location_type
    , location_tier_code, amount, source, owner, date_created
  from {1} 
  unpivot include nulls (
    amount for fiscal_month in (begbal as 0, jan as 1, feb as 2, mar as 3, apr as 4, may as 5, jun as 6, jul as 7, aug as 8, sep as 9, oct as 10, nov as 11, dec as 12 )
  )
  where source = '{2}' and year = '{3}' and fiscal_month = '{4}'"
                            , fileType.StageMonthTable, fileType.StageYearTable, fileType.FileTypeCode, fiscalYear.ToString(), fiscalMonth.ToString());
                        command.CommandText = sqlText;
                        recordsInserted = command.ExecuteNonQuery();
                        transaction.Commit();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(string.Empty, MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                message = string.Format("An error occurred trying to unpivot 13 month stage table for month = '{0}'", fiscalMonth) + ex.Message;
            }

            return recordsInserted;
        }

        public static int UnpivotDataWarehouseFrom13Month(FileType fileType, out string message) {
            string sqlText = string.Empty;
            int recordsInserted = 0;
            message = string.Empty;

            try {
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = connection.CreateCommand()) {
                    connection.Open();
                    using (OracleTransaction transaction = connection.BeginTransaction()) {
                        sqlText = string.Format(@"delete from {0} where source='{1}'", fileType.StageMonthTable, fileType.FileTypeCode);

                        command.CommandText = sqlText;
                        command.ExecuteNonQuery();
                        sqlText = string.Format(

@"insert into {0} (
    line_nbr, year, time, reporting_line, customer_account, entity, equipment, previous_type
    , connection_type, subaccount, tech_type, function, service_type, product, segment, scenario
    , views, kpi, version, vertical, owning_geography, owning_manager, branch, amount
    , source, owner, date_created, contract_term, program_eligibility
  )
  select line_nbr, year, fiscal_month, reporting_line, customer_account, entity, equipment, previous_type
    , connection_type, subaccount, tech_type, function, service_type, product, segment, scenario
    , views, kpi, version, vertical, owning_geography, owning_manager, branch, amount
    , source, owner, date_created, contract_term, program_eligibility
  from {1} 
  unpivot include nulls (
    amount for fiscal_month in (begbal as 0, jan as 1, feb as 2, mar as 3, apr as 4, may as 5, jun as 6, jul as 7, aug as 8, sep as 9, oct as 10, nov as 11, dec as 12 )
  )
  where source = '{2}'"
                            , fileType.StageMonthTable, fileType.StageYearTable, fileType.FileTypeCode);
                        command.CommandText = sqlText;
                        recordsInserted = command.ExecuteNonQuery();
                        transaction.Commit();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(string.Empty, MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                message = "An error occurred trying to unpivot 13 month stage table" + ex.Message;
            }

            return recordsInserted;
        }

        public static int UnpivotDataWarehouseOneMonthFrom13Month(FileType fileType, int fiscalYear, int fiscalMonth, out string message) {
            string sqlText = string.Empty;
            int recordsInserted = 0; 
            message = string.Empty;

            try {
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = connection.CreateCommand()) {
                    connection.Open();
                    using (OracleTransaction transaction = connection.BeginTransaction()) {
                        sqlText = string.Format(
@"delete from {0} where source='{1}' and time='{2}' and year='{3}'"
                            , fileType.StageMonthTable, fileType.FileTypeCode, fiscalMonth.ToString(), fiscalYear.ToString());

                        command.CommandText = sqlText;
                        command.ExecuteNonQuery();
                        sqlText = string.Format(

@"insert into {0} (
    line_nbr, year, time, reporting_line, customer_account, entity, equipment, previous_type
    , connection_type, subaccount, tech_type, function, service_type, product, segment, scenario
    , views, kpi, version, vertical, owning_geography, owning_manager, branch, amount
    , source, owner, date_created, contract_term, program_eligibility
  )
  select line_nbr, year, fiscal_month, reporting_line, customer_account, entity, equipment, previous_type
    , connection_type, subaccount, tech_type, function, service_type, product, segment, scenario
    , views, kpi, version, vertical, owning_geography, owning_manager, branch, amount
    , source, owner, date_created, contract_term, program_eligibility
  from {1} 
  unpivot include nulls (
    amount for fiscal_month in (begbal as 0, jan as 1, feb as 2, mar as 3, apr as 4, may as 5, jun as 6, jul as 7, aug as 8, sep as 9, oct as 10, nov as 11, dec as 12 )
  )
  where source = '{2}' and year = '{3}' and fiscal_month = '{4}'"
                            , fileType.StageMonthTable, fileType.StageYearTable, fileType.FileTypeCode, fiscalYear.ToString(), fiscalMonth.ToString());
                        command.CommandText = sqlText;
                        recordsInserted = command.ExecuteNonQuery();
                        transaction.Commit();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(string.Empty, MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                message = string.Format("An error occurred trying to unpivot 13 month stage table for month = '{0}'", fiscalMonth) + ex.Message;
            }

            return recordsInserted;
        }
        
        #region Process Delta Procedures

        public static int CallReportingProcessDelta(int month, string year, FileType fileType, string tempTableName, string requestor) {
            string sqlText = string.Empty;
            int recordsUpdated = -1;
            try {
                sqlText = fileType.IsAdjustment ? "etl_process_delta.load_adj_facts" : "etl_process_delta.load_facts";

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)  ) {
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new OracleParameter("@i_stage_table", OracleDbType.Varchar2, fileType.StageMonthTable, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@i_target_table", OracleDbType.Varchar2, fileType.DestinationTable, ParameterDirection.Input));
                    if (!fileType.IsAdjustment) {
                        command.Parameters.Add(new OracleParameter("@i_fiscal_month", OracleDbType.Varchar2, month.ToString(), ParameterDirection.Input));
                    }
                    command.Parameters.Add(new OracleParameter("@i_source", OracleDbType.Varchar2, fileType.FileTypeCode, ParameterDirection.Input));
                    if (!fileType.IsAdjustment) {
                        command.Parameters.Add(new OracleParameter("@i_fiscal_year", OracleDbType.Varchar2, year, ParameterDirection.Input));
                    }
                    command.Parameters.Add(new OracleParameter("@o_rows_updated", OracleDbType.Int32, ParameterDirection.Output));

                    command.ExecuteNonQuery();
                    recordsUpdated = int.Parse(string.Format("{0}", command.Parameters["@o_rows_updated"].Value));
                    if (recordsUpdated < 0) {
                        throw new Exception("process delta returned -1");
                    }

                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(requestor, MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                recordsUpdated = -1;
            }
            
            return recordsUpdated;
        }

        public static int CallLocationProcessDelta(int month, string year, FileType fileType, string requestor) {
            string sqlText = string.Empty;
            int recordsUpdated = -1;
            try {
                sqlText = fileType.IsAdjustment ? "etl_process_delta.load_location_adj_facts" : "etl_process_delta.load_location_user_facts";

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new OracleParameter("@i_stage_table", OracleDbType.Varchar2, fileType.StageMonthTable, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@i_target_table", OracleDbType.Varchar2, fileType.DestinationTable, ParameterDirection.Input));
                    if (!fileType.IsAdjustment) {
                        command.Parameters.Add(new OracleParameter("@i_fiscal_month", OracleDbType.Varchar2, month.ToString(), ParameterDirection.Input));
                        command.Parameters.Add(new OracleParameter("@i_fiscal_year", OracleDbType.Varchar2, year, ParameterDirection.Input));
                    }
                    command.Parameters.Add(new OracleParameter("@i_source", OracleDbType.Varchar2, fileType.FileTypeCode, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@o_rows_updated", OracleDbType.Int32, ParameterDirection.Output));
                    
                    command.ExecuteNonQuery();
                    recordsUpdated = int.Parse(string.Format("{0}", command.Parameters["@o_rows_updated"].Value));
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(requestor, MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                recordsUpdated = -1;
            }

            return recordsUpdated;
        }

        public static int CallEquipmentProcessDelta(int month, string year, FileType fileType, string requestor) {
            string sqlText = string.Empty;
            int recordsUpdated = -1;
            try {
                sqlText = fileType.IsAdjustment ? "etl_process_delta.load_equipment_adj_facts" : "etl_process_delta.load_equipment_user_facts";

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new OracleParameter("@i_stage_table", OracleDbType.Varchar2, fileType.StageMonthTable, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@i_target_table", OracleDbType.Varchar2, fileType.DestinationTable, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@i_source", OracleDbType.Varchar2, fileType.FileTypeCode, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@o_rows_updated", OracleDbType.Int32, ParameterDirection.Output));

                    command.ExecuteNonQuery();
                    recordsUpdated = int.Parse(string.Format("{0}", command.Parameters["@o_rows_updated"].Value));
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(requestor, MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                recordsUpdated = -1;
            }

            return recordsUpdated;
        }

        public static int CallDataWarehouseProcessDelta(int month, string year, FileType fileType, string requestor) {
            string sqlText = string.Empty;
            int recordsUpdated = -1;
            try {
                sqlText = fileType.IsAdjustment ? "etl_process_delta.load_dw_adj_facts" : "etl_process_delta.load_dw_user_facts";

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new OracleParameter("@i_stage_table", OracleDbType.Varchar2, fileType.StageMonthTable, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@i_target_table", OracleDbType.Varchar2, fileType.DestinationTable, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@i_source", OracleDbType.Varchar2, fileType.FileTypeCode, ParameterDirection.Input));
                    if (!fileType.IsAdjustment) {
                        command.Parameters.Add(new OracleParameter("@i_fiscal_month", OracleDbType.Varchar2, month.ToString(), ParameterDirection.Input));
                        command.Parameters.Add(new OracleParameter("@i_fiscal_year", OracleDbType.Varchar2, year, ParameterDirection.Input));
                    }
                    command.Parameters.Add(new OracleParameter("@o_rows_updated", OracleDbType.Int32, ParameterDirection.Output));

                    command.ExecuteNonQuery();
                    recordsUpdated = int.Parse(string.Format("{0}", command.Parameters["@o_rows_updated"].Value));
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(requestor, MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                recordsUpdated = -1;
            }

            return recordsUpdated;
        }

        #endregion

        public static ArrayList GetReportingLoadedRecords(FileType fileType, int month, string year, int maxRows, int rowsUpdated, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            string monthString = string.Empty;

            rowsSkipped = 0;
            switch (month) {
                case 0: monthString = "begbal"; break;
                case 1: monthString = "jan"; break;
                case 2: monthString = "feb"; break;
                case 3: monthString = "mar"; break;
                case 4: monthString = "apr"; break;
                case 5: monthString = "may"; break;
                case 6: monthString = "jun"; break;
                case 7: monthString = "jul"; break;
                case 8: monthString = "aug"; break;
                case 9: monthString = "sep"; break;
                case 10: monthString = "oct"; break;
                case 11: monthString = "nov"; break;
                case 12: monthString = "dec"; break;
            }


            try {

                if (fileType.IsAdjustment) {
                    sqlText = fileType.Is13Month || fileType.IsOutlook ?
                        string.Format(
@"select dim_rpt_reportngline, dim_rpt_account, dim_rpt_kpi, dim_rpt_view, dim_rpt_years, dim_rpt_scenario
      , dim_rpt_product, dim_rpt_subaccount, dim_rpt_servicetype, dim_rpt_function, dim_rpt_costcenter
      , dim_rpt_entity, dim_rpt_company, dim_rpt_equipment, dim_rpt_techtype, prp_rpt_createmodifydate
      , begbal, jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, dec
  from (
  select dim_rpt_reportngline, dim_rpt_account, dim_rpt_kpi, dim_rpt_view, dim_rpt_years, dim_rpt_scenario
    , dim_rpt_product, dim_rpt_subaccount, dim_rpt_servicetype, dim_rpt_function, dim_rpt_costcenter
    , dim_rpt_entity, dim_rpt_company, dim_rpt_equipment, dim_rpt_techtype, prp_rpt_createmodifydate, dim_rpt_time, fact_rpt_measure 
  from (
    select  s.prp_rpt_source, s.dim_rpt_reportngline, s.dim_rpt_account, s.dim_rpt_kpi, s.dim_rpt_view, s.dim_rpt_years, s.dim_rpt_scenario
      , s.dim_rpt_product, s.dim_rpt_subaccount, s.dim_rpt_servicetype, s.dim_rpt_function, s.dim_rpt_costcenter
      , s.dim_rpt_entity, s.dim_rpt_company, s.dim_rpt_equipment, s.dim_rpt_techtype, s.prp_rpt_createmodifydate
      , s.dim_rpt_time, s.fact_rpt_measure, row_number() over (order by s.prp_rpt_createmodifydate desc ) as rn
    from {1} s
    where s.prp_rpt_source = '{0}' 
  )
  where  rn <= {2}
  order by prp_rpt_createmodifydate
  )
  pivot (
    sum(fact_rpt_measure) for dim_rpt_time in ( 0 as begbal, 1 as jan, 2 as feb, 3 as mar, 4 as apr, 5 as may, 6 as jun, 7 as jul, 8 as aug, 9 as sep, 10 as oct, 11 as nov, 12 as dec)
  )"
                            , fileType.FileTypeCode, fileType.DestinationTable, rowsUpdated.ToString())
                        :
                        string.Format(
@"select * from (
    select s.dim_rpt_reportngline, s.dim_rpt_account, s.dim_rpt_kpi, s.dim_rpt_view, s.dim_rpt_years, s.dim_rpt_scenario
      , s.dim_rpt_product, s.dim_rpt_subaccount, s.dim_rpt_servicetype, s.dim_rpt_function, s.dim_rpt_costcenter
      , s.dim_rpt_entity, s.dim_rpt_company, s.dim_rpt_equipment, s.dim_rpt_techtype, s.prp_rpt_createmodifydate
      , s.dim_rpt_time, s.fact_rpt_measure, row_number() over (order by s.prp_rpt_createmodifydate desc ) as rn
    from {1} s
    where s.prp_rpt_source = '{0}' 
  )
  where  rn <= {2}
  order by prp_rpt_createmodifydate"
                            , fileType.FileTypeCode, fileType.DestinationTable, rowsUpdated.ToString());

                } else {
                    sqlText = string.Format(
@"select * from (
    select s.dim_rpt_reportngline, s.dim_rpt_account,s.dim_rpt_kpi, s.dim_rpt_view, s.dim_rpt_years, s.dim_rpt_scenario
      , s.dim_rpt_product, s.dim_rpt_subaccount, s.dim_rpt_servicetype, s.dim_rpt_function, s.dim_rpt_costcenter
      , s.dim_rpt_entity, s.dim_rpt_company, s.dim_rpt_equipment, s.dim_rpt_techtype, s.prp_rpt_createmodifydate
      , {1} {2}
      , row_number() over (order by s.prp_rpt_createmodifydate desc ) as rn
    from {4} s
    where s.prp_rpt_source = '{0}' and s.dim_rpt_years='{3}' 
  )
  where  rn <= {5}
  order by prp_rpt_createmodifydate"
                        , fileType.FileTypeCode
                        , fileType.Is13Month || fileType.IsOutlook ? string.Empty : string.Format("'{0}',", month)
                        , fileType.Is13Month || fileType.IsOutlook ? " s.fact_begbal, s.fact_jan, s.fact_feb, s.fact_mar, s.fact_apr, s.fact_may, s.fact_jun, s.fact_jul, s.fact_aug, s.fact_sep, s.fact_oct, s.fact_nov, s.fact_dec" : "s.fact_" + monthString
                        , year, fileType.DestinationTable
                        , rowsUpdated.ToString());
                }

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        while (reader.Read()) {
                            if (rowCount < maxRows) {
                                int i = 0;
                                FactDTO f = new FactDTO();
                                f.ReportingLine = reader.GetString(i);
                                f.Account = reader.GetString(++i);
                                f.KPI = reader.GetString(++i);
                                f.View = reader.GetString(++i);
                                f.Year = reader.GetString(++i);
                                f.Scenario = reader.GetString(++i);
                                f.Product = reader.GetString(++i);
                                f.SubAccount = reader.GetString(++i);
                                f.ServiceType = reader.GetString(++i);
                                f.Function = reader.GetString(++i);
                                f.CostCenter = reader.GetString(++i);
                                f.Entity = reader.GetString(++i);
                                f.Company = reader.GetString(++i);
                                f.Equipment = reader.GetString(++i);
                                f.TechType = reader.GetString(++i);
                                if (!reader.IsDBNull(++i)) f.CreateModifyDate = reader.GetDateTime(i);
                                if (!fileType.IsOutlook && !fileType.Is13Month) {
                                    if (!reader.IsDBNull(++i)) f.Month = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Fact = reader.GetDecimal(i).ToString();
                                } else {
                                    if (!reader.IsDBNull(++i)) f.Fact_BegBal = reader.GetDecimal(i).ToString(); ;
                                    if (!reader.IsDBNull(++i)) f.Fact_Jan = reader.GetDecimal(i).ToString(); ;
                                    if (!reader.IsDBNull(++i)) f.Fact_Feb = reader.GetDecimal(i).ToString(); ;
                                    if (!reader.IsDBNull(++i)) f.Fact_Mar = reader.GetDecimal(i).ToString(); ;
                                    if (!reader.IsDBNull(++i)) f.Fact_Apr = reader.GetDecimal(i).ToString(); ;
                                    if (!reader.IsDBNull(++i)) f.Fact_May = reader.GetDecimal(i).ToString(); ;
                                    if (!reader.IsDBNull(++i)) f.Fact_Jun = reader.GetDecimal(i).ToString(); ;
                                    if (!reader.IsDBNull(++i)) f.Fact_Jul = reader.GetDecimal(i).ToString(); ;
                                    if (!reader.IsDBNull(++i)) f.Fact_Aug = reader.GetDecimal(i).ToString(); ;
                                    if (!reader.IsDBNull(++i)) f.Fact_Sep = reader.GetDecimal(i).ToString(); ;
                                    if (!reader.IsDBNull(++i)) f.Fact_Oct = reader.GetDecimal(i).ToString(); ;
                                    if (!reader.IsDBNull(++i)) f.Fact_Nov = reader.GetDecimal(i).ToString(); ;
                                    if (!reader.IsDBNull(++i)) f.Fact_Dec = reader.GetDecimal(i).ToString(); ;
                                }

                                a.Add(f);
                                rowCount++;
                            } else {
                                // max row was reached 
                                rowsSkipped++;
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(string.Empty, MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        public static ArrayList GetLocationLoadedRecords(FileType fileType, int month, string year, int maxRows, int rowsUpdated, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                sqlText = fileType.Is13Month ?
                    string.Format(
@"with base_data as (
    select reporting_line, account, kpi, views, year, scenario, product, subaccount, service_type, function, cost_center, location
      , equipment, tech_type, store_status, design_type, location_type, location_subtype, location_tier_code, time, amount
    from (
      select reporting_line, account, kpi, views, substr(fiscal_period, 0, 4) as year, scenario, product, subaccount, service_type
        , function, cost_center, location, equipment, tech_type, store_status, design_type, location_type, location_subtype
        , location_tier_code, trunc(date_modified) dateM, substr(fiscal_period, 5, 2) time, amount
        , row_number() over (order by date_modified desc ) as rn
      from  {0} 
      where source = '{1}'
    )
    where  rn <= {2}
  )
  select * from base_data
  pivot (
    sum(amount) as amt for time in ( 
      '00' as begbal, '01' as jan, '02' as feb, '03' as mar, '04' as apr, '05' as may, '06' as jun, '07' as jul
      , '08' as aug, '09' as sep, '10' as oct, '11' as nov, '12' as dec)) "
                       , fileType.DestinationTable, fileType.FileTypeCode, rowsUpdated.ToString())
                    : string.Format(
@"select * from (
    select reporting_line, account, kpi, views, substr(fiscal_period, 0, 4) as year, scenario, product, subaccount
      , service_type, function, cost_center, location, equipment, tech_type, store_status, design_type, location_type
      , location_subtype, location_tier_code, substr(fiscal_period, 5, 2) as time, amount
      , row_number() over (order by date_modified desc) as rn
    from {0}  
    where source = '{1}' and substr(fiscal_period, 0, 4) = '{2}'
  )
  where  rn <= {3} "
                        , fileType.DestinationTable, fileType.FileTypeCode, year, rowsUpdated.ToString()); 
                    
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        while (reader.Read()) {
                            if (rowCount < maxRows) {
                                int i = 0;
                                FactDTO f = new FactDTO();
                                f.ReportingLine = reader.GetString(i);
                                f.Account = reader.GetString(++i);
                                f.KPI = reader.GetString(++i);
                                f.View = reader.GetString(++i);
                                f.Year = reader.GetString(++i);
                                f.Scenario = reader.GetString(++i);
                                f.Product = reader.GetString(++i);
                                f.SubAccount = reader.GetString(++i);
                                f.ServiceType = reader.GetString(++i);
                                f.Function = reader.GetString(++i);
                                f.CostCenter = reader.GetString(++i);
                                f.Entity = reader.GetString(++i); 
                                f.Equipment = reader.GetString(++i);
                                f.TechType = reader.GetString(++i);
                                f.StoreStatus = reader.GetString(++i);
                                f.DesignType = reader.GetString(++i);
                                f.LocationType = reader.GetString(++i);
                                f.LocationSubtype = reader.GetString(++i);
                                f.LocationTierCode = reader.GetString(++i);
                                if (!fileType.Is13Month) {
                                    if (!reader.IsDBNull(++i)) f.Month = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Fact = reader.GetDecimal(i).ToString();
                                } else {
                                    if (!reader.IsDBNull(++i)) f.Fact_BegBal = reader.GetDecimal(i).ToString();
                                    if (!reader.IsDBNull(++i)) f.Fact_Jan = reader.GetDecimal(i).ToString();
                                    if (!reader.IsDBNull(++i)) f.Fact_Feb = reader.GetDecimal(i).ToString();
                                    if (!reader.IsDBNull(++i)) f.Fact_Mar = reader.GetDecimal(i).ToString();
                                    if (!reader.IsDBNull(++i)) f.Fact_Apr = reader.GetDecimal(i).ToString();
                                    if (!reader.IsDBNull(++i)) f.Fact_May = reader.GetDecimal(i).ToString();
                                    if (!reader.IsDBNull(++i)) f.Fact_Jun = reader.GetDecimal(i).ToString();
                                    if (!reader.IsDBNull(++i)) f.Fact_Jul = reader.GetDecimal(i).ToString();
                                    if (!reader.IsDBNull(++i)) f.Fact_Aug = reader.GetDecimal(i).ToString();
                                    if (!reader.IsDBNull(++i)) f.Fact_Sep = reader.GetDecimal(i).ToString();
                                    if (!reader.IsDBNull(++i)) f.Fact_Oct = reader.GetDecimal(i).ToString();
                                    if (!reader.IsDBNull(++i)) f.Fact_Nov = reader.GetDecimal(i).ToString();
                                    if (!reader.IsDBNull(++i)) f.Fact_Dec = reader.GetDecimal(i).ToString();
                                }                                
                                a.Add(f);
                                rowCount++;
                            } else {
                                // max row was reached 
                                rowsSkipped++;
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(string.Empty, MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        public static ArrayList GetEquipmentLoadedRecords(FileType fileType, int month, string year, int maxRows, int rowsUpdated, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                sqlText = string.Format(
@"select * from (
    select s.reporting_line, s.kpi, s.views, s.scenario, s.service_type, s.function
      , s.cost_center, s.entity, s.equipment, s.tech_type, s.methodology_type
      , s.sale_type, s.discount_type, s.contract_term, s.fact_date, s.amount, s.date_modified
      , row_number() over (order by s.date_modified desc) as rn
    from {0} s
    where s.source = '{1}'  
  )
  where  rn <= {3}
  order by date_modified "
                    , fileType.DestinationTable, fileType.FileTypeCode, year, rowsUpdated.ToString());

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        while (reader.Read()) {
                            if (rowCount < maxRows) {
                                int i = 0;
                                FactDTO f = new FactDTO();
                                f.ReportingLine = reader.GetString(i);
                                f.KPI = reader.GetString(++i);
                                f.View = reader.GetString(++i);
                                f.Scenario = reader.GetString(++i);
                                f.ServiceType = reader.GetString(++i);
                                f.Function = reader.GetString(++i);
                                f.CostCenter = reader.GetString(++i);
                                f.Entity = reader.GetString(++i); ;
                                f.Equipment = reader.GetString(++i);
                                f.TechType = reader.GetString(++i);
                                f.MethodType = reader.GetString(++i);
                                f.SaleType = reader.GetString(++i);
                                f.DiscountType = reader.GetString(++i);
                                if (!reader.IsDBNull(++i)) f.ContractTerm = reader.GetString(i);
                                f.FactDate = reader.GetDateTime(++i);
                                if (!reader.IsDBNull(++i)) f.Fact = reader.GetDecimal(i).ToString();
                                a.Add(f);
                                rowCount++;
                            } else {
                                // max row was reached 
                                rowsSkipped++;
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }
                
        public static ArrayList GetDataWarehouseLoadedRecords(FileType fileType, int month, string year, int maxRows, int rowsUpdated, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                sqlText = fileType.Is13Month ?
                    string.Format(
@"with base_data as (
    select year, customer_account, reporting_line, entity, equipment, previous_type, connection_type, subaccount
      , tech_type, function, service_type, product, segment, scenario, views, kpi, version, vertical, owning_geography
      , owning_manager, branch, contract_term, program_eligibility, time,  amount 
    from (
      select substr(fiscal_period, 0, 4) as year, customer_account, reporting_line, entity, equipment, previous_type
        , connection_type, subaccount, tech_type, function, service_type, product, segment, scenario, views, kpi, version
        , vertical, owning_geography, owning_manager, branch, contract_term, program_eligibility, date_modified dateM, substr(fiscal_period, 5, 2) as time
        , amount, row_number() over (order by date_modified desc ) as rn
      from  {0} 
      where source = '{1}'
    ) 
    where  rn <= {2}
  )
  select * from base_data pivot (
    sum(amount) as amt for  time in (
      '00' as begbal, '01' as jan, '02' as feb, '03' as mar, '04' as apr, '05' as may, '06' as jun, '07' as jul, '08' as aug
      , '09' as sep, '10' as oct, '11' as nov, '12' as dec
    )
  )"
                        , fileType.DestinationTable, fileType.FileTypeCode, rowsUpdated.ToString())
                    : string.Format(
@"select year, customer_account, reporting_line, entity, equipment, previous_type, connection_type, subaccount, tech_type
    , function, service_type, product, segment, scenario, views, kpi, version, vertical, owning_geography, owning_manager
    , branch, contract_term, program_eligibility, time, amount 
  from (
    select substr(fiscal_period, 0, 4) as year, customer_account, reporting_line, entity, equipment, previous_type
      , connection_type, subaccount, tech_type, function, service_type, product, segment, scenario, views, kpi, version
      , vertical, owning_geography, owning_manager, branch, contract_term, program_eligibility, substr(fiscal_period, 5, 2) as time, amount
      , row_number() over (order by date_modified desc) as rn
    from {0} 
    where source = '{1}' and  substr(fiscal_period, 0, 4) = '{2}'
  )
  where  rn <= {3} "
                        , fileType.DestinationTable, fileType.FileTypeCode, year, rowsUpdated.ToString());
                
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        while (reader.Read()) {
                            if (rowCount < maxRows) {
                                int i = 0;
                                FactDTO f = new FactDTO();
                                f.Year = reader.GetString(i);
                                f.Account = reader.GetString(++i);
                                f.ReportingLine = reader.GetString(++i);
                                f.Entity = reader.GetString(++i); ;
                                f.Equipment = reader.GetString(++i);
                                f.PreviousType = reader.GetString(++i);
                                f.ConnectionType = reader.GetString(++i);
                                f.SubAccount = reader.GetString(++i);
                                f.TechType = reader.GetString(++i);
                                f.Function = reader.GetString(++i);
                                f.ServiceType = reader.GetString(++i);
                                f.Product = reader.GetString(++i);
                                f.Segment = reader.GetString(++i);
                                f.Scenario = reader.GetString(++i);
                                f.View = reader.GetString(++i);
                                f.KPI = reader.GetString(++i);
                                f.Version = reader.GetString(++i);
                                f.Vertical = reader.GetString(++i);
                                f.OwningGeo = reader.GetString(++i);
                                f.OwningMgr = reader.GetString(++i);
                                f.Branch = reader.GetString(++i);
                                f.ContractTerm = reader.GetString(++i);
                                f.ProgramEligible = reader.GetString(++i);
                                if (!fileType.Is13Month) {
                                    if (!reader.IsDBNull(++i)) f.Month = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Fact = reader.GetDecimal(i).ToString();
                                } else {
                                    if (!reader.IsDBNull(++i)) f.Fact_BegBal = reader.GetDecimal(i).ToString();
                                    if (!reader.IsDBNull(++i)) f.Fact_Jan = reader.GetDecimal(i).ToString();
                                    if (!reader.IsDBNull(++i)) f.Fact_Feb = reader.GetDecimal(i).ToString();
                                    if (!reader.IsDBNull(++i)) f.Fact_Mar = reader.GetDecimal(i).ToString();
                                    if (!reader.IsDBNull(++i)) f.Fact_Apr = reader.GetDecimal(i).ToString();
                                    if (!reader.IsDBNull(++i)) f.Fact_May = reader.GetDecimal(i).ToString();
                                    if (!reader.IsDBNull(++i)) f.Fact_Jun = reader.GetDecimal(i).ToString();
                                    if (!reader.IsDBNull(++i)) f.Fact_Jul = reader.GetDecimal(i).ToString();
                                    if (!reader.IsDBNull(++i)) f.Fact_Aug = reader.GetDecimal(i).ToString();
                                    if (!reader.IsDBNull(++i)) f.Fact_Sep = reader.GetDecimal(i).ToString();
                                    if (!reader.IsDBNull(++i)) f.Fact_Oct = reader.GetDecimal(i).ToString();
                                    if (!reader.IsDBNull(++i)) f.Fact_Nov = reader.GetDecimal(i).ToString();
                                    if (!reader.IsDBNull(++i)) f.Fact_Dec = reader.GetDecimal(i).ToString();
                                }
                                a.Add(f);
                                rowCount++;
                            } else {
                                // max row was reached 
                                rowsSkipped++;
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(string.Empty, MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        #endregion
        
        #region key combos

        /// <summary>
        /// Validates key combinations for the UserInpuytNewKey page
        /// </summary>
        public static ArrayList ValidateReportingKeyCombinations(FileType fileType, DateTime now, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                sqlText = string.Format(
@"select s.linenbr, s.dim_rpt_reportngline, s.dim_rpt_account, s.dim_rpt_kpi, s.dim_rpt_view, s.dim_rpt_scenario, s.dim_rpt_product
    , s.dim_rpt_subaccount, s.dim_rpt_servicetype, s.dim_rpt_function, s.dim_rpt_costcenter, s.dim_rpt_entity, s.dim_rpt_company
    , s.dim_rpt_equipment, s.dim_rpt_techtype, s.prp_rpt_createmodifydate, s.prp_rpt_source, f.prp_rpt_source as validsrc
    , r.member_name as RptLne, a.member_name as RptAcct, k.member_name as RptKPI, v.member_name as RptView, n.member_name as RptScenario
    , pr.member_name as RptProduct, u.member_name as RptSubAccount, t.member_name as RptServiceType, o.member_name as RptFunc
    , c.member_name as RptCostCenter, e.member_name as RptEntity, m.member_name as RptCompany, e2.member_name as RptEquipment
    , t2.member_name as RptTechType 
  from {0} s
    left outer join {3} f on s.dim_rpt_reportngline=f.dim_rpt_reportngline and s.dim_rpt_account=f.dim_rpt_account 
      and s.dim_rpt_kpi=f.dim_rpt_kpi and s.dim_rpt_view=f.dim_rpt_view and s.dim_rpt_scenario=f.dim_rpt_scenario
      and s.dim_rpt_product=f.dim_rpt_product and s.dim_rpt_subaccount=f.dim_rpt_subaccount and s.dim_rpt_servicetype=f.dim_rpt_servicetype 
      and s.dim_rpt_function=f.dim_rpt_function and s.dim_rpt_costcenter=f.dim_rpt_costcenter and s.dim_rpt_entity=f.dim_rpt_entity 
      and s.dim_rpt_equipment=f.dim_rpt_equipment and s.dim_rpt_techtype=f.dim_rpt_techtype 
    left outer join WEB_DIMENSIONS_TBL r on r.Member_Name=s.dim_rpt_reportngline and r.dim_storage='Store Data' and r.Dim_Type='REPORTINGLINE' and r.Level_Nbr='Lev0'
    left outer join WEB_DIMENSIONS_TBL a on a.Member_Name=s.dim_rpt_account      and a.dim_storage='Store Data' and a.Dim_Type='ACCOUNT' and a.Level_Nbr='Lev0'
    left outer join WEB_DIMENSIONS_TBL k on k.Member_Name=s.dim_rpt_kpi          and k.dim_storage='Store Data' and k.Dim_Type='KPI' and k.Level_Nbr='Lev0'
    left outer join WEB_DIMENSIONS_TBL v on v.Member_Name=s.dim_rpt_view         and v.dim_storage='Store Data' and v.Dim_Type='VIEW' and v.Level_Nbr='Lev0'
    left outer join WEB_DIMENSIONS_TBL n on n.Member_Name=s.dim_rpt_scenario     and n.dim_storage='Store Data' and n.Dim_Type='SCENARIO' and n.Level_Nbr='Lev0'
    left outer join WEB_DIMENSIONS_TBL pr on pr.Member_Name=s.dim_rpt_product    and pr.dim_storage='Store Data' and pr.Dim_Type='PRODUCT' and pr.Level_Nbr='Lev0'
    left outer join WEB_DIMENSIONS_TBL u on u.Member_Name=s.dim_rpt_subaccount   and u.dim_storage='Store Data' and u.Dim_Type='SUBACCOUNT' and u.Level_Nbr='Lev0'
    left outer join WEB_DIMENSIONS_TBL t on t.Member_Name=s.dim_rpt_servicetype  and t.dim_storage='Store Data' and t.Dim_Type='SERVICETYPE' and t.Level_Nbr='Lev0'
    left outer join WEB_DIMENSIONS_TBL o on o.Member_Name=s.dim_rpt_function     and o.dim_storage='Store Data' and o.Dim_Type='FUNCTION' and o.Level_Nbr='Lev0'
    left outer join WEB_DIMENSIONS_TBL c on c.Member_Name=s.dim_rpt_costcenter   and c.dim_storage='Store Data' and c.Dim_Type='COSTCENTER' and c.Level_Nbr='Lev0'
    left outer join WEB_DIMENSIONS_TBL e on e.Member_Name=s.dim_rpt_entity       and e.dim_storage='Store Data' and e.Dim_Type='ENTITY' and e.Level_Nbr='Lev0'
    left outer join WEB_DIMENSIONS_TBL m on m.Member_Name=s.dim_rpt_company      and m.dim_storage='Store Data' and m.Dim_Type='COMPANY' and m.Level_Nbr='Lev0'
    left outer join WEB_DIMENSIONS_TBL e2 on e2.Member_Name=s.dim_rpt_equipment  and e2.dim_storage='Store Data' and e2.Dim_Type='EQUIPMENT' and e2.Level_Nbr='Lev0'
    left outer join WEB_DIMENSIONS_TBL t2 on t2.Member_Name=s.dim_rpt_techtype   and t2.dim_storage='Store Data' and t2.Dim_Type='TECHTYPE' and t2.Level_Nbr='Lev0'
  where s.prp_rpt_createmodifydate=to_date('{2}', 'yyyy/mm/dd HH24.MI.SS')  and s.prp_rpt_source='{1}' and (
    f.prp_rpt_source <>'{1}' or r.member_name is null or a.member_name is null or k.member_name is null or v.member_name is null 
    or n.member_name is null or pr.member_name is null or u.member_name is null or t.member_name is null or o.member_name is null
    or c.member_name is null or e.member_name is null or m.member_name is null or e2.member_name is null or t2.member_name is null 
    or s.dim_rpt_reportngline is null or s.dim_rpt_product is null or s.dim_rpt_subaccount is null or s.dim_rpt_servicetype is null
    or s.dim_rpt_function is null or s.dim_rpt_costcenter is null or s.dim_rpt_equipment is null or s.dim_rpt_techtype is null
  )
  order by linenbr"
                , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                , fileType.FileTypeCode, now.ToString("yyyy/MM/dd HH:mm:ss"), fileType.ValidationKeyTable);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        while (reader.Read()) {
                            if (rowCount < maxRows) {
                                int i = 0;
                                FactValidDTO f = new FactValidDTO();
                                if (!reader.IsDBNull(i)) f.Line = reader.GetDecimal(i);
                                if (!reader.IsDBNull(++i)) f.ReportingLine = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.Account = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.Product = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.SubAccount = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.CostCenter = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.Company = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.CreateModifyDate = reader.GetDateTime(i);
                                if (!reader.IsDBNull(++i)) f.Source = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.SourceValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.ReportLineValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.AccountValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.KPIValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.ViewValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.ScenarioValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.ProductValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.SubAcctValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.ServiceValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.FunctionValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.CostCenterValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.EntityValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.CompanyValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.EquipmentValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.TechTypeValid = reader.GetString(i);
                                
                                a.Add(f);
                                rowCount++;
                            } else {
                                // max row was reached 
                                rowsSkipped++;
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        public static ArrayList ValidateLocationKeyCombinations(FileType fileType, DateTime now, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                sqlText = string.Format(
@"select s.line_nbr, s.reporting_line, s.account, s.kpi, s.views, s.scenario, s.product, s.subaccount, s.service_type, s.function
    , s.cost_Center, s.location, s.equipment, s.tech_type, s.store_status, s.design_type, s.location_type, s.location_subtype
    , s.location_tier_code, s.DATE_CREATED, s.SOURCE, f.SOURCE as ValidSrc, rl.member_name as RptLne, ac.member_name as RptAcct
    , kp.member_name as RptKPI, rv.member_name as RptView, sc.member_name as RptScenario, pr.member_name as RptProduct
    , sa.member_name as RptSubAccount, st.member_name as RptServiceType, rf.member_name as RptFunc, cc.member_name as RptCostCenter
    , en.member_name as RptEntity, eq.member_name as RptEquipment, tt.member_name as RptTechType, ss.member_name as RptStoreStatus
    , dt.member_name as RptDesignType, lt.member_name as RptLocType, st.member_name as RptLocSubType, tc.member_name as RptLocTierCode
  from {0} s
    left outer join {3} f on s.reporting_line=f.reporting_line and s.account=f.account and s.kpi=f.kpi and s.views=f.views 
      and s.scenario=f.scenario and s.product=f.product and s.subaccount=f.subaccount and s.service_type=f.service_type
      and s.function=f.function and s.cost_Center=f.cost_Center and s.location=f.location and s.equipment=f.equipment 
      and s.tech_type=f.tech_type
    left outer join V_LOCATION_DIMENSIONS rl on rl.Member_Name=s.reporting_line and rl.Dim_Type='REPORTING_LINE' and rl.Level_Nbr='Lev0'
    left outer join V_LOCATION_DIMENSIONS ac on ac.Member_Name=s.account and ac.Dim_Type='ACCOUNT' and ac.Level_Nbr='Lev0'
    left outer join V_LOCATION_DIMENSIONS kp on kp.Member_Name=s.kpi and kp.Dim_Type='KPI' and kp.Level_Nbr='Lev0'
    left outer join V_LOCATION_DIMENSIONS rv on rv.Member_Name=s.views and rv.Dim_Type='VIEWS' and rv.Level_Nbr='Lev0'
    left outer join V_LOCATION_DIMENSIONS sc on sc.Member_Name=s.scenario and sc.Dim_Type='SCENARIO' and sc.Level_Nbr='Lev0'
    left outer join V_LOCATION_DIMENSIONS pr on pr.Member_Name=s.product and pr.Dim_Type='PRODUCT' and pr.Level_Nbr='Lev0'
    left outer join V_LOCATION_DIMENSIONS sa on sa.Member_Name=s.subaccount and sa.Dim_Type='SUBACCOUNT' and sa.Level_Nbr='Lev0'
    left outer join V_LOCATION_DIMENSIONS st on st.Member_Name=s.service_type and st.Dim_Type='SERVICE_TYPE' and st.Level_Nbr='Lev0'
    left outer join V_LOCATION_DIMENSIONS rf on rf.Member_Name=s.function and rf.Dim_Type='FUNCTION' and rf.Level_Nbr='Lev0'
    left outer join V_LOCATION_DIMENSIONS cc on cc.Member_Name=s.cost_Center and cc.Dim_Type='COST_CENTER' and cc.Level_Nbr='Lev0'
    left outer join V_LOCATION_DIMENSIONS en on en.Member_Name=s.location and en.Dim_Type='ENTITY' and en.Level_Nbr='Lev0'
    left outer join V_LOCATION_DIMENSIONS eq on eq.Member_Name=s.equipment and eq.Dim_Type='EQUIPMENT' and eq.Level_Nbr='Lev0'
    left outer join V_LOCATION_DIMENSIONS tt on tt.Member_Name=s.tech_type and tt.Dim_Type='TECH_TYPE' and tt.Level_Nbr='Lev0'
    left outer join V_LOCATION_DIMENSIONS ss on ss.Member_Name=s.store_status and ss.Dim_Type='STORE_STATUS' and SS.Level_Nbr='Lev0'
    left outer join V_LOCATION_DIMENSIONS dt on dt.Member_Name=s.design_type and dt.Dim_Type='DESIGN_TYPE' and dt.Level_Nbr='Lev0'
    left outer join V_LOCATION_DIMENSIONS lt on lt.Member_Name=s.location_type and lt.Dim_Type='LOCATION_TYPE' and lt.Level_Nbr='Lev0'
    left outer join V_LOCATION_DIMENSIONS st on st.Member_Name=s.location_subtype and st.Dim_Type='LOCATION_SUBTYPE' and st.Level_Nbr='Lev0'
    left outer join V_LOCATION_DIMENSIONS tc on tc.Member_Name=s.location_tier_code and tc.Dim_Type='LOCATION_TIER_CODE' and tc.Level_Nbr='Lev0'
  where s.date_created =to_date('{2}', 'yyyy/mm/dd HH24.MI.SS') and s.SOURCE='{1}' and (
    f.SOURCE <>'{1}' or rl.member_name is null or ac.member_name is null or kp.member_name is null or rv.member_name is null 
    or sc.member_name is null or pr.member_name is null or sa.member_name is null or St.member_name is null or rf.member_name is null 
    or cc.member_name is null or en.member_name is null or eq.member_name is null or tt.member_name is null or ss.member_name is null
    or dt.member_name is null or lt.member_name is null or st.member_name is null or tc.member_name is null or s.reporting_line is null
    or s.product is null or s.subaccount is null or s.service_type is null or s.function is null or s.cost_Center is null 
    or s.equipment is null or s.tech_type is null  or s.Store_status is null or s.design_type is null or s.location_type is null 
    or s.location_subtype is null or s.location_tier_code is null
  )
  order by line_nbr"
                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                    , fileType.FileTypeCode, now.ToString("yyyy/MM/dd HH:mm:ss"), fileType.ValidationKeyTable
                );

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        while (reader.Read()) {
                            if (rowCount < maxRows) {
                                int i = 0;
                                FactValidDTO f = new FactValidDTO();
                                if (!reader.IsDBNull(i)) f.Line = reader.GetDecimal(i);
                                if (!reader.IsDBNull(++i)) f.ReportingLine = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.Account = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.Product = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.SubAccount = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.CostCenter = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.StoreStatus = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.DesignType = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.LocationType = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.LocationSubtype = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.LocationTierCode = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.CreateModifyDate = reader.GetDateTime(i);
                                if (!reader.IsDBNull(++i)) f.Source = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.SourceValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.ReportLineValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.AccountValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.KPIValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.ViewValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.ScenarioValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.ProductValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.SubAcctValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.ServiceValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.FunctionValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.CostCenterValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.EntityValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.EquipmentValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.TechTypeValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.StoreStatusValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.DesignTypeValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.LocationTypeValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.LocationSubtypeValid = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.LocationTierCodeValid = reader.GetString(i);
                                a.Add(f);
                                rowCount++;
                            } else {
                                // max row was reached 
                                rowsSkipped++;
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        public static ArrayList ValidateEquipmentKeyCombinations(FileType fileType, DateTime now, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                sqlText = string.Format(
@"select s.line_nbr, s.reporting_line, s.kpi, s.views, s.scenario, s.service_type
    , s.function, s.cost_center, s.entity, s.equipment, s.tech_type, s.methodology_type
    , s.sale_type, s.discount_type, s.contract_term, s.date_created, s.source, f.source
  from {0} s
    left outer join {1} f on s.reporting_line = f.reporting_line and s.kpi = f.kpi 
      and s.views = f.views and s.scenario = f.scenario and s.service_type = f.service_type
      and s.function = f.function and s.cost_center = f.cost_center and s.entity = f.entity
      and s.equipment = f.equipment and s.tech_type = f.tech_type 
      and s.methodology_type = f.methodology_type and s.sale_type = f.sale_type
      and s.discount_type = f.discount_type and s.contract_term = f.contract_term 
  where s.date_created =to_date('{2}', 'yyyy/mm/dd HH24.MI.SS') 
    and s.source = '{3}' and f.source <>'{3}' 
  order by line_nbr"
                    , fileType.StageMonthTable, fileType.ValidationKeyTable
                    , now.ToString("yyyy/MM/dd HH:mm:ss"), fileType.FileTypeCode
                   );

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        while (reader.Read()) {
                            if (rowCount < maxRows) {
                                int i = 0;
                                FactValidDTO f = new FactValidDTO();
                                if (!reader.IsDBNull(i)) f.Line = reader.GetDecimal(i);
                                if (!reader.IsDBNull(++i)) f.ReportingLine = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.CostCenter = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.MethodType = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.SaleType = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.DiscountType = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.ContractTerm = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.CreateModifyDate = reader.GetDateTime(i);
                                if (!reader.IsDBNull(++i)) f.Source = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.SourceValid = reader.GetString(i);
                                a.Add(f);            
                                rowCount++;
                            } else {
                                // max row was reached 
                                rowsSkipped++;
                            }
                        }
                        reader.Close();
                    }
                    // now do outline-dims if no rows were found 
                    if (a.Count == 0) {
                        sqlText = string.Format(
@"select s.line_nbr, s.reporting_line, s.kpi, s.views, s.scenario, s.service_type
    , s.function, s.cost_center, s.entity, s.equipment, s.tech_type, s.methodology_type
    , s.sale_type, s.discount_type, s.contract_term, s.date_created, s.source, rl.member_name as RptLne
    , kp.member_name as RptKPI, vi.member_name as RptView, sc.member_name as RptScenario
    , st.member_name as RptServiceType, fc.member_name as RptSalesCannel
    , cc.member_name as RptCostCenter, en.member_name as RptEntity
    , eq.member_name as RptEquipment, tt.member_name as RptTechType
    , mt.member_name as RptMethodType, sa.member_name as RptSaleType
    , dt.member_name as RptDiscType, ct.member_name as RptContractTerm
  from {0} s
    left outer join v_equipment_dimensions rl on rl.member_name=s.reporting_line and rl.storage_value = 'Store data' and rl.dimension_name='ReportingLine' and rl.level_number=0  
    left outer join v_equipment_dimensions kp on kp.member_name=s.kpi and kp.storage_value = 'Store data' and  kp.dimension_name='KPI' and kp.level_number=0  
    left outer join v_equipment_dimensions vi on vi.member_name=s.views and vi.storage_value = 'Store data' and vi.dimension_name='View' and vi.level_number=0    
    left outer join v_equipment_dimensions sc on sc.member_name=s.scenario and sc.storage_value = 'Store data' and  sc.dimension_name='Scenario' and sc.level_number=0  
    left outer join v_equipment_dimensions st on st.member_name=s.service_type and st.storage_value = 'Store data' and  st.dimension_name='ServiceType' and st.level_number=0  
    left outer join v_equipment_dimensions fc on fc.member_name=s.Function and fc.storage_value = 'Store data' and fc.dimension_name='Function' and fc.level_number=0  
    left outer join v_equipment_dimensions cc on cc.member_name=s.cost_center  and cc.storage_value = 'Store data' and  cc.dimension_name='CostCenter' and cc.level_number=0 
    left outer join v_equipment_dimensions en on en.member_name=s.entity and en.storage_value = 'Store data' and  en.dimension_name='Entities' and en.level_number=0  
    left outer join v_equipment_dimensions eq on eq.member_name=s.equipment and eq.storage_value = 'Store data' and eq.dimension_name='Equipment' and eq.level_number=0 
    left outer join v_equipment_dimensions tt on tt.member_name=s.tech_type and tt.storage_value = 'Store data' and tt.dimension_name='TechType' and tt.level_number=0 
    left outer join v_equipment_dimensions mt on mt.member_name=s.methodology_type and mt.storage_value = 'Store data' and mt.dimension_name='MethodologyType' and mt.level_number=0  
    left outer join v_equipment_dimensions sa on sa.member_name=s.sale_type and sa.storage_value = 'Store data' and sa.dimension_name='SaleType' and sa.level_number=0  
    left outer join v_equipment_dimensions dt on dt.member_name=s.discount_type and dt.storage_value = 'Store data' and  dt.dimension_name='DiscountType' and dt.level_number=0  
    left outer join v_equipment_dimensions ct on ct.member_name=s.contract_term and ct.storage_value = 'Store data' and  ct.dimension_name='ContractTerm' and ct.level_number=0  
  where s.date_created =to_date('{1}', 'yyyy/mm/dd HH24.MI.SS') and s.source='{2}' 
    and ( 
      rl.member_name is null or kp.member_name is null or vi.member_name is null 
      or sc.member_name is null or st.member_name is null or fc.member_name is null 
      or cc.member_name is null or en.member_name is null or eq.member_name is null 
      or tt.member_name is null or mt.member_name is null or sa.member_name is null 
      or dt.member_name is null or ct.member_name is null 
    )
  order by line_nbr"
                            , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                            , now.ToString("yyyy/MM/dd HH:mm:ss"), fileType.FileTypeCode
                        );

                        command.CommandText = sqlText;
                        using (OracleDataReader reader = command.ExecuteReader()) {
                            reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                            while (reader.Read()) {
                                if (rowCount < maxRows) {
                                    int i = 0;
                                    FactValidDTO f = new FactValidDTO();
                                    if (!reader.IsDBNull(i)) f.Line = reader.GetDecimal(i);
                                    if (!reader.IsDBNull(++i)) f.ReportingLine = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.CostCenter = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.MethodType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.SaleType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.DiscountType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ContractTerm = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.CreateModifyDate = reader.GetDateTime(i);
                                    if (!reader.IsDBNull(++i)) f.Source = reader.GetString(i);

                                    // validation table
                                    if (!reader.IsDBNull(++i)) f.ReportLineValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.KPIValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ViewValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ScenarioValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ServiceValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.FunctionValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.CostCenterValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.EntityValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.EquipmentValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.TechTypeValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.MethodTypeValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.SaleTypeValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.DiscountTypeValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ContractTermValid = reader.GetString(i);
                                    a.Add(f);
                                    rowCount++;
                                } else {
                                    // max row was reached 
                                    rowsSkipped++;
                                }
                            }
                            reader.Close();
                        }
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        public static ArrayList ValidateDataWarehouseKeyCombinations(FileType fileType, DateTime now, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                // first, look for rows already in valid key table
                sqlText = string.Format(
@"select s.line_nbr, s.customer_account, s.branch, s.connection_type, s.equipment, s.previous_type, s.function, s.kpi, s.entity
    , s.owning_geography, s.owning_manager, s.product, s.reporting_line, s.scenario, s.segment, s.service_type, s.subaccount
    , s.tech_type, s.version, s.vertical, s.views, s.contract_term, s.program_eligibility, s.source, v.source 
  from {0} s left outer join {1} v on  s.customer_account=v.customer_account and s.branch=v.branch and s.connection_type = v.connection_type 
    and s.equipment=v.equipment and s.previous_type=v.previous_type and s.function=v.function and s.kpi=v.kpi and s.entity=v.entity
    and s.owning_geography=v.owning_geography and s.owning_manager=v.owning_manager and s.product=v.product and s.reporting_line=v.reporting_line 
    and s.scenario=v.scenario and s.segment=v.segment and s.service_type=v.service_type and s.subaccount=v.subaccount and s.tech_type=v.tech_type 
    and s.version=v.version and s.vertical=v.vertical and s.views=v.views and s.contract_term=v.contract_term 
    and s.program_eligibility = v.program_eligibility
  where s.date_created =to_date('{2}', 'yyyy/mm/dd HH24.MI.SS') and s.source='{3}' and v.source <>'{3}'
  order by line_nbr"
                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                    , fileType.ValidationKeyTable, now.ToString("yyyy/MM/dd HH:mm:ss"), fileType.FileTypeCode
                );

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        while (reader.Read()) {
                            if (rowCount < maxRows) {
                                int i = 0;
                                FactValidDTO f = new FactValidDTO();
                                if (!reader.IsDBNull(i)) f.Line = reader.GetDecimal(i);
                                if (!reader.IsDBNull(++i)) f.Account = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.Branch = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.ConnectionType = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.PreviousType = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.OwningGeo = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.OwningMgr = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.Product = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.ReportingLine = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.Segment = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.SubAccount = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.Version = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.Vertical = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.ContractTerm = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.ProgramEligible = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.Source = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.SourceValid = reader.GetString(i);
                                a.Add(f);
                                rowCount++;
                            } else {
                                // max row was reached 
                                rowsSkipped++;
                            }
                        }
                        reader.Close();
                    }
                    // now do outline-dims if no rows were found 
                    if (a.Count == 0) {
                        sqlText = string.Format(
@"select s.line_nbr,  s.customer_account, s.branch, s.connection_type, s.equipment, s.previous_type, s.function, s.kpi, s.entity
    , s.owning_geography, s.owning_manager, s.product, s.reporting_line, s.scenario, s.segment, s.service_type, s.subaccount, s.tech_type
    , s.version, s.vertical, s.views, s.contract_term, s.program_eligibility, '' as  source,  

    ac.member_name as rptaccount, br.member_name as rptbranch, ct.member_name as rptconntype
    , eq.member_name as rptequipment,  pt.member_name as rptprevtype,  fc.member_name as rptfunction, kp.member_name as rptkpi
    , en.member_name as rptentity, og.member_name as rptowninggeo, om.member_name as rptowninggeo, pr.member_name as rptproduct
    , rl.member_name as rptreportingline, sc.member_name as rptscenario, sg.member_name as rptsegment, st.member_name as rptservicetype
    , sa.member_name as rptsubaccount, tt.member_name as rpttechtype,  vr.member_name as rptversion, vc.member_name as rptvertical
    , vi.member_name as rptview, ctt.member_name otl_contract_term, pe.member_name otl_program_eligibility   
  from {0} s
    left outer join V_DW_DIMENSIONS ac on ac.Member_Name=S.customer_account and ac.storage_value = 'Store data' and ac.DIMENSION_NAME='CustomerAccount' and ac.Level_Number=0    
    left outer join V_DW_DIMENSIONS br on br.Member_Name=S.branch and br.storage_value = 'Store data' and br.DIMENSION_NAME='Branch' and br.Level_Number=0  
    left outer join V_DW_DIMENSIONS ct on ct.Member_Name=S.Connection_Type and ct.storage_value = 'Store data' and ct.DIMENSION_NAME='ConnectionType' and ct.Level_Number=0  
    left outer join V_DW_DIMENSIONS eq on eq.Member_Name=S.equipment and eq.storage_value = 'Store data' and eq.DIMENSION_NAME='Equipment' and eq.Level_Number=0 
    left outer join V_DW_DIMENSIONS pt on pt.Member_Name=S.previous_type and pt.storage_value = 'Store data' and pt.DIMENSION_NAME='PrevType' and pt.Level_Number=0 
    left outer join V_DW_DIMENSIONS fc on fc.Member_Name=S.Function and fc.storage_value = 'Store data' and  fc.DIMENSION_NAME='Function' and fc.Level_Number=0  
    left outer join V_DW_DIMENSIONS kp on kp.Member_Name=S.kpi and kp.storage_value = 'Store data' and  kp.DIMENSION_NAME='KPI' and kp.Level_Number=0  
    left outer join V_DW_DIMENSIONS en on en.Member_Name=S.entity and en.storage_value = 'Store data' and  en.DIMENSION_NAME='Entities' and en.Level_Number=0  
    left outer join V_DW_DIMENSIONS og on og.Member_Name=S.owning_geography and og.storage_value = 'Store data' and  og.DIMENSION_NAME='OwningGeo' and og.Level_Number=0  
    left outer join V_DW_DIMENSIONS om on om.Member_Name=S.owning_manager and om.storage_value = 'Store data' and  om.DIMENSION_NAME='OwningMgr' and om.Level_Number=0  
    left outer join V_DW_DIMENSIONS pr on pr.Member_Name=S.product and pr.storage_value = 'Store data' and  pr.DIMENSION_NAME='Product' and pr.Level_Number=0  
    left outer join V_DW_DIMENSIONS rl on rl.Member_Name=S.reporting_line and rl.storage_value = 'Store data' and rl.DIMENSION_NAME='ReportingLine' and rl.Level_Number=0  
    left outer join V_DW_DIMENSIONS sc on sc.Member_Name=S.scenario and sc.storage_value = 'Store data' and  sc.DIMENSION_NAME='Scenario' and sc.Level_Number=0  
    left outer join V_DW_DIMENSIONS sg on sg.Member_Name=S.segment and sg.storage_value = 'Store data' and  sg.DIMENSION_NAME='Segment' and sg.Level_Number=0  
    left outer join V_DW_DIMENSIONS st on st.Member_Name=S.service_type and st.storage_value = 'Store data' and  st.DIMENSION_NAME='ServiceType' and st.Level_Number=0  
    left outer join V_DW_DIMENSIONS sa on sa.Member_Name=S.subaccount and sa.storage_value = 'Store data' and  sa.DIMENSION_NAME='SubAccount' and sa.Level_Number=0  
    left outer join V_DW_DIMENSIONS tt on tt.Member_Name=S.tech_type and tt.storage_value = 'Store data' and tt.DIMENSION_NAME='TechType' and tt.Level_Number=0 
    left outer join V_DW_DIMENSIONS vr on vr.Member_Name=S.Version   and vr.storage_value = 'Store data' and vr.DIMENSION_NAME='Version' and vr.Level_Number=0    
    left outer join V_DW_DIMENSIONS vc on vc.Member_Name=S.vertical and vc.storage_value = 'Store data' and vc.DIMENSION_NAME='Vertical' and vc.Level_Number=0    
    left outer join V_DW_DIMENSIONS vi on vi.Member_Name=S.views and vi.storage_value = 'Store data' and vi.DIMENSION_NAME='View' and vi.Level_Number=0    
    left outer join V_DW_DIMENSIONS ctt on ctt.Member_Name=S.contract_term and ctt.storage_value = 'Store data' and ctt.DIMENSION_NAME='ContractTerm' and ctt.Level_Number=0    
    left outer join V_DW_DIMENSIONS pe on pe.Member_Name=S.program_eligibility and pe.storage_value = 'Store data' and pe.DIMENSION_NAME='ProgramEligible' and pe.Level_Number=0    
  where  S.SOURCE='{1}' and S.date_created =to_date('{2}', 'yyyy/mm/dd HH24.MI.SS') and  ( 
    br.member_name is null or ct.member_name is null or eq.member_name is null or pt.member_name is null or fc.member_name is null or kp.member_name is null 
    or en.member_name is null or og.member_name is null or om.member_name is null or pr.member_name is null or rl.member_name is null 
    or sc.member_name is null or sg.member_name is null or st.member_name is null or sa.member_name is null or tt.member_name is null 
    or vr.member_name is null or vc.member_name is null or ac.member_name is null or vi.member_name is null or ctt.member_name is null
    or pe.member_name is null   
  )
  order by line_nbr"
                            , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                            , fileType.FileTypeCode, now.ToString("yyyy/MM/dd HH:mm:ss")
                        );
                        
                        command.CommandText = sqlText;
                        using (OracleDataReader reader = command.ExecuteReader()) {
                            reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                            while (reader.Read()) {
                                if (rowCount < maxRows) {
                                    int i = 0;
                                    FactValidDTO f = new FactValidDTO();
                                    if (!reader.IsDBNull(i)) f.Line = reader.GetDecimal(i);
                                    if (!reader.IsDBNull(++i)) f.Account = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Branch = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ConnectionType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.PreviousType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.OwningGeo = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.OwningMgr = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Product = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ReportingLine = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Segment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.SubAccount = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Version = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Vertical = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ContractTerm = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ProgramEligible = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Source = reader.GetString(i);

                                    // validation table
                                    if (!reader.IsDBNull(++i)) f.AccountValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.BranchValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ConnTypeValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.EquipmentValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.PreviousTypeValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.FunctionValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.KPIValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.EntityValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.OwningGeoValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.OwningMgrValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ProductValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ReportLineValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ScenarioValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.SegmentValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ServiceValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.SubAcctValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.TechTypeValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.VersionValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.VerticalValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ViewValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ContractTermValid = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ProgramEligibleValid = reader.GetString(i);
    
                                    a.Add(f);
                                    rowCount++;
                                } else {
                                    // max row was reached 
                                    rowsSkipped++;
                                }
                            }
                            reader.Close();
                        }
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        /// <summary>
        /// This version is specific to RPTG because source/
        /// </summary>
        public static bool AddRptUserInputKeys(FileType hft, string Owner, string dateAdded, string Requestor, out int Cnt)
        {
            OracleConnection oraConn = new OracleConnection(DbAccess.GetOracleConnectionString());
            //  OracleCommand sqlCmd = null;
            BasicOraCommand sqlCmd = new BasicOraCommand(DbAccess.GetOracleConnectionString());
            Cnt = 0;
            string Cmd = "";
            bool bRet = true;
            DateTime dtNow = DateTime.Now;
            string commandText = string.Empty;
            try
            {
                oraConn.Open();
                //  sqlCmd = new OracleCommand(Cmd, oraConn);
                Cmd = string.Format("insert into {0} (PRP_RPT_SOURCE,PRP_RPT_OWNER,PRP_RPT_CREATEMODIFYDATE",
                  hft.ValidationKeyTable);

                string Vals = ") select s.PRP_RPT_SOURCE,s.PRP_RPT_OWNER,s.PRP_RPT_CREATEMODIFYDATE";


                for (int i = 0; i < DbAccess.reportingFieldNames.Length - 3; i++)
                {
                    if (hft.Is13Month)
                    {
                        Cmd += ", " + outlookFieldNames[i];
                        Vals += ", s." + outlookFieldNames[i];
                    }
                    else
                    {
                        Cmd += ", " + reportingFieldNames[i];
                        Vals += ", s." + reportingFieldNames[i];
                    }
                }

                commandText = string.Format(@"{0} {1} from {2} s 
                    left outer join {3} f on s.dim_rpt_reportngline=f.dim_rpt_reportngline and 
                        s.dim_rpt_account=f.dim_rpt_account and
                        s.dim_rpt_kpi=f.dim_rpt_kpi and
                        s.dim_rpt_view=f.dim_rpt_view and
                        s.dim_rpt_scenario=f.dim_rpt_scenario and
                        s.dim_rpt_product=f.dim_rpt_product and
                        s.dim_rpt_subaccount=f.dim_rpt_subaccount and
                        s.dim_rpt_servicetype=f.dim_rpt_servicetype and
                        s.dim_rpt_function=f.dim_rpt_function and
                        s.dim_rpt_costcenter=f.dim_rpt_costcenter and
                        s.dim_rpt_entity=f.dim_rpt_entity and
                        s.dim_rpt_company=f.dim_rpt_company and 
                        s.dim_rpt_equipment=f.dim_rpt_equipment and 
                        s.dim_rpt_TechType=f.dim_rpt_TechType
                    where s.PRP_RPT_SOURCE='{4}' 
                        and f.PRP_RPT_SOURCE is null 
                        and s.PRP_RPT_CREATEMODIFYDATE=to_date('{5}', 'yyyy/mm/dd HH24.MI.SS') ",
                    Cmd,
                    Vals,
                    hft.Is13Month ? hft.StageYearTable : hft.StageMonthTable,
                    hft.ValidationKeyTable,
                    hft.FileTypeCode,
                    dateAdded
                    );
                //sqlCmd.CommandText = commandText;

                Cnt = sqlCmd.Exec(commandText);
                if (Cnt < 1)
                {
                    throw new Exception(sqlCmd.LastErrorMessage);
                }
                bRet = true;
            }
            catch (Exception ex)
            {
                //  Log the error to a table.
                GeneralDatabaseAccess.LogEvent(Requestor, "AddRptUserInputKeys", commandText, ex, UserToolLogLevel.Error);
            }
            finally
            {
                if (oraConn != null)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                }
            }
            return bRet;
        }

        public static bool AddLocUserInputKeys(FileType hft, string Owner, string dateAdded, string Requestor, out int Cnt)
        {
            OracleConnection oraConn = new OracleConnection(DbAccess.GetOracleConnectionString());
            //  OracleCommand sqlCmd = null;
            BasicOraCommand sqlCmd = new BasicOraCommand(DbAccess.GetOracleConnectionString());
            Cnt = 0;
            string Cmd = "";
            bool bRet = false;
            DateTime dtNow = DateTime.Now;
            string commandText = string.Empty;
            try
            {
                oraConn.Open();
                //  sqlCmd = new OracleCommand(Cmd, oraConn);
                Cmd = string.Format("insert into {0} (SOURCE,OWNER,DATE_CREATED",
                  hft.ValidationKeyTable);

                string Vals = ") select s.SOURCE,s.OWNER,s.DATE_CREATED";


                for (int i = 0; i < locationFieldNames.Length - 3; i++)
                {
                    Cmd += ", " + locationFieldNames[i];
                    Vals += ", s." + locationFieldNames[i];
                }

                commandText = string.Format(@"{0} {1} from {2} s 
                    left outer join {3} f on s.reporting_line=f.reporting_line and 
                        s.account=f.account and
                        s.kpi=f.kpi and
                        s.views=f.views and
                        s.scenario=f.scenario and
                        s.product=f.product and
                        s.subaccount=f.subaccount and
                        s.service_type=f.service_type and
                        s.function=f.function and
                        s.cost_center=f.cost_center and
                        s.location=f.location and
                        s.equipment=f.equipment and 
                        s.Tech_Type=f.Tech_Type and 
                        s.store_status=f.store_status and 
                        s.design_type=f.design_type and 
                        s.location_Type=f.location_Type and 
                        s.location_subType=f.location_subType and 
                        s.location_tier_code=f.location_tier_code
                    where s.SOURCE='{4}' 
                        and f.SOURCE is null 
                        and s.date_created=to_date('{5}', 'yyyy/mm/dd HH24.MI.SS') ",
                        Cmd,
                        Vals,
                         hft.Is13Month ? hft.StageYearTable : hft.StageMonthTable,
                        hft.ValidationKeyTable,
                        hft.FileTypeCode,
                        dateAdded);
                //sqlCmd.CommandText = commandText;

                Cnt = sqlCmd.Exec(commandText);
                if (Cnt < 1)
                {
                    throw new Exception(sqlCmd.LastErrorMessage);
                }
                bRet = true;
            }
            catch (Exception ex)
            {
                //  Log the error to a table.
                GeneralDatabaseAccess.LogEvent(Requestor, "AddLocUserInputKeys", commandText, ex, UserToolLogLevel.Error);
            }
            finally
            {
                if (oraConn != null)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                }
            }
            return bRet;
        }

        /// <summary>
        /// add keys to validation table, called for both equipment and datawarehouse
        /// </summary>
        /// <param name="fileType"></param>
        /// <param name="owner"></param>
        /// <param name="dateAdded"></param>
        /// <param name="requestor"></param>
        /// <param name="recordsUpdated"></param>
        /// <returns></returns>
        public static bool AddUserInputKeys(FileType fileType, string owner, string dateAdded, string requestor, out int recordsUpdated) {
            string sqlText = string.Empty;
            string[] fieldNames = null;
            bool returnValue = false;
            recordsUpdated = 0;

            switch ((FactTable)fileType.FactTableId) {
                case FactTable.EquipmentUser: fieldNames = equipmentFieldNames; break;
                case FactTable.DataWarehouseUser: fieldNames = dataWarehouseFieldNames; break;
            }

            try {
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = connection.CreateCommand()) {
                    connection.Open();

                    sqlText = string.Format("insert into {0} (source,owner,date_created", fileType.ValidationKeyTable);

                    string selectColumnList = ") select s.source,s.owner,s.date_created";
                    string joinSqlText = string.Empty;
                    for (int i = 0; i < fieldNames.Length; i++) {
                        if (fieldNames[i] != "FACT_DATE" && fieldNames[i] != "AMOUNT" && fieldNames[i] != "TIME" && fieldNames[i] != "YEAR") {
                            sqlText += ", " + fieldNames[i];
                            selectColumnList += ", s." + fieldNames[i];
                            joinSqlText += string.Format(" s.{0}= f.{0} and", fieldNames[i]);
                        }
                    }
                    command.CommandText = string.Format(@"{0} {1} from {2} s left outer join {3} f on {4}  
                        where s.source='{5}' and f.source is null and s.date_created=to_date('{6}', 'yyyy/mm/dd HH24.MI.SS') "
                        , sqlText, selectColumnList,
                        fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                        , fileType.ValidationKeyTable, joinSqlText.Remove(joinSqlText.Length - 3), fileType.FileTypeCode, dateAdded);
                    recordsUpdated = command.ExecuteNonQuery();
                    returnValue = true;
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(requestor, MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
            }
            
            return returnValue;
        }

        public static ArrayList GetCurrentReportingKeys(FileType fileType, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                sqlText = string.Format(
@"select s.rowid, s.dim_rpt_reportngline,s.dim_rpt_account,s.dim_rpt_kpi, s.dim_rpt_view,s.dim_rpt_scenario
    , s.dim_rpt_product,s.dim_rpt_subaccount, s.dim_rpt_servicetype,s.dim_rpt_function,s.dim_rpt_costcenter
    , s.dim_rpt_entity,s.dim_rpt_company, s.dim_rpt_equipment, s.dim_rpt_techtype
  from {0} s
  where s.prp_rpt_source='{1}'
  order by s.dim_rpt_reportngline, s.dim_rpt_account, s.dim_rpt_kpi, s.dim_rpt_view, s.dim_rpt_scenario
    , s.dim_rpt_product, s.dim_rpt_subaccount, s.dim_rpt_servicetype, s.dim_rpt_function, s.dim_rpt_costcenter
    , s.dim_rpt_entity, s.dim_rpt_equipment, s.dim_rpt_techtype"
                    , fileType.ValidationKeyTable, fileType.FileTypeCode);
                    
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        while (reader.Read()) {
                            if (rowCount < maxRows) {
                                int i = 0;
                                FactValidDTO f = new FactValidDTO();
                                f.ROWID = reader.GetString(i);
                                f.ReportingLine = reader.GetString(++i);
                                f.Account = reader.GetString(++i);
                                f.KPI = reader.GetString(++i);
                                f.View = reader.GetString(++i);
                                f.Scenario = reader.GetString(++i);
                                f.Product = reader.GetString(++i);
                                f.SubAccount = reader.GetString(++i);
                                f.ServiceType = reader.GetString(++i);
                                f.Function = reader.GetString(++i);
                                f.CostCenter = reader.GetString(++i);
                                f.Entity = reader.GetString(++i);
                                f.Company = reader.GetString(++i);
                                f.Equipment = reader.GetString(++i);
                                f.TechType = reader.GetString(++i);
                                a.Add(f);
                                rowCount++;
                            } else {
                                // max row was reached 
                                rowsSkipped++;
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        public static ArrayList GetCurrentLocationKeys(FileType fileType, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                sqlText = string.Format(
@"select s.rowid, s.reporting_line, s.account, s.kpi, s.views, s.scenario, s.product, s.subaccount, s.service_type
    , s.function, s.cost_center, s.location, s.equipment, s.tech_type, s.store_status, s.design_type, s.location_type
    , s.location_subtype, s.location_tier_code 
  from {0} s
  where s.source='{1}'
  order by s.reporting_line, s.account, s.kpi, s.views, s.scenario, s.product, s.subaccount, s.service_type
    , s.function, s.cost_center, s.location, s.equipment, s.tech_type, s.store_status, s.design_type, s.location_type
    , s.location_subtype, s.location_tier_code "
                    , fileType.ValidationKeyTable, fileType.FileTypeCode);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        while (reader.Read()) {
                            if (rowCount < maxRows) {
                                int i = 0;
                                FactValidDTO f = new FactValidDTO();
                                f.ROWID = reader.GetString(i);
                                f.ReportingLine = reader.GetString(++i);
                                f.Account = reader.GetString(++i);
                                f.KPI = reader.GetString(++i);
                                f.View = reader.GetString(++i);
                                f.Scenario = reader.GetString(++i);
                                f.Product = reader.GetString(++i);
                                f.SubAccount = reader.GetString(++i);
                                f.ServiceType = reader.GetString(++i);
                                f.Function = reader.GetString(++i);
                                f.CostCenter = reader.GetString(++i);
                                f.Entity = reader.GetString(++i);
                                f.Equipment = reader.GetString(++i);
                                f.TechType = reader.GetString(++i);
                                f.StoreStatus = reader.GetString(++i);
                                f.DesignType = reader.GetString(++i);
                                f.LocationType = reader.GetString(++i);
                                f.LocationSubtype = reader.GetString(++i);
                                f.LocationTierCode = reader.GetString(++i);
                                a.Add(f);
                                rowCount++;
                            } else {
                                // max row was reached 
                                rowsSkipped++;
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        public static ArrayList GetCurrentEquipmentKeys(FileType fileType, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                sqlText = string.Format(
@"select s.rowid, s.reporting_line, s.kpi, s.views, s.scenario, s.service_type, s.function
    , s.cost_center, s.entity, s.equipment, s.tech_type, s.methodology_type, s.sale_type
    , s.discount_type, s.contract_term  
  from {0} s
  where s.source='{1}'
  order by s.reporting_line, s.kpi, s.views, s.scenario, s.service_type, s.function
     , s.cost_center, s.entity, s.equipment, s.tech_type, s.methodology_type
     , s.sale_type, s.discount_type, s.contract_term",
                  fileType.ValidationKeyTable,
                  fileType.FileTypeCode); 

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        while (reader.Read()) {
                            if (rowCount < maxRows) {
                                int i = 0;
                                FactValidDTO f = new FactValidDTO();                                
                                f.ROWID = reader.GetString(i);
                                f.ReportingLine = reader.GetString(++i);
                                f.KPI = reader.GetString(++i);
                                f.View = reader.GetString(++i);
                                f.Scenario = reader.GetString(++i);
                                f.ServiceType = reader.GetString(++i);
                                f.Function = reader.GetString(++i);
                                f.CostCenter = reader.GetString(++i);
                                f.Entity = reader.GetString(++i);
                                f.Equipment = reader.GetString(++i);
                                f.TechType = reader.GetString(++i);
                                f.MethodType = reader.GetString(++i);
                                f.SaleType = reader.GetString(++i);
                                f.DiscountType = reader.GetString(++i);
                                if (!reader.IsDBNull(++i)) f.ContractTerm = reader.GetString(i);
                                a.Add(f);
                                rowCount++;
                            } else {
                                // max row was reached 
                                rowsSkipped++;
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        public static ArrayList GetCurrentDataWarehouseKeys(FileType fileType, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                sqlText = string.Format(
@"select s.rowid, s.customer_account, s.branch, s.connection_type, s.equipment, s.previous_type, s.function, s.kpi
    , s.entity, s.owning_geography, s.owning_manager, s.product, s.reporting_line, s.scenario, s.segment
    , s.service_type, s.subaccount, s.tech_type, s.version, s.vertical, s.views, s.contract_term, s.program_eligibility	 
  from {0} s
  where s.source='{1}'
  order by s.reporting_line, s.kpi, s.views, s.scenario, s.service_type "
                    , fileType.ValidationKeyTable, fileType.FileTypeCode);
                    
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        while (reader.Read()) {
                            if (rowCount < maxRows) {
                                int i = 0;
                                FactValidDTO f = new FactValidDTO();
                                f.ROWID = reader.GetString(i);
                                f.Account = reader.GetString(++i);
                                f.Branch = reader.GetString(++i);
                                f.ConnectionType = reader.GetString(++i);
                                f.Equipment = reader.GetString(++i);
                                f.PreviousType = reader.GetString(++i);
                                f.Function = reader.GetString(++i);
                                f.KPI = reader.GetString(++i);
                                f.Entity = reader.GetString(++i);
                                f.OwningGeo = reader.GetString(++i);
                                f.OwningMgr = reader.GetString(++i);
                                f.Product = reader.GetString(++i);
                                f.ReportingLine = reader.GetString(++i);
                                f.Scenario = reader.GetString(++i);
                                f.Segment = reader.GetString(++i);
                                f.ServiceType = reader.GetString(++i);
                                f.SubAccount = reader.GetString(++i);
                                f.TechType = reader.GetString(++i);
                                f.Version = reader.GetString(++i);
                                f.Vertical = reader.GetString(++i);
                                f.View = reader.GetString(++i);
                                if (!reader.IsDBNull(++i)) f.ContractTerm = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.ProgramEligible = reader.GetString(i);
                                a.Add(f);
                                rowCount++;
                            } else {
                                // max row was reached 
                                rowsSkipped++;
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        /// <summary>
        /// Move a key combination based on rowid - replaces array of keys parameter 
        /// </summary>
        /// <param name="fileType"></param>
        /// <param name="RowID"></param>
        /// <param name="requestor"></param>
        /// <param name="totalFactsMoved"></param>
        /// <param name="totalKeysMoved"></param>
        /// <returns>true if successful</returns>
        /// jevans 6/18/2012 refactored to accept a string of rowids instead of an array
        //TODO:possible CLOB bug
        public static bool MoveKeyCombos(FileType fileType, string rowIds, string originalFileType, string requestor, out int totalFactsMoved, out int totalKeysMoved) {
            bool returnValue = false;
            string sqlText = string.Empty;
            string[] fieldNames;
            totalFactsMoved = 0;
            totalKeysMoved = 0;

            switch ((FactTable)fileType.FactTableId) {
                case FactTable.LocationUser: fieldNames = locationFieldNames; break;
                case FactTable.EquipmentUser: fieldNames = equipmentFieldNames; break;
                case FactTable.DataWarehouseUser: fieldNames = dataWarehouseFieldNames; break;
                default: fieldNames = reportingFieldNames; break;
            }
            
            try {
                string joinSqlText = "f.rowid is not null and ";
                foreach (string fieldName in fieldNames) {
                    // skip fact and date columns
                    if (fieldName.Length == 0 || fieldName.Contains("AMOUNT") || fieldName.Contains("FACT")
                        || fieldName.Contains("MEASURE") || fieldName.Contains("YEAR") || fieldName.Contains("TIME"))
                        continue;
                    joinSqlText += string.Format(" f.{0}(+)=v.{0} and ", fieldName);
                }

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = connection.CreateCommand()) {
                    connection.Open();
                    using (OracleTransaction transaction = connection.BeginTransaction()) {
                        sqlText = string.Format(
@" update {0} f 
   set f.{1} = :val 
   where f.{1} = :val 
     and rowid in (
       select /*+ parallel(f 4) */ f.rowid 
       from {0} f, {2} v
       where {3} rowidtochar(v.rowid) in (
         select column_value from table(split_clob(:val))
       )
     )"
                            , fileType.DestinationTable, fileType.SourceColumnName, fileType.ValidationKeyTable, joinSqlText);
                        command.CommandText = sqlText;
                        command.Parameters.Add(new OracleParameter("@source", OracleDbType.Varchar2, 80, fileType.FileTypeCode, ParameterDirection.Input));
                        command.Parameters.Add(new OracleParameter("@filetype", OracleDbType.Varchar2, 80, originalFileType, ParameterDirection.Input));
                        command.Parameters.Add(new OracleParameter("@rowid", OracleDbType.Clob, rowIds, ParameterDirection.Input));
                        totalFactsMoved = command.ExecuteNonQuery();

                        // update validation table 
                        if (fileType.UsesValidKeyCombos) {
                            sqlText = string.Format(
    @" update {0} 
   set {1}=:val 
   where rowidtochar(rowid) in (
     select column_value from table(split_clob(:val))
   ) "
                                , fileType.ValidationKeyTable, fileType.SourceColumnName);
                            command.Parameters.Clear();
                            command.CommandText = sqlText;
                            command.Parameters.Add(new OracleParameter("@source", OracleDbType.Varchar2, 80, fileType.FileTypeCode, ParameterDirection.Input));
                            command.Parameters.Add(new OracleParameter("@rowid", OracleDbType.Clob, rowIds, ParameterDirection.Input));
                            totalKeysMoved = command.ExecuteNonQuery();
                        } // end of if valid-keys

                        transaction.Commit();
                    }
                    
                    returnValue = true;
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(requestor, MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                totalKeysMoved = -1;
                totalFactsMoved = -1;
                returnValue = false;
            }
            return returnValue;
        }

        // jevans 7/20/2011 - override to move all keys for a given type
        public static bool MoveAllKeyCombos(FileType SelType, string OrigFileType, string Requestor, out int iFactsMoved, out int iKeysMoved)
        {
            BasicOraCommand Wrtr = new BasicOraCommand(DbAccess.GetOracleConnectionString());
            string Msg = string.Empty;
            string Cmd = string.Empty;
            iFactsMoved = 0;
            iKeysMoved = 0;
            bool bResult = false;
            try
            {
                Cmd = string.Format("update {0} set {1}='{2}' where {1}='{3}'",
                    SelType.DestinationTable,
                    SelType.DestinationTable.ToUpper().StartsWith("RPT_") ? "prp_rpt_source" : "source",
                    SelType.FileTypeCode,
                    OrigFileType
                    );
                iFactsMoved = Wrtr.Exec(Cmd);
                if (iFactsMoved < 0)
                    throw new Exception(Wrtr.LastErrorMessage);
                if (SelType.UsesValidKeyCombos)
                {
                    Cmd = string.Format("update {0} set {1}='{2}' where {1}='{3}'",
                        SelType.ValidationKeyTable,
                        SelType.DestinationTable.ToUpper().StartsWith("RPT_") ? "prp_rpt_source" : "source",
                        SelType.FileTypeCode,
                        OrigFileType
                        );
                    // Wrtr.Open();
                    iKeysMoved = Wrtr.ExecOpened(Cmd);
                    if (iKeysMoved < 0)
                        throw new Exception(Wrtr.LastErrorMessage);
                }
                bResult = true;
            }
            catch (Exception ex)
            {
                //  Log the error to a table.
                GeneralDatabaseAccess.LogEvent(Requestor, "MoveKeyCombos", Cmd, ex, UserToolLogLevel.Error);
                // jevans 7/20/2011 - return message empty, an error was logged
                Msg = string.Empty;
                //Msg = string.Format("An error occured Moving keys: {0}<BR>{0}<BR>", ex.Message, ex.StackTrace);
            }
            finally
            {
                if (Wrtr != null)
                {
                    Wrtr.Close();
                    Wrtr.Dispose();
                }
            }
            return bResult;
        }

        public static bool DelUserInputKey(FileType hft, string ValTable, ArrayList RowIDs, string Requestor, out int Cnt)
        {
            OracleConnection oraConn = new OracleConnection(DbAccess.GetOracleConnectionString());
            BasicOraCommand sqlCmd = new BasicOraCommand(DbAccess.GetOracleConnectionString());
            string Cmd = "";
            Cnt = 0;

            bool bRet = false;
            try
            {
                oraConn.Open();
                // jevans 4/4/2012 - now uses oracle parameter to increase efficiency
                OracleParameter[] parms = new OracleParameter[1];
                if (RowIDs == null)
                {
                    Cmd = string.Format(@"delete from {0} where {1}=:val",
                        hft.ValidationKeyTable, // ConfigurationManager.AppSettings["UserInputValidationTbl"],
                       hft.SourceColumnName
                        );
                    parms[0] = new OracleParameter("@source", OracleDbType.Varchar2, 80);
                    parms[0].Value = hft.FileTypeCode;
                    Cnt = sqlCmd.Exec(Cmd, parms);
                    if (Cnt > 0)
                        bRet = true;
                    else
                        throw new Exception("Delete ALL keys returned the following: " + sqlCmd.LastErrorMessage);
                }
                else
                {
                    Cmd = string.Format(@"delete from {0} where  RowIDToChar(ROWID) = :val ",
                        hft.ValidationKeyTable
                        );
                    parms[0] = new OracleParameter("@rowid", OracleDbType.Char, 18);
                    foreach (string key in RowIDs)
                    {
                        parms[0].Value = key;
                        Cnt += sqlCmd.ExecOpened(Cmd, parms);
                        if (Cnt > 0)
                            bRet = true;
                        else
                            throw new Exception(sqlCmd.LastErrorMessage);
                    }
                }
            }
            catch (Exception ex)
            {
                //  Log the error to a table.
                GeneralDatabaseAccess.LogEvent(Requestor, "DelUserInputKey", Cmd, ex, UserToolLogLevel.Error);
            }
            finally
            {
                if (oraConn != null)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                    sqlCmd.Dispose();
                }
            }

            return bRet;
        }

        public static ArrayList GetReportingKeysToBeAdded(FileType fileType, DateTime now, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                sqlText = string.Format(
@"select s.dim_rpt_reportngline, s.dim_rpt_account, s.dim_rpt_kpi, s.dim_rpt_view, s.dim_rpt_scenario, s.dim_rpt_product
    , s.dim_rpt_subaccount, s.dim_rpt_servicetype, s.dim_rpt_function, s.dim_rpt_costcenter, s.dim_rpt_entity
    , s.dim_rpt_company, s.dim_rpt_equipment, s.dim_rpt_techtype 
  from {0} s
    left outer join {3} f on s.dim_rpt_reportngline=f.dim_rpt_reportngline and s.dim_rpt_account=f.dim_rpt_account 
      and s.dim_rpt_kpi=f.dim_rpt_kpi and s.dim_rpt_view=f.dim_rpt_view and s.dim_rpt_scenario=f.dim_rpt_scenario 
      and s.dim_rpt_product=f.dim_rpt_product and s.dim_rpt_subaccount=f.dim_rpt_subaccount 
      and s.dim_rpt_servicetype=f.dim_rpt_servicetype and s.dim_rpt_function=f.dim_rpt_function 
      and s.dim_rpt_costcenter=f.dim_rpt_costcenter and s.dim_rpt_entity=f.dim_rpt_entity 
      and s.dim_rpt_company=f.dim_rpt_company and s.dim_rpt_equipment=f.dim_rpt_equipment 
      and s.dim_rpt_techtype=f.dim_rpt_techtype
  where s.prp_rpt_createmodifydate=to_date('{2}', 'yyyy/mm/dd HH24.MI.SS') and s.prp_rpt_source='{1}'
    and (f.prp_rpt_source is null)"
                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                    , fileType.FileTypeCode, now.ToString("yyyy/MM/dd HH:mm:ss"), fileType.ValidationKeyTable);
                    
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        while (reader.Read()) {
                            if (rowCount < maxRows) {
                                int i = 0;
                                FactValidDTO f = new FactValidDTO();
                                f.ReportingLine = reader.GetString(i);
                                f.Account = reader.GetString(++i);
                                f.KPI = reader.GetString(++i);
                                f.View = reader.GetString(++i);
                                f.Scenario = reader.GetString(++i);
                                f.Product = reader.GetString(++i);
                                f.SubAccount = reader.GetString(++i);
                                f.ServiceType = reader.GetString(++i);
                                f.Function = reader.GetString(++i);
                                f.CostCenter = reader.GetString(++i);
                                f.Entity = reader.GetString(++i);
                                f.Company = reader.GetString(++i);
                                f.Equipment = reader.GetString(++i);
                                f.TechType = reader.GetString(++i);
                                a.Add(f);
                                rowCount++;
                            } else {
                                // max row was reached 
                                rowsSkipped++;
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        public static ArrayList GetLocationKeysToBeAdded(FileType fileType, DateTime now, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                sqlText = string.Format(
@"select s.reporting_line, s.account, s.kpi, s.views,s.scenario, s.product, s.subaccount, s.service_type, s.function
    , s.cost_center, s.location, s.equipment, s.tech_type, s.store_status, s.design_type
    , s.location_type, s.location_subtype, s.location_tier_code  
  from {0} s left outer join {3} f on s.reporting_line=f.reporting_line and s.account=f.account and s.kpi=f.kpi
    and s.views=f.views and s.scenario=f.scenario and s.product=f.product and s.subaccount=f.subaccount 
    and s.service_type=f.service_type and s.function=f.function and s.cost_center=f.cost_center 
    and s.location =f.location and s.equipment=f.equipment and s.tech_type=f.tech_type 
    and s.store_status=f.store_status and s.design_type=f.design_type and s.location_type=f.location_type
    and s.location_subtype=f.location_subtype and s.location_tier_code=f.location_tier_code
  where s.date_created=to_date('{2}', 'yyyy/mm/dd HH24.MI.SS') and s.source='{1}' and (f.source is null)"
                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                    , fileType.FileTypeCode, now.ToString("yyyy/MM/dd HH:mm:ss"), fileType.ValidationKeyTable);
                    
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        while (reader.Read()) {
                            if (rowCount < maxRows) {
                                int i = 0;
                                FactValidDTO f = new FactValidDTO();
                                f.ReportingLine = reader.GetString(i);
                                f.Account = reader.GetString(++i);
                                f.KPI = reader.GetString(++i);
                                f.View = reader.GetString(++i);
                                f.Scenario = reader.GetString(++i);
                                f.Product = reader.GetString(++i);
                                f.SubAccount = reader.GetString(++i);
                                f.ServiceType = reader.GetString(++i);
                                f.Function = reader.GetString(++i);                            
                                f.CostCenter = reader.GetString(++i);
                                f.Entity = reader.GetString(++i);
                                f.Equipment = reader.GetString(++i);
                                f.TechType = reader.GetString(++i);
                                f.StoreStatus = reader.GetString(++i);
                                f.DesignType = reader.GetString(++i);
                                f.LocationType = reader.GetString(++i);
                                f.LocationSubtype = reader.GetString(++i);
                                f.LocationTierCode = reader.GetString(++i);
                                a.Add(f);
                                rowCount++;
                            } else {
                                // max row was reached 
                                rowsSkipped++;
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        public static ArrayList GetEquipmentKeysToBeAdded(FileType fileType, DateTime now, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                sqlText = string.Format(
@"select s.reporting_line, s.kpi, s.views, s.scenario, s.service_type, s.Function
    , s.cost_center, s.entity, s.equipment, s.tech_type, s.methodology_type
    , s.sale_type, s.discount_type, s.contract_term
  from {0} s left outer join {1} f 
    on s.reporting_line = f.reporting_line 
      and s.kpi = f.kpi and s.views = f.views and s.scenario = f.scenario 
      and s.service_type = f.service_type and s.Function = f.Function
      and s.cost_center = f.cost_center and s.entity = f.entity 
      and s.equipment = f.equipment and s.Tech_Type = f.Tech_Type 
      and s.methodology_type = f.methodology_type 
      and s.discount_type = f.discount_type and s.sale_Type = f.sale_Type 
      and s.contract_term = f.contract_term
  where s.date_created=to_date('{2}', 'yyyy/mm/dd HH24.MI.SS') 
    and s.SOURCE='{3}' and (f.SOURCE is null)",
                    fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable, fileType.ValidationKeyTable
                    , now.ToString("yyyy/MM/dd HH:mm:ss"), fileType.FileTypeCode);
                    
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        while (reader.Read()) {
                            if (rowCount < maxRows) {
                                int i = 0;
                                FactValidDTO f = new FactValidDTO();
                                f.ReportingLine = reader.GetString(i);
                                f.KPI = reader.GetString(++i);
                                f.View = reader.GetString(++i);
                                f.Scenario = reader.GetString(++i);
                                f.ServiceType = reader.GetString(++i);
                                f.Function = reader.GetString(++i);
                                f.CostCenter = reader.GetString(++i);
                                f.Entity = reader.GetString(++i);
                                f.Equipment = reader.GetString(++i);
                                f.TechType = reader.GetString(++i);
                                f.MethodType = reader.GetString(++i);
                                f.SaleType = reader.GetString(++i);
                                f.DiscountType = reader.GetString(++i);
                                if (!reader.IsDBNull(++i)) f.ContractTerm = reader.GetString(i);
                                a.Add(f);
                                rowCount++;
                            } else {
                                // max row was reached 
                                rowsSkipped++;
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        public static ArrayList GetDataWarehouseKeysToBeAdded(FileType fileType, DateTime now, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                sqlText = string.Format(
@"select s.rowid, s.customer_account, s.branch, s.connection_type, s.equipment, s.previous_type, s.function, s.kpi
    , s.entity, s.owning_geography, s.owning_manager, s.product, s.reporting_line, s.scenario, s.segment, s.service_type
    , s.subaccount, s.tech_type, s.version, s.vertical, s.views, s.contract_term, s.program_eligibility
  from {0} s left outer join {1} f on s.branch=f.branch and s.connection_type=f.connection_type 
    and s.equipment=f.equipment and s.previous_type=f.previous_type and s.function=f.function 
    and s.kpi=f.kpi and s.entity =f.entity and s.owning_geography=f.owning_geography 
    and s.owning_manager=f.owning_manager and s.product=f.product and s.reporting_line=f.reporting_line 
    and s.scenario=f.scenario and s.segment=f.segment and s.service_type=f.service_type 
    and s.subaccount=f.subaccount and s.tech_type=f.tech_type and s.version=f.version 
    and s.vertical = f.vertical and s.customer_account=f.customer_account and s.views=f.views
    and s.contract_term = f.contract_term and s.program_eligibility = f.program_eligibility 
  where s.date_created=to_date('{2}', 'yyyy/mm/dd HH24.MI.SS') and s.source='{3}' and f.source is null "
                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                    , fileType.ValidationKeyTable, now.ToString("yyyy/MM/dd HH:mm:ss"), fileType.FileTypeCode);
                
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        while (reader.Read()) {
                            if (rowCount < maxRows) {
                                int i = 0;
                                FactValidDTO f = new FactValidDTO();
                                f.ROWID = reader.GetString(i);
                                f.Account = reader.GetString(++i);
                                f.Branch = reader.GetString(++i);
                                f.ConnectionType = reader.GetString(++i);
                                f.Equipment = reader.GetString(++i);
                                f.PreviousType = reader.GetString(++i);
                                f.Function = reader.GetString(++i);
                                f.KPI = reader.GetString(++i);
                                f.Entity = reader.GetString(++i);
                                f.OwningGeo = reader.GetString(++i);
                                f.OwningMgr = reader.GetString(++i);
                                f.Product = reader.GetString(++i);
                                f.ReportingLine = reader.GetString(++i);
                                f.Scenario = reader.GetString(++i);
                                f.Segment = reader.GetString(++i);
                                f.ServiceType = reader.GetString(++i);
                                f.SubAccount = reader.GetString(++i);
                                f.TechType = reader.GetString(++i);
                                f.Version = reader.GetString(++i);
                                f.Vertical = reader.GetString(++i);
                                f.View = reader.GetString(++i);
                                if (!reader.IsDBNull(++i)) f.ContractTerm = reader.GetString(i);
                                if (!reader.IsDBNull(++i)) f.ProgramEligible = reader.GetString(i);
                                a.Add(f);
                                rowCount++;
                            } else {
                                // max row was reached 
                                rowsSkipped++;
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        public static int AddToReportingValidation(string lineNumbers, string fileType, string requestor, int runStatusId, string month
            , string years, bool canPostAdjustmentsToAnyPeriod, string validationTableName, string tempTableName, out string message) {

            string sqlText = string.Empty;
            int numberAdded = -1;
            message = string.Empty;

            try {
                sqlText = string.Format(
@"insert into {0} (
    dim_rpt_reportngline, dim_rpt_account, dim_rpt_kpi, dim_rpt_view, dim_rpt_scenario, dim_rpt_product
    , dim_rpt_subaccount, dim_rpt_servicetype, dim_rpt_function, dim_rpt_costcenter, dim_rpt_entity, dim_rpt_company
    , prp_rpt_source, prp_rpt_createmodifydate, prp_rpt_owner, dim_rpt_equipment, dim_rpt_techtype
  )  (
    select distinct dim_rpt_reportngline, dim_rpt_account, dim_rpt_kpi, dim_rpt_view, dim_rpt_scenario
      , dim_rpt_product, dim_rpt_subaccount, dim_rpt_servicetype, dim_rpt_function, dim_rpt_costcenter, dim_rpt_entity
      , dim_rpt_company, prp_rpt_source, prp_rpt_createmodifydate, prp_rpt_owner, dim_rpt_equipment, dim_rpt_techtype 
    from {1}
    where linenbr in ({2}) and prp_rpt_source='{3}' )"
                    , validationTableName, tempTableName, lineNumbers, fileType);
                
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();
                    numberAdded = command.ExecuteNonQuery();
                    GeneralDatabaseAccess.LogEvent(requestor, "UserInputUpload", "User Added Key Combinations"
                        , string.Format("{0} new key combinations where added", numberAdded), UserToolLogLevel.Audit);
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(requestor, MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                message = ex.Message;
                return -1;
            }

            return numberAdded;
        }

        /// <summary>
        /// Location version adds user-defined keys to fact_location_validate
        /// </summary>
        public static int AddToLocationValidation(string lineNumbers, FileType fileType, string requestor, string month, string years, bool canPostAdjustmentToAnyPeriod, out string message) {
            string sqlText = string.Empty;
            int numberAdded = -1;
            message = string.Empty;

            try {
                sqlText = string.Format(
@"insert into {0} (
    reporting_line, account, kpi, views, scenario, product, subaccount, service_type, function, cost_center, location
    ,  source, date_created, owner, equipment, tech_type, store_status, design_type, location_type, location_subtype
    , location_tier_code
  )  (
    select distinct reporting_line, account, kpi, views, scenario, product, subaccount, service_type, function, cost_center, location
      ,  source, date_created, owner, equipment, tech_type, store_status, design_type, location_type, location_subtype, location_tier_code
    from {1}
    where line_nbr in ({2}) and source='{3}' 
  )"
                    , fileType.ValidationKeyTable
                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                    , lineNumbers, fileType.FileTypeCode);
                    
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();
                    numberAdded = command.ExecuteNonQuery();
                    GeneralDatabaseAccess.LogEvent(requestor, "UserInputUpload", "User Added Key Combinations"
                        , string.Format("{0} new key combinations where added", numberAdded), UserToolLogLevel.Audit);
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(requestor, MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                message = ex.Message;
                return -1;
            }

            return numberAdded;
        }

        //TODO: possibly fix clob logic
        public static int AddToEquipmentValidation(string lineNumbers, FileType fileType, string requestor
            , string month, string year, bool canPostAdjustmentToAnyPeriod, out string message) {
            
            string sqlText = string.Empty;
            int numberAdded = -1;
            message = string.Empty;

            try {
                sqlText = string.Format(
@"insert into {0} (
    reporting_line, kpi, views, scenario, service_type, function, cost_center, entity
    , equipment, tech_type, methodology_type, sale_type, discount_type, contract_term, source
    , date_created, owner                   
  ) 
  select reporting_line, kpi, views, scenario, service_type, function, cost_center, entity
    , equipment, tech_type, methodology_type, sale_type, discount_type, contract_term, source
    , date_created, owner                    
  from {1}
  where source ='{2}'
    and line_nbr in (select column_value from table(split_clob(:lines)))"
                    , fileType.ValidationKeyTable, fileType.StageMonthTable, fileType.FileTypeCode);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();
                    OracleParameter lineNumbersParameter = new OracleParameter("@line_numbers", OracleDbType.Clob);
                    lineNumbersParameter.Value = lineNumbers;
                    command.Parameters.Add(lineNumbersParameter);
                    numberAdded = command.ExecuteNonQuery();
                    GeneralDatabaseAccess.LogEvent(requestor, "UserInputUpload", "User Added Key Combinations"
                        , string.Format("{0} new key combinations where added", numberAdded), UserToolLogLevel.Audit);
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(requestor, MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                message = ex.Message;
                return -1;
            }
            
            return numberAdded;
        }
        
        //TODO: possibly fix clob logic
        public static int AddToDataWarehouseValidation(string lineNumbers, FileType fileType, string requestor, string month, string years, bool canPostAdjustmentToAnyPeriod, out string message) {
            string sqlText = string.Empty;
            int numberAdded = -1;
            message = string.Empty;

            try {
                sqlText = string.Format(
@"insert into {0} (
    customer_account, branch, connection_type, equipment, previous_type, function, kpi, entity, owning_geography, owning_manager
    , product, reporting_line, scenario, segment, service_type, subaccount, tech_type, version, vertical, views
    , contract_term, program_eligibility, source, date_created, owner                     
  )
  select distinct customer_account, branch, connection_type, equipment, previous_type, function, kpi, entity, owning_geography, owning_manager
    , product, reporting_line, scenario, segment, service_type, subaccount, tech_type, version, vertical, views, contract_term
    , program_eligibility, source, date_created, owner
  from {1}
  where source='{2}' and line_nbr in (select column_value from table(split_clob(:lines)))"
                    , fileType.ValidationKeyTable
                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                    , fileType.FileTypeCode);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();
                    OracleParameter lineNumbersParameter = new OracleParameter("@line_numbers", OracleDbType.Clob);
                    lineNumbersParameter.Value = lineNumbers;
                    command.Parameters.Add(lineNumbersParameter);
                    numberAdded = command.ExecuteNonQuery();
                    GeneralDatabaseAccess.LogEvent(requestor, "UserInputUpload", "User Added Key Combinations"
                        , string.Format("{0} new key combinations where added", numberAdded), UserToolLogLevel.Audit);
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(requestor, MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                message = ex.Message;
                return -1;
            }

            return numberAdded;
        }

        #endregion
        
        #region Process Status Routines

        public static int callAddNewProcess(string ProcessCode, string AsRelatesTo, string ClosePeriod,
            string Step, string Status, string Message, string UserId,
            string BlockingProcessCode, string BlockingAsRelatesTo,
            string Requestor)
        {
            OracleConnection oraConn = new OracleConnection(GetOracleConnectionString());
            OracleCommand sqlCmd = null;
            string Cmd = null;
            int iRet = -1;
            try
            {
                oraConn.Open();

                Cmd = "sp_ps_addnewprocessstatus";
                sqlCmd = new OracleCommand(Cmd, oraConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                OracleParameter pProcessCode = new OracleParameter("p_processcode", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pAsRelatesTo = new OracleParameter("p_asrelatesto", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pClosePeriod = new OracleParameter("p_closeperiod", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pStep = new OracleParameter("p_step", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pStatus = new OracleParameter("p_status", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pMessage = new OracleParameter("p_message", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pUserId = new OracleParameter("p_userid", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pBlockingProcessCode = new OracleParameter("p_blockingprocesscode", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pBlockingAsRelatesTo = new OracleParameter("p_blockingasrelatesto", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pProcessId = new OracleParameter("p_returncode", OracleDbType.Int32, ParameterDirection.Output);

                pProcessCode.Value = ProcessCode;
                pAsRelatesTo.Value = AsRelatesTo;
                if (ClosePeriod != null && ClosePeriod.Length > 0)
                    pClosePeriod.Value = ClosePeriod;
                pStep.Value = Step;
                pStatus.Value = Status;
                pMessage.Value = Message;
                pUserId.Value = UserId;
                if (BlockingProcessCode != null && BlockingProcessCode.Length > 0)
                    pBlockingProcessCode.Value = BlockingProcessCode;
                if (BlockingAsRelatesTo != null && BlockingAsRelatesTo.Length > 0)
                    pBlockingAsRelatesTo.Value = BlockingAsRelatesTo;

                sqlCmd.Parameters.Add(pProcessCode);
                sqlCmd.Parameters.Add(pAsRelatesTo);
                sqlCmd.Parameters.Add(pClosePeriod);
                sqlCmd.Parameters.Add(pStep);
                sqlCmd.Parameters.Add(pStatus);
                sqlCmd.Parameters.Add(pMessage);
                sqlCmd.Parameters.Add(pUserId);
                sqlCmd.Parameters.Add(pBlockingProcessCode);
                sqlCmd.Parameters.Add(pBlockingAsRelatesTo);
                sqlCmd.Parameters.Add(pProcessId);

                sqlCmd.ExecuteNonQuery();
                iRet = int.Parse(string.Format("{0}", pProcessId.Value));
            }
            catch (Exception ex)
            {
                //  Log the error to a table.
                GeneralDatabaseAccess.LogEvent(Requestor, "callAddNewProcess", Cmd, ex, UserToolLogLevel.Error);
                iRet = -1;
            }
            finally
            {
                if (oraConn != null)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                }
            }
            return iRet;
        }

        public static int callAddNextProcessStep(int ProcessId, string Step, string Status, string Message, string Requestor)
        {
            OracleConnection oraConn = new OracleConnection(GetOracleConnectionString());
            OracleCommand sqlCmd = null;
            string Cmd = null;
            int iRet = -1;
            try
            {
                oraConn.Open();

                Cmd = "SP_PS_ADDNEXTPROCESSSTEP";
                sqlCmd = new OracleCommand(Cmd, oraConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                OracleParameter pProcessId = new OracleParameter("p_processid", OracleDbType.Int32, ParameterDirection.Input);
                OracleParameter pStep = new OracleParameter("p_step", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pStatus = new OracleParameter("p_status", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pMessage = new OracleParameter("p_message", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pRetCode = new OracleParameter("p_returncode", OracleDbType.Int32, ParameterDirection.Output);

                pProcessId.Value = ProcessId;
                pStep.Value = Step;
                pStatus.Value = Status;
                pMessage.Value = Message;

                sqlCmd.Parameters.Add(pProcessId);
                sqlCmd.Parameters.Add(pStep);
                sqlCmd.Parameters.Add(pStatus);
                sqlCmd.Parameters.Add(pMessage);
                sqlCmd.Parameters.Add(pRetCode);

                sqlCmd.ExecuteNonQuery();
                iRet = int.Parse(string.Format("{0}", pRetCode.Value));
            }
            catch (Exception ex)
            {
                //  Log the error to a table.
                GeneralDatabaseAccess.LogEvent(Requestor, "callAddNextProcessStep", Cmd, ex, UserToolLogLevel.Error);
                iRet = -1;
            }
            finally
            {
                if (oraConn != null)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                }
            }
            return iRet;
        }

        public static int callEndProcessStep(int ProcessId, string Step, string Status, string Message, string Requestor)
        {
            OracleConnection oraConn = new OracleConnection(GetOracleConnectionString());
            OracleCommand sqlCmd = null;
            string Cmd = null;
            int iRet = -1;
            try
            {
                oraConn.Open();

                Cmd = "SP_PS_ENDPROCESSSTEP";
                sqlCmd = new OracleCommand(Cmd, oraConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                OracleParameter pProcessId = new OracleParameter("p_processid", OracleDbType.Int32, ParameterDirection.Input);
                OracleParameter pStep = new OracleParameter("p_step", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pStatus = new OracleParameter("p_status", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pMessage = new OracleParameter("p_message", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pRetCode = new OracleParameter("p_returncode", OracleDbType.Int32, ParameterDirection.Output);

                pProcessId.Value = ProcessId;
                pStep.Value = Step;
                pStatus.Value = Status;
                pMessage.Value = Message;

                sqlCmd.Parameters.Add(pProcessId);
                sqlCmd.Parameters.Add(pStep);
                sqlCmd.Parameters.Add(pStatus);
                sqlCmd.Parameters.Add(pMessage);
                sqlCmd.Parameters.Add(pRetCode);

                sqlCmd.ExecuteNonQuery();
                iRet = int.Parse(string.Format("{0}", pRetCode.Value));
            }
            catch (Exception ex)
            {
                //  Log the error to a table.
                GeneralDatabaseAccess.LogEvent(Requestor, "callAddNextProcessStep", Cmd, ex, UserToolLogLevel.Error);
                iRet = -1;
            }
            finally
            {
                if (oraConn != null)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                }
            }
            return iRet;
        }

        public static int callUpdateProcessStep(int ProcessId, string Step, string Status, string Message, string Requestor)
        {
            OracleConnection oraConn = new OracleConnection(GetOracleConnectionString());
            OracleCommand sqlCmd = null;
            string Cmd = null;
            int iRet = -1;
            try
            {
                oraConn.Open();

                Cmd = "SP_PS_UPDATEPROCESSSTEP";
                sqlCmd = new OracleCommand(Cmd, oraConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                OracleParameter pProcessId = new OracleParameter("p_processid", OracleDbType.Int32, ParameterDirection.Input);
                OracleParameter pStep = new OracleParameter("p_step", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pStatus = new OracleParameter("p_status", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pMessage = new OracleParameter("p_message", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pRetCode = new OracleParameter("p_returncode", OracleDbType.Int32, ParameterDirection.Output);

                pProcessId.Value = ProcessId;
                pStep.Value = Step;
                pStatus.Value = Status;
                pMessage.Value = Message;

                sqlCmd.Parameters.Add(pProcessId);
                sqlCmd.Parameters.Add(pStep);
                sqlCmd.Parameters.Add(pStatus);
                sqlCmd.Parameters.Add(pMessage);
                sqlCmd.Parameters.Add(pRetCode);

                sqlCmd.ExecuteNonQuery();
                iRet = int.Parse(string.Format("{0}", pRetCode.Value));
            }
            catch (Exception ex)
            {
                //  Log the error to a table.
                GeneralDatabaseAccess.LogEvent(Requestor, "callUpdateNextProcessStep", Cmd, ex, UserToolLogLevel.Error);
                iRet = -1;
            }
            finally
            {
                if (oraConn != null)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                }
            }
            return iRet;
        }

        public static int callCheckProcessRunning(string ProcessCode, string AsRelatesTo, string Requestor)
        {
            OracleConnection oraConn = new OracleConnection(GetOracleConnectionString());
            OracleCommand sqlCmd = null;
            string Cmd = null;
            int iRet = -1;
            try
            {
                oraConn.Open();

                Cmd = "sp_ps_checkprocessrunning";
                sqlCmd = new OracleCommand(Cmd, oraConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                OracleParameter pProcessCode = new OracleParameter("p_processcode", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pAsRelatesTo = new OracleParameter("p_asrelatesto", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pRetCode = new OracleParameter("p_returncode", OracleDbType.Int32, ParameterDirection.Output);

                pProcessCode.Value = ProcessCode;
                pAsRelatesTo.Value = AsRelatesTo;

                sqlCmd.Parameters.Add(pProcessCode);
                sqlCmd.Parameters.Add(pAsRelatesTo);
                sqlCmd.Parameters.Add(pRetCode);

                sqlCmd.ExecuteNonQuery();
                iRet = int.Parse(string.Format("{0}", pRetCode.Value));
            }
            catch (Exception ex)
            {
                //  Log the error to a table.
                GeneralDatabaseAccess.LogEvent(Requestor, "callCheckProcessRunning", Cmd, ex, UserToolLogLevel.Error);
                iRet = -1;
            }
            finally
            {
                if (oraConn != null)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                }
            }
            return iRet;
        }

        public static List<JobStatusDTO> RetrieveJobStatus(string period) {
            string sqlText = string.Empty;
            List<JobStatusDTO> list = new List<JobStatusDTO>();
            JobStatusDTO jobStatus;

            try {
                sqlText = string.Format(
@"
    with file_types as (select t.input_file_code, t.Description, t.Scheduled_Load_Date, t.is_13month, t.is_Adjustment, t.dest_table, t.Show_On_Upload_Status  from OPS_USER_INPUT_FILE t where t.Show_On_Upload_Status='Y' and t.dest_table not like 'PLANNING%'
                        UNION
                        select ft.input_file_code, ft.Description, ft.Scheduled_Load_Date, ft.is_13month, ft.is_Adjustment, ft.dest_table, ft.Show_On_Upload_Status  from user_tool.OPS_FILE_TYPES ft where ft.Show_On_Upload_Status='Y'
                        )
    select distinct t.input_file_code,a.endtime, t.Description, t.Scheduled_Load_Date
           , u.first_name, u.last_name
           , case 
               when lower(a.created_by) like '%autosys%' 
                 or lower(a.created_by) like 'vzw%' 
                 or lower(a.created_by) like 'fas%'
                 or a.created_by='ODI' then 
                   case 
                     when t.input_file_code like 'EIS%' then 'EIS'
                     when t.input_file_code like 'GL%' then 'GL'
                     when t.input_file_code like 'HC%' then 'HC'
                     when t.input_file_code like 'EQ%' then 'CIABI'
                     when t.input_file_code like 'DW%' then 'DW'
                     when t.input_file_code like 'RAAT%' then  'RAAT'
                     when t.input_file_code = 'PFS_MOU' then 'PFS_MOU'
                  end 
              else  a.created_by           
            end as created_by
          , t.is_13month, t.is_Adjustment, a.status, a.message
        from file_types t
          left outer join (
            select p.As_Relates_To, max(p.end_time) endtime, p.created_by, status, message
            from ops_run_status p
            where (p.status like 'Complete%' or p.Status='Success') 
               and p.fiscal_period={0} 
            group by p.As_Relates_To, p.CREATED_BY, status, message
            union all
            select p.AsRelatesTo As_Relates_To, max(p.endtime) endtime, p.userid, 'Complete' as status, message
            from rpt_process_status_tbl p
            where p.status='S' and p.ClosePeriod={0} and p.ProcessCode in ('USER_FEED','INTFC_LOAD') 
            group by p.AsRelatesTo,p.userid, status, message 
          ) a on t.input_file_code=a.As_Relates_To
          left outer join WEB_USERS u on u.user_id=CREATED_BY
        where t.Show_On_Upload_Status='Y' and t.dest_table not like 'PLANNING%'
        order by 1, 2 desc "
                  , period);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;

                        string lastSource = "";
                        while (reader.Read()) {
                            if (lastSource == reader.GetString(0))
                                continue;
                            lastSource = reader.GetString(0);
                            jobStatus = new JobStatusDTO();
                            if (!reader.IsDBNull(1)) jobStatus.dtCreate = reader.GetDateTime(1);
                            jobStatus.Source = lastSource;
                            if (!reader.IsDBNull(2)) jobStatus.Description = reader.GetString(2);
                            if (!reader.IsDBNull(4) && !reader.IsDBNull(5)) {
                                jobStatus.Owner = string.Format("{0} {1}", reader[4], reader[5]);
                            } else {
                                if (!reader.IsDBNull(6)) jobStatus.Owner = reader.GetString(6);
                            }
                            if (!reader.IsDBNull(3)) {
                                jobStatus.ScheduledLoad = reader.GetString(3);
                            }
                            switch (reader[9].ToString()) {
                                case "E": jobStatus.Status = "Error"; break;
                                case "S": jobStatus.Status = "Complete"; break;
                                default: jobStatus.Status = reader[9].ToString(); break;
                            }
                            jobStatus.Message = reader[10].ToString();
                            list.Add(jobStatus);
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
               
                //list = null;
            }
            return list;
        }
        
        #endregion
        
        #region CPGA Routines

        public static DataSet callCpgaValidate(string TriggerTbl, string PatternTbl, string SplitFuncTbl, string EntityOverrideTbl,
            string Requestor)
        {
            OracleConnection oraConn = new OracleConnection(GetOracleConnectionString());
            OracleCommand sqlCmd = null;
            DataSet dsResult = null;
            string Cmd = null;
            try
            {
                oraConn.Open();

                Cmd = "SP_CPGAVALIDATION";
                sqlCmd = new OracleCommand(Cmd, oraConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                OracleParameter pTriggerTbl = new OracleParameter("p_triggertbl", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pPatternTbl = new OracleParameter("p_patterntbl", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pSplitFuncTbl = new OracleParameter("p_splitfunctbl", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pEntityOvrrdTbl = new OracleParameter("p_entityovrrde", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pRowSet = new OracleParameter("p_rowset", OracleDbType.RefCursor, ParameterDirection.Output);

                pTriggerTbl.Value = TriggerTbl;
                pPatternTbl.Value = PatternTbl;
                pSplitFuncTbl.Value = SplitFuncTbl;
                pEntityOvrrdTbl.Value = EntityOverrideTbl;

                sqlCmd.Parameters.Add(pTriggerTbl);
                sqlCmd.Parameters.Add(pPatternTbl);
                sqlCmd.Parameters.Add(pSplitFuncTbl);
                sqlCmd.Parameters.Add(pEntityOvrrdTbl);
                sqlCmd.Parameters.Add(pRowSet);

                dsResult = new DataSet();
                OracleDataAdapter da = new OracleDataAdapter(sqlCmd);
                da.Fill(dsResult);

                //for (int rw = 0; rw < ds.Tables[0].Rows.Count; rw++)
                //{
                //    arrValid.Add(string.Format("{0}\t{1}\t{2}\t{3}",
                //        ds.Tables[0].Rows[rw][0], ds.Tables[0].Rows[rw][1], ds.Tables[0].Rows[rw][2], ds.Tables[0].Rows[rw][3]));
                //}
            }
            catch (Exception ex)
            {
                //  Log the error to a table.
                GeneralDatabaseAccess.LogEvent(Requestor, "callCpgaValidate", Cmd, ex, UserToolLogLevel.Error);
                if (dsResult != null)
                {
                    dsResult.Dispose();
                    dsResult = null;
                }
            }
            finally
            {
                if (oraConn != null)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                }
            }
            return dsResult;
        }

        public static bool callCpgaValPatsTrigs(string TriggerTbl, string PatternTbl,
            string Period, out string NotInTriggers, out string NotInPatterns,
            string Requestor)
        {
            NotInTriggers = "";
            NotInPatterns = "";

            OracleConnection oraConn = new OracleConnection(GetOracleConnectionString());
            OracleCommand sqlCmd = null;
            bool bRet = false;
            string Cmd = null;
            try
            {
                oraConn.Open();

                Cmd = "sp_cpga_val_pats_trigs";
                sqlCmd = new OracleCommand(Cmd, oraConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                OracleParameter pTriggerTbl = new OracleParameter("p_triggertbl", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pPatternTbl = new OracleParameter("p_patterntbl", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pPeriod = new OracleParameter("p_period", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pNotInTriggers = new OracleParameter("p_notintriggers", OracleDbType.Varchar2, 250, NotInTriggers, ParameterDirection.Output);
                OracleParameter pNotInPatterns = new OracleParameter("p_notinpatterns", OracleDbType.Varchar2, 250, NotInPatterns, ParameterDirection.Output);

                pTriggerTbl.Value = TriggerTbl;
                pPatternTbl.Value = PatternTbl;
                pPeriod.Value = Period;

                sqlCmd.Parameters.Add(pTriggerTbl);
                sqlCmd.Parameters.Add(pPatternTbl);
                sqlCmd.Parameters.Add(pPeriod);
                sqlCmd.Parameters.Add(pNotInTriggers);
                sqlCmd.Parameters.Add(pNotInPatterns);

                sqlCmd.ExecuteNonQuery();
                bRet = true;

                NotInTriggers = pNotInTriggers.Value.ToString();
                NotInPatterns = pNotInPatterns.Value.ToString();
                if (NotInTriggers.Equals("null"))
                    NotInTriggers = "";
                if (NotInPatterns.Equals("null"))
                    NotInPatterns = "";
            }
            catch (Exception ex)
            {
                //  Log the error to a table.
                GeneralDatabaseAccess.LogEvent(Requestor, "callCpgaValPatsTrigs", Cmd, ex, UserToolLogLevel.Error);
            }
            finally
            {
                if (sqlCmd != null)
                    sqlCmd.Dispose();

                if (oraConn != null)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                }
            }
            return bRet;
        }

        public static int callCpgaExplode(string PatternsTbl, string TriggersTbl,
            string FunctionsTbl, string LookupTbl, string DimTable, string Period, string Requestor)
        {
            BasicOraCommand Wrtr = new BasicOraCommand(GetOracleConnectionString());
            string Cmd = null;
            Int32 Ret = 0;
            try
            {
                Cmd = "sp_cpga_explode_f";

                OracleParameter pPatterns = new OracleParameter("P_IN_PATTERS", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pTriggers = new OracleParameter("P_IN_TRIGGERS", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pFunctions = new OracleParameter("P_IN_FUNCTIONS", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pLookup = new OracleParameter("P_OUT_TABLE", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pDimension = new OracleParameter("P_DIM_TABLE", OracleDbType.Varchar2, ParameterDirection.Input);
                OracleParameter pPeriod = new OracleParameter("P_CURRENT_TIME", OracleDbType.Int32, ParameterDirection.Input);
                OracleParameter pReturnCode = new OracleParameter("P_RETURNCODE", OracleDbType.Int32, ParameterDirection.Output);

                pPatterns.Value = PatternsTbl;
                pTriggers.Value = TriggersTbl;
                pFunctions.Value = FunctionsTbl;
                pLookup.Value = LookupTbl;
                pDimension.Value = DimTable;
                pPeriod.Value = int.Parse(Period);

                Wrtr.Exec(Cmd, CommandType.StoredProcedure, pPatterns, pTriggers, pFunctions,
                    pLookup, pDimension, pPeriod, pReturnCode);
                if (Wrtr.LastErrorMessage.Length > 0)
                    throw new Exception(Wrtr.LastErrorMessage);
                //Ret = (Int32) pReturnCode.Value;
            }
            catch (Exception ex)
            {
                //  Log the error to a table.
                GeneralDatabaseAccess.LogEvent(Requestor, "callCpgaExplode", Cmd, ex, UserToolLogLevel.Error);
            }

            if (Wrtr != null)
            {
                Wrtr.Close();
                Wrtr.Dispose();
            }
            return Ret;
        }

        public static DataSet callCpgaOverlap(string Period, string stgPattern, string stgTriggers, string stgLookup, out string WarnErr, string Requestor)
        {
            OracleConnection oraConn = new OracleConnection(GetOracleConnectionString());
            OracleCommand sqlCmd = null;
            DataSet dsResult = null;
            string Cmd = null;
            WarnErr = "";
            try
            {
                oraConn.Open();

                Cmd = "SP_CPGA_OVERLAP";
                sqlCmd = new OracleCommand(Cmd, oraConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                OracleParameter pPeriod = new OracleParameter("p_period", OracleDbType.Varchar2, ParameterDirection.Input);
                pPeriod.Value = Period;
                // jevans 3/14/2011 -  overlap now excepts stage table names
                OracleParameter pPatterns = new OracleParameter("P_IN_PATTERNS", OracleDbType.Varchar2, ParameterDirection.Input);
                pPatterns.Value = stgPattern;
                OracleParameter pTriggers = new OracleParameter("P_IN_TRIGGERS", OracleDbType.Varchar2, ParameterDirection.Input);
                pTriggers.Value = stgTriggers;
                OracleParameter pLookup = new OracleParameter("P_LOOKUP_TABLE", OracleDbType.Varchar2, ParameterDirection.Input);
                pLookup.Value = stgLookup;

                OracleParameter pWarnErr = new OracleParameter("p_warnerr", OracleDbType.Varchar2, 10);
                pWarnErr.Direction = ParameterDirection.Output;
                OracleParameter pRowSet = new OracleParameter("p_rowset", OracleDbType.RefCursor, ParameterDirection.Output);


                sqlCmd.Parameters.Add(pPatterns);
                sqlCmd.Parameters.Add(pTriggers);
                sqlCmd.Parameters.Add(pLookup);
                sqlCmd.Parameters.Add(pPeriod);
                sqlCmd.Parameters.Add(pWarnErr);
                sqlCmd.Parameters.Add(pRowSet);

                dsResult = new DataSet();
                OracleDataAdapter da = new OracleDataAdapter(sqlCmd);
                da.Fill(dsResult);
                WarnErr = (string)pWarnErr.Value.ToString();
            }
            catch (Exception ex)
            {
                //  Log the error to a table.
                GeneralDatabaseAccess.LogEvent(Requestor, "callCpgaOverlap", Cmd, ex, UserToolLogLevel.Error);
                if (dsResult != null)
                {
                    dsResult.Dispose();
                    dsResult = null;
                }
            }
            finally
            {
                if (oraConn != null)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                }
            }
            return dsResult;
        }

        /* version 1.11 */
        public static int CopyExcelToTable(string Filename, string SheetName, string StgTableName, bool bTruncTable, ArrayList arrColInfo, out string Msg, string Requestor)
        {
            int RecCnt = -1;
            Msg = "";
            try
            {
                //Create the Connection String
                //You must specify the Provider as is here, I think
                //Thre Data Source is the path to your file
                //Extended Properties is something to do with excel, use as here
                string ConnString;//= string.Format(@"Provider=Microsoft.Jet.OLEDB.4.0; Data Source={0};Extended Properties=""Excel 8.0;HDR=YES;IMEX=1;"" ", Filename);
                if (Filename.EndsWith(".xls"))
                    ConnString = string.Format(@"Provider=Microsoft.Jet.OLEDB.4.0; Data Source={0};Extended Properties=""Excel 8.0;IMEX=1;""", Filename);
                else
                    ConnString = string.Format(@"Provider=Microsoft.ACE.OLEDB.12.0; Data Source={0};Extended Properties=""Excel 12.0 Xml;IMEX=1;""", Filename);

                //Create the connection
                System.Data.OleDb.OleDbCommand OleCmd = null;
                System.Data.OleDb.OleDbDataReader OleRdr = null;
                System.Data.OleDb.OleDbConnection ExcelConnection = new System.Data.OleDb.OleDbConnection(ConnString);
                BasicOraCommand Wrtr = new BasicOraCommand(DbAccess.GetOracleConnectionString());

                try
                {
                    ExcelConnection.Open();

                    //  If we need to truncate the table, do it now.
                    if (bTruncTable)
                        Wrtr.Exec("Truncate Table " + StgTableName);
                    else
                        Wrtr.Open();

                    string InsCols = "";
                    string SelCols = "";

                    foreach (ExcelToMapInfo em in arrColInfo)
                    {
                        InsCols += "," + em.TblColName;
                        SelCols += "," + em.ExcelName;
                    }

                    // jevans 2/28/2011 -  Check for each field that should be in the file  
                    string fields = "";

                    //  We want to select all the UserInput fields from the Excel file.
                    string Cmd = string.Format(" Select * from [{0}$]", SheetName);

                    //Sheet1 is the sheet name
                    //create the query:
                    System.Data.OleDb.OleDbCommand ExcelCommand = new System.Data.OleDb.OleDbCommand(Cmd, ExcelConnection);

                    //Create a reader
                    System.Data.OleDb.OleDbDataReader ExcelReader;
                    try
                    {
                        ExcelReader = ExcelCommand.ExecuteReader();
                    }
                    catch (System.Data.OleDb.OleDbException)
                    {
                        Msg = string.Format("There was an error opening the Excel file.  Make sure that a Worksheet named '{0}' exists.", SheetName);
                        return -1;
                    }
                    for (int i = 0; i < arrColInfo.Count; i++)
                    {
                        bool bFound = false;
                        ExcelToMapInfo em = (ExcelToMapInfo)arrColInfo[i];
                        for (int j = 0; j < ExcelReader.VisibleFieldCount; j++)
                        {
                            if (em.ExcelName.ToUpper().Equals(ExcelReader.GetName(j).ToUpper()))
                            {
                                bFound = true;
                                break;
                            }

                        } // end for each excel column 
                        //  If the field wasn't found, throw an exception.
                        // jevans 11/22/2010 - do NOT throw an exception
                        if (bFound == false)
                        {
                            //throw new Exception("The following field was not defined in the file: " + UploadFlds[i]);
                            fields += "<li>" + em.ExcelName;
                        }
                    }// end of for each column
                    //ExcelReader.Close();
                    // ExcelConnection.Close ();
                    if (fields.Length > 1)
                    {
                        Msg = string.Format("The Load Process failed to find the following field(s) in the file: {0}<br>", fields);
                        return -1;
                    } // end of if fields 

                    // jevans 4/8/2011 - check for dups 
                    OleCmd = new System.Data.OleDb.OleDbCommand(string.Format("select count(1) from [{1}$] group by {0} having count(1) > 1", SelCols.Substring(1), SheetName), ExcelConnection);
                    OleRdr = OleCmd.ExecuteReader();
                    while (OleRdr.Read())
                    {
                        if (OleRdr.GetInt32(0) > 1)
                        {
                            Msg = string.Format("Duplicate rows detected in {0} sheet", SheetName);
                            return -1;
                        }
                    }

                    // now select records 
                    OleCmd = new System.Data.OleDb.OleDbCommand(string.Format("select {0} from [{1}$]",
                        SelCols.Substring(1), SheetName), ExcelConnection);

                    OleRdr = OleCmd.ExecuteReader();

                    RecCnt = 0;
                    string InsCmd = "";
                    while (OleRdr.Read())
                    {
                        InsCmd = string.Format("insert into {0} ({1}) values (", StgTableName, InsCols.Substring(1));
                        int c = 0;
                        bool SkipIt = false;
                        foreach (ExcelToMapInfo em in arrColInfo)
                        {
                            if (c > 0)
                                InsCmd += ",";

                            if (OleRdr.IsDBNull(c))
                            {
                                if (em.MustExist)
                                {
                                    SkipIt = true;
                                    break;
                                }

                                if (em.ValIfNull != null)
                                {
                                    switch (em.FldType)
                                    {
                                        case ExcelToMapInfo.FldTypes.DbFloat:
                                        case ExcelToMapInfo.FldTypes.DbInteger:
                                            InsCmd += em.ValIfNull;
                                            break;

                                        case ExcelToMapInfo.FldTypes.DbDate:
                                            InsCmd += string.Format("to_date('{0}', 'mm/dd/yyyy HH.MI.SS AM')", em.ValIfNull);
                                            break;

                                        case ExcelToMapInfo.FldTypes.DbString:
                                            InsCmd += "'" + em.ValIfNull + "'";
                                            break;
                                    }
                                }
                                else
                                    InsCmd += "NULL";
                            }
                            else
                            {
                                switch (em.FldType)
                                {
                                    case ExcelToMapInfo.FldTypes.DbFloat:
                                    case ExcelToMapInfo.FldTypes.DbInteger:
                                        InsCmd += OleRdr.GetValue(c).ToString();
                                        break;

                                    case ExcelToMapInfo.FldTypes.DbDate:
                                        InsCmd += string.Format("to_date('{0}', 'mm/dd/yyyy HH.MI.SS AM')", OleRdr.GetValue(c).ToString());
                                        break;

                                    case ExcelToMapInfo.FldTypes.DbString:
                                        string strVal = OleRdr.GetValue(c).ToString().ToUpper().Trim();
                                        if (em.TrimValues != null && em.TrimValues.Length > 0)
                                        {
                                            foreach (char ch in em.TrimValues)
                                            {
                                                strVal = strVal.Replace("" + ch, "");
                                            }
                                            strVal = strVal.Trim();
                                        }
                                        InsCmd += "'" + strVal + "'";
                                        break;
                                }
                            }
                            c++;
                        }
                        if (SkipIt)
                            continue;

                        if (Wrtr.ExecOpened(InsCmd + ")") < 1)
                        {
                            throw new Exception(string.Format("An Error Occurred writing Data to the {0} Table:  {1}\r\n{2}",
                                StgTableName,
                                Wrtr.LastErrorMessage,
                                InsCmd));
                        }
                        RecCnt++;
                    }
                    Wrtr.Close();
                }
                catch (Exception ex)
                {
                    Msg = ex.Message;
                    RecCnt = -1;
                }
                finally
                {
                    if (OleRdr != null)
                        OleRdr.Close();
                    if (OleCmd != null)
                        OleCmd.Dispose();
                    ExcelConnection.Dispose();
                }
            }
            catch (Exception ex1)
            {
                GeneralDatabaseAccess.LogEvent("CopyExcelToTable", "Writing Excel File", ex1.Message, Requestor, UserToolLogLevel.Error);
                RecCnt = -1;
            }
            return RecCnt;
        }

        #endregion
                
        #region   Upload Validations

        /// <summary>
        /// replaces any values in upload with forced values from file type definition
        /// </summary>
        /// <param name="fileType"></param>
        /// <returns></returns>
        public static string ProcessForcedValues(FileType fileType) {
            string sqlText = string.Empty;
            string message = string.Empty;

            try {
                foreach (FileTypeField fileTypeField in fileType.fields) {
                    if (fileTypeField.Source == FileTypeFieldSource.ForcedValue) {
                        if (sqlText.Length > 0)
                            sqlText += ",";
                        sqlText += string.Format("{0}='{1}'", fileTypeField.FactColumnName, fileTypeField.ForcedValue);
                    }
                }

                if (sqlText.Length > 0) {
                    sqlText = string.Format("update {0} set {1} where {2}='{3}'"
                        , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                        , sqlText, fileType.SourceColumnName, fileType.FileTypeCode);

                    using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                    using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                        connection.Open();
                        command.ExecuteNonQuery();
                        connection.Close();
                    }
                }                
                
            } catch (Exception ex) {
                message = ex.Message;
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
            }
            return message;
        }

        /// <summary>
        /// Processes fields and then returns any fields not mapped for regular fact upload file types
        /// </summary>
        public static ArrayList ProcessReportingAutomappedData(FileType fileType, int runStatusId, int maxRows, string fiscalPeriod, out string message, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            message = string.Empty;
            rowsSkipped = 0;

            try {
                if (ProcessReportingAutoMappedFields(fileType, runStatusId, fiscalPeriod, out message)) {
                    if (message.Length > 0) {
                        return null;
                    }

                    sqlText = string.Format(
@"select d.linenbr, d.dim_rpt_reportngline, d.dim_rpt_account,d.dim_rpt_kpi, d.dim_rpt_view, d.dim_rpt_years
    , d.dim_rpt_scenario, d.dim_rpt_product, d.dim_rpt_subaccount, d.dim_rpt_servicetype, d.dim_rpt_function
    , d.dim_rpt_costcenter, d.dim_rpt_entity, d.dim_rpt_company, d.dim_rpt_equipment, d.dim_rpt_techtype
    , d.dim_rpt_years {2}  
  from {0} d
  where (
    d.dim_rpt_reportngline is null or d.dim_rpt_product is null or d.dim_rpt_subaccount is null 
    or d.dim_rpt_servicetype is null or d.dim_rpt_function is null or d.dim_rpt_costcenter is null
    or d.dim_rpt_equipment is null or d.dim_rpt_techtype is null
  ) and d.prp_rpt_source='{1}'"
                        , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                        , fileType.FileTypeCode
                        , fileType.Is13Month ? string.Empty : ", d.dim_rpt_time");

                    LogMessage("Validating all data was Auto mapped", sqlText, null, runStatusId);

                    using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                    using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                        connection.Open();

                        using (OracleDataReader reader = command.ExecuteReader()) {
                            reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                            if (reader.HasRows) {
                                while (reader.Read()) {
                                    if (rowCount < maxRows) {
                                        int i = 0;
                                        FactValidDTO f = new FactValidDTO();
                                        f.Line = reader.GetDecimal(i);
                                        if (!reader.IsDBNull(++i)) f.ReportingLine = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.Account = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.Year = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.Product = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.SubAccount = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.CostCenter = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.Company = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.Year = reader.GetString(i);
                                        if (!fileType.Is13Month) {
                                            if (!reader.IsDBNull(++i)) f.Month = reader.GetString(i);
                                        }
                                        a.Add(f);
                                        rowCount++;
                                    } else {
                                        // max row was reached 
                                        rowsSkipped++;
                                    }
                                }
                            }
                            reader.Close();
                        }
                        connection.Close();
                    }
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        /// <summary>
        /// called by UserInputUpload / ProcessAutomappedData to process each field that 
        /// </summary>
        public static bool ProcessReportingAutoMappedFields(FileType fileType, int runStatusId, string fiscalPeriod, out string message) {
            string sqlText = string.Empty;
            bool fieldsWereAutomapped = false;
            message = string.Empty;

            try {
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = connection.CreateCommand()) {
                    connection.Open();

                    foreach (FileTypeField fileTypeField in fileType.fields) {
                        switch (fileTypeField.Source) {
                            case FileTypeFieldSource.AutomapOnAccount:
                                fieldsWereAutomapped = true;
                                sqlText = string.Format(
@"update {0} u
  set u.{1} = (select f.{1} 
  from rpt_reformat_map_tbl f where u.dim_rpt_account = f.rpt_mapped_acct 
    and f.rpt_gl_product=substr(u.dim_rpt_product,7,3) and f.dim_rpt_map_id='GL' and f.{1} <> 'N/A')
  where u.prp_rpt_source='{2}'"
                                , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                                , fileTypeField.FactColumnName, fileType.FileTypeCode);
                                command.CommandText = sqlText;
                                if (runStatusId > 0) LogMessage("Auto-mapping using Reformat Map table (prod specific)", sqlText, null, runStatusId);
                                command.ExecuteNonQuery();
                                
                                sqlText = string.Format(
@"update {0} u
  set u.{1} = (
    select f.{1} from rpt_reformat_map_tbl f 
    where u.dim_rpt_account = f.rpt_mapped_acct and f.rpt_gl_product='*' and f.dim_rpt_map_id='GL' and f.{1} <> 'N/A'
  )
  where u.prp_rpt_source='{2}' and u.{1} is null"
                                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                                    , fileTypeField.FactColumnName,fileType.FileTypeCode);
                                command.CommandText = sqlText;
                                if (runStatusId > 0) LogMessage("Auto-mapping using Reformat Map table (general)", sqlText, null, runStatusId);
                                command.ExecuteNonQuery();
                                break;

                            case FileTypeFieldSource.AutomapOnCostCenter:
                                fieldsWereAutomapped = true;

                                if (fileTypeField.FactColumnName == "DIM_RPT_PRODUCT") {
                                    sqlText = string.Format(
@"update {0} u
  set u.dim_rpt_product = coalesce((
    select c.product_out from map_cost_center_product c
    where u.dim_rpt_costcenter = c.cost_center_in
      and to_number(coalesce(u.dim_rpt_years, substr('{1}',0,4))) || lpad(coalesce(u.dim_rpt_time, substr('{1}',5,2)), 2, '0') 
        between c.start_period and c.end_period and c.product_out is not null), u.dim_rpt_product
  ) 
  where u.PRP_RPT_SOURCE='{2}' ",
                                        fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable,
                                        fiscalPeriod,
                                        fileType.FileTypeCode); 
                                    
                                    command.CommandText = sqlText;
                                    if (runStatusId > 0) LogMessage("Auto-mapping product based on cost center", sqlText, null, runStatusId);
                                    command.ExecuteNonQuery();
                                } else {
                                    sqlText = string.Format("update {0} set {1}=null where prp_rpt_source='{2}'"
                                        , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                                        , fileTypeField.FactColumnName, fileType.FileTypeCode);
                                    command.CommandText = sqlText;
                                    command.ExecuteNonQuery();
                                    sqlText = string.Format(
@"update {0} u
  set u.{1} = (
    select c.{1} from rpt_cc_to_ch_map_tbl c 
    where substr(u.dim_rpt_costcenter,-4) = c.dim_rpt_costcenter
  )
  where u.prp_rpt_source='{2}'"
                                        , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                                        , fileTypeField.FactColumnName, fileType.FileTypeCode);
                                    if (runStatusId > 0) LogMessage("Auto-mapping function based on cost center", sqlText, null, runStatusId);
                                    command.CommandText = sqlText;
                                    command.ExecuteNonQuery();
                                }
                                break;
                            case FileTypeFieldSource.AutomapOnFunction:
                                fieldsWereAutomapped = true;
                                sqlText = string.Format("update {0} set {1}=null where prp_rpt_source='{2}'"
                                        , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                                        , fileTypeField.FactColumnName, fileType.FileTypeCode);
                                command.CommandText = sqlText;
                                command.ExecuteNonQuery();
                                sqlText = string.Format(
@"update {0} u
  set u.{1} = (
    select f.{1} from rpt_fun_to_cc_map_tbl f where u.dim_rpt_function = f.dim_rpt_function
  )
  where u.prp_rpt_source='{2}'"
                                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                                    , fileTypeField.FactColumnName, fileType.FileTypeCode);
                                if (runStatusId > 0) LogMessage("Auto-mapping cost center based on function", sqlText, null, runStatusId);
                                command.CommandText = sqlText;
                                command.ExecuteNonQuery();
                                break;

                        }
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                message = ex.Message;
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                fieldsWereAutomapped = false;
            }

            return fieldsWereAutomapped;
        }

        /// <summary>
        /// new version for location, project 24524
        /// </summary>
        public static ArrayList ProcessLocationAutomappedData(FileType fileType, int runStatusId, int maxRows, out string message, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            message = string.Empty;
            rowsSkipped = 0;

            try {
                if (ProcessLocationAutoMappedFields(fileType, runStatusId, out message)) {
                    if (message.Length > 0) {
                        return null;
                    }

                    sqlText = string.Format(
@"select d.line_nbr, d.reporting_line, d.account, d.kpi, d.views, d.scenario, d.product, d.subaccount
    , d.service_type, d.function, d.cost_center, d.location, d.equipment, d.tech_type
    , d.store_status, d.design_type, d.location_type, d.location_subtype, d.location_tier_code, d.year {0}
  from {1} d
  where (
    d.reporting_line is null or d.product is null or d.subaccount is null or d.service_type is null 
    or d.function is null or d.cost_center is null or d.equipment is null or d.tech_type is null 
    or d.store_status is null or d.design_type is null or d.location_type is null  
    or d.location_subtype is null or d.location_tier_code is null  
  ) and d.source='{2}'"
                            , fileType.Is13Month ? string.Empty : ", d.time "
                            , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                            , fileType.FileTypeCode);

                    LogMessage("Validating all data was Auto mapped", sqlText, null, runStatusId);

                    using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                    using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                        connection.Open();

                        using (OracleDataReader reader = command.ExecuteReader()) {
                            reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                            if (reader.HasRows) {
                                while (reader.Read()) {
                                    if (rowCount < maxRows) {
                                        int i = 0;
                                        FactValidDTO f = new FactValidDTO();
                                        f.Line = reader.GetDecimal(i);
                                        if (!reader.IsDBNull(++i)) f.ReportingLine = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.Account = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.Product = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.SubAccount = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.CostCenter = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.StoreStatus = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.DesignType = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.LocationType = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.LocationSubtype = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.LocationTierCode = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.Year = reader.GetString(i);
                                        if (!fileType.Is13Month) {
                                            if (!reader.IsDBNull(++i)) f.Month = reader.GetString(i);
                                        }
                                        a.Add(f);
                                        rowCount++;
                                    } else {
                                        // max row was reached 
                                        rowsSkipped++;
                                    }
                                }
                            }
                            reader.Close();
                        }
                        connection.Close();
                    }
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        /// <summary>
        /// new version deals with location dimensions, project 24524
        /// </summary>
        public static bool ProcessLocationAutoMappedFields(FileType fileType, int runStatusId, out string message) {
            string sqlText = string.Empty;
            bool fieldsWereAutomapped = false;
            message = string.Empty;

            try {
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = connection.CreateCommand()) {
                    connection.Open();

                    foreach (FileTypeField fileTypeField in fileType.fields) {
                        switch (fileTypeField.Source) {
                            case FileTypeFieldSource.AutomapOnAccount:
                                fieldsWereAutomapped = true;
                                string mappingColumnName = string.Empty;
                                switch (fileTypeField.FactColumnName) {
                                    case "REPORTING_LINE": mappingColumnName = "DIM_RPT_REPORTNGLINE"; break;
                                    case "SERVICE_TYPE": mappingColumnName = "DIM_RPT_SERVICETYPE"; break;
                                    case "TECH_TYPE": mappingColumnName = "DIM_RPT_TECHTYPE"; break;
                                    default: mappingColumnName = string.Format("DIM_RPT_{0}", fileTypeField.FactColumnName); break;
                                }
                                
                                sqlText = string.Format(
@"update {0} u
  set u.{1} = (
    select f.{2} from rpt_reformat_map_tbl f 
    where u.account = f.rpt_mapped_acct 
      and f.rpt_gl_product=substr(u.product,7,3) 
      and f.dim_rpt_map_id='GL' and f.{2} <> 'N/A'
  )
  where u.source='{3}'"
                                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                                    , fileTypeField.FactColumnName, mappingColumnName, fileType.FileTypeCode);
                                command.CommandText = sqlText;
                                if (runStatusId > 0) LogMessage("Location Auto-mapping using Reformat Map table (prod specific)", sqlText, null, runStatusId);
                                command.ExecuteNonQuery();

                                sqlText = string.Format(
@"update {0} u
  set u.{1} = (
    select f.{2} 
    from rpt_reformat_map_tbl f 
    where u.account = f.rpt_mapped_acct 
      and f.rpt_gl_product='*' and f.dim_rpt_map_id='GL' and f.{2} <> 'N/A'
  )
  where u.source='{2}' and u.{1} is null"
                                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                                    , fileTypeField.FactColumnName, mappingColumnName, fileType.FileTypeCode);
                                command.CommandText = sqlText;
                                if (runStatusId > 0) LogMessage("Location Auto-mapping using Reformat Map table (general)", sqlText, null, runStatusId);
                                command.ExecuteNonQuery();
                                break;
                            case FileTypeFieldSource.AutomapOnCostCenter:
                                fieldsWereAutomapped = true;                   
                                sqlText = string.Format("update {0} set {1}=null where source='{2}'"
                                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                                    , fileTypeField.FactColumnName, fileType.FileTypeCode);
                                command.CommandText = sqlText;
                                command.ExecuteNonQuery();
                                
                                sqlText = string.Format(
@"update {0} u
  set u.{1} = (
    select c.dim_rpt_function 
    from rpt_cc_to_ch_map_tbl c 
    where substr(u.cost_center,-4) = c.dim_rpt_costcenter
  )
  where u.source='{2}'"
                                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                                    , fileTypeField.FactColumnName, fileType.FileTypeCode);
                                command.CommandText = sqlText;
                                if (runStatusId > 0) LogMessage("Location Auto-mapping function based on cost center", sqlText, null, runStatusId);
                                command.ExecuteNonQuery();
                                break;
                            case FileTypeFieldSource.AutomapOnFunction:
                                fieldsWereAutomapped = true;
                                sqlText = string.Format("update {0} set {1}=null where source='{2}'"
                                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                                    , fileTypeField.FactColumnName, fileType.FileTypeCode);
                                command.CommandText = sqlText;
                                command.ExecuteNonQuery();
                                
                                sqlText = string.Format(
@"update {0} u
  set u.{1} = (
    select f.dim_rpt_costcenter 
    from rpt_fun_to_cc_map_tbl f 
    where u.function = f.dim_rpt_function
  )
  where u.source='{2}'"
                                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                                    , fileTypeField.FactColumnName, fileType.FileTypeCode);
                                command.CommandText = sqlText;
                                if (runStatusId > 0) LogMessage("Location Auto-mapping cost center based on function", sqlText, null, runStatusId);
                                command.ExecuteNonQuery();
                                break;
                            case FileTypeFieldSource.AutomapOnLocation:
                                fieldsWereAutomapped = true;
                                // jevans 8/30/2011 - edit SQL to account for new effective period dating
                                // if 13 month, use current date, otherwise, use year/month of staged data 
                                // jevans 10/26/2011 - remove the WHERE criteria that examines destination dim  
                                sqlText = string.Format(
@"update {0} u
  set u.{1} = coalesce (
    (
      select f.{1} from master_location_reference f 
      where u.location = f.location and {2} >=  f.start_period and {2} <=  f.end_period
    )
    , u.{1}
  )
  where u.source='{3}'"
                                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                                    , fileTypeField.FactColumnName
                                    , fileType.Is13Month ? DateTime.Now.ToString("yyyyMM") : "to_number(u.year || lpad(u.time, 2, '0'))"
                                    , fileType.FileTypeCode);
                                command.CommandText = sqlText;
                                if (runStatusId > 0) LogMessage(string.Format("Location Auto-mapping '{0}' based on Location Code", fileTypeField.FactColumnName), sqlText, null, runStatusId);
                                command.ExecuteNonQuery();
                                break;
                        }
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                message = ex.Message;
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                fieldsWereAutomapped = false;
            }

            return fieldsWereAutomapped;
        }

        /// <summary>
        /// new version for equipment automapping, project 24735
        /// </summary>
        public static ArrayList ProcessEquipmentAutomappedData(FileType fileType, int runStatusId, int maxRows, out string message, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            message = string.Empty;
            rowsSkipped = 0;
            
            try {
                if (ProcessEquipmentAutoMappedFields(fileType, runStatusId, out message)) {
                    if (message.Length > 0) {
                        return null;
                    }

                    sqlText = string.Format(
@"select d.line_nbr, d.reporting_line, d.kpi, d.views, d.scenario, d.service_type
    , d.function, d.cost_center, d.entity, d.equipment, d.tech_type, d.methodology_type
    , d.sale_type, d.discount_type, d.contract_term, d.fact_date
  from {0} d
  where ( d.function is null or d.cost_center is null) and d.source='{1}'",
                        fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable, fileType.FileTypeCode);

                    LogMessage("Validating all data was Auto mapped", sqlText, null, runStatusId);

                    using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                    using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                        connection.Open();

                        using (OracleDataReader reader = command.ExecuteReader()) {
                            reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                            if (reader.HasRows) {
                                while (reader.Read()) {
                                    if (rowCount < maxRows) {
                                        int i = 0;
                                        FactValidDTO f = new FactValidDTO();
                                        f.Line = reader.GetDecimal(i);
                                        if (!reader.IsDBNull(++i)) f.ReportingLine = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.CostCenter = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.MethodType = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.SaleType = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.DiscountType = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.ContractTerm = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.FactDate = reader.GetDateTime(i);
                                        a.Add(f);
                                        rowCount++;
                                    } else {
                                        // max row was reached 
                                        rowsSkipped++;
                                    }
                                }
                            }
                            reader.Close();
                        }
                        connection.Close();                        
                    }
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        /// <summary>
        /// new version deals with EQUIPMENT dimensions, project 24375
        /// </summary>
        /// <param name="fileType"></param>
        /// <param name="runStatusId"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        public static bool ProcessEquipmentAutoMappedFields(FileType fileType, int runStatusId, out string message) {
            string sqlText = string.Empty;
            bool fieldsWereAutomapped = false;
            message = string.Empty;

            try {
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = connection.CreateCommand()) {
                    connection.Open();
                    
                    foreach (FileTypeField fileTypeField in fileType.fields) {
                        switch (fileTypeField.Source) {
                            case FileTypeFieldSource.AutomapOnCostCenter:
                                fieldsWereAutomapped = true;
                                sqlText = string.Format("update {0} set {1}=null where source='{2}'"
                                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                                    , fileTypeField.FactColumnName, fileType.FileTypeCode);
                                command.CommandText = sqlText;
                                command.ExecuteNonQuery();
                                sqlText = string.Format(
@"update {0} u
  set u.{1} = (
    select c.dim_rpt_function from rpt_cc_to_ch_map_tbl c
    where substr(u.cost_center,-4) = c.dim_rpt_costcenter
  )
  where u.source='{2}'"
                                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                                    , fileTypeField.FactColumnName, fileType.FileTypeCode);

                                if (runStatusId > 0)
                                    LogMessage("Location Auto-mapping based on CostCenter", sqlText, null, runStatusId);
                                command.CommandText = sqlText;
                                command.ExecuteNonQuery();
                                break;
                            case FileTypeFieldSource.AutomapOnFunction:
                                fieldsWereAutomapped = true;
                                sqlText = string.Format("update {0} set {1}=null where source='{2}'"
                                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                                    , fileTypeField.FactColumnName, fileType.FileTypeCode);
                                command.CommandText = sqlText;
                                command.ExecuteNonQuery();
                                sqlText = string.Format(
@"update {0} u
  set u.{1} = (
    select f.dim_rpt_costcenter from rpt_fun_to_cc_map_tbl f 
    where u.function = f.dim_rpt_function
  )
  where u.source='{2}'"
                                , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                                , fileTypeField.FactColumnName, fileType.FileTypeCode);

                                if (runStatusId > 0)
                                    LogMessage("Location Auto-mapping based on Function", sqlText, null, runStatusId);
                                command.CommandText = sqlText;
                                command.ExecuteNonQuery();
                                break;
                        }
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                message = ex.Message;
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                fieldsWereAutomapped = false;
            }
            
            return fieldsWereAutomapped;
        }

        public static ArrayList ProcessDataWarehouseAutomappedData(FileType fileType, int runStatusId, int maxRows, string fiscalPeriod, out string message, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            message = string.Empty;
            rowsSkipped = 0;

            try {
                if (ProcessDataWarehouseAutoMappedFields(fileType, runStatusId, fiscalPeriod, out message)) {
                    if (message.Length > 0) {
                        return null;
                    }

                    sqlText = string.Format(
@"select d.line_nbr, d.customer_account, d.branch, d.connection_type, d.equipment, d.previous_type, d.function
    , d.kpi, d.entity, d.owning_geography, d.owning_manager, d.product, d.reporting_line, d.scenario, d.segment
    , d.service_type, d.subaccount, d.tech_type, d.version, d.vertical, d.views, d.contract_term, d.program_eligibility, d.year {0}
  from {1} d
  where d.source='{2}' and (
    d.branch is null or d.reporting_line is null or d.subaccount is null or d.service_type is null or d.function is null
    or d.owning_geography is null or d.owning_manager is null or d.vertical is null
  )  "
                        , fileType.Is13Month ? string.Empty : ", d.time "
                        , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                        , fileType.FileTypeCode);
                    LogMessage("Validating all data was Auto mapped", sqlText, null, runStatusId);
                    
                    using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                    using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                        connection.Open();

                        using (OracleDataReader reader = command.ExecuteReader()) {
                            reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                            if (reader.HasRows) {
                                while (reader.Read()) {
                                    if (rowCount < maxRows) {
                                        int i = 0;
                                        FactValidDTO f = new FactValidDTO();
                                        if (!reader.IsDBNull(i)) f.Line = reader.GetDecimal(i);
                                        if (!reader.IsDBNull(++i)) f.Account = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.Branch = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.ConnectionType = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.PreviousType = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.OwningGeo = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.OwningMgr = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.Product = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.ReportingLine = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.Segment = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.SubAccount = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.Version = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.Vertical = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.Year = reader.GetString(i);
                                        if (!fileType.Is13Month) {
                                            if (!reader.IsDBNull(++i)) f.Month = reader.GetString(i);
                                        }
                                        a.Add(f);
                                        rowCount++;
                                    } else {
                                        // max row was reached 
                                        rowsSkipped++;
                                    }
                                }
                            }
                            reader.Close();
                        }
                        connection.Close();
                    }
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        public static bool ProcessDataWarehouseAutoMappedFields(FileType fileType, int runStatusId, string fiscalPeriod, out string message) {
            string sqlText = string.Empty;
            bool fieldsWereAutomapped = false;
            string columnName = string.Empty;
            string prefix = string.Empty;

            message = string.Empty;

            try {

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = connection.CreateCommand()) {
                    connection.Open();

                    foreach (FileTypeField fileTypeField in fileType.fields) {
                        switch (fileTypeField.Source) {
                            case FileTypeFieldSource.AutomapOnVESAccount:
                                fieldsWereAutomapped = true;
                                switch (fileTypeField.DimensionTypeName.ToUpper()) {
                                    case "BRANCH":
                                        columnName = "branch_code";
                                        prefix = "BR";
                                        break;
                                    case "OWNINGGEO":
                                        columnName = "owning_region_code";
                                        prefix = "OGEO";
                                        break;
                                    case "OWNINGMGR":
                                        columnName = "avp_code";
                                        prefix = "OMGR";
                                        break;
                                    case "VERTICAL":
                                        columnName = "vertical_code";
                                        prefix = "VV";
                                        break;
                                }
                                sqlText = string.Format(
@"update {0} u
  set u.{1} = coalesce (
    (
      select v.{2} from ves_rollup v
      where u.customer_account = v.ves_account_code 
    ), u.{1}, '{3}.NONE'
  ) 
  where u.SOURCE='{4}'"
                                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                                    , fileTypeField.FactColumnName, columnName, prefix, fileType.FileTypeCode);
                                command.CommandText = sqlText;
                                if (runStatusId > 0) LogMessage(string.Format("DWH Auto-mapping '{0}' based on VES Account Code", fileTypeField.FactColumnName), sqlText, null, runStatusId);
                                command.ExecuteNonQuery();
                                break;
                        }                         
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                message = ex.Message;
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                fieldsWereAutomapped = false;
            }

            return fieldsWereAutomapped;
        }

        /// <summary>
        /// validates regular upload period
        /// </summary>
        public static ArrayList ValidateReportingPeriod(FileType fileType, bool isPeriodCheckRequired, int month, string years, int runStatusId, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                sqlText =
@"select d.linenbr, d.dim_rpt_reportngline, d.dim_rpt_account, d.dim_rpt_kpi, d.dim_rpt_view,  d.dim_rpt_years, d.dim_rpt_scenario
    , d.dim_rpt_product, d.dim_rpt_subaccount, d.dim_rpt_servicetype, d.dim_rpt_function, d.dim_rpt_costcenter, d.dim_rpt_entity
    , d.dim_rpt_company, d.dim_rpt_equipment, d.dim_rpt_techtype, d.dim_rpt_time" +
(isPeriodCheckRequired 
                ?
                string.Format( // if we need to check the period
@" from {0} d 
   where (d.dim_rpt_time <> '{1}' or d.dim_rpt_years <> '{2}') and d.prp_rpt_source='{3}'"
                    , fileType.StageMonthTable, month, years, fileType.FileTypeCode)
                :
                string.Format( // if we do not need to check the period
@"  , y.member_name 
  from {0} d left outer join web_dimensions_tbl y on d.dim_rpt_years = y.alias and y.dim_type = 'YEARS' 
  where (d.dim_rpt_time not in ('0','1','2','3','4','5','6','7','8','9','10','11','12') or y.member_name is null) 
    and d.prp_rpt_source='{1}'"
                    , fileType.StageMonthTable, fileType.FileTypeCode)
                );
                
                LogMessage("Validating Period", sqlText, null, runStatusId);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        if (reader.HasRows) {
                            while (reader.Read()) {
                                if (rowCount < maxRows) {
                                    int i = 0;
                                    FactValidDTO f = new FactValidDTO();
                                    if (!reader.IsDBNull(i)) f.Line = reader.GetDecimal(i);
                                    if (!reader.IsDBNull(++i)) f.ReportingLine = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Account = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Year = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Product = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.SubAccount = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.CostCenter = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Company = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Month = reader.GetString(i);
                                    // if the SQL included member_name, return year validation
                                    if (!isPeriodCheckRequired && !reader.IsDBNull(++i)) f.YearValid = reader.GetString(i);
                                    a.Add(f);
                                    rowCount++;
                                } else {
                                    rowsSkipped++;
                                }
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        /// <summary>
        /// validates location upload period
        /// </summary>
        public static ArrayList ValidateLocationPeriod(FileType fileType, bool isPeriodCheckRequired, int month, string years, int runStatusId, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                sqlText =
@"select d.line_nbr, d.reporting_line, d.account, d.kpi, d.views, d.year, d.scenario, d.product, d.subaccount, d.service_type
    , d.function, d.cost_center, d.location, d.equipment,  d.tech_type, d.time, d.store_status, d.design_type, d.location_type
    , d.location_subtype, d.location_tier_code " +
(isPeriodCheckRequired
                ?
                string.Format( // if we need to check the period
@" from {0} d 
   where (d.time <> '{1}' or d.year <> '{2}') and d.SOURCE='{3}'"
                    , fileType.StageMonthTable, month, years, fileType.FileTypeCode)
                :
                string.Format( // if we do not need to check the period
@"  , y.member_name 
  from {0} d left outer join v_location_dimensions y on d.year = y.alias and y.dim_type='YEAR' 
  where (d.time not in ('0','1','2','3','4','5','6','7','8','9','10','11','12') or y.member_name is null) and d.SOURCE='{1}'"
                    , fileType.StageMonthTable, fileType.FileTypeCode)
                );
                
                LogMessage("Validating Location Period", sqlText, null, runStatusId);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        if (reader.HasRows) {
                            while (reader.Read()) {
                                if (rowCount < maxRows) {
                                    int i = 0;
                                    FactValidDTO f = new FactValidDTO();
                                    if (!reader.IsDBNull(i)) f.Line = reader.GetDecimal(i);
                                    if (!reader.IsDBNull(++i)) f.ReportingLine = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Account = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Year = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Product = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.SubAccount = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.CostCenter = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Month = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.StoreStatus = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.DesignType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.LocationType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.LocationSubtype = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.LocationTierCode = reader.GetString(i);
                                    // if the SQL included member_name, return year validation
                                    if (!isPeriodCheckRequired && !reader.IsDBNull(++i)) f.YearValid = reader.GetString(i);
                                    a.Add(f);
                                    rowCount++;
                                } else {
                                    rowsSkipped++;
                                }
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        /// <summary>
        /// validates EQUIPMENT upload period 
        /// </summary>
        public static ArrayList ValidateEquipmentPeriod(FileType fileType, bool isPeriodCheckRequired, int month, string year, int runStatusId, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;
            
            try {
                sqlText = 
@"select d.line_nbr, d.fact_date, d.reporting_line, d.kpi, d.views, d.scenario, d.service_type, d.Function
    , d.cost_center, d.entity, d.equipment, d.tech_type, d.methodology_type, d.sale_type, d.discount_type
    , d.contract_term " + 
                (isPeriodCheckRequired 
                ? 
                string.Format( // if we need to check the period
@"from {0} d 
  where (to_char(d.fact_date, 'MM') <> '{1}' or to_char(d.fact_date, 'YYYY') <> '{2}') and d.source='{3}'"
                    , fileType.StageMonthTable, month.ToString("00"), year, fileType.FileTypeCode)
                :
                string.Format( // if we do not need to check the period
@"  , y.member_name
  from {0}  d left outer join v_equipment_dimensions y 
    on to_char(d.fact_date, 'YYYY') = y.alias_name and y.dimension_name='Years'
  where y.alias_name is null and d.source='{1}'"
                ,fileType.StageMonthTable, fileType.FileTypeCode));

                LogMessage("Validating Equipment Period", sqlText, null, runStatusId);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        if (reader.HasRows) {
                            while (reader.Read()) {
                                if (rowCount < maxRows) {
                                    int i = 0;
                                    FactValidDTO f = new FactValidDTO();
                                    if (!reader.IsDBNull(i)) f.Line = reader.GetDecimal(i);
                                    if (!reader.IsDBNull(++i)) f.FactDate = reader.GetDateTime(i);
                                    if (!reader.IsDBNull(++i)) f.ReportingLine = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.CostCenter = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.MethodType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.SaleType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.DiscountType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ContractTerm = reader.GetString(i);
                                    // if the SQL included member_name, return year / time validation
                                    if (!isPeriodCheckRequired && !reader.IsDBNull(++i)) f.YearValid = reader.GetString(i);
                                    a.Add(f);
                                    rowCount++;
                                } else {
                                    rowsSkipped++;
                                }
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        /// <summary>
        /// validates Data Warehouse upload period
        /// </summary>
        public static ArrayList ValidateDataWarehousePeriod(FileType fileType, bool isPeriodCheckRequired, int month, string year, int runStatusId, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                sqlText =
@"select d.line_nbr, d.customer_account, d.branch, d.connection_type, d.equipment, d.previous_type, d.function
    , d.kpi, d.entity, d.owning_geography, d.owning_manager, d.product, d.reporting_line, d.scenario, d.segment
    , d.service_type, d.subaccount, d.tech_type, d.version, d.vertical, d.views, d.contract_term, d.program_eligibility, d.year, d.time " +
                (isPeriodCheckRequired
                ? string.Format( // if we need to check the period
@"from {0} d where (d.time <> '{1}' or  d.year <> '{2}') and d.source='{3}'"
                    , fileType.StageMonthTable, month, year, fileType.FileTypeCode)
                : string.Format( // if we do not need to check the period
@", y.member_name from {0} d left outer join v_dw_dimensions y on d.year=y.alias_name and y.dimension_name='Years' 
  where y.member_name is null and d.source ='{1}'"
                , fileType.StageMonthTable, fileType.FileTypeCode));

                LogMessage("Validating Data Warehouse Period", sqlText, null, runStatusId);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        if (reader.HasRows) {
                            while (reader.Read()) {
                                if (rowCount < maxRows) {
                                    int i = 0;
                                    FactValidDTO f = new FactValidDTO();
                                    if (!reader.IsDBNull(i)) f.Line = reader.GetDecimal(i);
                                    if (!reader.IsDBNull(++i)) f.Account = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Branch = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ConnectionType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.PreviousType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.OwningGeo = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.OwningMgr = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Product = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ReportingLine = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Segment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.SubAccount = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Version = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Vertical = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ContractTerm = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ProgramEligible = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Year = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Month = reader.GetString(i);
                                    // if the SQL included member_name, return year / time validation
                                    if (!isPeriodCheckRequired && !reader.IsDBNull(++i)) f.YearValid = reader.GetString(i);
                                    a.Add(f);
                                    rowCount++;
                                } else {
                                    rowsSkipped++;
                                }
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        /// <summary>
        /// This method was added to validate the year selected against the year column in the stage table.  
        /// This is required because later steps use the selected year for the unpivot operation.
        /// </summary>
        /// <param name="fileType">Various information about the file uploaded.</param>
        /// <param name="year">Year to be validated (from dropdown on screen)</param>
        /// <param name="runStatusId">Run status id for logging</param>
        /// <returns>true if the year matches the file, otherwise false</returns>
        public static bool IsYearValid(FileType fileType, int year, int runStatusId) {
            string sqlText = string.Empty;
            bool returnValue = false;

                        
            try {
                switch ((FactTable)fileType.FactTableId) {
                case FactTable.LocationUser:
                case FactTable.DataWarehouseUser:
                        sqlText = string.Format("select count(*) from {0} where source = '{1}' and year <> '{2}'", fileType.StageYearTable, fileType.FileTypeCode, year.ToString());
                        break;
                case FactTable.EquipmentUser:
                    return true; // 13 month uploads not allowed for equipment
                default:
                    sqlText = string.Format("select count(*) from {0} where prp_rpt_source = '{1}' and dim_rpt_years <> '{2}'", fileType.StageYearTable, fileType.FileTypeCode, year.ToString());
                    break;
                }

                LogMessage("Validating year", sqlText, null, runStatusId);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();
                    returnValue = (int.Parse(command.ExecuteScalar().ToString()) == 0);
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
            }
            return returnValue;
        }

        /// <summary>
        /// detects duplicate key combinations in resulting stage table
        /// </summary>
        /// <param name="fileType"></param>
        /// <param name="runStatusId"></param>
        /// <param name="maxRows"></param>
        /// <param name="rowsSkipped"></param>
        /// <returns></returns>
        public static ArrayList ValidateReportingDuplicateRows(FileType fileType, int runStatusId, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                sqlText = string.Format(
@"select count(1), d.dim_rpt_reportngline, d.dim_rpt_account, d.dim_rpt_kpi, d.dim_rpt_view, d.dim_rpt_scenario
    , d.dim_rpt_product, d.dim_rpt_subaccount, d.dim_rpt_servicetype, d.dim_rpt_function, d.dim_rpt_costcenter
    , d.dim_rpt_entity, d.dim_rpt_company, d.dim_rpt_equipment, d.dim_rpt_techtype, d.dim_rpt_years {2} 
  from {0} d 
  where d.prp_rpt_source='{1}'
  group by d.dim_rpt_reportngline,d.dim_rpt_account,d.dim_rpt_kpi, d.dim_rpt_view,d.dim_rpt_years
    , d.dim_rpt_scenario,d.dim_rpt_product,d.dim_rpt_subaccount, d.dim_rpt_servicetype
    , d.dim_rpt_function,d.dim_rpt_costcenter,d.dim_rpt_entity,d.dim_rpt_company
    , d.dim_rpt_equipment, d.dim_rpt_techtype {2}
  having count(1) > 1"
                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                    , fileType.FileTypeCode
                    , fileType.Is13Month ? string.Empty : ", d.dim_rpt_time"
                );
                LogMessage("Checking for Duplicate Keys", sqlText, null, runStatusId); 
                 
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        if (reader.HasRows) {
                            while (reader.Read()) {
                                if (rowCount < maxRows) {
                                    int i = 0;
                                    FactValidDTO f = new FactValidDTO();
                                    f.Line = reader.GetDecimal(i);
                                    if (!reader.IsDBNull(++i)) f.ReportingLine = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Account = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Product = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.SubAccount = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.CostCenter = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Company = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Year = reader.GetString(i);
                                    if (!fileType.Is13Month && !reader.IsDBNull(++i)) f.Month = reader.GetString(i);
                                    a.Add(f);
                                    rowCount++;
                                } else {
                                    // max row was reached 
                                    rowsSkipped++;
                                }
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        /// <summary>
        /// location dimensions version, project 24524
        /// </summary>
        /// <param name="fileType"></param>
        /// <param name="runStatusId"></param>
        /// <param name="maxRows"></param>
        /// <param name="rowsSkipped"></param>
        /// <returns></returns>
        public static ArrayList ValidateLocationDuplicateRows(FileType fileType, int runStatusId, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                sqlText = string.Format(
@"select count(1), d.reporting_line, d.account, d.kpi, d.views, d.year, d.scenario, d.product, d.subaccount, d.service_type
    , d.function, d.cost_center, d.location, d.equipment, d.tech_type, d.store_status, d.design_type, d.location_type
    , d.location_subtype, d.location_tier_code {2}
  from {0} d
  where d.source='{1}'
  group by  d.reporting_line, d.account, d.kpi, d.views, d.year, d.scenario, d.product, d.subaccount, d.service_type
    , d.function, d.cost_center, d.location, d.equipment,  d.tech_type, d.store_status,  d.design_type, d.location_type
    , d.location_subtype, d.location_tier_code {2} 
  having count(1) > 1"
                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                    , fileType.FileTypeCode
                    , fileType.Is13Month ? string.Empty : ", d.time"
                );
                LogMessage("Checking for Duplicate Location Keys", sqlText, null, runStatusId);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        if (reader.HasRows) {
                            while (reader.Read()) {
                                if (rowCount < maxRows) {
                                    int i = 0;
                                    FactValidDTO f = new FactValidDTO();
                                    f.Line = reader.GetDecimal(i);
                                    if (!reader.IsDBNull(++i)) f.ReportingLine = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Account = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Year = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Product = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.SubAccount = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.CostCenter = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.StoreStatus = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.DesignType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.LocationType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.LocationSubtype = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.LocationTierCode = reader.GetString(i);
                                    if (!fileType.Is13Month && !reader.IsDBNull(++i)) f.Month = reader.GetString(i);
                                    a.Add(f);
                                    rowCount++;
                                } else {
                                    // max row was reached 
                                    rowsSkipped++;
                                }
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        public static ArrayList ValidateEquipmentDuplicateRows(FileType fileType, int runStatusId, int maxRows, bool checkdate, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                sqlText = string.Format(
@"select count(1), {0} d.reporting_line, d.kpi, d.views, d.scenario, d.service_type, d.Function, d.cost_center
    , d.entity, d.equipment, d.tech_type, d.methodology_type, d.sale_type, d.discount_type, d.contract_term
  from {1} d
  where d.source='{2}'
  group by {0} d.reporting_line, d.kpi, d.views, d.scenario, d.service_type, d.Function, d.cost_center
    , d.entity, d.equipment, d.tech_type, d.methodology_type, d.sale_type, d.discount_type, d.contract_term 
  having count(1) > 1"
                    , checkdate ? "d.fact_date," : string.Empty
                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                    , fileType.FileTypeCode);
                LogMessage("Checking for Duplicate Equipment Keys", sqlText, null, runStatusId);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        if (reader.HasRows) {
                            while (reader.Read()) {
                                if (rowCount < maxRows) {
                                    int i = 0;
                                    FactValidDTO f = new FactValidDTO();
                                    f.Line = reader.GetDecimal(i);
                                    if (checkdate && !reader.IsDBNull(++i)) f.FactDate = reader.GetDateTime(i);
                                    if (!reader.IsDBNull(++i)) f.ReportingLine = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.CostCenter = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.MethodType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.SaleType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.DiscountType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ContractTerm = reader.GetString(i);
                                    a.Add(f);
                                    rowCount++;
                                } else {
                                    // max row was reached 
                                    rowsSkipped++;
                                }
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        public static ArrayList ValidateDataWarehouseDuplicateRows(FileType fileType, int runStatusId, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                sqlText = string.Format(
@"select count(1), d.customer_account, d.branch, d.connection_type, d.equipment, d.previous_type, d.function, d.kpi
    , d.entity, d.owning_geography, d.owning_manager, d.product, d.reporting_line, d.scenario, d.segment, d.service_type
    , d.subaccount, d.tech_type, d.version, d.vertical, d.views, d.contract_term, d.program_eligibility, d.year {2}
  from {0} d 
  where d.source='{1}'
  group by d.customer_account, d.branch, d.connection_type, d.equipment, d.previous_type, d.function, d.kpi
    , d.entity, d.owning_geography, d.owning_manager, d.product, d.reporting_line, d.scenario, d.segment
    , d.service_type, d.subaccount, d.tech_type, d.version, d.vertical, d.views, d.contract_term, d.program_eligibility, d.year {2}   
  having count(1) > 1"
                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                    , fileType.FileTypeCode
                    , fileType.Is13Month ? string.Empty : ", d.time"
                );
                LogMessage("Checking for Duplicate Data Warehouse Keys", sqlText, null, runStatusId);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        if (reader.HasRows) {
                            while (reader.Read()) {
                                if (rowCount < maxRows) {
                                    int i = 0;
                                    FactValidDTO f = new FactValidDTO();
                                    f.Line = reader.GetDecimal(i);
                                    if (!reader.IsDBNull(++i)) f.Account = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Branch = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ConnectionType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.PreviousType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.OwningGeo = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.OwningMgr = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Product = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ReportingLine = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Segment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.SubAccount = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Version = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Vertical = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ContractTerm = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ProgramEligible = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Year = reader.GetString(i);
                                    if (!fileType.Is13Month && !reader.IsDBNull(++i)) f.Month = reader.GetString(i);
                                    a.Add(f);
                                    rowCount++;
                                } else {
                                    // max row was reached 
                                    rowsSkipped++;
                                }
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        /// <summary>
        /// validate adjustment scenarios
        /// </summary>
        public static ArrayList ValidateReportingAdjustmentScenario(FileType fileType, string validAdjustmentScenarios, int runStatusId, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                string[] adjustmentScenarios = validAdjustmentScenarios.Split('|');
                string likeClause = string.Empty;
                string inClause = string.Empty;
                string optionalNotKeyword = fileType.IsAdjustment ? " not " : string.Empty;
                string andOrKeyword = fileType.IsAdjustment ? " and " : " or ";

                foreach (string scenario in adjustmentScenarios) {
                    if (scenario.Contains("%")) {
                        if (likeClause.Length > 0)
                            likeClause += andOrKeyword;
                        likeClause += string.Format("{0} d.dim_rpt_scenario like '{1}'", optionalNotKeyword, scenario);
                    } else {
                        if (inClause.Length > 0)
                            inClause += ",";
                        inClause += "'" + scenario + "'";
                    }
                }

                sqlText = string.Format(
@"select d.linenbr, d.dim_rpt_years, d.dim_rpt_reportngline, d.dim_rpt_account, d.dim_rpt_kpi, d.dim_rpt_view
    , d.dim_rpt_scenario, d.dim_rpt_product, d.dim_rpt_subaccount, d.dim_rpt_servicetype, d.dim_rpt_function
    , d.dim_rpt_costcenter, d.dim_rpt_entity, d.dim_rpt_company, d.dim_rpt_equipment, d.dim_rpt_techtype {0}
  from {1} d where d.prp_rpt_source='{2}' and ({3} {4} {5})"
                    , fileType.Is13Month ? "" : ", d.dim_rpt_time "
                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                    , fileType.FileTypeCode
                    , (inClause.Length > 0) ? string.Format(" d.dim_rpt_scenario {0} in ({1})", optionalNotKeyword, inClause) : string.Empty
                    , (likeClause.Length > 0 && inClause.Length > 0) ? andOrKeyword : string.Empty
                    , (inClause.Length > 0) ? string.Format(" ({0})", likeClause) : string.Empty);
                LogMessage("Validating Adj Scenario", sqlText, null, runStatusId);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        if (reader.HasRows) {
                            while (reader.Read()) {
                                if (rowCount < maxRows) {
                                    int i = 0;
                                    FactValidDTO f = new FactValidDTO();
                                    f.Line = reader.GetDecimal(i);
                                    if (!reader.IsDBNull(++i)) f.Year = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ReportingLine = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Account = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Product = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.SubAccount = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.CostCenter = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Company = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                    if (!fileType.Is13Month && !reader.IsDBNull(++i)) f.Month = reader.GetString(i);
                            
                                    a.Add(f);
                                    rowCount++;
                                } else {
                                    // max row was reached 
                                    rowsSkipped++;
                                }
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;       
        }

        public static ArrayList ValidateLocationAdjustmentScenario(FileType fileType, string validAdjustmentScenarios, int runStatusId, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                string[] adjustmentScenarios = validAdjustmentScenarios.Split('|');
                string likeClause = string.Empty;
                string inClause = string.Empty;
                string optionalNotKeyword = fileType.IsAdjustment ? " not " : string.Empty;
                string andOrKeyword = fileType.IsAdjustment ? " and " : " or ";

                foreach (string scenario in adjustmentScenarios) {
                    if (scenario.Contains("%")) {
                        if (likeClause.Length > 0)
                            likeClause += andOrKeyword;
                        likeClause += string.Format("{0} d.scenario like '{1}'", optionalNotKeyword, scenario);
                    } else {
                        if (inClause.Length > 0)
                            inClause += ",";
                        inClause += "'" + scenario + "'";
                    }
                }

                sqlText = string.Format(
@"select d.line_nbr, d.reporting_line, d.account, d.kpi, d.views, d.year, d.scenario, d.product, d.subaccount
    , d.service_type, d.function, d.cost_center, d.location, d.equipment, d.tech_type, d.store_status
    , d.design_type, d.location_type, d.location_subtype, d.location_tier_code {0} 
  from {1} d where d.source='{2}' and ({3} {4} {5})"
                    , fileType.Is13Month ? "" : ", d.time  "
                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                    , fileType.FileTypeCode
                    , (inClause.Length > 0) ? string.Format(" d.scenario {0} in ({1})", optionalNotKeyword, inClause) : string.Empty
                    , (likeClause.Length > 0 && inClause.Length > 0) ? andOrKeyword : string.Empty
                    , (inClause.Length > 0) ? string.Format(" ({0})", likeClause) : string.Empty);
                LogMessage("Validating Location Adj Scenario", sqlText, null, runStatusId);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        if (reader.HasRows) {
                            while (reader.Read()) {
                                if (rowCount < maxRows) {
                                    int i = 0;
                                    FactValidDTO f = new FactValidDTO();
                                    f.Line = reader.GetDecimal(i);
                                    if (!reader.IsDBNull(++i)) f.ReportingLine = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Account = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Year = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Product = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.SubAccount = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.CostCenter = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.StoreStatus = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.DesignType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.LocationType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.LocationSubtype = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.LocationTierCode = reader.GetString(i);
                                    if (!fileType.Is13Month && !reader.IsDBNull(++i)) f.Month = reader.GetString(i);
                                    a.Add(f);
                                    rowCount++;
                                } else {
                                    // max row was reached 
                                    rowsSkipped++;
                                }
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;       
        }

        public static ArrayList ValidateEquipmentAdjustmentScenario(FileType fileType, string validAdjustmentScenarios, int runStatusId, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                string[] adjustmentScenarios = validAdjustmentScenarios.Split('|');
                string likeClause = string.Empty;
                string inClause = string.Empty;
                string optionalNotKeyword = fileType.IsAdjustment ? " not " : string.Empty;
                string andOrKeyword = fileType.IsAdjustment ? " and " : " or ";
                
                foreach (string scenario in adjustmentScenarios) {
                    if (scenario.Contains("%")) {
                        if (likeClause.Length > 0)
                            likeClause += andOrKeyword;
                        likeClause += string.Format("{0} d.scenario like '{1}'", optionalNotKeyword, scenario);
                    } else {
                        if (inClause.Length > 0)
                            inClause += ",";
                        inClause += "'" + scenario + "'";
                    }
                }

                sqlText = string.Format(
@"select d.line_nbr, d.fact_date, d.reporting_line, d.kpi, d.views, d.scenario, d.service_type
    , d.function, d.cost_center, d.entity, d.equipment, d.tech_type, d.methodology_type
    , d.sale_type, d.discount_type, d.contract_term 
  from {0} d where d.source='{1}' and ({2} {3} {4})"
                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                    , fileType.FileTypeCode
                    , (inClause.Length > 0) ? string.Format(" d.scenario {0} in ({1})", optionalNotKeyword, inClause) : string.Empty
                    , (likeClause.Length > 0 && inClause.Length > 0) ? andOrKeyword : string.Empty
                    , (inClause.Length > 0) ? string.Format(" ({0})", likeClause) : string.Empty);
                LogMessage("Validating EQUIPMENT Adj Scenario", sqlText, null, runStatusId);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        if (reader.HasRows) {
                            while (reader.Read()) {
                                if (rowCount < maxRows) {
                                    int i = 0;
                                    FactValidDTO f = new FactValidDTO();
                                    f.Line = reader.GetDecimal(i);
                                    if (!reader.IsDBNull(++i)) f.FactDate = reader.GetDateTime(i);
                                    if (!reader.IsDBNull(++i)) f.ReportingLine = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.CostCenter = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.MethodType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.SaleType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.DiscountType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ContractTerm = reader.GetString(i);
                                    a.Add(f);
                                    rowCount++;
                                } else {
                                    // max row was reached 
                                    rowsSkipped++;
                                }
                            }
                        }                        
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        public static ArrayList ValidateDataWarehouseAdjustmentScenario(FileType fileType, string validAdjustmentScenarios, int runStatusId, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                string[] adjustmentScenarios = validAdjustmentScenarios.Split('|');
                string likeClause = string.Empty;
                string inClause = string.Empty;
                string optionalNotKeyword = fileType.IsAdjustment ? " not " : string.Empty;
                string andOrKeyword = fileType.IsAdjustment ? " and " : " or ";

                foreach (string scenario in adjustmentScenarios) {
                    if (scenario.Contains("%")) {
                        if (likeClause.Length > 0)
                            likeClause += andOrKeyword;
                        likeClause += string.Format("{0} d.scenario like '{1}'", optionalNotKeyword, scenario);
                    } else {
                        if (inClause.Length > 0)
                            inClause += ",";
                        inClause += "'" + scenario + "'";
                    }
                }

                sqlText = string.Format(
@"select d.line_nbr, d.customer_account, d.branch, d.connection_type, d.equipment, d.previous_type, d.function, d.kpi
    , d.entity, d.owning_geography, d.owning_manager, d.product, d.reporting_line, d.scenario, d.segment, d.service_type
    , d.subaccount, d.tech_type, d.version, d.vertical, d.views, d.contract_term, d.program_eligibility, d.year {0}   
  from {1} d where d.SOURCE='{2}' and ({3} {4} {5})"
                    , fileType.Is13Month ? "" : ", d.time  "
                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                    , fileType.FileTypeCode
                    , (inClause.Length > 0) ? string.Format(" d.scenario {0} in ({1})", optionalNotKeyword, inClause) : string.Empty
                    , (likeClause.Length > 0 && inClause.Length > 0) ? andOrKeyword : string.Empty
                    , (inClause.Length > 0) ? string.Format(" ({0})", likeClause) : string.Empty);
                LogMessage("Validating Data Warehouse Adj Scenario", sqlText, null, runStatusId);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        if (reader.HasRows) {
                            while (reader.Read()) {
                                if (rowCount < maxRows) {
                                    int i = 0;
                                    FactValidDTO f = new FactValidDTO();
                                    f.Line = reader.GetDecimal(i);
                                    if (!reader.IsDBNull(++i)) f.Account = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Branch = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ConnectionType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.PreviousType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.OwningGeo = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.OwningMgr = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Product = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ReportingLine = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Segment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.SubAccount = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Version = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Vertical = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ContractTerm = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ProgramEligible = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Year = reader.GetString(i);
                                    if (!fileType.Is13Month && !reader.IsDBNull(++i)) f.Month = reader.GetString(i);
                                    a.Add(f);
                                    rowCount++;
                                } else {
                                    // max row was reached 
                                    rowsSkipped++;
                                }
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        /// <summary>
        /// Detect dimension combinations in another source file type
        /// </summary>
        public static ArrayList ValidateReportingDimensionSource(FileType fileType, int runStatusId, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                sqlText = string.Format(
@"select a.linenbr, a.dim_rpt_reportngline, a.dim_rpt_account, a.dim_rpt_kpi, a.dim_rpt_view, a.dim_rpt_years
    , a.dim_rpt_scenario, a.dim_rpt_product, a.dim_rpt_subaccount, a.dim_rpt_servicetype, a.dim_rpt_function
    , a.dim_rpt_costcenter, a.dim_rpt_entity, a.dim_rpt_company, a.dim_rpt_equipment, a.dim_rpt_techtype, f.prp_rpt_source {3}
  from {0} a join {1} f on a.dim_rpt_reportngline=f.dim_rpt_reportngline and a.dim_rpt_account=f.dim_rpt_account 
    and a.dim_rpt_kpi=f.dim_rpt_kpi and a.dim_rpt_view=f.dim_rpt_view and a.dim_rpt_years=f.dim_rpt_years
    and a.dim_rpt_scenario=f.dim_rpt_scenario and a.dim_rpt_product=f.dim_rpt_product and a.dim_rpt_subaccount=f.dim_rpt_subaccount
    and a.dim_rpt_servicetype=f.dim_rpt_servicetype and a.dim_rpt_function=f.dim_rpt_function 
    and a.dim_rpt_costcenter=f.dim_rpt_costcenter and a.dim_rpt_entity=f.dim_rpt_entity and a.dim_rpt_company=f.dim_rpt_company
    and a.dim_rpt_equipment=f.dim_rpt_equipment and a.dim_rpt_techtype=f.dim_rpt_techtype 
  where a.prp_rpt_source = '{2}' and f.prp_rpt_source <> '{2}'
  order by a.linenbr"
                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                    , fileType.DestinationTable, fileType.FileTypeCode
                    , fileType.Is13Month ? string.Empty : ", a.dim_rpt_time");
                LogMessage("Validating Dimension Source", sqlText, null, runStatusId);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        if (reader.HasRows) {
                            while (reader.Read()) {
                                if (rowCount < maxRows) {
                                    int i = 0;
                                    FactValidDTO f = new FactValidDTO();
                                    f.Line = reader.GetDecimal(i);
                                    f.ReportingLine = reader.GetString(++i);
                                    f.Account = reader.GetString(++i);
                                    f.KPI = reader.GetString(++i);
                                    f.View = reader.GetString(++i);
                                    f.Year = reader.GetString(++i);
                                    f.Scenario = reader.GetString(++i);
                                    f.Product = reader.GetString(++i);
                                    f.SubAccount = reader.GetString(++i);
                                    f.ServiceType = reader.GetString(++i);
                                    f.Function = reader.GetString(++i);
                                    f.CostCenter = reader.GetString(++i);
                                    f.Entity = reader.GetString(++i);
                                    f.Company = reader.GetString(++i);
                                    f.Equipment = reader.GetString(++i);
                                    f.TechType = reader.GetString(++i);
                                    f.Source = reader.GetString(++i);
                                    if (!fileType.Is13Month) f.Month = reader.GetString(++i);
                                    a.Add(f);
                                    rowCount++;
                                } else {
                                    // max row was reached 
                                    rowsSkipped++;
                                }
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        /// <summary>
        /// location version detects dims in another file type 
        /// </summary>
        public static ArrayList ValidateLocationDimensionSource(FileType fileType, int runStatusId, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                sqlText = string.Format(
@"select distinct a.line_nbr, a.reporting_line, a.account, a.kpi, a.views, a.year, a.scenario, a.product, a.subaccount
    , a.service_type, a.function, a.cost_center, a.location, a.equipment, a.tech_type, a.store_status, a.design_type
    , a.location_type, a.location_subtype, a.location_tier_code, f.source {3} 
  from {0} a join {2} f on a.reporting_line = f.reporting_line and a.account = f.account and a.kpi = f.kpi
    and a.views = f.views and a.scenario = f.scenario and a.product = f.product and a.subaccount = f.subaccount
    and a.service_type = f.service_type and a.function = f.function and a.cost_center = f.cost_center
    and a.location = f.location and a.equipment = f.equipment and a.store_status = f.store_status 
    and a.tech_type = f.tech_type and a.design_type = f.design_type and a.location_type = f.location_type 
    and a.location_subtype = f.location_subtype and a.location_tier_code = f.location_tier_code 
  where a.source = '{1}' and f.source <> '{1}'
  order by a.line_nbr"
                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                    , fileType.FileTypeCode, fileType.DestinationTable
                    , fileType.Is13Month ? string.Empty : ", a.time ");
                LogMessage("Validating Location Dimension Source", sqlText, null, runStatusId);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        if (reader.HasRows) {
                            while (reader.Read()) {
                                if (rowCount < maxRows) {
                                    int i = 0;
                                    FactValidDTO f = new FactValidDTO();
                                    f.Line = reader.GetDecimal(i);
                                    f.ReportingLine = reader.GetString(++i);
                                    f.Account = reader.GetString(++i);
                                    f.KPI = reader.GetString(++i);
                                    f.View = reader.GetString(++i);
                                    f.Year = reader.GetString(++i);
                                    f.Scenario = reader.GetString(++i);
                                    f.Product = reader.GetString(++i);
                                    f.SubAccount = reader.GetString(++i);
                                    f.ServiceType = reader.GetString(++i);
                                    f.Function = reader.GetString(++i);
                                    f.CostCenter = reader.GetString(++i);
                                    f.Entity = reader.GetString(++i);
                                    f.Equipment = reader.GetString(++i);
                                    f.TechType = reader.GetString(++i);
                                    f.StoreStatus = reader.GetString(++i);
                                    f.DesignType = reader.GetString(++i);
                                    f.LocationType = reader.GetString(++i);
                                    f.LocationSubtype = reader.GetString(++i);
                                    f.LocationTierCode = reader.GetString(++i);
                                    f.Source = reader.GetString(++i);
                                    if (!fileType.Is13Month) f.Month = reader.GetString(++i);
                                    a.Add(f);
                                    rowCount++;
                                } else {
                                    // max row was reached 
                                    rowsSkipped++;
                                }
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        /// <summary>
        /// EQUIPMENT version detects dims in another file type 
        /// </summary>
        /// <param name="fileType"></param>
        /// <param name="scenario"></param>
        /// <param name="runStatusId"></param>
        /// <param name="maxRows"></param>
        /// <param name="rowsSkipped"></param>
        /// <returns></returns>
        public static ArrayList ValidateEquipmentDimensionSource(FileType fileType, int runStatusId, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                sqlText = string.Format(
@"select distinct a.line_nbr, a.reporting_line, a.kpi, a.views, a.scenario, a.service_type, a.function, a.cost_center
    , a.entity, a.equipment, a.tech_type, a.methodology_type, a.sale_type, a.discount_type, a.contract_term, f.source 
  from {0} a join {2} f on a.reporting_line=f.reporting_line and a.kpi=f.kpi and a.views=f.views and a.scenario=f.scenario
    and a.service_type=f.service_type and a.function=f.function and a.cost_center=f.cost_center and a.entity=f.entity
    and a.equipment=f.equipment and a.tech_type = f.tech_type and a.methodology_type=f.methodology_type and a.sale_type=f.sale_type
    and a.discount_type=f.discount_type and a.contract_term = f.contract_term
  where a.source = '{1}' and f.source <> '{1}'
  order by a.line_nbr"
                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                    , fileType.FileTypeCode, fileType.DestinationTable);
                LogMessage("Validating EQUIPMENT Dimension Source", sqlText, null, runStatusId);
                    
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        if (reader.HasRows) {
                            while (reader.Read()) {
                                if (rowCount < maxRows) {
                                    int i = 0;
                                    FactValidDTO f = new FactValidDTO();
                                    f.Line = reader.GetDecimal(i++);
                                    f.ReportingLine = reader.GetString(i++);
                                    f.KPI = reader.GetString(i++);
                                    f.View = reader.GetString(i++);
                                    f.Scenario = reader.GetString(i++);
                                    f.ServiceType = reader.GetString(i++);
                                    f.Function = reader.GetString(i++);
                                    f.CostCenter = reader.GetString(i++);
                                    f.Entity = reader.GetString(i++);
                                    f.Equipment = reader.GetString(i++);
                                    f.TechType = reader.GetString(i++);
                                    f.MethodType = reader.GetString(i++);
                                    f.SaleType = reader.GetString(i++);
                                    f.DiscountType = reader.GetString(i++);
                                    f.ContractTerm = reader.GetString(i++);
                                    f.Source = reader.GetString(i++);
                                    a.Add(f);
                                    rowCount++;
                                } else {
                                    // max row was reached 
                                    rowsSkipped++;
                                }
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        /// <summary>
        /// Service version detects dims in another file type 
        /// </summary>
        public static ArrayList ValidateDataWarehouseDimensionSource(FileType fileType, int runStatusId, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                sqlText = string.Format(
@"select distinct a.line_nbr, a.customer_account, a.branch, a.connection_type, a.equipment, a.previous_type, a.function, a.kpi
    , a.entity, a.owning_geography, a.owning_manager, a.product, a.reporting_line, a.scenario, a.segment, a.service_type
    , a.subaccount, a.tech_type, a.version, a.vertical, a.views, a.contract_term, a.program_eligibility, a.year, f.source {0}
  from {1} a join {2} f on a.customer_account=f.customer_account and a.branch=f.branch and a.connection_type = f.connection_type 
    and a.equipment=f.equipment and a.previous_type=f.previous_type and a.function=f.function and a.kpi=f.kpi
    and a.entity=f.entity and a.owning_geography=f.owning_geography and a.owning_manager=f.owning_manager and a.product=f.product
    and a.reporting_line=f.reporting_line and a.scenario=f.scenario and a.segment=f.segment and a.service_type=f.service_type
    and a.subaccount=f.subaccount and a.tech_type=f.tech_type and a.version=f.version and a.vertical=f.vertical 
    and a.views=f.views and a.contract_term = f.contract_term and a.program_eligibility=f.program_eligibility 
  where a.source = '{3}' and f.source <> '{3}'
  order by a.line_nbr"
                    , fileType.Is13Month ? string.Empty : ", a.time "
                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                    , fileType.DestinationTable, fileType.FileTypeCode
                 );
                    
                LogMessage("Validating Data Warehouse Dimension Source", sqlText, null, runStatusId);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        if (reader.HasRows) {
                            while (reader.Read()) {
                                if (rowCount < maxRows) {
                                    int i = 0;
                                    FactValidDTO f = new FactValidDTO();
                                    f.Line = reader.GetDecimal(i);
                                    if (!reader.IsDBNull(++i)) f.Account = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Branch = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ConnectionType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.PreviousType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.OwningGeo = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.OwningMgr = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Product = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ReportingLine = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Segment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.SubAccount = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Version = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Vertical = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Year = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Source = reader.GetString(i);
                                    if (!fileType.Is13Month && !reader.IsDBNull(++i)) f.Month = reader.GetString(i);
                                    a.Add(f);
                                    rowCount++;
                                } else {
                                    // max row was reached 
                                    rowsSkipped++;
                                }
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        /// <summary>
        /// return array of rows that contain protected reporting lines
        /// </summary>
        /// <param name="fileType"></param>
        /// <param name="runStatusId"></param>
        /// <param name="maxRows"></param>
        /// <param name="rowsSkipped"></param>
        /// <returns></returns>
        public static ArrayList ValidateReportingCoaCor(FileType fileType, int runStatusId, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                sqlText = string.Format(
@"select d.linenbr, d.dim_rpt_reportngline, d.dim_rpt_account, d.dim_rpt_kpi, d.dim_rpt_view, d.dim_rpt_years
    , d.dim_rpt_scenario, d.dim_rpt_product, d.dim_rpt_subaccount, d.dim_rpt_servicetype, d.dim_rpt_function
    , d.dim_rpt_costcenter, d.dim_rpt_entity, d.dim_rpt_company, d.dim_rpt_equipment, d.dim_rpt_techtype {2}
  from {0} d join web_coacor_rl_tbl c on d.dim_rpt_reportngline=c.reportingline
  where not c.reportingline is null and not d.dim_rpt_subaccount like 'SA.SG.%' and d.prp_rpt_source = '{1}'
  order by d.linenbr"
                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                    , fileType.FileTypeCode, fileType.Is13Month ? string.Empty : ", d.dim_rpt_time");

                LogMessage("Validating COA / COR", sqlText, null, runStatusId);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        if (reader.HasRows) {
                            while (reader.Read()) {
                                if (rowCount < maxRows) {
                                    int i = 0;
                                    FactValidDTO f = new FactValidDTO();
                                    if (!reader.IsDBNull(++i)) f.ReportingLine = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Account = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Year = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Product = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.SubAccount = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.CostCenter = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Company = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                    if (!fileType.Is13Month && !reader.IsDBNull(++i)) f.Month = reader.GetString(i);
                                    a.Add(f);
                                    rowCount++;
                                } else {
                                    // max row was reached 
                                    rowsSkipped++;
                                }
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }
        
        /// <summary>
        ///  check dims against validation or master dim tables
        /// </summary>
        public static ArrayList ValidateReportingDimensionFields(FileType fileType, int runStatusId, int maxRows, out string message, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;
            message = string.Empty;

            try {
                if (fileType.UsesValidKeyCombos) {
                    //  Select any items that don't exist in the Validate table.
                    sqlText = string.Format(
@"select d.linenbr, d.dim_rpt_reportngline, d.dim_rpt_account, d.dim_rpt_kpi, d.dim_rpt_view, d.dim_rpt_years, d.dim_rpt_scenario
    , d.dim_rpt_product, d.dim_rpt_subaccount, d.dim_rpt_servicetype, d.dim_rpt_function, d.dim_rpt_costcenter, d.dim_rpt_entity
    , d.dim_rpt_company, d.dim_rpt_equipment, d.dim_rpt_techtype, f.prp_rpt_source {4}
  from {0} d left outer join {2} f on {3} d.dim_rpt_reportngline=f.dim_rpt_reportngline and d.dim_rpt_account=f.dim_rpt_account 
    and d.dim_rpt_kpi=f.dim_rpt_kpi and d.dim_rpt_view=f.dim_rpt_view and d.dim_rpt_product=f.dim_rpt_product
    and d.dim_rpt_subaccount=f.dim_rpt_subaccount and d.dim_rpt_servicetype=f.dim_rpt_servicetype 
    and d.dim_rpt_function=f.dim_rpt_function and d.dim_rpt_costcenter=f.dim_rpt_costcenter 
    and d.dim_rpt_entity=f.dim_rpt_entity and d.dim_rpt_company=f.dim_rpt_company and d.dim_rpt_Equipment=f.dim_rpt_equipment 
    and d.dim_rpt_techtype=f.dim_rpt_techtype
  where (f.prp_rpt_source is null or f.prp_rpt_source <> '{1}') and d.prp_rpt_source='{1}'
  order by d.linenbr"
                        , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                        , fileType.FileTypeCode, fileType.ValidationKeyTable
                        , fileType.IsOutlook ? "f.dim_rpt_scenario like 'SC.O.%' and " : "d.dim_rpt_scenario=f.dim_rpt_scenario and "
                        , fileType.Is13Month ? string.Empty : ", dim_rpt_time");
                } else {
                    //  Validate individual fields against the Dimensions Table  
                    sqlText = string.Format(
@"select d.linenbr, d.dim_rpt_reportngline, d.dim_rpt_account, d.dim_rpt_kpi, d.dim_rpt_view, d.dim_rpt_years, d.dim_rpt_scenario
    , d.dim_rpt_product, d.dim_rpt_subaccount, d.dim_rpt_servicetype, d.dim_rpt_function, d.dim_rpt_costcenter, d.dim_rpt_entity
    , d.dim_rpt_company, d.dim_rpt_equipment, d.dim_rpt_techtype, '' as prp_rpt_source {2},
    
    r.Member_Name as ReportingLine, a.Member_Name as Account, k.Member_Name as KPI, v.Member_Name as RptView, y.Alias as Years
    , s.Member_Name as Scenario, p.Member_Name as Product, u.Member_Name as SubAccount, t.Member_Name as ServiceType
    , f.Member_Name as RptFunction, c.Member_Name as CostCenter, e.Member_Name as Entity, m.Member_Name as Company
    , e2.Member_Name as Equipment, t2.Member_Name as TechType 
  from {0} d
    left outer join web_dimensions_tbl r on r.member_name=d.dim_rpt_reportngline and r.dim_storage <> 'Shared Member' and r.dim_type='REPORTINGLINE' and r.level_nbr='Lev0'
    left outer join web_dimensions_tbl a on a.member_name=d.dim_rpt_account and a.dim_storage <> 'Shared Member' and a.dim_type='ACCOUNT' and a.level_nbr='Lev0'
    left outer join web_dimensions_tbl k on k.member_name=d.dim_rpt_kpi and k.dim_storage <> 'Shared Member' and k.dim_type='KPI' and k.level_nbr='Lev0'
    left outer join web_dimensions_tbl v on v.member_name=d.dim_rpt_view and v.dim_storage <> 'Shared Member' and v.dim_type='VIEW' and v.level_nbr='Lev0'
    left outer join web_dimensions_tbl y on y.alias=d.dim_rpt_years and y.dim_storage <> 'Shared Member' and y.dim_type='YEARS' and y.level_nbr='Lev0'
    left outer join web_dimensions_tbl s on s.member_name=d.dim_rpt_scenario and s.dim_storage <> 'Shared Member' and s.dim_type='SCENARIO' and s.level_nbr='Lev0'
    left outer join web_dimensions_tbl p on p.member_name=d.dim_rpt_product and p.dim_storage <> 'Shared Member' and p.dim_type='PRODUCT' and p.level_nbr='Lev0'
    left outer join web_dimensions_tbl u on u.member_name=d.dim_rpt_subaccount and u.dim_storage <> 'Shared Member' and u.dim_type='SUBACCOUNT' and u.level_nbr='Lev0'
    left outer join web_dimensions_tbl t on t.member_name=d.dim_rpt_servicetype and t.dim_storage <> 'Shared Member' and t.dim_type='SERVICETYPE' and t.level_nbr='Lev0'
    left outer join web_dimensions_tbl f on f.member_name=d.dim_rpt_function and f.dim_storage <> 'Shared Member' and f.dim_type='FUNCTION' and f.level_nbr='Lev0'
    left outer join web_dimensions_tbl c on c.member_name=d.dim_rpt_costcenter  and c.dim_storage <> 'Shared Member' and c.dim_type='COSTCENTER' and c.level_nbr='Lev0'
    left outer join web_dimensions_tbl e on e.member_name=d.dim_rpt_entity and e.dim_storage <> 'Shared Member' and e.dim_type='ENTITY' and e.level_nbr='Lev0'
    left outer join web_dimensions_tbl m on m.member_name=d.dim_rpt_company and m.dim_storage <> 'Shared Member' and m.dim_type='COMPANY' and m.level_nbr='Lev0'
    left outer join web_dimensions_tbl e2 on e2.member_name=d.dim_rpt_equipment and e2.dim_storage <> 'Shared Member' and e2.dim_type='EQUIPMENT' and e2.level_nbr='Lev0'
    left outer join web_dimensions_tbl t2 on t2.member_name=d.dim_rpt_techtype and t2.dim_storage <> 'Shared Member' and t2.dim_type='TECHTYPE' and t2.level_nbr='Lev0'
  where d.prp_rpt_source='{1}' and (
    r.member_name is null or a.member_name is null or k.member_name is null or v.member_name is null or y.alias is null 
    or s.member_name is null or p.member_name is null or u.member_name is null or t.member_name is null or f.member_name is null 
    or c.member_name is null or e.member_name is null or m.member_name is null or e2.member_name is null or t2.member_name is null
  )
  order by d.linenbr"
                        , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                        , fileType.FileTypeCode
                        , fileType.Is13Month ? string.Empty : ", dim_rpt_time"
                    ); 
                }

                LogMessage("Validating Dimension Values", sqlText, null, runStatusId);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        if (reader.HasRows) {
                            while (reader.Read()) {
                                if (rowCount < maxRows) {
                                    int i = 0;
                                    FactValidDTO f = new FactValidDTO();
                                    if (!reader.IsDBNull(i)) f.Line = reader.GetDecimal(i);
                                    if (!reader.IsDBNull(++i)) f.ReportingLine = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Account = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Year = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Product = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.SubAccount = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.CostCenter = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Company = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Source = reader.GetString(i);
                                    if (!fileType.Is13Month && !reader.IsDBNull(++i)) f.Month = reader.GetString(i);

                                    if (!fileType.UsesValidKeyCombos) {
                                        if (!reader.IsDBNull(++i)) f.ReportLineValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.AccountValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.KPIValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.ViewValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.YearValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.ScenarioValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.ProductValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.SubAcctValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.ServiceValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.FunctionValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.CostCenterValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.EntityValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.CompanyValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.EquipmentValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.TechTypeValid = reader.GetString(i);
                                    }
                                    // jevans 7/6/2012 - set table name for dimension error handler
                                    f.TableName = fileType.FactTableId.ToString();
                                    a.Add(f);
                                    rowCount++;
                                } else {
                                    rowsSkipped++;
                                }
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;            
        }

        public static ArrayList ValidateLocationDimensionFields(FileType fileType, int runStatusId, int maxRows, out string message, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;
            message = string.Empty;

            try {
                if (fileType.UsesValidKeyCombos) {
                    //  Select any items that don't exist in the Validate table.
                    sqlText = string.Format(
@"select d.line_nbr, d.reporting_line, d.account, d.kpi, d.views, d.year, d.scenario, d.product, d.subaccount, d.service_type
    , d.function, d.cost_center, d.location, d.equipment, d.tech_type, d.store_status, d.design_type, d.location_type
    , d.location_subtype, d.location_tier_code, f.source {3} 
  from {0} d
    left outer join {1} f on d.reporting_line=f.reporting_line and d.account=f.account and d.kpi=f.kpi 
      and d.views=f.views and d.product=f.product and d.subaccount=f.subaccount and d.service_type=f.service_type 
      and d.function=f.function and d.cost_center=f.cost_center and d.location=f.location and d.equipment=f.equipment 
      and d.tech_type=f.tech_type and d.store_status=f.store_status and d.design_type=f.design_type 
      and d.location_type=f.location_type and d.location_subtype=f.location_subtype and d.location_tier_code=f.location_tier_code                     
  where (f.source is null or f.source <> '{2}') and d.source='{2}'
  order by d.line_nbr"
                        , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                        , fileType.ValidationKeyTable, fileType.FileTypeCode
                        , fileType.Is13Month ? string.Empty : ", d.time"
                    );
                } else {
                    //  Validate individual fields against the Dimensions Table  
                    sqlText = string.Format(
@"select d.line_nbr, d.reporting_line, d.account, d.kpi, d.views, d.year, d.scenario, d.product, d.subaccount, d.service_type
    , d.function, d.cost_center, d.location, d.equipment, d.tech_type, d.store_status, d.design_type, d.location_type
    , d.location_subtype, d.location_tier_code, '' as source {2}, rl.member_name as rptReportingLine, ac.member_name as rptAccount
    , kp.member_name as rptKPI, vi.member_name as RptView, yr.Alias as rptYears, sc.member_name as rptScenario
    , pr.member_name as rptProduct, sa.member_name as rptSubAccount, st.member_name as rptServiceType, fc.member_name as rptRptFunction
    , cc.member_name as rptCostCenter, en.member_name as rptlocation, eq.member_name as rptEquipment, tt.member_name as rptTech_Type
    , ss.member_name as rptstorestatus, dt.member_name as rptdesigntype, lt.member_name as rptloctype, ls.member_name as rptlocsubtype
    , tc.member_name as rptloctiercode 
  from {0} d
    left outer join v_location_dimensions rl on rl.member_name=d.reporting_line and rl.dim_storage <> 'Shared member' and rl.dim_type='REPORTING_LINE' and rl.level_nbr='Lev0'
    left outer join v_location_dimensions ac on ac.member_name=d.account and ac.dim_storage <> 'Shared member' and ac.dim_type='ACCOUNT' and ac.level_nbr='Lev0'
    left outer join v_location_dimensions kp on kp.member_name=d.kpi and kp.dim_storage <> 'Shared member' and kp.dim_type='KPI' and kp.level_nbr='Lev0'
    left outer join v_location_dimensions vi on vi.member_name=d.views and vi.dim_storage <> 'Shared member' and vi.dim_type='VIEWS' and vi.level_nbr='Lev0'
    left outer join v_location_dimensions yr on yr.alias=d.year and yr.dim_storage <> 'Shared member' and yr.dim_type='YEAR' and yr.level_nbr='Lev0'
    left outer join v_location_dimensions sc on sc.member_name=d.scenario and sc.dim_storage <> 'Shared member' and sc.dim_type='SCENARIO' and sc.level_nbr='Lev0'
    left outer join v_location_dimensions pr on pr.member_name=d.product and pr.dim_storage <> 'Shared member' and pr.dim_type='PRODUCT' and pr.level_nbr='Lev0'
    left outer join v_location_dimensions sa on sa.member_name=d.subaccount and sa.dim_storage <> 'Shared member' and sa.dim_type='SUBACCOUNT' and sa.level_nbr='Lev0'
    left outer join v_location_dimensions st on st.member_name=d.service_type and st.dim_storage <> 'Shared member' and st.dim_type='SERVICE_TYPE' and st.level_nbr='Lev0'
    left outer join v_location_dimensions fc on fc.member_name=d.function and fc.dim_storage <> 'Shared member' and fc.dim_type='FUNCTION' and fc.level_nbr='Lev0'
    left outer join v_location_dimensions cc on cc.member_name=d.cost_center  and cc.dim_storage <> 'Shared member' and cc.dim_type='COST_CENTER' and cc.level_nbr='Lev0'
    left outer join v_location_dimensions en on en.member_name=d.location and en.dim_storage <> 'Shared member' and en.dim_type='ENTITY' and en.level_nbr='Lev0'
    left outer join v_location_dimensions eq on eq.member_name=d.equipment and eq.dim_storage <> 'Shared member' and eq.dim_type='EQUIPMENT' and eq.level_nbr='Lev0' 
    left outer join v_location_dimensions tt on tt.member_name=d.tech_type and tt.dim_storage <> 'Shared member' and tt.dim_type='TECH_TYPE' and tt.level_nbr='Lev0'
    left outer join v_location_dimensions ss on ss.member_name=d.store_status and ss.dim_storage <> 'Shared member' and ss.dim_type='STORE_STATUS' and ss.level_nbr='Lev0'
    left outer join v_location_dimensions dt on dt.member_name=d.design_type and dt.dim_storage <> 'Shared member' and dt.dim_type='DESIGN_TYPE' and dt.level_nbr='Lev0'
    left outer join v_location_dimensions lt on lt.member_name=d.location_type and lt.dim_storage <> 'Shared member' and lt.dim_type='LOCATION_TYPE' and lt.level_nbr='Lev0'
    left outer join v_location_dimensions ls on ls.member_name=d.location_subtype and ls.dim_storage <> 'Shared member' and ls.dim_type='LOCATION_SUBTYPE' and ls.level_nbr='Lev0'
    left outer join v_location_dimensions tc on tc.member_name=d.location_tier_code and tc.dim_storage <> 'Shared member' and tc.dim_type='LOCATION_TIER_CODE' and tc.level_nbr='Lev0'
  where d.source='{1}' and (
      rl.member_name is null or ac.member_name is null or kp.member_name is null or vi.member_name is null or yr.alias is null 
      or sc.member_name is null or pr.member_name is null or sa.member_name is null or st.member_name is null or fc.member_name is null
      or cc.member_name is null or en.member_name is null or eq.member_name is null or tt.member_name is null or ss.member_name is null
      or dt.member_name is null or lt.member_name is null or ls.member_name is null or tc.member_name is null
    )
  order by d.line_nbr"
                        , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                        , fileType.FileTypeCode
                        , fileType.Is13Month ? string.Empty : ", d.time"
                    );

                }

                LogMessage("Validating Location Dimension Values", sqlText, null, runStatusId);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        if (reader.HasRows) {
                            while (reader.Read()) {
                                if (rowCount < maxRows) {
                                    int i = 0;
                                    FactValidDTO f = new FactValidDTO();
                                    if (!reader.IsDBNull(i)) f.Line = reader.GetDecimal(i);
                                    if (!reader.IsDBNull(++i)) f.ReportingLine = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Account = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Year = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Product = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.SubAccount = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.CostCenter = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.StoreStatus = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.DesignType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.LocationType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.LocationSubtype = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.LocationTierCode = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Source = reader.GetString(i);
                                    if (!fileType.Is13Month && !reader.IsDBNull(++i)) f.Month = reader.GetString(i);

                                    // if query included validation columns
                                    if (!fileType.UsesValidKeyCombos) {
                                        if (!reader.IsDBNull(++i)) f.ReportLineValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.AccountValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.KPIValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.ViewValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.YearValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.ScenarioValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.ProductValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.SubAcctValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.ServiceValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.FunctionValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.CostCenterValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.EntityValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.EquipmentValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.TechTypeValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.StoreStatusValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.DesignTypeValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.LocationTypeValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.LocationSubtypeValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.LocationTierCodeValid = reader.GetString(i);
                                    }
                                    // jevans 7/6/2012 - set table name for dimension error handler
                                    f.TableName = fileType.FactTableId.ToString();
                                    a.Add(f);
                                    rowCount++;
                                } else {
                                    rowsSkipped++;
                                }
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a; 
        }

        public static ArrayList ValidateEquipmentDimensionFields(FileType fileType, int runStatusId, int maxRows, out string message, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;
            message = string.Empty;

            try {
                if (fileType.UsesValidKeyCombos) {
                    //  Select any items that don't exist in the Validate table.
                    sqlText = string.Format(
@"select d.line_nbr, d.fact_date, d.reporting_line, d.kpi, d.views, d.scenario, d.service_type, d.function, d.cost_center
    , d.entity, d.equipment, d.tech_type, d.methodology_type, d.sale_type, d.discount_type, d.contract_term, f.source
  from {0} d left outer join {1} f on
    d.reporting_line = f.reporting_line and d.kpi = f.kpi and d.views = f.views and d.scenario = f.scenario 
    and d.service_type = f.service_type and d.function = f.function and d.cost_center = f.cost_center 
    and d.entity = f.entity and d.equipment = f.equipment and d.methodology_type = f.methodology_type 
    and d.sale_type = f.sale_type and d.discount_type = f.discount_type and d.contract_term = f.contract_term  
    and d.tech_type = f.tech_type
  where (f.source is null or f.source <> '{2}') and d.source = '{2}'
  order by d.line_nbr",
                        fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                        , fileType.ValidationKeyTable, fileType.FileTypeCode
                    );

                } else {
                    //  Validate individual fields against the Dimensions Table  
                    sqlText = string.Format(
@"select d.line_nbr, d.fact_date, d.reporting_line, d.kpi, d.views, d.scenario, d.service_type, d.function, d.cost_center
    , d.entity, d.equipment, d.tech_type, d.methodology_type, d.sale_type, d.discount_type, d.contract_term, '' as  SOURCE
    , rl.Member_Name as rptReportingLine, kp.Member_Name as rptKPI, vi.Member_Name as RptView, sc.Member_Name as rptScenario
    , st.Member_Name as rptServiceType, fc.Member_Name as rptFunction, en.member_name as rptEntity, cc.Member_Name as rptCostCenter
    , eq.Member_Name as rptEquipment, tt.Member_Name as rptTechType, mt.Member_Name as rptMethodType, sa.Member_Name as rptSaleType
    , dt.Member_Name as rptdiscounttype, ct.member_name as rpt_contract_term, yr.Alias_Name as rptYears
  from {0} d left outer join v_equipment_dimensions rl on rl.member_name = d.reporting_line and rl.storage_value = 'Store data' and rl.dimension_name='ReportingLine' and rl.Level_Number=0  
    left outer join v_equipment_dimensions kp on kp.member_name = d.kpi and kp.storage_value = 'Store data' and  kp.dimension_name='KPI' and kp.Level_Number=0  
    left outer join v_equipment_dimensions vi on vi.member_name = d.views and vi.storage_value = 'Store data' and vi.dimension_name='View' and vi.Level_Number=0    
    left outer join v_equipment_dimensions sc on sc.member_name = d.scenario and sc.storage_value = 'Store data' and  sc.dimension_name='Scenario' and sc.Level_Number=0  
    left outer join v_equipment_dimensions st on st.member_name = d.service_type and st.storage_value = 'Store data' and  st.dimension_name='ServiceType' and st.Level_Number=0  
    left outer join v_equipment_dimensions fc on fc.member_name = d.Function and fc.storage_value = 'Store data' and fc.dimension_name='Function' and fc.Level_Number=0  
    left outer join v_equipment_dimensions cc on cc.member_name = d.cost_center  and cc.storage_value = 'Store data' and  cc.dimension_name='CostCenter' and cc.Level_Number=0 
    left outer join v_equipment_dimensions en on en.member_name = d.entity and en.storage_value = 'Store data' and  en.dimension_name='Entities' and en.Level_Number=0  
    left outer join v_equipment_dimensions eq on eq.member_name = d.equipment and eq.storage_value = 'Store data' and eq.dimension_name='Equipment' and eq.Level_Number=0 
    left outer join v_equipment_dimensions tt on tt.member_name = d.tech_type and tt.storage_value = 'Store data' and tt.dimension_name='TechType' and tt.Level_Number=0  
    left outer join v_equipment_dimensions mt on mt.member_name = d.methodology_type and mt.storage_value = 'Store data' and mt.dimension_name='MethodologyType' and mt.Level_Number=0  
    left outer join v_equipment_dimensions sa on sa.member_name = d.sale_type and sa.storage_value = 'Store data' and sa.dimension_name='SaleType' and sa.Level_Number=0  
    left outer join v_equipment_dimensions dt on dt.member_name = d.discount_type and dt.storage_value = 'Store data' and  dt.dimension_name='DiscountType' and dt.Level_Number=0  
    left outer join v_equipment_dimensions ct on ct.member_name = d.contract_term and ct.storage_value = 'Store data' and  ct.dimension_name='ContractTerm' and ct.Level_Number=0  
    left outer join v_equipment_dimensions yr on to_char(d.fact_date, 'YYYY') =yr.alias_Name and yr.dimension_name='Years' 
  where d.source = '{1}' and (
    rl.member_name is null or kp.member_name is null or vi.member_name is null or sc.member_name is null 
    or st.member_name is null or fc.member_name is null or cc.member_name is null or en.member_name is null 
    or eq.member_name is null or tt.member_name is null or mt.member_name is null or sa.member_name is null 
    or dt.member_name is null or ct.member_name is null or yr.alias_name is null 
  )
  order by d.line_nbr",
                        fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                        , fileType.FileTypeCode
                    );
                }
                
                LogMessage("Validating EQUIPMENT Dimension Values", sqlText, null, runStatusId);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        if (reader.HasRows) {
                            while (reader.Read()) {
                                if (rowCount < maxRows) {
                                    int i = 0;
                                    FactValidDTO f = new FactValidDTO();
                            
                                    if (!reader.IsDBNull(i)) f.Line = reader.GetDecimal(i);
                                    if (!reader.IsDBNull(++i)) f.FactDate = reader.GetDateTime(i);
                                    if (!reader.IsDBNull(++i)) f.ReportingLine = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.CostCenter = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.MethodType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.SaleType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.DiscountType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ContractTerm = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Source = reader.GetString(i);

                                    // if query included validation columns
                                    if (!fileType.UsesValidKeyCombos)
                                    {
                                        if (!reader.IsDBNull(++i)) f.ReportLineValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.KPIValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.ViewValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.ScenarioValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.ServiceValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.FunctionValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.EntityValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.CostCenterValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.EquipmentValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.TechTypeValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.MethodTypeValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.SaleTypeValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.DiscountTypeValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.ContractTermValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.YearValid = reader.GetString(i);
                                    }// end if valid fields included 
                                    // jevans 7/6/2012 - set table name for dimension error handler
                                    f.TableName = fileType.FactTableId.ToString();
                                    a.Add(f);
                                    rowCount++;
                                } else {                                    
                                    rowsSkipped++;
                                }
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        public static ArrayList ValidateDataWarehouseDimensionFields(FileType fileType, int runStatusId, int maxRows, out string message, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;
            message = string.Empty;

            try {
                if (fileType.UsesValidKeyCombos) {
                    //  Select any items that don't exist in the Validate table.
                    sqlText = string.Format(
@"select d.line_nbr, d.customer_account, d.branch, d.connection_type, d.equipment, d.previous_type, d.function, d.kpi
    , d.entity, d.owning_geography, d.owning_manager, d.product, d.reporting_line, d.scenario, d.segment, d.service_type
    , d.subaccount, d.tech_type, d.version, d.vertical, d.views, d.contract_term, d.program_eligibility, d.year, f.source {0}
  from {1} d
    left outer join {2} f on d.customer_account=f.customer_account and d.branch=f.branch and d.connection_type = f.connection_type 
      and d.equipment=f.equipment and d.previous_type=f.previous_type and d.function=f.function and d.kpi=f.kpi
      and d.entity=f.entity and d.owning_geography=f.owning_geography and d.owning_manager=f.owning_manager
      and d.product=f.product and d.reporting_line=f.reporting_line and d.scenario=f.scenario and d.segment=f.segment
      and d.service_type=f.service_type and d.subaccount=f.subaccount and d.tech_type=f.tech_type and d.version=f.version
      and d.vertical=f.vertical and d.views=f.views and d.contract_term = f.contract_term and d.program_eligibility = f.program_eligibility
  where d.source='{3}' and (f.source is null or f.source <> '{3}') 
  order by d.line_nbr"
                        , fileType.Is13Month ? string.Empty : ", d.time"
                        , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                        , fileType.ValidationKeyTable, fileType.FileTypeCode
                    ); 
                } else {
                    //  Validate individual fields against the Dimensions Table  
                    sqlText = string.Format(
@"select d.line_nbr, d.customer_account, d.branch, d.connection_type, d.equipment, d.previous_type, d.function, d.kpi
    , d.entity, d.owning_geography, d.owning_manager, d.product, d.reporting_line, d.scenario, d.segment, d.service_type
    , d.subaccount, d.tech_type, d.version, d.vertical, d.views, d.contract_term, d.program_eligibility, d.year, '' as source {0},

    ac.Member_Name as rptAccount, br.Member_Name as rptBranch, ct.Member_Name as rptConnType, eq.Member_Name as rptEquipment
    , pt.Member_Name as rptPrevtype, fc.Member_Name as rptFunction, kp.Member_Name as rptKPI, en.member_name as rptentity
    , og.Member_Name as rptOwningGeo, om.Member_Name as rptOwningMgr, pr.Member_Name as rptProduct, rl.Member_Name as rptReportingLine
    , sc.Member_Name as rptScenario, sg.Member_Name as rptSegment, st.Member_Name as rptServiceType, sa.Member_Name as rptSubaccount
    , tt.Member_Name as rptTechType, vr.Member_Name as RptVersion, vc.Member_Name as RptVertical
    , vi.Member_Name as RptView, ctt.member_name as otl_contract_term, pe.member_name as otl_program_eligibility, yr.alias_name as rptYears
  from {1} d
    left outer join v_dw_dimensions ac on ac.member_name=d.customer_account and ac.storage_value = 'Store data'    and ac.dimension_name='CustomerAccount' and ac.level_number=0    
    left outer join v_dw_dimensions br on br.member_name=d.branch and br.storage_value = 'Store data'          and br.dimension_name='Branch' and br.level_number=0  
    left outer join v_dw_dimensions ct on ct.member_name=d.connection_type and ct.storage_value = 'Store data' and ct.dimension_name='ConnectionType' and ct.level_number=0  
    left outer join v_dw_dimensions eq on eq.member_name=d.equipment and eq.storage_value = 'Store data'       and eq.dimension_name='Equipment' and eq.level_number=0 
    left outer join v_dw_dimensions pt on pt.member_name=d.previous_type and pt.storage_value = 'Store data' and pt.dimension_name='PrevType' and pt.level_number=0 
    left outer join v_dw_dimensions fc on fc.member_name=d.Function and fc.storage_value = 'Store data'        and fc.dimension_name='Function' and fc.level_number=0  
    left outer join v_dw_dimensions kp on kp.member_name=d.kpi and kp.storage_value = 'Store data'             and kp.dimension_name='KPI' and kp.level_number=0  
    left outer join v_dw_dimensions en on en.member_name=d.entity and en.storage_value = 'Store data'          and en.dimension_name='Entities' and en.level_number=0  
    left outer join v_dw_dimensions og on og.member_name=d.owning_geography and og.storage_value = 'Store data' and og.dimension_name='OwningGeo' and og.level_number=0  
    left outer join v_dw_dimensions om on om.member_name=d.owning_manager and om.storage_value = 'Store data'  and om.dimension_name='OwningMgr' and om.level_number=0  
    left outer join v_dw_dimensions pr on pr.member_name=d.product and pr.storage_value = 'Store data'         and pr.dimension_name='Product' and pr.level_number=0  
    left outer join v_dw_dimensions rl on rl.member_name=d.reporting_line and rl.storage_value = 'Store data'  and rl.dimension_name='ReportingLine' and rl.level_number=0  
    left outer join v_dw_dimensions sc on sc.member_name=d.scenario and sc.storage_value = 'Store data'        and sc.dimension_name='Scenario' and sc.level_number=0  
    left outer join v_dw_dimensions sg on sg.member_name=d.segment and sg.storage_value = 'Store data'         and sg.dimension_name='Segment' and sg.level_number=0  
    left outer join v_dw_dimensions st on st.member_name=d.service_type and st.storage_value = 'Store data'    and st.dimension_name='ServiceType' and st.level_number=0  
    left outer join v_dw_dimensions sa on sa.member_name=d.subaccount and sa.storage_value = 'Store data'      and sa.dimension_name='SubAccount' and sa.level_number=0  
    left outer join v_dw_dimensions tt on tt.member_name=d.tech_type and tt.storage_value = 'Store data'       and tt.dimension_name='TechType' and tt.level_number=0 
    left outer join v_dw_dimensions vr on vr.member_name=d.Version   and vr.storage_value = 'Store data'       and vr.dimension_name='Version' and vr.level_number=0    
    left outer join v_dw_dimensions vc on vc.member_name=d.vertical   and vc.storage_value = 'Store data'      and vc.dimension_name='Vertical' and vc.level_number=0    
    left outer join v_dw_dimensions vi on vi.member_name=d.views and vi.storage_value = 'Store data' and vi.dimension_name='View' and vi.level_number=0   
    left outer join v_dw_dimensions ctt on ctt.member_name=d.contract_term and ctt.storage_value = 'Store data' and ctt.dimension_name='ContractTerm' and ctt.level_number=0     
    left outer join v_dw_dimensions pe on pe.member_name=d.program_eligibility and pe.storage_value = 'Store data' and pe.dimension_name='ProgramEligible' and pe.level_number=0    
    left outer join v_dw_dimensions yr on yr.alias_name=d.year and yr.dimension_name='Years' 
  where d.source='{2}' and (
    ac.member_name is null or br.member_name is null or ct.member_name is null or eq.member_name is null 
      or pt.member_name is null or fc.member_name is null or kp.member_name is null or en.member_name is null 
      or og.member_name is null or om.member_name is null or pr.member_name is null or rl.member_name is null 
      or sc.member_name is null or sg.member_name is null or st.member_name is null or sa.member_name is null
      or tt.member_name is null or vr.member_name is null or vc.member_name is null or vi.member_name is null
      or ctt.member_name is null or pe.member_name is null or yr.alias_name is null 
  )
  order by d.line_nbr"
                        , fileType.Is13Month ? string.Empty : ", d.time"
                        , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                        , fileType.FileTypeCode
                    ); 
                }

                LogMessage("Validating Data Warehouse Dimension Values", sqlText, null, runStatusId);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        if (reader.HasRows) {
                            while (reader.Read()) {
                                if (rowCount < maxRows) {
                                    int i = 0;
                                    FactValidDTO f = new FactValidDTO();
                                    if (!reader.IsDBNull(i)) f.Line = reader.GetDecimal(i);
                                    if (!reader.IsDBNull(++i)) f.Account = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Branch = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ConnectionType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.PreviousType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.OwningGeo = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.OwningMgr = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Product = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ReportingLine = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Segment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.SubAccount = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Version = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Vertical = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ContractTerm = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ProgramEligible = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Year = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Source = reader.GetString(i);
                                    if (!fileType.Is13Month && !reader.IsDBNull(++i)) f.Month = reader.GetString(i);
                                    // if query included validation columns
                                    if (!fileType.UsesValidKeyCombos) {
                                        if (!reader.IsDBNull(++i)) f.AccountValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.BranchValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.ConnTypeValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.EquipmentValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.PreviousTypeValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.FunctionValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.KPIValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.EntityValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.OwningGeoValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.OwningMgrValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.ProductValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.ReportLineValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.ScenarioValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.SegmentValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.ServiceValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.SubAcctValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.TechTypeValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.VersionValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.VerticalValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.ViewValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.ContractTermValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.ProgramEligibleValid = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) f.YearValid = reader.GetString(i);
                                    }
                                    // jevans 7/6/2012 - set table name for dimension error handler
                                    f.TableName = fileType.FactTableId.ToString();
                                    a.Add(f);
                                    rowCount++;
                                } else {
                                    rowsSkipped++;
                                }
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;  
        }

        /// <summary>
        /// the four Check User Fields methods were merged into one method 
        /// </summary>
        /// <param name="fileType"></param>
        /// <param name="lineNumbers"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        public static bool CheckUserDefinedFields(FileType fileType, string lineNumbers, out string message) {
            string sqlText = string.Empty;
            message = string.Empty;
            string[] fieldNames;
            string masterTable = string.Empty;
            string lineNumberFieldName = string.Empty;
            string dimensionFieldName = string.Empty;
            string selectSqlText = string.Empty;
            string outerJoinSqlText = string.Empty;
            string joinSqlText = " 1 = 1 ";
            int lastDimensionFieldOffset = 3;
            int index;

            try {
                switch ((FactTable)fileType.FactTableId) {
                    case FactTable.LocationUser:
                        fieldNames = locationFieldNames;
                        masterTable = "V_LOCATION_DIMENSIONS";
                        lineNumberFieldName = "LINE_NBR";
                        dimensionFieldName = "DIM_TYPE";
                        break;
                    case FactTable.EquipmentUser:
                        fieldNames = equipmentFieldNames;
                        masterTable = "V_EQUIPMENT_DIMENSIONS";
                        lineNumberFieldName = "LINE_NBR";
                        dimensionFieldName = "DIMENSION_NAME";
                        lastDimensionFieldOffset = 1;  // this is critical because otherwise some dimensions will not be checked
                        break;
                    case FactTable.DataWarehouseUser:
                        fieldNames = dataWarehouseFieldNames;
                        masterTable = "V_DW_DIMENSIONS";
                        lineNumberFieldName = "LINE_NBR";
                        dimensionFieldName = "DIMENSION_NAME";
                        break;
                    default:
                        fieldNames = reportingFieldNames;
                        masterTable = "WEB_DIMENSIONS_TBL";
                        lineNumberFieldName = "linenbr";
                        dimensionFieldName = "DIM_TYPE";
                        break;
                }

                index = 0;
                foreach (FileTypeField fileTypeField in fileType.fields) {
                    if (fileTypeField.Source == FileTypeFieldSource.UserDefinableUserFeed) {
                        selectSqlText += string.Format(",max(v.{0}),max(t{1}.member_name)", fileTypeField.FactColumnName, index.ToString());

                        outerJoinSqlText += string.Format(" left outer join {0} t{1} on s.{2}=t{1}.member_name and upper(t{1}.{4})=upper('{3}')"
                                    , masterTable, index++.ToString(), fileTypeField.FactColumnName, fileTypeField.DimensionTypeName, dimensionFieldName);
                    }
                } 

                //  If Length is 0, there are no user definable fields.
                if (selectSqlText.Length == 0) {
                    // jevans 1/6/2011 - STOP PROCESSING
                    message = "There are Invalid Key Combinations in the User Feed.  Check individual lines for more information.";
                }

                //  Create the field list that should be included in the join.  
                for (int i = 0; i < fieldNames.Length - lastDimensionFieldOffset; i++) {
                    if (selectSqlText.Contains(fieldNames[i]) 
                        || fieldNames[i].Contains("FACT") 
                        || IsAutoMappedField(fileType.fields, fieldNames[i]))
                        continue;

                    if (joinSqlText.Length > 0)
                        joinSqlText += " and ";
                    joinSqlText += string.Format(" s.{0}=v.{0}", fieldNames[i]);
                }

                //  Create the Select Statement.  It should show the joined fields for the user definable fields
                //  so that we can determine if a key like the one we are trying to create exists.
                sqlText = string.Format(
@"select s.{0}{1}
  from {2} s left outer join {3} v on {4} and s.{5}='{6}' 
    {7}
  where s.{5}='{6}' and s.{0} in ({8})
  group by s.{0}  order by s.{0} "
                    , lineNumberFieldName, selectSqlText
                    , fileType.Is13Month ? fileType.StageYearTable : fileType.StageMonthTable
                    , fileType.ValidationKeyTable, joinSqlText, fileType.SourceColumnName, fileType.FileTypeCode, outerJoinSqlText, lineNumbers
                );

                //TODO: lineNumbers will most likely error if number of values is too high ,  Needs to be changed to a clob parameter 

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        //  For each row that is returned, make sure all the fields exist.  If any return a null,
                        //  It means that a record like the one we are trying to define doesn't exist.
                        string errorMessage = string.Empty;
                        string badLines = string.Empty;
                        string lines = string.Empty;
                        string fieldName = string.Empty;

                        while (reader.Read()) {
                            for (int f = 1; f < reader.FieldCount; f++) {
                                if (reader.IsDBNull(f)) {
                                    //  If it is the first field of the two fields per record, then it means there
                                    //  is no similar row in the validation table.  If it is the 2nd of the two columns
                                    //  per row checked, then the value was not found in the outline.
                                    if (((f - 1) & 1) == 0)
                                        lines += string.Format(", {0}", reader[0]);
                                    else {
                                        fieldName = reader.GetName(f - 1);
                                        fieldName = fieldName.Substring(6, fieldName.Length - 7);
                                        errorMessage += string.Format("Line {0} {1} does not exist in the outline.\r\n", reader[0], fieldName);
                                    }
                                    badLines += string.Format("{0}", reader[0]);
                                    break;
                                }
                            }
                        }
                        if (lines.Length > 0) {
                            lines = lines.Substring(1);
                            errorMessage += string.Format("The following lines are not Valid Key Combinations:<br>{0}<br>", lines);
                        }

                        if (badLines.Length > 0) {
                            message = errorMessage;
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                message = string.Empty;
                return false;
            }
            return true;
        }

        /// <summary>
        /// utility to determine if a given field is automapped, to avoid user defined key error
        /// </summary>
        /// <param name="fields"></param>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        private static bool IsAutoMappedField(List<FileTypeField> fields, string fieldName)
        {
            bool isAutomapped = false;
            foreach (FileTypeField field in fields) {
                // find  the current field in the field type array
                if (field.FactColumnName == fieldName)
                {
                    // if it is automap, return true so it is not included in the join criteria
                    if (field.Source == FileTypeFieldSource.AutomapOnAccount
                        || field.Source == FileTypeFieldSource.AutomapOnCostCenter
                        || field.Source == FileTypeFieldSource.AutomapOnFunction
                        || field.Source == FileTypeFieldSource.AutomapOnLocation
                        || field.Source == FileTypeFieldSource.AutomapOnVESAccount)
                    {
                        isAutomapped = true;
                    }
                    break;
                }
            }
            return isAutomapped;
        }
        /// <summary>
        /// confirm the scenarios in the outlook upload are unique
        /// </summary>
        /// <param name="hft"></param>
        public static bool ValidateSingleScenario(FileType hft, int RunStatusId)
        {
            BasicOraReader Rdr = new BasicOraReader(GetOracleConnectionString());
            FactTable e = (FactTable)hft.FactTableId;
            string Cmd = string.Format(@"Select distinct {0} from {1} where {2} ='{3}'",
                e == FactTable.LocationUser
                || e == FactTable.EquipmentUser
                || e == FactTable.DataWarehouseUser
                ? "scenario" : "dim_rpt_scenario",
                hft.Is13Month ? hft.StageYearTable : hft.StageMonthTable,
                hft.SourceColumnName,
                hft.FileTypeCode);
            LogMessage("Validating Scenario", Cmd, null, RunStatusId);
            if (Rdr.Open(Cmd) && Rdr.oraRdr.HasRows)
            {
                int NbrScn = 0;
                while (Rdr.oraRdr.Read())
                    NbrScn++;
                Rdr.Close();

                if (NbrScn > 1)
                {
                    return false;
                }
            }
            else if (Rdr.oraRdr == null)
            {
                // throw exception so email gets sent 
                Rdr.Dispose();
                throw new Exception(Rdr.LastErrorMessage);
            }
            return true;
        }

        public static int CallCompanyLookup(FileType hft, string Requestor)
        {
            OracleConnection oraConn = new OracleConnection(GetOracleConnectionString());
            OracleCommand sqlCmd = null;
            string Cmd = null;
            int iRet = -1;
            try
            {

                oraConn.Open();

                Cmd = "etl_process_delta.apply_company_mapping";
                sqlCmd = new OracleCommand(Cmd, oraConn);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                OracleParameter pStgInTbl = new OracleParameter("i_stage_table", OracleDbType.Varchar2);
                pStgInTbl.Direction = ParameterDirection.Input;
                pStgInTbl.Value = hft.Is13Month ? hft.StageYearTable : hft.StageMonthTable;
                sqlCmd.Parameters.Add(pStgInTbl);

                //  jevans - 2/26/2013 - add target table 
                OracleParameter pTarget = new OracleParameter("i_target_table", OracleDbType.Varchar2);
                pTarget.Direction = ParameterDirection.Input;
                pTarget.Value = hft.DestinationTable.ToUpper();
                sqlCmd.Parameters.Add(pTarget);

                //  jevans - 6/17/2013 - add mapset parm
                OracleParameter pMapset = new OracleParameter("i_mapset", OracleDbType.Varchar2);
                pMapset.Direction = ParameterDirection.Input;
                //pMapset.Value = hft.FileTypeCode;
                sqlCmd.Parameters.Add(pMapset);

                OracleParameter pSource = new OracleParameter("i_source", OracleDbType.Varchar2);
                pSource.Direction = ParameterDirection.Input;
                pSource.Value = hft.FileTypeCode;
                sqlCmd.Parameters.Add(pSource);

                OracleParameter pRetCode = new OracleParameter("o_rows_updated", OracleDbType.Int32);
                pRetCode.Direction = ParameterDirection.Output;
                sqlCmd.Parameters.Add(pRetCode);

                sqlCmd.ExecuteNonQuery();
                iRet = int.Parse(string.Format("{0}", pRetCode.Value));
            }
            catch (OracleException ex)
            {
                switch (ex.Number)
                {
                    case 20201:
                        iRet = -1;
                        break;
                }
            }
            catch (Exception ex)
            {
                //  Log the error to a table.
                GeneralDatabaseAccess.LogEvent(Requestor, "CallCompanyLookup", Cmd, ex, UserToolLogLevel.Error);
                iRet = -1;
            }
            finally
            {
                if (oraConn != null)
                {
                    oraConn.Close();
                    oraConn.Dispose();
                }
            }
            return iRet;
        }

        // end of validations 
        #endregion

        #region ops upload file
        // only called by OPS UPLOAD INPUT FILE
        public static bool UtilTruncateTable(string TableName, bool DisableConstraints)
        {
            BasicOraCommand Wrtr = new BasicOraCommand(DbAccess.GetOracleConnectionString());
            string Cmd = "util.truncate_table";
            bool bRet = false;
            try
            {
                OracleParameter pTableName = new OracleParameter("i_table_name", OracleDbType.Varchar2);
                OracleParameter pDisableConstraints = new OracleParameter("i_disable_constraints", OracleDbType.Decimal);

                pTableName.Value = TableName;
                pDisableConstraints.Value = DisableConstraints ? (Decimal)1 : (Decimal)0;

                Wrtr.Exec(Cmd, CommandType.StoredProcedure, pTableName); //, pDisableConstraints);
                if (Wrtr.LastErrorMessage.Length == 0)
                    bRet = true;
            }
            catch (Exception ex)
            {
                GeneralDatabaseAccess.LogEvent("", "Util.Truncate_table", Cmd, ex, UserToolLogLevel.Error);
            }

            //  We are done, clean up.
            Wrtr.Dispose();

            return bRet;
        }

        // called by opsuploadinputfile
        public static ReturnCodeDTO LoadDataInputFileIntoTable(
            string filename, string stageTableName, List<MasterDimension> dimensions, FileType fileType
            , string owner, int runId, out string scenario
        ) {
            ReturnCodeDTO rc = new ReturnCodeDTO();
            scenario = "";
            int LineNbr = 0;
            BasicOraCommand Wrtr = new BasicOraCommand(DbAccess.GetOracleConnectionString());

            //Create the Connection String
            //You must specify the Provider as is here 
            //The Data Source is the path to your file
            //learn about Extended Properties at http://www.connectionstrings.com/excel-2007
            // jevans 11/22/2010 - add 2007 extension 
            string ConnString;
            string path = Path.GetExtension(filename).ToLower();
            if (path.Equals(".xls"))
                ConnString = string.Format(@"Provider=Microsoft.Jet.OLEDB.4.0;
                Data Source={0};Extended Properties=""Excel 8.0;IMEX=1;""",
                    filename);
            else
                ConnString = string.Format(@"Provider=Microsoft.ACE.OLEDB.12.0; Data Source={0};Extended Properties=""Excel 12.0 Xml;IMEX=1;""",
                       filename);

            //Create the connection
            System.Data.OleDb.OleDbConnection ExcelConnection =
                new System.Data.OleDb.OleDbConnection(ConnString);

            //  We want to select all the UserInput fields from the Excel file.
            string Cmd = string.Format("Select * from [{0}$]", fileType.FileTypeCode);

            //use "Select * ... " to select the entire sheet
            //create the command
            System.Data.OleDb.OleDbCommand ExcelCommand = new System.Data.OleDb.OleDbCommand(Cmd, ExcelConnection);

            try
            {
                //Open the connection
                ExcelConnection.Open();

                //Create a reader
                System.Data.OleDb.OleDbDataReader ExcelReader = null;
                try
                {
                    ExcelReader = ExcelCommand.ExecuteReader();
                }
                catch (Exception)
                {
                    //throw new Exception(
                    rc.Message = string.Format("There was an error opening the Excel file.  Make sure that a Worksheet named '{0}' exists.", fileType.FileTypeCode);
                    rc.Success = true;
                    rc.ReturnCode = -1;
                    return rc;
                }

                //  Determine the table to insert into along with the fields that should be in the file.
                string FldDelim = "";
                foreach (MasterDimension md in dimensions)
                    FldDelim += (md.DimVariableType.ToLower().Equals("string") ? "'" : " ");

                int[] FldIdxes = new int[FldDelim.Length];
                string FldList = string.Format("insert into {0} (RUN_STATUS_ID, SOURCE_CD, FILE_TYPE, LINE_NBR",
                    stageTableName);

                //  Check each field that should be in the file and make sure it is there.
                int i = -1;
                string fields = "";
                foreach (MasterDimension md in dimensions)
                {
                    i++;
                    bool bFound = false;
                    for (int j = 0; j < ExcelReader.VisibleFieldCount; j++)
                    {
                        if (md.FactColumnName.ToUpper().Equals(ExcelReader.GetName(j).ToUpper()))
                        {
                            FldIdxes[i] = j;
                            bFound = true;

                            //  If it was found, add it to the field list
                            FldList += "," + md.FactColumnName;
                            break;
                        }
                    }

                    //  If the field wasn't found, throw an exception.
                    if (bFound == false)
                    {
                        //throw new Exception(
                        fields += "<li>" + md.FactColumnName;
                    }
                } // end for each 
                if (fields.Length > 1)
                {
                    rc.Message = string.Format("The Load Process failed to find the following field(s) in the file: {0}<br>", fields);
                    rc.ReturnCode = -1;
                    rc.Success = true;
                    return rc;
                } // end of if fields 

                FldList += string.Format(") values ({0}, 'MDUA', '{1}', ", runId, fileType.FileTypeCode);

                //  Clear out any previous attempt to load the file.
                DeleteInputFileStagingData(stageTableName, fileType.FileTypeCode);
                Wrtr.Open();

                //  For each row of data, write out all the data separated by tabs.
                rc.ReturnCode = 0;
                while (ExcelReader.Read())
                {
                    LineNbr++;
                    string Vals = "";
                    bool bAllNbrsNull = true;
                    for (int c = 0; c < FldDelim.Length; c++)
                    {
                        if (ExcelReader.IsDBNull(FldIdxes[c]))
                        {
                            Vals += ",NULL";
                        }
                        else
                        {
                            //  If it is a number, check the formatting.  If the first value appears lower in the
                            //  file, it can contain formatting (commas and dollar signs).  So make sure we
                            //  strip them out.
                            if (FldDelim[c] == ' ')
                            {
                                string Nbr = string.Format("{0}", ExcelReader.GetValue(FldIdxes[c]));
                                Nbr = Nbr.Replace(",", "");
                                Nbr = Nbr.Replace("$", "");
                                if (Nbr.Trim().Length > 0)
                                {
                                    Vals += "," + Nbr;
                                    bAllNbrsNull = false;
                                }
                            }
                            else
                                Vals += string.Format(",{0}{1}{0}", FldDelim[c], ExcelReader.GetValue(FldIdxes[c]));
                        }
                    } // for each field

                    //  If all the fields were null, just skip the line
                    if (bAllNbrsNull)
                        continue;

                    //  Add the record to the table.
                    Cmd = FldList + LineNbr.ToString() + Vals.ToUpper() + ")";
                    if (Wrtr.ExecOpened(Cmd) != 1)
                    {
                        rc.Success = false;
                        rc.Message += Wrtr.LastErrorMessage;
                        rc.ReturnCode = -1;
                        return rc;
                    }
                    rc.ReturnCode++;
                }

                if (fileType.IsOutlook)
                {
                    int Pos = Cmd.IndexOf("SC.O.");
                    if (Pos > 0)
                    {
                        scenario = Cmd.Substring(Pos + 5, 3);
                    }
                }
            }
            catch (Exception ex)
            {
                GeneralDatabaseAccess.LogEvent(owner, "LoadDataFileIntoTable", Cmd, ex, UserToolLogLevel.Error);
                rc.Message += ex.Message + ex.StackTrace;
                rc.ReturnCode = -1;
                rc.Success = false;
            }

            //  We are done, clean up.
            ExcelConnection.Close();
            Wrtr.Dispose();

            return rc;
        }

        // only called by OPS UPLOAD INPUT FILE
        public static int DeleteInputFileStagingData(string StageTableName, string FileType)
        {
            BasicOraCommand Wrtr = new BasicOraCommand(DbAccess.GetOracleConnectionString());
            string Cmd = string.Format("delete from {0} where file_type='{1}'",
                StageTableName, FileType);
            int RowsDeleted = Wrtr.Exec(Cmd);
            if (Wrtr.LastErrorMessage.Length == 0)
                return RowsDeleted;

            return -1;
        }
        // only called by OPS UPLOAD INPUT FILE
        public static ReturnCodeDTO ProcessInputFileForceValues(FileType hft, string StgTableName, int RunId)
        {
            ReturnCodeDTO rc = new ReturnCodeDTO();
            rc.Success = true;
            try
            {
                string Cmd = "";

                BasicOraCommand Wrtr = new BasicOraCommand(DbAccess.GetOracleConnectionString());
                Wrtr.Open();

                string LogMsg = "";
                foreach (FileTypeField tFlds in hft.fields)
                {
                    if (tFlds.Source != FileTypeFieldSource.ForcedValue)
                        continue;

                    if (LogMsg.Length > 0)
                        LogMsg += ", ";
                    LogMsg += string.Format("Forcing: {0}={1}", tFlds.FactColumnName, tFlds.ForcedValue);

                    if (Cmd.Length > 0)
                        Cmd += ",";
                    Cmd += string.Format("{0}='{1}'", tFlds.FactColumnName, tFlds.ForcedValue);
                }

                //  If there are forced value fields, set them now.
                if (Cmd.Length > 0)
                {
                    Cmd = string.Format("update {0} set {1} where PROCESS_id='{2}'",
                        StgTableName, Cmd, RunId);
                    if (Wrtr.ExecOpened(Cmd) < 0)
                    {
                        rc.Message = Wrtr.LastErrorMessage;
                        rc.Success = false;
                    }
                }
                LogMessage(LogMsg, Cmd, null, RunId);

                Wrtr.Dispose();
                Wrtr = null;
            }
            catch (Exception ex)
            {
                GeneralDatabaseAccess.LogEvent("", "DBAccess.cs", "ProcessInputFileForceValues", ex, UserToolLogLevel.Error);
                rc.Success = false;
                rc.Message = ex.Message + ex.StackTrace;
            }
            return rc;
        }

        // called by opsuploadinput
        public static int CopyInputFileStageToTrans(Int32 RunId, string FileType, string IsAdjustment)
        {
            BasicOraCommand Wrtr = new BasicOraCommand(DbAccess.GetOracleConnectionString());
            OracleParameter pRunId = new OracleParameter("i_PROCESS_id", OracleDbType.Int32, ParameterDirection.Input);
            OracleParameter pFileType = new OracleParameter("i_file_type", OracleDbType.Varchar2, ParameterDirection.Input);
            OracleParameter pIsAdjustment = new OracleParameter("i_is_adjustment", OracleDbType.Varchar2, ParameterDirection.Input);
            OracleParameter pRecsProcessed = new OracleParameter("o_records_processed", OracleDbType.Int32, ParameterDirection.Output);

            pRunId.Value = RunId;
            pFileType.Value = FileType;
            pIsAdjustment.Value = IsAdjustment;

            Wrtr.Exec("etl_ledger.mdua_stg_to_trans", CommandType.StoredProcedure, pRunId,
                pFileType, pIsAdjustment, pRecsProcessed);
            if (Wrtr.LastErrorMessage.Length > 0)
                return -1;

            int RecsCopied = Int32.Parse(pRecsProcessed.Value.ToString());
            Wrtr.Dispose();
            return RecsCopied;
        }

        #endregion

        #region PROCESS routines
        
        public static int RunStatusAdd(string ProcessName, string FiscalPeriod, string Status,
            string Message, string UserId, string AsRelatesTo)
        {
            BasicOraCommand Wrtr = new BasicOraCommand(DbAccess.GetOracleConnectionString());
            string Cmd = "";
            Int64 RunId = -1;
            try
            {
                OracleParameter pProcName = new OracleParameter("i_process_name", OracleDbType.Varchar2);
                OracleParameter pFiscalPeriod = new OracleParameter("i_fiscal_period", OracleDbType.Varchar2);
                //OracleParameter pToFiscalPeriod = new OracleParameter("i_to_fiscal_period", OracleDbType.Varchar2);
                OracleParameter pStatus = new OracleParameter("i_status", OracleDbType.Varchar2);
                OracleParameter pMessage = new OracleParameter("i_message", OracleDbType.Varchar2);
                OracleParameter pUserId = new OracleParameter("i_created_by", OracleDbType.Varchar2);
                OracleParameter pAsRelatesTo = new OracleParameter("i_as_relates_to", OracleDbType.Varchar2);
                OracleParameter pRunId = new OracleParameter("return_value", OracleDbType.Int32);
                pRunId.Direction = ParameterDirection.ReturnValue;

                pProcName.Value = ProcessName;
                pFiscalPeriod.Value = FiscalPeriod;
                // pToFiscalPeriod.Value = FiscalPeriod;
                pStatus.Value = Status;
                pMessage.Value = Message;
                pUserId.Value = UserId;
                pAsRelatesTo.Value = AsRelatesTo;

                //Wrtr.Exec("PROCESS.ADD", CommandType.StoredProcedure, pRunId, pProcName, pUserId, pAsRelatesTo);
                Wrtr.Exec("PROCESS.ADD", CommandType.StoredProcedure, pRunId, pProcName, pFiscalPeriod, pStatus, pMessage, pUserId, pAsRelatesTo);
                RunId = Int32.Parse(pRunId.Value.ToString());
                if (RunId == -1)
                    throw new Exception(Wrtr.LastErrorMessage);
            }
            catch (Exception ex)
            {
                GeneralDatabaseAccess.LogEvent(UserId, "RunStatusAdd", Cmd, ex, UserToolLogLevel.Error);
            }

            //  We are done, clean up.
            Wrtr.Dispose();

            return (int)RunId;
        }


        public static bool LogMessage(string Message, string SqlCmd, string Trace, int RunStatusId)
        {
            BasicOraCommand Wrtr = new BasicOraCommand(DbAccess.GetOracleConnectionString());
            string Cmd = "util.log_message";
            bool bRet = false;
            try
            {
                OracleParameter pMsg = new OracleParameter("i_msg", OracleDbType.Varchar2);
                OracleParameter pSql = new OracleParameter("i_sql", OracleDbType.Varchar2);
                OracleParameter pTrace = new OracleParameter("i_trace", OracleDbType.Varchar2);
                OracleParameter pRunStatusId = new OracleParameter("i_PROCESS_id", OracleDbType.Int32);

                pMsg.Value = Message;
                pSql.Value = SqlCmd;
                pTrace.Value = Trace;
                pRunStatusId.Value = RunStatusId;

                Wrtr.Exec(Cmd, CommandType.StoredProcedure, pMsg, pSql, pTrace, pRunStatusId);
                if (Wrtr.LastErrorMessage.Length == 0)
                    bRet = true;
            }
            catch (Exception ex)
            {
                GeneralDatabaseAccess.LogEvent("", "LogMessage", "util.log_message", ex, UserToolLogLevel.Error);
            }

            //  We are done, clean up.
            Wrtr.Dispose();

            return bRet;
        }

        public static bool RunStatusComplete(Int32 RunStatusId, string Status, string Message, Int32 RecordsProcessed, string FileName)
        {
            BasicOraCommand Wrtr = new BasicOraCommand(DbAccess.GetOracleConnectionString());
            string Cmd = "PROCESS.COMPLETE";
            bool bRet = false;
            try
            {
                OracleParameter pRunStatusId = new OracleParameter("i_run_status_id", OracleDbType.Int32);
                OracleParameter pStatus = new OracleParameter("i_status", OracleDbType.Varchar2);
                OracleParameter pMessage = new OracleParameter("i_message", OracleDbType.Varchar2);
                OracleParameter pRecsProcessed = new OracleParameter("i_records_processed", OracleDbType.Int32);
                OracleParameter pFilename = new OracleParameter("i_filename", OracleDbType.Varchar2);

                pRunStatusId.Value = RunStatusId;
                pStatus.Value = Status;
                // jevans 7/17/2012 - truncate message if greater than column size 
                pMessage.Value = Message.Length > 2000 ? Message.Substring(0, 1996) + "..." : Message;
                pRecsProcessed.Value = RecordsProcessed;
                pFilename.Value = FileName;

                Wrtr.Exec(Cmd, CommandType.StoredProcedure, pRunStatusId, pStatus, pMessage, pRecsProcessed, pFilename);
                if (Wrtr.LastErrorMessage.Length == 0)
                    bRet = true;
                else
                    throw new Exception(Wrtr.LastErrorMessage);
            }
            catch (Exception ex)
            {
                GeneralDatabaseAccess.LogEvent("", "RunStatusComplete", "PROCESS.COMPLETE", ex, UserToolLogLevel.Error);
            }

            //  We are done, clean up.
            Wrtr.Dispose();

            return bRet;
        }

        public static int GetProcessID(string AsRelatesTo, string ProcessCode)
        {
            BasicOraReader Rdr = new BasicOraReader(GetOracleConnectionString());
            int processID = 0;
            string SelCmd = string.Format(@"SELECT max(processid) FROM rpt_process_status_tbl
                where ProcessCode='{0}'", ProcessCode);
            if (AsRelatesTo.Length > 0)
                SelCmd += string.Format(" and asrelatesto='{0}'", AsRelatesTo);
            if (Rdr.Open(SelCmd) == false)
            {
                GeneralDatabaseAccess.LogEvent("", "WPUtils", "GetProcessInfo", Rdr.LastErrorMessage, UserToolLogLevel.Error);
            }

            //  If there is no process for this item, return a Progress Bar that says so.
            if (Rdr.oraRdr.Read() && Rdr.oraRdr.IsDBNull(0) == false)
                processID = (int)Rdr.oraRdr.GetDecimal(0);
            Rdr.Dispose();
            return processID;
        }

        public static ArrayList GetProcessSteps(string ProcessCode, string AsRelatesTo)
        {
            BasicOraReader Rdr = new BasicOraReader(GetOracleConnectionString());
            string SelCmd = string.Format(@"SELECT a.seqnbr, a.step, a.stepdescription, a.notifyid, a.expectedduration
                FROM rpt_process_step_tbl a
                where ProcessCode='{0}'", ProcessCode);
            if (AsRelatesTo.Length > 0)
                SelCmd += string.Format(" and a.asrelatesto='{0}'", AsRelatesTo);
            SelCmd += " order by seqnbr";
            if (Rdr.Open(SelCmd) == false)
            {
                GeneralDatabaseAccess.LogEvent("", "Utils.cs", "GetProcessInfo", SelCmd + ": " + Rdr.LastErrorMessage, UserToolLogLevel.Error);
                return null;
            }

            ArrayList arrSteps = new ArrayList();

            //  If there is no process for this item, return a Progress Bar that says so.
            while (Rdr.oraRdr.Read())
            {
                WPProcessStep ps = new WPProcessStep();
                ps.SeqNbr = (int)Rdr.oraRdr.GetDecimal(0);
                ps.Step = Rdr.oraRdr.GetString(1);
                ps.StepDescription = Rdr.oraRdr.GetString(2);
                ps.NotificationId = (int)Rdr.oraRdr.GetDecimal(3);
                ps.ExpectedDuration = (int)Rdr.oraRdr.GetDecimal(4);
                arrSteps.Add(ps);
            }
            Rdr.Dispose();

            return arrSteps;
        }

        public static ArrayList GetProcessSteps(int ProcessId, string ProcessCode, string AsRelatesTo)
        {
            BasicOraReader Rdr = new BasicOraReader(GetOracleConnectionString());
            string SelSteps = string.Format(@"select s.seqnbr, s.step, s.stepdescription, s.notifyid, s.expectedduration, 
            p.ClosePeriod, p.starttime, p.endtime, p.status, p.message from 
            rpt_process_step_tbl s
            left outer join rpt_process_status_tbl p on ProcessId={0} and 
                p.ProcessCode=s.processcode and
                p.AsRelatesTo=s.asrelatesto and 
                p.Step = s.step
            where s.processCode='{1}' and s.AsRelatesTo='{2}'
            order by s.seqnbr", ProcessId, ProcessCode, AsRelatesTo);

            if (Rdr.Open(SelSteps) == false)
            {
                GeneralDatabaseAccess.LogEvent("", "Utils.cs", "GetProcessSteps", SelSteps + ": " + Rdr.LastErrorMessage, UserToolLogLevel.Error);
                return null;
            }

            ArrayList arrSteps = new ArrayList();

            //  If there is no process for this item, return a Progress Bar that says so.
            while (Rdr.oraRdr.Read())
            {
                WPProcessStep ps = new WPProcessStep();
                ps.SeqNbr = (int)Rdr.oraRdr.GetDecimal(0);
                ps.Step = Rdr.oraRdr.GetString(1);
                ps.StepDescription = Rdr.oraRdr.GetString(2);
                ps.NotificationId = (int)Rdr.oraRdr.GetDecimal(3);
                ps.ExpectedDuration = (int)Rdr.oraRdr.GetDecimal(4);
                if (Rdr.oraRdr.IsDBNull(5) == false)
                    ps.ClosePeriod = Rdr.oraRdr.GetString(5);
                if (Rdr.oraRdr.IsDBNull(6) == false)
                    ps.StartTime = Rdr.oraRdr.GetDateTime(6);
                if (Rdr.oraRdr.IsDBNull(7) == false)
                    ps.EndTime = Rdr.oraRdr.GetDateTime(7);
                if (Rdr.oraRdr.IsDBNull(8) == false)
                    ps.Status = Rdr.oraRdr.GetString(8);
                if (Rdr.oraRdr.IsDBNull(9) == false)
                    ps.Message = Rdr.oraRdr.GetString(9);
                arrSteps.Add(ps);
            }

            Rdr.Dispose();

            return arrSteps;
        }

        public static string GetProcessDescription(int ProcessCode, string AsRelatesTo)
        {
            string sReturn = string.Empty;
            BasicOraReader Rdr = new BasicOraReader(GetOracleConnectionString());
            string SelCmd = string.Format(@"SELECT ProcessDescription FROM rpt_process_type_tbl
            where ProcessCode='{0}'", ProcessCode);
            if (AsRelatesTo.Length > 0)
                SelCmd += string.Format(" and asrelatesto='{0}'", AsRelatesTo);
            if (Rdr.Open(SelCmd) == false)
            {
                GeneralDatabaseAccess.LogEvent("", "WPUtils", "GetProcessInfo", SelCmd + ": " + Rdr.LastErrorMessage, UserToolLogLevel.Error);
            }

            //  If there is no process for this item, return a Progress Bar that says so.
            if (Rdr.oraRdr.Read())
                sReturn = Rdr.oraRdr.GetString(0);

            Rdr.Dispose();
            return sReturn;

        }

        public static string GetProcessDescription(string AsRelatesTo, string ProcessCode)
        {

            string sReturn = string.Empty;
            string Cmd = string.Empty;
            try
            {
                BasicOraReader Rdr = new MDUA.DataAccess.BasicOraReader(GetOracleConnectionString());
                Cmd = string.Format("Select ProcessDescription from rpt_process_type_tbl where asrelatesto like '{0}' and processcode = '{1}'",
                    AsRelatesTo, ProcessCode);
                Rdr.Open(Cmd);
                if (Rdr.oraRdr.Read())
                    sReturn = string.Format("There are no previous runs of the {0} process.", Rdr.oraRdr.GetString(0));
                else
                    sReturn = "There are no previous runs of that process.";
                Rdr.Dispose();
            }
            catch (Exception ex)
            {
                GeneralDatabaseAccess.LogEvent("", "GetProcess", Cmd, ex, UserToolLogLevel.Error);
                sReturn = "We're sorry, an error occurred while processing your request, and your transaction was not completed successfully.  ";
            }
            return sReturn;
        }

        public static bool GetProcessCode(int ProcessID, out string AsRelatesTo, out string ProcessCode)
        {
            BasicOraReader Rdr = new BasicOraReader(GetOracleConnectionString());
            AsRelatesTo = "";
            ProcessCode = "";
            string SelCmd = string.Format(@"SELECT ProcessCode, AsRelatesTo FROM rpt_process_status_tbl
                where ProcessId={0}", ProcessID.ToString());
            if (Rdr.Open(SelCmd) == false)
            {
                GeneralDatabaseAccess.LogEvent("", "WPUtils", "GetProcessInfo", SelCmd + ": " + Rdr.LastErrorMessage, UserToolLogLevel.Error);
                return false;
            }

            //  If there is no process for this item, return a Progress Bar that says so.
            if (Rdr.oraRdr.Read())
            {
                ProcessCode = Rdr.oraRdr.GetString(0);
                AsRelatesTo = Rdr.oraRdr.GetString(1);
            }
            return true;
        }

        #endregion
        
        #region download file creators

        /* used by utils for CPGA info page */
        public static int CopyTableToExcel(string Filename, string SheetName, string FnlTableName, bool CreateSheet, ArrayList arrColInfo, string Where, out string Msg, string Requestor)
        {
            int RecCnt = -1;
            Msg = "";
            try
            {
                //Create the Connection String
                //string ConnString = string.Format(@"Provider=Microsoft.Jet.OLEDB.4.0;
                //Data Source={0};Extended Properties=""Excel 8.0;HDR=YES;"" ",
                //    Filename);
                // jevans 4/7/2011 - add 2007 extension 
                //string ConnString = string.Format(ConnString = ConfigurationManager.ConnectionStrings["xlsx"].ConnectionString, Filename);
                string ConnString = string.Format(@"Provider=Microsoft.ACE.OLEDB.12.0; Data Source={0};Extended Properties=""Excel 12.0;HDR=YES;"" ", Filename);

                //Create the connection
                System.Data.OleDb.OleDbCommand OleCmd = null;
                System.Data.OleDb.OleDbConnection ExcelConnection =
                    new System.Data.OleDb.OleDbConnection(ConnString);
                string Cmd = string.Empty;
                try
                {
                    ExcelConnection.Open();

                    string CrtCols = "";
                    string SelCols = "";

                    foreach (ExcelToMapInfo em in arrColInfo)
                    {
                        CrtCols += ",[" + em.ExcelName + "] varchar(250)";
                        SelCols += "," + em.TblColName;
                    }

                    OleCmd = new System.Data.OleDb.OleDbCommand("", ExcelConnection);

                    //  If they need to create the table, lets do it now.
                    if (CreateSheet)
                    {
                        OleCmd.CommandText = "Create Table [" + SheetName + "] (" + CrtCols.Substring(1) + ")";
                        OleCmd.ExecuteNonQuery();
                    }

                    BasicOraReader Rdr = new BasicOraReader(DbAccess.GetOracleConnectionString());
                    Cmd = string.Format("select {0} from {1}", SelCols.Substring(1), FnlTableName);
                    if (Where.Length > 0)
                        Cmd += " where " + Where;

                    if (Rdr.Open(Cmd) == false)
                    {
                        ExcelConnection.Dispose();
                        OleCmd.Dispose();
                        throw new Exception(Rdr.LastErrorMessage);

                    }

                    RecCnt = 0;
                    while (Rdr.oraRdr.Read())
                    {
                        Cmd = string.Format("insert into [{0}$] values (", SheetName);
                        for (int c = 0; c < Rdr.oraRdr.FieldCount; c++)
                        {
                            if (c > 0)
                                Cmd += ",";
                            if (Rdr.oraRdr.IsDBNull(c))
                                Cmd += "NULL";
                            else
                                Cmd += "'" + Rdr.oraRdr.GetValue(c).ToString() + "'";
                        }
                        OleCmd.CommandText = Cmd + ")";

                        OleCmd.ExecuteNonQuery();
                        RecCnt++;
                    }
                    Rdr.Close();
                }
                catch (Exception ex)
                {
                    GeneralDatabaseAccess.LogEvent(Requestor, "CopyTableToExcel", Cmd, ex, UserToolLogLevel.Error);
                    return -1;
                }
                finally
                {
                    if (OleCmd != null)
                        OleCmd.Dispose();
                    ExcelConnection.Dispose();
                }
            }
            catch (Exception ex1)
            {
                GeneralDatabaseAccess.LogEvent(Requestor, "DbAccess.cs", "CopyTableToExcel", ex1, UserToolLogLevel.Error);
            }
            return RecCnt;
        }

        public static int WriteDataToCsv(string requestor, string filename, string sheetName, string commandText) {
            int rowsWritten = 0;
            System.Diagnostics.Debug.WriteLine(DateTime.Now);
            StringBuilder currentLine = new StringBuilder();
            try {
                System.Diagnostics.Debug.WriteLine(commandText);
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(commandText, connection)) {
                    connection.Open();
                    
                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        System.Diagnostics.Debug.WriteLine("FetchSize: " + reader.FetchSize);
                        using (StreamWriter writer = new StreamWriter(filename)) {
                            for (int i = 0; i < (reader.FieldCount - 1); i++) {
                                currentLine.Append(reader.GetName(i));
                                currentLine.Append(",");
                            }
                            currentLine.AppendLine(reader.GetName((reader.FieldCount - 1)));
                            writer.Write(currentLine.ToString());
                            GeneralDatabaseAccess.LogEvent(requestor, "DBAccess.cs", MethodBase.GetCurrentMethod().Name, string.Format("Writing CSV of {0}", sheetName), UserToolLogLevel.Message);

                            while (reader.Read()) {
                                currentLine.Clear();
                                for (int i = 0; i < (reader.FieldCount - 1); i++) {
                                    currentLine.Append(reader.IsDBNull(i) ? "NULL" : reader[i]);
                                    currentLine.Append(',');
                                }
                                currentLine.AppendLine(reader.IsDBNull(reader.FieldCount - 1) ? "NULL" : reader[reader.FieldCount - 1].ToString());
                                writer.Write(currentLine.ToString());
                                rowsWritten++;
                            }
                            writer.Close();
                            GeneralDatabaseAccess.LogEvent(requestor, "DBAccess.cs", MethodBase.GetCurrentMethod().Name, string.Format("Finished Writing {0} rows to CSV ", rowsWritten.ToString()), UserToolLogLevel.Message);
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(requestor, "DbAccess.cs", MethodBase.GetCurrentMethod().Name, ex, UserToolLogLevel.Error);
                return -1;
            }
            System.Diagnostics.Debug.WriteLine(DateTime.Now);
            return rowsWritten;            
        }

        public static bool WriteReportingAuditDataToCsv(string filename, string sheetName, ArrayList auditData, string requestor) {
            bool returnValue = false;
            try {
                string columnHeaders = @"dim_rpt_reportngline, dim_rpt_account, dim_rpt_kpi, dim_rpt_view, dim_rpt_years, dim_rpt_time, dim_rpt_scenario, dim_rpt_product, dim_rpt_subaccount, dim_rpt_servicetype, dim_rpt_function, dim_rpt_costcenter, dim_rpt_entity, dim_rpt_company, dim_rpt_Equipment,  dim_rpt_TechType, FACT_RPT_MEASURE, prp_rpt_source, TableName, AuditId, prp_rpt_owner, prp_rpt_createmodifydate, AuditFact, OwnerName";
                int rowCount = 0;

                using (StreamWriter writer = new StreamWriter(filename)) {
                    writer.WriteLine(columnHeaders);
                    foreach (FactDTO f in auditData) {
                        writer.WriteLine(string.Format(@"{0}, {1}, {2}, {3}, {4}, {5}, {6}, {7}, {8}, {9}, {10}, {11}, {12}, {13}, {14}, {15}, {16}, {17}, {18}, {19}, {20}, {21}, {22}, {23}"
                            , f.ReportingLine, f.Account, f.KPI, f.View, f.Year, f.Month, f.Scenario, f.Product, f.SubAccount, f.ServiceType
                            , f.Function, f.CostCenter, f.Entity, f.Company, f.Equipment, f.TechType, f.Fact, f.Source, f.TableName
                            , f.AuditId.ToString(), f.FactUser.UserId, string.Format("{0:MM/dd/yyyy HH:mm}", f.CreateModifyDate)
                            ,  f.FactAudit.ToString(), string.Format("{0} {1}", f.FactUser.FirstName, f.FactUser.LastName)
                        ));
                        rowCount++;
                    }  
                    writer.Dispose();
                }
                GeneralDatabaseAccess.LogEvent(requestor, "DBAccess.cs", MethodBase.GetCurrentMethod().Name, string.Format("Finished Writing {0} rows to CSV ", rowCount.ToString()), UserToolLogLevel.Message);

                returnValue = true;
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(requestor, "DbAccess.cs", MethodBase.GetCurrentMethod().Name, ex, UserToolLogLevel.Error);
            }
            return returnValue;
        }

        /// <summary>
        /// 24524 - location version 
        /// </summary>
        public static bool WriteLocationAuditDataToCsv(string filename, string sheetName, ArrayList auditData, string requestor) {
            bool returnValue = false;
            try {
                int rowCount = 0;

                using (StreamWriter writer = new StreamWriter(filename)) {
                    writer.WriteLine(@"reporting_line, account, kpi, views, year, time, scenario, product, subaccount, service_type, function, cost_center, location, Equipment, Tech_Type, store_status, design_type, location_type, location_subtype, location_tier_code, amount, source, TableName, Audit_Id, owner, date_modified, AuditFact, OwnerName");
                    foreach (FactDTO f in auditData) {
                        writer.WriteLine(string.Format(@"{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},{15},{16},{17},{18},{19},{20},{21},{22},{23},{24},{25},{26},{27}"
                                , f.ReportingLine, f.Account, f.KPI, f.View, f.Year, f.Month, f.Scenario, f.Product, f.SubAccount, f.ServiceType
                                , f.Function, f.CostCenter, f.Entity, f.Equipment, f.TechType, f.StoreStatus, f.LocationType, f.DesignType
                                , f.LocationSubtype, f.LocationTierCode, f.Fact, f.Source, f.TableName, f.AuditId.ToString(), f.FactUser.UserId
                                , string.Format("{0:MM/dd/yyyy HH:mm}", f.CreateModifyDate), f.FactAudit.ToString()
                                , string.Format("{0} {1}", f.FactUser.FirstName, f.FactUser.LastName)
                        ));
                        rowCount++;
                    } 
                    writer.Dispose();
                }
                GeneralDatabaseAccess.LogEvent(requestor, "DBAccess.cs", MethodBase.GetCurrentMethod().Name, string.Format("Finished Writing {0} rows to CSV ", rowCount.ToString()), UserToolLogLevel.Message);

                returnValue = true;
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(requestor, "DbAccess.cs", MethodBase.GetCurrentMethod().Name, ex, UserToolLogLevel.Error);
            }
            return returnValue;
        }

        public static bool WriteEquipmentAuditDataToCsv(string filename, string sheetName, ArrayList auditData, string requestor) {
            bool returnValue = false;
            try {
                int rowCount = 0;

                using (StreamWriter writer = new StreamWriter(filename)) {
                    writer.WriteLine(@"Fact_Date, Reporting_Line, Entity, Cost_Center, scenario, KPI, Views, Function, Service_Type, Equipment, Tech_Type, Methodology_Type, Sale_Type, Discount_Type, Contract_Term, amount, source, TableName, Audit_Id, owner, date_modified, AuditFact, OwnerName");                 
                    foreach (FactDTO f in auditData) {
                        writer.WriteLine(
                            string.Format(@"{0:MM/dd/yyyy},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},{15},{16},{17},{18},{19},{20:MM/dd/yyyy HH:mm},{21},{22} {23}"
                                , f.FactDate, f.ReportingLine, f.Entity, f.CostCenter
                                , f.Scenario, f.KPI, f.View, f.Function, f.ServiceType, f.Equipment, f.TechType
                                , f.MethodType, f.SaleType, f.DiscountType, f.ContractTerm, f.Fact, f.Source, f.TableName
                                , f.AuditId.ToString(), f.FactUser.UserId, f.CreateModifyDate, f.FactAudit.ToString()
                                , f.FactUser.FirstName, f.FactUser.LastName
                            )
                        );
                        rowCount++;
                    }
                }
                GeneralDatabaseAccess.LogEvent(requestor, "DBAccess.cs", MethodBase.GetCurrentMethod().Name, string.Format("Finished writing {0} rows to CSV ", rowCount.ToString()), UserToolLogLevel.Message);

                returnValue = true;
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(requestor, "DbAccess.cs", MethodBase.GetCurrentMethod().Name, ex, UserToolLogLevel.Error);
            }

            return returnValue;
        }

        public static bool WriteDataWarehouseAuditDataToCsv(string filename, string sheetName, ArrayList auditData, string requestor) {
            bool returnValue = false;
            try {
                int rowCount = 0;

                using (StreamWriter writer = new StreamWriter(filename)) {
                    writer.WriteLine(@"customer_account, branch, connection_type, equipment, previous_type, function, kpi, entity, owning_geography, owning_manager, product, reporting_line, scenario, segment, service_type, subaccount, tech_type, version, vertical, views, contract_term, program_eligibility, Year, Time,amount, source, TableName, Audit_Id, owner, date_modified, AuditFact, OwnerName");
                    foreach (FactDTO f in auditData) {
                        writer.WriteLine(string.Format(@"{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},{15},{16},{17},{18},{19},{20},{21},{22},{23},{24},{25},{26},{27},{28},{29},{30},{31}"
                            , f.Account, f.Branch, f.ConnectionType, f.Equipment, f.PreviousType, f.Function, f.KPI, f.Entity, f.OwningGeo
                            , f.OwningMgr, f.Product, f.ReportingLine, f.Scenario, f.Segment, f.ServiceType, f.SubAccount, f.TechType
                            , f.Version, f.Vertical, f.View, f.ContractTerm, f.ProgramEligible, f.Year, f.Month, f.Fact, f.Source, f.TableName, f.AuditId.ToString()
                            , f.FactUser.UserId, string.Format("{0:MM/dd/yyyy HH:mm}", f.CreateModifyDate), f.FactAudit.ToString()
                            , string.Format("{0} {1}", f.FactUser.FirstName, f.FactUser.LastName)
                        ));
                        rowCount++;
                    } 
                    writer.Dispose();
                }
                GeneralDatabaseAccess.LogEvent(requestor, "DBAccess.cs", MethodBase.GetCurrentMethod().Name, string.Format("Finished Writing {0} rows to CSV ", rowCount.ToString()), UserToolLogLevel.Message);

                returnValue = true;
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(requestor, "DbAccess.cs", MethodBase.GetCurrentMethod().Name, ex, UserToolLogLevel.Error);
            }

            return returnValue;
        }

        public static string BuildReportingFactDownloadSql(string requestor, FileType fileType, List<MasterDimension> dimensions, MasterFactTable masterFactTable, DateTime reportingPeriod, DateTime startDate, string filename) {
            string sqlText = string.Empty;
            
            try {
                foreach (MasterDimension dimension in dimensions) {
                    sqlText += "," + dimension.FactColumnName;
                }

                sqlText = "select /*+ PARALLEL(4) */ " + sqlText.Substring(1);

                //  Now add in the from.  For adjustments and non-Legacy data model, just go right to the table.
                //  for Legacy non-adjustment, pivot the data and only get the data we want.
                if (masterFactTable.IsLegacy) {
                    if (fileType.IsAdjustment) {
                        if (fileType.DestinationTable.ToUpper().StartsWith("RPT_")) {
                            sqlText += ",dim_rpt_years,dim_rpt_time, FACT_RPT_MEASURE";
                            sqlText += string.Format(@" from {3} where FACT_RPT_MEASURE is not null and 
                             to_number(dim_rpt_years) * 100 + to_number(dim_rpt_time) >= {1} and 
                             to_number(dim_rpt_years) * 100 + to_number(dim_rpt_time) <= {2} and prp_rpt_source='{0}'",
                                 fileType.FileTypeCode, startDate.ToString("yyyyMM"), reportingPeriod.ToString("yyyyMM"), masterFactTable.FactTableWithValues);
                        } else if (fileType.DestinationTable.ToUpper().StartsWith("CPGA_")) {
                            sqlText += ",year, month, fact, modifydate, owner ";
                            sqlText += string.Format(@" from {3} where FACT is not null and 
                              year * 100 + month >= {1} and 
                              year * 100 + month <= {2} and source='{0}'",
                                 fileType.FileTypeCode, startDate.ToString("yyyyMM"), reportingPeriod.ToString("yyyyMM"), masterFactTable.FactTableWithValues);
                        }
                    } else {
                        sqlText += string.Format(
@"  , dim_rpt_years, to_number(dim_rpt_time) dim_rpt_time, fact_rpt_measure, prp_rpt_owner updated_by, prp_rpt_createmodifydate updated_on
  from {3}
    unpivot (
      fact_rpt_measure for dim_rpt_time in ( 
        fact_begbal as '0', fact_jan as '1', fact_feb as '2', fact_mar as '3'
        , fact_apr as '4', fact_may as '5', fact_jun as '6', fact_jul as '7', fact_aug as '8'
        , fact_sep as '9', fact_oct as '10', fact_nov as '11', fact_dec as '12'
      )
    )
  where prp_rpt_source='{0}' 
    and to_number(dim_rpt_years) * 100 + to_number(dim_rpt_time) >= {1} 
    and to_number(dim_rpt_years) * 100 + to_number(dim_rpt_time) <= {2}"
                            , fileType.FileTypeCode
                            , startDate.ToString("yyyyMM")
                            , reportingPeriod.ToString("yyyyMM")
                            , masterFactTable.FactTableWithValues);
                    }
                } else {
                    sqlText += ", floor(fiscal_period / 100) year, mod(fiscal_period, 100) time, fact_amt";
                    sqlText += string.Format(@", ors.User_Id updated_by, ors.date_created updated_on from {3} s
                     join ops_run_status ors on s.run_status_id=ors.run_status_id and ors.as_relates_to='{0}'
                     where s.fiscal_period >= {1} and s.fiscal_period <= {2}",
                         fileType.FileTypeCode, startDate.ToString("yyyyMM"), reportingPeriod.ToString("yyyyMM"), masterFactTable.FactTableWithValues);
                }
                return sqlText;
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(requestor, MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                return string.Empty;
            }
        }

        public static string BuildLocationFactDownloadSql(string requestor, FileType fileType, List<MasterDimension> dimensions, MasterFactTable masterFactTable, DateTime reportingPeriod, DateTime startDate, string filename) {
            string selectSqlText = string.Empty;
            string sqlText = string.Empty;
            try {
                foreach (MasterDimension dimension in dimensions) {
                    selectSqlText = string.Format("{0}{1},", selectSqlText, dimension.FactColumnName);
                }

                sqlText = string.Format(
@"select /*+ parallel(4) */ {0} substr(fiscal_period, 0, 4) as year, substr(fiscal_period, 5, 2) as time, amount 
  from {1} 
  where amount is not null and fiscal_period >= {2} and fiscal_period <= {3} and source='{4}'"
                    , selectSqlText, masterFactTable.FactTableWithValues, startDate.ToString("yyyyMM")
                    , reportingPeriod.ToString("yyyyMM"), fileType.FileTypeCode
                );
                return sqlText;
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(requestor, MethodBase.GetCurrentMethod().Name, selectSqlText, ex, UserToolLogLevel.Error);
                return string.Empty;
            }
        }

        public static string BuildEquipmentFactDownloadSql(string requestor, FileType fileType, ArrayList dimensions, MasterFactTable masterFactTable, DateTime reportingPeriod, DateTime startDate, string filename) {
            string selectSqlText = string.Empty;
            string sqlText = string.Empty;
            try {
                foreach (MasterDimension dimension in dimensions) {
                    selectSqlText = string.Format("{0}{1},", selectSqlText, dimension.FactColumnName);
                }
                sqlText = string.Format(
@"select /*+ parallel(4) */ fact_date, {0} amount, owner, date_modified 
  from {1} 
  where amount is not null and fact_date >= to_date('{2}') and fact_date <= to_date('{3}') and source='{4}'"
                    , selectSqlText, masterFactTable.FactTableWithValues, startDate.ToString("dd-MMM-yy")
                    , reportingPeriod.ToString("dd-MMM-yy"), fileType.FileTypeCode
                );

                return sqlText;
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(requestor, MethodBase.GetCurrentMethod().Name, selectSqlText, ex, UserToolLogLevel.Error);
                return string.Empty;
            }
        }

        public static string BuildDataWarehouseFactDownloadSql(string requestor, FileType fileType, List<MasterDimension> dimensions, MasterFactTable masterFactTable, DateTime reportingPeriod, DateTime startDate, string filename) {
            string selectSqlText = string.Empty;
            string sqlText = string.Empty;
            
            try {
                foreach (MasterDimension dimension in dimensions) {
                    selectSqlText = string.Format("{0}{1},", selectSqlText, dimension.FactColumnName);
                }
                sqlText = string.Format(
@"select /*+ parallel(4) */ {0} substr(fiscal_period, 0, 4) as year,  substr(fiscal_period, 5, 2) as time, amount, owner, date_modified 
  from {1} 
  where amount is not null and fiscal_period >= {2} and fiscal_period <= {3} and source='{4}'"
                    , selectSqlText, masterFactTable.FactTableWithValues, startDate.ToString("yyyyMM")
                    , reportingPeriod.ToString("yyyyMM"), fileType.FileTypeCode
                );

                return sqlText;
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(requestor, MethodBase.GetCurrentMethod().Name, selectSqlText, ex, UserToolLogLevel.Error);
                return "";
            }
        }
                
        public static ArrayList GetReportingAuditTable(FactDTO criteria, string month, string year, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            string filter = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try  {
                if (criteria.ReportingLine.Length > 0) filter += string.Format(" and a.dim_rpt_ReportngLine in ({0})", criteria.ReportingLine);
                if (criteria.Account.Length > 0) filter += string.Format(" and a.dim_rpt_Account in ({0})", criteria.Account);
                if (criteria.KPI.Length > 0) filter += string.Format(" and a.dim_rpt_KPI in ({0})", criteria.KPI);
                if (criteria.View.Length > 0) filter += string.Format(" and a.dim_rpt_View in ({0})", criteria.View);
                if (criteria.Scenario.Length > 0) filter += string.Format(" and a.dim_rpt_Scenario in ({0})", criteria.Scenario);
                if (criteria.Product.Length > 0) filter += string.Format(" and a.dim_rpt_Product in ({0})", criteria.Product);
                if (criteria.ServiceType.Length > 0) filter += string.Format(" and a.dim_rpt_ServiceType in ({0})", criteria.ServiceType);
                if (criteria.Function.Length > 0) filter += string.Format(" and a.dim_rpt_Function in ({0})", criteria.Function);
                if (criteria.CostCenter.Length > 0) filter += string.Format(" and a.dim_rpt_CostCenter in ({0})", criteria.CostCenter);
                if (criteria.Entity.Length > 0) filter += string.Format(" and a.dim_rpt_Entity in ({0})", criteria.Entity);
                if (criteria.Company.Length > 0) filter += string.Format(" and a.dim_rpt_Company in ({0})", criteria.Company);
                if (criteria.Equipment.Length > 0) filter += string.Format(" and a.dim_rpt_Equipment in ({0})", criteria.Equipment);
                if (criteria.TechType.Length > 0) filter += string.Format(" and a.dim_rpt_TechType in ({0})", criteria.TechType);

                sqlText = string.Format( 
@"select vw.dim_rpt_reportngline,vw.dim_rpt_account,vw.dim_rpt_kpi, vw.dim_rpt_view, vw.dim_rpt_years
    , vw.dim_rpt_time, vw.dim_rpt_scenario, vw.dim_rpt_product, vw.dim_rpt_subaccount, vw.dim_rpt_servicetype
    , vw.dim_rpt_function, vw.dim_rpt_costcenter, vw.dim_rpt_entity, vw.dim_rpt_company, vw.dim_rpt_equipment
    , vw.dim_rpt_techtype, vw.fact_rpt_measure, vw.prp_rpt_source, vw.tabname, vw.auditid, t.prp_rpt_owner
    , t.prp_rpt_createmodifydate, t.fact_rpt_measure auditfact, u.firstname, u.lastname
  from (
    select a.dim_rpt_reportngline, a.dim_rpt_account, a.dim_rpt_kpi, a.dim_rpt_view,a.dim_rpt_years
      , a.dim_rpt_time, a.dim_rpt_scenario, a.dim_rpt_product, a.dim_rpt_subaccount, a.dim_rpt_servicetype
      , a.dim_rpt_function, a.dim_rpt_costcenter, a.dim_rpt_entity, a.dim_rpt_company, a.dim_rpt_equipment
      , a.dim_rpt_techtype, a.fact_rpt_measure, a.auditid, a.prp_rpt_source, 'rpt_fact_tbl_adj' tabname
    from rpt_fact_tbl_adj a
    where a.dim_rpt_years='{0}' and a.dim_rpt_time='{1}' {2}
    union all
    select a.dim_rpt_reportngline, a.dim_rpt_account, a.dim_rpt_kpi, a.dim_rpt_view, a.dim_rpt_years
      , a.dim_rpt_time, a.dim_rpt_scenario, a.dim_rpt_product, a.dim_rpt_subaccount, a.dim_rpt_servicetype
      , a.dim_rpt_function, a.dim_rpt_costcenter, a.dim_rpt_entity, a.dim_rpt_company, a.dim_rpt_equipment
      , a.dim_rpt_techtype, a.fact_rpt_measure, a.auditid, a.prp_rpt_source,'rpt_fact_tbl_Proforma_adj' tabname
    from rpt_fact_tbl_proforma_adj a
    where a.dim_rpt_years='{0}' and a.dim_rpt_time='{1}' {2}
  ) vw
    left outer join rpt_fact_audit_tbl t on vw.auditid = t.auditid
    left outer join web_user_tbl u on u.userid = t.prp_rpt_owner
  order by vw.dim_rpt_reportngline,vw.dim_rpt_account,vw.dim_rpt_kpi, vw.dim_rpt_view, vw.dim_rpt_years
    , vw.dim_rpt_time, vw.dim_rpt_scenario, vw.dim_rpt_product, vw.dim_rpt_subaccount, vw.dim_rpt_servicetype
    , vw.dim_rpt_function, vw.dim_rpt_costcenter, vw.dim_rpt_entity, vw.dim_rpt_company, vw.dim_rpt_equipment
    , vw.dim_rpt_techtype, vw.auditid, t.prp_rpt_createmodifydate"
                    , year, month, filter);
                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();
                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        if (reader.HasRows) {
                            while (reader.Read()) {
                                if (rowCount < maxRows) {
                                    int i = 0;
                                    FactDTO f = new FactDTO();
                                    if (!reader.IsDBNull(i)) f.ReportingLine = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Account = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Year = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Month = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Product = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.SubAccount = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.CostCenter = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Company = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                    f.Fact = !reader.IsDBNull(++i) ? reader.GetDecimal(i).ToString() : string.Empty;
                                    if (!reader.IsDBNull(++i)) f.Source = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.TableName = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.AuditId = reader.GetDecimal(i);
                                    f.FactUser = new UserInfo();
                                    if (!reader.IsDBNull(++i)) f.FactUser.UserId = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.CreateModifyDate = reader.GetDateTime(i);
                                    f.FactAudit = !reader.IsDBNull(++i) ? reader.GetDecimal(i).ToString() : string.Empty;
                                    if (!reader.IsDBNull(++i)) f.FactUser.FirstName = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.FactUser.LastName = reader.GetString(i);
                                    a.Add(f);
                                    rowCount++;
                                } else {
                                    // max row was reached 
                                    rowsSkipped++;
                                }
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        /// <summary>
        /// 24524 - location version 
        /// </summary>
        public static ArrayList GetLocationAuditTable(FactDTO criteria, string month, string year, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            string filter = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                if (criteria.ReportingLine.Length > 0) filter += string.Format(" and f.REPORTING_LINE in ({0})", criteria.ReportingLine);
                if (criteria.Account.Length > 0) filter += string.Format(" and f.Account in ({0})", criteria.Account);
                if (criteria.KPI.Length > 0) filter += string.Format(" and f.KPI in ({0})", criteria.KPI);
                if (criteria.View.Length > 0) filter += string.Format(" and f.Views in ({0})", criteria.View);
                if (criteria.Scenario.Length > 0) filter += string.Format(" and f.Scenario in ({0})", criteria.Scenario);
                if (criteria.Product.Length > 0) filter += string.Format(" and f.Product in ({0})", criteria.Product);
                if (criteria.ServiceType.Length > 0) filter += string.Format(" and f.SERVICE_TYPE in ({0})", criteria.ServiceType);
                if (criteria.Function.Length > 0) filter += string.Format(" and f.Function in ({0})", criteria.Function);
                if (criteria.CostCenter.Length > 0) filter += string.Format(" and f.Cost_Center in ({0})", criteria.CostCenter);
                if (criteria.Entity.Length > 0) filter += string.Format(" and f.location in ({0})", criteria.Entity);
                if (criteria.Equipment.Length > 0) filter += string.Format(" and f.Equipment in ({0})", criteria.Equipment);
                if (criteria.TechType.Length > 0) filter += string.Format(" and f.Tech_Type in ({0})", criteria.TechType);
                if (criteria.StoreStatus.Length > 0) filter += string.Format(" and f.store_status in ({0})", criteria.StoreStatus);
                if (criteria.DesignType.Length > 0) filter += string.Format(" and f.design_type in ({0})", criteria.DesignType);
                if (criteria.LocationType.Length > 0) filter += string.Format(" and f.location_type in ({0})", criteria.LocationType); 
                if (criteria.LocationSubtype.Length > 0) filter += string.Format(" and f.location_subtype in ({0})", criteria.LocationSubtype);
                if (criteria.LocationTierCode.Length > 0) filter += string.Format(" and f.location_tier_code in ({0})", criteria.LocationTierCode);

                sqlText = string.Format(
@"select f.reporting_line, f.account, f.kpi, f.views, f.fiscal_period, f.scenario, f.product, f.subaccount, f.service_type
    , f.function, f.cost_center, f.location, f.equipment, f.tech_type, f.store_status, f.design_type, f.location_type
    , f.location_subtype, f.location_tier_code, f.amount, f.source, 'fact_location_user' tabname, f.audit_id
    , t.prp_rpt_createmodifydate, t.fact_rpt_measure AuditFact, t.prp_rpt_owner, u.firstname, u.lastname
  from fact_location_user f
    left outer join rpt_fact_audit_tbl t on f.Audit_Id=t.AuditId
    left outer join WEB_USER_TBL u on u.UserId=t.prp_rpt_owner
  where f.fiscal_period='{0}' and f.Audit_Id is not null  {1}
  order by f.reporting_line, f.account, f.kpi, f.views, f.scenario, f.product, f.subaccount, f.service_type, f.function
    , f.cost_center, f.location, f.Equipment, f.Tech_Type, f.store_status, f.design_type, f.location_type
    , f.location_subtype, f.location_tier_code, f.audit_id "
                    , string.Format("{0}{1}", year, month.Length == 1 ? String.Format("0{0}", month) : month)
                    , filter
                );

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();
                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        if (reader.HasRows) {
                            while (reader.Read()) {
                                if (rowCount < maxRows) {
                                    int i = 0;
                                    FactDTO f = new FactDTO();
                                    if (!reader.IsDBNull(i)) f.ReportingLine = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Account = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) {
                                        f.Year = reader[i].ToString().Substring(0, 4);
                                        f.Month = reader[i].ToString().Substring(4, 2);
                                    }
                                    if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Product = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.SubAccount = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.CostCenter = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.StoreStatus = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.DesignType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.LocationType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.LocationSubtype = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.LocationTierCode = reader.GetString(i);
                                    f.Fact = !reader.IsDBNull(++i) ? reader.GetDecimal(i).ToString() : string.Empty;
                                    if (!reader.IsDBNull(++i)) f.Source = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.TableName = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.AuditId = reader.GetDecimal(i);
                                    if (!reader.IsDBNull(++i)) f.CreateModifyDate = reader.GetDateTime(i);
                                    f.FactAudit = !reader.IsDBNull(++i) ? reader.GetDecimal(i).ToString() : string.Empty;
                                    f.FactUser = new UserInfo();
                                    if (!reader.IsDBNull(++i)) f.FactUser.UserId = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.FactUser.FirstName = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.FactUser.LastName = reader.GetString(i);
                                    a.Add(f);
                                    rowCount++;
                                } else {
                                    // max row was reached 
                                    rowsSkipped++;
                                }
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        public static ArrayList GetEquipmentAuditTable(FactDTO criteria, string day, string month, string year, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            string filter = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                if (criteria.ReportingLine.Length > 0) filter += string.Format(" and f.reporting_line in ({0})", criteria.ReportingLine);
                if (criteria.KPI.Length > 0) filter += string.Format(" and f.kpi in ({0})", criteria.KPI);
                if (criteria.View.Length > 0) filter += string.Format(" and f.views in ({0})", criteria.View);
                if (criteria.Scenario.Length > 0) filter += string.Format(" and f.scenario in ({0})", criteria.Scenario);
                if (criteria.ServiceType.Length > 0) filter += string.Format(" and f.service_type in ({0})", criteria.ServiceType);
                if (criteria.Function.Length > 0) filter += string.Format(" and f.function in ({0})", criteria.Function);
                if (criteria.CostCenter.Length > 0) filter += string.Format(" and f.cost_center in ({0})", criteria.CostCenter);
                if (criteria.Entity.Length > 0) filter += string.Format(" and f.entity in ({0})", criteria.Entity);
                if (criteria.Equipment.Length > 0) filter += string.Format(" and f.equipment in ({0})", criteria.Equipment);
                if (criteria.TechType.Length > 0) filter += string.Format(" and f.tech_type in ({0})", criteria.TechType);
                if (criteria.MethodType.Length > 0) filter += string.Format(" and f.methodology_type in ({0})", criteria.MethodType);
                if (criteria.SaleType.Length > 0) filter += string.Format(" and f.sale_type in ({0})", criteria.SaleType);
                if (criteria.DiscountType.Length > 0) filter += string.Format(" and f.discount_type in ({0})", criteria.DiscountType);
                if (criteria.ContractTerm.Length > 0) filter += string.Format(" and f.contract_term in ({0})", criteria.ContractTerm);
                if (day.Length > 0) filter += string.Format(" and to_char(f.fact_date, 'dd') = '{0}'", string.Format("0{0}", day).Substring(day.Length - 1));
                if (month.Length > 0) filter += string.Format(" and to_char(f.fact_date, 'mm') = '{0}'", string.Format("0{0}", month).Substring(month.Length - 1));
                if (year.Length > 0) filter += string.Format(" and to_char(f.fact_date, 'yyyy')  = '{0}' ", year);
                
                // remove first AND 
                if (filter.Length > 0) filter = filter.Remove(0, 4);
                
                sqlText = string.Format(
@"select f.fact_date, f.reporting_line, f.kpi, f.views, f.scenario, f.service_type, f.Function
    , f.cost_center, f.entity, f.Equipment, f.Tech_Type, f.methodology_type, f.sale_type, f.discount_type
    , f.contract_term, f.amount, f.source, 'fact_equipment_user' tabname, f.Audit_Id, t.prp_rpt_createmodifydate
    , t.fact_rpt_measure AuditFact, t.prp_rpt_owner, u.firstname, u.lastname
  from fact_equipment_user f
    left outer join rpt_fact_audit_tbl t on f.Audit_Id=t.AuditId
    left outer join WEB_USER_TBL u on u.UserId=t.prp_rpt_owner
  where {0}
  order by f.fact_date, f.reporting_line, f.kpi, f.views, f.scenario,  f.service_type, f.function
    , f.cost_center, f.entity, f.equipment, f.tech_type, f.methodology_type, f.sale_type
    , f.discount_type, f.audit_id "
                    , filter);

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();
                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        if (reader.HasRows) {
                            while (reader.Read()) {
                                if (rowCount < maxRows) {
                                    int i = 0;

                                    FactDTO f = new FactDTO();
                                    if (!reader.IsDBNull(i)) f.FactDate = reader.GetDateTime(i);
                                    if (!reader.IsDBNull(++i)) f.ReportingLine = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.CostCenter = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.MethodType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.SaleType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.DiscountType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ContractTerm = reader.GetString(i);
                                    f.Fact = (!reader.IsDBNull(++i)) ? reader.GetDecimal(i).ToString() : string.Empty;
                                    if (!reader.IsDBNull(++i)) f.Source = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.TableName = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.AuditId = reader.GetDecimal(i);
                                    if (!reader.IsDBNull(++i)) f.CreateModifyDate = reader.GetDateTime(i);
                                    f.FactAudit = (!reader.IsDBNull(++i)) ? reader.GetDecimal(i).ToString() : string.Empty;
                                    f.FactUser = new UserInfo();
                                    if (!reader.IsDBNull(++i)) f.FactUser.UserId = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.FactUser.FirstName = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.FactUser.LastName = reader.GetString(i);
                                    a.Add(f);
                                    rowCount++;
                                } else {
                                    // max row was reached 
                                    rowsSkipped++;
                                }
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        public static ArrayList GetDataWarehouseAuditTable(FactDTO criteria, string month, string year, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            string filter = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                if (criteria.Account.Length > 0) filter += string.Format(" and f.customer_account in ({0})", criteria.Account);
                if (criteria.Branch.Length > 0) filter += string.Format(" and f.branch in ({0})", criteria.Branch);
                if (criteria.ConnectionType.Length > 0) filter += string.Format(" and f.connection_type in ({0})", criteria.ConnectionType);
                if (criteria.Equipment.Length > 0) filter += string.Format(" and f.equipment in ({0})", criteria.Equipment);
                if (criteria.PreviousType.Length > 0) filter += string.Format(" and f.previous_type in ({0})", criteria.PreviousType);
                if (criteria.Function.Length > 0) filter += string.Format(" and f.function in ({0})", criteria.Function);
                if (criteria.KPI.Length > 0) filter += string.Format(" and f.kpi in ({0})", criteria.KPI);
                if (criteria.Entity.Length > 0) filter += string.Format(" and f.entity in ({0})", criteria.Entity);
                if (criteria.OwningGeo.Length > 0) filter += string.Format(" and f.owning_geography in ({0})", criteria.OwningGeo);
                if (criteria.OwningMgr.Length > 0) filter += string.Format(" and f.owning_manager in ({0})", criteria.OwningMgr);
                if (criteria.Product.Length > 0) filter += string.Format(" and f.product in ({0})", criteria.Product);
                if (criteria.ReportingLine.Length > 0) filter += string.Format(" and f.reporting_line in ({0})", criteria.ReportingLine);
                if (criteria.Scenario.Length > 0) filter += string.Format(" and f.scenario in ({0})", criteria.Scenario);
                if (criteria.Segment.Length > 0) filter += string.Format(" and f.segment in ({0})", criteria.Segment);
                if (criteria.ServiceType.Length > 0) filter += string.Format(" and f.service_type in ({0})", criteria.ServiceType);
                if (criteria.SubAccount.Length > 0) filter += string.Format(" and f.subaccount in ({0})", criteria.SubAccount);
                if (criteria.TechType.Length > 0) filter += string.Format(" and f.tech_type in ({0})", criteria.TechType);
                if (criteria.Version.Length > 0) filter += string.Format(" and f.version in ({0})", criteria.Version);
                if (criteria.Vertical.Length > 0) filter += string.Format(" and f.vertical in ({0})", criteria.Vertical);
                if (criteria.View.Length > 0) filter += string.Format(" and f.views in ({0})", criteria.View);
                if (criteria.ContractTerm.Length > 0) filter += string.Format(" and f.contract_term in ({0})", criteria.ContractTerm);
                if (criteria.ProgramEligible.Length > 0) filter += string.Format(" and f.program_eligibility in ({0})", criteria.ProgramEligible);

                sqlText = string.Format(
@"select f.fiscal_period, f.customer_account, f.branch, f.connection_type, f.Equipment, f.previous_type
    , f.function, f.kpi, f.entity, f.owning_geography, f.owning_manager, f.product, f.reporting_line
    , f.scenario, f.segment, f.service_type, f.subaccount, f.tech_type, f.version, f.vertical, f.views
    , f.contract_term, f.program_eligibility, f.amount, f.source, 'fact_DW_user' tabname, f.audit_id
    , t.prp_rpt_createmodifydate, t.fact_rpt_measure AuditFact, t.prp_rpt_owner, u.firstname, u.lastname
  from fact_dw_user f
    left outer join rpt_fact_audit_tbl t on f.audit_id=t.AuditId
    left outer join web_user_tbl u on u.UserId=t.prp_rpt_owner
  where f.fiscal_period='{0}' and f.audit_id is not null  {1}
  order by fiscal_period, f.customer_account, f.branch, f.connection_type, f.equipment, f.previous_type
    , f.function, f.kpi, f.entity, f.owning_geography, f.owning_manager, f.product, f.reporting_line
    , f.scenario, f.segment, f.service_type, f.subaccount, f.Tech_Type, f.version, f.vertical
    , f.views, f.contract_term, f.program_eligibility, f.audit_id "
                    , string.Format("{0}{1}", year, month.Length == 1 ? String.Format("0{0}", month) : month)
                    , filter
                );

                using (OracleConnection connection = new OracleConnection(GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();
                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DefaultRowsToFetch;
                        if (reader.HasRows) {
                            while (reader.Read()) {
                                if (rowCount < maxRows) {
                                    int i = 0;

                                    FactDTO f = new FactDTO();
                                    if (!reader.IsDBNull(i)) {
                                        f.Year = reader[i].ToString().Substring(0, 4);
                                        f.Month = reader[i].ToString().Substring(4, 2);
                                    }
                                    if (!reader.IsDBNull(++i)) f.Account = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Branch = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ConnectionType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Equipment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.PreviousType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Function = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.KPI = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Entity = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.OwningGeo = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.OwningMgr = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Product = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ReportingLine = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Scenario = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Segment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ServiceType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.SubAccount = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.TechType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Version = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.Vertical = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.View = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ContractTerm = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.ProgramEligible = reader.GetString(i);
                                    f.Fact = !reader.IsDBNull(++i) ? reader.GetDecimal(i).ToString() : string.Empty;
                                    if (!reader.IsDBNull(++i)) f.Source = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.TableName = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.AuditId = reader.GetDecimal(i);
                                    if (!reader.IsDBNull(++i)) f.CreateModifyDate = reader.GetDateTime(i);
                                    f.FactAudit = !reader.IsDBNull(++i) ? reader.GetDecimal(i).ToString() : string.Empty;
                                    f.FactUser = new UserInfo();
                                    if (!reader.IsDBNull(++i)) f.FactUser.UserId = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.FactUser.FirstName = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) f.FactUser.LastName = reader.GetString(i);
                                    a.Add(f);
                                    rowCount++;
                                } else {
                                    // max row was reached 
                                    rowsSkipped++;
                                }
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        #endregion
    } // end of class
} //end of namespace 
