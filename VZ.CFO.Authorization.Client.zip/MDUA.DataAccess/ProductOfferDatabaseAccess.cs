﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Security.Cryptography;
using MDUA.DTO;
using Oracle.DataAccess.Client;
using Oracle.DataAccess.Types;
using System.Reflection;


namespace MDUA.DataAccess {
    public class ProductOfferDatabaseAccess {

        private static string[] productOfferFieldNames = new string[] {
            "FACT_DATE", "REPORTING_LINE", "ENTITY", "EQUIPMENT", "SERVICE_TYPE",
	        "SCENARIO", "CONTRACT_TERM", "ORGANIZATION", "PRODUCT", "CONNECTION_TYPE", "ACCOUNT",
	        "FUNCTION", "SEGMENT", "COST_CENTER", "ORG_CHART", "ACCOUNT_SIZE", "HRHV",
	        "ETHNICITY", "AMOUNT"
        };
        
        private static string[] productOffer13MonthFieldNames = new string[] {
            "REPORTING_LINE", "ENTITY", "EQUIPMENT", "SERVICE_TYPE",
	        "SCENARIO", "CONTRACT_TERM", "ORGANIZATION", "PRODUCT", "CONNECTION_TYPE", "ACCOUNT",
	        "FUNCTION", "SEGMENT", "COST_CENTER", "ORG_CHART", "ACCOUNT_SIZE", "HRHV",
	        "ETHNICITY", "YEAR", "BEGBAL", "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", 
            "AUG", "SEP", "OCT", "NOV", "DEC" };

        private static int _maxRows = 0;

        private static int MaxRows {
            get {
                if (_maxRows == 0 && !int.TryParse(ConfigurationManager.AppSettings["UploadMaxLinesDisplayed"], out _maxRows))
                    _maxRows = 1000;
                return _maxRows;
            }
        }
        
        public ProductOfferDatabaseAccess() { }

        
        public static ReturnCodeDTO ValidateDimensionValue(string dimensionName, string value) {
            string sqlText = "etl_web_product.validate_dimension_value";
            ReturnCodeDTO rc = new ReturnCodeDTO();
            try {
                using (OracleConnection connection = new OracleConnection(DbAccess.GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;
                                        
                    command.Parameters.Add(new OracleParameter("@is_valid", OracleDbType.Int32, ParameterDirection.ReturnValue));
                    command.Parameters.Add(new OracleParameter("@i_dimension_name", OracleDbType.Varchar2, dimensionName, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@i_value", OracleDbType.Varchar2, value, ParameterDirection.Input));
                    
                    command.ExecuteNonQuery();
                    if (!Convert.ToBoolean(Convert.ToInt32(command.Parameters["@is_valid"].Value.ToString()))) {
                        rc.Message = string.Format("{0} is not a valid {1} value", value, dimensionName);
                        rc.ReturnCode = 1;
                    }
                    rc.Success = true;
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                rc.Success = false;
                rc.Message = string.Format("There was an error validating the value {0}", value);
            }

            return rc;
        }


        public static int LoadProductOfferExcelToStage(string filename, FileType fileType, string owner, bool checkFact, out string message, out int runStatusId) {
            const int maxRowsPerUpdate = 2000;
            int totalRecordsAdded = -2;     // total records returned: -1 user error, -2 program error
            int rowsSkipped = 0;
            int currentBindArrayIndex = 0;
            string sqlText = string.Empty;
            DateTime now = DateTime.Now;
            message = string.Empty;         // the return string 
            int excelRowsRead = 0;
            int numberNullFields;
            int index;
            double amountValue;
            DateTime dateValue;
            short tempShort;
            string[] fieldNames = fileType.IsOutlook || fileType.Is13Month ? ProductOfferDatabaseAccess.productOffer13MonthFieldNames : ProductOfferDatabaseAccess.productOfferFieldNames;
            Dictionary<string, int> fieldReferences = new Dictionary<string, int>();

            List<int> lineNumbersList = new List<int>();
            List<string> reportingLineList = new List<string>();
            List<string> entityList = new List<string>();
            List<string> equipmentList = new List<string>();
            List<string> serviceTypeList = new List<string>();
            List<string> scenarioList = new List<string>();
            List<string> contractTermList = new List<string>();
            List<string> organizationList = new List<string>();
            List<string> productList = new List<string>();
            List<string> connectionTypeList = new List<string>();
            List<string> accountList = new List<string>();
            List<string> functionList = new List<string>();
            List<string> segmentList = new List<string>();
            List<string> costCenterList = new List<string>();
            List<string> orgChartList = new List<string>();
            List<string> accountSizeList = new List<string>();
            List<string> hrhvList = new List<string>();
            List<string> ethnicityList = new List<string>();
            List<string> yearList = new List<string>();
            List<DateTime> factDateList = new List<DateTime>();
            List<double> amountList = new List<double>();
            List<OracleParameterStatus> amountNullList = new List<OracleParameterStatus>();
            List<double> begbalAmountList = new List<double>();
            List<OracleParameterStatus> begbalAmountNullList = new List<OracleParameterStatus>();
            List<double> januaryAmountList = new List<double>();
            List<OracleParameterStatus> januaryAmountNullList = new List<OracleParameterStatus>();
            List<double> februaryAmountList = new List<double>();
            List<OracleParameterStatus> februaryAmountNullList = new List<OracleParameterStatus>();
            List<double> marchAmountList = new List<double>();
            List<OracleParameterStatus> marchAmountNullList = new List<OracleParameterStatus>();
            List<double> aprilAmountList = new List<double>();
            List<OracleParameterStatus> aprilAmountNullList = new List<OracleParameterStatus>();
            List<double> mayAmountList = new List<double>();
            List<OracleParameterStatus> mayAmountNullList = new List<OracleParameterStatus>();
            List<double> juneAmountList = new List<double>();
            List<OracleParameterStatus> juneAmountNullList = new List<OracleParameterStatus>();
            List<double> julyAmountList = new List<double>();
            List<OracleParameterStatus> julyAmountNullList = new List<OracleParameterStatus>();
            List<double> augustAmountList = new List<double>();
            List<OracleParameterStatus> augustAmountNullList = new List<OracleParameterStatus>();
            List<double> septemberAmountList = new List<double>();
            List<OracleParameterStatus> septemberAmountNullList = new List<OracleParameterStatus>();
            List<double> octoberAmountList = new List<double>();
            List<OracleParameterStatus> octoberAmountNullList = new List<OracleParameterStatus>();
            List<double> novemberAmountList = new List<double>();
            List<OracleParameterStatus> novemberAmountNullList = new List<OracleParameterStatus>();
            List<double> decemberAmountList = new List<double>();
            List<OracleParameterStatus> decemberAmountNullList = new List<OracleParameterStatus>();

            try {
                string missingUploadFields = string.Empty;

                sqlText = string.Format(" select * from [{0}$]", fileType.FileTypeCode);

                using (OleDbConnection excelConnection = new OleDbConnection(DbAccess.GetExcelConnectionString(filename)))
                using (OleDbCommand excelCommand = new OleDbCommand(sqlText, excelConnection)) {
                    excelConnection.Open();

                    using (OleDbDataReader excelReader = excelCommand.ExecuteReader()) {
                        //  Check each field that should be in the file and make sure it is there.
                        for (int i = 0; i < fieldNames.Length; i++) {
                            bool matchWasFound = false;
                            for (int j = 0; j < excelReader.VisibleFieldCount; j++) {
                                if (fieldNames[i].Equals(excelReader.GetName(j).ToUpper())) {
                                    matchWasFound = true;
                                    fieldReferences.Add(fieldNames[i], j);  // capture index for later use
                                    break;
                                }
                            }
                            if (!matchWasFound) {
                                missingUploadFields += "<li>" + fieldNames[i];
                            }
                        }
                        if (missingUploadFields.Length > 1) {
                            message = string.Format("The Load Process failed to find the following field(s) in the file: {0}<br>", missingUploadFields);
                            runStatusId = -1;
                            return -1;
                        }

                        using (OracleConnection connection = new OracleConnection(DbAccess.GetOracleConnectionString()))
                        using (OracleCommand command = connection.CreateCommand()) {
                            connection.Open();
                            using (OracleTransaction transaction = connection.BeginTransaction()) {

                                command.CommandType = CommandType.StoredProcedure;
                                command.CommandText = "etl_web_product.start_process";

                                command.Parameters.Add(new OracleParameter("@name", OracleDbType.Varchar2, "PROD_OFFER_UPLOAD", ParameterDirection.Input));
                                command.Parameters.Add(new OracleParameter("@file_type", OracleDbType.Varchar2, fileType.FileTypeCode, ParameterDirection.Input));
                                command.Parameters.Add(new OracleParameter("@run_status_id", OracleDbType.Int32, ParameterDirection.Output));

                                command.ExecuteNonQuery();
                                runStatusId = int.Parse(command.Parameters["@run_status_id"].Value.ToString());                            

                                command.CommandType = CommandType.Text;
                                command.Parameters.Clear();
                                
                                sqlText = string.Format(
@"insert into {0} (
    line_number, reporting_line, entity, equipment, service_type, scenario, contract_term
    , organization, product, connection_type, account, function, segment, cost_center, org_chart
    , account_size, hrhv, ethnicity, source, owner, run_status_id
    {1}
    
  ) values (
    :line_nbr, :reporting_line, :entity, :equipment, :service_type, :scenario, :contract_term
    , :organization, :product, :connection_type, :account, :function, :segment, :cost_center, :org_chart
    , :account_size, :hrhv, :ethnicity, '{2}', '{3}', {4}
    {5}
  )"
                                    , fileType.Is13Month || fileType.IsOutlook ? fileType.StageYearTable : fileType.StageMonthTable
                                    , checkFact
                                         ? (fileType.Is13Month || fileType.IsOutlook
                                            ? ", year, begbal, jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, dec"
                                            : ", fact_date, amount")
                                        : string.Empty
                                    , fileType.FileTypeCode
                                    , owner
                                    , runStatusId
                                    , checkFact
                                        ? (fileType.Is13Month || fileType.IsOutlook
                                            ? ", :year, :begbal, :jan, :feb, :mar, :apr, :may, :jun, :jul, :aug, :sep, :oct, :nov, :dec"
                                            : ", :fact_date, :amount")
                                        : string.Empty);

                                command.Parameters.Clear();
                                command.CommandText = sqlText;

                                // add parameters
                                command.Parameters.Add(new OracleParameter(":line_nbr", OracleDbType.Int32));
                                command.Parameters.Add(new OracleParameter(":reporting_line", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":entity", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":equipment", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":service_type", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":scenario", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":contract_term", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":organization", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":product", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":connection_type", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":account", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":function", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":segment", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":cost_center", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":org_chart", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":account_size", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":hrhv", OracleDbType.Varchar2));
                                command.Parameters.Add(new OracleParameter(":ethnicity", OracleDbType.Varchar2));
                                                                
                                if (checkFact) {                                    
                                    if (fileType.Is13Month || fileType.IsOutlook) {
                                        command.Parameters.Add(new OracleParameter(":year", OracleDbType.Varchar2));
                                        command.Parameters.Add(new OracleParameter(":begbal", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":jan", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":feb", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":mar", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":apr", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":may", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":jun", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":jul", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":aug", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":sep", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":oct", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":nov", OracleDbType.Double));
                                        command.Parameters.Add(new OracleParameter(":dec", OracleDbType.Double));
                                    } else {
                                        command.Parameters.Add(new OracleParameter(":fact_date", OracleDbType.Date));
                                        command.Parameters.Add(new OracleParameter(":amount", OracleDbType.Double));
                                    }
                                }

                                command.BindByName = true;

                                totalRecordsAdded = 0;
                                while (excelReader.Read()) {
                                    excelRowsRead++;
                                    numberNullFields = 0;
                                    foreach (int i in fieldReferences.Values) {
                                        if (excelReader.IsDBNull(i)) numberNullFields++;
                                    }

                                    //TODO: Not sure about - 2
                                    // skip if all fields are null
                                    if (numberNullFields >= fieldNames.Length - 2) {
                                        rowsSkipped++;
                                        continue;
                                    }

                                    #region Add excel rows to lists

                                    lineNumbersList.Add(excelRowsRead);
                                    reportingLineList.Add(excelReader.GetValue(fieldReferences["REPORTING_LINE"]).ToString().Trim());
                                    accountList.Add(excelReader.GetValue(fieldReferences["ACCOUNT"]).ToString().Trim());
                                    organizationList.Add(excelReader.GetValue(fieldReferences["ORGANIZATION"]).ToString().Trim());
                                    orgChartList.Add(excelReader.GetValue(fieldReferences["ORG_CHART"]).ToString().Trim());
                                    scenarioList.Add(excelReader.GetValue(fieldReferences["SCENARIO"]).ToString().Trim());
                                    productList.Add(excelReader.GetValue(fieldReferences["PRODUCT"]).ToString().Trim());
                                    accountSizeList.Add(excelReader.GetValue(fieldReferences["ACCOUNT_SIZE"]).ToString().Trim());
                                    serviceTypeList.Add(excelReader.GetValue(fieldReferences["SERVICE_TYPE"]).ToString().Trim());
                                    functionList.Add(excelReader.GetValue(fieldReferences["FUNCTION"]).ToString().Trim());
                                    entityList.Add(excelReader.GetValue(fieldReferences["ENTITY"]).ToString().Trim());
                                    equipmentList.Add(excelReader.GetValue(fieldReferences["EQUIPMENT"]).ToString().Trim());
                                    hrhvList.Add(excelReader.GetValue(fieldReferences["HRHV"]).ToString().Trim());
                                    ethnicityList.Add(excelReader.GetValue(fieldReferences["ETHNICITY"]).ToString().Trim());
                                    costCenterList.Add(excelReader.GetValue(fieldReferences["COST_CENTER"]).ToString().Trim());
                                    connectionTypeList.Add(excelReader.GetValue(fieldReferences["CONNECTION_TYPE"]).ToString().Trim());
                                    segmentList.Add(excelReader.GetValue(fieldReferences["SEGMENT"]).ToString().Trim());
                                    contractTermList.Add(excelReader.GetValue(fieldReferences["CONTRACT_TERM"]).ToString().Trim());
                                    
                                    if (checkFact) {
                                        if (fileType.Is13Month || fileType.IsOutlook) {
                                            // validate year is a number
                                            if (!Int16.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["YEAR"])), out tempShort)) {
                                                message = string.Format("The column 'YEAR' in row {0} contains an invalid value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                yearList.Add(Convert.ToString(tempShort));
                                            }
 
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["BEGBAL"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                begbalAmountList.Add(amountValue);
                                                begbalAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                begbalAmountList.Add(0); // placeholder in array
                                                begbalAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["JAN"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                januaryAmountList.Add(amountValue);
                                                januaryAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                januaryAmountList.Add(0); // placeholder in array
                                                januaryAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["FEB"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                februaryAmountList.Add(amountValue);
                                                februaryAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                februaryAmountList.Add(0); // placeholder in array
                                                februaryAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["MAR"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                marchAmountList.Add(amountValue);
                                                marchAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                marchAmountList.Add(0); // placeholder in array
                                                marchAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["APR"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                aprilAmountList.Add(amountValue);
                                                aprilAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                aprilAmountList.Add(0); // placeholder in array
                                                aprilAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["MAY"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                mayAmountList.Add(amountValue);
                                                mayAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                mayAmountList.Add(0); // placeholder in array
                                                mayAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["JUN"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                juneAmountList.Add(amountValue);
                                                juneAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                juneAmountList.Add(0); // placeholder in array
                                                juneAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["JUL"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                julyAmountList.Add(amountValue);
                                                julyAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                julyAmountList.Add(0); // placeholder in array
                                                julyAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["AUG"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                augustAmountList.Add(amountValue);
                                                augustAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                augustAmountList.Add(0); // placeholder in array
                                                augustAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["SEP"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                septemberAmountList.Add(amountValue);
                                                septemberAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                septemberAmountList.Add(0); // placeholder in array
                                                septemberAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["OCT"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                octoberAmountList.Add(amountValue);
                                                octoberAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                octoberAmountList.Add(0); // placeholder in array
                                                octoberAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["NOV"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                novemberAmountList.Add(amountValue);
                                                novemberAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                novemberAmountList.Add(0); // placeholder in array
                                                novemberAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["DEC"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                decemberAmountList.Add(amountValue);
                                                decemberAmountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                decemberAmountList.Add(0); // placeholder in array
                                                decemberAmountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                        } else {
                                            // validate fact date
                                            if (DateTime.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["FACT_DATE"])), out dateValue)) {
                                                factDateList.Add(dateValue);
                                            } else {
                                                message = string.Format("Fact date in row {0} contains an invalid date.", excelRowsRead);
                                                return -1;
                                            }
                                            
                                            // validate a fact column to ensure amount is valid
                                            if (double.TryParse(Convert.ToString(excelReader.GetValue(fieldReferences["AMOUNT"])).Replace(",", string.Empty).Replace(";", string.Empty), out amountValue)) {
                                                amountList.Add(amountValue);
                                                amountNullList.Add(OracleParameterStatus.Success);
                                            } else if (fileType.IsAdjustment) {
                                                message = string.Format("Fact column in row {0} contains a non-numeric or null value.", excelRowsRead);
                                                return -1;
                                            } else {
                                                amountList.Add(0); // placeholder in array
                                                amountNullList.Add(OracleParameterStatus.NullInsert);
                                            }
                                        }
                                    }

                                    #endregion

                                    currentBindArrayIndex++;
                                    index = 0;
                                    if (currentBindArrayIndex == maxRowsPerUpdate) {
                                        command.Parameters[index].Value = lineNumbersList.ToArray();
                                        command.Parameters[++index].Value = reportingLineList.ToArray();
                                        command.Parameters[++index].Value = entityList.ToArray();
                                        command.Parameters[++index].Value = equipmentList.ToArray();
                                        command.Parameters[++index].Value = serviceTypeList.ToArray();
                                        command.Parameters[++index].Value = scenarioList.ToArray();
                                        command.Parameters[++index].Value = contractTermList.ToArray();
                                        command.Parameters[++index].Value = organizationList.ToArray();
                                        command.Parameters[++index].Value = productList.ToArray();
                                        command.Parameters[++index].Value = connectionTypeList.ToArray();
                                        command.Parameters[++index].Value = accountList.ToArray();
                                        command.Parameters[++index].Value = functionList.ToArray();
                                        command.Parameters[++index].Value = segmentList.ToArray();
                                        command.Parameters[++index].Value = costCenterList.ToArray();
                                        command.Parameters[++index].Value = orgChartList.ToArray();
                                        command.Parameters[++index].Value = accountSizeList.ToArray();
                                        command.Parameters[++index].Value = hrhvList.ToArray();
                                        command.Parameters[++index].Value = ethnicityList.ToArray();
                                        
                                        if (checkFact) {                                            
                                            if (fileType.Is13Month || fileType.IsOutlook) {
                                                command.Parameters[++index].Value = yearList.ToArray();
                                                command.Parameters[++index].Value = begbalAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = begbalAmountNullList.ToArray();
                                                command.Parameters[++index].Value = januaryAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = januaryAmountNullList.ToArray();
                                                command.Parameters[++index].Value = februaryAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = februaryAmountNullList.ToArray();
                                                command.Parameters[++index].Value = marchAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = marchAmountNullList.ToArray();
                                                command.Parameters[++index].Value = aprilAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = aprilAmountNullList.ToArray();
                                                command.Parameters[++index].Value = mayAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = mayAmountNullList.ToArray();
                                                command.Parameters[++index].Value = juneAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = juneAmountNullList.ToArray();
                                                command.Parameters[++index].Value = julyAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = julyAmountNullList.ToArray();
                                                command.Parameters[++index].Value = augustAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = augustAmountNullList.ToArray();
                                                command.Parameters[++index].Value = septemberAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = septemberAmountNullList.ToArray();
                                                command.Parameters[++index].Value = octoberAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = octoberAmountNullList.ToArray();
                                                command.Parameters[++index].Value = novemberAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = novemberAmountNullList.ToArray();
                                                command.Parameters[++index].Value = decemberAmountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = decemberAmountNullList.ToArray();
                                            } else {
                                                command.Parameters[++index].Value = factDateList.ToArray();
                                                command.Parameters[++index].Value = amountList.ToArray();
                                                command.Parameters[index].ArrayBindStatus = amountNullList.ToArray();
                                            }
                                        }

                                        command.ArrayBindCount = currentBindArrayIndex;
                                        totalRecordsAdded += command.ExecuteNonQuery();
                                        currentBindArrayIndex = 0;
                                        lineNumbersList.Clear();
                                        reportingLineList.Clear();
                                        accountList.Clear();
                                        organizationList.Clear();
                                        orgChartList.Clear();
                                        scenarioList.Clear();
                                        productList.Clear();
                                        accountSizeList.Clear();
                                        serviceTypeList.Clear();
                                        functionList.Clear();
                                        entityList.Clear();
                                        equipmentList.Clear();
                                        hrhvList.Clear();
                                        costCenterList.Clear();
                                        connectionTypeList.Clear();
                                        segmentList.Clear();
                                        contractTermList.Clear();
                                        ethnicityList.Clear();
                                        
                                        if (checkFact) {
                                            if (fileType.Is13Month || fileType.IsOutlook) {
                                                yearList.Clear();
                                                index = command.Parameters.IndexOf(":begbal"); // this offset is important
                                                begbalAmountList.Clear();
                                                begbalAmountNullList.Clear();
                                                command.Parameters[index].ArrayBindStatus = null;
                                                januaryAmountList.Clear();
                                                januaryAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                februaryAmountList.Clear();
                                                februaryAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                marchAmountList.Clear();
                                                marchAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                aprilAmountList.Clear();
                                                aprilAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                mayAmountList.Clear();
                                                mayAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                juneAmountList.Clear();
                                                juneAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                julyAmountList.Clear();
                                                julyAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                augustAmountList.Clear();
                                                augustAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                septemberAmountList.Clear();
                                                septemberAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                octoberAmountList.Clear();
                                                octoberAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                novemberAmountList.Clear();
                                                novemberAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                                decemberAmountList.Clear();
                                                decemberAmountNullList.Clear();
                                                command.Parameters[++index].ArrayBindStatus = null;
                                            } else {
                                                factDateList.Clear();
                                                amountList.Clear();
                                                amountNullList.Clear();
                                                command.Parameters[":amount"].ArrayBindStatus = null;
                                            }
                                        }
                                    }
                                }
                                index = 0;
                                if (currentBindArrayIndex > 0) {
                                    command.Parameters[index].Value = lineNumbersList.ToArray();
                                    command.Parameters[++index].Value = reportingLineList.ToArray();
                                    command.Parameters[++index].Value = entityList.ToArray();
                                    command.Parameters[++index].Value = equipmentList.ToArray();
                                    command.Parameters[++index].Value = serviceTypeList.ToArray();
                                    command.Parameters[++index].Value = scenarioList.ToArray();
                                    command.Parameters[++index].Value = contractTermList.ToArray();
                                    command.Parameters[++index].Value = organizationList.ToArray();
                                    command.Parameters[++index].Value = productList.ToArray();
                                    command.Parameters[++index].Value = connectionTypeList.ToArray();
                                    command.Parameters[++index].Value = accountList.ToArray();
                                    command.Parameters[++index].Value = functionList.ToArray();
                                    command.Parameters[++index].Value = segmentList.ToArray();
                                    command.Parameters[++index].Value = costCenterList.ToArray();
                                    command.Parameters[++index].Value = orgChartList.ToArray();
                                    command.Parameters[++index].Value = accountSizeList.ToArray();
                                    command.Parameters[++index].Value = hrhvList.ToArray();
                                    command.Parameters[++index].Value = ethnicityList.ToArray();
                                    
                                    if (checkFact) {
                                        if (fileType.Is13Month || fileType.IsOutlook) {
                                            command.Parameters[++index].Value = yearList.ToArray();
                                            command.Parameters[++index].Value = begbalAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = begbalAmountNullList.ToArray();
                                            command.Parameters[++index].Value = januaryAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = januaryAmountNullList.ToArray();
                                            command.Parameters[++index].Value = februaryAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = februaryAmountNullList.ToArray();
                                            command.Parameters[++index].Value = marchAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = marchAmountNullList.ToArray();
                                            command.Parameters[++index].Value = aprilAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = aprilAmountNullList.ToArray();
                                            command.Parameters[++index].Value = mayAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = mayAmountNullList.ToArray();
                                            command.Parameters[++index].Value = juneAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = juneAmountNullList.ToArray();
                                            command.Parameters[++index].Value = julyAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = julyAmountNullList.ToArray();
                                            command.Parameters[++index].Value = augustAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = augustAmountNullList.ToArray();
                                            command.Parameters[++index].Value = septemberAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = septemberAmountNullList.ToArray();
                                            command.Parameters[++index].Value = octoberAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = octoberAmountNullList.ToArray();
                                            command.Parameters[++index].Value = novemberAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = novemberAmountNullList.ToArray();
                                            command.Parameters[++index].Value = decemberAmountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = decemberAmountNullList.ToArray();
                                        } else {
                                            command.Parameters[++index].Value = factDateList.ToArray();
                                            command.Parameters[++index].Value = amountList.ToArray();
                                            command.Parameters[index].ArrayBindStatus = amountNullList.ToArray();
                                        }
                                    }
                                    command.ArrayBindCount = currentBindArrayIndex;
                                    totalRecordsAdded += command.ExecuteNonQuery();
                                }
                                transaction.Commit();
                            }
                            excelReader.Close();
                            excelConnection.Close();
                            connection.Close();
                        }
                    }
                }
            } catch (OleDbException) {
                message = string.Format("There was an error opening the Excel file.  Make sure that a Worksheet named '{0}' exists.", fileType.FileTypeCode);
                runStatusId = -1;
                return -1;
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                message = ex.Message + "<BR>" + ex.StackTrace;
                runStatusId = -1;
                return -2;
            }
            System.Diagnostics.Debug.WriteLine(DateTime.Now);
            return totalRecordsAdded;
        }

        public static ArrayList ProcessStagedData(int runStatusId, string fiscalPeriod, FileType fileType, string userId, out StageProcessingStatus status, out string message, out int rows, out int rowsSkipped) {
            string sqlText = "etl_web_product.process_stage_to_fact";
            int rowCount = 0;
            ArrayList results = new ArrayList();
            int procedureStatus;
            rows = 0;
            rowsSkipped = 0;
            try {
                using (OracleConnection connection = new OracleConnection(DbAccess.GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new OracleParameter("@i_run_status_id", OracleDbType.Int32, runStatusId, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@i_user_id", OracleDbType.Varchar2, userId, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@i_source", OracleDbType.Varchar2, fileType.FileTypeCode, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@i_fiscal_period", OracleDbType.Varchar2, fiscalPeriod, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@status", OracleDbType.Int32, ParameterDirection.Output));
                    command.Parameters.Add(new OracleParameter("@rows", OracleDbType.Int32, ParameterDirection.Output));

                    command.ExecuteNonQuery();
                    procedureStatus = Convert.ToInt32(command.Parameters["@status"].Value.ToString());
                    rows = Convert.ToInt32(command.Parameters["@rows"].Value.ToString());
                    message = string.Empty;
                    status = (StageProcessingStatus)procedureStatus;
                    command.Parameters.Clear();
                    command.CommandType = CommandType.Text;

                    switch (status) {
                        case StageProcessingStatus.CriticalValidationsFailed:
                        case StageProcessingStatus.AdditionOfKeysRequired:
                            command.CommandText = string.Format(
@"
select a.line_number, b.message
  , a.reporting_line, a.entity, a.equipment, a.service_type
  , a.scenario, a.contract_term, a.organization, a.product, a.connection_type
  , a.account, a.function, a.segment, a.cost_center, a.org_chart, a.account_size
  , a.hrhv, a.ethnicity, a.source, a.owner, a.run_status_id
  {0}
from {1} a, web_validation_tracking b
where a.run_status_id = b.run_status_id and a.line_number = b.line_number
  and a.run_status_id = :i_run_status_id
order by line_number"
                                
                                , fileType.Is13Month ? ", a.year, a.begbal, a.jan, a.feb, a.mar, a.apr, a.may, a.jun, a.jul, a.aug, a.sep, a.oct, a.nov, a.dec" : ", a.fact_date, a.amount"
                                , fileType.Is13Month ? "stg_product_offer_user_13m" : "stg_product_offer_user") ;
                            command.Parameters.Add(new OracleParameter("@i_run_status_id", OracleDbType.Int32, runStatusId, ParameterDirection.Input));
                            using (OracleDataReader reader = command.ExecuteReader()) {
                                reader.FetchSize = command.RowSize * DbAccess.DefaultRowsToFetch;
                                if (reader.HasRows) {
                                    int i;
                                    while (reader.Read()) {
                                        if (rowCount < MaxRows) {
                                            rowCount++;
                                            i = 0;
                                            ProductOfferFact record = new ProductOfferFact();
                                            if (!reader.IsDBNull(i)) record.Line = reader.GetDecimal(i);
                                            if (!reader.IsDBNull(++i)) record.Message = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.ReportingLine = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Entity = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Equipment = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.ServiceType = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Scenario = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.ContractTerm = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Organization = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Product = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.ConnectionType = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Account = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Function = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Segment = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.CostCenter = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.OrgChart = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.AccountSize = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.HRHV = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Ethnicity = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Source = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Owner = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.RunStatusId = reader.GetValue(i).ToString();

                                            if (fileType.Is13Month) {
                                                if (!reader.IsDBNull(++i)) record.Year = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_BegBal = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Jan = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Feb = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Mar = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Apr = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_May = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Jun = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Jul = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Aug = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Sep = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Oct = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Nov = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Dec = reader.GetValue(i).ToString();
                                            } else {
                                                if (!reader.IsDBNull(++i)) record.FactDate = reader.GetDateTime(i);
                                                if (!reader.IsDBNull(++i)) record.Amount = reader.GetValue(i).ToString();
                                            }
                                            results.Add(record);
                                        } else {
                                            rowsSkipped++;
                                        }
                                    }
                                }
                                reader.Close();
                            }

                            break;                        
                        case StageProcessingStatus.LoadedToFact:
                            command.CommandText = fileType.Is13Month ?
@"with base_data as (
    select a.reporting_line, a.entity, a.equipment, a.service_type
      , a.scenario, a.contract_term, a.organization, a.product, a.connection_type
      , a.account, a.function, a.segment, a.cost_center, a.org_chart, a.account_size
      , a.hrhv, a.ethnicity, a.source, a.owner, a.run_status_id
      , to_char(a.fact_date, 'MM') month, to_char(a.fact_date, 'YYYY') year, a.amount, count(*) over () total_records
    from fact_product_offer_user a
    where a.run_status_id = :i_run_status_id
  )
  select reporting_line, entity, equipment, service_type
      , scenario, contract_term, organization, product, connection_type
      , account, function, segment, cost_center, org_chart, account_size
      , hrhv, ethnicity, source, owner, run_status_id
      , year, begbal, jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, dec
  from (
    select * from base_data
    pivot ( 
      sum(amount)for month in ( 
        '00' as begbal, '01' as jan, '02' as feb, '03' as mar, '04' as apr, '05' as may, '06' as jun
        , '07' as jul, '08' as aug, '09' as sep, '10' as oct, '11' as nov, '12' as dec
      )
    )
  ) "

                                : 
@" select a.reporting_line, a.entity, a.equipment, a.service_type
      , a.scenario, a.contract_term, a.organization, a.product, a.connection_type
      , a.account, a.function, a.segment, a.cost_center, a.org_chart, a.account_size
      , a.hrhv, a.ethnicity, a.source, a.owner, a.run_status_id
      , a.fact_date, a.amount
   from fact_product_offer_user a
   where a.run_status_id = :i_run_status_id "; 
                                
                            command.Parameters.Add(new OracleParameter("@i_run_status_id", OracleDbType.Int32, runStatusId, ParameterDirection.Input));
                            using (OracleDataReader reader = command.ExecuteReader()) {
                                reader.FetchSize = command.RowSize * DbAccess.DefaultRowsToFetch;
                                if (reader.HasRows) {
                                    int i;
                                    while (reader.Read()) {
                                        if (rowCount < MaxRows) {
                                            rowCount++;
                                            i = 0;
                                            ProductOfferFact record = new ProductOfferFact();
                                            if (!reader.IsDBNull(i)) record.ReportingLine = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Entity = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Equipment = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.ServiceType = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Scenario = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.ContractTerm = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Organization = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Product = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.ConnectionType = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Account = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Function = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Segment = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.CostCenter = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.OrgChart = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.AccountSize = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.HRHV = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Ethnicity = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Source = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Owner = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.RunStatusId = reader.GetValue(i).ToString();

                                            if (fileType.Is13Month) {
                                                if (!reader.IsDBNull(++i)) record.Year = reader.GetString(i);
                                                if (!reader.IsDBNull(++i)) record.Fact_BegBal = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Jan = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Feb = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Mar = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Apr = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_May = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Jun = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Jul = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Aug = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Sep = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Oct = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Nov = reader.GetValue(i).ToString();
                                                if (!reader.IsDBNull(++i)) record.Fact_Dec = reader.GetValue(i).ToString();
                                            } else {
                                                if (!reader.IsDBNull(++i)) record.FactDate = reader.GetDateTime(i);
                                                if (!reader.IsDBNull(++i)) record.Amount = reader.GetValue(i).ToString();
                                            }
                                            results.Add(record);
                                        } else {
                                            rowsSkipped++;
                                        }
                                    }
                                }
                                reader.Close();
                            }

                            break;
                    }
                    
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                message = string.Empty;
                status = StageProcessingStatus.CriticalValidationsFailed;
            }

            return results;
        }

        public static ArrayList ProcessMissingKeysAndStagedData(int runStatusId, FileType fileType, string userId, out StageProcessingStatus status, out int rows, out int rowsSkipped) {
            string sqlText = "etl_web_product.add_keys_and_load_to_fact";
            ArrayList results = new ArrayList();
            int procedureStatus;
            int rowCount = 0;
            rowsSkipped = 0;
            rows = 0;
            try {
                using (OracleConnection connection = new OracleConnection(DbAccess.GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new OracleParameter("@i_run_status_id", OracleDbType.Int32, runStatusId, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@i_user_id", OracleDbType.Varchar2, userId, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@i_source", OracleDbType.Varchar2, fileType.FileTypeCode, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@status", OracleDbType.Int32, ParameterDirection.Output));
                    command.Parameters.Add(new OracleParameter("@rows", OracleDbType.Int32, ParameterDirection.Output));

                    command.ExecuteNonQuery();
                    procedureStatus = Convert.ToInt32(command.Parameters["@status"].Value.ToString());
                    rows = Convert.ToInt32(command.Parameters["@rows"].Value.ToString());
                    status = (StageProcessingStatus)procedureStatus;
                    command.Parameters.Clear();
                    command.CommandType = CommandType.Text;
                    command.CommandText = fileType.Is13Month ?
@"with base_data as (
    select a.reporting_line, a.entity, a.equipment, a.service_type
      , a.scenario, a.contract_term, a.organization, a.product, a.connection_type
      , a.account, a.function, a.segment, a.cost_center, a.org_chart, a.account_size
      , a.hrhv, a.ethnicity, a.source, a.owner, a.run_status_id
      , to_char(a.fact_date, 'MM') month, to_char(a.fact_date, 'YYYY') year, a.amount
    from fact_product_offer_user a
    where a.run_status_id = :i_run_status_id
  )
  select reporting_line, entity, equipment, service_type
      , scenario, contract_term, organization, product, connection_type
      , account, function, segment, cost_center, org_chart, account_size
      , hrhv, ethnicity, source, owner, run_status_id
      , year, begbal, jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, dec
  from (
    select * from base_data
    pivot ( 
      sum(amount) for month in ( 
        '00' as begbal, '01' as jan, '02' as feb, '03' as mar, '04' as apr, '05' as may, '06' as jun
        , '07' as jul, '08' as aug, '09' as sep, '10' as oct, '11' as nov, '12' as dec
      )
    )
  )"
                            : 
@"select * from (
    select a.reporting_line, a.entity, a.equipment, a.service_type
      , a.scenario, a.contract_term, a.organization, a.product, a.connection_type
      , a.account, a.function, a.segment, a.cost_center, a.org_chart, a.account_size
      , a.hrhv, a.ethnicity, a.source, a.owner, a.run_status_id
      , a.fact_date, a.amount
   from fact_product_offer_user a
   where a.run_status_id = :i_run_status_id
 )";

                    command.Parameters.Add(new OracleParameter("@i_run_status_id", OracleDbType.Int32, runStatusId, ParameterDirection.Input));
                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DbAccess.DefaultRowsToFetch;
                        if (reader.HasRows) {
                            int i;
                            while (reader.Read()) {
                                if (rowCount < MaxRows) {
                                    rowCount++;
                                    i = 0;
                                    ProductOfferFact record = new ProductOfferFact();
                                    if (!reader.IsDBNull(i)) record.ReportingLine = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.Entity = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.Equipment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.ServiceType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.Scenario = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.ContractTerm = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.Organization = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.Product = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.ConnectionType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.Account = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.Function = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.Segment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.CostCenter = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.OrgChart = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.AccountSize = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.HRHV = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.Ethnicity = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.Source = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.Owner = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.RunStatusId = reader.GetValue(i).ToString();

                                    if (fileType.Is13Month) {
                                        if (!reader.IsDBNull(++i)) record.Year = reader.GetString(i);
                                        if (!reader.IsDBNull(++i)) record.Fact_BegBal = reader.GetValue(i).ToString();
                                        if (!reader.IsDBNull(++i)) record.Fact_Jan = reader.GetValue(i).ToString();
                                        if (!reader.IsDBNull(++i)) record.Fact_Feb = reader.GetValue(i).ToString();
                                        if (!reader.IsDBNull(++i)) record.Fact_Mar = reader.GetValue(i).ToString();
                                        if (!reader.IsDBNull(++i)) record.Fact_Apr = reader.GetValue(i).ToString();
                                        if (!reader.IsDBNull(++i)) record.Fact_May = reader.GetValue(i).ToString();
                                        if (!reader.IsDBNull(++i)) record.Fact_Jun = reader.GetValue(i).ToString();
                                        if (!reader.IsDBNull(++i)) record.Fact_Jul = reader.GetValue(i).ToString();
                                        if (!reader.IsDBNull(++i)) record.Fact_Aug = reader.GetValue(i).ToString();
                                        if (!reader.IsDBNull(++i)) record.Fact_Sep = reader.GetValue(i).ToString();
                                        if (!reader.IsDBNull(++i)) record.Fact_Oct = reader.GetValue(i).ToString();
                                        if (!reader.IsDBNull(++i)) record.Fact_Nov = reader.GetValue(i).ToString();
                                        if (!reader.IsDBNull(++i)) record.Fact_Dec = reader.GetValue(i).ToString();
                                    } else {
                                        if (!reader.IsDBNull(++i)) record.FactDate = reader.GetDateTime(i);
                                        if (!reader.IsDBNull(++i)) record.Amount = reader.GetValue(i).ToString();
                                    }                                
                                    results.Add(record);
                                } else {
                                    rowsSkipped++;
                                }
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                status = StageProcessingStatus.CriticalValidationsFailed;
            }

            return results;
        }

        public static string BuildProdOfferFactDownloadSql(FileType fileType, DateTime reportingPeriod, DateTime startDate) {
            string sqlText = string.Empty;
            try {
                sqlText = string.Format(
@"select /*+ parallel(4) */ fact_date, reporting_line, entity, equipment, service_type, scenario, contract_term, organization
    , product, connection_type, account, function, segment, cost_center, org_chart, account_size
    , hrhv, ethnicity, amount, source, audit_id, owner, run_status_id, date_created, date_modified 
  from fact_product_offer_user
  where amount is not null and fact_date >= to_date('{0}') and fact_date <= to_date('{1}') and source='{2}'"
                    , startDate.ToString("dd-MMM-yy"), reportingPeriod.ToString("dd-MMM-yy"), fileType.FileTypeCode
                );

                return sqlText;
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(null, MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                return string.Empty;
            }
        }

        public static ArrayList GetCurrentProdOfferKeys(FileType fileType, int maxRows, out int rowsSkipped) {
            string sqlText = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                sqlText = string.Format(
@" select rowid, reporting_line, entity, equipment, service_type, scenario, contract_term, organization, product
  , connection_type, account, function, segment, cost_center, org_chart, account_size, hrhv, ethnicity
from fact_product_offer_validate 
where source = '{0}'
order by reporting_line, scenario, service_type, function, cost_center, entity
  , equipment, contract_term, organization, product, connection_type, account
  , segment, org_chart, account_size, hrhv, ethnicity"
                  , fileType.FileTypeCode);

                using (OracleConnection connection = new OracleConnection(DbAccess.GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();

                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DbAccess.DefaultRowsToFetch;
                        while (reader.Read()) {
                            if (rowCount < maxRows) {
                                int i = 0;
                                ProductOfferFact f = new ProductOfferFact();
                                f.RowId = reader.GetString(i);
                                f.ReportingLine = reader.GetString(++i);
                                f.Entity = reader.GetString(++i);
                                f.Equipment = reader.GetString(++i);
                                f.ServiceType = reader.GetString(++i);
                                f.Scenario = reader.GetString(++i);
                                f.ContractTerm = reader.GetString(++i);
                                f.Organization = reader.GetString(++i);
                                f.Product = reader.GetString(++i);
                                f.ConnectionType = reader.GetString(++i);
                                f.Account = reader.GetString(++i);
                                f.Function = reader.GetString(++i);
                                f.Segment = reader.GetString(++i);
                                f.CostCenter = reader.GetString(++i);
                                f.OrgChart = reader.GetString(++i);
                                f.AccountSize = reader.GetString(++i);
                                f.HRHV = reader.GetString(++i);
                                f.Ethnicity = reader.GetString(++i);
                                a.Add(f);
                                rowCount++;
                            } else {
                                // max row was reached 
                                rowsSkipped++;
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }
        
        public static int DeleteKeys(FileType fileType, List<string> rowids, bool deleteAll) {
            const int maxRowsPerUpdate = 2000;
            int totalRecordsDeleted = 0; 
            string sqlText = string.Empty;
            int idsToProcess;
            int index = 0;
            
            try {
                using (OracleConnection connection = new OracleConnection(DbAccess.GetOracleConnectionString()))
                using (OracleCommand command = connection.CreateCommand()) {
                    connection.Open();

                    if (deleteAll) {
                        sqlText = @"delete from fact_product_offer_validate where source = :source";
                        command.CommandType = CommandType.Text;
                        command.CommandText = sqlText;
                        command.Parameters.Add(new OracleParameter("source", OracleDbType.Varchar2, fileType.FileTypeCode, ParameterDirection.Input));
                        totalRecordsDeleted = command.ExecuteNonQuery();
                    } else {
                        using (OracleTransaction transaction = connection.BeginTransaction()) {
                            sqlText = @"delete from fact_product_offer_validate where rowid = chartorowid(:rid)";
                            command.CommandType = CommandType.Text;
                            command.Parameters.Clear();
                            command.CommandText = sqlText;

                            command.Parameters.Add(new OracleParameter(":rid", OracleDbType.Varchar2));
                            command.BindByName = true;

                            totalRecordsDeleted = 0;
                            idsToProcess = rowids.Count;

                            index = 0;

                            while (idsToProcess > maxRowsPerUpdate) {
                                command.Parameters[0].Value = rowids.GetRange(index, maxRowsPerUpdate).ToArray();
                                command.ArrayBindCount = maxRowsPerUpdate;
                                totalRecordsDeleted += command.ExecuteNonQuery();
                                index += maxRowsPerUpdate;
                                idsToProcess -= maxRowsPerUpdate;
                            }

                            command.Parameters[0].Value = rowids.GetRange(index, idsToProcess).ToArray();
                            command.ArrayBindCount = idsToProcess;
                            totalRecordsDeleted += command.ExecuteNonQuery();
                            transaction.Commit();
                        }
                    }
                    connection.Close();
                }


            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                return -2;
            }

            return totalRecordsDeleted;
        }

        public static void MoveKeys(FileType targetFileType, string sourceFileType, List<string> rowids, bool moveAll, out int totalFactsMoved, out int totalKeysMoved) {
            const int maxRowsPerUpdate = 2000;
            string sqlText = string.Empty;
            int idsToProcess;
            int index = 0;
            totalFactsMoved = 0;
            totalKeysMoved = 0;

            try {
                using (OracleConnection connection = new OracleConnection(DbAccess.GetOracleConnectionString()))
                using (OracleCommand command = connection.CreateCommand()) 
                using (OracleCommand commandFact = connection.CreateCommand()) {

                    connection.Open();
                    using (OracleTransaction transaction = connection.BeginTransaction()) {

                        if (moveAll) {
                            commandFact.CommandText = @"update fact_product_offer_user set source = :source where source = :previous_source";
                            commandFact.CommandType = CommandType.Text;
                            commandFact.Parameters.Add(new OracleParameter("source", OracleDbType.Varchar2, targetFileType.FileTypeCode, ParameterDirection.Input));
                            commandFact.Parameters.Add(new OracleParameter("previous_source", OracleDbType.Varchar2, sourceFileType, ParameterDirection.Input));

                            command.CommandText = @"update fact_product_offer_validate set source = :source where source = :previous_source";
                            command.CommandType = CommandType.Text;
                            command.Parameters.Add(new OracleParameter("source", OracleDbType.Varchar2, targetFileType.FileTypeCode, ParameterDirection.Input));
                            command.Parameters.Add(new OracleParameter("previous_source", OracleDbType.Varchar2, sourceFileType, ParameterDirection.Input));
                            totalFactsMoved = commandFact.ExecuteNonQuery();
                            totalKeysMoved = command.ExecuteNonQuery();                            
                        } else {
                            command.CommandType = CommandType.Text;
                            command.CommandText = string.Format(@"update fact_product_offer_validate set source = '{0}' where rowid = chartorowid(:rid)", targetFileType.FileTypeCode);
                            command.Parameters.Add(new OracleParameter(":rid", OracleDbType.Varchar2));
                            command.BindByName = true;

                            commandFact.CommandType = CommandType.Text;
                            commandFact.CommandText = string.Format(
@"update fact_product_offer_user set source = '{0}' 
  where rowid in (
    select /*+ parallel(f 4) */ f.rowid 
    from fact_product_offer_user f, fact_product_offer_validate v
    where v.rowid = chartorowid(:rid) 
      and f.reporting_line = v.reporting_line and f.entity = v.entity and f.equipment = v.equipment
      and f.service_type = v.service_type and f.scenario = v.scenario and f.contract_term = v.contract_term
      and f.organization = v.organization and f.product = v.product and f.connection_type = v.connection_type
      and f.account = v.account and f.function = v.function and f.segment = v.segment
      and f.cost_center = v.cost_center and f.org_chart = v.org_chart and f.account_size = v.account_size
      and f.hrhv = v.hrhv and f.ethnicity = v.ethnicity and f.source = v.source
  )"
                                , targetFileType.FileTypeCode);
                            commandFact.Parameters.Add(new OracleParameter(":rid", OracleDbType.Varchar2));
                            commandFact.BindByName = true;

                            totalKeysMoved = 0;
                            totalFactsMoved = 0;
                            idsToProcess = rowids.Count;

                            index = 0;

                            while (idsToProcess > maxRowsPerUpdate) {
                                command.Parameters[0].Value = rowids.GetRange(index, maxRowsPerUpdate).ToArray();
                                commandFact.Parameters[0].Value = rowids.GetRange(index, maxRowsPerUpdate).ToArray();
                                command.ArrayBindCount = maxRowsPerUpdate;
                                commandFact.ArrayBindCount = maxRowsPerUpdate;
                                totalFactsMoved += commandFact.ExecuteNonQuery();
                                totalKeysMoved += command.ExecuteNonQuery();
                                index += maxRowsPerUpdate;
                                idsToProcess -= maxRowsPerUpdate;
                            }

                            command.Parameters[0].Value = rowids.GetRange(index, idsToProcess).ToArray();
                            commandFact.Parameters[0].Value = rowids.GetRange(index, idsToProcess).ToArray();
                            command.ArrayBindCount = idsToProcess;
                            commandFact.ArrayBindCount = idsToProcess;
                            totalFactsMoved += commandFact.ExecuteNonQuery();
                            totalKeysMoved += command.ExecuteNonQuery();                            
                        }
                        transaction.Commit();
                    }
                    connection.Close();
                }

            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
            }
        }

        public static ArrayList ProcessStagedKeyData(int runStatusId, string fiscalPeriod, FileType fileType, string userId, out StageProcessingStatus status, out string message, out int rows, out int rowsSkipped) {
            string sqlText = "etl_web_product.process_staged_key_data";
            ArrayList results = new ArrayList();
            int procedureStatus;
            int rowCount = 0;
            rowsSkipped = 0;
            rows = 0;
            try {
                using (OracleConnection connection = new OracleConnection(DbAccess.GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new OracleParameter("@i_run_status_id", OracleDbType.Int32, runStatusId, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@i_user_id", OracleDbType.Varchar2, userId, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@i_source", OracleDbType.Varchar2, fileType.FileTypeCode, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@i_fiscal_period", OracleDbType.Varchar2, fiscalPeriod, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@status", OracleDbType.Int32, ParameterDirection.Output));
                    command.Parameters.Add(new OracleParameter("@rows", OracleDbType.Int32, ParameterDirection.Output));

                    command.ExecuteNonQuery();
                    procedureStatus = Convert.ToInt32(command.Parameters["@status"].Value.ToString());
                    rows = Convert.ToInt32(command.Parameters["@rows"].Value.ToString());
                    message = string.Empty;
                    status = (StageProcessingStatus)procedureStatus;
                    command.Parameters.Clear();
                    command.CommandType = CommandType.Text;

                    switch (status) {
                        case StageProcessingStatus.CriticalValidationsFailed:
                            command.CommandText = string.Format(
@"
select a.line_number, b.message
  , a.reporting_line, a.entity, a.equipment, a.service_type
  , a.scenario, a.contract_term, a.organization, a.product, a.connection_type
  , a.account, a.function, a.segment, a.cost_center, a.org_chart, a.account_size
  , a.hrhv, a.ethnicity, a.source, a.owner, a.run_status_id
from {0} a, web_validation_tracking b
where a.run_status_id = b.run_status_id and a.line_number = b.line_number
  and a.run_status_id = :i_run_status_id
order by line_number"
                                , fileType.Is13Month ? "stg_product_offer_user_13m" : "stg_product_offer_user");
                            command.Parameters.Add(new OracleParameter("@i_run_status_id", OracleDbType.Int32, runStatusId, ParameterDirection.Input));
                            using (OracleDataReader reader = command.ExecuteReader()) {
                                reader.FetchSize = command.RowSize * DbAccess.DefaultRowsToFetch;
                                if (reader.HasRows) {
                                    int i;
                                    while (reader.Read()) {
                                        if (rowCount < MaxRows) {
                                            rowCount++;
                                            i = 0;
                                            ProductOfferFact record = new ProductOfferFact();
                                            if (!reader.IsDBNull(i)) record.Line = reader.GetDecimal(i);
                                            if (!reader.IsDBNull(++i)) record.Message = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.ReportingLine = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Entity = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Equipment = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.ServiceType = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Scenario = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.ContractTerm = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Organization = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Product = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.ConnectionType = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Account = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Function = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Segment = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.CostCenter = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.OrgChart = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.AccountSize = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.HRHV = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Ethnicity = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Source = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Owner = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.RunStatusId = reader.GetValue(i).ToString();
                                            results.Add(record);
                                        } else {
                                            rowsSkipped++;
                                        }
                                    }
                                }
                                reader.Close();
                            }

                            break;
                        default:
                            if (rows == 0) {
                                return null;
                            }
                            command.CommandText = string.Format(
@"
select a.line_number, a.reporting_line, a.entity, a.equipment, a.service_type
  , a.scenario, a.contract_term, a.organization, a.product, a.connection_type
  , a.account, a.function, a.segment, a.cost_center, a.org_chart, a.account_size
  , a.hrhv, a.ethnicity, a.source, a.owner, a.run_status_id
from {0} a
where a.run_status_id = :i_run_status_id
  and line_number in (
    select line_number from web_validation_tracking where run_status_id = :i_run_status_id
  )
order by line_number"
                                , fileType.Is13Month ? "stg_product_offer_user_13m" : "stg_product_offer_user");
                            command.Parameters.Add(new OracleParameter("@i_run_status_id", OracleDbType.Int32, runStatusId, ParameterDirection.Input));
                            using (OracleDataReader reader = command.ExecuteReader()) {
                                reader.FetchSize = command.RowSize * DbAccess.DefaultRowsToFetch;
                                if (reader.HasRows) {
                                    int i;
                                    while (reader.Read()) {
                                        if (rowCount < MaxRows) {
                                            rowCount++;
                                            i = 0;
                                            ProductOfferFact record = new ProductOfferFact();
                                            if (!reader.IsDBNull(i)) record.Line = reader.GetDecimal(i);
                                            if (!reader.IsDBNull(++i)) record.ReportingLine = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Entity = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Equipment = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.ServiceType = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Scenario = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.ContractTerm = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Organization = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Product = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.ConnectionType = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Account = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Function = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Segment = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.CostCenter = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.OrgChart = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.AccountSize = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.HRHV = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Ethnicity = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Source = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.Owner = reader.GetString(i);
                                            if (!reader.IsDBNull(++i)) record.RunStatusId = reader.GetValue(i).ToString();
                                            results.Add(record);
                                        } else {
                                            rowsSkipped++;
                                        }
                                    }
                                }
                                reader.Close();
                            }

                            break;
                    }

                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                message = string.Empty;
                status = StageProcessingStatus.CriticalValidationsFailed;
            }

            return results;
        }

        public static ArrayList AddKeysFromStagedData(FileType fileType, int runStatusId, out bool addWasSuccessful, out int rows) {
            string sqlText = "etl_web_product.add_keys_from_stage";
            ArrayList results = new ArrayList();
            rows = 0;
            try {
                using (OracleConnection connection = new OracleConnection(DbAccess.GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(new OracleParameter("@i_run_status_id", OracleDbType.Int32, runStatusId, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@i_source", OracleDbType.Varchar2, fileType.FileTypeCode, ParameterDirection.Input));
                    command.Parameters.Add(new OracleParameter("@status", OracleDbType.Varchar2, ParameterDirection.Output));
                    command.Parameters["@status"].Size = 30;
                    command.Parameters.Add(new OracleParameter("@rows", OracleDbType.Int32, ParameterDirection.Output));

                    command.ExecuteNonQuery();
                    addWasSuccessful = (command.Parameters["@status"].Value.ToString() == "Y");
                    rows = Convert.ToInt32(command.Parameters["@rows"].Value.ToString());
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                addWasSuccessful = false;
            }

            return results;
        }

        public static ArrayList GetAuditTable(ProductOfferFact criteria, string month, string year, out int rowsSkipped) {
            string sqlText = string.Empty;
            string filter = string.Empty;
            ArrayList a = new ArrayList();
            int rowCount = 0;
            rowsSkipped = 0;

            try {
                if (criteria.ReportingLine.Length > 0) filter += string.Format(" and f.reporting_line in ({0})", criteria.ReportingLine);
                if (criteria.Entity.Length > 0) filter += string.Format(" and f.entity in ({0})", criteria.Entity);
                if (criteria.Equipment.Length > 0) filter += string.Format(" and f.equipment in ({0})", criteria.Equipment);
                if (criteria.ServiceType.Length > 0) filter += string.Format(" and f.service_type in ({0})", criteria.ServiceType);
                if (criteria.Scenario.Length > 0) filter += string.Format(" and f.scenario in ({0})", criteria.Scenario);
                if (criteria.ContractTerm.Length > 0) filter += string.Format(" and f.contract_term in ({0})", criteria.ContractTerm);
                if (criteria.Organization.Length > 0) filter += string.Format(" and f.organization in ({0})", criteria.Organization);
                if (criteria.Product.Length > 0) filter += string.Format(" and f.product in ({0})", criteria.Product);
                if (criteria.ConnectionType.Length > 0) filter += string.Format(" and f.connection_type in ({0})", criteria.ConnectionType);
                if (criteria.Account.Length > 0) filter += string.Format(" and f.customer_account in ({0})", criteria.Account);
                if (criteria.Function.Length > 0) filter += string.Format(" and f.function in ({0})", criteria.Function);
                if (criteria.Segment.Length > 0) filter += string.Format(" and f.segment in ({0})", criteria.Segment);               
                if (criteria.CostCenter.Length > 0) filter += string.Format(" and f.cost_center in ({0})", criteria.CostCenter);
                if (criteria.OrgChart.Length > 0) filter += string.Format(" and f.org_chart in ({0})", criteria.OrgChart);
                if (criteria.AccountSize.Length > 0) filter += string.Format(" and f.account_size in ({0})", criteria.AccountSize);                
                if (criteria.HRHV.Length > 0) filter += string.Format(" and f.hrhv in ({0})", criteria.HRHV);
                if (criteria.Ethnicity.Length > 0) filter += string.Format(" and f.ethnicity in ({0})", criteria.Ethnicity);

                sqlText = string.Format(
@" select f.fact_date, f.reporting_line, f.entity, f.equipment, f.service_type, f.scenario, f.contract_term, f.organization
  , f.product, f.connection_type, f.account, f.function, f.segment, f.cost_center, f.org_chart, f.account_size
  , f.hrhv, f.ethnicity, f.amount, f.source, f.audit_id
  , t.prp_rpt_createmodifydate, t.fact_rpt_measure AuditFact, t.prp_rpt_owner, u.firstname, u.lastname
from fact_product_offer_user f
  left outer join rpt_fact_audit_tbl t on f.audit_id=t.auditid
  left outer join web_user_tbl u on u.UserId=t.prp_rpt_owner
where to_char(f.fact_date, 'YYYYMM') = '{0}' and f.audit_id is not null  {1}
order by f.fact_date, f.reporting_line, f.entity, f.equipment, f.service_type, f.scenario, f.contract_term, f.organization
  , f.product, f.connection_type, f.account, f.function, f.segment, f.cost_center, f.org_chart, f.account_size
  , f.hrhv, f.ethnicity, f.amount, f.source, f.audit_id"
                    , string.Format("{0}{1}", year, month.Length == 1 ? String.Format("0{0}", month) : month)
                    , filter
                );

                using (OracleConnection connection = new OracleConnection(DbAccess.GetOracleConnectionString()))
                using (OracleCommand command = new OracleCommand(sqlText, connection)) {
                    connection.Open();
                    using (OracleDataReader reader = command.ExecuteReader()) {
                        reader.FetchSize = command.RowSize * DbAccess.DefaultRowsToFetch;
                        if (reader.HasRows) {
                            while (reader.Read()) {
                                if (rowCount < MaxRows) {
                                    int i = 0;

                                    ProductOfferFact record = new ProductOfferFact();
                                    if (!reader.IsDBNull(i)) record.FactDate = reader.GetDateTime(i);
                                    if (!reader.IsDBNull(++i)) record.ReportingLine = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.Entity = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.Equipment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.ServiceType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.Scenario = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.ContractTerm = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.Organization = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.Product = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.ConnectionType = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.Account = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.Function = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.Segment = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.CostCenter = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.OrgChart = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.AccountSize = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.HRHV = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.Ethnicity = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.Amount = reader.GetValue(i).ToString();
                                    if (!reader.IsDBNull(++i)) record.Source = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.AuditId = reader.GetDecimal(i);
                                    if (!reader.IsDBNull(++i)) record.DateModified = reader.GetDateTime(i);
                                    record.FactAudit = !reader.IsDBNull(++i) ? reader.GetDecimal(i).ToString() : string.Empty;
                                    record.FactUser = new UserInfo();
                                    if (!reader.IsDBNull(++i)) record.FactUser.UserId = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.FactUser.FirstName = reader.GetString(i);
                                    if (!reader.IsDBNull(++i)) record.FactUser.LastName = reader.GetString(i);
                                    a.Add(record);
                                    rowCount++;
                                } else {
                                    // max row was reached 
                                    rowsSkipped++;
                                }
                            }
                        }
                        reader.Close();
                    }
                    connection.Close();
                }
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent("", MethodBase.GetCurrentMethod().Name, sqlText, ex, UserToolLogLevel.Error);
                a = null;
            }
            return a;
        }

        public static bool WriteAuditDataToCsv(string filename, string sheetName, ArrayList auditData, string requestor) {
            bool returnValue = false;
            try {
                int rowCount = 0;

                using (StreamWriter writer = new StreamWriter(filename)) {
                    writer.WriteLine(@"fact_date, reporting_line, entity, equipment, service_type, scenario, contract_term, organization, product, connection_type, account, function, segment, cost_center, org_chart, account_size, hrhv, ethnicity, amount, source, audit_id, owner, date_modified, audit_amount, name");
                    foreach (ProductOfferFact f in auditData) {
                        writer.WriteLine(string.Format(@"{0},{1},{2},{3},{4},{5},{6},{7},{8},{9},{10},{11},{12},{13},{14},{15},{16},{17},{18},{19},{20},{21},{22},{23},{24}"
                            , string.Format("{0:MM/dd/yyyy}", f.FactDate), f.ReportingLine, f.Entity, f.Equipment, f.ServiceType, f.Scenario, f.ContractTerm, f.Organization, f.Product, f.ConnectionType, f.Account, f.Function, f.Segment, f.CostCenter, f.OrgChart, f.AccountSize, f.HRHV, f.Ethnicity, f.Amount, f.Source, f.AuditId.ToString(), f.Owner, string.Format("{0:MM/dd/yyyy HH:mm}", f.DateModified), f.FactAudit, string.Format("{0} {1}", f.FactUser.FirstName, f.FactUser.LastName)
                        ));
                        rowCount++;
                    }
                    writer.Dispose();
                }
                GeneralDatabaseAccess.LogEvent(requestor, "DBAccess.cs", MethodBase.GetCurrentMethod().Name, string.Format("Finished Writing {0} rows to CSV ", rowCount.ToString()), UserToolLogLevel.Message);

                returnValue = true;
            } catch (Exception ex) {
                GeneralDatabaseAccess.LogEvent(requestor, "DbAccess.cs", MethodBase.GetCurrentMethod().Name, ex, UserToolLogLevel.Error);
            }

            return returnValue;
        }

    
    }
}
