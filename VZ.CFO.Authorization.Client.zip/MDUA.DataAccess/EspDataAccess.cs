﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using MDUA.DTO;
using System.IO;
using System.Runtime.Serialization.Json;
using System.Net;
using System.Security.Cryptography;
namespace MDUA.DataAccess
{
    /// <summary>
    /// Data Access class to fetch response from ESP
    /// </summary>
    public class EspDataAccess
    {
        #region private variables
        private static readonly string Command = "command";
        private static readonly string PostMethod = "POST";
        private static readonly string Authorization = "Authorization";
        #endregion
        #region public attributes
        /// <summary>
        /// Esp Rest Api URL
        /// </summary>
        public static string EspRestApiUrl
        {
            get { return ConfigurationManager.AppSettings["EspRestApiUrl"].ToString(); }
        }
        /// <summary>
        /// Esp Prefix
        /// </summary>
        public static string EspPrefix
        {
            get { return ConfigurationManager.AppSettings["EspPrefix"].ToString(); }
        }

        /// <summary>
        /// Esp Timezone
        /// </summary>
        public static string EspTimezone
        {
            get { return ConfigurationManager.AppSettings["EspTimezone"].ToString(); }
        }

        /// <summary>
        /// Esp Username
        /// </summary>
        public static string EspUserName
        {
            get { return ConfigurationManager.AppSettings["EspUserName"].ToString(); }
        }

        /// <summary>
        /// EspPassword
        /// </summary>
        public static string EspPassword
        {
            get { return ConfigurationManager.AppSettings["EspPassword"].ToString(); }
        }

        #endregion
        #region public methods
        public EspMessage GetJobStatus(EspMessage request)
        {
            EspMessage jobStatusResponse = ExecuteEspCommandWrapper(request);
            return jobStatusResponse;
        }
        public EspMessage TriggerJob(EspMessage request)
        {
            EspMessage triggerJobResponse = null;
            triggerJobResponse = ExecuteEspCommandWrapper(request);
            return triggerJobResponse;
        }
        #endregion
        #region private methods
        /// <summary>
        /// Method to deserialize json. 
        /// TODO: Should be moved to Util. 
        /// Placing it here for time being to avoid circular reference to Business Logic layer
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="json"></param>
        /// <returns></returns>
        private static T DeserializeFromJson<T>(string json)
        {
            using (Stream stream = new MemoryStream())
            {
                byte[] data = System.Text.Encoding.UTF8.GetBytes(json);
                stream.Write(data, 0, data.Length);
                stream.Position = 0;
                DataContractJsonSerializer deserializer = new DataContractJsonSerializer(typeof(T));
                return (T)deserializer.ReadObject(stream);
            }
        }
        /// <summary>
        ///  Method to Serialize json. 
        ///  TODO: Should be moved to Util. 
        ///  Placing it here for time being to avoid circular reference to Business Logic layer
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        private static string SerializeToJson(object obj)
        {
            if (null == obj)
            {
                throw new ArgumentNullException("obj", "obj cannot be null");
            }
            using (MemoryStream memoryStream = new MemoryStream())
            using (StreamReader reader = new StreamReader(memoryStream))
            {
                DataContractJsonSerializer serializer = new DataContractJsonSerializer(obj.GetType());
                serializer.WriteObject(memoryStream, obj);
                memoryStream.Position = 0;
                return reader.ReadToEnd();
            }
        }

        private EspMessage ExecuteEspCommandWrapper(EspMessage request)
        {
            try
            {
                return ExecuteEspCommand(request);
            }
            catch(WebException ex)
            {
                if (ex.Status == WebExceptionStatus.ReceiveFailure || ex.Status == WebExceptionStatus.ConnectionClosed)
                {
                    //Sleep for 2 seconds and retry
                    System.Threading.Thread.Sleep(2000);
                    return ExecuteEspCommand(request);
                }
                else
                {
                    throw ex;
                }
            }
        }

        /// <summary>
        /// Executes a ESP Request
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        private EspMessage ExecuteEspCommand(EspMessage request)
        {
            // Create a request for the URL. 
            string espCommandURL = string.Format("{0}/{1}", EspRestApiUrl, Command);
            EspMessage commandResponse = null;
            Stream PostData = null;
            HttpWebResponse resp = null;
            HttpWebRequest req = null;
            StreamReader loResponseStream = null;
            try
            {
                req = WebRequest.Create(espCommandURL) as HttpWebRequest;
                //keep alive property should be false: otherwise getting random server closed error
                req.KeepAlive = false;
                req.Method = "POST";
                //ESP Rest API requires Basic Authenciation with credentials in the format: BASE64-UTF8(username:password)
                req.Headers.Add(Authorization, string.Format("{0} {1}", "Basic", GetEspAuth()));
                //Prepare post data
                string requestData = SerializeToJson(request);
                byte[] buffer = Encoding.ASCII.GetBytes(requestData);
                req.ContentLength = buffer.Length;
                req.ContentType = "application/json";
                //Get request stream and write post data
                PostData = req.GetRequestStream();
                PostData.Write(buffer, 0, buffer.Length);
                PostData.Close();
                //Get Response
                resp = req.GetResponseNoException();
                Encoding enc = System.Text.Encoding.GetEncoding(1252);
                loResponseStream = new StreamReader(resp.GetResponseStream(), enc);
                string response = loResponseStream.ReadToEnd();
                loResponseStream.Close();
                resp.Close();
                //Deserialize the response
                commandResponse = DeserializeFromJson<EspMessage>(response);
                //return the deserilized response back
                return commandResponse;
            }
            finally
            {
                if (PostData != null) PostData.Close();
                if (resp != null) resp.Close();
                if (loResponseStream != null) loResponseStream.Close();
                if (req != null) req = null;
            }
            
        }
        /// <summary>
        /// Returns EspAuth in the format base634-utf8(username:password) 
        /// </summary>
        /// <returns></returns>
        private static string GetEspAuth()
        {
            string userName = Decrypt(EspDataAccess.EspUserName, "HypMdua2008");
            string password = Decrypt(EspDataAccess.EspPassword, "HypMdua2008");
            return ConvertToBase64String(string.Format("{0}:{1}", userName, password));
        }
        #region base64 conversions

        private static string ConvertToBase64String(string text)
        {
            byte[] textBytes = System.Text.Encoding.UTF8.GetBytes(text); 
            string base64String = Convert.ToBase64String(textBytes);
            return base64String;
        }

        private static string ConvertFromBase64String(string base64Text)
        {
            byte[] textBytes = Convert.FromBase64String(base64Text);
            string clearText = System.Text.Encoding.UTF8.GetString(textBytes); 
            return clearText.Trim();
        }
        #endregion

        #region encryption
        private static string Decrypt(string cipherText, string password)
        {
            byte[] cipherBytes = Convert.FromBase64String(cipherText);
            PasswordDeriveBytes pdb = new PasswordDeriveBytes(password
                , new byte[] {
                    0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65,0x64, 0x76, 0x65, 0x64, 0x65, 0x76
                });
            return DecryptStringFromBytes(cipherBytes, pdb.GetBytes(32), pdb.GetBytes(16));
        }
        private static string DecryptStringFromBytes(byte[] cipherText, byte[] Key, byte[] IV)
        {
            // Check arguments.
            if (cipherText == null || cipherText.Length <= 0)
                throw new ArgumentNullException("cipherText");
            if (Key == null || Key.Length <= 0)
                throw new ArgumentNullException("Key");
            if (IV == null || IV.Length <= 0)
                throw new ArgumentNullException("Key");

            // Declare the string used to hold
            // the decrypted text.
            string plaintext = null;

            // Create an Rijndael object
            // with the specified key and IV.
            using (Rijndael rijAlg = Rijndael.Create())
            {
                rijAlg.Key = Key;
                rijAlg.IV = IV;

                // Create a decrytor to perform the stream transform.
                ICryptoTransform decryptor = rijAlg.CreateDecryptor(rijAlg.Key, rijAlg.IV);

                // Create the streams used for decryption.
                using (MemoryStream msDecrypt = new MemoryStream(cipherText))
                {
                    using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                        {

                            // Read the decrypted bytes from the decrypting stream
                            // and place them in a string.
                            plaintext = srDecrypt.ReadToEnd();
                        }
                    }
                }

            }

            return plaintext;

        }
        #endregion
        #endregion
    }
}
