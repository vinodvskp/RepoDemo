using System;
using System.Data;
using System.Configuration;
using System.Web;
//using System.Web.Security;
//using System.Web.UI;
//using System.Web.UI.WebControls;
//using System.Web.UI.WebControls.WebParts;
//using System.Web.UI.HtmlControls;

using System.Data.SqlClient;
using System.Collections;
using System.Collections.Generic;

/// <summary>
/// Summary description for GlobalRecs
/// </summary>
public class GlobalRecs
{
	public GlobalRecs()
	{
		//
		// TODO: Add constructor logic here
		//
	}
}

public enum LogLevel : short { FatalError = 1, Error = 3, Message = 5, Audit = 7, Debug = 9 }
public enum UserRole : short { AnonymousUser = 0, ReadOnly=1, RegUser = 3, Admin = 9 }

public class UserInfo
{
    public string EmployeeID = "";
    public string FirstName = "";
    public string LastName = "";
    public string EMail = "";
    public string UserId = "";          //  User's 5+2 ID.
    public UserRole Role = UserRole.ReadOnly;
    public bool Active = false;
    public string UserAccess = "";

    public bool CanAddUserInputKeys
    {
        get { return UserAccess.IndexOf("|ADFK|") >= 0; }
        set { UpdAccessType("ADFK", value); }
    }
    public bool CanPostAdjImmediately
    {
        get { return UserAccess.IndexOf("|ADJN|") >= 0; }
        set { UpdAccessType("ADJN", value); }
    }
    public bool CanPostAdjToAnyPeriod
    {
        get { return UserAccess.IndexOf("|POAP|") >= 0; }
        set { UpdAccessType("POAP", value); }
    }
    public bool CanAssignUserFileType
    {
        get { return UserAccess.IndexOf("|ASFT|") >= 0; }
        set { UpdAccessType("ASFT", value); }
    }
    public bool CanAssignBalShtFileType
    {
        get { return UserAccess.IndexOf("|ASBS|") >= 0; }
        set { UpdAccessType("ASBS", value); }
    }
    public bool CanAssignAutosysOD
    {
        get { return UserAccess.IndexOf("|ASAO|") >= 0; }
        set { UpdAccessType("ASAO", value); }
    }
    public bool CanAddNewFileType
    {
        get { return UserAccess.IndexOf("|ADFT|") >= 0; }
        set { UpdAccessType("ADFT", value); }
    }
    public bool CanModifyOutline
    {
        get { return UserAccess.IndexOf("|MDOL|") >= 0; }
        set { UpdAccessType("MDOL", value); }
    }
    public bool CanProcessCpga
    {
        get { return UserAccess.IndexOf("|CPGA|") >= 0; }
        set { UpdAccessType("CPGA", value); }
    }
    public bool CanPostToAnyPeriod
    {
        get { return UserAccess.IndexOf("|PFAP|") >= 0; }
        set { UpdAccessType("PFAP", value); }
    }

    public string FullName
    {
        get { return FirstName + " " + LastName; }
    }

    public UserInfo()
    {
    }

    private void UpdAccessType(string KeyVal, bool AddIt)
    {
        int Idx = UserAccess.IndexOf("|" + KeyVal + "|");
        if (AddIt)
        {
            //  Add a new key type.  If it is already here, just return.
            if (Idx >= 0)
                return;
            if (UserAccess.Length == 0)
                UserAccess = "|";
            UserAccess += KeyVal + "|";
        }
        else
        {
            //  Remove an existing key.  If it is not here, just return.
            if (Idx < 0)
                return;
            UserAccess = UserAccess.Substring(0, Idx + 1) +
                UserAccess.Substring(Idx + KeyVal.Length + 2, UserAccess.Length - Idx);
        }
    }
}

public class HypWebSettings
{
    public DateTime LastProcessed;
    public string LockedBy = "";
    public bool UserFeedEnabled = true;
    public bool CoaCorEnabled = true;
    public string UserFeedUser = "";
    public string CoaCorUser = "";
    public string CurrentPeriod = "";
    public string BroadcastMessage = "";

    public HypWebSettings()
    {
    }

    public string CurrentMonth
    {
        get { return CurrentPeriod.Substring(4); }
        set
        {
            if (CurrentPeriod.Length < 4)
                CurrentPeriod = DateTime.Now.Year.ToString();
            CurrentPeriod = CurrentPeriod.Substring(0, 4);
            if (value.Length < 2)
                CurrentPeriod += "0";
            CurrentPeriod += value;
        }
    }

    public int CurrentMonthInt
    {
        get 
        {
            int Mnth = 1;
            int.TryParse(CurrentMonth, out Mnth);
            return Mnth;
        }
        set
        {
            string Mnth = value.ToString();
            CurrentMonth = Mnth;
        }
    }

    public string CurrentMonthString
    {
        get 
        { 
            string[] Months = { "Beginning Balance","January","February","March","April","May","June",
                "July","August","September","October","November","December" };
            int mnth;
            if (int.TryParse(CurrentMonth, out mnth) == false)
                mnth = 1;
            return Months[mnth]; 
        }
    }

    public string CurrentYear
    {
        get { return CurrentPeriod.Substring(0, 4); }
        set
        {
            if (CurrentPeriod.Length < 4)
                CurrentPeriod = value;
            else
                CurrentPeriod = value + CurrentPeriod.Substring(4);
        }
    }      
}

public class HypWebLookup : IComparable
{
    public string FldType = "";
    public string Value = "";
    public string Description = "";
    public string Extra = "";

    public HypWebLookup()
    {
    }

    #region IComparable Members

    public int CompareTo(object obj)
    {
        if (obj is HypWebLookup)
            return Value.CompareTo(((HypWebLookup)obj).Value);
        if (obj is string)
            return Value.CompareTo(obj);

        throw new Exception("The method or operation is not implemented.");
    }

    #endregion
}

public class HypDimension : IComparable
{
    public int DimId = 0;
    public string Parent = "";
    public string MemberName = "";
    public string Alias = "";
    public string Alias2 = "";
    public char Location = ' ';
    public string LocationSibling = "";
    public char Consolidation = ' ';
    public string Storage = " ";
    public string Formula = "";
    public string TwoPass = "";
    public string FldComment = "";
    public string LevelNbr = "";
    public string GenerationNbr = "";
    public DateTime LastUpdated;

    //  Mapping Fields
    public string MapId = null;
    public string Function = null;
    public string Product = null;
    public string ServiceType = null;
    public string ReportingLine = null;
    public string SubAccount = null;

    public string AltFunction = null;

    public string CostCenter = null;

    //  Used to create a Tree View
    public ArrayList arrChildren = null;
    public HypDimension ParentNode = null;

    public HypDimension()
    {
    }

    #region IComparable Members

    public int CompareTo(object obj)
    {
        if (obj is HypDimension)
        {
            int Cmp = Parent.CompareTo(((HypDimension)obj).Parent);
            if (Cmp != 0)
                return Cmp;

            return MemberName.CompareTo(((HypDimension)obj).MemberName);
        }

        if (obj is string)
            return MemberName.CompareTo(obj);
        throw new Exception("The method or operation is not implemented.");
    }

    #endregion
}

public class HypMapping
{
    public string MapId = "";
    public string Account = "";
    public string Function = "";
    public string Product = "";
    public string ServiceType = "";
    public string ReportingLine = "";
    public string SubAccount = "";

    public HypMapping()
    {
    }
}

public class HypFileType : IComparable
{
    public string Cube = "";
    public string Code = "";
    public string Description = "";
    public bool isAdjustment = false;
    public bool is13Month = false;
    public bool isOutlook = false;
    public bool isUserFeed = true;
    public bool UsesValidKeyCombos = true;
    public bool ShowOnUploadStatus = true;
    public string ScheduledLoadDate = "";
    public string DestTable = "";
    public int FactTableId = 0;
    public ArrayList arrFlds = new ArrayList();

    public HypFileType()
    {
    }

    #region IComparable Members

    public int CompareTo(object obj)
    {
        if (obj is string)
            return Code.CompareTo(obj);

        if (obj is HypFileType)
            return Code.CompareTo(((HypFileType)obj).Code);

        throw new Exception("The method or operation is not implemented.");
    }

    #endregion
}

public enum HypFileTypeFldSource { UserFeed, UserDefinableUserFeed, ForcedValue, AutomapOnAccount, AutomapOnCostCenter, AutomapOnFunction };
public class HypFileTypeFlds
{
    public string Code = "";
    public string MemberName = "";
    public string ForcedValue = "";
    public HypFileTypeFldSource Source = HypFileTypeFldSource.UserFeed;

    public HypFileTypeFlds()
    {
    }
}

public class HypMappingFileType
{
    public string MappingCode = "";
    public string Description = "";
    public bool UsesStartEndDates = false;
    public string MappingTable = "";

    public ArrayList arrFlds = null;

    public HypMappingFileType()
    {
    }
}

public class HypMappingFileTypeFlds
{
    public string ConstFld = "";
    public string Value = "";

    public HypMappingFileTypeFlds()
    {
    }
}

public class HypTableColumnInfo
{
    public string Name = "";
    public string ColType = "";
    public bool IsNumber = false;
    public HypTableColumnInfo()
    {
    }
}

public class HypExcelToMapInfo
{
    public enum FldTypes { DbString, DbInteger, DbDate, DbFloat };

    public string ExcelName = "";
    public string TblColName = "";
    public FldTypes FldType = FldTypes.DbString;
    public int FldLen = 50;
    public string ValIfNull = null;
    public bool MustExist = false;
    public string TrimValues = null;

    public HypExcelToMapInfo()
    {
    }

    public HypExcelToMapInfo(string ExlColName, string DbColName, int Len)
    {
        ExcelName = ExlColName;
        TblColName = DbColName;
        FldLen = Len;
    }

    public HypExcelToMapInfo(string ExlColName, string DbColName, FldTypes ColType)
    {
        ExcelName = ExlColName;
        TblColName = DbColName;
        FldType = ColType;
    }
}

public class WPProcessInfo
{
    public string ProcessCode = "";
    public string AsRelatesTo = "";
    public int ProcessId = 0;
    public string Description = "";

    public ArrayList arrSteps = null;

    public WPProcessInfo()
    {
    }
}

public class WPProcessStep
{
    public string ClosePeriod = "";
    public string Step = "";
    public string StepDescription = "";
    public DateTime StartTime = DateTime.MinValue;
    public DateTime EndTime = DateTime.MinValue;
    public string Status = "";
    public string Message = "";
    public int NotificationId = 0;
    public int ExpectedDuration = 0;
    public int SeqNbr = 0;

    public string StatusDesc
    {
        get
        {
            switch (Status)
            {
                case "S": return "Success";
                case "P": return "Pending"; 
                case "R": return "Running"; 
                case "E": return "Error"; 
                case "C": return "Canceled"; 
                default: return "No Status"; 
            }
        }
    }

    public WPProcessStep()
    {
    }
}

public class MasterDimension : IComparable
{
    public int Id = 0;
    public string Code = "";
    public string Name = "";
    public string Type = "";
    public string MasterTable = "";
    public string ValidationColumn = "";
    public string IdColumn = "";
    public string Prefix = "";
    public string TableAlias = "";
    public string ExtraValidationClause = "";
    public string KeyComboValidation = "";
    public bool IsIncludedInUserFeed = false;
    public string StageTableColumnName = "";

    public MasterDimension()
    {
    }

    #region IComparable Members

    public int CompareTo(object obj)
    {
        if (obj is string)
            return Name.CompareTo(obj);

        if (obj is int)
            return Id.CompareTo(obj);

        if (obj is MasterDimension)
            return Name.CompareTo(((MasterDimension)obj).Name);

        throw new Exception("The method or operation is not implemented.");
    }

    #endregion
}

public class MasterFactTable
{
    public int FactTableId = 0;
    public string FactTableName = "";
    public string FactTableDesc = "";
    public string StageTableYearName = "";
    public string StageTableMonthName = "";
    public string PreFactLoadProcedure = "";
    public string KeyComboTableName = "";
    public string FactTableWithValues = "";
    public bool IsLegacy = false;
    public bool AllowsAdjustments = false;

    public MasterFactTable()
    {
    }
}

public class HypAutosysInfo
{
    public string AutosysJobName = "";
    public string Description = "";
    public string ButtonText = "";
    public string AutosysEvent = "";
    public DateTime DateCreated = DateTime.MinValue;
    public DateTime DateModified = DateTime.MinValue;

    public HypAutosysInfo()
    {
    }
}