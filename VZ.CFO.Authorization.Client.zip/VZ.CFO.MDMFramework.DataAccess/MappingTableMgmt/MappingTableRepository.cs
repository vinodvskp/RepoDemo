﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.DataAccess.MappingTableMgmt
{
    public class MappingTableRepository : Providers.MappingTableDataProvider
    {
        public MappingTableRepository(string connectionString)
            : base(connectionString)
        { 
        }

        protected override Contracts.Data.MappingTableMgmt.MappingTable[] OnGetAllMappingTables(string userId)
        {
            Contracts.Data.MappingTableMgmt.MappingTable[] mappingTable = new Contracts.Data.MappingTableMgmt.MappingTable[] 
            {
                new Contracts.Data.MappingTableMgmt.MappingTable() { Id = 100, Name = "PMR Table"},
                new Contracts.Data.MappingTableMgmt.MappingTable() { Id = 200, Name = "Mapping Table 2"}
            };

            return mappingTable;
        }

        protected override Contracts.Data.MappingTableMgmt.MappingTableDataPage OnGetMappingTable(string userId, long mappingTableId, int pageNumber, int rowsPerPage, int totalRecords)
        {
            throw new NotImplementedException();
        }

        protected override Contracts.Data.MappingTableMgmt.MappingTable OnGetMappingTable(string userId, long id)
        {
            throw new NotImplementedException();
        }

        protected override bool OnSaveMappingTableData(string userId, Contracts.Data.MappingTableMgmt.MappingTable mappingTable, bool isForceSave)
        {
            throw new NotImplementedException();
        }

        protected override Contracts.Data.MappingTableMgmt.MappingTable OnValidationMappingTableData(string userId, Contracts.Data.MappingTableMgmt.MappingTable mappingTable)
        {
            throw new NotImplementedException();
        }

        protected override Contracts.Data.MappingTableMgmt.AuditLogPage OnGetAuditDataPage(string userId, long mappingTableId, int pageNumber, int rowsPerPage, int totalRecords)
        {
            throw new NotImplementedException();
        }

        protected override Contracts.Data.MappingTableMgmt.AuditLogPage OnGetAuditData(string userId, long mappingTableId)
        {
            throw new NotImplementedException();
        }

        protected override bool OnMigrateMappingValues(string userId, long mappingTableId)
        {
            throw new NotImplementedException();
        }
    }
}
