﻿using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.BL.MappingTableMgmt
{
    public class MappingTableManager : ManagerBase, Contracts.Service.MappingTableMgmt.IMappingTableManager
    {
                /// <summary>
        /// Default Constructor
        /// </summary>
        [InjectionConstructor]
        public MappingTableManager() : base() { }

        /// <summary>
        /// Parameterzied Constructor
        /// </summary>
        /// <param name="configurationManager"></param>
        public MappingTableManager(Configuration.IConfigurationManager configurationManager) : base(configurationManager) { }


        public Contracts.Data.MappingTableMgmt.MappingTable[] GetAllMappingTables(string userId)
        {
            Contracts.Providers.IMappingTableDataProvider mappingTableDataProvider = GetConfiguration().CreateMappingTableDataProvider("");
            return mappingTableDataProvider.GetAllMappingTables(userId);
        }

        public Contracts.Data.MappingTableMgmt.MappingTableDataPage GetMappingTable(string userId, long mappingTableId, int pageNumber, int rowsPerPage, int totalRecords)
        {
            throw new NotImplementedException();
        }

        public Contracts.Data.MappingTableMgmt.MappingTable GetMappingTable(string userId, long id)
        {
            throw new NotImplementedException();
        }

        public bool SaveMappingTableData(string userId, Contracts.Data.MappingTableMgmt.MappingTable mappingTable, bool isForceSave)
        {
            throw new NotImplementedException();
        }

        public Contracts.Data.MappingTableMgmt.MappingTable ValidationMappingTableData(string userId, Contracts.Data.MappingTableMgmt.MappingTable mappingTable)
        {
            throw new NotImplementedException();
        }

        public Contracts.Data.MappingTableMgmt.AuditLogPage GetAuditDataPage(string userId, long mappingTableId, int pageNumber, int rowsPerPage, int totalRecords)
        {
            throw new NotImplementedException();
        }

        public Contracts.Data.MappingTableMgmt.AuditLogPage GetAuditData(string userId, long mappingTableId)
        {
            throw new NotImplementedException();
        }

        public bool MigrateMappingValues(string userId, long mappingTableId)
        {
            throw new NotImplementedException();
        }
    }
}
