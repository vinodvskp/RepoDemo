﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.MDMFramework.BL
{
    public class ManagerBase
    {
        /// <summary>
        /// IConfigurationManager instance which is used to return objects from DataProviderFactory including DataProviders, Repositories, etc.
        /// </summary>
        private Configuration.IConfigurationManager configurationManager;
        /// <summary>
        /// Default constructor
        /// </summary>
        protected ManagerBase()
        {
            configurationManager = DataProviderFactory.GetProvider<Configuration.IConfigurationManager>();
        }
        protected ManagerBase(VZ.CFO.MDMFramework.Configuration.IConfigurationManager configurationManager)
        {
            this.configurationManager = configurationManager;
        }

        protected Configuration.IConfigurationManager GetConfiguration()
        {
            return configurationManager;
        }

        /// <summary>
        /// Flag to hold the detail about the disposed status
        /// </summary>
        private bool disposed;

        /// <summary>
        /// Id to hold the data provider factory
        /// </summary>
        protected static Providers.DataProviderFactory DataProviderFactory
        {
            get
            {
                if (null == Providers.DataProviderFactory.Current)
                {
                    throw new InvalidOperationException("DataProviderFactory has not been properly initialized");
                }
                return Providers.DataProviderFactory.Current;
            }
        }

        /// <summary>
        /// Checks if this Service instance has already been disposed.
        /// Throws an ObjectDisposedException if this controller is already disposed.
        /// </summary>
        protected void CheckIfServiceIsDisposed()
        {
            // Check if this controller instance is already disposed.
            if (disposed)
            {
                throw new ObjectDisposedException(GetType().Name);
            }
        }
    }
}
