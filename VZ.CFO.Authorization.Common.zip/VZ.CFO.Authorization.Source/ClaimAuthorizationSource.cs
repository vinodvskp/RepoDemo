﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.Authorization.Providers.Authorization
{
    public abstract class ClaimAuthorizationSource : DataProvider, Contracts.Service.IAuthorizationSource
    {
        protected ClaimAuthorizationSource(ProviderConfiguration config)
            : base(null)
        {
            if (config == null)
            {
                throw new ArgumentNullException("config");
            }

            this.Configuration = config;
        }

        /// <summary>
        /// Gets or sets the provider configuration.
        /// </summary>
        protected ProviderConfiguration Configuration { get; set; }

        /// <summary>
        /// Gets or sets the connection string for the authorization source.
        /// </summary>
        protected new string ConnectionString
        {
            get
            {
                return this.Configuration.ConnectionString;
            }
        }

        /// <summary>
        /// Indicates the Authrorization Source's supported authentication mechanism
        /// </summary>
        public abstract Contracts.Data.AuthenticationSource SupportedAuthenticationMechanism
        {
            get;
        }

        public Claim[] GetUserClaims(string userId, Contracts.Data.AuthenticationSource userIdType)
        {
            if (string.IsNullOrWhiteSpace(userId))
            {
                throw new ArgumentException("userId cannot be null or whitespace.", "userId");
            }
            if (SupportedAuthenticationMechanism != Contracts.Data.AuthenticationSource.Any && userIdType != SupportedAuthenticationMechanism)
            {
                throw new InvalidOperationException("userIdType does not match source supported authentication mechanism");
            }
            return OnGetUserClaims(userId, userIdType);
        }

        protected abstract Claim[] OnGetUserClaims(string userId, Contracts.Data.AuthenticationSource userIdType);
    }
}
