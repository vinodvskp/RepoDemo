﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.Authorization.Source
{
    public class GenericRestfulSource : ClaimAuthorizationSource
    {

        private const int DefaultHttpRequestTimeOutSec = 30;

        public GenericRestfulSource(ProviderConfiguration config)
            : base(config)
        {

        }


        public override Contracts.Data.AuthenticationSource SupportedAuthenticationMechanism
        {
            get
            {
                return Contracts.Data.AuthenticationSource.Any;
            }
        }


        protected override System.Security.Claims.Claim[] OnGetUserClaims(string userId, Contracts.Data.AuthenticationSource userIdType)
        {
            using (Task<System.Security.Claims.Claim[]> task = GetUserClaimsFromService(userId, userIdType))
            {
                task.Wait(DefaultHttpRequestTimeOutSec * 1000);
                //task.Wait();
                if (task.IsCompleted)
                {
                    return task.Result;
                }
                else
                {
                    throw new TimeoutException();
                }
            }
        }

        private async Task<System.Security.Claims.Claim[]> GetUserClaimsFromService(string userId, Contracts.Data.AuthenticationSource userIdType)
        {
            //VZ.CFO.Authorization.Server.AuthorizationSources.RESTFullAuthorizationSource, VZ.CFO.Authorization.Server, Version=1.0.0.0, Culture=neutral
            //VZ.CFO.Authorization.Source.GenericRestfulSource, VZ.CFO.Authorization.Source, Version=1.0.0.0, Culture=neutral

            //call Restful Implementation of IAuthorizationSource
            List<System.Security.Claims.Claim> result = new List<System.Security.Claims.Claim>();

            string url = string.Format("{0}/{1}/{2}", base.ConnectionString, userId, userIdType);

            System.Net.HttpWebRequest client = System.Net.WebRequest.Create(url) as System.Net.HttpWebRequest;
            client.Method = "GET";
            client.Accept = "application/json";

            try
            {
                using (System.Net.WebResponse response = await client.GetResponseAsync())
                {
                    using (System.IO.MemoryStream data = new System.IO.MemoryStream())
                    {
                        using (System.IO.Stream responseStream = response.GetResponseStream())
                        {
                            await responseStream.CopyToAsync(data);
                        }

                        string json = System.Text.Encoding.UTF8.GetString(data.GetBuffer());

                        //we expect the RESTFul source to implement IAuthorizationSource, which requires return of Claim[] not AuthToken
                        Contracts.Data.CustomClaim[] claims = Newtonsoft.Json.JsonConvert.DeserializeObject<Contracts.Data.CustomClaim[]>(json);
                        foreach (var c in claims)
                        {
                            result.Add(new Claim(c.Type, c.Value));
                        }
                    }
                }
            }
            catch (Exception)
            {
                // result = default(T);
            }

            return result.ToArray();
        }
    }
}
