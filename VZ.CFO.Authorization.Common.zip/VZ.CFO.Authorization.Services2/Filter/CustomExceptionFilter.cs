﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http.Filters;
using VZ.CFO.Authorization.Configuration;
using VZ.CFO.Authorization.Contracts.Service;
using VZ.CFO.Authorization.Providers;

namespace VZ.CFO.Authorization.Services2.Filter
{
    public class CustomExceptionFilter : ExceptionFilterAttribute
    {
        private ILogManager logManager;

        public CustomExceptionFilter()
        {
            logManager = GetLogManager();
        }

        public override void OnException(HttpActionExecutedContext actionExecutedContext)
        {
            string exceptionMessage = string.Empty;

            if (actionExecutedContext.Exception.InnerException == null)
            {
                exceptionMessage = actionExecutedContext.Exception.Message;
            }
            else
            {
                exceptionMessage = actionExecutedContext.Exception.InnerException.Message;
            }

            logManager.LogException("Controller", actionExecutedContext.Exception);

            var response = new HttpResponseMessage(HttpStatusCode.InternalServerError)
            {
                Content = new StringContent("An unhandled exception was thrown by service."),
                ReasonPhrase = "Internal Server Error. Please Contact your Administrator."
            };
            actionExecutedContext.Response = response;
        }

        protected DataProviderFactory DataProviderFactory
        {
            get
            {
                if (null == DataProviderFactory.Current)
                {
                    throw new InvalidOperationException("DataProviderFactory has not been properly initialized");
                }

                return DataProviderFactory.Current;
            }
        }

        private ILogManager GetLogManager()
        {
            ConfigurationManager config = DataProviderFactory.GetProvider<ConfigurationManager>();
            return config.GetLogProvider() as ILogManager;
        }
    }
}