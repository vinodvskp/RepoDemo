﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using VZ.CFO.Authorization.Services2.Filter;
namespace VZ.CFO.Authorization.Services2
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            //Enable CORS
            config.EnableCors();

            // Web API configuration and services
            RegisterDataProviders(new Configuration.ServerConfigurationManager(
                    new Configuration.FileBasedConfigurationDataProvider()));

            //Add Custom Filter
            config.Filters.Add(new CustomExceptionFilter());

            // Web API routes
            config.MapHttpAttributeRoutes();

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );
        }

        private static void RegisterDataProviders(Configuration.ConfigurationManager config)
        {
            if (config == null)
            {
                throw new ArgumentNullException("config");
            }

            Microsoft.Practices.Unity.UnityContainer container = new Microsoft.Practices.Unity.UnityContainer();
            //register configuration provider, in case its needed elsewhere
            container.RegisterInstance(typeof(Configuration.ConfigurationManager),
                typeof(Configuration.ConfigurationManager).Name, config,
                new Microsoft.Practices.Unity.ContainerControlledLifetimeManager());

            container.RegisterInstance(typeof(Providers.Data.ApplicationDataProvider),
                typeof(Providers.Data.ApplicationDataProvider).Name,
                config.GetApplicationDataProvider(), new Microsoft.Practices.Unity.ContainerControlledLifetimeManager());

            container.RegisterInstance(typeof(Providers.Data.AuthorizationProviderDataProvider),
                typeof(Providers.Data.AuthorizationProviderDataProvider).Name,
                config.GetAuthorizationProviderDataProvider(), new Microsoft.Practices.Unity.ContainerControlledLifetimeManager());

            container.RegisterInstance(typeof(Providers.Data.LdapDataProvider),
                typeof(Providers.Data.LdapDataProvider).Name,
                config.GetLdapDataProvider(), new Microsoft.Practices.Unity.ContainerControlledLifetimeManager());

            container.RegisterInstance(typeof(Providers.Data.LogProvider),
                typeof(Providers.Data.LogProvider).Name,
                config.GetLogProvider(), new Microsoft.Practices.Unity.ContainerControlledLifetimeManager());

            VZ.CFO.Authorization.Providers.DataProviderFactory.ActivateFactoryInstace(container);
        }
    }
}
