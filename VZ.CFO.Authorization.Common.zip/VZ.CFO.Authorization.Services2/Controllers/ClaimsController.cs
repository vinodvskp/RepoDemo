﻿using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Claims;
using System.Web;
using System.Web.Http;
using VZ.CFO.Authorization.Configuration;
using VZ.CFO.Authorization.Contracts.Data;
using VZ.CFO.Authorization.Contracts.Data.Authorization;
using VZ.CFO.Authorization.Contracts.Service;
using VZ.CFO.Authorization.Providers.Authorization;

namespace VZ.CFO.Authorization.Services2.Controllers
{
    //[RoutePrefix("api/claims")]
    [RoutePrefix(Routes.Token.Root)]
    public class ClaimsController : AuthorizationServiceBaseController, IClaim
    {
        private IAuthorizationManager authorizationManager;
        private ILdapManager ldapManager;
        private ILogManager logManager;

        private string ssoUserIdHeaderName;

        [InjectionConstructor]
        public ClaimsController()
        {
            this.authorizationManager = base.GetAuthManager();
            this.ldapManager = base.GetLdapManager();
            this.logManager = base.GetLogManager();
            this.ssoUserIdHeaderName = base.GetSsoUserIdHeaderName();
        }

        public ClaimsController(IAuthorizationManager authorizationManager, ILdapManager ldapManager)
        {
            this.authorizationManager = authorizationManager;
            this.ldapManager = ldapManager;
            this.logManager = base.GetLogManager();
            this.ssoUserIdHeaderName = base.GetSsoUserIdHeaderName();
        }


        private AuthenticationSource GetConfiguredAuthenticationMechanism()
        {
            ConfigurationManager config = base.DataProviderFactory.GetProvider<ConfigurationManager>();
            return config.GetAuthenticationMechanism();
        }

        private static UserWrapper GetUserWrapperForSso(string userId)
        {
            return new UserWrapper()
            {
                UserName = userId,
                Mechanism = AuthenticationSource.Sso
            };
        }

        private static UserWrapper GetUserWrapperForLdap(string userId)
        {
            return new UserWrapper()
            {
                UserName = userId,
                Mechanism = AuthenticationSource.LDAP
            };
        }

        //[Route("token/{applicationId}/{issueAsCode:bool}")]
        [Route(Routes.Token.WebToken)]
        [HttpGet]
        public string IssueToken(long applicationId, bool issueAsCode)
        {
            if (this.IsDisposed)
            {
                throw new ObjectDisposedException("ClaimsController");
            }
            var app = authorizationManager.GetRegisteredApplicationById(applicationId);
            if (app == null)
            {
                throw new NullReferenceException("No application registered with the given applicationId");
            }

            List<UserWrapper> userDetails = new List<UserWrapper>();

            switch (GetConfiguredAuthenticationMechanism())
            {
                case AuthenticationSource.Sso:
                    IEnumerable<string> userIdHeaderValues = Request.Headers.Contains(ssoUserIdHeaderName)
                                                            ? Request.Headers.GetValues(ssoUserIdHeaderName)
                                                            : null;
                    // Header contains an authenticated BEMS Id from WSSO.
                    if (null != userIdHeaderValues && !string.IsNullOrWhiteSpace(userIdHeaderValues.FirstOrDefault()))
                    {
                        userDetails.Add(GetUserWrapperForSso(userIdHeaderValues.First()));
                    }
                    break;
                default:
                    throw new InvalidOperationException("Invalid authentication mechanism configured.");
            }

            if (0 == userDetails.Count)
            {
                throw new UnauthorizedAccessException("Not authenticated.");
            }
            AuthToken token = authorizationManager.Authorize(applicationId, userDetails.ToArray(), GetSSOCookies());
            if (null == token)
            {
                throw new NullReferenceException("No token created.");
            }

            AuthToken result = null;
            if (issueAsCode)
            {
                //result = authorizationManager.CreateCodeToken(token);
                //make sure that the token now has the Code claim from result
                //token.CopyClaimValue(VZ.CFO.AuthorizationServer.Common.Security.Claims.AuthorizationCode.ClaimName, result, true);
            }
            else
            {
                result = token;
            }
            //authorizationManager.SaveToken(token);
            return authorizationManager.ToJWT(result, app);

        }

        //[EnableCors(origins: "*", headers: "*", methods: "*", SupportsCredentials = true)]
        //[Route("tokenpost/{applicationId}/{issueAsCode:bool}")]
        [Route(Routes.Token.LdapWebToken)]
        [HttpPost]
        public string IssueToken(long applicationId, bool issueAsCode, LdapAuthRequest ldapRequest)
        {
            if (this.IsDisposed)
            {
                throw new ObjectDisposedException("ClaimsController");
            }

            logManager.LogMessage("ClaimsController", string.Format("Application Id: {0}, IssueRequest: {1}", applicationId, issueAsCode));

            var app = authorizationManager.GetRegisteredApplicationById(applicationId);
            if (app == null)
            {
                throw new NullReferenceException("No application registered with the given applicationId");
            }

            List<UserWrapper> userDetails = new List<UserWrapper>();

            if (ldapRequest == null)
            {
                logManager.LogMessage("ClaimsController", "Ldap Request is null");
                if (GetConfiguredAuthenticationMechanism() == AuthenticationSource.Sso)
                {
                    IEnumerable<string> userIdHeaderValues = Request.Headers.Contains(ssoUserIdHeaderName)
                                                                               ? Request.Headers.GetValues(ssoUserIdHeaderName)
                                                                               : null;
                    // Header contains an authenticated BEMS Id from WSSO.
                    if (null != userIdHeaderValues && !string.IsNullOrWhiteSpace(userIdHeaderValues.FirstOrDefault()))
                    {
                        userDetails.Add(GetUserWrapperForSso(userIdHeaderValues.First()));
                    }
                }
                else
                {
                    throw new InvalidOperationException("Invalid authentication mechanism configured.");
                }
            }
            else
            {
                logManager.LogMessage("ClaimsController", string.Format("Ldap Request for {0}", ldapRequest.UserName));
                if (ldapManager.IsAuthenticated(ldapRequest.UserName, ldapRequest.EncryptedPassword))
                {
                    string[] splitDomain = ldapRequest.UserName.Split('\\');
                    string samAccountName = string.Empty;
                    if (splitDomain.Length == 2)
                    {
                        samAccountName = splitDomain[1];
                    }
                    else
                    {
                        samAccountName = ldapRequest.UserName;
                    }

                    var user = ldapManager.GetUser(samAccountName);

                    if (user != null)
                    {
                        logManager.LogMessage("ClaimsController", "Ldap user found.");
                        userDetails.Add(user);
                    }
                }
            }

            if (0 == userDetails.Count)
            {
                throw new UnauthorizedAccessException("Not authenticated.");
            }
            AuthToken token = authorizationManager.Authorize(applicationId, userDetails.ToArray(), GetSSOCookies());
            if (null == token)
            {
                throw new NullReferenceException("No token created.");
            }

            AuthToken result = null;
            if (issueAsCode)
            {
                throw new NotImplementedException();
            }
            else
            {
                logManager.LogMessage("ClaimsController", "Got Token");
                result = token;
            }
            return authorizationManager.ToJWT(result, app);
        }

        public Contracts.Data.AuthToken Authorize(long applicationId, string userId, Contracts.Data.AuthenticationSource authenticationSourceType, System.Net.CookieContainer ssoCookieContainer)
        {
            if (this.IsDisposed)
            {
                throw new ObjectDisposedException("ClaimsController");
            }
            if (string.IsNullOrWhiteSpace(userId))
            {
                throw new ArgumentException("userId cannot be null or whitespace.", "userId");
            }

            return authorizationManager.Authorize(applicationId, userId, authenticationSourceType, ssoCookieContainer);
        }

        public Contracts.Data.AuthToken ResolveClaim(Guid authorizationCode)
        {
            throw new NotImplementedException();
        }

        public void RevokeClaim(Guid authorizationCode)
        {
            throw new NotImplementedException();
        }

        private System.Net.CookieContainer GetSSOCookies()
        {
            System.Net.CookieContainer ssoCookieContainer = new CookieContainer();

            if (HttpContext.Current == null)
            {
                throw new Exception("HttpContext.Current is null");
            }
            else if (HttpContext.Current.Request == null)
            {
                throw new Exception("HttpContext.Current.Request is null");
            }
            else if (HttpContext.Current.Request.Cookies == null)
            {
                throw new Exception("HttpContext.Current.Request.Cookies is null");
            }
            else
            {
                HttpCookieCollection oCookies = HttpContext.Current.Request.Cookies;
                for (int j = 0; j < oCookies.Count; j++)
                {
                    HttpCookie oCookie = oCookies.Get(j);
                    Cookie oC = new Cookie();

                    // Convert between the System.Net.Cookie to a System.Web.HttpCookie...
                    oC.Domain = HttpContext.Current.Request.Url.Host;  //myRequest.RequestUri.Host;
                    oC.Expires = oCookie.Expires;
                    oC.Name = oCookie.Name;
                    oC.Path = oCookie.Path;
                    oC.Secure = oCookie.Secure;
                    oC.Value = oCookie.Value;

                    ssoCookieContainer.Add(oC);
                }

            }

            return ssoCookieContainer;
        }

        [Route("GetCookies")]
        public string[] GetCookies()
        {
            List<string> cl = new List<string>();

            return cl.ToArray();
            
        }

        [Route("GetUserClaimsFromService/{userId}")]
        public string[] GetUserClaimsFromService(string userId)
        {
            //call Restful Implementation of IAuthorizationSource
            List<string> rs = new List<string>();
            List<System.Security.Claims.Claim> result = new List<System.Security.Claims.Claim>();

            string url = string.Format("{0}/{1}/{2}", "http://eu9sc1wna002.itcent.ebiz.verizon.com/FDMService/api/mdua/useraccess/GetUserAccess", userId, "Sso");
            //string url = string.Format("{0}/{1}/{2}", @"http://localhost:54486/MDMFramewoapi/mdua/useraccess/GetUserAccess", userId, userIdType);



            CookieContainer emersoncookie = new CookieContainer();


            System.Net.HttpWebRequest client = System.Net.WebRequest.Create(url) as System.Net.HttpWebRequest;
            client.Method = "GET";
            client.Accept = "application/json";

            if (HttpContext.Current == null)
            {
                rs.Add("current is null");
            }
            else if (HttpContext.Current.Request == null)
            {
                rs.Add("request is null");
            }
            else if (HttpContext.Current.Request.Cookies == null)
            {
                rs.Add("request.cookies is null");
            }
            else
            {
                HttpCookieCollection oCookies = HttpContext.Current.Request.Cookies;
                for (int j = 0; j < oCookies.Count; j++)
                {
                    HttpCookie oCookie = oCookies.Get(j);
                    Cookie oC = new Cookie();

                    // Convert between the System.Net.Cookie to a System.Web.HttpCookie...
                    oC.Domain = client.RequestUri.Host;  //myRequest.RequestUri.Host;
                    oC.Expires = oCookie.Expires;
                    oC.Name = oCookie.Name;
                    oC.Path = oCookie.Path;
                    oC.Secure = oCookie.Secure;
                    oC.Value = oCookie.Value;

                    emersoncookie.Add(oC);
                }

                client.CookieContainer = emersoncookie;

                try
                {
                    //using (System.Net.WebResponse response = await client.GetResponseAsync())
                    using (System.Net.WebResponse response = client.GetResponse())
                    {
                        using (System.IO.MemoryStream data = new System.IO.MemoryStream())
                        {
                            using (System.IO.Stream responseStream = response.GetResponseStream())
                            {
                                //await responseStream.CopyToAsync(data);
                                responseStream.CopyTo(data);
                            }

                            string json = System.Text.Encoding.UTF8.GetString(data.GetBuffer());

                            //we expect the RESTFul source to implement IAuthorizationSource, which requires return of Claim[] not AuthToken
                            CustomClaim[] claims = Newtonsoft.Json.JsonConvert.DeserializeObject<VZ.CFO.Authorization.Contracts.Data.CustomClaim[]>(json);
                            foreach (var c in claims)
                            {
                                result.Add(new Claim(c.Type, c.Value));
                                rs.Add(c.Type + "-" + c.Value);
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                    rs.Add(e.Message);
                }
            }
            rs.Add("from BL");
            //return string.Join(", ", rs);
            return rs.ToArray();
        }
    }
}
