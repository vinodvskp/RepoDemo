﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.Authorization.Contracts.Service;
using VZ.CFO.Authorization.Providers.Authorization;
using VZ.CFO.Authorization.Providers.Data;
using VZ.CFO.Authorization.Server.Providers;

namespace VZ.CFO.Authorization.Configuration
{
    public class ServerConfigurationManager : ConfigurationManager
    {
        /// <summary>
        /// Creates a new instance of ServerConfigurationManager
        /// </summary>
        /// <param name="config">The configuration data source.</param>
        public ServerConfigurationManager(ConfigurationDataProvider config)
            : base(config)
        {
        }

        /// <summary>
        /// Gets the application data provider instance.
        /// </summary>
        /// <returns>The application data provider instance.</returns>
        protected override ApplicationDataProvider OnGetApplicationDataProvider()
        {
            return new DbApplicationDataProvider(this.AuthorizationConnectionString, this.EncryptionSaltConfig);
        }

        /// <summary>
        /// Gets the authorization data provider instance.
        /// </summary>
        /// <returns>The authorization data provider instance.</returns>
        protected override AuthorizationProviderDataProvider OnGetAuthorizationProviderDataProvider()
        {
            return new DbAuthorizationProviderDataProvider(this.AuthorizationConnectionString, this.EncryptionSaltConfig);
        }

        /// <summary>
        /// Gets the authorization manager instance.
        /// </summary>
        /// <returns>The authorization manager instance.</returns>
        protected override IClaim OnGetAuthorizationManager()
        {
            return new AuthorizationManager(GetAuthorizationProviderDataProvider(), GetApplicationDataProvider(), this.TokenExpirationHours, this.AuthorizationConnectionString, this.EncryptionSaltConfig);
        }

        protected override LdapDataProvider OnGetLdapDataProvider()
        {
            return new DbLdapDataProvider(this.LdapConnection, this.LdapUserNameConfig, this.LdapEncryptedPasswordConfig, this.EncryptionSaltConfig);
        }

        protected override LogProvider OnGetLogProvider()
        {
            if (this.LogType == "text")
            {
                return new TextFileLogProvider(this.LogPath);
            }
            else
            {
                throw new NotImplementedException();
            }
        }
    }
}
