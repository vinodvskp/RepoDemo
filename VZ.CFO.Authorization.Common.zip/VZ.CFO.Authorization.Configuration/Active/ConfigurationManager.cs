﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.Authorization.Contracts.Data;

namespace VZ.CFO.Authorization.Configuration
{
    /// <summary>
    /// Manages application configurations.
    /// </summary>
    public abstract class ConfigurationManager : ConfigurationDataProvider
    {
        /// <summary>
        /// Creates a new instance of ConfigurationManager.
        /// </summary>
        /// <param name="config">ConfigurationDataProvider instance.</param>
        protected ConfigurationManager(ConfigurationDataProvider config)
        {
            if (config == null)
            {
                throw new ArgumentNullException("config");
            }
            this.Config = config;
        }

        private ConfigurationDataProvider Config { get; set; }

        /// <summary>
        /// Gets the connection string authorization server database.
        /// </summary>
        /// <returns>The connection string authorization server database.</returns>
        protected override string OnGetAuthorizationConnectionString()
        {
            return this.Config.AuthorizationConnectionString;
        }

        /// <summary>
        /// Gets the token expiration time duration (in hours).
        /// </summary>
        /// <returns>The token expiration time duration.</returns>
        protected override double OnGetTokenExpirationHours()
        {
            return this.Config.TokenExpirationHours;
        }

        /// <summary>
        /// Get the configured authentication mechanism
        /// </summary>
        /// <returns></returns>
        protected override AuthenticationSource OnGetAuthenticationMechanism()
        {
            return this.Config.GetAuthenticationMechanism();
        }

        protected override string OnGetEncryptionSalt()
        {
            return this.Config.EncryptionSaltConfig;
        }
        protected override string OnGetLdapConnection()
        {
            return this.Config.LdapConnection;
        }

        protected override string OnGetLdapUserName()
        {
            return this.Config.LdapUserNameConfig;
        }

        protected override string OnGetLdapEncryptedPassword()
        {
            return this.Config.LdapEncryptedPasswordConfig;
        }

        protected override string OnGetLogPath()
        {
            return this.Config.LogPath;
        }

        protected override string OnGetLogType()
        {
            return this.Config.LogType;
        }

        protected override string OnSsoUserIdHeaderName()
        {
            return this.Config.SsoUserIdHeaderName;
        }
    }
}
