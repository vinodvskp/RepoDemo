﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.Authorization.Providers.Authorization;
using VZ.CFO.Authorization.Providers.Data;
using VZ.CFO.Authorization.Server.Providers;

namespace VZ.CFO.Authorization.Configuration
{
    /// <summary>
    /// Manages data provider instances.
    /// </summary>
    public class FileBasedConfigurationDataProvider : ConfigurationDataProvider
    {
        private const string AuthroizationRepositoryConfigKey = "VZ.Authorization.Repository.ConnectionString.Name";
        private const string TokenExpirationHoursConfigKey = "VZ.Authorization.Security.TokenExpirationHours";
        private const string AuthenticationMechanismConfigKey = "VZ.Authorization.Authentication.Mechanism";
        private const string LdapConnectionConfigKey = "VZ.Authorization.LDAP.Connection";
        private const string EncryptionSaltConfigKey = "VZ.Authorization.EncryptionSalt";
        private const string LdapUserNameConfigKey = "VZ.Authorization.LDAP.UserName";
        private const string LdapEncryptedPasswordConfigKey = "VZ.Authorization.LDAP.EncryptedPassword";
        private const string LogTypeConfigKey = "VZ.Authorization.Log.Type";
        private const string LogPathConfigKey = "VZ.Authorization.Log.Path";
        private const string SsoUserIdHeaderNameConfigKey = "VZ.Authorization.Authentication.Sso.UserIdHeaderName";

        /// <summary>
        /// Gets the authorization database connection string.
        /// </summary>
        /// <returns>The authorization database connection string.</returns>
        protected override string OnGetAuthorizationConnectionString()
        {
            return GetConnectionString(GetAppSettingValue(AuthroizationRepositoryConfigKey));
        }

        /// <summary>
        /// Gets the token expiration time (in hours) from the configuration file.
        /// </summary>
        /// <returns>The token expiration time (in hours) from the configuration file.</returns>
        protected override double OnGetTokenExpirationHours()
        {
            return Convert.ToDouble(GetAppSettingValue(TokenExpirationHoursConfigKey));
        }

        protected override string OnGetEncryptionSalt()
        {
            return GetAppSettingValue(EncryptionSaltConfigKey);
        }

        protected override string OnGetLdapConnection()
        {
            return GetAppSettingValue(LdapConnectionConfigKey);
        }

        protected override string OnGetLdapUserName()
        {
            return GetAppSettingValue(LdapUserNameConfigKey);
        }

        protected override string OnGetLdapEncryptedPassword()
        {
            return GetAppSettingValue(LdapEncryptedPasswordConfigKey);
        }

        protected override string OnGetLogType()
        {
            return GetAppSettingValue(LogTypeConfigKey);
        }

        protected override string OnGetLogPath()
        {
            return GetAppSettingValue(LogPathConfigKey);
        }

        protected override string OnSsoUserIdHeaderName()
        {
            return GetAppSettingValue(SsoUserIdHeaderNameConfigKey);
        }

        protected override LogProvider OnGetLogProvider()
        {
            if (OnGetLogType() == "text") {
                return new TextFileLogProvider(OnGetLogPath());
            }
            else
            {
                throw new NotImplementedException();
            }
        }

        /// <summary>
        /// Gets the ApplicationDataProvider instance.
        /// </summary>
        /// <returns>The ApplicationDataProvider instance.</returns>
        protected override ApplicationDataProvider OnGetApplicationDataProvider()
        {
            return new DbApplicationDataProvider(GetConnectionString(AuthroizationRepositoryConfigKey), OnGetEncryptionSalt());
        }

        /// <summary>
        /// Gets the AuthorizationProviderDataProvider instance.
        /// </summary>
        /// <returns>The AuthorizationProviderDataProvider instance.</returns>
        protected override AuthorizationProviderDataProvider OnGetAuthorizationProviderDataProvider()
        {
            return new DbAuthorizationProviderDataProvider(GetConnectionString(AuthroizationRepositoryConfigKey), OnGetEncryptionSalt());
        }

        /// <summary>
        /// Gets the AuthorizationManager instance.
        /// </summary>
        /// <returns>The AuthorizationManager instance.</returns>
        protected override Contracts.Service.IClaim OnGetAuthorizationManager()
        {
            return new AuthorizationManager(GetAuthorizationProviderDataProvider(), GetApplicationDataProvider(), OnGetTokenExpirationHours(), GetConnectionString(AuthroizationRepositoryConfigKey), OnGetEncryptionSalt());
        }

        protected override LdapDataProvider OnGetLdapDataProvider()
        {
            return new DbLdapDataProvider(OnGetLdapConnection(), OnGetLdapUserName(), OnGetLdapEncryptedPassword(), OnGetEncryptionSalt());
        }
        /// <summary>
        /// Gets the ClaimsManagerProvider instance.
        /// </summary>
        /// <returns>The ClaimsManagerProvider instance.</returns>
        //protected override ClaimsManagerProvider OnGetClaimsManagerDataProvider()
        //{
        //    return new DbClaimsDataProvider(GetConnectionString(AuthroizationRepositoryConfigKey));
        //}

        protected override Contracts.Data.AuthenticationSource OnGetAuthenticationMechanism()
        {
            string mechanism = GetAppSettingValue(AuthenticationMechanismConfigKey);
            Contracts.Data.AuthenticationSource uis = Contracts.Data.AuthenticationSource.Sso;
            if (false == Enum.TryParse<Contracts.Data.AuthenticationSource>(mechanism, out uis))
                uis = Contracts.Data.AuthenticationSource.Sso;
            return uis;
        }

        /// <summary>
        /// Gets the appsettings value for the provided key.
        /// </summary>
        /// <param name="name">The key of the setting.</param>
        /// <returns>The appsettings value for the provided key.</returns>
        protected virtual string GetAppSettingValue(string key)
        {
            if (string.IsNullOrWhiteSpace(key))
            {
                throw new ArgumentException("key cannot be null or whitespace.", "key");
            }

            return System.Configuration.ConfigurationManager.AppSettings[key];
        }

        /// <summary>
        /// Reads the configuration file and gets the connection string for the given name.
        /// </summary>
        /// <param name="name">The name of the connection string.</param>
        /// <returns>The connection string for the given name.</returns>
        protected virtual string GetConnectionString(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                throw new ArgumentException("name cannot be null or whitespace.", "name");
            }
            System.Configuration.ConnectionStringSettings css = System.Configuration.ConfigurationManager.ConnectionStrings[name];

            return null == css ? null : css.ConnectionString;
        }

        
    }
}
