﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.Authorization.Contracts.Service;
using VZ.CFO.Authorization.Providers;
using VZ.CFO.Authorization.Providers.Data;

namespace VZ.CFO.Authorization.Configuration
{
    /// <summary>
    /// Manages data provider instances.
    /// </summary>
    public abstract class ConfigurationDataProvider : DataProvider
    {
        /// <summary>
        /// Creates a new instance of ConfigurationDataProvider.
        /// </summary>
        protected ConfigurationDataProvider()
            : base(null, null)
        {
        }

        /// <summary>
        /// Gets the connection string for authorization server database.
        /// </summary>
        public string AuthorizationConnectionString { get { return OnGetAuthorizationConnectionString(); } }

        /// <summary>
        /// Gets the token expiration time duration (in hours).
        /// </summary>
        public double TokenExpirationHours { get { return OnGetTokenExpirationHours(); } }

        public string EncryptionSaltConfig { get { return OnGetEncryptionSalt(); } }

        public string LdapConnection { get { return OnGetLdapConnection(); } }

        public string LdapUserNameConfig { get { return OnGetLdapUserName(); } }

        public string LdapEncryptedPasswordConfig { get { return OnGetLdapEncryptedPassword(); } }

        public string LogType { get { return OnGetLogType(); } }

        public string LogPath { get { return OnGetLogPath(); } }

        public string SsoUserIdHeaderName { get { return OnSsoUserIdHeaderName(); } }

        /// <summary>
        /// Gets the AuthorizationManager instance.
        /// </summary>
        /// <returns>The AuthorizationManager instance.</returns>
        public IClaim GetAuthorizationManager()
        {
            return OnGetAuthorizationManager();
        }

        /// <summary>
        /// Gets the ApplicationDataProvider instance.
        /// </summary>
        /// <returns>The ApplicationDataProvider instance.</returns>
        public ApplicationDataProvider GetApplicationDataProvider()
        {
            return OnGetApplicationDataProvider();
        }

        //<summary>
        //Gets the AuthorizationProviderDataProvider instance.
        //</summary>
        //<returns>The AuthorizationProviderDataProvider instance</returns>
        public AuthorizationProviderDataProvider GetAuthorizationProviderDataProvider()
        {
            return OnGetAuthorizationProviderDataProvider();
        }

        public Contracts.Data.AuthenticationSource GetAuthenticationMechanism()
        {
            return OnGetAuthenticationMechanism();
        }

        public LdapDataProvider GetLdapDataProvider()
        {
            return OnGetLdapDataProvider();
        }

        public LogProvider GetLogProvider()
        {
            return OnGetLogProvider();
        }

        protected abstract LogProvider OnGetLogProvider();

        protected abstract string OnSsoUserIdHeaderName();
        
        protected abstract string OnGetLogType();

        protected abstract string OnGetLogPath();

        protected abstract string OnGetEncryptionSalt();

        protected abstract string OnGetLdapConnection();

        protected abstract string OnGetLdapUserName();

        protected abstract string OnGetLdapEncryptedPassword();

        protected abstract string OnGetAuthorizationConnectionString();

        protected abstract double OnGetTokenExpirationHours();

        protected abstract IClaim OnGetAuthorizationManager();

        protected abstract ApplicationDataProvider OnGetApplicationDataProvider();

        protected abstract AuthorizationProviderDataProvider OnGetAuthorizationProviderDataProvider();

        protected abstract Contracts.Data.AuthenticationSource OnGetAuthenticationMechanism();

        protected abstract LdapDataProvider OnGetLdapDataProvider();
    }
}
