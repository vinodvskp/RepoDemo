﻿using System;
using System.Threading.Tasks;
using Microsoft.Owin;
using Owin;
using System.Web.Http;

[assembly: OwinStartup(typeof(VZ.CFO.Authorization.Services.Startup.Startup))]

namespace VZ.CFO.Authorization.Services.Startup
{
    public class Startup
    {

        /// <summary>
        /// Method implements the unity pattern to achieve a decoupled or very loosely coupled design
        /// </summary>
        /// <param name="config">The configuration manager.</param>
        public static void RegisterDataProviders(Configuration.ConfigurationManager config)
        {
             if (config == null)
            {
                throw new ArgumentNullException("config");
            }

            Microsoft.Practices.Unity.UnityContainer container = new Microsoft.Practices.Unity.UnityContainer();
            //register configuration provider, in case its needed elsewhere
            container.RegisterInstance(typeof(Configuration.ConfigurationManager),
                typeof(Configuration.ConfigurationManager).Name, config,
                new Microsoft.Practices.Unity.ContainerControlledLifetimeManager());

            container.RegisterInstance(typeof(Providers.Data.ApplicationDataProvider),
                typeof(Providers.Data.ApplicationDataProvider).Name,
                config.GetApplicationDataProvider(), new Microsoft.Practices.Unity.ContainerControlledLifetimeManager());
            
            container.RegisterInstance(typeof(Providers.Data.AuthorizationProviderDataProvider),
                typeof(Providers.Data.AuthorizationProviderDataProvider).Name,
                config.GetAuthorizationProviderDataProvider(), new Microsoft.Practices.Unity.ContainerControlledLifetimeManager());

            container.RegisterInstance(typeof(Providers.Data.LdapDataProvider),
                typeof(Providers.Data.LdapDataProvider).Name,
                config.GetLdapDataProvider(), new Microsoft.Practices.Unity.ContainerControlledLifetimeManager());

            container.RegisterInstance(typeof(Providers.Data.LogProvider),
                typeof(Providers.Data.LogProvider).Name,
                config.GetLogProvider(), new Microsoft.Practices.Unity.ContainerControlledLifetimeManager());

            VZ.CFO.Authorization.Providers.DataProviderFactory.ActivateFactoryInstace(container);
        }

        public void Configuration(IAppBuilder app)
        {
            // For more information on how to configure your application, visit http://go.microsoft.com/fwlink/?LinkID=316888
            HttpConfiguration config = new HttpConfiguration();
            config.EnableCors();
            config.MapHttpAttributeRoutes();
            app.UseWebApi(config);
        }
    }
}
