﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Http.Cors;
using VZ.CFO.Authorization.Configuration;
using VZ.CFO.Authorization.Contracts.Service;
using VZ.CFO.Authorization.Providers;
using VZ.CFO.Authorization.Providers.Authorization;
using VZ.CFO.Authorization.Services.Filter;

namespace VZ.CFO.Authorization.Services
{
    /// <summary>
    /// Authorization base controller having the Provider factory to maintain the object instance inside the container.
    /// </summary>
    [CustomExceptionFilter]
    [EnableCors(origins: "*", headers: "*", methods: "*", SupportsCredentials = true)]
    public class AuthorizationServiceBaseController : ApiController
    {
        public AuthorizationServiceBaseController()
            : base()
        {
        }

        /// <summary>
        /// Gets the DataProviderFactory instance to all inheriting controllers.
        /// </summary>
        protected DataProviderFactory DataProviderFactory
        {
            get
            {
                if (null == DataProviderFactory.Current)
                {
                    throw new InvalidOperationException("DataProviderFactory has not been properly initialized");
                }

                return DataProviderFactory.Current;
            }
        }

        /// <summary>
        /// Indicates if the controller has been disposed.
        /// </summary>
        protected bool IsDisposed { get; set; }

        /// <summary>
        /// Calls the base ApiController's Dispose method.
        /// </summary>
        /// <param name="disposing">Flag to indicate if the instance is being disposed currently.</param>
        protected override void Dispose(bool disposing)
        {
            if (IsDisposed)
            {
                return;
            }

            base.Dispose(disposing);

            IsDisposed = true;
        }

        protected ILogManager GetLogManager()
        {
            ConfigurationManager config = DataProviderFactory.GetProvider<ConfigurationManager>();
            return config.GetLogProvider() as ILogManager;
        }

        protected IAuthorizationManager GetAuthManager()
        {
            ConfigurationManager config = DataProviderFactory.GetProvider<ConfigurationManager>();
            return config.GetAuthorizationManager() as IAuthorizationManager;
        }

        protected ILdapManager GetLdapManager()
        {
            ConfigurationManager config = DataProviderFactory.GetProvider<ConfigurationManager>();
            return config.GetLdapDataProvider() as ILdapManager;
        }

        protected string GetSsoUserIdHeaderName()
        {
            ConfigurationManager config = DataProviderFactory.GetProvider<ConfigurationManager>();
            return config.SsoUserIdHeaderName;
        }
    }
}