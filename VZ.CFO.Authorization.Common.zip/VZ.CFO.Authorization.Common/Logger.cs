﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.Authorization.Common
{
    public static class Logger
    {
        
    }
}
