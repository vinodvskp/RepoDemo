﻿using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.Authorization.Common;
using VZ.CFO.Authorization.Providers.Data;

namespace VZ.CFO.Authorization.Server.Providers
{
    public class DbLdapDataProvider : LdapDataProvider
    {
        public DbLdapDataProvider(string ldapServer, string ldapUserName, string ldapEncryptedPassword, string encryptionSalt)
            : base(ldapServer, ldapUserName, ldapEncryptedPassword, encryptionSalt) 
        { }
        
        protected override bool OnIsAuthenticated(string userName, string encryptedPassword)
        {
            bool isAuthenticated = false;
            try
            {
                DirectoryEntry entry = new DirectoryEntry(this.LdapServerName, userName, Utility.Decrypt(encryptedPassword, this.EncryptionSalt));
                object nativeObject = entry.NativeObject;
                isAuthenticated = true;
            }
            catch (DirectoryServicesCOMException cex)
            {
                isAuthenticated = false;
            }
            catch (Exception ex)
            {
                isAuthenticated = false;
            }
            return isAuthenticated;
        }

        protected override Contracts.Data.Authorization.UserWrapper OnGetUser(string userName)
        {
            Contracts.Data.Authorization.UserWrapper user = null;
            DirectoryEntry entry = new DirectoryEntry();
            entry.Path = this.LdapServerName;
            entry.Username = this.LdapUserName;
            entry.Password = Utility.Decrypt(this.LdapEncryptedPassword, this.EncryptionSalt);

            using (DirectorySearcher mySearcher = new DirectorySearcher(entry))
            {
                mySearcher.PageSize = 5;
                mySearcher.CacheResults = false;
                //Add all properties that need to be fetched   
                mySearcher.PropertiesToLoad.Add("samAccountName");
                mySearcher.PropertiesToLoad.Add("employeeid");
                mySearcher.PropertiesToLoad.Add("employeeNumber");
                //mySearcher.PropertiesToLoad.Add("mail");
                //mySearcher.PropertiesToLoad.Add("sn");
                //mySearcher.PropertiesToLoad.Add("givenname");

                mySearcher.SearchScope = SearchScope.Subtree;

                mySearcher.Filter = string.Format("(&(objectCategory=user)(samAccountName={0}))", userName);
                SearchResult userResult = mySearcher.FindOne();

                if (userResult != null)
                {
                    DirectoryEntry de = userResult.GetDirectoryEntry();
                    user = new Contracts.Data.Authorization.UserWrapper();
                    user.UserName = Convert.ToString(de.Properties["employeeNumber"].Value);
                    user.EmployeeNumber = Convert.ToString(de.Properties["employeeid"].Value);
                    user.Mechanism = Contracts.Data.AuthenticationSource.LDAP;

                    if (string.IsNullOrEmpty(user.UserName))
                    {
                        user.UserName = userName;
                    }
                }
            }
            
            return user;
        }
    }
}
