﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.Authorization.Contracts.Data;
using VZ.CFO.Authorization.Providers.Data;
using Oracle.ManagedDataAccess.Client;
using System.Data;
using VZ.CFO.Authorization.Contracts.Service;
namespace VZ.CFO.Authorization.Server.Providers
{
    public class DbApplicationDataProvider : ApplicationDataProvider
    {
        public DbApplicationDataProvider(string connectionString, string encryptionSalt)
            : base(connectionString, encryptionSalt)
        { }

        protected override long OnSaveApplication(Contracts.Data.Application app)
        {
            throw new NotImplementedException();
        }

        protected override void OnDeleteApplication(long applicationId)
        {
            throw new NotImplementedException();
        }

        protected override Contracts.Data.Application OnGetApplication(long applicationId)
        {
            Application application = new Application();
            string query = string.Format("SELECT Application_Id, Application_Name, Application_Description, Application_Secret FROM AZ_Application WHERE Application_Id = {0}", applicationId);
            using(OracleConnection conn = new OracleConnection(this.ConnectionString))
            using(OracleCommand cmd = new OracleCommand(query, conn))
            {
                conn.Open();
                try
                {
                    using (OracleDataReader dataReader = cmd.ExecuteReader())
                    {
                        int idCol = dataReader.GetOrdinal("Application_Id");
                        int nameCol = dataReader.GetOrdinal("Application_Name");
                        int descCol = dataReader.GetOrdinal("Application_Description");
                        int secretCol = dataReader.GetOrdinal("Application_Secret");
                        if (dataReader.Read())
                        {
                            application.Name = dataReader.GetString(nameCol);
                            application.Description = dataReader.GetString(descCol);
                            application.Id = dataReader.GetInt64(idCol);
                            application.Secret = dataReader.GetString(secretCol);
                        }
                        dataReader.Close();
                    }
                }
                catch
                {
                    throw;
                }
                finally
                {
                    conn.Close();
                }
            }
            return application;
        }

        protected override Contracts.Data.Application[] OnGetApplications()
        {
            throw new NotImplementedException();
        }

        protected override Contracts.Data.Scope[] OnGetApplicationScopes(long applicationId)
        {
            var query = string.Format("SELECT sc.Scope_Id, sc.Scope_Name, sc.Scope_Description FROM AZ_Scope sc INNER JOIN AZ_Application_Scope_Map apsc ON sc.Scope_Id = apsc.Scope_Id WHERE apsc.Application_Id = {0}", applicationId);
            List<Scope> scopes = new List<Scope>();

            using (OracleConnection conn = new OracleConnection(this.ConnectionString))
            using (OracleCommand cmd = new OracleCommand(query, conn))
            {
                conn.Open();
                try
                {
                    using (OracleDataReader dataReader = cmd.ExecuteReader())
                    {
                        int idCol = dataReader.GetOrdinal("Scope_Id");
                        int nameCol = dataReader.GetOrdinal("Scope_Name");
                        int descCol = dataReader.GetOrdinal("Scope_Description");
                        while (dataReader.Read())
                        {
                            scopes.Add(new Scope
                            {
                                Id = dataReader.GetInt64(idCol),
                                Name = dataReader.GetString(nameCol),
                                Description = dataReader.GetString(descCol)
                            });
                        }
                        dataReader.Close();
                    }
                }
                catch
                {
                    throw;
                }
                finally
                {
                    conn.Close();
                }
            }
            return scopes.ToArray();
        }

        protected override void OnAddApplicationScope(long applicationId, long scopeId)
        {
            throw new NotImplementedException();
        }

        protected override void OnDeleteApplicationScope(long applicationId, long scopeId)
        {
            throw new NotImplementedException();
        }
    }
}
