﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.Authorization.Contracts.Data;
using VZ.CFO.Authorization.Providers.Data;

namespace VZ.CFO.Authorization.Server.Providers
{
    public class DbAuthorizationProviderDataProvider : AuthorizationProviderDataProvider
    {
        public DbAuthorizationProviderDataProvider(string connectionString, string encryptionSalt)
            : base(connectionString, encryptionSalt)
        { }

        protected override Contracts.Data.AuthorizationProvider OnGetProvider(long providerId)
        {
            throw new NotImplementedException();
        }

        protected override Contracts.Data.AuthorizationProvider[] OnGetProviders(string scope)
        {
            var query = string.Format("select P.Provider_Id, P.Provider_Name, P.Provider_Uri, Pc.Key, Pc.Value from Az_Provider p " +
            "INNER JOIN Az_Scope_Provider_Map spm ON P.Provider_Id = Spm.Provider_Id " +
            "INNER JOIN Az_Scope s ON S.Scope_Id = Spm.Scope_Id " +
            "LEFT JOIN Az_Provider_Config pc ON Pc.Provider_Id = P.Provider_Id AND Pc.Application_Id IS NULL " +
            "WHERE S.Scope_Name = '{0}'", scope);

            Dictionary<long, AuthorizationProvider> providerIdProviderMap = new Dictionary<long, AuthorizationProvider>();
            Dictionary<long, DbConnectionStringBuilder> providerIdConfigurationMap = new Dictionary<long, DbConnectionStringBuilder>();

            using (OracleConnection conn = new OracleConnection(this.ConnectionString))
            using (OracleCommand cmd = new OracleCommand(query, conn))
            {
                conn.Open();

                try
                {
                    using (OracleDataReader dataReader = cmd.ExecuteReader())
                    {
                        int providerIdCol = dataReader.GetOrdinal("Provider_Id");
                        int providerNameCol = dataReader.GetOrdinal("Provider_Name");
                        int providerUriCol = dataReader.GetOrdinal("Provider_Uri");
                        int keyCol = dataReader.GetOrdinal("Key");
                        int valueCol = dataReader.GetOrdinal("Value");

                        while (dataReader.Read())
                        {
                            long providerId = dataReader.GetInt64(providerIdCol);
                            string configKey = (dataReader.IsDBNull(keyCol) ? string.Empty : dataReader.GetString(keyCol));
                            string configValue = (dataReader.IsDBNull(valueCol) ? string.Empty : dataReader.GetString(valueCol)); //dataReader.GetString(valueCol);
                            // Provider already exists. Add the configuration.
                            if (providerIdConfigurationMap.ContainsKey(providerId) && string.IsNullOrWhiteSpace(configKey) == false)
                            {
                                providerIdConfigurationMap[providerId].Add(configKey, configValue);
                            }
                            else
                            {
                                providerIdProviderMap.Add(providerId, new AuthorizationProvider
                                {
                                    Id = providerId,
                                    Name = dataReader.GetString(providerNameCol),
                                    ProviderUri = dataReader.GetString(providerUriCol),
                                    HasApplicationSpecificConfiguration = false
                                });

                                // Create a new DbConnectionStringBuilder for the current provider.
                                DbConnectionStringBuilder dbConnectionStringBuilder = new DbConnectionStringBuilder();
                                if (string.IsNullOrWhiteSpace(configKey) == false)
                                {
                                    dbConnectionStringBuilder.Add(configKey, configValue);
                                }
                                providerIdConfigurationMap.Add(providerId, dbConnectionStringBuilder);
                            }

                        }
                        dataReader.Close();
                    }
                }
                catch
                {
                    throw;
                }
                finally
                {
                    conn.Close();
                }
            }

            //// Construct the configuration from the map.
            return providerIdProviderMap.Values.Select(provider =>
            {
                provider.Configuration = providerIdConfigurationMap[provider.Id].ConnectionString;
                return provider;
            }).ToArray();
        }

        protected override void OnDelete(long providerId)
        {
            throw new NotImplementedException();
        }

        protected override void OnSave(Contracts.Data.AuthorizationProvider provider)
        {
            throw new NotImplementedException();
        }

        protected override string OnGetProviderApplicationConifguration(long providerId, long applicationId)
        {
            var query = string.Format("SELECT pc.Key, pc.Value FROM Az_Provider_Config pc " +
                            "INNER JOIN Az_Provider p ON p.Provider_Id = Pc.Provider_Id " +
                            "INNER JOIN Az_Application a ON A.Application_Id = Pc.Application_Id " +
                            "WHERE Pc.Provider_Id ={0} AND (Pc.Application_Id IS NULL OR A.Application_Id = {1})", providerId, applicationId);

            DbConnectionStringBuilder dbConnectionStringBuilder = new DbConnectionStringBuilder();

            using (OracleConnection conn = new OracleConnection(this.ConnectionString))
            using (OracleCommand cmd = new OracleCommand(query, conn))
            {
                conn.Open();

                try
                {
                    using (OracleDataReader dataReader = cmd.ExecuteReader())
                    {
                        int keyIndex = dataReader.GetOrdinal("Key");
                        int valueIndex = dataReader.GetOrdinal("Value");

                        while (dataReader.Read())
                        {
                            dbConnectionStringBuilder.Add(dataReader[keyIndex] as string, dataReader[valueIndex] as string);
                        }
                    }
                }
                catch
                {
                    throw;
                }
                finally
                {
                    conn.Close();
                }
            }

            return dbConnectionStringBuilder.ConnectionString;
        }
    }
}
