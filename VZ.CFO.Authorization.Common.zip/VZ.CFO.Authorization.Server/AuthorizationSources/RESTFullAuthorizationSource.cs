﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.Authorization.Providers.Authorization;
using VZ.CFO.Authorization.Common;

namespace VZ.CFO.Authorization.Server.AuthorizationSources
{
    public class RESTFullAuthorizationSource : ClaimAuthorizationSource
    {
        private const int DefaultHttpRequestTimeOutSec = 30;

        /// <summary>
        /// Creates a new instance of RESTFullAuthorizationSource.
        /// </summary>
        /// <param name="config">The configuration required for the RESTful source.</param>
        public RESTFullAuthorizationSource(ProviderConfiguration config)
            : base(config)
        {

        }

        public override Contracts.Data.AuthenticationSource SupportedAuthenticationMechanism
        {
            get
            {
                return Contracts.Data.AuthenticationSource.Any;
            }
        }

        /// <summary>
        /// Gets the claims for the given authenticated user by calling the REST API.
        /// </summary>
        /// <param name="userId">The Id of the user.</param>
        /// <param name="userIdType">The type of authentication.</param>
        /// <returns>Collection of claims for the given authenticated user from REST API.</returns>
        protected override Claim[] OnGetUserClaims(string userId, Contracts.Data.AuthenticationSource userIdType)
        {
            Task<System.Security.Claims.Claim[]> t = Task.Run(() => { return GetUserClaimsFromService(userId, userIdType); });
            t.Wait(DefaultHttpRequestTimeOutSec * 1000);
            
            if (t.IsCompleted)
            {
                return t.Result;
            }
            else
            {
                throw new TimeoutException();
            }
        }

        private async Task<System.Security.Claims.Claim[]> GetUserClaimsFromService(string userId, Contracts.Data.AuthenticationSource userIdType)
        {
            //call Restful Implementation of IAuthorizationSource
            List<System.Security.Claims.Claim> result = new List<System.Security.Claims.Claim>();

            string url = string.Format("{0}/{1}/{2}", base.ConnectionString, userId, userIdType);        
            //string url = string.Format("{0}/{1}/{2}", @"http://eu9sc1wna002.itcent.ebiz.verizon.com/FDMService/api/mdua/useraccess/GetUserAccess", userId, userIdType);

            System.Net.HttpWebRequest client = System.Net.WebRequest.Create(url) as System.Net.HttpWebRequest;
            client.Method = "GET";
            client.Accept = "application/json";
            client.CookieContainer = base.Configuration.ssoCookieContainer;

            try
            {
                using (System.Net.WebResponse response = await client.GetResponseAsync())
                {
                    using (System.IO.MemoryStream data = new System.IO.MemoryStream())
                    {
                        using (System.IO.Stream responseStream = response.GetResponseStream())
                        {
                            await responseStream.CopyToAsync(data);
                        }

                        string json = System.Text.Encoding.UTF8.GetString(data.GetBuffer());

                        //we expect the RESTFul source to implement IAuthorizationSource, which requires return of Claim[] not AuthToken
                        Contracts.Data.CustomClaim[] claims = Newtonsoft.Json.JsonConvert.DeserializeObject<Contracts.Data.CustomClaim[]>(json);
                        foreach (var c in claims)
                        {
                            result.Add(new Claim(c.Type, c.Value));
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }

            return result.ToArray();
        }

    }
}
