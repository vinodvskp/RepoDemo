﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.Authorization.Providers.Authorization;

namespace VZ.CFO.Authorization.Server.AuthorizationSources
{
    public class DBAuthorizationSource : ClaimAuthorizationSource
    {
        public DBAuthorizationSource(ProviderConfiguration config)
            : base(config)
        {
        }

        public override Contracts.Data.AuthenticationSource SupportedAuthenticationMechanism
        {
            get
            {
                return Contracts.Data.AuthenticationSource.Any;
            }
        }

        protected override System.Security.Claims.Claim[] OnGetUserClaims(string userId, Contracts.Data.AuthenticationSource userIdType)
        {
            List<System.Security.Claims.Claim> claimList = new List<System.Security.Claims.Claim>();
            using (OracleConnection oraConn = new OracleConnection(base.Configuration.AuthZDataConnectionString))
            using (OracleCommand oraCommand = new OracleCommand())
            {
                oraConn.Open();

                OracleCommand userInfoUpdateCmd = new OracleCommand(base.Configuration.ConnectionString, oraConn);
                //userInfoUpdateCmd.BindByName = true;
                userInfoUpdateCmd.CommandType = CommandType.StoredProcedure;
                userInfoUpdateCmd.Parameters.Add(new OracleParameter("i_employee_id", OracleDbType.Varchar2)).Value = userId;
                userInfoUpdateCmd.Parameters.Add(new OracleParameter("o_result_cur", OracleDbType.RefCursor, ParameterDirection.Output));

                try
                {
                    using (var dataReader = userInfoUpdateCmd.ExecuteReader())
                    {
                        int claimNameOrdinal = dataReader.GetOrdinal("claim_name");
                        int claimValueOrdinal = dataReader.GetOrdinal("claim_value");

                        while (dataReader.Read())
                        {
                            var claimName = dataReader.IsDBNull(claimNameOrdinal) ? string.Empty : dataReader.GetString(claimNameOrdinal);
                            var claimValue = dataReader.IsDBNull(claimValueOrdinal) ? string.Empty : dataReader.GetString(claimValueOrdinal);
                            if (false == (string.IsNullOrEmpty(claimName) && string.IsNullOrEmpty(claimValue)))
                            {
                                claimList.Add(new System.Security.Claims.Claim(claimName, claimValue));
                            }
                        }
                    }
                }
                catch (Exception ex) 
                {
                    throw ex;
                }
                finally 
                {
                    oraConn.Close();
                }
            }

            return claimList.ToArray();

        }
    }
}
