﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.Authorization.Contracts.Service
{
    [ServiceContract]
    public interface IApplication
    {
        // <summary>
        /// Gets the application that is configured with the authorization server by Id.
        /// </summary>
        /// <param name="applicationId">The Id of the application.</param>
        /// <returns>The application for the given Id.</returns>
        [OperationContract]
        Data.Application GetApplication(long applicationId);

        /// <summary>
        /// Gets all the applications configured with the authorization server.
        /// </summary>
        /// <returns>All the applications configured with the authorization server.</returns>
        [OperationContract]
        Data.Application[] GetApplications();

        /// <summary>
        /// Gets the scopes mapped to a given applicationId.
        /// </summary>
        /// <param name="applicationId">The applicationId for which the scopes need to be returned.</param>
        /// <returns>Collection of scopes mapped under the given applicationId.</returns>
        [OperationContract]
        Data.Scope[] GetApplicationScopes(long applicationId);
    }
}
