﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.Authorization.Contracts.Data.Authorization;

namespace VZ.CFO.Authorization.Contracts.Service
{
    public interface ILdapManager
    {
        bool IsAuthenticated(string userName, string encryptedPassword);
        UserWrapper GetUser(string userName);
    }
}
