﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.Authorization.Contracts.Data;

namespace VZ.CFO.Authorization.Contracts.Service
{
    /// <summary>
    /// Provides services to manage authorization providers.
    /// </summary>
    [ServiceContract]
    public interface IAuthorizationProviderManager : IAuthorizationProvider
    {
        /// <summary>
        /// Deletes the authorization provider based on the given providerId.
        /// </summary>
        /// <param name="providerId">The Id of the provider to delete.</param>
        [OperationContract]
        void Delete(long providerId);

        /// <summary>
        /// Saves a new authorization provider.
        /// </summary>
        /// <param name="provider">The authorization provider to save.</param>
        [OperationContract]
        void Save(AuthorizationProvider provider);
    }
}
