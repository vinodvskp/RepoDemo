﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.Authorization.Contracts.Service
{
    /// <summary>
    /// Constants for API routes.
    /// </summary>
    public static class Routes
    {
        /// <summary>
        /// Root route for all APIs.
        /// </summary>
        public const string Root = "api";

        /// <summary>
        /// Contains shared route parameters.
        /// </summary>
        private static class SharedIdentifiers
        {
            /// <summary>
            /// Route parameter for applicationId.
            /// </summary>
            public const string ApplicationId = "{applicationId}";
        }


        /// <summary>
        /// Contains routes related to tokens.
        /// </summary>
        public static class Token
        {
            private const string rootPath = "/token";

            /// <summary>
            /// Root API path for accessing tokens.
            /// </summary>
            public const string Root = Routes.Root + rootPath;

            /// <summary>
            /// Path with applicationId and issueAsCode parameters.
            /// </summary>
            public const string WebToken = SharedIdentifiers.ApplicationId + "/{issueAsCode:bool}";
            public const string LdapWebToken = "ldaptoken/" +  SharedIdentifiers.ApplicationId + "/{issueAsCode:bool}";
        }
    }
}
