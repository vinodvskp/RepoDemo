﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.Authorization.Contracts.Data;

namespace VZ.CFO.Authorization.Contracts.Service
{
    [ServiceContract]
    public interface IAuthorizationProvider
    {
        /// <summary>
        /// Gets the authorization provider based on the Id.
        /// </summary>
        /// <param name="providerId">The Id of the authorization provider.</param>
        /// <returns>The authorization provider for the given providerId</returns>
        [OperationContract]
        AuthorizationProvider GetProvider(long providerId);

        /// <summary>
        /// Gets a collection of authorization providers for the given scope.
        /// </summary>
        /// <param name="scope">The name of the scope.</param>
        /// <returns>A collection of authorization providers for the given scope.</returns>
        [OperationContract]
        AuthorizationProvider[] GetProviders(string scope);

        /// <summary>
        /// Gets the configuration available for the provider under the given applicationId and
        /// application-independent configuration.
        /// </summary>
        /// <param name="providerId">The Id of the provider.</param>
        /// <param name="applicationId">The Id of the application.</param>
        /// <returns>The configuration for the given provider and application in connection string format:
        /// Ex: ServicePort=443
        /// </returns>
        [OperationContract]
        string GetProviderApplicationConifguration(long providerId, long applicationId);
    }
}
