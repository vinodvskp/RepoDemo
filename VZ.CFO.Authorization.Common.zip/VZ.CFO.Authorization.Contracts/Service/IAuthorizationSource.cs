﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.Authorization.Contracts.Data;

namespace VZ.CFO.Authorization.Contracts.Service
{
    /// <summary>
    /// Provides services to consume claims.
    /// </summary>
    [ServiceContract]
    public interface IAuthorizationSource
    {
        [OperationContract]
        System.Security.Claims.Claim[] GetUserClaims(string userId, AuthenticationSource userIdType);
    }
}
