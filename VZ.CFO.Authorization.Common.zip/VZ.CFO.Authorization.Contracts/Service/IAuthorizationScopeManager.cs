﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.Authorization.Contracts.Data;

namespace VZ.CFO.Authorization.Contracts.Service
{
     [ServiceContract]
    public interface IAuthorizationScopeManager : Contracts.Service.IAuthorizationScope
    {
        /// <summary>
        /// Adds a provider under a scope by its Id.
        /// </summary>
        /// <param name="scopeId">The Id of the scope.</param>
        /// <param name="providerId">The Id of the provider.</param>
        [OperationContract]
         void AddProvider(long scopeId, long providerId);

        /// <summary>
        /// Deletes the association between the given scope and provider.
        /// </summary>
        /// <param name="scopeId">The Id of the scope.</param>
        /// <param name="providerId">The Id of the provider.</param>
        [OperationContract]
        void DeleteProvider(long scopeId, long providerId);

        /// <summary>
        /// Deletes the scope based on the given scopeId.
        /// </summary>
        /// <param name="scopeId">The Id of the scope to delete.</param>
        [OperationContract]
        void Delete(long scopeId);

        /// <summary>
        /// Saves a new scope.
        /// </summary>
        /// <param name="scope">The scope to save.</param>
        [OperationContract]
        void Save(Scope scope);
    }
}
