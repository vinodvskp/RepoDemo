﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.Authorization.Contracts.Data;

namespace VZ.CFO.Authorization.Contracts.Service
{
    /// <summary>
    /// Provides services to consume scopes.
    /// </summary>
    [ServiceContract]
    public interface IAuthorizationScope
    {
        /// <summary>
        /// Gets the scope by its name.
        /// </summary>
        /// <param name="scope">The name of the scope.</param>
        /// <returns>The scope for the given name.</returns>
        [OperationContract]
        Scope GetScope(string scope);

        /// <summary>
        /// Gets a collection of all scopes.
        /// </summary>
        /// <returns>A collection of all scopes.</returns>
        [OperationContract]
        Scope[] GetScopes();
    }
}
