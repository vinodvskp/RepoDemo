﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.Authorization.Contracts.Data;

namespace VZ.CFO.Authorization.Contracts.Service
{
    public interface IClaimManager
    {
        [OperationContract]
        AuthToken ResolveClaim(Guid authorizationCode);
        [OperationContract]
        void RevokeClaim(Guid authorizationCode);
    }
}
