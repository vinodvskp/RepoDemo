﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.Authorization.Contracts.Service
{
    /// <summary>
    /// Provides services to manage application configurations in the authorization server.
    /// </summary>
    [ServiceContract]
    public interface IApplicationManager : IApplication
    {
        /// <summary>
        /// Saves the application in the authorization server. This will be used to configure
        /// applications in the authorization server.
        /// </summary>
        /// <param name="app">The application to save.</param>
        /// <returns>
        /// The Guid that the client application needs to use whenever it needs to interact with the
        /// authorization server.
        /// </returns>
        [OperationContract]
        long SaveApplication(Data.Application app);

        /// <summary>
        /// Removes a configured application from the authorization server.
        /// </summary>
        /// <param name="applicationId">The Id of the application to remove.</param>
        [OperationContract]
        void DeleteApplication(long applicationId);

        /// <summary>
        /// Configures the application to use the scope provided.
        /// </summary>
        /// <param name="applicationId">The Id of the application to add scope to.</param>
        /// <param name="scopeId">The Id of the scope to map to the application.</param>
        [OperationContract]
        void AddApplicationScope(long applicationId, long scopeId);

        /// <summary>
        /// Removes the given scope Id from the application.
        /// </summary>
        /// <param name="applicationId">The Id of the application to remove the scope from.</param>
        /// <param name="scopeId">The Id of the scope mapped to the application.</param>
        [OperationContract]
        void DeleteApplicationScope(long applicationId, long scopeId);
    }
}
