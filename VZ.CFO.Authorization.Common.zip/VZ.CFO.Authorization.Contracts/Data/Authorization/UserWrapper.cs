﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.Authorization.Contracts.Data.Authorization
{
    public class UserWrapper
    {
        public AuthenticationSource Mechanism { get; set; }
        public string UserName { get; set; }
        public string EmployeeNumber { get; set; }
    }
}
