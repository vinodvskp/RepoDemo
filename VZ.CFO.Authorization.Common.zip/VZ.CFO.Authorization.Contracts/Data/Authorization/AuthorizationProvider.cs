﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.Authorization.Contracts.Data
{
    [DataContract]
    public class AuthorizationProvider
    {
        [DataMember]
        public long Id { get; set; }
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string ProviderUri { get; set; }
        [DataMember]
        public long[] Scopes { get; set; }
        [DataMember]
        public string Configuration { get; set; }
        [DataMember]
        public bool HasApplicationSpecificConfiguration { get; set; }
    }
}
