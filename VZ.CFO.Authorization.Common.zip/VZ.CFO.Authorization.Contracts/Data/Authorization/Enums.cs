﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.Authorization.Contracts.Data
{
    public enum AuthenticationSource
    {
        LDAP,
        Sso,
        Any
    }
}
