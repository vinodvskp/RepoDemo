﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Security.Claims;
namespace VZ.CFO.Authorization.Contracts.Data
{
    [DataContract]
    public class AuthToken
    {
        public Claim[] Claims { get; set; }

        public Claim[] Find(string type)
        {
            if (null == Claims)
            {
                return null;
            }

            return (from c in Claims where string.Compare(c.Type, type, true) == 0 select c).ToArray();
        }

        public Claim Find(string type, string value)
        {
            if (null == Claims)
            {
                return null;
            }

            return (from c in Claims where string.Compare(c.Type, type, true) == 0 && string.Compare(c.Value, value, true) == 0 select c).FirstOrDefault();
        }

        public void CopyClaimValue(string type, AuthToken source, bool updateValue)
        {
            if (string.IsNullOrWhiteSpace(type))
            {
                throw new ArgumentException("type cannot be null or whitespace.", "type");
            }
            if (source == null)
            {
                throw new ArgumentNullException("source");
            }

            Claim[] sourceClaims = source.Find(type);
            if (null != sourceClaims && sourceClaims.Length > 0)
            {
                //copy only the first value..., we have no current need for multiple values to be copied...
                EnsureClaim(type, sourceClaims[0].Value, updateValue);
            }
        }

        public void EnsureClaim(string type, string value, bool updateValue)
        {
            //Claim[] claims = this.Find(type);

            //if (claims != null && claims.Any())
            //{
            //    if (updateValue)
            //    {
            //        for (int i = 0; i < claims.Length; i++)
            //        {
            //            claims[i].Value = value;
            //        }
            //    }
            //    return;
            //}

            //// if we're here, means claim was not found
            //List<Claim> list = new List<Claim>();
            //if (this.Claims != null)
            //{
            //    list.AddRange(this.Claims);
            //}

            //list.Add(new Claim(type, value));

            //this.Claims = list.ToArray();

            throw new NotImplementedException();
        }
    }
}
