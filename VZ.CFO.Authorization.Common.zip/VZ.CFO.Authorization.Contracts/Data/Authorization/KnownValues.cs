﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.Authorization.Contracts.Data.Authorization
{
    public static class KnownValues
    {
        public static class Claims
        {
            /// <summary>
            /// Issued At time claim type.
            /// </summary>
            public static class IssuedAt
            {
                /// <summary>
                /// Claim name for Issued At time claim.
                /// </summary>
                public const string ClaimName = "iat";
            }

            /// <summary>
            /// Token Id claim type.
            /// </summary>
            public static class TokenId
            {
                /// <summary>
                /// Claim name for Token Id claim.
                /// </summary>
                public const string ClaimName = "jti";
            }

            /// <summary>
            /// WSSO-issued identity claim type.
            /// </summary>
            public static class SsoIdentity
            {
                /// <summary>
                /// Claim name for WSSO-issued identity claims.
                /// </summary>
                public const string ClaimName = "urn:verizon.identity.sso";
            }

            /// <summary>
            /// Active Directory-issued identity claim type.
            /// </summary>
            public static class AdIdentity
            {
                /// <summary>
                /// Claim name for Active Directory-issued identity claims.
                /// </summary>
                public const string ClaimName = "urn:verizon.identity.ad";
            }

            /// <summary>
            /// NameIdentity claim type.
            /// </summary>
            public static class NameIdentity
            {
                public const string ClaimName = "urn:verizon.claimidentity";
            }
        }
    }
}
