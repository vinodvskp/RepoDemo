﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.Authorization.Contracts.Data
{
    public class Constants
    {
        public const string SsoHttpHeaderEmployeeId = "EMPLOYEEID";
        public const string AdAuthenticatedClientType = "NT NAME";
        public const string SsoAuthenticatedClientType = "EMPLOYEEID";

        public static class SystemDefinedClaimValues
        {
            public const string IssuerAddress = "http://localhost:62236"; //"https://authz.verizon.com";
        }


    }
}
