﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.Authorization.Providers
{
    /// <summary>
    /// The data provider factory class
    /// </summary>
    public class DataProviderFactory
    {
        /// <summary>
        /// Initializes a new instance of the DataProviderFactory class
        /// </summary>
        /// <param name="container">The container.</param>
        private DataProviderFactory(Microsoft.Practices.Unity.IUnityContainer container)
        {
            if (null == container)
            {
                throw new ArgumentNullException("container");
            }
            this.UnityContainer = container;
        }

        /// <summary>
        /// Gets or sets the unity container.
        /// </summary>
        /// <value>
        /// The unity container.
        /// </value>
        private Microsoft.Practices.Unity.IUnityContainer UnityContainer { get; set; }

        /// <summary>
        /// Gets the current.
        /// </summary>
        /// <value>
        /// The current.
        /// </value>
        public static DataProviderFactory Current { get; private set; }

        /// <summary>
        /// Activates the factory instance.
        /// </summary>
        /// <param name="container">The container.</param>
        public static void ActivateFactoryInstace(Microsoft.Practices.Unity.IUnityContainer container)
        {
            //if (null != Current) return;

            //not sure if we want to throw exception or simply replace the "Current" instance
            if (null != Current)
            {
                throw new InvalidOperationException("Provider Factory has already been activated");
            }
            Current = new DataProviderFactory(container);
        }

        /// <summary>
        /// Method called to get provider
        /// </summary>
        //public T GetProvider<T>() where T : BTE.Providers.DataProvider
        //{
        //    //TODO: expand the implementation, if needed...
        //    //return UnityContainer.Resolve(typeof(T), typeof(T).Name) as T;

        //    return UnityContainer.Resolve(typeof(T), typeof(T).Name) as T;
        //}

        /// <summary>
        /// Method called to get provider
        /// </summary>
        public T GetProvider<T>() where T : class
        {
            //TODO: expand the implementation, if needed...
            return (T)UnityContainer.Resolve(typeof(T), typeof(T).Name);
        }
    }
}
