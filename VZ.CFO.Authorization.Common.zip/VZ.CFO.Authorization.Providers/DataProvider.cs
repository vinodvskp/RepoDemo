﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.Authorization.Common;

namespace VZ.CFO.Authorization.Providers
{
    public abstract class DataProvider
    {
        /// <summary>
        /// Initializes a new instance of the DataProvider class
        /// </summary>
        /// <param name="connectionString">The connection string.</param>
        protected DataProvider(string connectionString, string encryptionSalt)
        {
            this.EncryptionSalt = encryptionSalt;
            if (string.IsNullOrEmpty(connectionString) == false)
            {
                if (string.IsNullOrEmpty(encryptionSalt) == false)
                {
                    System.Data.Common.DbConnectionStringBuilder dbConnBuilder = new System.Data.Common.DbConnectionStringBuilder();
                    dbConnBuilder.ConnectionString = connectionString;
                    if (dbConnBuilder.ContainsKey("User Id"))
                    {
                        dbConnBuilder["User Id"] = Utility.Decrypt(dbConnBuilder["User Id"].ToString(), encryptionSalt);
                    }
                    if (dbConnBuilder.ContainsKey("Password"))
                    {
                        dbConnBuilder["Password"] = Utility.Decrypt(dbConnBuilder["Password"].ToString(), encryptionSalt);
                    }
                    this.ConnectionString = dbConnBuilder.ConnectionString;
                }
                else
                {
                    this.ConnectionString = connectionString;
                }
                
            }
        }

        protected DataProvider(string ldapServerName, string ldapUserName, string ldapEncryptedPassword, string encryptionSalt)
        {
            this.LdapServerName = ldapServerName;
            this.LdapUserName = ldapUserName;
            this.LdapEncryptedPassword = ldapEncryptedPassword;
            this.EncryptionSalt = encryptionSalt;
        }

        /// <summary>
        /// Gets the connection string.
        /// </summary>
        /// <value>
        /// The connection string.
        /// </value>
        protected string ConnectionString { get; private set; }

        protected string LdapServerName { get; private set; }
        protected string LdapUserName { get; private set; }
        protected string LdapEncryptedPassword { get; private set; }
        protected string EncryptionSalt { get; private set; }
    }
}
