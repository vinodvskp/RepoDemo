﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.Authorization.Providers.Authorization
{
    public class ProviderConfiguration
    {
        /// <summary>
        /// Initializes a new instance of ProviderConfiguration.
        /// </summary>
        /// <param name="connectionString">The connection string for the provider.</param>
        public ProviderConfiguration(string connectionString, System.Net.CookieContainer ssoCookieContainer, string authZDataConnectionString)
        {
            this.ssoCookieContainer = ssoCookieContainer;
            string[] connectionStringSplit = connectionString.Split('=');
            if (connectionStringSplit.Length == 2 && string.IsNullOrEmpty(connectionStringSplit[1]) == false)
            {
                this.ConnectionString = connectionStringSplit[1];
            }
            else
            {
                this.ConnectionString = connectionString;
            }
            this.AuthZDataConnectionString = authZDataConnectionString;
        }

        /// <summary>
        /// The connection string for the provider.
        /// </summary>
        public string ConnectionString { get; set; }

        public System.Net.CookieContainer ssoCookieContainer { get; set; }

        public string AuthZDataConnectionString { get; set; }
    }
}
