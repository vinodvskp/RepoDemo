﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.Authorization.Contracts.Data;
using VZ.CFO.Authorization.Contracts.Data.Authorization;

namespace VZ.CFO.Authorization.Providers.Authorization
{
    public interface IAuthorizationManager : VZ.CFO.Authorization.Contracts.Service.IClaim
    {
        Contracts.Data.AuthToken Authorize(long applicationId, UserWrapper[] user, System.Net.CookieContainer ssoCookieContainer);

        string ToJWT(Contracts.Data.AuthToken token, Application application);

        Contracts.Data.Application GetRegisteredApplicationById(long applicationId);
    }
}
