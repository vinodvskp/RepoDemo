﻿using Microsoft.Owin.Security.DataHandler.Encoder;
using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.Authorization.Contracts.Data;
using VZ.CFO.Authorization.Contracts.Data.Authorization;
using VZ.CFO.Authorization.Contracts.Service;
using VZ.CFO.Authorization.Common;
namespace VZ.CFO.Authorization.Providers.Authorization
{
    public class AuthorizationManager : IAuthorizationManager
    {
        /// <summary>
        /// IApplicationManager instance.
        /// </summary>
        private IApplicationManager applicationDataProvider;

        /// <summary>
        /// IAuthorizationProviderManager instance.
        /// </summary>
        private IAuthorizationProviderManager authorizationProviderDataProvider;

        /// <summary>
        /// The token expiration time duration (in hours).
        /// </summary>
        private double tokenExpirationDurationHours;

        private string dbProviderConnectionString;

        private string encryptSalt;

        public AuthorizationManager(IAuthorizationProviderManager authorizationProviderDataProvider, IApplicationManager applicationDataProvider,
            double tokenExpirationDurationHours, string dbProviderConnectionString, string encryptSalt)
        {
            if (authorizationProviderDataProvider == null)
            {
                throw new ArgumentNullException("authProviderProvider");
            }
            if (applicationDataProvider == null)
            {
                throw new ArgumentNullException("appDataProvider");
            }
            
            this.authorizationProviderDataProvider = authorizationProviderDataProvider;
            this.applicationDataProvider = applicationDataProvider;
            this.tokenExpirationDurationHours = tokenExpirationDurationHours;
            this.dbProviderConnectionString = dbProviderConnectionString;
            this.encryptSalt = encryptSalt;
        }



        /// <summary>
        /// Gets the names of application scopes mapped to the given application.
        /// </summary>
        /// <param name="appId">The Id of the application requesting authorization.</param>
        /// <returns>The names of application scopes mapped to the given application.</returns>
        private string[] GetApplicationScopes(long appId)
        {
            Scope[] scopes = this.applicationDataProvider.GetApplicationScopes(appId);
            if (scopes == null)
            {
                return null;
            }
            return scopes.Select(scope => scope.Name).Distinct(StringComparer.CurrentCultureIgnoreCase).ToArray();
        }

        /// <summary>
        /// Creates a list of ClaimsAuthorizationSource from AuthorizationProvider associated with a scope.
        /// </summary>
        /// <param name="scopes">List of scopes for which providers need to be obtained.</param>
        /// <returns>List of ClaimsAuthorizationSource.</returns>
        private IEnumerable<ClaimAuthorizationSource> GetAuthorizationSources(long applicationId, System.Net.CookieContainer ssoCookieContainer)
        {
            List<ClaimAuthorizationSource> authorizationSources = new List<ClaimAuthorizationSource>();

            //keeps track of processed scope, in case scopes[] has duplicate entries
            List<string> processedScopes = new List<string>();

            // get scopes from app
            string[] scopes = GetApplicationScopes(applicationId);

            if (scopes == null || !scopes.Any())
            {
                return authorizationSources.AsReadOnly();
            }

            // keeps track of processed providers in case the same provider is configured in different scopes
            List<long> processedProviders = new List<long>();
            foreach (string scope in scopes)
            {
                // check if scope has already been processed -- this also dedups scope array
                if (processedScopes.Contains(scope))
                {
                    continue;
                }
                AuthorizationProvider[] scopeProviders = authorizationProviderDataProvider.GetProviders(scope);

                foreach (AuthorizationProvider provider in scopeProviders)
                {
                    if (processedProviders.Contains(provider.Id))
                    {
                        continue;
                    }
                    // create instance of provider source based on config
                    ClaimAuthorizationSource authSource = CreateAuthorizationSource(provider, applicationId, ssoCookieContainer);
                    if (null != authSource)
                    {
                        authorizationSources.Add(authSource);
                    }
                    processedProviders.Add(provider.Id);
                }
                processedScopes.Add(scope);
            }

            return authorizationSources.AsReadOnly();
        }

        /// <summary>
        /// Instantiates a ClaimsAuthorizationScource from the configuration information provided by the AuthorizationProvider data contract.
        /// </summary>
        /// <param name="info">The authorization provider.</param>
        /// <returns>A ClaimsAuthorizationScource instance from the configuration information provided by the AuthorizationProvider data contract.</returns>
        private ClaimAuthorizationSource CreateAuthorizationSource(AuthorizationProvider info, long applicationId, System.Net.CookieContainer ssoCookieContainer)
        {
            if (info == null)
            {
                throw new ArgumentNullException("info");
            }

            string config = info.HasApplicationSpecificConfiguration
                                ? authorizationProviderDataProvider.GetProviderApplicationConifguration(info.Id, applicationId)
                                : info.Configuration;

            Type providerType = Type.GetType(info.ProviderUri);

            return Activator.CreateInstance(providerType, new object[] { new ProviderConfiguration(config, ssoCookieContainer, BuildConnectionString(dbProviderConnectionString, encryptSalt)) }) as ClaimAuthorizationSource;
        }


        /// <summary>
        /// Adds system defined claims (that are managed by the authorization server) with the provided claims.
        /// </summary>
        /// <param name="applicationId">The Id of the application requesting authorization.</param>
        /// <param name="claims">The claims obtained from authorization sources.</param>
        /// <returns>System defined claims added with the provided claims.</returns>
        private static System.Security.Claims.Claim[] AddSystemDefinedClaims(List<System.Security.Claims.Claim> claims)
        {
            claims.AddRange(new List<System.Security.Claims.Claim>
            {
                new Claim(KnownValues.Claims.IssuedAt.ClaimName, DateTime.UtcNow.ToString()),
                new Claim(KnownValues.Claims.TokenId.ClaimName, Guid.NewGuid().ToString()),
                //new Claim { Type = Claims.AuthorizationCode.ClaimName, Value = Guid.NewGuid().ToString() },
                //new Claim { Type = Claims.Expiration.ClaimName, Value = DateTime.UtcNow.Add(expirationTime).ToString() },
                //new Claim { Type = Claims.Issuer.ClaimName, Value = Constants.SystemDefinedClaimValues.IssuerAddress },
                //new Claim { Type = Claims.Audience.ClaimName, Value = applicationId.ToString() },
                //new Claim { Type = Claims.IssuedAt.ClaimName, Value = DateTime.UtcNow.ToString() },
                //new Claim { Type = Claims.TokenId.ClaimName, Value = Guid.NewGuid().ToString() },         
                //new Claim { Type = Claims.EncryptionAlgorithm.ClaimName, Value = Encryption.Helper.HashAlgorithm.RS256.ToString() },
            });
            return claims.ToArray();
        }

        private string BuildConnectionString(string connectionString, string encryptionSalt)
        {
            string formedConnectionString = connectionString;
            if (string.IsNullOrEmpty(connectionString) == false)
            {
                if (string.IsNullOrEmpty(encryptionSalt) == false)
                {
                    System.Data.Common.DbConnectionStringBuilder dbConnBuilder = new System.Data.Common.DbConnectionStringBuilder();
                    dbConnBuilder.ConnectionString = connectionString;
                    if (dbConnBuilder.ContainsKey("User Id"))
                    {
                        dbConnBuilder["User Id"] = Utility.Decrypt(dbConnBuilder["User Id"].ToString(), encryptionSalt);
                    }
                    if (dbConnBuilder.ContainsKey("Password"))
                    {
                        dbConnBuilder["Password"] = Utility.Decrypt(dbConnBuilder["Password"].ToString(), encryptionSalt);
                    }
                    formedConnectionString = dbConnBuilder.ConnectionString;
                }
                else
                {
                    formedConnectionString = connectionString;
                }
            }

            return formedConnectionString;
        }

        public Contracts.Data.AuthToken Authorize(long applicationId, UserWrapper[] user, System.Net.CookieContainer ssoCookieContainer)
        {
            if (null == user)
            {
                throw new ArgumentNullException("user", "User cannot be null");
            }

            if (0 == user.Length)
            {
                throw new ArgumentException("user array cannot be empty.", "user");
            }

            IEnumerable<ClaimAuthorizationSource> authorizationSources = GetAuthorizationSources(applicationId, ssoCookieContainer);

            if (authorizationSources == null)
            {
                return null;
            }
            List<Claim> claims = new List<Claim>();
            // we'll want to invoke in sources in parallel
            ParallelLoopResult result = Parallel.ForEach(authorizationSources, source =>
            {
                UserWrapper uw = null;
                try
                {
                    if (source.SupportedAuthenticationMechanism == AuthenticationSource.Any)
                    {
                        uw = user[0];
                    }
                    else
                    {
                        uw = (from u in user where u.Mechanism == source.SupportedAuthenticationMechanism select u).FirstOrDefault();
                    }

                    if (null != uw) // should we be ignoring any source that can't participate?
                    {
                        Claim[] userClaims = source.GetUserClaims(uw.UserName, uw.Mechanism);
                        if (userClaims != null && userClaims.Any())
                        {
                            // lock claims collection to make sure different thread don't try to add at same time
                            lock (claims)
                            {
                                claims.AddRange(userClaims);
                            }
                        }
                    }
                }
                catch
                {
                    throw;
                }
            });

            if (result.IsCompleted == false)
            {
                return null;
            }

            UserWrapper ssoUser = (from u in user where u.Mechanism == AuthenticationSource.Sso select u).FirstOrDefault();
            UserWrapper adUser = (from u in user where u.Mechanism == AuthenticationSource.LDAP select u).FirstOrDefault();

            // Add Identity token.
            if (null != ssoUser)
            {
                claims.Add(new System.Security.Claims.Claim(KnownValues.Claims.SsoIdentity.ClaimName, ssoUser.UserName));
                claims.Add(new System.Security.Claims.Claim(KnownValues.Claims.NameIdentity.ClaimName, ssoUser.UserName));
            }

            if (null != adUser)
            {
                claims.Add(new System.Security.Claims.Claim(KnownValues.Claims.AdIdentity.ClaimName, adUser.UserName));
                claims.Add(new System.Security.Claims.Claim(KnownValues.Claims.NameIdentity.ClaimName, adUser.UserName));
            }

            // Create token with system-defined claims added.
            AuthToken token = new AuthToken
            {
                Claims = AddSystemDefinedClaims(claims)
            };
            return token;
        }

        public string ToJWT(Contracts.Data.AuthToken token, Contracts.Data.Application application)
        {
            if (token == null)
            {
                throw new ArgumentNullException("token");
            }

            if (token.Claims == null || !token.Claims.Any())
            {
                throw new ArgumentException("token must have claims.", "token.Claims");
            }

            string symmetricKeyAsBase64 = application.Secret;
            var keyByteArray = TextEncodings.Base64Url.Decode(symmetricKeyAsBase64);
            var hmacSign = new HMACSHA256(keyByteArray);
            var securityKey = new Microsoft.IdentityModel.Tokens.SymmetricSecurityKey(hmacSign.Key);
            var signingKey = new Microsoft.IdentityModel.Tokens.SigningCredentials(securityKey, "HS256");
            var issued = DateTime.UtcNow;
            var expires = DateTime.UtcNow.Add(TimeSpan.FromHours(tokenExpirationDurationHours));
            var issuer = Constants.SystemDefinedClaimValues.IssuerAddress;
            var securityToken = new JwtSecurityToken(issuer, application.Name, token.Claims, issued, expires, signingKey);
            var handler = new JwtSecurityTokenHandler();
            var jwt = handler.WriteToken(securityToken);
            return jwt;
        }

        public Contracts.Data.Application GetRegisteredApplicationById(long applicationId)
        {
            Application application = null;
            application = applicationDataProvider.GetApplication(applicationId);
            return application;
        }

        public string IssueToken(long applicationId, bool issueAsCode)
        {
            throw new NotImplementedException();
        }

        public Contracts.Data.AuthToken Authorize(long applicationId, string userId, Contracts.Data.AuthenticationSource authenticationSourceType, System.Net.CookieContainer ssoCookieContainer)
        {
            if (string.IsNullOrWhiteSpace(userId))
            {
                throw new ArgumentException("userId cannot be null or empty.", "userId");
            }

            return Authorize(applicationId, new UserWrapper[] { new UserWrapper() { UserName = userId, Mechanism = authenticationSourceType } }, ssoCookieContainer);
        }

        public Contracts.Data.AuthToken ResolveClaim(Guid authorizationCode)
        {
            throw new NotImplementedException();
        }

        public void RevokeClaim(Guid authorizationCode)
        {
            throw new NotImplementedException();
        }
    }
}
