﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.Authorization.Contracts.Service;

namespace VZ.CFO.Authorization.Providers.Authorization
{
    public interface IClaimManagerDataProvider: IClaimManager
    {
        Contracts.Data.AuthToken CreateCodeToken(Contracts.Data.AuthToken token);

        void SaveToken(Contracts.Data.AuthToken token);
    }
}
