﻿using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.Authorization.Common;
using VZ.CFO.Authorization.Contracts.Service;

namespace VZ.CFO.Authorization.Providers.Data
{
    public abstract class LdapDataProvider : DataProvider, ILdapManager
    {
        public LdapDataProvider(string ldapServer, string ldapUserName, string ldapEncryptedPassword, string encryptionSalt)
            : base(ldapServer, ldapUserName, ldapEncryptedPassword, encryptionSalt)
        {
        }

        public bool IsAuthenticated(string userName, string encryptedPassword)
        {
            return OnIsAuthenticated(userName, encryptedPassword);
        }

        public Contracts.Data.Authorization.UserWrapper GetUser(string userName)
        {
            return OnGetUser(userName);
        }

        protected abstract bool OnIsAuthenticated(string userName, string encryptedPassword);
        
        protected abstract Contracts.Data.Authorization.UserWrapper OnGetUser(string userName);
    }
}
