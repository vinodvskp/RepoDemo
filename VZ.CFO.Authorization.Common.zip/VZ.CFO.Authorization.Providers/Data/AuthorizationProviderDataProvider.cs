﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.Authorization.Providers.Data
{
    public abstract class AuthorizationProviderDataProvider : DataProvider, Contracts.Service.IAuthorizationProviderManager
    {
        protected AuthorizationProviderDataProvider(string connectionString, string encryptionSalt)
            : base(connectionString, encryptionSalt)
        {
        }

        public void Delete(long providerId)
        {
            OnDelete(providerId);
        }

        public void Save(Contracts.Data.AuthorizationProvider provider)
        {
            if (null == provider)
            {
                throw new ArgumentNullException("provider");
            }
            OnSave(provider);
        }

        public Contracts.Data.AuthorizationProvider GetProvider(long providerId)
        {
            return OnGetProvider(providerId);
        }

        public Contracts.Data.AuthorizationProvider[] GetProviders(string scope)
        {
            if (string.IsNullOrEmpty(scope))
            {
                throw new ArgumentNullException("scope");
            }
            return OnGetProviders(scope);
        }

        public string GetProviderApplicationConifguration(long providerId, long applicationId)
        {
            return OnGetProviderApplicationConifguration(providerId, applicationId);
        }

        protected abstract Contracts.Data.AuthorizationProvider OnGetProvider(long providerId);

        protected abstract Contracts.Data.AuthorizationProvider[] OnGetProviders(string scope);

        protected abstract void OnDelete(long providerId);

        protected abstract void OnSave(Contracts.Data.AuthorizationProvider provider);

        protected abstract string OnGetProviderApplicationConifguration(long providerId, long applicationId);
    }
}
