﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VZ.CFO.Authorization.Contracts.Service;

namespace VZ.CFO.Authorization.Providers.Data
{
    public abstract class LogProvider : DataProvider, ILogManager
    {
        
        public LogProvider(string logLocation) : base(logLocation, null) { }
        
        public void LogMessage(string module, string message)
        {
            OnLogMessage(module, message);
        }

        public void LogException(string module, Exception ex)
        {
            OnLogException(module, ex);
        }

        protected abstract void OnLogMessage(string module, string message);
        protected abstract void OnLogException(string module, Exception ex);
        
    }
}
