﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VZ.CFO.Authorization.Providers.Data
{
    public abstract class ApplicationDataProvider : DataProvider, Contracts.Service.IApplicationManager
    {
        protected ApplicationDataProvider(string connectionString, string encryptionSalt)
            : base(connectionString, encryptionSalt)
        { 
        }

        public long SaveApplication(Contracts.Data.Application app)
        {
            if (null == app)
            {
                throw new ArgumentNullException("app");
            }
            return OnSaveApplication(app);
        }

        public void DeleteApplication(long applicationId)
        {
            OnDeleteApplication(applicationId);
        }

        public void AddApplicationScope(long applicationId, long scopeId)
        {
            OnAddApplicationScope(applicationId, scopeId);
        }

        public void DeleteApplicationScope(long applicationId, long scopeId)
        {
            OnDeleteApplicationScope(applicationId, scopeId);
        }

        public Contracts.Data.Application GetApplication(long applicationId)
        {
            return OnGetApplication(applicationId);
        }

        public Contracts.Data.Application[] GetApplications()
        {
            return OnGetApplications();
        }

        public Contracts.Data.Scope[] GetApplicationScopes(long applicationId)
        {
            return OnGetApplicationScopes(applicationId);
        }

        protected abstract long OnSaveApplication(Contracts.Data.Application app);

        protected abstract void OnDeleteApplication(long applicationId);

        protected abstract Contracts.Data.Application OnGetApplication(long applicationId);

        protected abstract Contracts.Data.Application[] OnGetApplications();

        protected abstract Contracts.Data.Scope[] OnGetApplicationScopes(long applicationId);

        protected abstract void OnAddApplicationScope(long applicationId, long scopeId);

        protected abstract void OnDeleteApplicationScope(long applicationId, long scopeId);
    }
}
